-- ============================================
-- US Market Logistics Tracking (17Track API)
-- ============================================

-- 1. Add US carriers to eb_express
INSERT INTO `eb_express` (`name`, `code`, `partner_id`, `partner_key`, `net`, `account`, `key`, `net_name`, `is_show`, `status`, `sort`)
VALUES
  ('UPS', 'ups', 0, 0, 0, '', '', '', 1, 1, 10),
  ('USPS', 'usps', 0, 0, 0, '', '', '', 1, 1, 20),
  ('FedEx', 'fedex', 0, 0, 0, '', '', '', 1, 1, 30),
  ('DHL', 'dhl', 0, 0, 0, '', '', '', 1, 1, 40)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- 2. Add 17Track API key config
INSERT INTO `eb_system_config` (`menu_name`, `type`, `config_tab_id`, `parameter`, `upload_type`, `required`, `info`, `desc`, `sort`, `status`, `value`)
VALUES
  ('system_17track_api_key', 'text', 0, '', 0, '', '17Track API Key', '17Track物流追踪API密钥', 0, 1, '""')
ON DUPLICATE KEY UPDATE `info` = VALUES(`info`);

-- 3. Set logistics_type to 3 (17Track) for US market
-- Uncomment below to switch; or set manually in admin backend:
-- UPDATE `eb_system_config` SET `value` = '"3"' WHERE `menu_name` = 'logistics_type';
