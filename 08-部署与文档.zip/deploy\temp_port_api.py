# -*- coding: utf-8 -*-
import io, os

SRC = r'D:\eccomall\mobile-app-v3\lib\api'
DST = r'D:\eccomall\mobile-app\lib\api'

mapping = {
    'reward-coins.ts': 'rewardCoins.ts',
    '游戏补币.ts': 'gameWallet.ts',
    '积分购买.ts': 'pointPurchase.ts',
    '海底寻珠.ts': 'pearl.ts',
    'pet.ts': 'petWorld.ts',
}

repls = [
    ('@/lib/api/http', '@/lib/api/legacyHttp'),
    ('@/lib/api/游戏补币', '@/lib/api/gameWallet'),
]

for sname, dname in mapping.items():
    s = io.open(os.path.join(SRC, sname), encoding='utf-8').read()
    for a, b in repls:
        s = s.replace(a, b)
    io.open(os.path.join(DST, dname), 'w', encoding='utf-8', newline='\n').write(s)
    print('ported', sname, '->', dname, len(s))
