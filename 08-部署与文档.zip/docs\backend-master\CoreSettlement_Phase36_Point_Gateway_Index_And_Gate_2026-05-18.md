# CoreSettlement Phase 36 Point Gateway Index And Gate 2026-05-18

## Current Task

Phase 36 creates a compact Point Gateway index and gate checklist.

No code path was enabled.
No route was exposed.
No SQL was executed.
No DB write was added.
No production deployment was executed.

## Completed Scope

```text
Phase 19: PointTransactionService dry-run gateway
Phase 20: point entry audit
Phase 21: admin/AI management design
Phase 22: farm/mine/checkin shadow hooks
Phase 23: point ledger table design draft
Phase 24: dry-run store adapter skeleton
Phase 25: disabled DB store skeleton
Phase 26: migration readiness assert
Phase 27: admin read service skeleton
Phase 28: admin controller skeleton, unexposed
Phase 29: readonly route contract, unexposed
Phase 30: reconciliation skeleton
Phase 31: admin filter hardening
Phase 32: legacy user_bill mapper
Phase 33: reconciliation mapper wiring
Phase 34: frozen/expiry readonly lists
Phase 35: AI operation log draft
```

## Current Runtime State

```text
PointTransaction default store: DryRunPointTransactionStore
DbPointTransactionStore selected: false
route/admin.php exposed: false
deploy SQL created: false
production deploy: false
switch activation: false
Manghe/order/payment integration: false
```

## Assert Pack

```text
point_transaction_gateway_assert
point_transaction_persistence_assert
point_transaction_migration_readiness_assert
point_gateway_admin_controller_assert
point_gateway_admin_read_assert
point_gateway_admin_route_contract_assert
point_gateway_reconciliation_assert
legacy_point_bill_mapper_assert
point_gateway_ai_operation_log_assert
core_settlement_backend_package_assert
```

## Gate Before Route Exposure

Required before exposing `adminapi/core/point_gateway/*`:

```text
1. route/admin.php adds GET only
2. no POST/PUT/DELETE point_gateway routes
3. no menu SQL execution in same phase
4. no DB store enablement in same phase
5. no rollback execution endpoint
6. no fix_user_points/manual_adjust endpoint
7. all asserts pass after route change
```

## Gate Before DB Store Enablement

Required before selecting `DbPointTransactionStore`:

```text
1. approved migration SQL
2. production table existence verified readonly
3. rollback/freeze/expiry semantics accepted
4. reconciliation read path accepted
5. shadow mode observed with real traffic
6. kill switch documented
7. rollback plan documented
```

## Do Not Do Yet

```text
execute SQL
deploy route/menu change
enable DB store
connect Manghe/order/payment
add rollback execution
add automatic point fix
```
