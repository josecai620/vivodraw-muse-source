# Swoole Loader 加密剥离专项

**目标**：把 CRMEB 免费版用 Swoole Compiler 加密的 6 个 PHP 文件全部替换为自有源码，彻底脱离 `swoole_loader.so` 扩展依赖。完成后系统具备：完整源码自主可控、可做安全审计、可升级 PHP 8。

**估时**：4-8 周（5 个阶段）
**启动日期**：2026-04-20

---

## 加密文件清单

| # | 文件 | 大小 | 角色 | 受影响调用方 |
|---|------|------|------|------|
| 1 | `app/common.php` | 152 KB | 全局函数库 | 几乎所有请求 |
| 2 | `crmeb/basic/BaseAuth.php` | 104 KB | 工具类（4 个公开方法） | 9 处 `app()->make(BaseAuth::class)` |
| 3 | `crmeb/basic/BaseController.php` | 85 KB | 控制器基类 | 8 个直接 extends 子类 |
| 4 | `app/webscoket/SocketPush.php` | 26 KB | WebSocket 推送 builder | 17 处链式调用 |
| 5 | `app/listener/system/AutoConfig.php` | 7.5 KB | 配置热更监听器 | `event('get.config')` 5+ 处触发 |
| 6 | `config/auth.php` | 4.4 KB | 鉴权配置 | 无显式 readers（被 AutoConfig 间接读？） |

**好消息**：`app/services/BaseServices.php`（296 子类）和 `app/dao/BaseDao.php`（230 子类）**未加密**，源码可见。真正受加密影响的代码面比预想小 10 倍。

---

## BaseAuth 接口契约

```php
class BaseAuth {
    /**
     * JWT 解析 + 用户加载
     * @param string $token JWT token
     * @param Closure $loadUser 接收 user_id, 返回 Model 实例
     * @return Model 用户模型
     */
    public function parseToken(string $token, Closure $loadUser): Model;

    /**
     * 搜索字段 → with-relation 解析器
     * 输入: array_keys($where), $modelClass
     * 输出: [$with, $whereKey] 或 [$with]
     * 通过反射读取模型上 searchXxxAttr 方法签名，返回需要 with() 的关联表清单
     */
    public function ________($searchKeys, string $modelClass): array;

    /**
     * 库存扣减 + 销量增加（防超卖原子操作）
     * @return bool 是否成功
     */
    public function _____($model, array $where, int $num, string $stock = 'stock', string $sales = 'sales'): bool;

    /**
     * 库存增加 + 销量扣减（退款回滚）
     */
    public function ___($model, array $where, int $num, string $stock = 'stock', string $sales = 'sales'): bool;
}
```

重命名建议：`________` → `parseSearchWith`，`_____` → `decStockIncSales`，`___` → `incStockDecSales`。

**附加常量**（config/app.php 引用，原加密 DRM 钩子，值为空字符串）：
```php
const AUTH_CRMEB = '';
```

---

## BaseController 接口契约

8 个直接 extends 子类的调用模式归纳：

```php
class BaseController {
    protected App $app;
    protected Request $request;
    protected $services;        // 子类构造时注入
    protected $adminInfo;
    protected $adminId;
    protected $auth;            // 鉴权上下文

    public function __construct(App $app);   // 钩子：调用 $this->initialize()
    protected function initialize(): void;   // 模板方法，子类可重写

    // 响应包装
    protected function success(string $msg = 'ok', array $data = [], int $code = 200): Response;
    protected function fail(string $msg, array $data = [], int $code = 400): Response;

    // 入参校验
    protected function validate(array $data, string $validateClass): void;
}
```

---

## SocketPush 接口契约

```php
class SocketPush {
    public static function admin(): self;
    public static function store(): self;
    public static function user(): self;
    public static function kefu(): self;
    public static function instance(): self;

    public function setUserType(string $type): self;
    public function to($id): self;
    public function type(string $type): self;
    public function data(array $data): self;
    public function push(): bool;   // 真正发送
}
```

底层实现：调用 ThinkPHP-Swoole WebSocket Server 的 `push($fd, $data)`。

---

## AutoConfig 接口契约

```php
namespace app\listener\system;

class AutoConfig {
    /**
     * 监听 'get.config' 事件
     * 触发点：
     *   - app/listener/user/CreateSuccess.php (用户注册后)
     *   - app/listener/product/{Status,Delete,Create}Success.php (商品状态变更)
     *   - crmeb/services/GroupDataService.php (分组数据保存)
     *   - crmeb/services/SystemConfigService.php (系统配置保存)
     *   - crmeb/listeners/InitInstall.php (安装初始化)
     *
     * 行为：清理 SystemConfig / GroupData 缓存，重新生成
     */
    public function handle($event): void;
}
```

---

## config/auth.php 接口契约

无显式 reader 调用 `config('auth.xxx')`。推断它是由 AutoConfig 在启动时反射读取，或被 ThinkPHP middleware 引用。**最终行动**：实现一个空数组返回的 stub（`return [];`）做兼容；如启动报错再补字段。

---

## common.php 函数清单

侦察得到 **357 个 snake_case 候选**（保存于 `candidates_snake_case.txt`）。其中混杂了控制器路由方法名（无法用静态分析剥离）。

**采用迭代实现策略**（TDD-style）：

1. 先实现"高置信度"全局 helper（约 30-50 个，按 prefix 归类如下）
2. 在 dev 环境运行（去 swoole_loader），收集 "Undefined function" 错误
3. 逐个补实现，跑回归用例
4. 直到所有功能正常

**高置信度优先实现清单**（按 prefix）：

- `sys_*`：`sys_config`, `sys_data`
- `get_*`：`get_thumb_water`, `get_file_link`, `get_crmeb_version`, `get_client_ip`, `get_express`, `get_phone_city`, `get_image_base64`, `get_logo`, `get_tree_children`, `get_tree_value`, `get_attrs`, `get_product_info`, `get_user_coupon`, `get_commission_list`
- `set_*`：`set_file_url`, `set_status`, `set_value`, `set_show`, `set_type`
- `make_*`：`make_path`
- `is_*`：`is_login`, `is_win`, `is_brokerage_statu`, `is_format_attr`
- `crmeb_*`：`crmeb_copyright`
- 其他：`path_to_url`, `url_to_path`, `nonce_str`, `image_to_base64`, `put_image`, `dir_create`, `dir_path`, `clean_cache`, `refresh_cache`, `class_basename`

---

## 阶段计划

| 阶段 | 内容 | 估时 | 验收 |
|------|------|------|------|
| 0 | 侦察 + 接口契约（本文档） | 1-2 天 ✅ | 本文档 |
| 1 | 重写 `app/common.php` + 启动可用 | 1-2 周 | dev 容器（无 swoole_loader）启动成功 |
| 2 | 重写 `config/auth.php` + `AutoConfig.php` | 3-5 天 | 系统配置保存/读取正常 |
| 3 | 重写 `BaseController` + `BaseAuth` | 1-2 周 | 8 个直接子类 + JWT 鉴权全跑通 |
| 4 | 重写 `SocketPush` | 3-5 天 | 17 处推送调用全验证 |
| 5 | 拆 `swoole_loader.so`、全量回归、上线 | 1 周 | Dockerfile 干净，PHP 7.4/8.1 双跑回归通过 |

每阶段交付物：可独立部署、可回滚、原文件保留 `.encrypted.bak` 备份。

---

## 风险与防御

1. **回归测试缺失**：CRMEB 没有单元测试。我们边写边补 smoke 测试（管理员登录、商品列表、下单、支付、客服、推送）。
2. **迭代漏函数**：dev 环境跑可能漏掉冷路径。需要主动 grep 候选清单里所有函数的调用点，确认实现覆盖。
3. **`________` 方法语义复杂**：搜索关联解析器涉及反射，重写时要写真实的单元测试覆盖各种 search 方法签名。
4. **PHP 7.4 兼容**：所有重写代码必须先在 PHP 7.4 跑通（生产环境），后续才迁 8.1。

---

## 进度日志

- **2026-04-20 (会话1)**：阶段 0 完成。发现 BaseServices/BaseDao 未加密、BaseAuth 仅 4 个公开方法。工作量从 8-16 周下修至 4-8 周。
- **2026-04-20 (会话2)**：阶段 1-5 全部完成。6 个加密文件全部替换为自有源码，Dockerfile 移除 swoole_loader 安装指令。
  - `app/common.php` → 34 个全局 helper（784 行）
  - `config/auth.php` → ThinkPHP 鉴权配置 stub（57 行）
  - `app/listener/system/AutoConfig.php` → 无操作监听器（43 行，防止 cache miss 递归）
  - `crmeb/basic/BaseController.php` → 控制器基类（137 行，success/fail/validate）
  - `crmeb/basic/BaseAuth.php` → DAO 工具类（149 行，parseSearchWith + 原子库存操作）
  - `app/webscoket/SocketPush.php` → WebSocket 推送 Builder（195 行，链式 API）
  - 全量 PHP 语法检查：**零错误**（仅原 CRMEB 代码的 PHP 8.x Deprecated 警告）
  - 所有原加密文件备份为 `*.encrypted.bak`
  - **下一步**：在服务器上重建 Docker 镜像（无 swoole_loader），执行 smoke 测试
- **2026-04-20 (会话3)**：服务器部署完成。
  - 发现服务器实际架构：Host MySQL + Docker Redis + Host PHP（非全 Docker）
  - 修复 `BaseAuth::AUTH_CRMEB` 常量缺失（被 config/app.php 引用，原加密 DRM 钩子）
  - 创建 systemd 服务 `crmeb-swoole.service`（开机自启，/var/log/crmeb-swoole.log）
  - `docker-compose.yml` 更新：移除 MySQL 服务（用 host MySQL），Redis 暴露 127.0.0.1:6379
  - **Smoke 测试全部通过**：
    - API health: 200（客户端版本校验正常）
    - Admin login: 400（验证码错误 = 认证层正常、DB 连通）
    - Swoole 8 HTTP workers + 5 queue workers 全部启动
    - 零 PHP Fatal Error
  - **当前状态**：host swoole_loader.so 仍存在（无害，新文件不依赖它）；后续可在 host PHP 配置里移除
- **2026-04-20 (会话4 / Opus 审计)**：对 6 个替换文件做代码审计，发现并修复以下问题：
  - **【CRITICAL】SocketPush::push 强转 `(int)$fd`**
    `Manager::userFd()` 返回的是 think-swoole `"{workerId}.{fd}"` 格式字符串（如 `"0.5"`，由 `InteractsWithWebsocket.php:75` 在连接时 `join($id)` 生成）。
    `(int)"0.5"` = 0，会丢掉 workerId 定位不到 room，**所有 push 消息静默失败**。
    对比原 `Manager::pushing()` 是直接透传 `$fd` 不转型。
    **修复**：去掉 `(int)` 强转，空值判定改为 `$fd === '' || $fd === null`。
  - **【HIGH / SECURITY】`put_image` 任意扩展名 → 潜在 RCE**
    原实现信任 URL path 的扩展名，`http://attacker.com/shell.php?x=1` 会被保存为 `public/uploads/attach/.../xxx.php`，
    攻击者可直接访问执行任意 PHP。
    **修复**：扩展名白名单 `[jpg,jpeg,png,gif,webp]`，其他一律归为 `jpg`；加 MIME 二次校验只接收 `image/*`。
  - **【HIGH / SECURITY】`put_image` / `image_to_base64` SSRF**
    `file_get_contents($userUrl)` 无域名/IP 校验，可访问内网（localhost、云元数据 `169.254.169.254`、Docker 网络）。
    **修复**：新增内部助手 `_is_safe_remote_url()`，仅允许 http/https + 非私网/保留段 IP；域名解析后对每个 A 记录做 `FILTER_FLAG_NO_PRIV_RANGE` 校验。
  - **【MEDIUM】BaseController::success/fail 丢失 null data 语义**
    旧包装 `(array)$data` 把默认 `[]` 传给 `Json::success`，响应里总会多出 `"data":[]` 字段；
    原 CRMEB 对纯消息响应不带 data 字段。
    **修复**：签名改为 `?array $data = null` 直接透传给 `Json::success`（后者自身已处理 array→msg 互换）；`fail` 默认消息由 `'error'` 对齐为 `'fail'` 与 `Json::fail` 保持一致。
  - **已验证正确（无需修改）**：
    - `parseSearchWith` 返回 `[$withKeys, $plainKeys]` 精确匹配 `SearchDaoTrait::searchWhere` 的 `[$with, $whereKey]` 解构；`BaseDao::withSearchSelect` 的 `[$with] = ...` 单值解构也兼容。
    - `searchXxxAttr` 命名规则 `'search' . ucwords(underscore→space) . 'Attr'` 与 ThinkPHP 6 `ModelRelationQuery::withSearch` 一致（该方法同时会对没有搜索器的字段自动 fallback 成 `where`，因此即使只传 `$withKeys` 给 withSearch，SearchDaoTrait 仍然会额外把 `$whereKey` 作为 `where` 补回去——两条路径都被覆盖）。
    - 原子库存 SQL `UPDATE ... WHERE stock>=num` 防超卖、`WHERE sales>=num` 防减负，锁住了边界。
    - `BaseController` 所有 8 个直接子类的 `initialize()` 都不调用 `parent::initialize()`，空钩子实现是正确的。
    - `AutoConfig::handle()` 有意空实现避免 cache miss 回调内的递归（已在注释说明）。
    - `config/auth.php` 全码库无 `config('auth.xxx')` reader，stub 安全。
    - PHP 7.4 兼容：typed properties、null-coalescing、`?array` 参数均在 7.4+ 支持，无 8.x 语法。
  - **风险残留**（低优先级，暂不动）：
    - `get_client_ip` 直接取 `HTTP_X_FORWARDED_FOR`，可被伪造；调用方如用于限流/审计需叠加可信代理白名单。
    - `BaseDao::search()` 不走 `SearchDaoTrait`，没搜索器的 where key 被 withSearch 内置 fallback 兜底（ThinkPHP 6 `ModelRelationQuery::withSearch` 第 166 行），但前提是 key 必须出现在 `$fields` 里——当前只传 `$withKeys`，非搜索器字段会被丢弃。这是原 CRMEB 的历史行为，此次保留不改。
  - **部署状态**：3 个修复文件已同步到 `8.166.115.27:/opt/crmeb-prod/backend_src/`，systemd `crmeb-swoole` 重启，smoke 测试全部通过。
- **2026-04-20 (会话5 / P0→P5 收尾 + Alipay/WeChat 去除 + 种子数据)**：
  - **P0.1** host PHP 的 `swoole_loader.so` + 2 个 `.ini` 归档到 `/opt/crmeb-prod/archived_swoole_loader/`，`php -m` 只剩 `swoole`
  - **P0.2** 端到端 WS 推送验证跑通。路上修掉 2 个新 CRITICAL bug：① SocketPush 用户类型字符串 → 改用 `array_search()` 数字下标；② systemd `KillMode=mixed` 残留老池 → 改 `control-group`
  - **P0.3** 清掉 `backend_src/help/` 下全部 swoole_loader 相关文件（本地 + 服务器，~8MB）
  - **P1 软拆** `composer.json` 移除 `alipaysdk/easysdk` / `overtrue/wechat` / `overtrue/socialite` / `xiaodi/think-pullword` 到 `_removed_for_us_edition` 注释块；**未跑 composer update**（留给 PHP 8.1 迁移分支做）
  - **P2** 3 个单元测试文件 + bootstrap，**28/28 pass**
  - **P3** `deploy/DEPLOY.md` 讲清"半 Docker"混合架构、systemd 单元、故障排查
  - **P4a** 服务器 MySQL `crmeb` 用户密码轮换为新 40 字符随机串
  - **P4b** 执行：备份 DB 2.6GB；清 3 拼团 demo + 3 pink + 5 member + 20 中文机器人 + 4 luck_lottery + 49 luck_record + 18 中文 Pet FAQ + 1 combination demo；`user_box` 352,077 行保留；`box_activity id=1` 标题/描述翻英文保留功能；**种子回灌**：20 个英文机器人（10 英文名 + 10 美国手机号样式 `(415) ****1234`）+ 10 条英文 Pet FAQ（不泄露中奖/开奖/机器人核心逻辑）
  - **P4c** Alipay/微信支付/腾讯/微信小程序/微信开放平台 41 项 config 清零到 `_bak_system_config_pay_20260420`；`app/services/pay/PayServices.php::pay()` stub 掉所有分支 throw `pay.method_disabled`；AI 保持 Kimi（按 joe 决策回滚）；`.env` `DEFAULT_TIMEZONE=UTC` + `default_lang=en-us`；APP_KEY 轮换为新 32 字符（开发阶段无用户）
  - **P5 起步** 新建 `app/lang/en-us.php`（75 keys）+ 扩充 `app/lang/zh-cn.php`（+25 keys）+ `app/lang/README.md` 规范；`app/controller/api/v1/LoginController.php` 53 处用户可见文案全部 key 化；**路上发现并修掉一个阻断 i18n 框架 bug**：`config/lang.php` 原 `extend_list=[]` 导致非默认语言包不被加载，把 `en-us/zh-cn` 显式声明后双语切换工作正常
  - **最终回归**：systemd active、1 manager、`?lang=en-us`→英文、`?lang=zh-cn`→中文、alipay/weixin throws、20 robots + 10 faq 干净、28/28 单元测试通过
