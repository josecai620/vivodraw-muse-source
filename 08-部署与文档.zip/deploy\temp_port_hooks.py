# -*- coding: utf-8 -*-
import io, os

SRC3 = r'D:\eccomall\mobile-app-v3'
DST = r'D:\eccomall\mobile-app\hooks'

TOKEN_FN = """function currentToken() {
  try {
    return useAuthStore.getState().token ?? "";
  } catch { return ""; }
}"""

OLD_TOKEN_FN_A = """function currentToken() {
  try {
    if (typeof localStorage === "undefined") return "";
    const direct = localStorage.getItem("auth_token")?.trim();
    if (direct) return direct.startsWith("local-v3-") ? "" : direct;
    const session = JSON.parse(localStorage.getItem("eccomall:v3:session") || "{}");
    return session.source === "api" && typeof session.token === "string" && !session.token.startsWith("local-v3-") ? session.token.trim() : "";
  } catch { return ""; }
}"""

OLD_TOKEN_FN_B = """function currentToken() {
  try {
    if (typeof localStorage === "undefined") return "";
    const direct = localStorage.getItem("auth_token")?.trim();
    if (direct) return direct.startsWith("local-v3-") ? "" : direct;
    const session = JSON.parse(localStorage.getItem("eccomall:v3:session") || "{}");
    return session.source === "api" && typeof session.token === "string" && !session.token.startsWith("local-v3-") ? session.token.trim() : "";
  } catch { return ""; }
}
const loginStatus = (status?: number) => [401, 410000, 410001, 410002].includes(status ?? 0);"""

NEW_TOKEN_FN_B = TOKEN_FN + """
const loginStatus = (status?: number) => [401, 410000, 410001, 410002].includes(status ?? 0);"""

common_repls = [
    ('@/lib/api/游戏补币', '@/lib/api/gameWallet'),
    ('@/lib/api/积分购买', '@/lib/api/pointPurchase'),
    ('@/lib/api/http', '@/lib/api/legacyHttp'),
    ('@/lib/api/account', '@/lib/api/walletRecharge'),
    ('./补币恢复', '@/lib/game/gameWalletRecovery'),
    ('./购买恢复', '@/lib/game/pointPurchaseRecovery'),
    ('./充值恢复', '@/lib/game/rechargeRecovery'),
    ('./请求锁', '@/lib/game/accountRequestLock'),
    ('import { SESSION_UPDATED_EVENT } from "@/lib/session";\n', ''),
    (' window.addEventListener(SESSION_UPDATED_EVENT, sync);', ''),
    (' window.removeEventListener(SESSION_UPDATED_EVENT, sync);', ''),
    # 用 zustand 订阅代替自定义会话事件
    ('window.addEventListener("storage", sync);',
     'window.addEventListener("storage", sync); const unsubAuth = useAuthStore.subscribe(sync);'),
    ('window.removeEventListener("storage", sync);',
     'window.removeEventListener("storage", sync); unsubAuth();'),
]

jobs = [
    (r'features\游戏补给\补给状态.ts', 'useGameSupply.ts', OLD_TOKEN_FN_B, NEW_TOKEN_FN_B),
    (r'features\积分购买\购买状态.ts', 'usePointPurchase.ts', OLD_TOKEN_FN_A, TOKEN_FN),
    (r'features\积分购买\充值返回.ts', 'useRechargeReturn.ts', OLD_TOKEN_FN_A, TOKEN_FN),
]

for rel, dname, old_tok, new_tok in jobs:
    s = io.open(os.path.join(SRC3, rel), encoding='utf-8').read()
    if old_tok not in s:
        print('!! token anchor not found in', rel)
    s = s.replace(old_tok, new_tok)
    for a, b in common_repls:
        s = s.replace(a, b)
    # 注入 auth store 导入（放在第一行 import 后）
    s = s.replace('import { useCallback, useEffect, useRef, useState } from "react";',
                  'import { useCallback, useEffect, useRef, useState } from "react";\nimport { useAuthStore } from "@/store/auth";', 1)
    io.open(os.path.join(DST, dname), 'w', encoding='utf-8', newline='\n').write(s)
    print('ported', dname, len(s))
