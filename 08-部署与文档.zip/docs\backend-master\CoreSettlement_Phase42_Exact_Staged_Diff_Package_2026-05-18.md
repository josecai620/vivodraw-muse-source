# CoreSettlement Phase 42 Exact Staged Diff Package 2026-05-18

## Current Task

Phase 42 locks the exact Point Gateway / Economy Gateway staging package.

No file was staged.
No commit was created.
No push was executed.
No deployment was executed.
No SQL was executed.

## Baseline Checks

```text
branch: codex/pet-world-v2
core package assert: passed
point gateway staging manifest assert: passed
route/admin.php point_gateway exposure: no match
```

`DEPLOY-WORKFLOW.md` was readable.
`docs/网站开发工作流-架构师版.md` was not present in this worktree at Phase42 check time, so Phase42 used current `AGENTS.md`, `DEPLOY-WORKFLOW.md`, and `docs/backend-master/*` as the active boundary.

Server sync and `git pull` were not run in Phase42 because the worktree already contained many unrelated active changes. Running rsync or rebase at this point could mix or overwrite other agents' work. Current Phase42 is commit-boundary preparation only.

## Include In Point Gateway Commit

```text
backend_src/app/controller/admin/v1/core/PointGateway.php
backend_src/app/services/core/LegacyPointBillMapperService.php
backend_src/app/services/core/PointGatewayAdminReadService.php
backend_src/app/services/core/PointGatewayAiOperationLogService.php
backend_src/app/services/core/PointGatewayReconciliationService.php
backend_src/app/services/core/PointTransactionService.php
backend_src/app/services/core/contracts/LegacyPointBillMapperServiceInterface.php
backend_src/app/services/core/contracts/PointGatewayAdminReadServiceInterface.php
backend_src/app/services/core/contracts/PointGatewayAiOperationLogServiceInterface.php
backend_src/app/services/core/contracts/PointGatewayReconciliationServiceInterface.php
backend_src/app/services/core/contracts/PointTransactionServiceInterface.php
backend_src/app/services/core/contracts/PointTransactionStoreInterface.php
backend_src/app/services/core/stores/DbPointTransactionStore.php
backend_src/app/services/core/stores/DryRunPointTransactionStore.php
backend_src/app/services/game/farm/FarmSettlementServices.php
backend_src/app/services/game/mine/MineSettlementServices.php
backend_src/app/services/user/UserSignServices.php
backend_src/scripts/core_settlement_backend_package_assert.php
backend_src/scripts/legacy_point_bill_mapper_assert.php
backend_src/scripts/point_gateway_admin_controller_assert.php
backend_src/scripts/point_gateway_admin_permission_contract_assert.php
backend_src/scripts/point_gateway_admin_read_assert.php
backend_src/scripts/point_gateway_admin_route_contract_assert.php
backend_src/scripts/point_gateway_ai_operation_log_assert.php
backend_src/scripts/point_gateway_ai_approval_policy_assert.php
backend_src/scripts/point_gateway_operation_log_schema_assert.php
backend_src/scripts/point_gateway_reconciliation_assert.php
backend_src/scripts/point_gateway_staging_manifest_assert.php
backend_src/scripts/point_transaction_gateway_assert.php
backend_src/scripts/point_transaction_migration_readiness_assert.php
backend_src/scripts/point_transaction_persistence_assert.php
docs/backend-master/CoreSettlement_Phase23_Point_Ledger_Table_Design_2026-05-18.md
docs/backend-master/CoreSettlement_Phase29_Point_Admin_Route_Contract_2026-05-18.md
docs/backend-master/CoreSettlement_Phase30_Point_Reconciliation_Readonly_Skeleton_2026-05-18.md
docs/backend-master/CoreSettlement_Phase31_Point_Admin_Filter_Contract_Hardening_2026-05-18.md
docs/backend-master/CoreSettlement_Phase32_Legacy_User_Bill_Readonly_Mapper_2026-05-18.md
docs/backend-master/CoreSettlement_Phase33_Reconciliation_Mapper_Wiring_2026-05-18.md
docs/backend-master/CoreSettlement_Phase34_Frozen_Expiry_Readonly_Lists_2026-05-18.md
docs/backend-master/CoreSettlement_Phase35_AI_Operation_Log_Draft_2026-05-18.md
docs/backend-master/CoreSettlement_Phase36_Point_Gateway_Index_And_Gate_2026-05-18.md
docs/backend-master/CoreSettlement_Phase37_Point_Gateway_Staging_Manifest_2026-05-18.md
docs/backend-master/CoreSettlement_Phase38_AI_Approval_Policy_2026-05-18.md
docs/backend-master/CoreSettlement_Phase39_Admin_Read_Sensitive_Field_Whitelist_2026-05-18.md
docs/backend-master/CoreSettlement_Phase40_Admin_Permission_Menu_Contract_2026-05-18.md
docs/backend-master/CoreSettlement_Phase41_AI_Operation_Log_Table_Draft_2026-05-18.md
docs/backend-master/CoreSettlement_Phase42_Exact_Staged_Diff_Package_2026-05-18.md
docs/backend-master/Backend_Master_Phase29_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase30_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase31_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase32_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase33_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase34_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase35_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase36_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase37_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase38_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase39_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase40_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase41_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase41_To_Phase42_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase42_Handoff_2026-05-18.md
```

## Force Add Required

`backend_src/scripts/*` is ignored by `.gitignore`.

Use explicit force add only for assert scripts:

```bash
git add -f \
  backend_src/scripts/core_settlement_backend_package_assert.php \
  backend_src/scripts/legacy_point_bill_mapper_assert.php \
  backend_src/scripts/point_gateway_admin_controller_assert.php \
  backend_src/scripts/point_gateway_admin_permission_contract_assert.php \
  backend_src/scripts/point_gateway_admin_read_assert.php \
  backend_src/scripts/point_gateway_admin_route_contract_assert.php \
  backend_src/scripts/point_gateway_ai_operation_log_assert.php \
  backend_src/scripts/point_gateway_ai_approval_policy_assert.php \
  backend_src/scripts/point_gateway_operation_log_schema_assert.php \
  backend_src/scripts/point_gateway_reconciliation_assert.php \
  backend_src/scripts/point_gateway_staging_manifest_assert.php \
  backend_src/scripts/point_transaction_gateway_assert.php \
  backend_src/scripts/point_transaction_migration_readiness_assert.php \
  backend_src/scripts/point_transaction_persistence_assert.php
```

## Exclude From Point Gateway Commit

```text
.gitignore
AGENTS.md
DESIGN.md
deploy/*.sql
game/
mobile-app/
mobile-app-v3/
backend_src/public/
backend_src/runtime/
.env
db_backup/
mysql_data/
redis_data/
docs/backend-master/Backend_Master_Final_Handoff_2026-05-18.md deletion
docs/backend-master/Backend_Master_Index.md deletion
docs/backend-master/Backend_Master_Next_Window_Startup.md deletion
docs/backend-master/CoreSettlement_Business_PreIntegration_Review.md deletion
docs/backend-master/CoreSettlement_Dry_Run_Handoff_2026-05-17.md deletion
docs/backend-master/CoreSettlement_Dry_Run_Test_Matrix.md deletion
docs/backend-master/CoreSettlement_Next_Phase_Approval_Package_Draft_2026-05-18.md deletion
docs/backend-master/CoreSettlement_Next_Phase_Approval_Package_Template.md deletion
docs/backend-master/CoreSettlement_Phase_Gate_Checklist.md deletion
```

## Exact Stage Command

Run only after user approves staging:

```bash
git add \
  backend_src/app/controller/admin/v1/core/PointGateway.php \
  backend_src/app/services/core/LegacyPointBillMapperService.php \
  backend_src/app/services/core/PointGatewayAdminReadService.php \
  backend_src/app/services/core/PointGatewayAiOperationLogService.php \
  backend_src/app/services/core/PointGatewayReconciliationService.php \
  backend_src/app/services/core/PointTransactionService.php \
  backend_src/app/services/core/contracts/LegacyPointBillMapperServiceInterface.php \
  backend_src/app/services/core/contracts/PointGatewayAdminReadServiceInterface.php \
  backend_src/app/services/core/contracts/PointGatewayAiOperationLogServiceInterface.php \
  backend_src/app/services/core/contracts/PointGatewayReconciliationServiceInterface.php \
  backend_src/app/services/core/contracts/PointTransactionServiceInterface.php \
  backend_src/app/services/core/contracts/PointTransactionStoreInterface.php \
  backend_src/app/services/core/stores/DbPointTransactionStore.php \
  backend_src/app/services/core/stores/DryRunPointTransactionStore.php \
  backend_src/app/services/game/farm/FarmSettlementServices.php \
  backend_src/app/services/game/mine/MineSettlementServices.php \
  backend_src/app/services/user/UserSignServices.php \
  docs/backend-master/CoreSettlement_Phase23_Point_Ledger_Table_Design_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase29_Point_Admin_Route_Contract_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase30_Point_Reconciliation_Readonly_Skeleton_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase31_Point_Admin_Filter_Contract_Hardening_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase32_Legacy_User_Bill_Readonly_Mapper_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase33_Reconciliation_Mapper_Wiring_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase34_Frozen_Expiry_Readonly_Lists_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase35_AI_Operation_Log_Draft_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase36_Point_Gateway_Index_And_Gate_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase37_Point_Gateway_Staging_Manifest_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase38_AI_Approval_Policy_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase39_Admin_Read_Sensitive_Field_Whitelist_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase40_Admin_Permission_Menu_Contract_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase41_AI_Operation_Log_Table_Draft_2026-05-18.md \
  docs/backend-master/CoreSettlement_Phase42_Exact_Staged_Diff_Package_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase29_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase30_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase31_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase32_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase33_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase34_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase35_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase36_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase37_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase38_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase39_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase40_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase41_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase41_To_Phase42_Handoff_2026-05-18.md \
  docs/backend-master/Backend_Master_Phase42_Handoff_2026-05-18.md

git add -f \
  backend_src/scripts/core_settlement_backend_package_assert.php \
  backend_src/scripts/legacy_point_bill_mapper_assert.php \
  backend_src/scripts/point_gateway_admin_controller_assert.php \
  backend_src/scripts/point_gateway_admin_permission_contract_assert.php \
  backend_src/scripts/point_gateway_admin_read_assert.php \
  backend_src/scripts/point_gateway_admin_route_contract_assert.php \
  backend_src/scripts/point_gateway_ai_operation_log_assert.php \
  backend_src/scripts/point_gateway_ai_approval_policy_assert.php \
  backend_src/scripts/point_gateway_operation_log_schema_assert.php \
  backend_src/scripts/point_gateway_reconciliation_assert.php \
  backend_src/scripts/point_gateway_staging_manifest_assert.php \
  backend_src/scripts/point_transaction_gateway_assert.php \
  backend_src/scripts/point_transaction_migration_readiness_assert.php \
  backend_src/scripts/point_transaction_persistence_assert.php
```

Do not run `git add -A`.

## Validation Before Any Commit

```bash
php backend_src/scripts/core_settlement_backend_package_assert.php
php backend_src/scripts/point_gateway_staging_manifest_assert.php
php backend_src/scripts/point_gateway_operation_log_schema_assert.php
php backend_src/scripts/point_gateway_admin_read_assert.php
php backend_src/scripts/point_gateway_ai_operation_log_assert.php
php backend_src/scripts/point_gateway_ai_approval_policy_assert.php
php backend_src/scripts/point_gateway_admin_permission_contract_assert.php
git diff --check -- backend_src/app/controller/admin/v1/core backend_src/app/services/core backend_src/app/services/game/farm/FarmSettlementServices.php backend_src/app/services/game/mine/MineSettlementServices.php backend_src/app/services/user/UserSignServices.php docs/backend-master
rg -n "point_gateway|PointGateway|v1\\.core\\.PointGateway" backend_src/route/admin.php || true
```

## Commit Guard

Before commit, inspect staged files:

```bash
git diff --cached --name-only
git diff --cached --stat
```

The staged file list must match the include list above and must not contain excluded areas.
