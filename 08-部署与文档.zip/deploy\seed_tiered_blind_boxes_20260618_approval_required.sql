-- Tiered blind-box launch seed.
-- Approval required before production execution.
-- Scope:
--   1) Add store_category.tag5/tag6 for Legendary/Secret public odds.
--   2) Create/update six blind-box category lanes.
--   3) Clone existing real products into each blind-box prize pool.
--   4) Enable explicit recovery_price on cloned blind-box products.
--
-- Safety:
--   - Does not move or overwrite source products.
--   - Re-runnable: cloned products use [blind-box-seed:<box>:<source_id>] markers.
--   - No payment, order, ledger, or inventory settlement changes.

SET NAMES utf8mb4;
SET @schema_name := DATABASE();
SET @now := UNIX_TIMESTAMP();
SET @old_sql_mode := @@SESSION.sql_mode;
SET SESSION sql_mode = TRIM(BOTH ',' FROM REPLACE(REPLACE(@@SESSION.sql_mode, 'NO_AUTO_VALUE_ON_ZERO,', ''), 'NO_AUTO_VALUE_ON_ZERO', ''));

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_category` ADD COLUMN `tag5` decimal(10,2) NOT NULL DEFAULT ''0.00'' COMMENT ''Legendary odds percent'' AFTER `tag4`',
    'SELECT ''eb_store_category.tag5 exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_category' AND COLUMN_NAME = 'tag5'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_category` ADD COLUMN `tag6` decimal(10,2) NOT NULL DEFAULT ''0.00'' COMMENT ''Secret odds percent'' AFTER `tag5`',
    'SELECT ''eb_store_category.tag6 exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_category' AND COLUMN_NAME = 'tag6'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `is_recovery` tinyint(1) NOT NULL DEFAULT 0 COMMENT ''Recovery enabled'' AFTER `xiaci_jiqiren_time`',
    'SELECT ''eb_store_product.is_recovery exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'is_recovery'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `recovery_price` decimal(12,2) NOT NULL DEFAULT ''0.00'' COMMENT ''Recovery price'' AFTER `is_recovery`',
    'SELECT ''eb_store_product.recovery_price exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'recovery_price'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `reference_price` decimal(12,2) NOT NULL DEFAULT ''0.00'' COMMENT ''Reference price'' AFTER `recovery_price`',
    'SELECT ''eb_store_product.reference_price exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'reference_price'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `recovery_discount` decimal(10,2) NOT NULL DEFAULT ''100.00'' COMMENT ''Recovery discount'' AFTER `reference_price`',
    'SELECT ''eb_store_product.recovery_discount exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'recovery_discount'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

INSERT INTO `eb_store_category`
  (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`, `price`, `price1`, `price3`, `price5`, `price10`, `product_id`, `cate_desc`, `tag1`, `tag2`, `tag3`, `tag4`, `tag5`, `tag6`)
SELECT 0, 'Starter Vault', 'Starter Vault', '', 901, 1, @now, '', 4, 4.99, 4.99, 14.22, 23.70, 44.91, 0,
       'Level 1. Low-risk first pull with useful minis and clear recovery credits.', 68.00, 22.00, 8.00, 1.70, 0.25, 0.05
WHERE NOT EXISTS (SELECT 1 FROM `eb_store_category` WHERE `cate_name` = 'Starter Vault' OR `cate_name_en` = 'Starter Vault');

INSERT INTO `eb_store_category`
  (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`, `price`, `price1`, `price3`, `price5`, `price10`, `product_id`, `cate_desc`, `tag1`, `tag2`, `tag3`, `tag4`, `tag5`, `tag6`)
SELECT 0, 'Daily Select Box', 'Daily Select Box', '', 902, 1, @now, '', 4, 9.99, 9.99, 28.47, 47.45, 89.91, 0,
       'Level 2. Beauty, desk, game, and travel picks for daily pulls.', 60.00, 25.00, 10.00, 4.00, 0.80, 0.20
WHERE NOT EXISTS (SELECT 1 FROM `eb_store_category` WHERE `cate_name` = 'Daily Select Box' OR `cate_name_en` = 'Daily Select Box');

INSERT INTO `eb_store_category`
  (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`, `price`, `price1`, `price3`, `price5`, `price10`, `product_id`, `cate_desc`, `tag1`, `tag2`, `tag3`, `tag4`, `tag5`, `tag6`)
SELECT 0, 'Gift Vault', 'Gift Vault', '', 903, 1, @now, '', 4, 19.99, 19.99, 56.97, 94.95, 179.91, 0,
       'Level 3. Giftable home, travel, self-care, and game prizes.', 52.00, 28.00, 14.00, 5.00, 0.80, 0.20
WHERE NOT EXISTS (SELECT 1 FROM `eb_store_category` WHERE `cate_name` = 'Gift Vault' OR `cate_name_en` = 'Gift Vault');

INSERT INTO `eb_store_category`
  (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`, `price`, `price1`, `price3`, `price5`, `price10`, `product_id`, `cate_desc`, `tag1`, `tag2`, `tag3`, `tag4`, `tag5`, `tag6`)
SELECT 0, 'Premium Vault', 'Premium Vault', '', 904, 1, @now, '', 4, 49.99, 49.99, 142.47, 237.45, 449.91, 0,
       'Level 4. Higher-value tech, beauty devices, game gear, and travel wins.', 45.00, 30.00, 17.00, 6.50, 1.20, 0.30
WHERE NOT EXISTS (SELECT 1 FROM `eb_store_category` WHERE `cate_name` = 'Premium Vault' OR `cate_name_en` = 'Premium Vault');

INSERT INTO `eb_store_category`
  (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`, `price`, `price1`, `price3`, `price5`, `price10`, `product_id`, `cate_desc`, `tag1`, `tag2`, `tag3`, `tag4`, `tag5`, `tag6`)
SELECT 0, 'Black Label Vault', 'Black Label Vault', '', 905, 1, @now, '', 4, 99.00, 99.00, 282.15, 470.25, 891.00, 0,
       'Level 5. Limited high-value pulls with conservative odds and visible recovery value.', 40.00, 30.00, 20.00, 8.00, 1.80, 0.20
WHERE NOT EXISTS (SELECT 1 FROM `eb_store_category` WHERE `cate_name` = 'Black Label Vault' OR `cate_name_en` = 'Black Label Vault');

INSERT INTO `eb_store_category`
  (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`, `price`, `price1`, `price3`, `price5`, `price10`, `product_id`, `cate_desc`, `tag1`, `tag2`, `tag3`, `tag4`, `tag5`, `tag6`)
SELECT 0, 'Signature Vault', 'Signature Vault', '', 906, 1, @now, '', 4, 199.00, 199.00, 567.15, 945.25, 1791.00, 0,
       'Level 6. Highest tier tech and gift bundle lane with explicit odds.', 35.00, 29.00, 22.00, 10.00, 3.50, 0.50
WHERE NOT EXISTS (SELECT 1 FROM `eb_store_category` WHERE `cate_name` = 'Signature Vault' OR `cate_name_en` = 'Signature Vault');

UPDATE `eb_store_category`
SET `pid` = 0, `sort` = 901, `is_show` = 1, `mall_type` = 4, `price` = 4.99, `price1` = 4.99, `price3` = 14.22, `price5` = 23.70, `price10` = 44.91,
    `product_id` = 0, `cate_desc` = 'Level 1. Low-risk first pull with useful minis and clear recovery credits.',
    `tag1` = 68.00, `tag2` = 22.00, `tag3` = 8.00, `tag4` = 1.70, `tag5` = 0.25, `tag6` = 0.05
WHERE `cate_name` = 'Starter Vault' OR `cate_name_en` = 'Starter Vault';

UPDATE `eb_store_category`
SET `pid` = 0, `sort` = 902, `is_show` = 1, `mall_type` = 4, `price` = 9.99, `price1` = 9.99, `price3` = 28.47, `price5` = 47.45, `price10` = 89.91,
    `product_id` = 0, `cate_desc` = 'Level 2. Beauty, desk, game, and travel picks for daily pulls.',
    `tag1` = 60.00, `tag2` = 25.00, `tag3` = 10.00, `tag4` = 4.00, `tag5` = 0.80, `tag6` = 0.20
WHERE `cate_name` = 'Daily Select Box' OR `cate_name_en` = 'Daily Select Box';

UPDATE `eb_store_category`
SET `pid` = 0, `sort` = 903, `is_show` = 1, `mall_type` = 4, `price` = 19.99, `price1` = 19.99, `price3` = 56.97, `price5` = 94.95, `price10` = 179.91,
    `product_id` = 0, `cate_desc` = 'Level 3. Giftable home, travel, self-care, and game prizes.',
    `tag1` = 52.00, `tag2` = 28.00, `tag3` = 14.00, `tag4` = 5.00, `tag5` = 0.80, `tag6` = 0.20
WHERE `cate_name` = 'Gift Vault' OR `cate_name_en` = 'Gift Vault';

UPDATE `eb_store_category`
SET `pid` = 0, `sort` = 904, `is_show` = 1, `mall_type` = 4, `price` = 49.99, `price1` = 49.99, `price3` = 142.47, `price5` = 237.45, `price10` = 449.91,
    `product_id` = 0, `cate_desc` = 'Level 4. Higher-value tech, beauty devices, game gear, and travel wins.',
    `tag1` = 45.00, `tag2` = 30.00, `tag3` = 17.00, `tag4` = 6.50, `tag5` = 1.20, `tag6` = 0.30
WHERE `cate_name` = 'Premium Vault' OR `cate_name_en` = 'Premium Vault';

UPDATE `eb_store_category`
SET `pid` = 0, `sort` = 905, `is_show` = 1, `mall_type` = 4, `price` = 99.00, `price1` = 99.00, `price3` = 282.15, `price5` = 470.25, `price10` = 891.00,
    `product_id` = 0, `cate_desc` = 'Level 5. Limited high-value pulls with conservative odds and visible recovery value.',
    `tag1` = 40.00, `tag2` = 30.00, `tag3` = 20.00, `tag4` = 8.00, `tag5` = 1.80, `tag6` = 0.20
WHERE `cate_name` = 'Black Label Vault' OR `cate_name_en` = 'Black Label Vault';

UPDATE `eb_store_category`
SET `pid` = 0, `sort` = 906, `is_show` = 1, `mall_type` = 4, `price` = 199.00, `price1` = 199.00, `price3` = 567.15, `price5` = 945.25, `price10` = 1791.00,
    `product_id` = 0, `cate_desc` = 'Level 6. Highest tier tech and gift bundle lane with explicit odds.',
    `tag1` = 35.00, `tag2` = 29.00, `tag3` = 22.00, `tag4` = 10.00, `tag5` = 3.50, `tag6` = 0.50
WHERE `cate_name` = 'Signature Vault' OR `cate_name_en` = 'Signature Vault';

SET @starter_vault_id := (SELECT `id` FROM `eb_store_category` WHERE `cate_name` = 'Starter Vault' OR `cate_name_en` = 'Starter Vault' ORDER BY `id` DESC LIMIT 1);
SET @daily_select_id := (SELECT `id` FROM `eb_store_category` WHERE `cate_name` = 'Daily Select Box' OR `cate_name_en` = 'Daily Select Box' ORDER BY `id` DESC LIMIT 1);
SET @gift_vault_id := (SELECT `id` FROM `eb_store_category` WHERE `cate_name` = 'Gift Vault' OR `cate_name_en` = 'Gift Vault' ORDER BY `id` DESC LIMIT 1);
SET @premium_vault_id := (SELECT `id` FROM `eb_store_category` WHERE `cate_name` = 'Premium Vault' OR `cate_name_en` = 'Premium Vault' ORDER BY `id` DESC LIMIT 1);
SET @black_label_id := (SELECT `id` FROM `eb_store_category` WHERE `cate_name` = 'Black Label Vault' OR `cate_name_en` = 'Black Label Vault' ORDER BY `id` DESC LIMIT 1);
SET @signature_vault_id := (SELECT `id` FROM `eb_store_category` WHERE `cate_name` = 'Signature Vault' OR `cate_name_en` = 'Signature Vault' ORDER BY `id` DESC LIMIT 1);

DROP PROCEDURE IF EXISTS seed_blind_box_prize;
DELIMITER //
CREATE PROCEDURE seed_blind_box_prize(
  IN p_source_id INT,
  IN p_box_code VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  IN p_cate_id INT,
  IN p_tag INT,
  IN p_sort INT,
  IN p_recovery_rate DECIMAL(6,4)
)
BEGIN
  DECLARE v_marker VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
  SET v_marker = CONCAT('[blind-box-seed:', p_box_code, ':', p_source_id, ']');

  CREATE TEMPORARY TABLE IF NOT EXISTS tmp_blind_box_product LIKE eb_store_product;
  TRUNCATE TABLE tmp_blind_box_product;

  IF p_cate_id IS NOT NULL
     AND EXISTS (SELECT 1 FROM eb_store_product WHERE id = p_source_id AND is_del = 0)
     AND NOT EXISTS (
       SELECT 1
       FROM eb_store_product
       WHERE store_info COLLATE utf8mb4_unicode_ci LIKE CONCAT('%', v_marker, '%')
          OR keyword COLLATE utf8mb4_unicode_ci LIKE CONCAT('%', v_marker, '%')
     ) THEN
    INSERT INTO tmp_blind_box_product SELECT * FROM eb_store_product WHERE id = p_source_id LIMIT 1;

    UPDATE tmp_blind_box_product
    SET id = 0,
        cate_id = p_cate_id,
        mall_type = (COALESCE(mall_type, 0) | 4),
        tag = p_tag,
        sort = p_sort,
        is_show = 1,
        is_del = 0,
        stock = GREATEST(COALESCE(stock, 0), 999),
        sales = 0,
        ficti = 0,
        is_recovery = 1,
        reference_price = price,
        recovery_discount = ROUND(p_recovery_rate * 100, 2),
        recovery_price = ROUND(price * p_recovery_rate, 2),
        store_info = LEFT(CONCAT(v_marker, ' ', COALESCE(store_info, 'Blind-box prize pool item')), 255),
        keyword = LEFT(CONCAT(v_marker, ',blind-box,', COALESCE(keyword, '')), 255),
        add_time = @now;

    INSERT INTO eb_store_product SELECT * FROM tmp_blind_box_product;
  END IF;
END//
DELIMITER ;

CALL seed_blind_box_prize(966, 'starter-vault', @starter_vault_id, 1, 601, 0.35);
CALL seed_blind_box_prize(957, 'starter-vault', @starter_vault_id, 2, 602, 0.40);
CALL seed_blind_box_prize(956, 'starter-vault', @starter_vault_id, 3, 603, 0.45);
CALL seed_blind_box_prize(965, 'starter-vault', @starter_vault_id, 4, 604, 0.50);
CALL seed_blind_box_prize(958, 'starter-vault', @starter_vault_id, 5, 605, 0.55);
CALL seed_blind_box_prize(955, 'starter-vault', @starter_vault_id, 6, 606, 0.60);

CALL seed_blind_box_prize(954, 'daily-select', @daily_select_id, 1, 611, 0.35);
CALL seed_blind_box_prize(963, 'daily-select', @daily_select_id, 2, 612, 0.40);
CALL seed_blind_box_prize(959, 'daily-select', @daily_select_id, 3, 613, 0.45);
CALL seed_blind_box_prize(964, 'daily-select', @daily_select_id, 4, 614, 0.50);
CALL seed_blind_box_prize(960, 'daily-select', @daily_select_id, 5, 615, 0.55);
CALL seed_blind_box_prize(1036, 'daily-select', @daily_select_id, 6, 616, 0.60);

CALL seed_blind_box_prize(989, 'gift-vault', @gift_vault_id, 1, 621, 0.35);
CALL seed_blind_box_prize(962, 'gift-vault', @gift_vault_id, 2, 622, 0.40);
CALL seed_blind_box_prize(1003, 'gift-vault', @gift_vault_id, 3, 623, 0.45);
CALL seed_blind_box_prize(1005, 'gift-vault', @gift_vault_id, 4, 624, 0.50);
CALL seed_blind_box_prize(992, 'gift-vault', @gift_vault_id, 5, 625, 0.55);
CALL seed_blind_box_prize(1040, 'gift-vault', @gift_vault_id, 6, 626, 0.60);

CALL seed_blind_box_prize(1021, 'premium-vault', @premium_vault_id, 1, 631, 0.35);
CALL seed_blind_box_prize(1036, 'premium-vault', @premium_vault_id, 2, 632, 0.40);
CALL seed_blind_box_prize(1023, 'premium-vault', @premium_vault_id, 3, 633, 0.45);
CALL seed_blind_box_prize(1038, 'premium-vault', @premium_vault_id, 4, 634, 0.50);
CALL seed_blind_box_prize(1040, 'premium-vault', @premium_vault_id, 5, 635, 0.55);
CALL seed_blind_box_prize(925, 'premium-vault', @premium_vault_id, 6, 636, 0.60);

CALL seed_blind_box_prize(914, 'black-label', @black_label_id, 1, 641, 0.35);
CALL seed_blind_box_prize(918, 'black-label', @black_label_id, 2, 642, 0.40);
CALL seed_blind_box_prize(920, 'black-label', @black_label_id, 3, 643, 0.45);
CALL seed_blind_box_prize(923, 'black-label', @black_label_id, 4, 644, 0.50);
CALL seed_blind_box_prize(925, 'black-label', @black_label_id, 5, 645, 0.55);
CALL seed_blind_box_prize(953, 'black-label', @black_label_id, 6, 646, 0.60);

CALL seed_blind_box_prize(926, 'signature-vault', @signature_vault_id, 1, 651, 0.35);
CALL seed_blind_box_prize(937, 'signature-vault', @signature_vault_id, 2, 652, 0.40);
CALL seed_blind_box_prize(944, 'signature-vault', @signature_vault_id, 3, 653, 0.45);
CALL seed_blind_box_prize(947, 'signature-vault', @signature_vault_id, 4, 654, 0.50);
CALL seed_blind_box_prize(952, 'signature-vault', @signature_vault_id, 5, 655, 0.55);
CALL seed_blind_box_prize(953, 'signature-vault', @signature_vault_id, 6, 656, 0.60);

-- Normalize seeded clone values for USD-facing storefront review.
-- Blind-box clones must stay in a realistic consumer-goods range.
UPDATE eb_store_product p
JOIN eb_store_product src ON src.id = 925
SET p.store_name = 'Apple AirTag 4-Pack',
    p.price = 99.00,
    p.ot_price = 119.00,
    p.cost = 75.00,
    p.reference_price = 99.00,
    p.recovery_discount = 60.00,
    p.recovery_price = 59.40,
    p.image = src.image,
    p.slider_image = src.slider_image,
    p.store_info = LEFT(CONCAT('[blind-box-seed:premium-vault:925] Everyday Apple tracker bundle with realistic USD-facing value.'), 255),
    p.keyword = 'blind-box,airtag,tracker,premium'
WHERE p.store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:premium-vault:925]%';

UPDATE eb_store_product
SET store_name = 'TOZO Wireless Earbuds',
    price = 39.00,
    ot_price = 49.00,
    cost = 22.00,
    reference_price = 39.00,
    recovery_discount = 35.00,
    recovery_price = 13.65
WHERE store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:black-label:914]%';

UPDATE eb_store_product
SET store_name = 'Amazfit Smartwatch',
    price = 89.00,
    ot_price = 109.00,
    cost = 48.00,
    reference_price = 89.00,
    recovery_discount = 40.00,
    recovery_price = 35.60
WHERE store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:black-label:918]%';

UPDATE eb_store_product
SET store_name = 'Collectible Figure Bundle',
    price = 79.00,
    ot_price = 99.00,
    cost = 42.00,
    reference_price = 79.00,
    recovery_discount = 45.00,
    recovery_price = 35.55
WHERE store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:black-label:920]%';

UPDATE eb_store_product
SET store_name = 'Nintendo Switch Lite',
    price = 199.00,
    ot_price = 219.00,
    cost = 155.00,
    reference_price = 199.00,
    recovery_discount = 50.00,
    recovery_price = 99.50
WHERE store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:black-label:923]%';

UPDATE eb_store_product
SET store_name = 'Apple AirTag 4-Pack',
    price = 99.00,
    ot_price = 119.00,
    cost = 75.00,
    reference_price = 99.00,
    recovery_discount = 55.00,
    recovery_price = 54.45
WHERE store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:black-label:925]%';

UPDATE eb_store_product p
JOIN eb_store_product src ON src.id = 923
SET p.store_name = 'Premium Travel Tech Bundle',
    p.price = 299.00,
    p.ot_price = 349.00,
    p.cost = 210.00,
    p.reference_price = 299.00,
    p.recovery_discount = 60.00,
    p.recovery_price = 179.40,
    p.image = src.image,
    p.slider_image = src.slider_image,
    p.store_info = LEFT(CONCAT('[blind-box-seed:black-label:953] High-tier tech bundle with realistic USD-facing value.'), 255),
    p.keyword = 'blind-box,tech,bundle,premium'
WHERE p.store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:black-label:953]%';

UPDATE eb_store_product
SET store_name = '250 Points Instant Credit',
    price = 25.00,
    ot_price = 25.00,
    cost = 0.00,
    reference_price = 25.00,
    recovery_discount = 35.00,
    recovery_price = 8.75
WHERE store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:signature-vault:926]%';

UPDATE eb_store_product
SET store_name = 'Apple AirPods Pro 2',
    price = 249.00,
    ot_price = 279.00,
    cost = 190.00,
    reference_price = 249.00,
    recovery_discount = 40.00,
    recovery_price = 99.60
WHERE store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:signature-vault:937]%';

UPDATE eb_store_product
SET store_name = 'Apple iPad Air 11 inch M2',
    price = 599.00,
    ot_price = 649.00,
    cost = 470.00,
    reference_price = 599.00,
    recovery_discount = 45.00,
    recovery_price = 269.55
WHERE store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:signature-vault:944]%';

UPDATE eb_store_product
SET store_name = 'Sony WH-1000XM5 Headphones',
    price = 399.00,
    ot_price = 429.00,
    cost = 300.00,
    reference_price = 399.00,
    recovery_discount = 50.00,
    recovery_price = 199.50
WHERE store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:signature-vault:947]%';

UPDATE eb_store_product
SET store_name = 'Premium Smartphone Upgrade',
    price = 799.00,
    ot_price = 899.00,
    cost = 620.00,
    reference_price = 799.00,
    recovery_discount = 55.00,
    recovery_price = 439.45
WHERE store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:signature-vault:952]%';

UPDATE eb_store_product p
JOIN eb_store_product src ON src.id = 944
SET p.store_name = 'Signature Tech Bundle',
    p.price = 899.00,
    p.ot_price = 999.00,
    p.cost = 690.00,
    p.reference_price = 899.00,
    p.recovery_discount = 60.00,
    p.recovery_price = 539.40,
    p.image = src.image,
    p.slider_image = src.slider_image,
    p.store_info = LEFT(CONCAT('[blind-box-seed:signature-vault:953] Signature electronics bundle with realistic USD-facing value.'), 255),
    p.keyword = 'blind-box,tech,bundle,signature'
WHERE p.store_info COLLATE utf8mb4_unicode_ci LIKE '%[blind-box-seed:signature-vault:953]%';

DROP PROCEDURE IF EXISTS seed_blind_box_prize;
DROP TEMPORARY TABLE IF EXISTS tmp_blind_box_product;

UPDATE eb_store_category c
SET c.pic = COALESCE(NULLIF((SELECT p.image FROM eb_store_product p WHERE p.cate_id = c.id AND p.is_del = 0 AND p.is_show = 1 ORDER BY p.tag DESC, p.price DESC LIMIT 1), ''), c.pic),
    c.big_pic = COALESCE(NULLIF((SELECT p.image FROM eb_store_product p WHERE p.cate_id = c.id AND p.is_del = 0 AND p.is_show = 1 ORDER BY p.tag DESC, p.price DESC LIMIT 1), ''), c.big_pic)
WHERE c.id IN (@starter_vault_id, @daily_select_id, @gift_vault_id, @premium_vault_id, @black_label_id, @signature_vault_id);

SELECT
  c.id,
  c.cate_name,
  c.price1,
  c.price3,
  c.price5,
  c.price10,
  c.tag1 AS common_odds,
  c.tag2 AS uncommon_odds,
  c.tag3 AS rare_odds,
  c.tag4 AS epic_odds,
  c.tag5 AS legendary_odds,
  c.tag6 AS secret_odds,
  COUNT(p.id) AS prize_count,
  SUM(p.tag = 1) AS common_count,
  SUM(p.tag = 2) AS uncommon_count,
  SUM(p.tag = 3) AS rare_count,
  SUM(p.tag = 4) AS epic_count,
  SUM(p.tag = 5) AS legendary_count,
  SUM(p.tag = 6) AS secret_count,
  MIN(p.recovery_price) AS min_recovery_price,
  MAX(p.price) AS max_prize_value
FROM eb_store_category c
LEFT JOIN eb_store_product p ON p.cate_id = c.id AND p.is_del = 0 AND p.is_show = 1 AND (COALESCE(p.mall_type, 0) & 4) > 0
WHERE c.id IN (@starter_vault_id, @daily_select_id, @gift_vault_id, @premium_vault_id, @black_label_id, @signature_vault_id)
GROUP BY c.id, c.cate_name, c.price1, c.price3, c.price5, c.price10, c.tag1, c.tag2, c.tag3, c.tag4, c.tag5, c.tag6
ORDER BY c.sort ASC, c.id ASC;

SET SESSION sql_mode = @old_sql_mode;
