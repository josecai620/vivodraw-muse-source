-- Read-only verification queries for phase 7 robot/test data cleanup.

SELECT 'robot_rows_remaining' AS section;
SELECT 'eb_store_integral_product_huanqu_log_unique' AS table_name, COUNT(*) AS robot_rows
FROM eb_store_integral_product_huanqu_log_unique
WHERE is_jiqiren = 1
UNION ALL
SELECT 'eb_store_integral_product_huanqu_log', COUNT(*)
FROM eb_store_integral_product_huanqu_log
WHERE is_jiqiren = 1
UNION ALL
SELECT 'eb_store_integral_product_kaijiang_log', COUNT(*)
FROM eb_store_integral_product_kaijiang_log
WHERE is_jiqiren = 1
UNION ALL
SELECT 'eb_user_box', COUNT(*)
FROM eb_user_box
WHERE is_jiqiren = 1
UNION ALL
SELECT 'eb_box_order', COUNT(*)
FROM eb_box_order
WHERE is_jiqiren = 1;

SELECT 'real_rows_remaining' AS section;
SELECT 'eb_store_integral_product_huanqu_log_unique' AS table_name, COUNT(*) AS real_rows
FROM eb_store_integral_product_huanqu_log_unique
WHERE is_jiqiren = 0
UNION ALL
SELECT 'eb_store_integral_product_huanqu_log', COUNT(*)
FROM eb_store_integral_product_huanqu_log
WHERE is_jiqiren = 0
UNION ALL
SELECT 'eb_store_integral_product_kaijiang_log', COUNT(*)
FROM eb_store_integral_product_kaijiang_log
WHERE is_jiqiren = 0
UNION ALL
SELECT 'eb_user_box', COUNT(*)
FROM eb_user_box
WHERE is_jiqiren = 0
UNION ALL
SELECT 'eb_box_order', COUNT(*)
FROM eb_box_order
WHERE is_jiqiren = 0;

SELECT 'relationship_checks' AS section;
SELECT 'user_box_real_to_missing_order' AS check_name, COUNT(*) AS count_value
FROM eb_user_box ub
LEFT JOIN eb_box_order bo ON bo.id = ub.order_id
WHERE ub.is_jiqiren = 0 AND ub.order_id > 0 AND bo.id IS NULL
UNION ALL
SELECT 'huanqu_real_to_missing_order', COUNT(*)
FROM eb_store_integral_product_huanqu_log h
LEFT JOIN eb_box_order bo ON bo.id = h.box_order_id
WHERE h.is_jiqiren = 0 AND h.box_order_id > 0 AND bo.id IS NULL
UNION ALL
SELECT 'unique_real_to_missing_huanqu', COUNT(*)
FROM eb_store_integral_product_huanqu_log_unique u
LEFT JOIN eb_store_integral_product_huanqu_log h ON h.id = u.huanqu_id
WHERE u.is_jiqiren = 0 AND u.huanqu_id > 0 AND h.id IS NULL
UNION ALL
SELECT 'kaijiang_real_to_missing_huanqu', COUNT(*)
FROM eb_store_integral_product_kaijiang_log k
LEFT JOIN eb_store_integral_product_huanqu_log h ON h.id = k.huanqu_id
WHERE k.is_jiqiren = 0 AND k.huanqu_id > 0 AND h.id IS NULL
UNION ALL
SELECT 'store_order_to_robot_user_box', COUNT(*)
FROM eb_store_order so
JOIN eb_user_box ub ON FIND_IN_SET(ub.id, so.box_ids)
WHERE so.is_box_order = 1 AND ub.is_jiqiren = 1;

SELECT 'table_sizes' AS section;
SELECT
  table_name,
  table_rows,
  ROUND((data_length + index_length) / 1024 / 1024, 2) AS total_mb,
  ROUND(data_free / 1024 / 1024, 2) AS free_mb
FROM information_schema.tables
WHERE table_schema = DATABASE()
  AND table_name IN (
    'eb_store_integral_product_huanqu_log_unique',
    'eb_store_integral_product_huanqu_log',
    'eb_store_integral_product_kaijiang_log',
    'eb_user_box',
    'eb_box_order',
    'eb_store_order'
  )
ORDER BY total_mb DESC;
