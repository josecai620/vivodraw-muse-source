-- 在顶部导航栏增加：常规商城、积分商城、盲盒商城
-- 执行方式：mysql -u用户 -p 数据库名 < add_mall_nav_menus.sql
-- 或通过 phpmyadmin / 宝塔 等导入
-- 表前缀默认 eb_，如不同请自行替换

-- 1. 常规商城（商品列表，筛选 mall_type=0）
INSERT INTO `eb_system_menus` (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2200, 0, 1, 'md-cube-outline', '常规商城', 'admin', 'product.product', 'index', '', '', '[]', 130, 1, 0, 1, '/admin/product/product_list', '', 1, 'mall_regular', 1, 'admin-mall-regular', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2200 AND `is_del` = 0);

INSERT INTO `eb_system_menus` (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2201, 2200, 1, 'md-list', '商品列表', 'admin', 'product.product', 'index', '', '', '[]', 1, 1, 0, 1, '/admin/product/product_list?mall_type=0', '2200', 1, '', 0, 'admin-mall-regular-product', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2201 AND `is_del` = 0);

-- 2. 积分商城（营销 → 积分商品）
INSERT INTO `eb_system_menus` (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2202, 0, 1, 'logo-euro', '积分商城', 'admin', 'marketing.store_integral', 'index', '', '', '[]', 129, 1, 0, 1, '/admin/marketing/store_integral/index', '', 1, 'mall_integral', 1, 'admin-mall-integral', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2202 AND `is_del` = 0);

INSERT INTO `eb_system_menus` (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2203, 2202, 1, 'md-list-box', '积分商品', 'admin', 'marketing.store_integral', 'index', '', '', '[]', 1, 1, 0, 1, '/admin/marketing/store_integral/index', '2202', 1, '', 0, 'admin-mall-integral-product', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2203 AND `is_del` = 0);

-- 3. 盲盒商城（商品列表，筛选 mall_type=2）
INSERT INTO `eb_system_menus` (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2204, 0, 1, 'md-cube', '盲盒商城', 'admin', 'product.product', 'index', '', '', '[]', 128, 1, 0, 1, '/admin/product/product_list', '', 1, 'mall_manghe', 1, 'admin-mall-manghe', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2204 AND `is_del` = 0);

INSERT INTO `eb_system_menus` (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2205, 2204, 1, 'md-list', '盲盒商品', 'admin', 'product.product', 'index', '', '', '[]', 1, 1, 0, 1, '/admin/product/product_list?mall_type=2', '2204', 1, '', 0, 'admin-mall-manghe-product', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2205 AND `is_del` = 0);

-- 4. 为各角色追加新菜单权限（非超级管理员需有此权限才能看到）
-- 若 roles.rules 中已含 2200 则跳过，避免重复追加
UPDATE `eb_system_role` SET `rules` = CONCAT(IFNULL(`rules`,''), ',2200,2201,2202,2203,2204,2205')
WHERE `status` = 1 AND (ISNULL(`rules`) OR `rules` NOT LIKE '%2200%');

-- ========== 执行后必做：清理缓存 ==========
-- 在服务器上执行（二选一）：
--   直接执行：  php think clear
--   Docker下：  docker exec crmeb-app php think clear
--
-- 然后：退出后台 → 清除浏览器该站点的 localStorage（或使用无痕模式）→ 重新登录
