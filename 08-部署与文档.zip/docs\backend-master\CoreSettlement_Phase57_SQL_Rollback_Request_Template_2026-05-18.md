# CoreSettlement Phase57 SQL Rollback Request Template 2026-05-18

## Current Task

Phase57 prepares a no-execution rollback request template for the future Point Gateway table SQL execution path.

Template only.
No SQL was executed.
No rollback was executed.
No rollback was approved.
No production database connection was opened.
No deployment was executed.
No write path was enabled.

## Template Status

```text
rollback_request_template_created: true
rollback_request_filled: false
rollback_approved: false
rollback_executed: false
sql_executed: false
production_connection_opened: false
database_writes: false
```

## Rollback Scope Boundary

Rollback can only be requested for newly created empty Point Gateway tables from:

```text
deploy/core_point_gateway_tables_approval_required.sql
```

Target tables:

```text
eb_core_point_transaction
eb_core_point_freeze
eb_core_point_rollback_request
eb_core_point_expiry_batch
eb_core_point_gateway_ai_operation_log
eb_core_point_gateway_approval_audit
```

## Hard Non-Rollback Areas

```text
never touch eb_user
never touch user_bill
never touch order tables
never touch payment tables
never touch manghe tables
never touch uploads or runtime files
never execute DROP/TRUNCATE without separate approval
never rollback if any target table contains rows
```

## Future Rollback Request Template

Copy this section into a new dated rollback request document only after a failed or unwanted approved table creation.

```text
rollback_request_status: draft|requested|approved|rejected|executed|cancelled
request_date:
timezone:
requesting_operator_window_id:
original_execution_result_doc:
original_execution_commit_hash:
target_database_name:
rollback_reason:
tables_considered:
readonly_row_count_check_result:
all_target_tables_empty: true|false
legacy_tables_untouched: true|false
backup_restore_option_available: true|false
proposed_rollback_sql_summary:
credentials_printed: false
approval_required_before_rollback: true
rollback_command_executed: false
rollback_result_doc:
next_action:
```

## Rollback Approval Text Required Later

Future rollback must not proceed unless the user provides separate approval after reviewing a filled request.

Minimum approval text must include:

```text
I approve rollback for the empty Point Gateway tables listed in the filled rollback request.
I understand rollback may drop only those newly created empty Point Gateway tables.
I do not approve touching eb_user, user_bill, order, payment, or manghe tables.
I approve stopping if any target table contains rows.
```

Any shorter approval is not enough to run rollback SQL.
Approval to create this template is not approval to rollback.

## Required Pre-Rollback Gates

```text
1. Confirm original execution result doc exists.
2. Confirm rollback request doc is filled.
3. Confirm separate user rollback approval text exists.
4. Run readonly row-count check for every target table.
5. Confirm every target table has zero rows.
6. Confirm no DB store, route, or production switch was enabled.
7. Confirm backup/restore option remains known.
8. Confirm proposed rollback SQL only targets empty Point Gateway tables.
9. Confirm credentials will be redacted.
10. Stop if any table has rows or unknown state.
```

## Proposed Rollback SQL Policy

```text
rollback SQL file must not be created in Phase57
rollback SQL must be prepared only after separate approval
rollback SQL may only target empty Point Gateway tables
rollback SQL must not touch legacy user_bill
rollback SQL must not touch eb_user integral
rollback SQL must not touch order/payment/manghe tables
rollback SQL must not be executed automatically after creation
```

## Required Validation Before Future Rollback Request Use

```text
php backend_src/scripts/point_gateway_sql_rollback_request_template_assert.php
php backend_src/scripts/point_gateway_sql_execution_result_template_assert.php
php backend_src/scripts/point_gateway_sql_operator_runbook_assert.php
php backend_src/scripts/core_settlement_backend_package_assert.php
git diff --check -- deploy/core_point_gateway_tables_approval_required.sql docs/backend-master backend_src/scripts
```

## Phase57 Guards

```text
rollback_request_template_created: true
rollback_request_filled: false
rollback_approved: false
rollback_executed: false
sql_executed: false
migration_run: false
production_connection_opened: false
database_writes: false
deployment_executed: false
sql_file_changed: false
db_store_enabled: false
route_exposure: false
production_switch_enabled: false
separate_rollback_approval_required: true
separate_execution_approval_required: true
```
