# Codex 体检工作流

中文别名：`体检工作流`、`项目体检`、`全项目体检`。

适用场景：用户要求“全项目查漏”“审计漏洞”“查漏补缺”“检查数据库/后端/前端/游戏/配置风险”时使用。

默认原则：

- 只读优先，dry-run 优先，生产只读。
- 不执行生产 SQL，不改生产配置，不开自动开关，不修改支付/库存/ledger 生产数据。
- 任何高风险动作必须先列出风险、影响范围、回滚方式，并等待用户明确确认。
- 旧历史文档只作为历史证据；当前判断以当前代码、`AGENTS.md`、2026-05 文档和实际 schema 为准。
- 每轮必须留下证据：扫描范围、命令、commit/hash、问题清单、风险等级、验证结果。

## 角色分工

- Codex：扫描、审计、风险分级、修复草案、dry-run 验证。
- ChatGPT：汇总报告、压缩表达、给产品/运营视角的最终中文报告。
- 如果没有独立 ChatGPT 窗口，Codex 也可以生成最终报告，但必须标注“Codex 生成”。

## 输入目标

启动前先确认这些目标是否存在：

- 代码库：`/Users/joe/eccomall`
- 数据库结构：`schema.sql`、`docs/backend-master/*`、`backend_src/database/*`、`backend_src/app/*`
- workflow/config：`AGENTS.md`、`DEPLOY-WORKFLOW.md`、`deploy/`
- 后端：`backend_src/app/`、`backend_src/config/`、`backend_src/routes/`
- 前端：`mobile-app/`、`mobile-app-v3/`
- 游戏：`game/`
- 开关/权限/脚本：`deploy/*.sql`、`backend_src/scripts/`、`.env.example`、配置模板

缺少目标时，不猜测；在报告里标为“缺少输入，无法确认”。

## Step 0：目标环境准备

输出 `targets_list`：

- 当前分支与 commit：`git rev-parse --abbrev-ref HEAD`、`git rev-parse HEAD`
- 工作区状态：`git status --short --branch`
- 改动范围：`git diff --stat`、`git diff --name-only`
- 扫描目录列表
- 明确排除：`node_modules`、`vendor`、`runtime`、`uploads`、数据库备份、构建产物、旧 3-4 月历史 md

如果工作区很脏，只做只读审计；不要自动提交、回滚或整理别人的改动。

## Step 1：扫描模块

输出 `issues_list`。

扫描维度：

- 数据库：表结构、索引、唯一约束、ledger/积分流水、迁移脚本、默认开关。
- 后端：结算、奖励、签到、农场、矿洞、盲盒、积分商城、权限、幂等、回滚。
- 前端：展示状态、奖励状态、接口契约、错误兜底、重复提交、旧入口。
- 游戏：奖励触发、mock/真实数据边界、状态同步、资源和 runtime 分离。
- 配置：`.env` 模板、部署脚本、workflow、AGENTS 规则、旧 IP、密钥痕迹。

每个问题必须带：

- 文件路径
- 证据片段或命令
- 影响模块
- 是否需要线上/数据库确认

## Step 2：审计模块

输出 `audit_results`。

风险等级：

- 高：可能导致重复结算、资产丢失、支付/库存/ledger 错账、生产配置破坏、权限绕过、数据不可回滚。
- 中：可能导致状态漂移、奖励不一致、前后端契约错位、后台读错、部署后不可用。
- 低：文档过期、命名混乱、无害冗余、可重建缓存、非关键体验问题。

重点检查：

- 是否会重复发放积分/奖励。
- 是否缺少幂等键、唯一约束、状态机保护。
- dry-run 是否真的无副作用。
- rollback 是否可执行、可验证。
- switch 默认是否关闭。
- 后台权限/菜单是否默认暴露。
- mock 数据是否会误入生产路径。

## Step 3：修复草案模块

输出 `patches`。

规则：

- 只生成修复方案或本地 patch draft。
- 不执行生产 SQL，不跑线上迁移，不修改生产配置。
- 高风险问题只给方案、SQL 草案、回滚草案和人工确认点。
- 低风险问题可准备本地修复 patch，但提交前必须再确认工作区改动归属。

每个 patch draft 必须写清：

- 修改文件
- 修改原因
- 影响范围
- 是否写库
- 是否影响生产
- 是否可回滚
- 验证命令

## Step 4：Dry-run 测试模块

输出 `dry_run_results`。

允许自动执行：

- `php -l <changed.php>`
- 本地只读脚本
- 本地 dry-run 命令
- `npm run typecheck`
- `git diff --check`
- 本地单元测试或 smoke test

禁止自动执行：

- 生产 SQL / migration
- `DROP` / `TRUNCATE`
- ledger `UPDATE` / `DELETE`
- 支付、库存、订单生产改动
- 服务器配置改动
- force push / history rewrite

Dry-run 结果必须标注：

- 是否有副作用
- 是否写库
- 是否依赖生产
- 是否可重复执行
- 失败后的最短修复路径

## Step 5：审计报告生成

输出 `final_report`，中文，面向产品/运营/总控可读。

报告结构固定：

1. 结论
2. 扫描范围
3. 当前 branch / commit hash
4. 高风险问题
5. 中风险问题
6. 低风险问题
7. 修复建议
8. dry-run 结果
9. 需要人工确认的操作
10. 未确认/缺失输入

每条问题格式：

```text
[风险等级] 标题
位置：path:line
证据：简短证据
影响：业务影响
建议：最小修复路径
验证：命令或人工检查点
```

## 输出文件建议

如果用户要求落文件，默认写到：

- `docs/audit/full-audit-YYYYMMDD-HHMM.md`
- `docs/audit/patch-draft-YYYYMMDD-HHMM.md`
- `docs/audit/dry-run-YYYYMMDD-HHMM.md`

如果只是聊天审计，直接在对话中输出，不强制落文件。

## 一句话触发

用户说以下任意表达时，默认使用本工作流：

- “体检工作流”
- “跑项目体检”
- “全项目体检”
- “给项目做体检”
- “全项目查漏”
- “全项目审计”
- “查漏洞”
- “查漏补缺”
- “看看哪里还有风险”
- “数据库/后端/前端/游戏一起检查”
- “按 full audit workflow 跑”
