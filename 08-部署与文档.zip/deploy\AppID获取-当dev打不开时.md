# 当 dev.dcloud.net.cn 打不开时，怎么拿到 AppID

你当前 **https://dev.dcloud.net.cn/developer/app** 显示 “Whoops, something went wrong”，可以按下面顺序试。

---

## 1. 换这些地址试（同一网站不同路径）

在浏览器里分别打开，看哪个能正常显示页面：

- **https://dev.dcloud.net.cn/**  
  （开发者中心首页，若能用再点「应用管理」或「我的应用」）

- **https://open.dcloud.net.cn/**  
  （开放平台，登录后看是否有「应用列表」或「我的应用」）

- **https://www.dcloud.io/**  
  （官网，看是否有「控制台」「开发者」等入口进到应用管理）

能打开哪一个，就从那里找「创建应用」或「应用列表」，创建/打开应用后复制 **AppID**（`__UNI__` 开头）。

---

## 2. 换网络或设备试

- 用**手机 4G/5G**（不要连同一 WiFi）在浏览器打开：  
  **https://dev.dcloud.net.cn/developer/app**
- 或连 **VPN** 后再用电脑打开上述地址。  
有时是本地网络或 DNS 导致只拦了部分 DCloud 域名，换网络后可能就正常。

---

## 3. 在 HBuilderX 里用「重新获取」（需能连上 DCloud）

若 HBuilderX 能正常联网、只有网页打不开，可以试：

1. 在 HBuilderX 打开 **manifest.json**
2. 切到 **「基础配置」**（不要用「源码视图」）
3. 找到 **「应用标识(AppID)」**，点后面的 **「重新获取」**
4. 若弹出登录框，用 DCloud 账号登录；成功后会生成/绑定新 AppID 并写回 manifest

这样拿到的也是合法 AppID，不依赖你打开 dev 网页。

---

## 4. 联系 DCloud 客服

若以上都试过仍无法打开或无法获取 AppID，可向 DCloud 说明情况并请求协助（例如分配一个 AppID 或给备用地址）：

- 邮箱：**service@dcloud.io**
- 或到 **https://ask.dcloud.net.cn/** 发帖，说明「dev.dcloud.net.cn/developer/app 一直打不开，需要获取 uni-app 的 AppID」

---

## 拿到 AppID 之后

把得到的 **AppID**（例如 `__UNI__8A1B2C3D`）发给我，或在本项目根目录执行：

```bash
bash deploy/写入AppID到manifest.sh __UNI__你的AppID
```

我会帮你写进 manifest，然后你在 HBuilderX 再执行一次 **发行 → 网站-PC Web或手机H5** 即可。
