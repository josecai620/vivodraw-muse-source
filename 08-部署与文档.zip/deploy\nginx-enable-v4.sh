#!/usr/bin/env bash
# Safely enable the /v4 nginx location.
# New config is expected at /tmp/vivodraw.com.conf.new.
# Verifies current config is healthy first, backs up, swaps in the new file,
# and only reloads after `nginx -t` passes. On any test failure it reverts the
# file and does NOT reload, so the running site is untouched.
set -uo pipefail

TARGET=/etc/nginx/sites-enabled/vivodraw.com.conf
NEW=/tmp/vivodraw.v4.candidate
TS="${1:-manual}"

[ -f "$NEW" ] || { echo NO_NEW_FILE; exit 2; }

# 1) baseline must already be healthy
if ! nginx -t; then
  echo BASELINE_NGINX_BROKEN_ABORT
  exit 3
fi

# 2) backup live config and stage the new one
cp -a "$TARGET" "${TARGET}.bak.v4-${TS}"
cp "$NEW" "$TARGET"

# 3) test; reload only if healthy, otherwise revert
if nginx -t; then
  systemctl reload nginx
  echo "V4_NGINX_ENABLED_AT_${TS}"
else
  cp -a "${TARGET}.bak.v4-${TS}" "$TARGET"
  echo NGINX_TEST_FAILED_REVERTED
  exit 1
fi
