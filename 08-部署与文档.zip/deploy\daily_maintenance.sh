#!/usr/bin/env bash
# eccomall 每日维护脚本（cron 每天 03:15 执行）
#  1. dump MySQL → /opt/crmeb-prod/db_backup（保留最近 7 天）
#  2. 清理 deploy_backups 只保留最近 5 份前端
#  3. 清理 > 30 天的 TP runtime 日志
set -euo pipefail
LOG=/var/log/crmeb-maintenance.log
exec >> "$LOG" 2>&1
echo "===== $(date '+%F %T') ====="

PROJECT_DIR=/opt/crmeb-prod
DB_DIR=/opt/crmeb-prod/db_backup
DEPLOY_DIR=/opt/crmeb-prod/deploy_backups
RUNTIME_LOG=/opt/crmeb-prod/backend_src/runtime/log
BACKEND_ENV="${PROJECT_DIR}/backend_src/.env"

get_ini() {
  local section="$1"
  local key="$2"
  local file="$3"
  awk -v section="$section" -v key="$key" '
    BEGIN { in_section=0 }
    /^\[/ { in_section = ($0 == "[" section "]"); next }
    in_section && $0 ~ "^[[:space:]]*" key "[[:space:]]*=" {
      sub(/^[^=]*=[[:space:]]*/, "");
      sub(/[[:space:]]*$/, "");
      print;
      exit;
    }
  ' "$file"
}

DB_HOST="$(get_ini DATABASE HOSTNAME "${BACKEND_ENV}" 2>/dev/null || true)"
DB_NAME="$(get_ini DATABASE DATABASE "${BACKEND_ENV}" 2>/dev/null || true)"
DB_USER="$(get_ini DATABASE USERNAME "${BACKEND_ENV}" 2>/dev/null || true)"
DB_PASS="$(get_ini DATABASE PASSWORD "${BACKEND_ENV}" 2>/dev/null || true)"
DB_PORT="$(get_ini DATABASE HOSTPORT "${BACKEND_ENV}" 2>/dev/null || true)"
DB_CHARSET="$(get_ini DATABASE CHARSET "${BACKEND_ENV}" 2>/dev/null || true)"

DB_HOST="${DB_HOST:-127.0.0.1}"
DB_NAME="${DB_NAME:-manghehoutai_qhe}"
DB_USER="${DB_USER:-crmeb}"
DB_PORT="${DB_PORT:-3306}"
DB_CHARSET="${DB_CHARSET:-utf8mb4}"

# 1. MySQL 备份
mkdir -p "$DB_DIR"
TS=$(date +%Y%m%d_%H%M%S)
OUT="$DB_DIR/manghehoutai_qhe_${TS}.sql.gz"
TMP_OUT="${OUT}.tmp"
ERR_FILE="${OUT}.err"
rm -f "$TMP_OUT" "$ERR_FILE"

if MYSQL_PWD="$DB_PASS" mysqldump -h"$DB_HOST" -P"$DB_PORT" -u"$DB_USER" \
  --single-transaction --quick --no-tablespaces --default-character-set="$DB_CHARSET" \
  --routines --triggers --events \
  "$DB_NAME" 2>"$ERR_FILE" | gzip -9 > "$TMP_OUT"; then
  if gzip -t "$TMP_OUT"; then
    UNCOMPRESSED_BYTES=$(gzip -l "$TMP_OUT" | awk 'NR==2 {print $2 + 0}')
  else
    UNCOMPRESSED_BYTES=0
  fi

  if [ -s "$TMP_OUT" ] && [ "${UNCOMPRESSED_BYTES:-0}" -gt 0 ]; then
    mv "$TMP_OUT" "$OUT"
    rm -f "$ERR_FILE"
    echo "[db_backup] OK: $(ls -lh "$OUT" | awk '{print $5}'), uncompressed=${UNCOMPRESSED_BYTES} bytes -> $OUT"
  else
    echo "[db_backup] FAILED: empty dump, removing ${TMP_OUT}"
    rm -f "$TMP_OUT"
    [ -s "$ERR_FILE" ] && sed -E 's/(using password: ).*/\1<redacted>/' "$ERR_FILE" | head -20
    exit 1
  fi
else
  echo "[db_backup] FAILED: mysqldump error, removing ${TMP_OUT}"
  rm -f "$TMP_OUT"
  [ -s "$ERR_FILE" ] && sed -E 's/(using password: ).*/\1<redacted>/' "$ERR_FILE" | head -20
  exit 1
fi

# 1b. 保留最近 7 份 dump
if [ "${SKIP_RETENTION:-0}" != "1" ]; then
  cd "$DB_DIR" && ls -1t *.sql.gz 2>/dev/null | tail -n +8 | while IFS= read -r f; do
    [ -f "$f" ] && rm -f "$f" && echo "[db_backup] deleted old: $f"
  done
fi

# 2. 前端部署备份保留最近 5 份
if [ "${SKIP_RETENTION:-0}" != "1" ] && [ -d "$DEPLOY_DIR" ]; then
  cd "$DEPLOY_DIR" && ls -1td frontend_* 2>/dev/null | tail -n +6 | while IFS= read -r d; do
    [ -d "$d" ] && rm -rf "$d" && echo "[deploy_backup] deleted: $d"
  done
fi

# 3. TP runtime 日志 > 30 天
if [ "${SKIP_RETENTION:-0}" != "1" ] && [ -d "$RUNTIME_LOG" ]; then
  find "$RUNTIME_LOG" -name "*.log" -type f -mtime +30 -delete -print | sed 's/^/[runtime_log] deleted: /'
fi

echo "[df] $(df -h / | tail -1)"
echo
