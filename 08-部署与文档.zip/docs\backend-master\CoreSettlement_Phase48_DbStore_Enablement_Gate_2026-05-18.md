# CoreSettlement Phase 48 DbStore Enablement Gate 2026-05-18

## Current Task

Phase 48 defines the DbPointTransactionStore enablement gate.

Gate only.
No PHP runtime store wiring was changed.
No production switch was enabled.
No SQL was executed.
No migration was run.
No deployment was executed.
No write path was enabled.

## Current Required State

```text
PointTransactionService default store: DryRunPointTransactionStore
DbPointTransactionStore::usesDatabase(): false
database_writes: false
dry_run_only: true
production_switch_enabled: false
```

## Enablement Preconditions

```text
explicit user approval required: true
tables created and verified: required
readonly reconciliation report: required
write shadow comparison: required
rollback plan: required
kill switch: required
rate limit: required
admin audit log: required
AI execution endpoint: forbidden
route mutation endpoints: forbidden
```

## Required Future Switches

```text
core_point_gateway_db_store_enabled default 0
core_point_gateway_write_shadow default 0
core_point_gateway_write_live default 0
```

All switches default to 0.
Live write cannot be enabled in the same phase as DB store wiring.

## Future Rollout Order

```text
1. create tables after approval
2. verify tables readonly
3. wire DbPointTransactionStore behind default-off switch
4. run local assert pack
5. deploy after approval
6. enable write shadow only after approval
7. compare dry-run vs db rows
8. enable live write only after separate approval
```

## Guards

```text
store_wiring_changed: false
db_store_enabled: false
live_write_enabled: false
shadow_write_enabled: false
sql_executed: false
migration_run: false
deployment_executed: false
```

## Validation

```text
point_gateway_db_store_enablement_gate_assert
core_settlement_backend_package_assert
```
