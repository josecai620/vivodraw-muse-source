#!/usr/bin/env bash
set -euo pipefail
cp /tmp/MemberCardServices.php /opt/crmeb-prod/backend_src/app/services/user/member/MemberCardServices.php
docker exec crmeb-php-fpm php -l /var/www/backend/app/services/user/member/MemberCardServices.php
docker exec crmeb-php-fpm sh -c 'cd /var/www/backend && php think clear' || true
bash /tmp/remote-release-root.sh 20260916_191000 I_UNDERSTAND_WHOLE_SITE_REPLACEMENT
bash /tmp/remote-bump-v4rel.sh 20260916_191000
echo RELEASE_DONE
