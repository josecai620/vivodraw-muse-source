# PHP 8.1 迁移（方案 A 完整版）

**决策日期**：2026-04-21
**决策**：走 **方案 A**（弃 think-swoole + PHP-FPM + 独立 WS 服务），**一步到位**
**决策人**：joe
**预估工期**：4-6 周（按阶段可随时暂停不影响生产）

---

## 为什么选 A

- 预见到上线后用户会过千，WebSocket 是刚需（客服实时聊天、管理员订单提醒）
- 不想做两次迁移（C 短期方案迟早要切 A，还不如一次做对）
- pre-launch 阶段是做架构重塑的最佳窗口（没有真实用户要照顾）

## 为什么不选 B（Hyperf 重构）

- 10-16 周工期完全重构业务代码，代价太大
- 当前业务稳定性已经 OK（P0-P5 清理、Pet AI 多语言都做好了），架构并不需要推倒重来
- B 适合"已经有 MRR、稳定业务、做技术重塑"的阶段；现在不是

---

## 目标架构

```
┌───────────────┐     HTTP       ┌──────────────────┐
│   Nginx       │───────────────▶│   PHP 8.1 FPM    │
│   443/80      │   /api/*       │   (HTTP API)     │
│               │                 └─────────┬────────┘
│               │                           │
│               │   WebSocket                │ Redis PUBLISH
│               │───────────────────┐       │ chan: push.admin.{id}
│               │   /ws/*          │       ▼
│               │                   │ ┌──────────┐
│               │                   ▼ │  Redis   │
│               │              ┌─────────────┐ │ (pub/sub + cache)
│               │              │   Soketi    │◀┘
│               │◀─────────────┤  (WS svc)   │
│               │   push frames│  Pusher     │
└───────────────┘              │  protocol   │
                                └─────────────┘

同时还有：
┌──────────────────┐
│  PHP 8.1 CLI     │  (systemd-managed workers)
│  Queue workers   │  - CRMEB_PRO (下单后续)
│  Cron tasks      │  - CRMEB_PRO_BATCH
└──────────────────┘  - CRMEB_PRO_TASK / _ERP / _LOG
```

### 关键组件选型

| 组件 | 选型 | 理由 |
|------|-----|------|
| HTTP API | PHP 8.1 FPM | 主流、成熟、易运维 |
| Nginx | 继续用 | 已有配置，reverse proxy 好做 |
| WS 服务 | **Soketi** | Pusher 协议兼容、Docker 一把起、社区活跃（Laravel 生态默认）、MIT license、自维护代码 0 行 |
| WS 客户端 | **pusher-js** | 官方 Pusher 客户端，Vue/React/Expo 全兼容；断线重连 + 心跳内置 |
| 队列 | think-queue + Redis driver | 保留现有代码，但用 supervisord 跑 worker 进程 |
| Pub/Sub 桥 | Redis | 已有，零成本 |

### 为什么用 Pusher 协议（Soketi）而不是自写 WS

- **Pusher 协议是标准**：前端 JS / iOS / Android SDK 都现成
- **Soketi** 是 Pusher 开源兼容实现，完全替代 Pusher 自建
- 带内置：private channel（鉴权）、presence channel（在线列表）、心跳重连
- 我们自写 WS = 重新发明轮子 + bug 源 + 维护成本

---

## 业务代码兼容性策略（**核心：业务层零改动**）

关键决策：**保留 `SocketPush::admin()->type(...)->data(...)->push()` fluent API 接口不变**。

所有控制器 / service / listener 里的调用都不动，只换底层实现：

```php
// app/webscoket/SocketPush.php 内部改成
public function push(): bool
{
    return $this->adapter->push($this->userType, $this->targetId, $this->msgType, $this->msgData);
}
```

而 `$this->adapter` 通过容器注入，两种实现任选：
- `ThinkSwoolePushAdapter` — 当前走 think-swoole IPC（过渡期保留）
- `RedisBroadcastPushAdapter` — 未来走 Redis PUBLISH 到 Soketi（A 方案实际用）

切换方式：`config/push.php` 或 `.env` 里一个开关。

---

## 分阶段执行路线图

### 阶段 1：抽象层 + 基础设施（**1-2 周**，不影响生产）

**1.1** 抽象 `SocketPushAdapter` 接口
- 定义方法 `push(string $userType, $targetId, string $type, array $data): bool`
- 实现 `ThinkSwoolePushAdapter`（把当前 `SocketPush::push()` 里的 think-swoole IPC 逻辑搬进去）
- `SocketPush::push()` 委托给 adapter
- 通过 `bind(SocketPushAdapter::class, ThinkSwoolePushAdapter::class)` 注入
- **验证**：现有功能 100% 不变（回归所有 Pet AI / 管理员推送等场景）

**1.2** 实现 `RedisBroadcastPushAdapter`
- 把消息 PUBLISH 到 Redis channel `push.{userType}.{targetId}` 或广播 `push.{userType}`
- Channel 名称约定 + payload 格式写进 `docs/php81-migration/websocket_protocol.md`
- 单元测试：发 push，订阅端收到

**1.3** 起 Soketi 容器 + 连接测试
- `docker-compose.yml` 加 soketi service（端口 6001）
- 配置 Redis adapter（订阅 Redis pub/sub）
- 简单客户端（pusher-js 的 node.js demo）连上 Soketi，验证通道工作

**1.4** 验证链路
- 后端调 `RedisBroadcastPushAdapter::push()` → Redis PUBLISH
- Soketi 读取 → 推给订阅了对应 channel 的客户端
- 客户端收到消息

**里程碑**：**SocketPush 业务代码零改动，底层 Adapter 可一键切换。**

---

### 阶段 2：PHP 8.1 FPM 环境（**1 周**）

**2.1** 构建 `deploy/docker/php81-fpm/Dockerfile`
- FROM php:8.1-fpm-bookworm
- 装扩展：pdo_mysql, mysqli, bcmath, gd, intl, zip, pcntl, opcache, redis, mbstring
- 不装 swoole 了（PHP-FPM 模式不需要）

**2.2** 依赖升级（在 Docker 容器里跑）
- `topthink/framework` 6.0.9 → ^6.1
- `symfony/var-dumper` + `symfony/http-foundation` → ^5.4
- `firebase/php-jwt` 5.x → ^6.10
- `overtrue/wechat` → ^6（可选，不 plug 也可以）
- `alipaysdk/easysdk` 保留最新版（代码已 stub，不真正调）
- `xiaodi/think-pullword` 删除（已做，见前）
- **删除 `topthink/think-swoole`**（不再用）

**2.3** Nginx + PHP-FPM 配置
- `deploy/nginx/eccomall.conf` 改成 fastcgi + Unix socket
- `/api/*` → PHP-FPM
- `/ws/*` → Soketi (6001)
- `/static/*` → public/ 直出

**2.4** PHP 8.x 破坏点扫描与修复
- `each()`、`create_function()`、`ReflectionType::__toString()` 删除
- 可 null 传 string 函数（`strlen(null)`、`explode()` 等）变 deprecated warning → 全码检查
- 动态属性 8.1 deprecated 警告 → 加 `#[AllowDynamicProperties]` 或声明属性
- 用 **phpstan level 1** 做一轮扫描，最严重的问题先修

**2.5** 启动 FPM 测试
- curl 基础 API 能响应
- Login 能通
- 单元测试 28/28 通过

---

### 阶段 3：队列 worker 独立化（**3-5 天**）

think-swoole 之前把 5 个 queue workers（CRMEB_PRO / _BATCH / _TASK / _ERP / _LOG）跑在同进程。PHP-FPM 模式下必须独立。

**3.1** 写 systemd 单元 `eccomall-queue@.service`
- 模板化单元，用 `@connection` 参数传 queue 名
- `ExecStart=/usr/bin/php8.1 think queue:work --queue=%i --sleep=3 --tries=3`

**3.2** `supervisord` 或 5 个 systemd 实例并存
- 每个 queue 一个独立进程（hang 不影响其他）
- 日志分开 `/var/log/eccomall-queue-{name}.log`

**3.3** 验证
- 下单后，订单通知 queue job 能被正确消费
- 队列消息从 Redis → worker → 处理完成

---

### 阶段 4：前端 WS 客户端切换（**1 周**）

现在前端用的是 think-swoole 自定义协议（`?type=admin&token=xxx`）。Soketi 用 Pusher 协议，要改前端 WS 客户端代码。

**4.1** Vue 后台（管理员、门店、客服）
- 装 `pusher-js`
- 把原 WS 连接代码 `new WebSocket('ws://.../?...')` 换成：
  ```js
  const pusher = new Pusher('app-key', { cluster: 'mt1', wsHost: 'ws.yoursite.com', wsPort: 443 });
  const channel = pusher.subscribe(`private-admin.${adminId}`);
  channel.bind('NEW_ORDER', (data) => { /* ... */ });
  ```
- Channel 订阅逻辑：`private-admin.{uid}`、`private-store.{store_id}`、`private-kefu.{uid}`

**4.2** Expo RN 前台（用户端聊天、公告）
- 装 `pusher-js` 或 `@pusher/pusher-websocket-react-native`
- 同上改订阅

**4.3** Private channel 鉴权
- Soketi 请求 `/broadcasting/auth` 端点验证用户是否有权限订阅该 channel
- 后端实现一个 `BroadcastingAuthController`（签 Pusher 格式的 token）

**4.4** 前后端协议对照表
- 写在 `docs/php81-migration/websocket_protocol.md`
- 列出所有事件名（NEW_ORDER / WITHDRAW / PAY_SMS_SUCCESS 等）对应的 channel 和 payload 结构

---

### 阶段 5：双跑 + 切换 + 下线老服务（**1 周**）

**5.1** 双跑期
- 旧 think-swoole 继续在 127.0.0.1:20199（内部访问）
- 新 PHP-FPM + Soketi 在新端口
- 用 Nginx 根据 `cookie` 或 `header` 做灰度（1% → 10% → 50% → 100%）

**5.2** 切换
- Nginx 全量切到新架构
- 观察 24 小时，看是否有回归

**5.3** 回滚预案
- 保留旧 think-swoole 服务文件一周
- 回滚只需 Nginx 切配置

**5.4** 下线
- `systemctl disable crmeb-swoole`
- 归档旧镜像 tag

---

### 阶段 6：运维 + 文档（持续）

- Prometheus node_exporter + Soketi metrics
- Sentry error tracking（后端 PHP + 前端 Vue/Expo）
- 更新 `deploy/DEPLOY.md` 反映新架构
- CHANGELOG 记录版本升级

---

## 风险与回滚

### 风险等级

| 风险 | 级别 | 缓解 |
|------|-----|------|
| composer update 冲突（wechat/socialite SDK 新版 API 有 breaking change）| 🔴 高 | 阶段 2.2 单独跑，失败就回滚到 6.0 框架 |
| 前端 pusher-js 在 Expo RN 上不稳 | 🟡 中 | 先 Vue 后台迁，Expo 延后；必要时用 `@pusher/pusher-websocket-react-native` |
| Private channel 鉴权实现错误导致广播错消息 | 🟡 中 | 端到端测试每个 channel，特别是 admin / store / kefu 之间不能串 |
| Queue worker 单进程挂导致消费停滞 | 🟡 中 | systemd `Restart=always`，配 healthcheck |

### 回滚能力

- **每阶段独立**：阶段 1 完成后可以停留观察（底层 Adapter 已抽象，业务代码不变）
- **阶段 5 切换**：Nginx 配置是回滚开关，30 秒内能切回旧架构

---

## 已完成的预处理（2026-04-20 会话 5 做的，保留有效）

- ✅ `app/services/pay/PayServices.php` stub 掉 Alipay/WeChat 工厂
- ✅ `crmeb/services/VicWordService.php` 改成 stub（去中文分词依赖）
- ✅ DB `eb_system_config` 里 Alipay/微信/腾讯 相关 41 项配置已清零
- ✅ `app/lang/en-us.php` + `zh-cn.php` + `LoginController` i18n 改造起步
- ✅ Pet AI 多语言自适应

---

## 2026-04-21 失败尝试（已回滚）

尝试 PHP 8.1 + swoole 4.8.13 + think-swoole 4.1.1 三种组合都 silent fail。think-swoole 是死包（2022 年后无更新），无 PHP 8.1 兼容版本。**方案 A 完全绕过这个包，该问题不再存在**。

---

## 本轮启动点

**立刻开始**：阶段 1.1 — 抽象 SocketPushAdapter 接口。

这是一个**不影响现有服务**的改动，相当于给未来切 A 留好"还款接口"。就算后来不做 A 了，这个抽象本身也是正确的架构（解耦业务和基础设施）。
