# CoreSettlement Phase 41 AI Operation Log Table Draft 2026-05-18

## Current Task

Phase 41 defines the AI operation log and approval audit table draft.

Draft only.
No migration file was created.
No SQL was executed.
No DB write was added.
No deployment was executed.

## Table Draft

```text
primary table: eb_core_point_gateway_ai_operation_log
approval audit table: eb_core_point_gateway_approval_audit
mode: schema_draft_only
```

## Required Fields

```text
id
proposal_no
approval_request_id
operation
scene
request_id
target_table
target_id
uid
decision
status
risk_level
summary
payload_hash
payload_json
evidence_json
policy_version
created_by_type
created_by_id
approved_by
approved_at
expires_at
created_at
updated_at
```

## Index Draft

```text
uniq_proposal_no(proposal_no)
idx_target(target_table, target_id)
idx_uid_status(uid, status)
idx_operation_decision(operation, decision)
idx_approval_request(approval_request_id)
idx_created_at(created_at)
```

`payload_json` and `evidence_json` should remain `TEXT` in the draft until production MySQL JSON compatibility is confirmed.

## Approval Audit Table Draft

```text
table: eb_core_point_gateway_approval_audit
approval_request_id
source_log_id
uid
operation
target_table
target_id
status
risk_level
requested_by_type
requested_by_id
reviewed_by_admin_id
reviewed_by_admin_name
review_note
evidence_hash
created_at
reviewed_at
expired_at
```

## Approval Audit Index Draft

```text
uk_approval_request(approval_request_id)
idx_status_time(status, created_at)
idx_uid_status(uid, status)
idx_target(target_table, target_id)
idx_source_log(source_log_id)
```

## Status Draft

```text
suggested
needs_review
rejected_by_policy
pending_review
human_approved
human_rejected
expired
cancelled
executed_in_later_phase
```

## Guards

```text
sql_execution: false
migration_created: false
database_writes: false
append_only_required: true
payload_hash_required: true
raw_sensitive_fields_allowed: false
execution_endpoint: false
```

Approval is not execution.
`human_approved` only allows a later separate write phase with kill switch and reconciliation.

Never store raw sensitive fields:

```text
payload
headers
cookie
token
password
secret
authorization
```

## Validation

```text
point_gateway_operation_log_schema_assert
point_gateway_ai_operation_log_assert
```
