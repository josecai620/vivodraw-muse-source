-- 需要先在「系统设置 → 隐私与安全性 → 辅助功能」里给「终端」或「脚本编辑器」勾选
tell application "HBuilderX" to activate
delay 1.5
tell application "System Events"
	tell process "HBuilderX"
		set frontmost to true
		click menu bar item "发行" of menu bar 1
		delay 0.8
		click menu item "网站-PC Web或手机H5" of menu 1 of menu bar item "发行" of menu bar 1
	end tell
end tell
