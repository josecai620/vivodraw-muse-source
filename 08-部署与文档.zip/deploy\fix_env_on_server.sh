#!/usr/bin/env bash
# 修复服务器上的 .env（部署时被本地配置覆盖后，恢复为 Docker 环境所需配置）
# 用法: ./fix_env_on_server.sh <服务器IP> [ssh_user] [ssh_port]
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "用法: $0 <服务器IP> [ssh_user] [ssh_port]"
  exit 1
fi

SERVER_IP="$1"
SSH_USER="${2:-root}"
SSH_PORT="${3:-49375}"
REMOTE_DIR="/opt/crmeb-prod"
BACKEND_DIR="${REMOTE_DIR}/backend_src"
ENV_FILE="${REMOTE_DIR}/deploy/.deploy.env"

echo "==> 修复服务器 ${SERVER_IP} 上的 .env"

ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" "bash -s" << 'REMOTE_SCRIPT'
set -e
BACKEND_DIR="/opt/crmeb-prod/backend_src"
ENV_FILE="/opt/crmeb-prod/deploy/.deploy.env"
ENV="${BACKEND_DIR}/.env"

[[ -f "${ENV}" ]] || { echo "错误: ${ENV} 不存在"; exit 1; }
[[ -f "${ENV_FILE}" ]] || { echo "错误: ${ENV_FILE} 不存在，无法读取数据库配置"; exit 1; }

source "${ENV_FILE}"
# 修复 Docker 环境所需的连接配置
sed -i "s|^HOSTNAME.*|HOSTNAME = mysql|" "${ENV}"
sed -i "s|^HOSTPORT.*|HOSTPORT = 3306|" "${ENV}"
sed -i "s|^USERNAME.*|USERNAME = ${MYSQL_USER}|" "${ENV}"
sed -i "s|^PASSWORD.*|PASSWORD = '${MYSQL_PASSWORD}'|" "${ENV}"
sed -i "s|^DATABASE.*|DATABASE = ${MYSQL_DATABASE}|" "${ENV}"
sed -i "s|^REDIS_HOSTNAME.*|REDIS_HOSTNAME = redis|" "${ENV}"
sed -i "s|^PORT.*|PORT = 6379|" "${ENV}"
sed -i "s|^REDIS_PASSWORD.*|REDIS_PASSWORD = ''|" "${ENV}"
sed -i "s|^APP_DEBUG.*|APP_DEBUG = false|" "${ENV}" || true
echo "==> .env 已修复"
REMOTE_SCRIPT

echo "==> 重启应用容器"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" "docker restart crmeb-app"

echo "==> 完成，请访问 http://${SERVER_IP}/ 验证"
