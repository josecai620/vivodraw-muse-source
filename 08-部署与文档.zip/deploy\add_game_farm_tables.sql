-- Farm game tables.
-- Apply only after backup and DB approval.

CREATE TABLE IF NOT EXISTS `eb_game_farm_profile` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Farm profile id',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'User uid',
  `farm_level` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'Farm level',
  `plot_total` tinyint(3) unsigned NOT NULL DEFAULT '9' COMMENT 'Unlocked plot count',
  `harvest_count_total` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Total harvested plots',
  `today_steal_used` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Today steal count',
  `today_steal_limit` int(10) unsigned NOT NULL DEFAULT '8' COMMENT 'Today steal limit',
  `steal_day` char(10) NOT NULL DEFAULT '' COMMENT 'Steal day YYYY-MM-DD',
  `guard_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 inactive 1 active',
  `guard_expired_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Guard expire time',
  `guard_block_rate_bp` int(10) unsigned NOT NULL DEFAULT '5000' COMMENT 'Guard block rate basis points',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Create time',
  `updated_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Update time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`),
  KEY `guard_expired_at` (`guard_expired_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Farm user profile';

CREATE TABLE IF NOT EXISTS `eb_game_farm_plot` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Farm plot id',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'User uid',
  `plot_no` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Plot number',
  `is_unlocked` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT 'Is unlocked',
  `state` varchar(16) NOT NULL DEFAULT 'idle' COMMENT 'idle growing mature wilted',
  `crop_key` varchar(32) NOT NULL DEFAULT '' COMMENT 'Crop key',
  `crop_label` varchar(32) NOT NULL DEFAULT '' COMMENT 'Crop label',
  `cost_points` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Plant cost points',
  `harvest_reward_points` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Harvest reward points',
  `planted_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Plant time',
  `mature_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Mature time',
  `wither_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Wither time',
  `stolen_points_total` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Stolen points in cycle',
  `steal_count_current_cycle` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Steal count in cycle',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Create time',
  `updated_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Update time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_plot_no` (`uid`,`plot_no`),
  KEY `state_mature_at` (`state`,`mature_at`),
  KEY `state_wither_at` (`state`,`wither_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Farm plot state';

CREATE TABLE IF NOT EXISTS `eb_game_farm_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Farm action log id',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Actor uid',
  `action` varchar(32) NOT NULL DEFAULT '' COMMENT 'Action',
  `plot_no` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Target plot number',
  `target_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Target uid',
  `points_delta` int(11) NOT NULL DEFAULT '0' COMMENT 'Signed points delta',
  `balance_after` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Integral balance after action',
  `risk_flags` varchar(255) NOT NULL DEFAULT '' COMMENT 'Risk flags',
  `request_hash` varchar(64) NOT NULL DEFAULT '' COMMENT 'Idempotency hash',
  `client_now_ms` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Client timestamp audit',
  `server_now` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Server timestamp',
  `payload_json` text NULL COMMENT 'Debug payload',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Create time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_hash` (`request_hash`),
  KEY `uid_action_time` (`uid`,`action`,`created_at`),
  KEY `target_uid_time` (`target_uid`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Farm action audit log';
