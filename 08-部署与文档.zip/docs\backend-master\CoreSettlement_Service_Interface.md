# CoreSettlement Service Interface

## 原则

本接口设计只定义旁路规范层，不写真实业务接入。

旧表继续保留：

- `eb_user`
- `eb_user_bill`
- `eb_store_order`
- `eb_store_product`
- `eb_store_product_attr_value`
- `eb_store_integral_product*`
- `eb_store_integral_order*`
- `eb_box_order`
- `eb_user_box`
- `eb_group_lottery*`
- `game_farm_*`
- `game_mine_*`

第一批明确不接：

- 不接 `MangheController`
- 不接支付
- 不接订单
- 不接真实库存扣减
- 不动 `game/` 当前开发代码

## CoreSettlementService

职责：

- 统一结算入口。
- 统一幂等检查。
- 统一事务边界。
- 统一结果记录。
- 统一失败记录。

接口草案：

```php
interface CoreSettlementServiceInterface
{
    public function begin(string $scene, string $action, int $uid, string $requestId, array $payload = []): SettlementContext;

    public function run(SettlementContext $context, callable $handler): SettlementResult;

    public function finish(SettlementContext $context, array $result = []): void;

    public function fail(SettlementContext $context, \Throwable $error): void;

    public function getByRequest(string $scene, string $requestId): ?array;
}
```

## LedgerService

职责：

- 管理积分旁路账本。
- 记录积分收入、支出、余额前后值。
- 保留映射旧 `eb_user_bill` 能力，但第一批不自动写旧表。

接口草案：

```php
interface LedgerServiceInterface
{
    public function previewPointChange(int $uid, int $amount): array;

    public function addPoint(SettlementContext $context, int $uid, int $amount, string $reason, array $meta = []): array;

    public function deductPoint(SettlementContext $context, int $uid, int $amount, string $reason, array $meta = []): array;

    public function getByRequest(string $scene, string $requestId): ?array;
}
```

## RewardService

职责：

- 创建奖励记录。
- 管理奖励状态。
- 奖励领取必须走 claim lock。
- 奖励先入记录，再领取到账。

接口草案：

```php
interface RewardServiceInterface
{
    public function createReward(int $uid, string $rewardType, string $sourceScene, string $sourceId, array $payload = []): array;

    public function claimReward(int $uid, int $rewardId, string $claimKey): array;

    public function expireReward(int $rewardId): void;

    public function revokeReward(int $rewardId, string $reason): void;
}
```

## RewardClaimLockService

职责：

- 保证同一奖励同一领取键只成功一次。
- 重复请求返回首次结果。
- 失败是否可重试由状态决定。

接口草案：

```php
interface RewardClaimLockServiceInterface
{
    public function acquire(int $uid, int $rewardId, string $claimKey): array;

    public function finish(int $lockId, array $result): void;

    public function fail(int $lockId, string $error, bool $retryable = false): void;

    public function getExisting(int $uid, int $rewardId, string $claimKey): ?array;
}
```

## InventoryLockService

职责：

- 管理库存锁。
- 管理库存流水。
- 第一批只允许 dry-run，不扣真实库存。

接口草案：

```php
interface InventoryLockServiceInterface
{
    public function lockStock(SettlementContext $context, int $productId, string $skuId, int $qty, int $expireAt): array;

    public function releaseStock(int $lockId, string $reason): void;

    public function commitStock(int $lockId): array;

    public function writeInventoryLedger(SettlementContext $context, int $delta, int $before, int $after, array $meta = []): void;
}
```

## PaymentWebhookLogService

职责：

- 支付回调先落日志。
- 使用 `provider + event_id` 幂等。
- 第一批不接真实支付回调。

接口草案：

```php
interface PaymentWebhookLogServiceInterface
{
    public function record(string $provider, string $eventId, array $rawPayload, string $signature = ''): array;

    public function markVerified(int $logId): void;

    public function markRejected(int $logId, string $reason): void;

    public function markProcessed(int $logId, array $result = []): void;

    public function isDuplicate(string $provider, string $eventId): bool;
}
```

## RiskLogService

职责：

- 记录风控命中。
- 第一批只记录，不强拦截。
- 决策枚举：`allow`、`review`、`block`、`throttle`。

接口草案：

```php
interface RiskLogServiceInterface
{
    public function check(SettlementContext $context, array $payload = []): array;

    public function writeRiskLog(SettlementContext $context, string $riskCode, string $level, string $decision, string $reason): void;

    public function throttleKey(string $scene, int $uid, string $action): string;
}
```

## AnalyticsEventService

职责：

- 记录行为埋点。
- 可异步，不阻断主结算。
- 用于奖励漏斗、支付回调、风控命中、库存消耗、结算结果统计。

接口草案：

```php
interface AnalyticsEventServiceInterface
{
    public function track(int $uid, string $scene, string $eventName, array $payload = []): void;

    public function trackSettlement(SettlementContext $context, SettlementResult $result): void;

    public function trackRisk(SettlementContext $context, array $decision): void;
}
```

## 接入顺序

第一批：

1. 创建接口和空服务。
2. 创建 dry-run 写入能力。
3. 后台测试入口或命令行测试入口。

当前 dry-run 命令：

```bash
cd backend_src
php think core:settlement-dry-run
```

该命令只调用旁路服务骨架并输出 JSON，不写数据库，不接真实业务。

Standalone dry-run fallback:

```bash
php backend_src/scripts/core_settlement_dry_run.php
```

本地 PHP 若未安装 Redis 扩展，`php think` 可能在框架启动阶段报 `not support: redis`。此时用 standalone 脚本验证服务骨架；该脚本不启动 ThinkPHP，不写数据库。

暂时禁止：

1. `MangheController`
2. 支付回调
3. 普通商城订单
4. 积分开奖
5. 拼团退款/开奖
6. 真实库存扣减
