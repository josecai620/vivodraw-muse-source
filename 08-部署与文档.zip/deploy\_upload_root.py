# -*- coding: utf-8 -*-
"""分块上传 v4 根包并切 nginx $v4rel。"""
import os
import json
import subprocess
from datetime import datetime
from pathlib import Path


manifest_path = os.environ.get("RELEASE_MANIFEST")
if not manifest_path:
    raise SystemExit(
        "refusing full-root upload: RELEASE_MANIFEST is required; "
        "use scoped overlay unless the user explicitly authorizes whole-site replacement"
    )
manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
if manifest.get("mode") != "full-site":
    raise SystemExit("refusing full-root upload: manifest mode must be full-site")
if os.environ.get("RELEASE_WHOLE_SITE_AUTH") != "I_UNDERSTAND_WHOLE_SITE_REPLACEMENT":
    raise SystemExit(
        "refusing full-root upload: explicit whole-site authorization token is required"
    )

key = os.path.expanduser(r"~\.ssh\vivodraw_windows_ed25519")
host = "root@186.241.72.176"
port = "49375"
ssh = [
    "ssh", "-i", key, "-p", port,
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
    "-o", "ServerAliveInterval=15",
    host,
]
scp = [
    "scp", "-O", "-i", key, "-P", port,
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
]
bundle = Path(r"D:\eccomall\deploy\v4-root-bundle.tar.gz")
chunks_dir = Path(r"D:\eccomall\deploy\v4-chunks")
ts = datetime.now().strftime("%Y%m%d_%H%M%S")
prefix = "v4up-%s" % ts
if not bundle.is_file():
    raise SystemExit("missing bundle")
data = bundle.read_bytes()
chunks_dir.mkdir(exist_ok=True)
for old in chunks_dir.glob("part-*"):
    old.unlink()
size = 4_000_000
parts = []
for i in range(0, len(data), size):
    name = "part-%03d" % (i // size)
    (chunks_dir / name).write_bytes(data[i:i + size])
    parts.append(name)
print("ts", ts, "bytes", len(data), "parts", len(parts), flush=True)
subprocess.check_call(ssh + ["rm -f /tmp/%s-*" % prefix])
for name in parts:
    dest = "%s:/tmp/%s-%s" % (host, prefix, name)
    print("scp", name, flush=True)
    rc = subprocess.call(scp + [str(chunks_dir / name), dest])
    if rc != 0:
        raise SystemExit("scp failed " + name)
remote_parts = " ".join("/tmp/%s-%s" % (prefix, n) for n in parts)
cat = "cat %s > /tmp/v4-root-bundle.tar.gz && rm -f /tmp/%s-* && ls -l /tmp/v4-root-bundle.tar.gz" % (remote_parts, prefix)
print(subprocess.check_output(ssh + [cat], timeout=120).decode(errors="replace"), flush=True)
release = "bash /root/remote-release-root.sh %s I_UNDERSTAND_WHOLE_SITE_REPLACEMENT" % ts
print(subprocess.check_output(ssh + [release], timeout=180).decode(errors="replace"), flush=True)
bump = "bash /root/remote-bump-v4rel.sh %s" % ts
print(subprocess.check_output(ssh + [bump], timeout=60).decode(errors="replace"), flush=True)
Path(r"D:\eccomall\deploy\.last_ts").write_text(ts, encoding="utf-8")
print("LIVE", ts, flush=True)
