#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="${PROJECT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
SQL_FILE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/add_feedback_reward_columns.sql"
for envf in "${PROJECT_DIR}/deploy/.deploy.env" "${PROJECT_DIR}/deploy/.env"; do
  [[ -f "${envf}" ]] && { set -a; source "${envf}" 2>/dev/null || true; set +a; [[ -n "${MYSQL_DATABASE:-}" ]] && break; }
done
[[ -z "${MYSQL_DATABASE:-}" ]] && [[ -f "${PROJECT_DIR}/backend_src/.env" ]] && {
  MYSQL_DATABASE=$(grep -E '^[[:space:]]*DATABASE[[:space:]]*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed 's/.*=[[:space:]]*//;s/[[:space:]\x27\x22]*$//' | head -1)
}
MYSQL_DATABASE="${MYSQL_DATABASE:-${DATABASE:-crmeb}}"
APP_USER=$(grep -E '^[[:space:]]*USERNAME[[:space:]]*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed 's/.*=[[:space:]]*//;s/[[:space:]]*$//' | tr -d "'\"" | head -1)
APP_PASS=$(grep -E '^[[:space:]]*PASSWORD[[:space:]]*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed "s/.*=[[:space:]]*//;s/[[:space:]]*$//;s/^['\"]//;s/['\"]$//" | head -1)
echo "==> feedback reward columns on ${MYSQL_DATABASE}"
MYSQL_PWD="${APP_PASS}" mysql -u"${APP_USER}" -h127.0.0.1 --default-character-set=utf8mb4 "${MYSQL_DATABASE}" < "${SQL_FILE}"
echo "==> done"
MYSQL_PWD="${APP_PASS}" mysql -u"${APP_USER}" -h127.0.0.1 -N -e "SHOW COLUMNS FROM ${MYSQL_DATABASE}.eb_store_service_feedback"
