#!/bin/bash
# 清理 CRMEB 缓存（执行 add_mall_nav_menus.sql 后请运行）
# 用法：./clear_cache.sh 或 bash clear_cache.sh

cd "$(dirname "$0")/.." || exit 1

# 优先用 Docker
if docker ps 2>/dev/null | grep -q crmeb-app; then
    echo "检测到 Docker 容器 crmeb-app，执行: docker exec crmeb-app php think clear"
    docker exec crmeb-app php think clear
else
    echo "未检测到 Docker，尝试本地执行: php think clear"
    php think clear 2>/dev/null || echo "请到项目根目录执行: php think clear"
fi

echo ""
echo "缓存已清理。请："
echo "  1. 退出后台"
echo "  2. 清除浏览器该站点的 localStorage（F12 → Application → Local Storage → 清除）"
echo "  3. 或使用无痕/隐私模式重新打开"
echo "  4. 重新登录后台"
echo ""
