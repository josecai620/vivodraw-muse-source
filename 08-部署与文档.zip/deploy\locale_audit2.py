# -*- coding: utf-8 -*-
import json, re, os, glob
ROOT = r'D:\eccomall\mobile-app'
en = json.load(open(os.path.join(ROOT,'lib/i18n/locales/en.json'),encoding='utf-8'))
zh = json.load(open(os.path.join(ROOT,'lib/i18n/locales/zh-TW.json'),encoding='utf-8'))
def has(o,p):
    for x in p.split('.'):
        if isinstance(o,dict) and x in o: o=o[x]
        else: return False
    return True
# 所有 "xxx.yyy" 形态、首段是已知顶层命名空间的字符串
top=set(en.keys())
lit=re.compile(r'''["'`]([a-z][A-Za-z0-9]*\.[A-Za-z0-9_.]+)["'`]''')
used={}
for f in glob.glob(os.path.join(ROOT,'app/box/**/*.tsx'),recursive=True):
    for i,l in enumerate(open(f,encoding='utf-8'),1):
        for m in lit.finditer(l):
            k=m.group(1)
            if k.split('.')[0] in top:
                used.setdefault(k,set()).add(f'{os.path.basename(f)}:{i}')
miss=sorted(k for k in used if not has(en,k))
# 过滤动态后缀（如 invite.level 后接 +n、rarity. 前缀）——打印人工判断
for k in miss:
    print(k, '<-', ','.join(sorted(used[k])))
print('total missing:',len(miss))
