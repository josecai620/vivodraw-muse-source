#!/usr/bin/env bash
# 仅更新线上代码（不重装环境、不导库）
# 用法: ./update_online.sh <服务器IP> [ssh_user] [ssh_port]
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "用法: $0 <服务器IP> [ssh_user] [ssh_port]"
  echo "示例: $0 186.241.72.176"
  exit 1
fi

SERVER_IP="$1"
SSH_USER="${2:-root}"
SSH_PORT="${3:-49375}"
REMOTE_DIR="/opt/crmeb-prod"

LOCAL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
# PROJECT_ROOT 就是仓库根目录，等于 LOCAL_ROOT（deploy-frontend.sh 就在这里）
PROJECT_ROOT="${LOCAL_ROOT}"

# 按明确文件清单发布单个功能，避免完整同步覆盖其他线上工作。
# 默认只允许 app/route；客服配置源码须另行显式批准，不允许同步 .env。
if [[ -n "${DEPLOY_BACKEND_FILES_FILE:-}" ]]; then
  SCOPED_PYTHON="${DEPLOY_PYTHON:-python3}"
  SCOPED_MANIFEST="${DEPLOY_BACKEND_MANIFEST:-}"
  if [[ ( "${DEPLOY_REQUIRE_MANIFEST:-0}" == "1" || "${DEPLOY_SUPPORT_CONFIG:-0}" == "1" ) && -z "${SCOPED_MANIFEST}" ]]; then
    echo '此发布必须提供 DEPLOY_BACKEND_MANIFEST；未上传任何文件。' >&2
    exit 1
  fi
  [[ "${SERVER_IP}" =~ ^[A-Za-z0-9][A-Za-z0-9.-]*$ && "${SSH_USER}" =~ ^[A-Za-z_][A-Za-z0-9_-]*$ && "${SSH_PORT}" =~ ^[0-9]+$ && ${#SSH_PORT} -le 5 ]] || { echo 'SSH 目标参数不合法。' >&2; exit 1; }
  (( 10#${SSH_PORT} >= 1 && 10#${SSH_PORT} <= 65535 )) || { echo 'SSH 端口不合法。' >&2; exit 1; }
  SCOPED_SSH_OPTIONS=(-p "${SSH_PORT}" -o BatchMode=yes -o IdentitiesOnly=yes -o StrictHostKeyChecking=yes)
  if [[ -n "${DEPLOY_SSH_IDENTITY:-}" ]]; then
    [[ -f "${DEPLOY_SSH_IDENTITY}" && "${DEPLOY_SSH_IDENTITY}" != *$'\n'* && "${DEPLOY_SSH_IDENTITY}" != *$'\r'* ]] || { echo 'SSH 身份文件不可用。' >&2; exit 1; }
    SCOPED_SSH_OPTIONS+=(-i "${DEPLOY_SSH_IDENTITY}")
  fi
  # rsync 自行解析 -e：参数中的空格用引号保护，不使用 Bash 的反斜杠 %q。
  SCOPED_RSH='ssh'
  for SCOPED_ARG in "${SCOPED_SSH_OPTIONS[@]}"; do
    SCOPED_ESCAPED="${SCOPED_ARG//\"/\"\"}"
    SCOPED_RSH+=" \"${SCOPED_ESCAPED}\""
  done
  # manifest 示例：{"schema":1,"files":[{"path":"backend_src/route/api.php","local_sha256":"...","remote_sha256":"..."}]}
  # remote_sha256=null 明确要求远端尚不存在；清单与 manifest 的指纹在整个发布期间固定。
  scoped_verify() {
    "${SCOPED_PYTHON}" - "${LOCAL_ROOT}" "${DEPLOY_BACKEND_FILES_FILE}" "${DEPLOY_SUPPORT_CONFIG:-0}" "${SCOPED_MANIFEST}" "$1" "${SCOPED_FILES_SHA:-}" "${SCOPED_MANIFEST_SHA:-}" <<'PY'
from pathlib import Path
import hashlib, json, re, stat, sys
source_root = Path(sys.argv[1])
root = source_root.resolve()
mode = sys.argv[5]
def reject():
    raise SystemExit('清单路径、归属或 SHA 校验失败；未授权文件不得上传。')
def plain_path(path):
    for current in (path, *path.parents):
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400):
            reject()
def read_plain(path):
    plain_path(path)
    if not path.is_file():
        reject()
    return path.read_bytes()
plain_path(source_root)
raw_list = read_plain(Path(sys.argv[2]))
items = raw_list.decode('utf-8-sig').splitlines()
files_sha = hashlib.sha256(raw_list).hexdigest()
if sys.argv[6] and files_sha != sys.argv[6]:
    reject()
if not items or len(items) != len(set(items)):
    reject()
if sys.argv[3] not in ('0', '1'):
    reject()
for item in items:
    path = Path(item)
    allowed = item.startswith(('backend_src/app/', 'backend_src/route/')) or (
        sys.argv[3] == '1' and item == 'backend_src/config/support.php')
    if not allowed or any(part in ('', '.', '..') for part in item.split('/')) or any(char in item for char in '\\:\0\r\n') or path.suffix != '.php' or path.is_absolute():
        reject()
    try:
        (root / path).resolve().relative_to(root)
    except ValueError:
        reject()
    read_plain(root / path)
manifest_sha = '-'
records = []
if sys.argv[4]:
    raw_manifest = read_plain(Path(sys.argv[4]))
    manifest_sha = hashlib.sha256(raw_manifest).hexdigest()
    if sys.argv[7] and manifest_sha != sys.argv[7]:
        reject()
    def unique_object(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                reject()
            value[key] = item
        return value
    manifest = json.loads(raw_manifest.decode('utf-8-sig'), object_pairs_hook=unique_object)
    if not isinstance(manifest, dict) or type(manifest.get('schema')) is not int or manifest['schema'] != 1 or not isinstance(manifest.get('files'), list):
        reject()
    records = manifest['files']
    if len(records) != len(items) or any(not isinstance(row, dict) or set(row) != {'path', 'local_sha256', 'remote_sha256'} for row in records):
        reject()
    if any(not isinstance(row['path'], str) for row in records) or sorted(row['path'] for row in records) != sorted(items):
        reject()
    for row in records:
        if not isinstance(row['local_sha256'], str) or not re.fullmatch('[a-f0-9]{64}', row['local_sha256']):
            reject()
        if row['remote_sha256'] is not None and (not isinstance(row['remote_sha256'], str) or not re.fullmatch('[a-f0-9]{64}', row['remote_sha256'])):
            reject()
        if hashlib.sha256(read_plain(root / row['path'])).hexdigest() != row['local_sha256']:
            reject()
if mode == 'plan':
    print(files_sha, manifest_sha)
elif mode == 'files':
    print('\n'.join(items))
elif mode in ('remote-before', 'remote-after'):
    if not records:
        reject()
    expected = [{'path': row['path'], 'sha256': row['remote_sha256'] if mode == 'remote-before' else row['local_sha256']} for row in records]
    # 远端只读核验固定仓库；不创建目录、不修改文件、不运行 PHP。
    program = '''from pathlib import Path
import hashlib, json, stat
root = Path('/opt/crmeb-prod')
records = json.loads(__RECORDS__)
for row in records:
    target = root / row['path']
    for path in (target, *target.parents):
        try:
            info = path.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, 'st_file_attributes', 0) & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400):
            raise SystemExit('Remote scoped check failed: linked path')
    if row['sha256'] is None:
        if target.exists():
            raise SystemExit('Remote scoped check failed: expected absent file')
    elif not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest() != row['sha256']:
        raise SystemExit('Remote scoped check failed: baseline mismatch')
print('Remote scoped SHA check passed')
'''
    print(program.replace('__RECORDS__', repr(json.dumps(expected, ensure_ascii=True))))
else:
    reject()
PY
  }
  SCOPED_FINGERPRINTS="$(scoped_verify plan)"
  read -r SCOPED_FILES_SHA SCOPED_MANIFEST_SHA <<< "${SCOPED_FINGERPRINTS}"
  echo '本次仅发布清单内 PHP 文件；不传 .env、资源或数据库。'
  if [[ -n "${SCOPED_MANIFEST}" ]]; then
    SCOPED_REMOTE_CHECK="$(scoped_verify remote-before)"
    printf '%s\n' "${SCOPED_REMOTE_CHECK}" | ssh "${SCOPED_SSH_OPTIONS[@]}" "${SSH_USER}@${SERVER_IP}" 'python3 -'
  else
    echo '警告：兼容旧 scoped 调用，未提供远端 SHA manifest；本次客服发布不得使用此模式。' >&2
  fi
  BACKUP_FILE="${REMOTE_DIR}/deploy_backups/海底寻珠-后端-$(date +%Y%m%d-%H%M%S).tar.gz"
  SCOPED_VALIDATED_FILES="$(scoped_verify files)"
  printf '%s\n' "${SCOPED_VALIDATED_FILES}" | ssh "${SCOPED_SSH_OPTIONS[@]}" "${SSH_USER}@${SERVER_IP}" \
    "mkdir -p '${REMOTE_DIR}/deploy_backups' && cd '${REMOTE_DIR}' && tar --ignore-failed-read -czf '${BACKUP_FILE}' -T -"
  # 再验本地 SHA 后才生成 rsync 的 stdin 清单，防止读取到后来被替换的清单文件。
  # SHA 检查到 rsync 仍有短竞态；本流程不是跨服务器原子 CAS，不自动回滚他人改动。
  SCOPED_VALIDATED_FILES="$(scoped_verify files)"
  printf '%s\n' "${SCOPED_VALIDATED_FILES}" | rsync -avz --no-owner --no-group --files-from=- \
    -e "${SCOPED_RSH}" "${LOCAL_ROOT}/" "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/"
  if [[ -n "${SCOPED_MANIFEST}" ]]; then
    SCOPED_REMOTE_CHECK="$(scoped_verify remote-after)"
    printf '%s\n' "${SCOPED_REMOTE_CHECK}" | ssh "${SCOPED_SSH_OPTIONS[@]}" "${SSH_USER}@${SERVER_IP}" 'python3 -'
  fi
  ssh "${SCOPED_SSH_OPTIONS[@]}" "${SSH_USER}@${SERVER_IP}" \
    "rm -f '${REMOTE_DIR}/backend_src/runtime/route_list.php' && docker restart crmeb-php-fpm"
  curl -fsS --max-time 30 https://vivodraw.com/ >/dev/null
  echo "已按清单发布，发布前代码备份：${BACKUP_FILE}"
  exit 0
fi

health_check() {
  local html entry
  html="$(curl -fsS "http://${SERVER_IP}/")" || return 1
  entry="$(python3 -c "import re,sys; html=sys.stdin.read(); m=re.search(r'(_expo/static/js/web/entry-[a-f0-9]+\\.js)', html); print(m.group(1) if m else '')" <<< "${html}")"
  [[ -n "${entry}" ]] || return 1
  curl -fsS -I "http://${SERVER_IP}/${entry}" >/dev/null || return 1
  echo "前台健康检查通过: ${entry}"
}

admin_v2_ready() {
  local dir="$1" asset
  [[ -d "${dir}" ]] || return 1
  [[ -f "${dir}/index.html" ]] || return 1
  asset="$(find "${dir}" -type f \( -name '*.js' -o -name '*.css' \) -print -quit)"
  [[ -n "${asset}" ]] || return 1
}

echo "==> 检查本地文件"
[[ -d "${LOCAL_ROOT}/backend_src" ]] || { echo "缺少 backend_src"; exit 1; }

echo "==> 上传 backend_src 到服务器（保留前台静态资源，避免覆盖/删除已部署前台）"
rsync -avz --no-owner --no-group --delete -e "ssh -p ${SSH_PORT}" \
  --exclude='.env' \
  --exclude='runtime/' \
  --exclude='view/admin/node_modules/' \
  --exclude='view/admin/.cache/' \
  --exclude='view/admin/dist/' \
  --exclude='view/supplier/node_modules/' \
  --exclude='view/supplier/.cache/' \
  --exclude='view/supplier/dist/' \
  --exclude='public/admin/' \
  --exclude='public/admin-v2/' \
  --exclude='public/index.html' \
  --exclude='public/index.php' \
  --exclude='public/_expo/' \
  --exclude='public/assets/' \
  --exclude='public/static/' \
  --exclude='public/legacy/' \
  --exclude='public/install/install.lock' \
  --exclude='public/phpExcel/' \
  --exclude='public/uploads/' \
  "${LOCAL_ROOT}/backend_src/" \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/backend_src/"

echo "==> 同步 deploy 脚本到服务器（排除 .env/.deploy.env 以免覆盖服务器数据库配置）"
rsync -avz --no-owner --no-group -e "ssh -p ${SSH_PORT}" \
  --exclude='.env' \
  --exclude='.deploy.env' \
  "${LOCAL_ROOT}/deploy/" \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/deploy/"

echo "==> 同步根部署入口脚本到服务器"
rsync -avz --no-owner --no-group -e "ssh -p ${SSH_PORT}" \
  "${LOCAL_ROOT}/deploy.sh" \
  "${LOCAL_ROOT}/deploy-frontend.sh" \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/"

echo "==> 同步 Vue 后台静态资源到线上 public/admin-v2"
# 注意：上面 rsync 特意 exclude 了 public/admin-v2/ 防止误删；Vue admin 走单独同步
# 优先同步线上隐藏后台入口 /admin-shop/ 对应的 public/admin-v2；兼容历史 dist，但必须完整。
LOCAL_PUBLIC_ADMIN_V2="${LOCAL_ROOT}/backend_src/public/admin-v2"
LOCAL_DIST="${LOCAL_ROOT}/backend_src/view/admin/dist"
if admin_v2_ready "${LOCAL_PUBLIC_ADMIN_V2}"; then
  rsync -avz --no-owner --no-group --delete -e "ssh -p ${SSH_PORT}" \
    "${LOCAL_PUBLIC_ADMIN_V2}/" \
    "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/backend_src/public/admin-v2/"
  echo "   Vue 经典后台 public/admin-v2 已同步到线上。"
elif admin_v2_ready "${LOCAL_DIST}"; then
  rsync -avz --no-owner --no-group --delete -e "ssh -p ${SSH_PORT}" \
    "${LOCAL_DIST}/" \
    "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/backend_src/public/admin-v2/"
  echo "   Vue admin dist 已同步到线上 public/admin-v2/。"
else
  echo "   跳过（本地未找到完整 admin-v2 静态资源：需要 index.html 和至少一个 js/css 文件）"
fi
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" \
  "cd ${REMOTE_DIR}/backend_src/public && ln -sfn admin-v2 admin-shop && ln -sfn admin-v2 admin"

echo "==> 确保 install.lock 存在（被 rsync exclude 保护，需单独维护）"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" \
  "[ -f ${REMOTE_DIR}/backend_src/public/install/install.lock ] || echo 'installed' > ${REMOTE_DIR}/backend_src/public/install/install.lock"

echo "==> 确保导出目录可写（避免 phpExcel 被本机 UID 覆盖成不可写）"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" \
  "mkdir -p ${REMOTE_DIR}/backend_src/public/phpExcel && chown -R www-data:www-data ${REMOTE_DIR}/backend_src/public/phpExcel && chmod 775 ${REMOTE_DIR}/backend_src/public/phpExcel"

echo "==> 清理 TP6 路由缓存（不清的话新路由不生效）"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" \
  "rm -f ${REMOTE_DIR}/backend_src/runtime/route_list.php"

echo "==> 重启 PHP-FPM 容器以加载 PHP 修改"
# 实际容器名是 crmeb-php-fpm，不是历史脚本里的 crmeb-app
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" "docker restart crmeb-php-fpm"

echo "==> 发布后前台验活"
if ! health_check; then
  echo "检测到前台异常，自动执行前台发布恢复..."
  if [[ -x "${PROJECT_ROOT}/deploy-frontend.sh" ]]; then
    bash "${PROJECT_ROOT}/deploy-frontend.sh" "${SERVER_IP}" "${SSH_USER}" "${SSH_PORT}"
    health_check
  else
    echo "未找到 ${PROJECT_ROOT}/deploy-frontend.sh，无法自动恢复。"
    exit 1
  fi
fi

if [[ -x "${PROJECT_ROOT}/deploy/verify_online.sh" ]]; then
  bash "${PROJECT_ROOT}/deploy/verify_online.sh" "${SERVER_IP}" "${SSH_USER}" "${SSH_PORT}"
fi

echo "==> 完成（已通过验活）"
