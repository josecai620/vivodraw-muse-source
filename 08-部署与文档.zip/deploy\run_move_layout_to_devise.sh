#!/usr/bin/env bash
# 在服务器上执行，将「排版管理」移到「首页装修」下
# 用法：bash deploy/run_move_layout_to_devise.sh
# 或从本机：ssh root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/run_move_layout_to_devise.sh"
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/opt/crmeb-prod}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SQL_FILE="${SCRIPT_DIR}/move_layout_to_devise.sql"

for envf in "${PROJECT_DIR}/.env" "${PROJECT_DIR}/backend_src/.env"; do
  if [[ -f "${envf}" ]]; then
    while IFS= read -r line; do
      [[ "$line" =~ ^[A-Za-z_][A-Za-z0-9_]*\s*=\s* ]] || continue
      k="${line%%=*}"; k="${k%"${k##*[! ]}"}"
      v="${line#*=}"; v="${v#"${v%%[! ]*}"}"; v="${v%"${v##*[! ]}"}"; v="${v%\"*}"; v="${v#*\"}"
      [[ -n "$k" ]] && export "$k=$v" 2>/dev/null || true
    done < <(grep -E '^[A-Za-z_][A-Za-z0-9_]*\s*=' "$envf" 2>/dev/null || true)
  fi
done

MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-${MYSQL_PASSWORD:-${PASSWORD:-}}}"
MYSQL_DATABASE="${MYSQL_DATABASE:-${DATABASE:-}}"

if [[ -z "${MYSQL_ROOT_PASSWORD}" || -z "${MYSQL_DATABASE}" ]]; then
  echo "请设置 MYSQL_ROOT_PASSWORD 和 MYSQL_DATABASE 环境变量"
  echo "或确保 .env 中存在 MYSQL_ROOT_PASSWORD、MYSQL_DATABASE（或 PASSWORD、DATABASE）"
  exit 1
fi

MYSQL_CONTAINER=$(docker ps --format '{{.Names}}' | grep -i mysql | head -1)
[[ -z "$MYSQL_CONTAINER" ]] && MYSQL_CONTAINER="crmeb-mysql"

echo "==> 将「排版管理」移到「首页装修」下 (容器: $MYSQL_CONTAINER)"
docker exec -i "$MYSQL_CONTAINER" mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" "${MYSQL_DATABASE}" < "${SQL_FILE}"
echo "==> 完成。请刷新后台，装修 → 首页装修 → 排版管理"
