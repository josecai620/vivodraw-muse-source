-- Seed v3 product categories for storefront and admin product maintenance.
-- Safe default: review with the SELECT first, then run in an approved deploy window.
-- mall_type is a bitmask: 1=regular, 2=points, 4=blind box. 7 means visible in all three lanes.

SET NAMES utf8mb4;
SET @now := UNIX_TIMESTAMP();

SELECT
  `id`,
  `pid`,
  `cate_name`,
  `cate_name_en`,
  `mall_type`,
  `is_show`,
  `sort`
FROM `eb_store_category`
WHERE `cate_name_en` IN (
  'Beauty & Self-care',
  'Cute Desk / Home Lifestyle',
  'Game Gear',
  'Premium Tech',
  'Toys / Collectibles',
  'Outdoor / Travel'
)
   OR `cate_name` IN ('美妆护理', '桌面生活', '游戏装备', '高级数码', '玩具收藏', '户外旅行');

INSERT INTO `eb_store_category` (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`)
SELECT 0, '美妆护理', 'Beauty & Self-care', '', 960, 1, @now, '', 7
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_store_category`
  WHERE `cate_name_en` = 'Beauty & Self-care' OR `cate_name` = '美妆护理'
);

UPDATE `eb_store_category`
SET `pid` = 0,
    `cate_name` = '美妆护理',
    `cate_name_en` = 'Beauty & Self-care',
    `sort` = 960,
    `is_show` = 1,
    `mall_type` = 7
WHERE `cate_name_en` = 'Beauty & Self-care' OR `cate_name` = '美妆护理';

INSERT INTO `eb_store_category` (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`)
SELECT 0, '桌面生活', 'Cute Desk / Home Lifestyle', '', 950, 1, @now, '', 7
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_store_category`
  WHERE `cate_name_en` = 'Cute Desk / Home Lifestyle' OR `cate_name` = '桌面生活'
);

UPDATE `eb_store_category`
SET `pid` = 0,
    `cate_name` = '桌面生活',
    `cate_name_en` = 'Cute Desk / Home Lifestyle',
    `sort` = 950,
    `is_show` = 1,
    `mall_type` = 7
WHERE `cate_name_en` = 'Cute Desk / Home Lifestyle' OR `cate_name` = '桌面生活';

INSERT INTO `eb_store_category` (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`)
SELECT 0, '游戏装备', 'Game Gear', '', 940, 1, @now, '', 7
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_store_category`
  WHERE `cate_name_en` = 'Game Gear' OR `cate_name` = '游戏装备'
);

UPDATE `eb_store_category`
SET `pid` = 0,
    `cate_name` = '游戏装备',
    `cate_name_en` = 'Game Gear',
    `sort` = 940,
    `is_show` = 1,
    `mall_type` = 7
WHERE `cate_name_en` = 'Game Gear' OR `cate_name` = '游戏装备';

INSERT INTO `eb_store_category` (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`)
SELECT 0, '高级数码', 'Premium Tech', '', 930, 1, @now, '', 7
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_store_category`
  WHERE `cate_name_en` = 'Premium Tech' OR `cate_name` = '高级数码'
);

UPDATE `eb_store_category`
SET `pid` = 0,
    `cate_name` = '高级数码',
    `cate_name_en` = 'Premium Tech',
    `sort` = 930,
    `is_show` = 1,
    `mall_type` = 7
WHERE `cate_name_en` = 'Premium Tech' OR `cate_name` = '高级数码';

INSERT INTO `eb_store_category` (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`)
SELECT 0, '玩具收藏', 'Toys / Collectibles', '', 920, 1, @now, '', 7
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_store_category`
  WHERE `cate_name_en` = 'Toys / Collectibles' OR `cate_name` = '玩具收藏'
);

UPDATE `eb_store_category`
SET `pid` = 0,
    `cate_name` = '玩具收藏',
    `cate_name_en` = 'Toys / Collectibles',
    `sort` = 920,
    `is_show` = 1,
    `mall_type` = 7
WHERE `cate_name_en` = 'Toys / Collectibles' OR `cate_name` = '玩具收藏';

INSERT INTO `eb_store_category` (`pid`, `cate_name`, `cate_name_en`, `pic`, `sort`, `is_show`, `add_time`, `big_pic`, `mall_type`)
SELECT 0, '户外旅行', 'Outdoor / Travel', '', 910, 1, @now, '', 7
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_store_category`
  WHERE `cate_name_en` = 'Outdoor / Travel' OR `cate_name` = '户外旅行'
);

UPDATE `eb_store_category`
SET `pid` = 0,
    `cate_name` = '户外旅行',
    `cate_name_en` = 'Outdoor / Travel',
    `sort` = 910,
    `is_show` = 1,
    `mall_type` = 7
WHERE `cate_name_en` = 'Outdoor / Travel' OR `cate_name` = '户外旅行';

SELECT
  `id`,
  `pid`,
  `cate_name`,
  `cate_name_en`,
  `mall_type`,
  `is_show`,
  `sort`
FROM `eb_store_category`
WHERE `cate_name_en` IN (
  'Beauty & Self-care',
  'Cute Desk / Home Lifestyle',
  'Game Gear',
  'Premium Tech',
  'Toys / Collectibles',
  'Outdoor / Travel'
)
ORDER BY `sort` DESC, `id` DESC;
