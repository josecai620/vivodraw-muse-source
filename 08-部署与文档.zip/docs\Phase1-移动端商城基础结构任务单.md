# Phase 1 移动端商城基础结构任务单

> 阶段：Phase 1
> 时间：2026-05-17 起
> 范围：只做前端基础结构，不做后端

---

## 一、阶段目标

建立移动端商城的基础体验骨架，让用户：

1. 快速理解商城价值
2. 快速进入商品
3. 快速识别活动入口
4. 快速完成加购 / 购买
5. 在不混乱的前提下继续停留

---

## 二、本阶段只做什么

- Design System
- Bottom Navigation
- 首页结构
- 商品卡片系统
- 按钮系统
- 弹窗系统
- 页面布局规范
- 首屏性能预算

---

## 三、本阶段不做什么

- 不改后端接口
- 不做复杂盲盒动画
- 不做复杂积分规则
- 不做复杂拼购逻辑
- 不做大规模目录搬迁
- 不做全站视觉重刷

---

## 四、Phase 1 核心交付物

## 1. 首页结构定稿

必须产出：

- 首屏模块顺序
- 二屏活动分层
- 推荐流插入规则
- 每日任务位置

## 2. 底部导航定稿

建议版本：

- Home
- Browse
- Activity
- Cart
- Profile

## 3. Design System v1

必须定稿：

- Color tokens
- Font scale
- Button system
- Card system
- Modal system
- Spacing system
- Motion system
- Product card system

## 4. 性能预算 v1

必须定稿：

- 首屏内容预算
- 图片预算
- 列表预算
- 动画预算

---

## 五、现有代码映射

## 可复用基础

- 首页入口：`mobile-app/app/(tabs)/index.tsx`
- Tabs：`mobile-app/app/(tabs)/_layout.tsx`
- 首页 block：`mobile-app/components/home-layout/*`
- 主题 token：`mobile-app/constants/theme.ts`
- 按钮：`mobile-app/components/ui/Button.tsx`
- 商品卡：`mobile-app/components/shared/ProductCard.tsx`
- 图片：`mobile-app/components/shared/CachedImage.tsx`

## 当前结构风险

- 首页入口文件已较重，含大量 inline 视觉和动效逻辑
- 首页 block 体系已存在，但模块命名与层级还不够产品化
- `theme.ts` 已有 token，但缺少正式 spec 文档和组件映射表
- tabs 已存在隐藏 `points` 入口，说明导航结构还未真正收口

---

## 六、Phase 1 推荐 skill 组合

本阶段默认这样配 skill：

- 沟通汇报：`caveman`
- 结构分析：`graphify`
- UI / UX 质量约束：`impeccable`
- 设计资产 / 原型：`opendesign`
- 竞品设计拆解：`extract-design`
- 浏览器点击验收：`browser-harness`
- 视频能力：`video-use` 暂不进入 Phase 1 主链路

### Phase 1 使用原则

- 先 `graphify` 看结构，再决定目录和组件边界
- 先受 `impeccable` 约束，再出首页和组件规范
- 需要参考外部站点时，先用 `extract-design`
- 需要做设计稿或交互原型时，再走 `opendesign`
- 页面改完后，用 `browser-harness` 验首屏、点击路径、滚动体验

---

## 七、Agent 第一轮任务

## 1. Mobile UX Agent

### 当前任务目标

先画清首页到购买的最短路径与停留路径。

### 本次只修改什么

- 只输出结构图和路径建议
- 不改代码

### 不修改什么

- 不碰 API
- 不碰 hooks
- 不碰动画实现

### 影响文件列表

- `mobile-app/app/(tabs)/index.tsx`
- `mobile-app/app/(tabs)/_layout.tsx`
- `mobile-app/app/product/[id].tsx`
- `mobile-app/app/checkout/index.tsx`

### 修改原因

没有信息架构，后续 UI 和代码都会返工。

### 风险点

- 活动入口过多会压垮首屏
- 商品入口过深会降低转化

### 测试方式

- 用手机视角模拟：首次进入首页，3 秒内能否知道卖什么、点哪里

### 下一步建议

- 确认首页模块顺序
- 确认底导结构
- 建议 skill：`impeccable` + `browser-harness`

## 2. UI Polish Agent

### 当前任务目标

统一商城高级感与可爱感，不让活动页显得廉价。

### 本次只修改什么

- 只定义视觉规范与组件等级
- 不直接改业务页

### 不修改什么

- 不碰接口
- 不碰产品逻辑

### 影响文件列表

- `mobile-app/constants/theme.ts`
- `mobile-app/components/ui/Button.tsx`
- `mobile-app/components/ui/Card.tsx`
- `mobile-app/components/shared/ProductCard.tsx`
- `mobile-app/components/shared/SectionHeader.tsx`

### 修改原因

当前基础组件已存在，应该升格为统一规范入口。

### 风险点

- 只追求可爱会掉价
- 只追求高级会失去刺激感

### 测试方式

- 对照 3 类页面：首页、商品卡、活动入口，看是否像同一产品

### 下一步建议

- 先定 hero、button、product card 三件套
- 建议 skill：`impeccable`，必要时加 `opendesign` / `extract-design`

## 3. Frontend Architecture Agent

### 当前任务目标

定义 Phase 1 可执行的渐进式结构，不搞一次性大迁移。

### 本次只修改什么

- 只出目录、边界、分层文档
- 不大规模搬代码

### 不修改什么

- 不重写旧页面
- 不调整业务流程

### 影响文件列表

- `mobile-app/app/`
- `mobile-app/components/`
- `mobile-app/hooks/`
- `mobile-app/lib/api/`
- `mobile-app/store/`

### 修改原因

没有边界，首页、活动、商品、任务会继续搅在一起。

### 风险点

- 过度设计目录会拖慢开发
- 一次性迁移会和活跃分支冲突

### 测试方式

- 看新 feature 是否能用同一套边界落位，不需要再争论放哪

### 下一步建议

- 先出 `features/` 与 `design/` 目标结构
- 建议 skill：`graphify`

## 4. Performance Agent

### 当前任务目标

为首页和商品流建立性能预算，压住动效冲动。

### 本次只修改什么

- 只输出预算与策略
- 不删除核心模块

### 不修改什么

- 不碰业务逻辑
- 不删转化入口

### 影响文件列表

- `mobile-app/app/(tabs)/index.tsx`
- `mobile-app/components/shared/CachedImage.tsx`
- `mobile-app/components/home-layout/HlProductList.tsx`
- `mobile-app/components/box/vfx/*`

### 修改原因

商城前端一旦首页视觉过重，移动端体验会直接崩。

### 风险点

- 为性能过度砍视觉
- 为视觉忽略低端机

### 测试方式

- 手机视口滚动检查
- 首屏首图加载检查
- 连续滑动掉帧观察

### 下一步建议

- 先定义 hero 动画上限
- 先定义商品图尺寸与格式策略
- 建议 skill：`browser-harness`，必要时加 `graphify`

## 5. Ecommerce Frontend Agent

### 当前任务目标

明确商品浏览到下单的前端流程与字段需求。

### 本次只修改什么

- 只定义页面字段和用户流程
- 不改后端接口

### 不修改什么

- 不碰数据库
- 不改支付后端

### 影响文件列表

- `mobile-app/app/(tabs)/categories.tsx`
- `mobile-app/app/product/[id].tsx`
- `mobile-app/app/(tabs)/cart.tsx`
- `mobile-app/app/checkout/index.tsx`
- `mobile-app/components/shared/ProductCard.tsx`

### 修改原因

没有字段模型，商品卡和详情页会一直反复改。

### 风险点

- 商品卡信息过多，影响扫描
- 商品详情信息过少，影响信任

### 测试方式

- 从首页点进商品，是否能无疑问完成加购

### 下一步建议

- 先定商品卡最小字段集
- 再定详情页模块顺序
- 建议 skill：`impeccable` + `graphify`

## 6. Analytics Frontend Agent

### 当前任务目标

先建立最小埋点集合，服务后续优化。

### 本次只修改什么

- 只出事件表和命名规范
- 不接复杂分析系统

### 不修改什么

- 不影响渲染性能
- 不在所有组件里乱加埋点

### 影响文件列表

- `mobile-app/app/(tabs)/index.tsx`
- `mobile-app/app/product/[id].tsx`
- `mobile-app/app/(tabs)/cart.tsx`
- `mobile-app/app/checkout/index.tsx`

### 修改原因

没有数据，后面无法判断哪个模块带转化、哪个模块只是热闹。

### 风险点

- 埋点过多拖慢页面
- 事件命名混乱难以复用

### 测试方式

- 检查是否能覆盖：首页曝光、商品点击、加购、结算、停留

### 下一步建议

- 先做关键路径事件，不做全量埋点
- 建议 skill：`browser-harness`

---

## 八、Phase 1 验收清单

满足以下条件，才可进入 Phase 2：

- 已确认首页模块顺序
- 已确认底部导航结构
- 已确认 product card 统一样式与字段位
- 已确认 button / modal / card 基础规范
- 已确认首页性能预算
- 已确认活动入口层级，不再堆首屏
- 已确认哪些文件属于保护区
- 已确认关键页面能用 `browser-harness` 走通真实点击路径
- 已确认结构方案不是拍脑袋，必要处已用 `graphify` 做过关系盘点

---

## 九、保护区

本阶段禁止误伤：

- `mobile-app/constants/api.ts`
- `mobile-app/lib/api/points.ts`
- `mobile-app/hooks/usePoints.ts`
- `mobile-app/lib/api/box.ts`
- `mobile-app/hooks/useBox.ts`
- `mobile-app/hooks/index.ts`
- `mobile-app/app/points/`
- `mobile-app/app/box/`
- `game/`

---

## 十、Phase 1 结束口径

本阶段结束不看“功能多不多”，只看：

1. 基础体验是否成立
2. 首页是否更像高端游戏化商城，而不是普通促销页
3. 商品路径是否更短
4. 视觉是否统一
5. 性能是否可控

一句话：

> Phase 1 目标不是热闹，是把商城移动端骨架做成可扩展、可转化、可继续打磨的底座。
