#!/usr/bin/env bash
# 云购 T11/T10 建表执行脚本（需用户明确批准后再运行；须先执行过 云购T09执行建表.sh）
# 用法：ssh -p 49375 root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/云购T11执行建表.sh"
# 行为：备份 kaijiang_log / user 表结构 → 执行 deploy/云购T11建表-需批准后执行.sql → 核对 → 清应用缓存。
# 不碰 .env、上传文件、数据库其他表；机器人与调控默认关闭，需后台再开。

set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
SQL_FILE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/云购T11建表-需批准后执行.sql"
[[ -f "$SQL_FILE" ]] || { echo "找不到 SQL 文件：$SQL_FILE"; exit 1; }

ENV_FILE="${PROJECT_DIR}/backend_src/.env"
read_env() { grep -E "^\s*$1\s*=" "$ENV_FILE" 2>/dev/null | head -1 | sed 's/^[^=]*=\s*//; s/^["'"'"']//; s/["'"'"']\s*$//; s/\s*$//'; }
DB_HOST="$(read_env HOSTNAME)"; DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="$(read_env HOSTPORT)"; DB_PORT="${DB_PORT:-3306}"
DB_NAME="$(read_env DATABASE)"
DB_USER="$(read_env USERNAME)"
DB_PASS="$(read_env PASSWORD)"
[[ -n "$DB_NAME" && -n "$DB_USER" ]] || { echo "读取 backend_src/.env 数据库配置失败"; exit 1; }

BACKUP_DIR="${PROJECT_DIR}/db_backup"
mkdir -p "$BACKUP_DIR"
STAMP="$(date +%Y%m%d-%H%M%S)"

run_mysql() {
  MYSQL_PWD="$DB_PASS" mysql -u"$DB_USER" -h"$DB_HOST" -P"$DB_PORT" --default-character-set=utf8mb4 "$DB_NAME" "$@"
}
command -v mysql >/dev/null 2>&1 || { echo "本机没有 mysql 客户端；请手动执行 SQL"; exit 1; }

echo "==> 前置检查：T09 七张表必须已存在"
T09_COUNT="$(run_mysql -N -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name IN ('eb_wallet_request','eb_cloud_buy_request','eb_cloud_buy_code_pool','eb_lucky_value_log','eb_draw_snapshot','eb_draw_snapshot_input','eb_store_integral_cart')")"
[[ "$T09_COUNT" == "7" ]] || { echo "T09 表只有 ${T09_COUNT}/7，请先执行 deploy/云购T09执行建表.sh"; exit 1; }

echo "==> 备份 kaijiang_log / user 表结构到 ${BACKUP_DIR}/云购T11前-表结构-${STAMP}.sql"
if command -v mysqldump >/dev/null 2>&1; then
  MYSQL_PWD="$DB_PASS" mysqldump -u"$DB_USER" -h"$DB_HOST" -P"$DB_PORT" --no-data \
    "$DB_NAME" eb_store_product_kaijiang_log eb_user \
    > "${BACKUP_DIR}/云购T11前-表结构-${STAMP}.sql"
fi

echo "==> 执行 ${SQL_FILE}"
run_mysql < "$SQL_FILE"

echo "==> 核对五张新表"
run_mysql -N -e "SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name IN ('eb_robot_account','eb_robot_pad_config','eb_robot_pad_rule','eb_robot_pad_log','eb_draw_control') ORDER BY table_name"
echo "==> 核对 kaijiang_log 补列"
run_mysql -N -e "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='eb_store_product_kaijiang_log' AND COLUMN_NAME IN ('unique','log_unique_id','huanqu_num','zhongjiang_time','order_no','shijian_sum','snapshot_id') ORDER BY COLUMN_NAME"

echo "==> 清应用缓存"
docker exec crmeb-php-fpm sh -c 'cd /var/www/backend && php think clear' 2>/dev/null || true
echo "==> 完成。机器人/调控默认关闭；开奖与验算接口 60 秒内自动切到快照路径。"
echo "    建议 crontab：* * * * * docker exec crmeb-php-fpm sh -c 'cd /var/www/backend && php think yunmall:tick' >/dev/null 2>&1"
