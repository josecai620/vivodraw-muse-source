-- Rollback for database optimization phase 6 indexes.
--
-- DEPRECATED:
-- This historical rollback references stale reveal-log table names and can fail
-- after partially dropping indexes. Use the guarded current rollback instead:
--   deploy/db_repair_20260615_rollback_approval_required.sql
SIGNAL SQLSTATE '45000'
  SET MESSAGE_TEXT = 'Deprecated script: use deploy/db_repair_20260615_rollback_approval_required.sql';
--
-- IMPORTANT:
-- 1. Run only if the added indexes cause an operational problem.
-- 2. Run during low traffic.
-- 3. Take a verified backup first.

ALTER TABLE `eb_store_integral_product_huanqu_log_unique`
  DROP INDEX `idx_hq_unique_draw_lookup`,
  DROP INDEX `idx_hq_unique_huanqu_isset`,
  ALGORITHM=INPLACE,
  LOCK=NONE;

ALTER TABLE `eb_store_integral_product_huanqu_log`
  DROP INDEX `idx_hq_log_product_bianhao_id`,
  DROP INDEX `idx_hq_log_uid_boxcate_id`,
  ALGORITHM=INPLACE,
  LOCK=NONE;

ALTER TABLE `eb_store_integral_product_kaijiang_log`
  DROP INDEX `idx_kaijiang_product_bianhao`,
  DROP INDEX `idx_kaijiang_status_time_id`,
  ALGORITHM=INPLACE,
  LOCK=NONE;

ALTER TABLE `eb_user_box`
  DROP INDEX `idx_user_box_uid_product_status_id`,
  DROP INDEX `idx_user_box_uid_cate_status_product`,
  DROP INDEX `idx_user_box_order_id`,
  DROP INDEX `idx_user_box_huanqu_id`,
  ALGORITHM=INPLACE,
  LOCK=NONE;

ALTER TABLE `eb_box_order`
  DROP INDEX `idx_box_order_uid_id`,
  DROP INDEX `idx_box_order_order_sn`,
  DROP INDEX `idx_box_order_pay_status_id`,
  ALGORITHM=INPLACE,
  LOCK=NONE;

ANALYZE TABLE
  `eb_store_integral_product_huanqu_log_unique`,
  `eb_store_integral_product_huanqu_log`,
  `eb_store_integral_product_kaijiang_log`,
  `eb_user_box`,
  `eb_box_order`;
