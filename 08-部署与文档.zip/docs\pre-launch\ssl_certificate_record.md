# SSL 证书记录

## vivodraw.com

- 域名：`vivodraw.com`、`www.vivodraw.com`
- 证书：Let's Encrypt
- 签发时间：2026-05-15
- 到期日：2026-08-13
- 服务器：`8.166.115.27`
- 证书路径：`/etc/letsencrypt/live/vivodraw.com/fullchain.pem`
- 私钥路径：`/etc/letsencrypt/live/vivodraw.com/privkey.pem`
- 自动续期：已启用 `certbot.timer`

## 检查命令

```bash
bash deploy/remote_exec.sh "certbot certificates"
bash deploy/remote_exec.sh "certbot renew --dry-run"
curl -Iv https://vivodraw.com/
```

## 提醒

到期前 30 天检查续期状态。当前建议检查日：`2026-07-14`。
