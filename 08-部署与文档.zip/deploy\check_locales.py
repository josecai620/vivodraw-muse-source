import json, sys
for f in [r'D:\eccomall\mobile-app\lib\i18n\locales\en.json',
          r'D:\eccomall\mobile-app\lib\i18n\locales\zh-TW.json']:
    try:
        data = json.load(open(f, encoding='utf-8'))
        print(f, 'OK, top keys:', len(data))
    except Exception as e:
        print(f, 'BAD:', e)
