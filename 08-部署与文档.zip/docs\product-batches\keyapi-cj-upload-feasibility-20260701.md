# KeyAPI + CJ 商品采集上传可行性 - 2026-07-01

结论：可以做成半自动链路，但当前不能直接全自动上传并发布。安全版本是：KeyAPI 找热销信号，CJ 找可履约商品，生成待审核草稿，默认 `is_show=0`，人工确认图片、成本、库存后再上架。

## 当前验证

| 环节 | 状态 | 证据 |
| --- | --- | --- |
| KeyAPI token | 可用 | macOS Keychain `keyapi-token` 存在；实际请求 TikTok Shop / Google Shopping 返回 `code=0` |
| KeyAPI TikTok Shop | 可用 | `GET /v1/tiktok/product/list/analytics` 返回 10 个 US 热销商品 |
| KeyAPI Google Shopping | 可用 | `portable handheld fan` 返回 40 个 US shopping 结果 |
| Amazon Best Sellers | 不稳定 | `category=beauty` 本次返回空，不作为本轮依据 |
| CJ API key | 可用但未写入线上配置 | 线上 `cj_api_key` 当前为空；本机历史记录找到一个 CJ API key，已通过 `authentication/getAccessToken` 验证成功；未写入 Git/文档/线上 DB |
| CJ 商品匹配 | 可做 | 已用 CJ `product/listV2` + `product/query` 匹配 6 个候选，输出 `docs/product-batches/keyapi-cj-hot-products-dryrun-20260701.csv` |
| Vivodraw 自动上传 | 有门禁 | `product:import-drafts` 支持 CSV dry-run / draft import；默认不发布 |

## 本轮候选 CSV

文件：`docs/product-batches/keyapi-cj-hot-products-dryrun-20260701.csv`

| 商品 | 分类 | 价格 | 风险 |
| --- | --- | --- | --- |
| Spray Cooling Desk Fan | Outdoor / Travel | $49 | 季节品；避免碰瓷 Dyson / Shark |
| Pocket Turbo Handheld Fan | Outdoor / Travel | $39 | 当前 CJ 库存较低，只适合小批测试 |
| 59-Piece Precision Screwdriver Set | Game Gear | $39 | 相对稳，非消耗品 |
| Electric Makeup Brush Cleaner | Beauty & Self-care | $34 | 只能写工具清洁，不写功效医疗话术 |
| LED Vanity Desk Mirror | Beauty & Self-care | $79 | 客单较高，执行前要复核运费/图片裁切 |
| Travel Makeup Organizer Insert | Cute Desk / Home Lifestyle | $29 | 低价配件，适合积分/盲盒补货 |

## 本轮验证

- CJ `authentication/getAccessToken` 成功，`product/listV2` 和 `product/query` 均返回有效商品数据。
- CSV 本地解析通过：6 行，`source_link`、图片、分类、价格、库存字段完整。
- 6 个主图 URL 全部 `200`，6 个 CJ source page 全部 `200`。
- 线上分类匹配成功：`Beauty & Self-care`、`Cute Desk / Home Lifestyle`、`Game Gear`、`Outdoor / Travel`。
- 线上重复源链接查询无结果，说明这批 `source_link` 当前未在商品表中存在。
- `php think product:import-drafts ...` dry-run 被当前 PHP CLI 的 Redis 扩展/驱动配置挡住，报错 `not support: redis`；未执行 `--execute`，未写入商品。

## 热销信号

| 信号 | 数据 |
| --- | --- |
| TikTok Shop K-beauty stick / serum | 7 天销量约 24k-80k，评分 4.3-4.7，评论数 7k-34k |
| TikTok Shop hydration sticks | 7 天销量约 21k，低价复购，但属于可食用/健康品，合规风险高 |
| TikTok Shop mini recovery massager | 7 天销量约 21k，客单价约 $75，需安全/售后审核 |
| Google Shopping portable handheld fan | Walmart / Target / Muji 等有 $4.88-$19.90 价格带，夏季需求明显 |

## CJ 相关候选

| 优先级 | VivoDraw 候选 | CJ 匹配 | 当前判断 |
| --- | --- | --- | --- |
| P1 | Portable Handheld Mist Fan | https://cjdropshipping.com/product/portable-handheld-spray-fan-4-speed-water-spray-mist-fan-summer-cooling-artifact-usb-charging-summer-supplies-outdoor-mini-fan-p-2406110841391604400.html | 可进入候选；需要成本、库存、图片移动端检查 |
| P1 | USB Rechargeable Handheld Fan | https://cjdropshipping.com/product/usb-rechargeable-mini-portable-handheld-electric-fan-foldable-neck-hanging-outdoor-fan-adjustable-5-speed-powerful-air-cooler-p-1527129857384263680.html | 可进入候选；匹配 Google fan 热销信号 |
| P2 | Precision Screwdriver Set | https://www.cjdropshipping.com/product/115-in-1-precision-screwdriver-set--super-durable-mini-professional-magnetic-repair-tool-kit-small-screwdriver-for-phone-computer-watch-laptop-macbook-eyeglass-electronic-p-1832684738768162816.html | 可进入候选；非消耗品，适合 Game Gear / Premium Tech |
| P2 | Makeup Storage Box With LED Mirror | https://cjdropshipping.com/product/makeup-storage-box-with-led-light-mirror-portable-travel-makeup-cosmetics-storage-box-touch-light-storage-organizer-p-1729064891924885504.html | 可进入候选；避开品牌 K-beauty 侵权，转为 beauty 工具 |
| P2 | Portable Electric Makeup Brush Cleaner | https://cjdropshipping.com/product/women-eye-shadow-brush-cleaning-tool-portable-electric-makeup-brush-cleaner-machine-with-usb-charging-automatic-cosmetic-brush-p-1638751740415717376.html | 可进入候选；匹配 beauty/self-care，但要看图片质感 |
| Reject | Branded Dyson / Shark fan | Google Shopping 有需求 | 不做，除非授权经销；否则价格透明 + IP 风险 |
| Reject | Medicube / Dr.Melaxin 同款复制 | TikTok 热销强 | 不复制品牌 listing；只能找无品牌替代品 |
| Reject | Hydration / supplement sticks | TikTok 热销强 | 食品/健康品合规风险高，当前不建议上传 |

## 可执行上传路径

1. KeyAPI 每日/每周拉取 TikTok Shop US 和 Google Shopping 热销关键词。
2. 把关键词映射成 CJ 搜索词：如 `handheld fan`、`precision screwdriver`、`makeup organizer`。
3. 有 CJ API key 时，用 `product/listV2` 按 `keyWord`、`countryCode=US`、价格、库存筛选。
4. 线上配置仍为空时，不依赖后台自动取 CJ 详情；候选 CSV 必须直接带 CJ 图片 URL。
5. 生成 `docs/product-batches/*.csv`，默认 `trend_status=watchlist` 或 `pricing_status=needs_cost_check`。
6. 图片、成本、库存、移动端展示都过后，才改成 `ready` + `image_status=pass`。
7. 执行 `php think product:import-drafts <csv>` dry-run。
8. 你二次确认后，才允许 `--execute` 创建后台草稿；默认 `is_show=0`。
9. 前台检查通过后，再单独批准发布。

## 不能跳过的门禁

- 不能用 KeyAPI / TikTok / Google / Amazon 图片直接上前台。
- 不能复制品牌商品名、品牌图、品牌功效话术。
- 不能上传食品、补剂、医疗/美容功效强声明商品，除非有供应商资质和合规文案。
- 不能用已停用的 `/openapi/product/import_from_cj` 当稳定生产接口。
- 不能在没有 CJ API key 的情况下承诺稳定库存、运费、US 仓。

## 下一步

建议先做一个 `3-5` 个商品的小批次，只创建草稿、不发布：

1. Handheld fan
2. Precision screwdriver set
3. Makeup storage / LED mirror box
4. Makeup brush cleaner
5. Optional desk/home organizer

需要正式自动化时，建议把 CJ API key 补到后台 `cj_api_key`；否则可继续用本机临时 key 生成候选 CSV，但后台命令不能自动补详情。
