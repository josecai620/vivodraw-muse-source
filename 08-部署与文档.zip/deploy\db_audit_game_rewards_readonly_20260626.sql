-- Read-only audit for farm/mine real-service launch safety.
-- Usage:
--   mysql manghehoutai_qhe < deploy/db_audit_game_rewards_readonly_20260626.sql
--
-- This script must stay SELECT-only. It does not modify data or schema.

SELECT 'runtime' AS section;
SELECT
  DATABASE() AS database_name,
  VERSION() AS mysql_version,
  @@sql_mode AS sql_mode,
  @@time_zone AS time_zone;

SELECT 'required_tables' AS section;
SELECT
  required.table_name,
  CASE WHEN actual.table_name IS NULL THEN 'MISSING' ELSE 'OK' END AS status,
  actual.engine,
  actual.table_rows
FROM (
  SELECT 'eb_user' AS table_name UNION ALL
  SELECT 'eb_user_bill' UNION ALL
  SELECT 'eb_system_config' UNION ALL
  SELECT 'eb_store_order' UNION ALL
  SELECT 'eb_game_farm_profile' UNION ALL
  SELECT 'eb_game_farm_plot' UNION ALL
  SELECT 'eb_game_farm_log' UNION ALL
  SELECT 'eb_game_mine_profile' UNION ALL
  SELECT 'eb_game_mine_node' UNION ALL
  SELECT 'eb_game_mine_inventory' UNION ALL
  SELECT 'eb_game_mine_lab_recipe' UNION ALL
  SELECT 'eb_game_mine_worker' UNION ALL
  SELECT 'eb_game_mine_log'
) required
LEFT JOIN information_schema.tables actual
  ON actual.table_schema = DATABASE()
 AND actual.table_name = required.table_name
ORDER BY required.table_name;

SELECT 'required_unique_indexes' AS section;
SELECT
  required.table_name,
  required.index_name,
  CASE WHEN actual.index_name IS NULL THEN 'MISSING' ELSE 'OK' END AS status
FROM (
  SELECT 'eb_game_farm_profile' AS table_name, 'uid' AS index_name UNION ALL
  SELECT 'eb_game_farm_plot', 'uid_plot_no' UNION ALL
  SELECT 'eb_game_farm_log', 'request_hash' UNION ALL
  SELECT 'eb_game_mine_profile', 'uniq_uid' UNION ALL
  SELECT 'eb_game_mine_node', 'uniq_uid_plot' UNION ALL
  SELECT 'eb_game_mine_inventory', 'uniq_uid_item' UNION ALL
  SELECT 'eb_game_mine_lab_recipe', 'uniq_uid_recipe' UNION ALL
  SELECT 'eb_game_mine_worker', 'uniq_uid_worker' UNION ALL
  SELECT 'eb_game_mine_log', 'uniq_request_hash'
) required
LEFT JOIN (
  SELECT DISTINCT table_name, index_name
  FROM information_schema.statistics
  WHERE table_schema = DATABASE()
    AND non_unique = 0
) actual
  ON actual.table_name = required.table_name
 AND actual.index_name = required.index_name
ORDER BY required.table_name, required.index_name;

SELECT 'live_switches_and_reward_caps' AS section;
SELECT
  required.menu_name,
  COALESCE(config.value, '<missing; code default applies>') AS value,
  CASE
    WHEN required.menu_name IN ('game_farm_live_enabled', 'game_mine_live_enabled')
      THEN 'must be 0 until release owner approves live service'
    WHEN required.menu_name IN ('game_farm_test_enabled', 'game_mine_test_enabled')
      THEN '0 by default; 1 only for scoped internal real-data test'
    WHEN required.menu_name IN ('game_farm_test_uids', 'game_mine_test_uids')
      THEN 'comma-separated internal tester uid allowlist; empty means no tester'
    WHEN required.menu_name = 'reward_coin_daily_earn_cap'
      THEN 'code clamps maximum to 50'
    WHEN required.menu_name = 'reward_coin_single_earn_cap'
      THEN 'code clamps maximum to 50'
    WHEN required.menu_name = 'reward_coin_exchange_rate'
      THEN 'code minimum is 10 coins per point'
    ELSE ''
  END AS expected
FROM (
  SELECT 'game_farm_live_enabled' AS menu_name UNION ALL
  SELECT 'game_mine_live_enabled' UNION ALL
  SELECT 'game_farm_test_enabled' UNION ALL
  SELECT 'game_farm_test_uids' UNION ALL
  SELECT 'game_mine_test_enabled' UNION ALL
  SELECT 'game_mine_test_uids' UNION ALL
  SELECT 'reward_coin_exchange_rate' UNION ALL
  SELECT 'reward_coin_daily_earn_cap' UNION ALL
  SELECT 'reward_coin_single_earn_cap'
) required
LEFT JOIN eb_system_config config
  ON config.menu_name = required.menu_name
ORDER BY required.menu_name;

SELECT 'direct_integral_game_reward_leaks_last_14d' AS section;
SELECT
  type,
  COUNT(*) AS bill_count,
  SUM(number) AS leaked_integral
FROM eb_user_bill
WHERE category = 'integral'
  AND pm = 1
  AND status = 1
  AND type IN (
    'farm_harvest',
    'farm_steal',
    'farm_task',
    'farm_mall_reward',
    'mine_collect',
    'mine_worker',
    'mine_friend'
  )
  AND add_time >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 14 DAY))
GROUP BY type
ORDER BY leaked_integral DESC;

SELECT 'reward_coin_game_rewards_last_14d' AS section;
SELECT
  type,
  COUNT(*) AS bill_count,
  SUM(number) AS reward_coins
FROM eb_user_bill
WHERE category = 'reward_coin'
  AND pm = 1
  AND status = 1
  AND type IN (
    'farm_harvest',
    'farm_steal',
    'farm_task',
    'farm_mall_reward',
    'mine_collect',
    'mine_worker',
    'mine_friend',
    'pet_daily_gift',
    'task_reward'
  )
  AND add_time >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 14 DAY))
GROUP BY type
ORDER BY reward_coins DESC;

SELECT 'today_reward_coin_cap_overages' AS section;
SELECT
  uid,
  SUM(number) AS reward_coins_today
FROM eb_user_bill
WHERE category = 'reward_coin'
  AND pm = 1
  AND status = 1
  AND add_time >= UNIX_TIMESTAMP(CURDATE())
GROUP BY uid
HAVING SUM(number) > 50
ORDER BY reward_coins_today DESC
LIMIT 50;

SELECT 'farm_duplicate_request_hashes' AS section;
SET @has_farm_log := (
  SELECT COUNT(*)
  FROM information_schema.tables
  WHERE table_schema = DATABASE()
    AND table_name = 'eb_game_farm_log'
);
SET @sql := IF(
  @has_farm_log > 0,
  'SELECT request_hash, COUNT(*) AS duplicate_count, MIN(created_at) AS first_seen, MAX(created_at) AS last_seen FROM eb_game_farm_log WHERE request_hash <> '''' GROUP BY request_hash HAVING COUNT(*) > 1 ORDER BY duplicate_count DESC LIMIT 20',
  'SELECT ''MISSING eb_game_farm_log'' AS request_hash, 0 AS duplicate_count, NULL AS first_seen, NULL AS last_seen'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT 'mine_duplicate_request_hashes' AS section;
SET @has_mine_log := (
  SELECT COUNT(*)
  FROM information_schema.tables
  WHERE table_schema = DATABASE()
    AND table_name = 'eb_game_mine_log'
);
SET @sql := IF(
  @has_mine_log > 0,
  'SELECT request_hash, COUNT(*) AS duplicate_count, MIN(created_at) AS first_seen, MAX(created_at) AS last_seen FROM eb_game_mine_log WHERE request_hash <> '''' GROUP BY request_hash HAVING COUNT(*) > 1 ORDER BY duplicate_count DESC LIMIT 20',
  'SELECT ''MISSING eb_game_mine_log'' AS request_hash, 0 AS duplicate_count, NULL AS first_seen, NULL AS last_seen'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT 'farm_today_reward_log_totals' AS section;
SET @sql := IF(
  @has_farm_log > 0,
  'SELECT uid, SUM(points_delta) AS reward_coins_today FROM eb_game_farm_log WHERE action IN (''harvest'', ''harvest_all'', ''steal'', ''claim_task'', ''purchase_mall_reward'') AND points_delta > 0 AND created_at >= UNIX_TIMESTAMP(CURDATE()) GROUP BY uid HAVING SUM(points_delta) > 50 ORDER BY reward_coins_today DESC LIMIT 50',
  'SELECT 0 AS uid, 0 AS reward_coins_today, ''MISSING eb_game_farm_log'' AS status'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT 'mine_today_reward_log_totals' AS section;
SET @sql := IF(
  @has_mine_log > 0,
  'SELECT uid, SUM(points_delta) AS reward_coins_today FROM eb_game_mine_log WHERE action IN (''collect'', ''collect_all'', ''worker_recall'', ''friend_assist'') AND points_delta > 0 AND created_at >= UNIX_TIMESTAMP(CURDATE()) GROUP BY uid HAVING SUM(points_delta) > 50 ORDER BY reward_coins_today DESC LIMIT 50',
  'SELECT 0 AS uid, 0 AS reward_coins_today, ''MISSING eb_game_mine_log'' AS status'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT 'farm_internal_test_logs_today' AS section;
SET @sql := IF(
  @has_farm_log > 0,
  'SELECT uid, COUNT(*) AS log_count, SUM(points_delta) AS points_delta_sum, MIN(created_at) AS first_seen, MAX(created_at) AS last_seen FROM eb_game_farm_log WHERE payload_json LIKE ''%"internalTestMode":true%'' AND created_at >= UNIX_TIMESTAMP(CURDATE()) GROUP BY uid ORDER BY log_count DESC',
  'SELECT 0 AS uid, 0 AS log_count, 0 AS points_delta_sum, NULL AS first_seen, NULL AS last_seen, ''MISSING eb_game_farm_log'' AS status'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SELECT 'mine_internal_test_logs_today' AS section;
SET @sql := IF(
  @has_mine_log > 0,
  'SELECT uid, COUNT(*) AS log_count, SUM(points_delta) AS points_delta_sum, MIN(created_at) AS first_seen, MAX(created_at) AS last_seen FROM eb_game_mine_log WHERE payload_json LIKE ''%"internalTestMode":true%'' AND created_at >= UNIX_TIMESTAMP(CURDATE()) GROUP BY uid ORDER BY log_count DESC',
  'SELECT 0 AS uid, 0 AS log_count, 0 AS points_delta_sum, NULL AS first_seen, NULL AS last_seen, ''MISSING eb_game_mine_log'' AS status'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
