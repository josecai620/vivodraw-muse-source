-- 云购 T11（机器人垫购 + 开奖调控）+ T10（开奖落地）建表 SQL
-- 出处：yunmall-hybrid/modules/robot-pad/design.md、modules/draw/design.md、CURSOR-实现-T09T10T11三件套.md
-- 需用户明确批准后再在生产库执行；执行前请先备份。依赖：先执行 云购T09建表-需批准后执行.sql。
-- 执行方式：ssh -p 49375 root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/云购T11执行建表.sh"
-- 说明：全部为新建表 / 加列 / 加默认行，不删不改现有数据。机器人与调控默认关闭（robot_pad_config.enabled=0, control_enabled=0）。

-- ---------------------------------------------------------------------------
-- 机器人账户池（对齐 参考实现 autobuy_member + member.auto_user=1）
-- 机器人是真实 eb_user 行（user_type='robot'），钱包/买份/发码与真人同一通道
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `eb_robot_account` (
  `uid` INT UNSIGNED NOT NULL COMMENT 'eb_user.uid，user_type=robot',
  `status` TINYINT NOT NULL DEFAULT 1 COMMENT '1 可用 / 0 停用',
  `source` VARCHAR(16) NOT NULL DEFAULT 'admin' COMMENT 'admin / legacy',
  `legacy_jiqiren_id` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '镜像到 eb_user_jiqiren.id（=uid），供旧展示代码按 is_jiqiren 查昵称头像',
  `buy_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `shares_total` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `topup_total` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '累计补给积分',
  `last_buy_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `note` VARCHAR(255) NOT NULL DEFAULT '',
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='云购机器人账户池';

-- ---------------------------------------------------------------------------
-- 全局配置（单行 id=1）；默认全部关闭
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `eb_robot_pad_config` (
  `id` TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `enabled` TINYINT NOT NULL DEFAULT 0 COMMENT '垫购总开关，默认关',
  `max_buys_per_tick` SMALLINT UNSIGNED NOT NULL DEFAULT 5 COMMENT '每次 tick 最多买几笔（含包尾）',
  `topup_enabled` TINYINT NOT NULL DEFAULT 1 COMMENT '机器人余额不足自动补给（只对机器人账户，写 user_bill 流水）',
  `topup_points` INT UNSIGNED NOT NULL DEFAULT 2000 COMMENT '单次补给积分',
  `topup_daily_cap` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '全站每日补给上限，0 不限',
  `control_enabled` TINYINT NOT NULL DEFAULT 0 COMMENT '开奖调控总开关，默认关',
  `control_policy` VARCHAR(16) NOT NULL DEFAULT 'manual' COMMENT 'manual 只执行后台布控 / robot_guard 对齐 参考实现 lottery_min_money：总人次≥阈值的期自动让机器人中',
  `control_min_total_shares` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'robot_guard 生效的最小总人次（参考实现 lottery_min_money 语义）',
  `control_finish_when_remaining_le` SMALLINT UNSIGNED NOT NULL DEFAULT 20 COMMENT '剩余 ≤ 此值且本期有布控时机器人立即包尾',
  `control_backdate_max_ms` INT UNSIGNED NOT NULL DEFAULT 20000 COMMENT '末笔时间键允许回拨的最大毫秒（且不早于窗口上一条记录）',
  `control_wait_max_ms` INT UNSIGNED NOT NULL DEFAULT 1500 COMMENT '末笔时间键允许前等的最大毫秒（事务内 usleep）',
  `updated_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_by` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='云购机器人/调控全局配置';
INSERT IGNORE INTO `eb_robot_pad_config` (`id`, `enabled`, `control_enabled`, `updated_at`) VALUES (1, 0, 0, UNIX_TIMESTAMP());

-- ---------------------------------------------------------------------------
-- 规则池（参考实现 autobuy_config：账户范围 / 份数区间 / 商品集 / 多商品 / 启停
--         + Vivodraw Jiqiren：三段营业时段 / 间隔 min-max / 三段份数）
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `eb_robot_pad_rule` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL DEFAULT '',
  `enabled` TINYINT NOT NULL DEFAULT 0,
  `robot_uid_min` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '机器人 uid 范围；0-0 = 整个账户池',
  `robot_uid_max` INT UNSIGNED NOT NULL DEFAULT 0,
  `product_ids` TEXT COMMENT '逗号分隔 store_product.id；空 = 全部开放中的云购商品',
  `multi_product` TINYINT NOT NULL DEFAULT 0 COMMENT '1 每次对多件商品各买一笔（参考实现 m_shop）',
  `max_products_per_run` SMALLINT UNSIGNED NOT NULL DEFAULT 3,
  `interval_min_sec` INT UNSIGNED NOT NULL DEFAULT 60,
  `interval_max_sec` INT UNSIGNED NOT NULL DEFAULT 300,
  `seg1_start` TINYINT NOT NULL DEFAULT 0 COMMENT '营业时段 1 起始小时(0-23)，-1 关闭',
  `seg1_end` TINYINT NOT NULL DEFAULT 23,
  `seg2_start` TINYINT NOT NULL DEFAULT -1,
  `seg2_end` TINYINT NOT NULL DEFAULT -1,
  `seg3_start` TINYINT NOT NULL DEFAULT -1,
  `seg3_end` TINYINT NOT NULL DEFAULT -1,
  `tier1_min` SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  `tier1_max` SMALLINT UNSIGNED NOT NULL DEFAULT 5,
  `tier1_weight` TINYINT UNSIGNED NOT NULL DEFAULT 50,
  `tier2_min` SMALLINT UNSIGNED NOT NULL DEFAULT 5,
  `tier2_max` SMALLINT UNSIGNED NOT NULL DEFAULT 20,
  `tier2_weight` TINYINT UNSIGNED NOT NULL DEFAULT 30,
  `tier3_min` SMALLINT UNSIGNED NOT NULL DEFAULT 20,
  `tier3_max` SMALLINT UNSIGNED NOT NULL DEFAULT 50,
  `tier3_weight` TINYINT UNSIGNED NOT NULL DEFAULT 20,
  `avoid_last_n` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '剩余 ≤ N 时普通垫购跳过（布控包尾不受此限）',
  `next_run_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `last_run_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `run_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_enabled_next` (`enabled`, `next_run_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='云购机器人垫购规则池';

-- ---------------------------------------------------------------------------
-- 垫购审计：每次尝试一行（买到 / 剔除 / 出错 / 跳过 / 补给）
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `eb_robot_pad_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `rule_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `control_id` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '包尾对应的 draw_control.id',
  `uid` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '机器人 uid',
  `product_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `period_no` INT UNSIGNED NOT NULL DEFAULT 0,
  `period_id` VARCHAR(64) NOT NULL DEFAULT '',
  `kind` VARCHAR(16) NOT NULL DEFAULT 'pad' COMMENT 'pad 普通垫购 / finish 布控包尾 / topup 补给',
  `shares_requested` INT UNSIGNED NOT NULL DEFAULT 0,
  `shares` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '实际买到',
  `points` INT UNSIGNED NOT NULL DEFAULT 0,
  `request_id` VARCHAR(64) NOT NULL DEFAULT '',
  `result` VARCHAR(16) NOT NULL DEFAULT '' COMMENT 'accepted / dropped / error / skipped',
  `code` VARCHAR(64) NOT NULL DEFAULT '',
  `message` VARCHAR(255) NOT NULL DEFAULT '',
  `became_full` TINYINT NOT NULL DEFAULT 0,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_period` (`product_id`, `period_no`),
  KEY `idx_uid_time` (`uid`, `created_at`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='云购机器人垫购审计';

-- ---------------------------------------------------------------------------
-- 开奖调控（对齐 参考实现 calculate_code_v2/luck 的产品语义，但不改历史记录：
--   只决定机器人「包尾那一笔」的时间键，使公开公式算到目标码；快照即公示，前台验算对得上）
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `eb_draw_control` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `period_id` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '{product_id}-{bianhao}',
  `product_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `period_no` INT UNSIGNED NOT NULL DEFAULT 0,
  `policy` VARCHAR(16) NOT NULL DEFAULT 'robot' COMMENT 'robot 让机器人中 / human 让真人中 / target_uid 指定用户 / target_code 指定幸运码',
  `target_uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `target_code` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` VARCHAR(16) NOT NULL DEFAULT 'armed' COMMENT 'armed 待执行 / applied 已落码 / missed 真人先满员未执行 / unreachable 目标不可达按自然时间 / cancelled 已撤销',
  `source` VARCHAR(16) NOT NULL DEFAULT 'admin' COMMENT 'admin / robot_guard',
  `natural_code` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '若按自然时间会开出的码（审计）',
  `planned_at_ms` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `planned_time_key` CHAR(9) NOT NULL DEFAULT '',
  `planned_code` INT UNSIGNED NOT NULL DEFAULT 0,
  `candidates_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '可选目标码数',
  `applied_record_id` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '包尾 huanqu_log.id',
  `applied_uid` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '执行包尾的机器人',
  `operator_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `note` VARCHAR(255) NOT NULL DEFAULT '',
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_period` (`period_id`),
  KEY `idx_status` (`status`, `product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='云购开奖调控（一期一行）';

-- ---------------------------------------------------------------------------
-- 现役表补列（线上缺列导致现役 Kaijiang / 揭晓接口报错；均为加列带默认值，不改数据）
-- ---------------------------------------------------------------------------
-- store_product_kaijiang_log：开奖结果列
SET @db := DATABASE();
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_product_kaijiang_log' AND COLUMN_NAME='unique');
SET @sql := IF(@c = 0, "ALTER TABLE `eb_store_product_kaijiang_log` ADD COLUMN `unique` VARCHAR(20) NOT NULL DEFAULT '' COMMENT '中奖幸运码'", 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_product_kaijiang_log' AND COLUMN_NAME='log_unique_id');
SET @sql := IF(@c = 0, "ALTER TABLE `eb_store_product_kaijiang_log` ADD COLUMN `log_unique_id` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '中奖 huanqu_log_unique.id'", 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_product_kaijiang_log' AND COLUMN_NAME='huanqu_num');
SET @sql := IF(@c = 0, "ALTER TABLE `eb_store_product_kaijiang_log` ADD COLUMN `huanqu_num` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '中奖者本笔份数'", 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_product_kaijiang_log' AND COLUMN_NAME='zhongjiang_time');
SET @sql := IF(@c = 0, "ALTER TABLE `eb_store_product_kaijiang_log` ADD COLUMN `zhongjiang_time` INT UNSIGNED NOT NULL DEFAULT 0", 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_product_kaijiang_log' AND COLUMN_NAME='order_no');
SET @sql := IF(@c = 0, "ALTER TABLE `eb_store_product_kaijiang_log` ADD COLUMN `order_no` VARCHAR(32) NOT NULL DEFAULT ''", 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_product_kaijiang_log' AND COLUMN_NAME='shijian_sum');
SET @sql := IF(@c = 0, "ALTER TABLE `eb_store_product_kaijiang_log` ADD COLUMN `shijian_sum` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '快照 input_sum'", 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_product_kaijiang_log' AND COLUMN_NAME='snapshot_id');
SET @sql := IF(@c = 0, "ALTER TABLE `eb_store_product_kaijiang_log` ADD COLUMN `snapshot_id` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'draw_snapshot.id'", 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @c := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_product_kaijiang_log' AND INDEX_NAME='idx_product_bianhao');
SET @sql := IF(@c = 0, 'ALTER TABLE `eb_store_product_kaijiang_log` ADD INDEX `idx_product_bianhao` (`product_id`, `bianhao`)', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- user：中奖弹窗列（现役 get_tanchuang 读这两列；线上缺列）
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_user' AND COLUMN_NAME='kaijiang_id');
SET @sql := IF(@c = 0, 'ALTER TABLE `eb_user` ADD COLUMN `kaijiang_id` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT ''待弹窗的中奖记录 id''', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_user' AND COLUMN_NAME='is_tanchuang');
SET @sql := IF(@c = 0, 'ALTER TABLE `eb_user` ADD COLUMN `is_tanchuang` TINYINT NOT NULL DEFAULT 0', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_user' AND COLUMN_NAME='phone_city');
SET @sql := IF(@c = 0, 'ALTER TABLE `eb_user` ADD COLUMN `phone_city` VARCHAR(100) NOT NULL DEFAULT ''''', 'SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
