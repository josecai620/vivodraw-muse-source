# -*- coding: utf-8 -*-
import io, os, shutil

SRC = r'D:\eccomall\mobile-app-v3'
DST = r'D:\eccomall\mobile-app'

# 1) 素材 avatars + sheets（递归，sheets 下有子目录）
for sub in ['avatars', 'sheets']:
    s = os.path.join(SRC, 'assets', 'pets', sub)
    d = os.path.join(DST, 'assets', 'pets', sub)
    if os.path.isdir(d):
        shutil.rmtree(d)
    shutil.copytree(s, d)
    n = sum(len(files) for _, _, files in os.walk(d))
    print('assets/pets/%s %d' % (sub, n))

# 2) 纯逻辑 lib
for name in ['pet-animation-assets.ts', 'pet-animations.ts', 'pet-gift-tiers.ts', 'pet-unlock.ts', 'pets.ts']:
    data = io.open(os.path.join(SRC, 'lib', name), encoding='utf-8').read()
    io.open(os.path.join(DST, 'lib', name), 'w', encoding='utf-8', newline='\n').write(data)
    print('lib', name)

# 3) store/pet-theme
data = io.open(os.path.join(SRC, 'store', 'pet-theme.tsx'), encoding='utf-8').read()
io.open(os.path.join(DST, 'store', 'pet-theme.tsx'), 'w', encoding='utf-8', newline='\n').write(data)
print('store pet-theme')

# 4) 组件（跳过 FloatingDeskPet 全局悬浮宠）
comp_src = os.path.join(SRC, 'components', 'pets')
comp_dst = os.path.join(DST, 'components', 'pets')
os.makedirs(comp_dst, exist_ok=True)
comps = ['PixelDeskPetStage.tsx', 'FXLayer.tsx', 'SpriteSheetPlayer.tsx',
         'PixelDeskPetSprite.tsx', 'PetStateMachine.tsx', 'PetActionPreviewPanel.tsx']
for name in comps:
    data = io.open(os.path.join(comp_src, name), encoding='utf-8').read()
    data = data.replace('import { theme } from "@/constants/theme";', 'import { theme } from "./petTheme";')
    io.open(os.path.join(comp_dst, name), 'w', encoding='utf-8', newline='\n').write(data)
    print('comp', name)

# 5) 本地 theme 兼容垫片
shim = '''// 桌宠组件从 v3 移植，保留其 theme 取值方式，颜色对齐方向 C / teal 体系
export const theme = {
  colors: {
    accent: "#04A8AE",
    accentDeep: "#07858C",
    accentSoft: "#ECFBFB",
    amber: "#F59E0B",
    hairline: "rgba(12,31,31,0.08)",
    muted: "#787976",
    neon: "#33C6CC",
    nightPanel: "#0F2A2C",
    surface: "#FFFFFF",
    violet: "#8B5CF6",
  },
  radius: { pill: 999 },
  spacing: { xs: 4, md: 12 },
  typography: {
    family: { ui: "System" as const },
    size: { xs: 11, sm: 13, md: 15, lg: 18 },
  },
};
'''
io.open(os.path.join(comp_dst, 'petTheme.ts'), 'w', encoding='utf-8', newline='\n').write(shim)
print('shim petTheme')
