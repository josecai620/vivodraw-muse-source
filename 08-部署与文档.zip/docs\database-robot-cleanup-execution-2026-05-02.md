# 机器人/测试数据清理执行记录（2026-05-02）

对象：测试服务器 `8.166.115.27`，数据库 `manghehoutai_qhe`。

本次已按方案归档并删除 5 张业务表内 `is_jiqiren = 1` 的机器人/测试数据。非机器人数据保留。

## 执行前备份

全库备份：

- `db_backup/db_20260502_202714.sql.gz`
- 压缩包约 `168MB`
- 解压后约 `2,763,084,913` bytes
- `gzip -t` 通过
- dump 完成时间：`2026-05-02 20:29:04`

机器人数据归档：

- `db_backup/robot_cleanup/20260502_204752`
- 目录大小约 `175MB`
- `gzip -t db_backup/robot_cleanup/20260502_204752/*.sql.gz` 通过

归档行数：

| 表 | 归档行 |
| --- | ---: |
| `eb_store_integral_product_huanqu_log_unique` | 12,721,643 |
| `eb_store_integral_product_huanqu_log` | 609,513 |
| `eb_store_integral_product_kaijiang_log` | 45,835 |
| `eb_user_box` | 351,346 |
| `eb_box_order` | 206,153 |

## 删除结果

执行脚本：

- `deploy/db_cleanup_phase7_robot_data.sql`

服务器日志：

- `/tmp/db_cleanup_phase7_robot_data_20260502_210757.log`

执行时间：

- 开始：`2026-05-02 21:07:57`
- 完成：`2026-05-02 22:28:18`

删除行数：

| 表 | 删除行 |
| --- | ---: |
| `eb_store_integral_product_huanqu_log_unique` | 12,721,643 |
| `eb_store_integral_product_kaijiang_log` | 45,835 |
| `eb_user_box` | 351,346 |
| `eb_store_integral_product_huanqu_log` | 609,513 |
| `eb_box_order` | 206,153 |

删除后已执行 `ANALYZE TABLE`，5 张表返回 `OK`。

## 验证结果

只读验证脚本：

- `deploy/db_cleanup_phase7_verify.sql`

机器人行剩余：

| 表 | 剩余机器人行 |
| --- | ---: |
| `eb_store_integral_product_huanqu_log_unique` | 0 |
| `eb_store_integral_product_huanqu_log` | 0 |
| `eb_store_integral_product_kaijiang_log` | 0 |
| `eb_user_box` | 0 |
| `eb_box_order` | 0 |

非机器人行保留：

| 表 | 非机器人行 |
| --- | ---: |
| `eb_store_integral_product_huanqu_log_unique` | 822 |
| `eb_store_integral_product_huanqu_log` | 228 |
| `eb_store_integral_product_kaijiang_log` | 8 |
| `eb_user_box` | 846 |
| `eb_box_order` | 392 |

关联检查：

| 检查项 | 结果 |
| --- | ---: |
| `user_box_real_to_missing_order` | 0 |
| `huanqu_real_to_missing_order` | 0 |
| `unique_real_to_missing_huanqu` | 0 |
| `kaijiang_real_to_missing_huanqu` | 0 |
| `store_order_to_robot_user_box` | 0 |

线上验活：

- `frontend index`：HTTP 200
- `frontend entry`：HTTP 200
- `mobile api /api/category`：HTTP 200
- `legacy china entry disabled`：HTTP 410
- `admin login gate`：HTTP 200
- 核心容器可见

## 表空间说明

删除后 `information_schema.tables` 显示大表数据已变成表内可复用空间，例如：

| 表 | total_mb | free_mb |
| --- | ---: | ---: |
| `eb_store_integral_product_huanqu_log_unique` | 13.13 | 4,192.00 |
| `eb_store_integral_product_huanqu_log` | 3.16 | 234.00 |
| `eb_user_box` | 17.11 | 161.00 |
| `eb_box_order` | 16.16 | 51.00 |
| `eb_store_integral_product_kaijiang_log` | 0.09 | 20.00 |

这些空间目前可被 InnoDB 复用，但通常不会立即归还给操作系统。真正释放磁盘空间需要后续单独执行 `OPTIMIZE TABLE` 或重建表，建议另开维护窗口处理。
