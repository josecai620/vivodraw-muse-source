import re, os, glob
ROOT = r'D:\eccomall\mobile-app'
keys = """auth.loginHint auth.loginRequired backpack.emptyHint backpack.goExplore
collection.empty collection.emptyHint collection.openBoxes common.no common.yes
detail.each detail.openLabel detail.pityProgress exchange.accept exchange.cancelConfirm
exchange.confirmMsg exchange.confirmTitle exchange.createFirst exchange.decline
exchange.noMyListings exchange.noOffers exchange.statusActive exchange.statusCancelled
exchange.statusDone exchange.statusPending exchange.wantsToSwap freeDraw.alreadyDrawn
freeDraw.comeBackTomorrow freeDraw.dailyFree freeDraw.description freeDraw.drawNow
freeDraw.goToBackpack freeDraw.rareCongrats freeDraw.resetsDaily freeDraw.title
invite.claim invite.heroDesc invite.heroTitle invite.inviteN invite.invited invite.level
invite.notYet invite.paidUsers invite.rewards invite.shareMessage invite.shareNow
invite.shareTitle invite.title invite.yourCode wishlist.notifications""".split()
pat = re.compile(r't\(\s*["\`]([A-Za-z0-9_.]+)["\`]([^)]{0,120})')
seen = {}
for f in glob.glob(os.path.join(ROOT, 'app/box/**/*.tsx'), recursive=True):
    for i, line in enumerate(open(f, encoding='utf-8'), 1):
        for m in pat.finditer(line):
            k = m.group(1)
            if k in keys and k not in seen:
                seen[k] = '%s:%d %s' % (os.path.basename(f), i, line.strip()[:150])
for k in keys:
    print(seen.get(k, k + '  ## NOT FOUND'))
