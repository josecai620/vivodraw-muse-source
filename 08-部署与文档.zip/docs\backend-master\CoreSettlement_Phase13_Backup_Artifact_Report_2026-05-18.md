# CoreSettlement Phase 13 Backup Artifact Report 2026-05-18

## Current Task

Phase 13 只做 DB backup artifact creation and verification。

本轮未执行业务 SQL，未创建 CoreSettlement 表，未插入 config switch，未开启任何 switch，未修改生产 DB。

## Backup Command

Executed from repo root:

```bash
bash deploy/从服务器导出数据库.sh 8.166.115.27
```

Script behavior:

- reads target DB config from `/opt/crmeb-prod/backend_src/.env`
- runs `mysqldump --single-transaction --quick --no-tablespaces`
- writes remote temp file under `/tmp`
- downloads gzipped dump to local `db_backup/`
- removes remote temp file

## Target DB

- host: `8.166.115.27`
- app dir: `/opt/crmeb-prod`
- DB host: `127.0.0.1`
- DB port: `3306`
- DB name: `manghehoutai_qhe`
- DB user: `crmeb`
- MySQL version in dump header: `8.0.45-0ubuntu0.24.04.1`

## Backup Artifact

Local artifact:

- `/Users/joe/eccomall/db_backup/db_20260518_050233.sql.gz`

Verification:

```text
gzip -t: ok
compressed: 920809 bytes
uncompressed: 6437960 bytes
visible size: 899K
```

Header check:

```text
-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
-- Host: 127.0.0.1    Database: manghehoutai_qhe
-- Server version 8.0.45-0ubuntu0.24.04.1
```

Remote temp status:

```text
remote_tmp_removed
```

Git safety:

- `db_backup/` is ignored by `.gitignore`
- backup artifact was not staged
- backup artifact must never be committed

## Important Restore Warning

The backup is a full `mysqldump` artifact.

It contains normal restore statements such as `DROP TABLE IF EXISTS`.

This is acceptable for a backup artifact, but it is not an execution plan for CoreSettlement rollout.

Do not run this dump against production unless doing an explicitly approved full DB restore.

## Readiness Decision

Phase 13 backup artifact creation passed.

Execution remains **NO-GO** for CoreSettlement DB changes until a separate phase approves table and switch SQL.

Reasons:

- `eb_core_settlement_ledger` is still not created by this phase
- 5 CoreSettlement switch rows are still not inserted by this phase
- no switch has been opened
- no readonly re-check after table/switch creation exists because table/switch creation did not happen

## Next Execution Gate

Before any DB-changing CoreSettlement phase:

1. confirm this backup artifact path
2. confirm restore command or temp-DB restore test
3. run readonly checks again
4. create `eb_core_settlement_ledger` only from approved current writer schema
5. insert switch rows only with `value='0'`
6. keep all switches off
7. verify table columns, unique key, and switch defaults
8. stop

Do not activate any switch in the same phase as table creation.

## Forbidden Areas

Do not touch without explicit approval:

- `backend_src/app/controller/api/v1/manghe/MangheController.php`
- payment
- order
- real inventory deduction
- ledger history mutation
- switch activation
- server `.env`
- `game/*`
- `mobile-app/*`
- `mobile-app-v3/*`
- unrelated dirty worktree changes

## Next Task

Phase 14 can be table-and-switch SQL execution planning or execution, depending on approval level.

Safe recommended next phase:

1. verify backup artifact path still exists
2. run readonly pre-checks
3. execute only:
   - create `eb_core_settlement_ledger`
   - insert missing switch rows with `value='0'`
4. run readonly post-checks
5. keep every switch `0`
6. write Phase 14 report

## NEXT WINDOW HANDOFF PACKAGE

- Role: Backend Master Controller
- Phase: Phase 14 table and switch default-off readiness
- Completed: Phase 13 backup artifact created and verified
- Key Findings: backup artifact exists locally and passed `gzip -t`; remote temp dump removed; no DB schema/config change was made
- Key Files: this report, `docs/backend-master/CoreSettlement_Phase10_NoExecution_Migration_Readiness_2026-05-18.md`, `docs/backend-master/CoreSettlement_Phase12_Backup_Execution_Approval_Plan_2026-05-18.md`
- Backup Artifact: `/Users/joe/eccomall/db_backup/db_20260518_050233.sql.gz`
- Dirty Worktree Notes: unrelated game/mobile/v3/docs deletions remain; do not stage broad changes
- Forbidden Areas: payment/order/Manghe/switch activation/ledger mutation/game/mobile/v3
- Next Step: table + switch default-off phase only if approved
- Validation: gzip test, size check, header check, remote temp removed
- Risks: dump contains full restore statements; never run it as CoreSettlement rollout SQL
