# VivoDraw US Video UI Capture Log - 2026-06-21

## Scope

Review-only UI capture evidence for VQ-001 product discovery video.

No production SQL, payment, inventory, ledger, commission, wallet, DNS, or server config change was performed.

## Captures

Command:

```bash
bash deploy/ops/capture_us_video_ui_shots.sh
```

Latest output:

```text
/Users/joe/eccomall/.codex-artifacts/us-video-ui-captures/20260621-092512/
```

Files:

- `SC-007-ui.png`: homepage/product discovery surface.
- `SC-008-ui.png`: product detail route for `/product/1096`.
- `SC-009-trust.png`: support/trust surface.
- `metadata.json`: capture metadata with route titles and file sizes.

The captures are ignored by Git through `.codex-artifacts/` and are review-only until Public Entry Health passes.

## Brand Title Fix

During the first capture pass, browser titles still showed old `Eccomall` labels. That hurts US trust and makes video footage look like a rebranded shell, because yes, users notice the tab title when we least want them to.

Fix applied:

- `mobile-app-v3/app.json`: Expo app name changed from `Eccomall V3` to `VivoDraw`.
- `deploy/ops/check_us_trust_surface.sh`: now checks `mobile-app-v3/app.json` and blocks legacy `Eccomall` in user-facing v3 metadata/source.

Deploy performed:

```bash
VERIFY_URL=http://8.166.115.27 DEPLOY_SSH_PORT=2222 EXPO_PUBLIC_API_BASE_URL=http://8.166.115.27 bash deploy/deploy-frontend-v3.sh
```

Deploy evidence:

- Review-only public asset guard passed.
- `mobile-app-v3` built successfully.
- Remote v3 backup created under `/opt/crmeb-prod/frontend-v3-root/backup-before-v3-deploy-20260621092427`.
- v3 static output uploaded to `/opt/crmeb-prod/frontend-v3-root/current`.
- URL verification passed for `http://8.166.115.27`.

Browser runtime title evidence after deploy:

```text
http://8.166.115.27/ => 🐴 VivoDraw
http://8.166.115.27/product/1096 => 🐴 Product | VivoDraw
http://8.166.115.27/support => 🐴 VivoDraw
```

## Current Footage Caveats

- Captures are desktop viewport screenshots from browser-harness, not final 9:16 mobile video plates.
- Pet overlay appears in some frames; crop or hide it before final video if it distracts from product/trust proof.
- Public `vivodraw.com` remains blocked, so final public edit must not show `vivodraw.com` as a CTA until Public Entry Health passes.
- Product close-up clips still need rights-safe product footage or licensed stills.

## Next Capture Step

Capture mobile-viewport versions of SC-007, SC-008, and SC-009 once a reliable mobile viewport automation path is available, or crop these review shots into storyboard references only.
