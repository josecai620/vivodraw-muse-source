# -*- coding: utf-8 -*-
import io, os, shutil

SRC = r'D:\eccomall\mobile-app-v3'
DST = r'D:\eccomall\mobile-app'

# 素材
s = os.path.join(SRC, 'assets', '极简农场')
d = os.path.join(DST, 'assets', '极简农场')
if os.path.isdir(d):
    shutil.rmtree(d)
shutil.copytree(s, d)
print('assets copied:', len(os.listdir(d)))

# 视觉组件 → components/farm-demo（../../assets 深度不变）
fd = os.path.join(DST, 'components', 'farm-demo')
os.makedirs(fd, exist_ok=True)
for name in ['农场视觉层.tsx', '等轴舞台.tsx']:
    data = io.open(os.path.join(SRC, 'features', '极简农场', name), encoding='utf-8').read()
    if name == '农场视觉层.tsx':
        # 方向 C：去掉 emoji 表情
        data = data.replace('<Text style={styles.avatarFace}>🙂</Text>', '<Text style={styles.avatarFace}></Text>')
    io.open(os.path.join(fd, name), 'w', encoding='utf-8', newline='\n').write(data)
    print('visual', name)

# 试玩收成 → lib/game/practiceHarvest.ts（中英双语）
logic = io.open(os.path.join(SRC, 'features', '极简农场', '试玩收成.ts'), encoding='utf-8').read()
io.open(os.path.join(DST, 'lib', 'game', 'practiceHarvest.ts'), 'w', encoding='utf-8', newline='\n').write(logic)
print('logic practiceHarvest')
