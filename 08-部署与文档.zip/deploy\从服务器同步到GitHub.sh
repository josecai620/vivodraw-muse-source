#!/usr/bin/env bash
# 把服务器上的系统同步到 GitHub 仓库
# 流程：服务器 → 本地 → 提交 → 推送
# 用法: bash deploy/从服务器同步到GitHub.sh [服务器IP]
# 示例: bash deploy/从服务器同步到GitHub.sh 186.241.72.176
set -euo pipefail

SERVER_IP="${1:-186.241.72.176}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOCAL_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
BRANCH="$(git -C "${LOCAL_ROOT}" branch --show-current)"
: "${BRANCH:?当前不在分支上，停止推送}"

cd "${LOCAL_ROOT}"

echo "==> 1/3 从服务器 ${SERVER_IP} 拉取代码到本地"
bash deploy/从服务器同步到本地.sh "${SERVER_IP}"

echo ""
echo "==> 2/3 提交变更"
git add -- \
  backend_src/ deploy/ admin.php docker-compose.yml migrations/20260516_consolidated_menu_fixes.sql run_fix_manghe_menus.sh \
  ':(exclude)backend_src/public/uploads/**' \
  ':(exclude)backend_src/runtime/**' \
  ':(exclude)backend_src/public/install/install.lock' 2>/dev/null || true

echo "==> 2.1 仓库卫生检查"
bash deploy/ops/check_git_hygiene.sh
bash deploy/ops/check_secret_leakage_safety.sh

if git diff --cached --quiet 2>/dev/null; then
  echo "    无变更，跳过提交"
else
  git commit -m "同步服务器 ${SERVER_IP} 最新代码"
fi

echo ""
echo "==> 3/3 推送到 GitHub"
bash deploy/ops/check_git_hygiene.sh
bash deploy/ops/check_secret_leakage_safety.sh
git push origin "${BRANCH}"

echo ""
echo "==> 完成：服务器系统已同步到 GitHub"
