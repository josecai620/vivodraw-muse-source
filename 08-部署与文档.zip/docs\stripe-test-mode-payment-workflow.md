# Stripe Test Mode Payment Workflow

This workflow keeps real card capture closed until the Stripe account is approved.

## Default State

- Backend order gateway is closed unless `pay_stripe_open=1` or local `PAY_STRIPE_OPEN=1`.
- Frontend card checkout is closed by default. Set `EXPO_PUBLIC_ENABLE_STRIPE_CHECKOUT=1` only after Stripe keys are ready.
- Stripe mode follows the secret key prefix: `sk_test_` uses test mode, `sk_live_` uses live mode.

## Test Mode Setup

Use test credentials only:

```bash
STRIPE_SECRET_KEY=sk_test_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
STRIPE_CURRENCY=usd
PAY_STRIPE_OPEN=1
EXPO_PUBLIC_ENABLE_STRIPE_CHECKOUT=1
```

For live payment testing, use the live key instead:

```bash
STRIPE_SECRET_KEY=sk_live_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
PAY_STRIPE_OPEN=1
```

Webhook endpoint:

```text
POST /api/pay/notify/stripe
```

Handled events:

```text
checkout.session.completed
payment_intent.succeeded
```

## Runtime Flow

1. Checkout preview reads cart, coupons, shipping, and totals.
2. Frontend calls `POST /api/order/create/:key` with `payType=stripe`.
3. Backend creates a Stripe Checkout Session and returns `checkoutUrl`.
4. User pays on Stripe-hosted checkout.
5. Stripe webhook verifies signature and marks the order paid through `StoreOrderSuccessServices::paySuccess`.

## Go-Live Gate

Before real payments:

- Stripe account approved.
- Live webhook configured in Stripe Dashboard.
- `STRIPE_SECRET_KEY=sk_live_xxx`.
- `STRIPE_WEBHOOK_SECRET=whsec_xxx` from the live endpoint.
- `pay_stripe_open=1`.
- Run one low-value real order, then verify order paid status, webhook log, points issuance, and procurement task creation.
