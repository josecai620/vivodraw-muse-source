# -*- coding: utf-8 -*-
from pathlib import Path
from PIL import Image, ImageDraw

out = Path(r"D:/eccomall/mobile-app/assets/icons") / "账户明细图标.png"
out.parent.mkdir(parents=True, exist_ok=True)

size = 256
img = Image.new("RGBA", (size, size), (255, 255, 255, 0))
d = ImageDraw.Draw(img)
teal = (4, 168, 174, 255)
white = (255, 255, 255, 255)
stroke = 22

d.rounded_rectangle([46, 36, 210, 222], radius=26, outline=teal, width=stroke)
d.rounded_rectangle([88, 18, 168, 58], radius=12, outline=teal, width=stroke)
d.rectangle([104, 40, 152, 58], fill=white)
for i, y in enumerate((86, 122, 158)):
    right = 176 if i < 2 else 148
    d.rounded_rectangle([76, y, right, y + 16], radius=8, fill=teal)
d.ellipse([148, 166, 224, 242], fill=teal)
d.ellipse([166, 184, 206, 224], fill=white)

img.save(out, "PNG")
names = [x.name for x in out.parent.iterdir()]
log = Path(r"D:/eccomall/deploy/_icon_out.txt")
log.write_text(f"saved={out.exists()} size={out.stat().st_size if out.exists() else 0}\nnames={names}\n", encoding="utf-8")
