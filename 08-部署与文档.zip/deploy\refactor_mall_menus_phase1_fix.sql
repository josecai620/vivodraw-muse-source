-- ===========================================================
-- 三商城独立栏目重构 · 第一阶段补丁
-- ===========================================================
-- 修复：把积分商城/盲盒商城/拼团抽奖子菜单 menu_path
-- 从原 path 切换到独立 path，让 vue-router 能识别正确的顶栏 header
--
-- 配套：前端新增 mallIntegral.js / mallManghe.js / mallLottery.js 路由模块
-- ===========================================================

SET NAMES utf8mb4;

-- ===== 积分商城 顶栏与子菜单（2300 系列）=====
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_integral/store_integral' WHERE `id` = 2300 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_integral/store_integral' WHERE `id` = 2301 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_integral/store_integral/create' WHERE `id` = 2302 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_integral/store_integral/order_list' WHERE `id` = 2303 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_integral/integral/system_config/3/11' WHERE `id` = 2304 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_integral/integral/signIn' WHERE `id` = 2305 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_integral/user_point/index' WHERE `id` = 2306 AND `is_del` = 0;

-- ===== 盲盒商城 顶栏与子菜单（2310 系列）=====
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_manghe/product_list?mall_type=2' WHERE `id` = 2310 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_manghe/product_list?mall_type=2' WHERE `id` = 2311 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_manghe/add_product' WHERE `id` = 2312 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_manghe/openbox_list' WHERE `id` = 2313 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_manghe/zhongjiangset' WHERE `id` = 2314 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_manghe/choujiang_list' WHERE `id` = 2315 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_manghe/jiqiren_list' WHERE `id` = 2316 AND `is_del` = 0;

-- ===== 拼团抽奖 顶栏与子菜单（2320 系列）=====
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_lottery/group_lottery/index' WHERE `id` = 2320 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_lottery/group_lottery/index' WHERE `id` = 2321 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_lottery/group_lottery/create' WHERE `id` = 2322 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_lottery/group_lottery/pink_list' WHERE `id` = 2323 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_lottery/group_lottery/cancel_review' WHERE `id` = 2324 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_lottery/group_lottery/robot_list' WHERE `id` = 2325 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_lottery/group_lottery/statistics' WHERE `id` = 2326 AND `is_del` = 0;
