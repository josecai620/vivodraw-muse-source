# -*- coding: utf-8 -*-
import re
import urllib.request

base = "https://vivodraw.com"
hdr = {"Cache-Control": "no-cache", "Pragma": "no-cache"}


def fetch(path, timeout=30):
    req = urllib.request.Request(base + path, headers=hdr)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read()


def head(path, timeout=20):
    req = urllib.request.Request(base + path, method="HEAD", headers=hdr)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, int(r.headers.get("Content-Length") or 0)


st, html_b = fetch("/profile/avatar-frames")
html = html_b.decode("utf-8", "replace")
print("PAGE", st, "v4rel", "20260919_093152" in html, "len", len(html))
entry = re.search(r"/_expo/static/js/web/entry-[a-f0-9]+\.js", html)
print("entry", entry.group(0) if entry else "MISSING")
if not entry:
    raise SystemExit(2)

chunk = "/_expo/static/js/web/avatar-frames-480dd3ccc4a846e6d48bfe9250e14a57.js?v=20260919_093152"
st, data = fetch(chunk)
text = data.decode("utf-8", "replace")
print("CHUNK", st, "bytes", len(data))
for n in [
    "useEffect",
    "累计实付",
    "Dream Return",
    "已锁定",
    "动态 SVGA",
    "自绘",
    "preloadAvatarFrameAssets",
    "试用会员赠送",
]:
    print(" ", n, n in text)

member = "/_expo/static/js/web/member-card-e21ae0c2f003d0367419255ca634feb8.js?v=20260919_093152"
st, data = fetch(member)
mtext = data.decode("utf-8", "replace")
print("MEMBER", st, "bytes", len(data), "回归梦境", "回归梦境" in mtext, "三生三世", "三生三世" in mtext)

for label, path in [
    ("svga-sansheng", "/assets/assets/member/%E4%B8%89%E7%94%9F%E4%B8%89%E4%B8%96.364e6d22528c195a272d57dd99f4d53a.svga"),
    ("svga-dream", "/assets/assets/member/%E5%9B%9E%E5%BD%92%E6%A2%A6%E5%A2%83.8c6ebabf19a6aa931dded55957676961.svga"),
]:
    try:
        st, size = head(path)
        print("ASSET", label, st, size)
    except Exception as e:
        print("ASSET_FAIL", label, e)
