# CoreSettlement Phase 23 Point Ledger Table Design 2026-05-18

## Current Task

Readonly table design draft for Point Gateway.

No SQL was executed.
No production deployment was executed.
No switch was activated.
Do not execute SQL.

## Draft Tables

```sql
CREATE TABLE IF NOT EXISTS `eb_core_point_transaction` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `scene` VARCHAR(64) NOT NULL DEFAULT '',
  `action` VARCHAR(32) NOT NULL DEFAULT '',
  `request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `target_request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `amount` INT NOT NULL DEFAULT 0,
  `direction` TINYINT NOT NULL DEFAULT 0,
  `status` VARCHAR(24) NOT NULL DEFAULT 'success',
  `error_code` VARCHAR(64) NOT NULL DEFAULT '',
  `meta_json` TEXT DEFAULT NULL,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_scene_request` (`scene`, `request_id`),
  KEY `idx_uid_time` (`uid`, `created_at`),
  KEY `idx_status_time` (`status`, `created_at`),
  KEY `idx_target` (`target_request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway canonical transaction ledger';

CREATE TABLE IF NOT EXISTS `eb_core_point_freeze` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `scene` VARCHAR(64) NOT NULL DEFAULT '',
  `freeze_request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `amount` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` VARCHAR(24) NOT NULL DEFAULT 'frozen',
  `expire_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_freeze_request` (`scene`, `freeze_request_id`),
  KEY `idx_uid_status` (`uid`, `status`),
  KEY `idx_expire` (`status`, `expire_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway frozen point records';

CREATE TABLE IF NOT EXISTS `eb_core_point_rollback_request` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `rollback_request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `target_request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `amount` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` VARCHAR(24) NOT NULL DEFAULT 'draft',
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_rollback_request` (`rollback_request_id`),
  UNIQUE KEY `uk_target_once` (`target_request_id`),
  KEY `idx_uid_status` (`uid`, `status`),
  KEY `idx_status_time` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway rollback approval requests';

CREATE TABLE IF NOT EXISTS `eb_core_point_expiry_batch` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `expire_batch` VARCHAR(96) NOT NULL DEFAULT '',
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `source_request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `amount` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` VARCHAR(24) NOT NULL DEFAULT 'pending',
  `expire_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_batch_source` (`expire_batch`, `uid`, `source_request_id`),
  KEY `idx_uid_status` (`uid`, `status`),
  KEY `idx_expire` (`status`, `expire_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway expiry batch items';

CREATE TABLE IF NOT EXISTS `eb_core_point_ai_operation_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `operator_type` VARCHAR(32) NOT NULL DEFAULT 'ai',
  `operator_id` VARCHAR(64) NOT NULL DEFAULT '',
  `operation` VARCHAR(64) NOT NULL DEFAULT '',
  `target_table` VARCHAR(64) NOT NULL DEFAULT '',
  `target_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `decision` VARCHAR(24) NOT NULL DEFAULT 'suggested',
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_target` (`target_table`, `target_id`),
  KEY `idx_uid_time` (`uid`, `created_at`),
  KEY `idx_status_time` (`decision`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway AI/admin operation audit log';
```

## Guard

This file is design only. It must not be copied into `deploy/` or executed without approval.
