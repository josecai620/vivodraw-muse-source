# -*- coding: utf-8 -*-
import os
import subprocess

key = os.path.expanduser(r"~\.ssh\vivodraw_windows_ed25519")
ssh = [
    "ssh", "-i", key, "-p", "49375",
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
    "-o", "ServerAliveInterval=15",
    "root@186.241.72.176",
]
scp_base = [
    "scp", "-O", "-i", key, "-P", "49375",
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
]
root = r"D:\eccomall"
files = [
    "backend_src/app/services/game/海底寻珠经营规则.php",
    "backend_src/app/services/game/海底寻珠服务.php",
    "backend_src/app/services/core/游戏补币服务.php",
    "backend_src/app/controller/api/v1/user/海底寻珠控制器.php",
]
staging = r"D:\eccomall\deploy\_t27-pearl-lf"
for rel in files:
    src = os.path.join(root, rel.replace("/", os.sep))
    dest = os.path.join(staging, rel.replace("/", os.sep))
    if not os.path.isfile(src):
        raise SystemExit("missing " + src)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    open(dest, "wb").write(open(src, "rb").read().replace(b"\r\n", b"\n"))

rel = " ".join(files)
backup = (
    "mkdir -p /opt/crmeb-prod/deploy_backups && cd /opt/crmeb-prod && "
    "tar --ignore-failed-read -czf "
    "deploy_backups/t27-pearl-backend-$(date +%Y%m%d-%H%M%S).tar.gz {rel} && "
    "echo BACKUP_OK"
).format(rel=rel)
print(subprocess.check_output(ssh + [backup], timeout=60).decode(errors="replace"), flush=True)
for f in files:
    local = os.path.join(staging, f.replace("/", os.sep))
    dest = "root@186.241.72.176:/opt/crmeb-prod/" + f
    print("scp", f, flush=True)
    rc = subprocess.call(scp_base + [local, dest])
    if rc != 0:
        raise SystemExit("scp failed {} rc={}".format(f, rc))
print("UPLOAD_OK", flush=True)
lint = [
    "/var/www/backend/app/services/game/海底寻珠经营规则.php",
    "/var/www/backend/app/services/game/海底寻珠服务.php",
    "/var/www/backend/app/services/core/游戏补币服务.php",
    "/var/www/backend/app/controller/api/v1/user/海底寻珠控制器.php",
]
check = " && ".join("docker exec crmeb-php-fpm php -l " + p for p in lint)
check += (
    " && rm -f /opt/crmeb-prod/backend_src/runtime/route_list.php"
    " && docker exec crmeb-php-fpm sh -c 'cd /var/www/backend && php think clear' || true"
    " && docker restart crmeb-php-fpm && echo RESTART_OK"
)
print(subprocess.check_output(ssh + [check], timeout=120).decode(errors="replace"), flush=True)
