# Windows 工作区更新与接手说明

**2026-09-17 现行入口：** 云端与新克隆以 GitHub `https://github.com/josecai620/eccomall` 的 `main` 为准；当前前台 `mobile-app/`（v4）。下文是 2026-09-14 从 Gitee / `mobile-app-v3` 接手 Windows 的历史步骤，不要覆盖现行入口。

---

更新日期：2026-09-14。本次目标是让 Windows Agent 获取这台 Mac 当时工作区的代码、开发文档和文字记录。

## 当时的同步入口（2026-09-14，历史）

- 仓库：`https://gitee.com/caiweizhou/eccomall.git`
- 工作分支：`codex/pet-world-v2`。
- 本次整理前 Mac 基线提交：`61a0a4747efd4d91adad47bb83edbcfa0ad4b27a`。
- 用户前台当时为 `mobile-app-v3/`；旧 `mobile-app/` 曾被删除，后又作为 v4 源码恢复，**现在不要按「已删除」处理**。
- 后端：`backend_src/`；后台源码：`backend_src/view/admin/`；游戏：`game/`。
- 开发资料：`docs/`、`.claude/memory/`、`审查记录/`；`promo/` 只保留指定格式的文字记录与制作脚本。
- 当时仅同步 Git，没有部署、运行数据库迁移或覆盖服务器文件。

## Windows 旧工作区更新：推荐旁边新建目录

旧工作区已落后数月，先完整保留它（包括未提交修改、.env 和本地素材），在它的父目录用 PowerShell 执行：

```powershell
git -c core.longpaths=true -c core.autocrlf=false clone --depth 1 --single-branch --branch codex/pet-world-v2 https://gitee.com/caiweizhou/eccomall.git eccomall-最新
if ($LASTEXITCODE -ne 0) { throw "克隆失败，请检查 Gitee 访问权限" }
Set-Location eccomall-最新
git config core.longpaths true
git config core.autocrlf false
git status --short --branch
git rev-parse HEAD
git rev-list --left-right --count HEAD...origin/codex/pet-world-v2
```

`core.autocrlf=false` 仅用于新克隆目录，保留源码换行，避免 Windows 自动转换导致 WSL 执行 Shell 脚本失败；不修改旧工作区或全局设置。

成功标准：当前分支为 `codex/pet-world-v2`、工作区干净、最后一条输出 `0 0`；完成后将编辑器工作区切换到新目录。新目录的提交号应与 Mac 本次交付的提交号相同。

`--depth 1 --single-branch` 用于只取最新版本，避免把历史提交里的图片视频一起下载。历史仍留在远端；以后取消浅克隆或拉旧分支会重新获取历史对象。若仍沿用旧目录，其 `.git` 中已有的旧媒体也不会自动消失。

不要对旧目录执行 `git reset --hard`、`git clean -fdx` 或全目录覆盖。若必须沿用原路径，先保留完整副本并关闭编辑器，再由用户决定目录替换；不能丢弃尚未核对的 Windows 独有修改。

后续在新目录更新（先保证工作区干净）：

```powershell
git status --short --branch
git pull --ff-only origin codex/pet-world-v2
```

本地有修改、分支不对或出现分叉时，先审查并保存差异，不强推、不自动丢弃。需要回查历史时再按需补取，避免无意下载旧媒体。

## 图片、视频和其他素材缺口

用户已明确：所有图片和视频，包括 Logo、图标、游戏贴图等运行资源，都不上传 Git；接受在 Windows 另行补齐。

本次也排除音频和三维制作素材。Mac 现有文件保留原位置；Git 最新版本停止跟踪这些资源。被移出的既有文件和校验值见 [媒体文件清单](跨机同步/需另行补齐的媒体文件清单.tsv)。清单描述打包时曾跟踪的文件，不是所有本机素材的总目录。

在补齐所需路径前，前台构建可能因缺少图标失败，游戏可能没有贴图或动效。不能把克隆成功说成完整应用可运行。需要资源时由用户另行传输到清单中的相对路径，`.gitignore` 会继续避免再次上传。

制作记录里的脚本保留其原始系统和工具依赖，部分使用 Mac 路径、Zsh 或本机媒体工具；纳入 Git 供接续参考，并不代表可以在 Windows 原样执行。

Git 不包含私钥、真实 .env、数据库数据、用户上传、构建缓存和安装包。登录权限与本地测试数据库需单独配置；不要把旧工作区整个 `.env` 或数据库直接覆盖到服务器。

## Agent 接手顺序

1. 读 `AGENTS.md`、`CLAUDE.md`、`DEPLOY-WORKFLOW.md`、`docs/网站开发工作流-架构师版.md`。
2. 读 `docs/上线前修复续接清单-20260914.md`、`docs/全项目测试报告-20260914.md`、`docs/三游戏积分购买与兑换任务记录-20260914.md`，必要时查看同目录 JSON 与 `审查记录/`。其中未完成、暂停、待验收事项继续保持原状态。
3. 当前前台是 `mobile-app/`（v4）。`mobile-app-v3/` 不要当默认改动入口。积分商城保护清单里的 `mobile-app/` 路径按现役 v4 理解。
4. 跨机器的目标核对技能使用 `docs/工作目标核对技能/SKILL.md`。Mac 绝对路径不可直接用于 Windows 或云端；视频等其他本机技能需要按实际任务另行配置，不能假称已安装。
5. 现行代码基线是 GitHub `main`。不要自动从服务器反向同步覆盖刚克隆的代码。云端不要 SSH。后续进入功能开发时，服务器与仓库不同先只读检查并确认归属。
6. 旧资料保留历史意义；与本说明冲突的旧仓库、服务器、分支、主前台目录不再作为操作入口。收到新任务再按当前授权执行，不因历史制作/迁移记录自动恢复付费生成或线上写入。

## 环境与服务器

- 前端依赖以 `mobile-app/package-lock.json` 和 `game/package-lock.json` 为准；当前 Expo SDK 54、React Native 0.81.5，Node 最低要求以仓库锁定依赖的 engines 字段为准，不照旧文档安装 Node 18。
- PHP 8.1 + ThinkPHP 6，Composer 依赖以 `backend_src/composer.lock` 为准。
- Windows 部署脚本建议在 WSL 中运行，准备 Bash、Git、OpenSSH、rsync 和对应运行时。
- 服务器：`root@186.241.72.176`，SSH 端口 `49375`；项目根目录 `/opt/crmeb-prod`。
- 线上商城 `https://vivodraw.com`；公司官网 `https://altanexgroup.vip`。
- 现役前台是 v4：源码 `mobile-app/`。`./deploy-frontend.sh` 是旧 v3 入口，不要当云端或现役发布命令。v4 发版见 `yunmall-hybrid/STATUS.md`。
- 后端发布入口 `bash deploy/update_online.sh 186.241.72.176`。只在有明确发布需求并完成相应检查时运行。

新电脑 SSH 公钥需另行授权；GitHub 与服务器登录权限分别配置，凭证放系统凭证管理器或本机私有配置，禁止写进文档、Git URL 或提交。云端 Agent 不要配置生产 SSH。
