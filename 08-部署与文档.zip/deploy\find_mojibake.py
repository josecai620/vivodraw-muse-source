# -*- coding: utf-8 -*-
import json, re, os
L = r'D:\eccomall\mobile-app\lib\i18n\locales'
cjk = re.compile(r'[　-鿿＀-￯]')
def walk(o, path=''):
    if isinstance(o, dict):
        for k, v in o.items():
            yield from walk(v, path + '.' + k)
    elif isinstance(o, str):
        if cjk.search(o):
            yield path, o
for f in ['en.json', 'zh-TW.json']:
    print('====', f)
    d = json.load(open(os.path.join(L, f), encoding='utf-8'))
    for p, s in walk(d):
        print(p, '=>', repr(s))
