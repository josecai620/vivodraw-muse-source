# 数据库索引执行记录（2026-05-02）

执行对象：测试服务器 `8.166.115.27`，数据库 `manghehoutai_qhe`。

本次只添加索引并刷新统计信息，没有修改业务字段、没有删除业务数据。

## 执行前

- 有效备份：`db_backup/db_20260502_182104_host.sql.gz`
- 备份校验：`gzip -t` 通过
- 目标索引：执行前均不存在
- 活跃 MySQL 查询：仅本次检查连接

## 执行内容

执行时间：2026-05-02 20:13:46 到 20:16:12（Asia/Shanghai）。

已添加索引：

- `eb_store_integral_product_huanqu_log_unique`
  - `idx_hq_unique_draw_lookup(product_id, bianhao, status, isset)`
  - `idx_hq_unique_huanqu_isset(huanqu_id, isset, is_jiqiren)`
- `eb_store_integral_product_huanqu_log`
  - `idx_hq_log_product_bianhao_id(product_id, bianhao, id)`
  - `idx_hq_log_uid_boxcate_id(uid, box_cate_id, id)`
- `eb_store_integral_product_kaijiang_log`
  - `idx_kaijiang_product_bianhao(product_id, bianhao)`
  - `idx_kaijiang_status_time_id(status, kaijiang_time, id)`
- `eb_user_box`
  - `idx_user_box_uid_product_status_id(uid, product_id, status, id)`
  - `idx_user_box_uid_cate_status_product(uid, cate_id, status, product_id)`
  - `idx_user_box_order_id(order_id)`
  - `idx_user_box_huanqu_id(huanqu_id)`
- `eb_box_order`
  - `idx_box_order_uid_id(uid, id)`
  - `idx_box_order_order_sn(order_sn)`
  - `idx_box_order_pay_status_id(pay_status, id)`

执行后已 `ANALYZE TABLE` 刷新统计信息，所有目标表返回 `OK`。

## 验证结果

核心 `EXPLAIN` 改善：

| 查询 | 执行前 | 执行后 |
| --- | --- | --- |
| 唯一号按 `product_id + bianhao + status + isset` | `index_merge` | `idx_hq_unique_draw_lookup` |
| 换取日志按 `product_id + bianhao order by id` | `index_merge + filesort` | `idx_hq_log_product_bianhao_id` |
| 开奖日志按 `product_id + bianhao` | 全表扫描约 45k 行 | `idx_kaijiang_product_bianhao` |
| 用户盲盒按 `uid + product_id + status` | 主键扫描过滤 | `idx_user_box_uid_product_status_id` |
| 用户盲盒按 `uid + cate_id + status group by product_id` | 全表扫描约 345k 行 | `idx_user_box_uid_cate_status_product` |
| 用户盲盒按 `order_id` | 全表扫描约 345k 行 | `idx_user_box_order_id` |
| 盲盒订单按 `uid order by id desc` | 主键反向扫描过滤 | `idx_box_order_uid_id` |
| 盲盒订单按 `order_sn` | 全表扫描约 203k 行 | `idx_box_order_order_sn` |

线上验活通过：

- 前台首页：HTTP 200
- 前台入口 JS：HTTP 200
- 移动端 `/api/category`：HTTP 200
- 中国旧支付入口：HTTP 410
- 后台登录门：HTTP 200
- 核心容器：可见

## 回滚

如索引导致异常，可在低峰期执行：

`deploy/db_optimize_phase6_drop_indexes.sql`
