from pathlib import Path
src = Path(r"D:\eccomall\deploy\v4-root-bundle.tar.gz")
out = Path(r"D:\eccomall\deploy\v4-chunks")
out.mkdir(exist_ok=True)
for old in out.glob("part-*"):
    old.unlink()
data = src.read_bytes()
n = 0
for i in range(0, len(data), 1_800_000):
    (out / f"part-{n:03d}").write_bytes(data[i : i + 1_800_000])
    n += 1
print(f"bytes={len(data)} parts={n}")
