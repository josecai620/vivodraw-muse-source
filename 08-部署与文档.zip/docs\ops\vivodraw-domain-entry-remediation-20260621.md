# VivoDraw Domain Entry Remediation - 2026-06-21

## Scope

Read-only remediation package for the public entry blocker.

No DNS change, Nginx/server config change, production SQL, deploy, payment, inventory, ledger, or wallet write was performed.

## Current Evidence

Command:

```bash
bash deploy/ops/vivodraw-ops-health.sh
```

Observed result after the DNS-over-HTTPS upgrade:

- PASS: `http://8.166.115.27/` returned HTTP `200`.
- PASS: `GET http://8.166.115.27/api/category` with `X-Client: mobile-app` returned `status=200` and real category data.
- PASS: `http://8.166.115.27/agent-admin/` returned HTTP `200`.
- PASS: Google DNS-over-HTTPS returned `vivodraw.com A 8.166.115.27`.
- PASS: Cloudflare DNS-over-HTTPS returned `vivodraw.com A 8.166.115.27`.
- FAIL: `Host: vivodraw.com` against `8.166.115.27` returned HTTP `403` via `Beaver`.
- FAIL: TLS/SNI path for `https://vivodraw.com/` returned HTTP `000`.
- WARN: local resolver returned `198.18.0.73`, likely workstation proxy/DNS behavior.
- WARN: visible MX/TXT readiness is not proven, so email lead capture is not launch-safe.

Additional confirmation on 2026-06-21:

```bash
curl --noproxy '*' -v --max-time 12 -H 'Host: vivodraw.com' http://8.166.115.27/codex-probe-raw
```

Result:

- HTTP `403 Forbidden`.
- Response header: `Server: Beaver`.
- Response title/body: `Non-compliance ICP Filing`.
- The block appears when the request uses `Host: vivodraw.com`; direct IP with `Host: 8.166.115.27` still returns the app.

## Conclusion

The storefront is alive by IP, and the public A record is likely already correct.

The current blocker is not "point the domain at the server" in the simple sense. It is now confirmed as an Alibaba Cloud ICP filing compliance block on the public domain path.

The server-local evidence still matters:

- Server-side Nginx serves `vivodraw.com`.
- Server-side HTTPS/SNI serves `vivodraw.com`.
- Public direct IP without the domain Host serves the app.
- Public request with `Host: vivodraw.com` returns Alibaba Cloud's ICP block page.

Blunt version: this is not an Expo, PHP, Nginx, or Let's Encrypt fix. Rewriting app code here is painting a locked door.

## Owner-Level Fix Paths

These actions require owner approval or account access. Codex should not execute them silently.

### Path A - Fast Path: Move Public Entry Outside Mainland China

Use this for US Stripe/PayPal review and US consumer launch.

Intent:

- Host `vivodraw.com` and `www.vivodraw.com` on non-mainland infrastructure, such as US/Hong Kong VPS, Vercel, Netlify, Cloudflare Pages + Worker/API proxy, or another offshore edge.
- Keep `https://vivodraw.com` as the customer/payment-review URL.
- Proxy or route API traffic to the existing backend only through a controlled HTTPS path.
- Avoid using a mainland-China origin with the public domain Host unless ICP filing is complete.

Why:

- Alibaba Cloud docs state mainland-China hosted websites require ICP filing, while non-mainland servers do not require ICP filing.
- This project targets US consumers and US payment review, so offshore public entry is the shortest operational path.

Prepared package:

```bash
cd /Users/joe/eccomall
bash deploy/offshore-entry/prepare-cloudflare-pages.sh
```

Upload directory:

```text
.codex-artifacts/vivodraw-cloudflare-pages
```

The package includes a Cloudflare Pages Worker that:

- Serves the Expo static frontend.
- Maps generated dynamic routes such as `/product/957` to Expo static HTML.
- Proxies `/api`, `/adminapi`, and uploaded asset paths to `http://8.166.115.27`.
- Rewrites origin IP links in JSON/text responses back to the public origin, so product images do not stay on `http://8.166.115.27` under an HTTPS page.

Rollback:

- Restore previous DNS records from provider history or screenshots.
- Re-run the public entry gates below.

### Path B - Slow Path: Complete ICP Filing For Mainland Hosting

Use only if the business intentionally wants to keep `vivodraw.com` hosted on Alibaba Cloud mainland infrastructure.

Check:

- ICP filing eligibility for the actual filing entity.
- Domain ownership and entity information.
- Alibaba Cloud ICP Filing console requirements.
- Whether a foreign company can complete the needed filing directly or needs a China-side filing entity/service path.

Tradeoff:

- This can take days to weeks.
- It may require entity/admin documents that Codex cannot submit for the owner.
- It is unnecessary for US Stripe/PayPal review if the public site is hosted outside mainland China.

Rollback:

- None for submitted regulatory filings except provider-side cancellation/modification workflow.

### Path C - Server/Nginx Virtual Host

Use only after confirming traffic reaches the server Nginx layer.

Current evidence already shows server-local Nginx is healthy. Do not start here unless a later gate proves the server config regressed.

Check:

```bash
nginx -T
```

Required intent:

- `server_name vivodraw.com www.vivodraw.com;`
- HTTP route serves the current frontend/public app.
- HTTPS route has a valid certificate for `vivodraw.com`.
- `/agent-admin/` remains protected and available.
- Existing `.env`, uploads, database, backups, and runtime files are untouched.

Rollback:

- Backup the active Nginx config before editing.
- Restore the backup and reload Nginx if validation fails.

### Path D - Mail Readiness

Use before any public CTA that says "email us" or collects leads.

Check or configure:

- MX record for the chosen mail provider.
- SPF TXT.
- DKIM TXT from the provider.
- DMARC TXT.
- A real receiving inbox, for example `support@vivodraw.com`.

Rollback:

- Restore previous DNS records from registrar/provider history.

## Approval Template

Use this before any account/server change:

```text
Approve public domain remediation?

Actions allowed:
- Inspect domain/edge/DNS/TLS config.
- Export or screenshot current config before change.
- Update domain binding, WAF/edge routing, TLS cert, or Nginx virtual host only if evidence confirms the target layer.
- Configure MX/SPF/DKIM/DMARC only if mail provider details are available.

Actions still forbidden:
- Production SQL/migration.
- Payment, inventory, ledger, wallet, commission writes.
- Force push or history rewrite.
- Broad deploy unrelated to domain entry.

Rollback:
- Restore exported/screenshot config or Nginx backup.
- Re-run `bash deploy/ops/vivodraw-ops-health.sh`.
```

## Post-Fix Verification

Run:

```bash
bash deploy/ops/check_vivodraw_domain_remote.sh
bash deploy/ops/vivodraw-ops-health.sh
bash deploy/ops/check_agent_growth_surface.sh
bash deploy/ops/check_us_trust_surface.sh
bash deploy/ops/vivodraw_daily_ops_report.sh
```

Public entry pass condition:

- IP storefront passes.
- Category API passes.
- `/agent-admin/` passes.
- `Host: vivodraw.com` no longer returns `403 Beaver`.
- TLS/SNI path returns HTTP `200`, `301`, or `302`.
- DNS-over-HTTPS includes `8.166.115.27`.

Launch traffic remains blocked until both public entry and agent growth surface gates pass, unless the owner explicitly approves a narrower launch.

## Read-Only Remote Diagnostic Script

Added script:

```bash
SERVER_IP=8.166.115.27 SSH_PORT=2222 DOMAIN=vivodraw.com bash deploy/ops/check_vivodraw_domain_remote.sh
```

Purpose:

- Confirm whether the production host itself serves `vivodraw.com` correctly.
- Collect filtered Nginx listen/server_name/certificate/proxy evidence.
- Collect certificate metadata without printing private key contents.
- Collect server-side DNS and listening-port evidence.

This script is intentionally read-only. If it shows local Host/TLS passing while external health still fails, the next likely layer is cloud edge, WAF, ICP/filing, provider gateway, or network ACL. If it shows local Host/TLS failing, fix Nginx/TLS locally first with backup and rollback.

Latest run:

```text
localhost HTTP with Host:vivodraw.com: HTTP 301
localhost HTTPS with SNI:vivodraw.com: HTTP 200
public IP HTTP with Host:vivodraw.com from server: HTTP 301
A: 8.166.115.27
Certificate: vivodraw.com / www.vivodraw.com, valid until 2026-08-13
Listening ports: 80, 443, 20199
```

Interpretation:

- Server-side Nginx and TLS for `vivodraw.com` are alive.
- External health still returns `403 Beaver` / TLS HTTP `000`.
- The remaining fault is therefore outside the local app/Nginx path: cloud edge, WAF, ICP/filing/provider gateway, upstream security policy, or network ACL.
