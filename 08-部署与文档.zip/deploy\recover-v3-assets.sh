#!/usr/bin/env bash
# De-hash static assets from deployed V3 build and tar them for local rebuild.
set -e
SRC=/opt/crmeb-prod/frontend-v3-root/current/assets/assets
rm -rf /tmp/v3assets && mkdir -p /tmp/v3assets
cp -a "$SRC/." /tmp/v3assets/
find /tmp/v3assets -type f | while read -r f; do
  d=$(dirname "$f")
  b=$(basename "$f")
  nb=$(printf "%s" "$b" | sed -E "s/\.[0-9a-f]{20,}(\.[^.]+)$/\1/")
  if [ "$b" != "$nb" ]; then mv "$f" "$d/$nb"; fi
done
rm -f /tmp/v3-assets-dehashed.tar.gz
tar -czf /tmp/v3-assets-dehashed.tar.gz -C /tmp/v3assets .
echo "files: $(find /tmp/v3assets -type f | wc -l)"
ls -la /tmp/v3-assets-dehashed.tar.gz
