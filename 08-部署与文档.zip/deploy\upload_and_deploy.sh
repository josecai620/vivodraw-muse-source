#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "用法: $0 <服务器IP> [ssh_user] [ssh_port]"
  exit 1
fi

SERVER_IP="$1"
SSH_USER="${2:-root}"
SSH_PORT="${3:-49375}"
REMOTE_DIR="/opt/crmeb-prod"

LOCAL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

health_check() {
  local html entry
  html="$(curl -fsS "http://${SERVER_IP}/")" || return 1
  entry="$(python3 -c "import re,sys; html=sys.stdin.read(); m=re.search(r'(_expo/static/js/web/entry-[a-f0-9]+\\.js)', html); print(m.group(1) if m else '')" <<< "${html}")"
  [[ -n "${entry}" ]] || return 1
  curl -fsS -I "http://${SERVER_IP}/${entry}" >/dev/null || return 1
  echo "前台健康检查通过: ${entry}"
}

echo "==> 检查本地文件"
[[ -d "${LOCAL_ROOT}/backend_src" ]] || { echo "缺少 backend_src"; exit 1; }
[[ -f "${LOCAL_ROOT}/sql_www_sawa_com_20250629_010659.sql.gz" ]] || { echo "缺少 sql_www_sawa_com_20250629_010659.sql.gz"; exit 1; }

echo "==> 创建远程目录"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" "mkdir -p '${REMOTE_DIR}'"

echo "==> 上传项目文件（保留前台静态资源，避免误删）"
rsync -avz --delete -e "ssh -p ${SSH_PORT}" \
  --exclude='public/index.html' \
  --exclude='public/_expo/' \
  --exclude='public/assets/' \
  --exclude='public/static/' \
  --exclude='public/legacy/' \
  --exclude='public/phpExcel/' \
  "${LOCAL_ROOT}/backend_src/" \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/backend_src/"

rsync -avz -e "ssh -p ${SSH_PORT}" \
  "${LOCAL_ROOT}/deploy/" \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/deploy/"

scp -P "${SSH_PORT}" \
  "${LOCAL_ROOT}/sql_www_sawa_com_20250629_010659.sql.gz" \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/"

echo "==> 远程执行部署"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" "chmod +x '${REMOTE_DIR}/deploy/server_deploy.sh' '${REMOTE_DIR}/deploy/enable_https.sh' '${REMOTE_DIR}/deploy/import_sql.sh' && bash '${REMOTE_DIR}/deploy/server_deploy.sh'"

echo "==> 发布后前台验活"
health_check

echo "==> 完成"
