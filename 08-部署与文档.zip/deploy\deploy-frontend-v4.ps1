# deploy-frontend-v4.ps1
# Publish the v4 teal frontend as an ISOLATED preview at https://vivodraw.com/v4.
# It NEVER touches the live root (frontend-v3-root/current), /v2, the old v3
# preview, backend public, or any backend/container state.
#
# Pipeline:
#   1. validate mobile-app/dist-v4 (must be built with EXPO_WEB_BASE_URL=/v4)
#   2. tar the build locally
#   3. scp the tarball up to /opt/crmeb-prod/frontend-v4
#   4. on the server (bash -s over stdin, so quoting is preserved): unpack into a
#      timestamped release and atomically repoint the `current` symlink. Old
#      releases are kept for instant rollback.
#
# This script does NOT modify nginx. Enabling /v4 is a separate explicit step.
#
# Examples:
#   powershell -ExecutionPolicy Bypass -File deploy/deploy-frontend-v4.ps1 -LocalPackOnly
#   powershell -ExecutionPolicy Bypass -File deploy/deploy-frontend-v4.ps1

[CmdletBinding()]
param(
  [string]$ServerIp = "186.241.72.176",
  [string]$SshUser  = "root",
  [int]$SshPort    = 49375,
  [string]$KeyPath  = "",
  [string]$RemoteBase = "/opt/crmeb-prod/frontend-v4",
  [int]$KeepReleases = 5,
  [switch]$LocalPackOnly
)

$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Split-Path -Parent $here
$appDir = Join-Path $repoRoot "mobile-app"
$distDir = Join-Path $appDir "dist-v4"
$bundle = Join-Path $appDir "v4-bundle.tar.gz"

if ([string]::IsNullOrEmpty($KeyPath)) {
  $KeyPath = Join-Path $env:USERPROFILE ".ssh\vivodraw_windows_ed25519"
}

# Directories the v4 publish must never write into.
$Forbidden = @(
  "/opt/crmeb-prod/frontend-v3-root",
  "/opt/crmeb-prod/backend_src/public",
  "/opt/crmeb-prod/frontend-v2",
  "/opt/crmeb-prod/frontend-v3-preview"
)

function Assert-True([bool]$cond, [string]$msg) {
  if (-not $cond) { throw $msg }
}

Write-Host "=== 1. Validate local v4 build ===" -ForegroundColor Cyan
Assert-True (Test-Path (Join-Path $distDir "index.html")) "missing dist-v4/index.html; build with EXPO_WEB_BASE_URL=/v4 first"
Assert-True (Test-Path (Join-Path $distDir "_expo")) "missing dist-v4/_expo"
$idx = Get-Content (Join-Path $distDir "index.html") -Raw
Assert-True ($idx -match "/v4/_expo") "dist-v4/index.html is NOT prefixed with /v4; refusing to publish a root-path build"
$bare = [regex]::Matches($idx, '(?<!/v4)["''(]/_expo/').Count
Assert-True ($bare -eq 0) "dist-v4/index.html still has $bare bare /_expo refs"
Write-Host "OK: build is /v4-prefixed"

foreach ($f in $Forbidden) {
  Assert-True ($RemoteBase -ne $f -and -not $RemoteBase.StartsWith($f + "/")) "RemoteBase must not intersect live path $f"
}
Write-Host "OK: target $RemoteBase is isolated from live paths"

Write-Host "=== 2. Package dist-v4 ===" -ForegroundColor Cyan
if (Test-Path $bundle) { Remove-Item $bundle -Force }
Push-Location $appDir
try {
  & tar -czf $bundle -C dist-v4 .
  if ($LASTEXITCODE -ne 0) { throw "tar failed" }
} finally { Pop-Location }
$mb = [math]::Round((Get-Item $bundle).Length / 1MB, 2)
Write-Host "bundle: $bundle ($mb MB)"

if ($LocalPackOnly) {
  Write-Host "LocalPackOnly set; bundle ready, skipping upload." -ForegroundColor Yellow
  return
}

Assert-True (Test-Path $KeyPath) "SSH key not found: $KeyPath"
$sshCommon = @("-i", $KeyPath, "-o", "IdentitiesOnly=yes", "-o", "StrictHostKeyChecking=accept-new", "-o", "ConnectTimeout=15", "-p", "$SshPort")
$ts = Get-Date -Format "yyyyMMdd_HHmmss"
$target = "$SshUser@$ServerIp"

Write-Host "=== 3. Ensure remote base ===" -ForegroundColor Cyan
& ssh @sshCommon $target "mkdir -p '$RemoteBase/releases' && echo READY"
if ($LASTEXITCODE -ne 0) { throw "ssh connect/setup failed" }

Write-Host "=== 4. Upload bundle ===" -ForegroundColor Cyan
& scp -i $KeyPath -P $SshPort -o "StrictHostKeyChecking=accept-new" $bundle "${target}:$RemoteBase/v4-bundle.tar.gz"
if ($LASTEXITCODE -ne 0) { throw "scp upload failed" }

Write-Host "=== 5. Remote atomic release: $ts ===" -ForegroundColor Cyan
# Upload a LF/no-BOM remote script, then run it. This avoids the UTF-8 BOM /
# CRLF corruption that happens when a PowerShell here-string is piped to ssh.
$enc = New-Object System.Text.UTF8Encoding($false)
$rs = [IO.File]::ReadAllText((Join-Path $here "remote-release-v4.sh"))
$rs = $rs -replace "`r`n","`n"
$tmpRs = Join-Path $env:TEMP "remote-release-v4.upload.sh"
[IO.File]::WriteAllText($tmpRs, $rs, $enc)
& scp -i $KeyPath -P $SshPort -o "StrictHostKeyChecking=accept-new" $tmpRs "${target}:/tmp/remote-release-v4.sh"
if ($LASTEXITCODE -ne 0) { throw "upload remote script failed" }
& ssh @sshCommon $target "sed -i 's/\r`$//' /tmp/remote-release-v4.sh && bash /tmp/remote-release-v4.sh '$RemoteBase' '$ts' '$KeepReleases'; rc=`$?; rm -f /tmp/remote-release-v4.sh; exit `$rc"
if ($LASTEXITCODE -ne 0) { throw "remote release failed; previous current symlink (if any) is untouched" }

Write-Host "=== v4 published to $RemoteBase/current; live site, /v2 and v3 untouched ===" -ForegroundColor Green
Write-Host "Next (separate step): add the /v4 nginx location (mirroring /v2), nginx -t, reload, then verify."
