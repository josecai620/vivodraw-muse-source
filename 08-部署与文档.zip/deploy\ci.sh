#!/bin/bash
# +----------------------------------------------------------------------
# | ECCOMALL CI 脚本 — 本地 / Gitee / 服务器手动跑
# +----------------------------------------------------------------------
# | 用法：
# |   bash deploy/ci.sh               # 完整跑：语法 + 单元测试
# |   bash deploy/ci.sh syntax        # 只语法扫描
# |   bash deploy/ci.sh tests         # 只单元测试
# |   bash deploy/ci.sh health        # 活节点端到端健康检查
# |
# | 生产 (/opt/crmeb-prod) 上可直接执行，用 docker exec 进 FPM 容器跑。
# +----------------------------------------------------------------------
set -euo pipefail

MODE="${1:-all}"
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BACKEND="${REPO_ROOT}/backend_src"

# 服务器 vs 本地判断：服务器用 docker exec 进 crmeb-php-fpm 跑，本地直接 PHP
if docker ps --format '{{.Names}}' 2>/dev/null | grep -qx 'crmeb-php-fpm'; then
    PHP_CMD='docker exec crmeb-php-fpm php'
    BACKEND_IN_CTR='/var/www/backend'
    echo "[ci] server mode (using crmeb-php-fpm container)"
else
    PHP_CMD='php'
    BACKEND_IN_CTR="$BACKEND"
    echo "[ci] local mode (using host PHP $(php -r 'echo PHP_VERSION;'))"
fi

syntax_scan() {
    echo ""
    echo "==> [1/3] PHP 语法扫描（app/ + crmeb/ + config/）"
    cd "$BACKEND"
    local ERRORS
    ERRORS=$(find app crmeb config -name "*.php" -not -name "*.bak" -print0 | \
      xargs -0 -n 20 -P 4 $PHP_CMD -l 2>&1 | grep -v "No syntax errors" || true)
    if [ -z "$ERRORS" ]; then
        echo "[ci] ✓ 无语法错误"
    else
        # 只 Parse error / Fatal 算 fail
        if echo "$ERRORS" | grep -qE "Parse error|Fatal"; then
            echo "[ci] ✗ 语法错误:"
            echo "$ERRORS"
            return 1
        fi
        echo "[ci] ⚠ 仅有 deprecated warning（不阻断）:"
        echo "$ERRORS" | head -5
    fi
}

unit_tests() {
    echo ""
    echo "==> [2/3] 单元测试"
    cd "$BACKEND"
    $PHP_CMD "$BACKEND_IN_CTR/tests/unit/run_all.php"
}

health_check() {
    echo ""
    echo "==> [3/4] 健康检查（需要运行时服务可用）"
    local URL="${CI_HEALTH_URL:-http://127.0.0.1:20199/api/healthz}"
    echo "[ci] GET $URL"
    local RESP HTTP
    RESP=$(curl -s -o /tmp/healthz.json -w '%{http_code}' --max-time 5 "$URL" || echo "000")
    HTTP="$RESP"
    if [ "$HTTP" = "200" ]; then
        echo "[ci] ✓ HTTP 200"
        cat /tmp/healthz.json | python3 -m json.tool 2>/dev/null || cat /tmp/healthz.json
    else
        echo "[ci] ✗ HTTP $HTTP"
        cat /tmp/healthz.json 2>/dev/null
        return 1
    fi
}

api_smoke() {
    echo ""
    echo "==> [4/4] API 集成 smoke 测试（8 条）"
    $PHP_CMD "$BACKEND_IN_CTR/tests/integration/api_smoke.php"
}

case "$MODE" in
    syntax) syntax_scan ;;
    tests)  unit_tests ;;
    health) health_check ;;
    smoke)  api_smoke ;;
    all)    syntax_scan && unit_tests && health_check && api_smoke ;;
    *)      echo "usage: $0 [all|syntax|tests|health|smoke]"; exit 2 ;;
esac

echo ""
echo "[ci] ✓ DONE"
