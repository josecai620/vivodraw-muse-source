# CoreSettlement Phase 40 Admin Permission Menu Contract 2026-05-18

## Current Task

Phase 40 defines Point Gateway admin route, permission, and menu contract.

No route was exposed.
No menu SQL was executed.
No DB write was added.
No deployment was executed.

## Contract

```text
mode: readonly_contract_only
route_prefix: adminapi/core/point_gateway
menu: Point Gateway, hidden by default
GET only
root unique_auth: admin-core-point-gateway
api auth_type: 2
api methods: GET
```

## Readonly Routes

```text
GET overview -> point_gateway.overview.view
GET transactions -> point_gateway.transactions.view
GET detail -> point_gateway.transactions.detail
GET rollback_requests -> point_gateway.rollback_requests.view
GET frozen_points -> point_gateway.frozen_points.view
GET expiry_batches -> point_gateway.expiry_batches.view
GET ai_operation_logs -> point_gateway.ai_operation_logs.view
```

## DB/Vue unique_auth Mapping

```text
admin-core-point-gateway
core-point-gateway-overview
core-point-gateway-transactions
core-point-gateway-detail
core-point-gateway-rollback-requests
core-point-gateway-frozen-points
core-point-gateway-expiry-batches
core-point-gateway-ai-operation-logs
```

Contract keys keep dot style for backend docs.
DB/Vue `unique_auth` uses hyphen style to match existing admin permission habit.

## Forbidden

```text
POST
PUT
PATCH
DELETE
point_gateway.rollback.execute
point_gateway.manual_adjust.execute
point_gateway.legacy_bill.update
point_gateway.user_integral.update
```

## Gate Before Exposure

```text
1. route/admin.php GET routes only
2. ACL permission rows approved
3. menu hidden by default
4. no menu SQL in same phase
5. no mutation endpoints
6. all assert scripts pass
```

## Validation

```text
point_gateway_admin_permission_contract_assert
point_gateway_admin_read_assert
point_gateway_admin_route_contract_assert
```
