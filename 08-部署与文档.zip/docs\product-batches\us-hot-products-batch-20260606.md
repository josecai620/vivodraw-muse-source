# US Hot Product Candidate Batch - 2026-06-06

Status: candidate intake only. No backend upload yet. CSV rows use `publish=0`.

## Selection Rules

- Pick for US demand first: Amazon best-seller/category signals, recent marketplace reports, and CJ availability.
- Avoid obvious IP/brand traps: do not reuse Amazon/branded photos unless rights are clear.
- Price from landed cost, not vibes: supplier cost + shipping buffer + service margin + reward buffer + risk buffer.
- Prefer products that support points/blind-box retention without feeling like casino bait.
- Reject or hold battery/high-complaint items until safety, shipping, and return exposure are checked.

## Files

- Intake CSV: `docs/product-batches/us-hot-products-batch-20260606.csv`
- Category/admin workflow: `docs/product-upload-maintenance-workflow.md`
- Candidate shortlist source: `docs/us-hot-product-candidate-shortlist-20260606.md`

## Recommended Upload Order

1. `Makeup Storage Organizer Set`
   - Category: Cute Desk / Home Lifestyle
   - CJ SKU: `CJJT142263501AZ`
   - Cost: `$4.11`
   - Landed estimate: `$14.11`
   - Markup: `$9`
   - Sale price: `$23`
   - Reason: low-ticket, easy impulse buy, US desk/vanity organizer demand is strong.

2. `Hall Effect Mobile Gamepad`
   - Category: Game Gear
   - CJ SKU: `CJYX238694101AZ`
   - Cost: `$28.03`
   - Landed estimate: `$36.03`
   - Markup: `$13`
   - Sale price: `$49`
   - Reason: under-$50 gaming accessory with clear feature value. Copy must avoid overclaiming compatibility.

3. `Mini Building Block Flower Set`
   - Category: Toys / Collectibles
   - CJ SKU: `CJYD238848801AZ`
   - Cost: `$0.63`
   - Landed estimate: `$5.63`
   - Markup: `$12`
   - Sale price: `$18`
   - Reason: cheap, giftable, desk-display friendly, good for points/blind-box cross-sell.
   - Guardrail: never call it `LEGO`.

4. `Desktop LED Light Makeup Mirror`
   - Category: Beauty & Self-care
   - CJ SKU: `CJYD235175002BY`
   - Cost: `$22.06` high-end variant estimate
   - Landed estimate: `$32.06`
   - Markup: `$27`
   - Sale price: `$59`
   - Reason: visually sellable beauty item, but margin only works if shipping is controlled and hero image is premium.

5. `Cartoon Fan Pendant Keychain`
   - Category: Toys / Collectibles
   - CJ SKU: `CJJT178781401AZ`
   - Cost: `$2.45`
   - Landed estimate: `$8.45`
   - Markup: `$10`
   - Sale price: `$19`
   - Reason: cute summer utility accessory. Needs strong image styling or it will look like a dollar-store toy.

## Hold / Watchlist

- `Cordless Air Duster`: demand is real, but Amazon price is transparent and battery/device quality risk is higher. Hold until exact shipping, warranty, and safety claims are checked.
- `Mini Magnetic Wireless Power Bank`: useful travel product, but battery compliance and real capacity must be verified before selling.
- `Body Mist Gift Bundle`: fragrance/body mist demand is real, but Amazon/branded images cannot be reused. Needs authorized supplier or private-label source first.

## Upload Gate

Do not upload to backend until all are true:

- Product categories exist in backend or seed SQL has been approved and run.
- Each product has allowed supplier images or internally edited images.
- Hero and gallery images pass crop QA: full subject, no ugly background, no cut-off edge, no brand confusion.
- Shipping cost and delivery estimate are refreshed for US.
- Battery/electronics products pass safety/compliance copy review.
- Admin upload is approved by owner, because this becomes real sellable catalog data.

## Source Links

- Amazon Electronics Best Sellers: https://www.amzn.com/Best-Sellers-Line-Conditioners/zgbs/electronics/
- Amazon Perfumes & Fragrances Best Sellers: https://www.amzn.com/Best-Sellers-Perfumes-Fragrances/zgbs/beauty/11056591
- ASINsight US Desk Accessories report: https://www.asinsight.com/report/US/desk-accessories
- CJ Makeup Storage Organizer Set: https://cjdropshipping.com/product/makeup-storage-organizer-set-p-1496403300390670336.html
- CJ Hall Effect Mobile Gamepad: https://cjdropshipping.com/product/type-c-wired-bluetooth-android-ios-computer-streaming-ps-handle-p-2505270943401607600.html
- CJ Mini Building Block Flower Set: https://cjdropshipping.com/product/building-block-flower-small-particle-assembly-toy-p-2505290621481615400.html
- CJ LED Makeup Mirror: https://cjdropshipping.com/product/desktop-led-light-makeup-mirror-p-2504111306501618600.html
- CJ Magnetic Wireless Power Bank: https://cjdropshipping.com/product/mini-fast-charging-magnetic-wireless-power-bank-5000-mah-portable-p-1462611587847294976.html
- CJ Cartoon Fan Pendant Keychain: https://cjdropshipping.com/product/student-summer-cartoon-fan-pendant-keychain-p-1673517871877599232.html
