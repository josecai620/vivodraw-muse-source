#!/usr/bin/env bash
# 固定线上验活：前台入口、移动端 API、旧中国入口禁用、后台登录保护。
set -euo pipefail

SERVER_IP="${1:-186.241.72.176}"
SSH_USER="${2:-root}"
SSH_PORT="${3:-49375}"
BASE_URL="${BASE_URL:-https://vivodraw.com}"
RULES="$(cd "$(dirname "$0")" && pwd)/ops/验收规则.php"

tmp_file() {
  mktemp "${TMPDIR:-/tmp}/eccomall_verify.XXXXXX"
}

http_code() {
  local url="$1"
  local output="$2"
  shift 2
  curl -sS --connect-timeout 8 --max-time 20 "$@" -o "${output}" -w "%{http_code}" "${url}" || true
}

expect_code() {
  local name="$1"
  local code="$2"
  local expected="$3"
  if [[ "${code}" != "${expected}" ]]; then
    echo "[verify] ${name} failed: HTTP ${code}, expected ${expected}"
    return 1
  fi
  echo "[verify] ${name}: HTTP ${code}"
}

expect_revalidate_html() {
  local name="$1"
  local url="$2"
  local headers
  headers="$(curl -fsS -I --connect-timeout 8 --max-time 20 "${url}" | tr -d '\r')" || {
    echo "[verify] ${name} cache headers failed"
    return 1
  }
  if ! php "${RULES}" cache <<< "${headers}"; then
    echo "[verify] ${name} requires HTTP 200 with no-store or max-age=0, must-revalidate"
    echo "${headers}" | sed -n '1,12p'
    return 1
  fi
  echo "[verify] ${name}: HTML cache policy safe"
}

verify_runtime_services() {
  ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" '
    set -e

    docker ps --format "{{.Names}}" | grep -qx "crmeb-nginx"
    docker ps --format "{{.Names}}" | grep -qx "crmeb-php-fpm"

    if docker ps --format "{{.Names}}" | grep -qx "crmeb-redis"; then
      exit 0
    fi

    if command -v systemctl >/dev/null 2>&1 && systemctl is-active --quiet redis-server; then
      exit 0
    fi

    if command -v redis-cli >/dev/null 2>&1 && redis-cli -h 127.0.0.1 -p 6379 ping 2>/dev/null | grep -qx "PONG"; then
      exit 0
    fi

    exit 1
  '
}

echo "==> 线上验活: ${BASE_URL}"

front_html="$(tmp_file)"
front_code="$(http_code "${BASE_URL}/" "${front_html}")"
expect_code "frontend index" "${front_code}" "200"
entry="$(python3 -c "import re,sys; html=open(sys.argv[1]).read(); m=re.search(r'(_expo/static/js/web/entry-[a-f0-9]+\\.js)', html); print(m.group(1) if m else '')" "${front_html}")"
rm -f "${front_html}"
if [[ -z "${entry}" ]]; then
  echo "[verify] frontend entry not found"
  exit 1
fi
entry_head="$(curl -fsS -I --connect-timeout 8 --max-time 20 "${BASE_URL}/${entry}" >/dev/null && echo 200 || echo 000)"
expect_code "frontend entry ${entry}" "${entry_head}" "200"
expect_revalidate_html "frontend index cache" "${BASE_URL}/"
expect_revalidate_html "frontend index.html cache" "${BASE_URL}/index.html"
expect_revalidate_html "frontend SPA route cache" "${BASE_URL}/categories"

api_body="$(tmp_file)"
api_code="$(http_code "${BASE_URL}/api/category" "${api_body}" -H "X-Client: mobile-app")"
expect_code "mobile api /api/category" "${api_code}" "200"
python3 -c "import json,sys; data=json.load(open(sys.argv[1])); assert data.get('status') == 200" "${api_body}"
rm -f "${api_body}"

legacy_body="$(tmp_file)"
legacy_code="$(http_code "${BASE_URL}/api/wechat/config" "${legacy_body}" -H "X-Client: mobile-app")"
rm -f "${legacy_body}"
if [[ "${legacy_code}" == "410" || "${legacy_code}" == "404" ]]; then
  echo "[verify] legacy china entry disabled: HTTP ${legacy_code}"
else
  echo "[verify] legacy china entry should be disabled, got HTTP ${legacy_code}"
  exit 1
fi

admin_body="$(tmp_file)"
admin_code="$(http_code "${BASE_URL}/adminapi/home/header" "${admin_body}")"
expect_code "admin login gate" "${admin_code}" "200"
python3 -c "import json,sys; data=json.load(open(sys.argv[1])); assert data.get('status') in (410000, 410001, 410002)" "${admin_body}"
rm -f "${admin_body}"

verify_runtime_services
echo "[verify] core containers visible"

health_body="$(tmp_file)"
health_code="$(http_code "${BASE_URL}/api/healthz" "${health_body}")"
expect_code "release dependencies" "${health_code}" "200"
if ! php "${RULES}" health < "${health_body}"; then
  rm -f "${health_body}"
  echo "[verify] configured realtime dependency must be repaired before release; HTTP 200 alone is insufficient"
  exit 1
fi
rm -f "${health_body}"

echo "==> 线上验活通过"
