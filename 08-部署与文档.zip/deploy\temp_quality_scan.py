# -*- coding: utf-8 -*-
"""检查本次新增/移植文件：1) 乱码特征（鍏/鐨/鏍/� 等 GBK 误解码）；2) emoji；3) v3 残留导入。"""
import io, os, re

ROOT = r'D:\eccomall\mobile-app'
FILES = [
    'app/coin-exchange.tsx', 'app/game-wallet.tsx', 'app/point-purchase.tsx',
    'app/wallet.tsx', 'app/pearl.tsx', 'app/pet-deck.tsx', 'app/play.tsx',
    'app/farm1.tsx', 'app/pick-your-prize.tsx', 'app/profile/delete-account.tsx',
    'app/community/index.tsx', 'app/community/new.tsx', 'app/community/[id].tsx',
    'lib/api/legacyHttp.ts', 'lib/api/community.ts', 'lib/api/pearl.ts',
    'lib/api/petWorld.ts', 'lib/api/rewardCoins.ts', 'lib/api/gameWallet.ts',
    'lib/api/pointPurchase.ts', 'lib/api/walletRecharge.ts',
    'lib/community-share.ts', 'lib/game/practiceHarvest.ts',
    'hooks/useGameSupply.ts', 'hooks/usePointPurchase.ts', 'hooks/useRechargeReturn.ts',
    'hooks/useCommunityFeed.ts', 'hooks/useCommunityDetail.ts', 'hooks/useCommunityComposer.ts',
]
# 递归加 components/pearl, components/pets, components/farm-demo, lib/game
for d in ['components/pearl', 'components/pets', 'components/farm-demo', 'lib/game', 'store']:
    full = os.path.join(ROOT, d)
    if os.path.isdir(full):
        for name in os.listdir(full):
            if name.endswith(('.ts', '.tsx')):
                FILES.append(f'{d}/{name}')

mojibake = re.compile(r'[鍏鐨鏍鐢涓瀵荤彔褰撳墠鐗堟湰鏃犳硶鍖归厤缃戝潃鏂囦欢浠跨敤鑻辨枃鎶€鏈悕绉�]|�')
# 常见 emoji 区段
emoji = re.compile(r'[\U0001F000-\U0001FAFF☀-➿⬀-⯿️]')
v3mark = re.compile(r'@/lib/i18n|useSessionReadModel|@/components/ui/|@/components/shared/Screen|eccomall:v3|local-v3-|features/')

bad = 0
for rel in FILES:
    p = os.path.join(ROOT, rel.replace('/', os.sep))
    if not os.path.exists(p):
        print('MISSING', rel); bad += 1; continue
    s = io.open(p, encoding='utf-8').read()
    m = mojibake.findall(s)
    e = [c for c in emoji.findall(s)]
    v = v3mark.findall(s)
    if m or e or v:
        bad += 1
        print(f'!! {rel}: mojibake={set(m)} emoji={set(e)} v3={set(v)}')
print('scan done, problems =', bad)
