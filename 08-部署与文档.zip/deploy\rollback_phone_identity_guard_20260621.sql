-- Requires explicit approval before production execution.
-- Rolls back deploy/phone_identity_guard_20260621.sql.

DROP PROCEDURE IF EXISTS rollback_phone_identity_guard_20260621;
DELIMITER //
CREATE PROCEDURE rollback_phone_identity_guard_20260621()
BEGIN
    IF EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'eb_user'
            AND INDEX_NAME = 'uniq_user_phone_unique'
    ) THEN
        ALTER TABLE eb_user DROP INDEX uniq_user_phone_unique;
    END IF;

    IF EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'eb_user'
            AND COLUMN_NAME = 'phone_unique'
    ) THEN
        ALTER TABLE eb_user DROP COLUMN phone_unique;
    END IF;
END//
DELIMITER ;

CALL rollback_phone_identity_guard_20260621();
DROP PROCEDURE IF EXISTS rollback_phone_identity_guard_20260621;
