-- Agent promo wallet MVP for VivoDraw creator/agent portal.
-- Scope: additive tables and seed medal packages only.
-- Safe to run more than once.

CREATE TABLE IF NOT EXISTS `eb_agent_promo_package` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(64) NOT NULL DEFAULT '' COMMENT 'Stable package code',
  `name` varchar(120) NOT NULL DEFAULT '' COMMENT 'Package display name',
  `medal_level` varchar(32) NOT NULL DEFAULT '' COMMENT 'Physical medal level',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT 'Medal package sale price',
  `promo_points` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Promo points budget credited to agent',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT 'Package notes',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1 enabled, 0 disabled',
  `sort` int(10) NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_agent_promo_package_code` (`code`),
  KEY `idx_agent_promo_package_status_sort` (`status`,`sort`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent VivoDraw medal promo point packages';

CREATE TABLE IF NOT EXISTS `eb_agent_promo_wallet` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Agent user uid',
  `total_points` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Total credited promo budget',
  `used_points` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Granted promo points',
  `frozen_points` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Reserved or frozen budget',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1 active, 0 frozen',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_agent_promo_wallet_uid` (`uid`),
  KEY `idx_agent_promo_wallet_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent promo point budget wallet';

CREATE TABLE IF NOT EXISTS `eb_agent_promo_ledger` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Agent uid',
  `user_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Target member uid, 0 for wallet-only events',
  `operator_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Admin uid for admin operations',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT 'medal_credit, grant, wallet_freeze, wallet_unfreeze',
  `wallet_delta` int(11) NOT NULL DEFAULT '0' COMMENT 'Signed agent available budget delta',
  `user_delta` int(11) NOT NULL DEFAULT '0' COMMENT 'Signed target user point delta',
  `before_points` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Agent available budget before event',
  `after_points` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Agent available budget after event',
  `user_before_integral` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Target user integral before event',
  `user_after_integral` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Target user integral after event',
  `ref_type` varchar(64) NOT NULL DEFAULT '' COMMENT 'Business reference type',
  `ref_id` varchar(120) NOT NULL DEFAULT '' COMMENT 'Business reference id',
  `package_code` varchar(64) NOT NULL DEFAULT '' COMMENT 'Medal package code if any',
  `client_request_id` varchar(64) DEFAULT NULL COMMENT 'Agent grant idempotency key',
  `reason` varchar(255) NOT NULL DEFAULT '' COMMENT 'Operator or agent reason',
  `mark` varchar(255) NOT NULL DEFAULT '' COMMENT 'Audit mark',
  `ip` varchar(45) NOT NULL DEFAULT '' COMMENT 'Request IP',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_agent_promo_ledger_request` (`agent_uid`,`client_request_id`),
  KEY `idx_agent_promo_ledger_agent_time` (`agent_uid`,`add_time`,`id`),
  KEY `idx_agent_promo_ledger_user_time` (`user_uid`,`add_time`,`id`),
  KEY `idx_agent_promo_ledger_type_time` (`type`,`add_time`,`id`),
  KEY `idx_agent_promo_ledger_ref` (`ref_type`,`ref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent promo point budget and grant ledger';

CREATE TABLE IF NOT EXISTS `eb_agent_member_note` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `agent_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Agent uid',
  `user_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'First-level member uid',
  `stage` varchar(32) NOT NULL DEFAULT '' COMMENT 'Member stage label',
  `tags` varchar(255) NOT NULL DEFAULT '' COMMENT 'Comma separated tags',
  `note` varchar(500) NOT NULL DEFAULT '' COMMENT 'Agent private note',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_agent_member_note_pair` (`agent_uid`,`user_uid`),
  KEY `idx_agent_member_note_user` (`user_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent private first-level member notes';

INSERT INTO `eb_agent_promo_package`
  (`code`, `name`, `medal_level`, `price`, `promo_points`, `description`, `status`, `sort`, `add_time`, `update_time`)
VALUES
  ('bronze_medal_500', 'VivoDraw Bronze Medal', 'bronze', 500.00, 500, 'Physical bronze medal package. Credits 500 promo points to the approved agent.', 1, 10, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
  ('silver_medal_1500', 'VivoDraw Silver Medal', 'silver', 1500.00, 1500, 'Physical silver medal package. Credits 1500 promo points to the approved agent.', 1, 20, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
  ('gold_medal_3000', 'VivoDraw Gold Medal', 'gold', 3000.00, 3000, 'Physical gold medal package. Credits 3000 promo points to the approved agent.', 1, 30, UNIX_TIMESTAMP(), UNIX_TIMESTAMP())
ON DUPLICATE KEY UPDATE
  `name` = VALUES(`name`),
  `medal_level` = VALUES(`medal_level`),
  `price` = VALUES(`price`),
  `promo_points` = VALUES(`promo_points`),
  `description` = VALUES(`description`),
  `status` = VALUES(`status`),
  `sort` = VALUES(`sort`),
  `update_time` = UNIX_TIMESTAMP();
