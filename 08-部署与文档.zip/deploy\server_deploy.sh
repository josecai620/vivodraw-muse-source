#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/opt/crmeb-prod}"
DEPLOY_DIR="${PROJECT_DIR}/deploy"
BACKEND_DIR="${PROJECT_DIR}/backend_src"
SQL_FILE="${PROJECT_DIR}/sql_www_sawa_com_20250629_010659.sql.gz"
ENV_FILE="${DEPLOY_DIR}/.deploy.env"

MYSQL_DATABASE="${MYSQL_DATABASE:-manghehoutai_qhe}"
MYSQL_USER="${MYSQL_USER:-crmeb}"
MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-}"
MYSQL_PASSWORD="${MYSQL_PASSWORD:-}"

if [[ -z "${MYSQL_ROOT_PASSWORD}" ]]; then
  MYSQL_ROOT_PASSWORD="$(openssl rand -hex 12)"
fi
if [[ -z "${MYSQL_PASSWORD}" ]]; then
  MYSQL_PASSWORD="$(openssl rand -hex 12)"
fi

need_cmd() {
  command -v "$1" >/dev/null 2>&1 || return 1
}

pkg_manager() {
  if need_cmd dnf; then
    echo "dnf"
    return
  fi
  if need_cmd apt-get; then
    echo "apt"
    return
  fi
  echo "unknown"
}

install_docker_if_needed() {
  if need_cmd docker; then
    return 0
  fi
  case "$(pkg_manager)" in
    dnf)
      dnf install -y dnf-plugins-core curl ca-certificates
      dnf config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
      dnf install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
      ;;
    apt)
      apt-get update
      apt-get install -y docker.io docker-compose curl ca-certificates
      ;;
    *)
      echo "不支持的系统：未找到 dnf/apt-get"
      exit 1
      ;;
  esac
  systemctl enable --now docker
}

compose_cmd() {
  if docker compose version >/dev/null 2>&1; then
    docker compose "$@"
    return
  fi
  if need_cmd docker-compose; then
    docker-compose "$@"
    return
  fi
  echo "未找到 docker compose / docker-compose"
  exit 1
}

install_nginx_if_needed() {
  if ! need_cmd nginx; then
    case "$(pkg_manager)" in
      dnf) dnf install -y nginx ;;
      apt) apt-get update && apt-get install -y nginx ;;
      *) echo "不支持的系统：无法安装 nginx"; exit 1 ;;
    esac
  fi
  systemctl enable --now nginx
}

configure_firewall() {
  if systemctl is-active --quiet firewalld; then
    firewall-cmd --permanent --add-service=http || true
    firewall-cmd --permanent --add-service=https || true
    firewall-cmd --reload || true
  fi
  if need_cmd ufw; then
    ufw allow 80/tcp || true
    ufw allow 443/tcp || true
  fi
}

write_env_file() {
  mkdir -p "${DEPLOY_DIR}"
  cat > "${ENV_FILE}" <<EOF
MYSQL_ROOT_PASSWORD=${MYSQL_ROOT_PASSWORD}
MYSQL_DATABASE=${MYSQL_DATABASE}
MYSQL_USER=${MYSQL_USER}
MYSQL_PASSWORD=${MYSQL_PASSWORD}
EOF
  chmod 600 "${ENV_FILE}"
}

update_app_env() {
  [[ -f "${BACKEND_DIR}/.env" ]] || { echo "缺少 ${BACKEND_DIR}/.env"; exit 1; }
  sed -i "s/^HOSTNAME.*/HOSTNAME = mysql/" "${BACKEND_DIR}/.env"
  sed -i "s/^HOSTPORT.*/HOSTPORT = 3306/" "${BACKEND_DIR}/.env"
  sed -i "s/^USERNAME.*/USERNAME = ${MYSQL_USER}/" "${BACKEND_DIR}/.env"
  sed -i "s/^PASSWORD.*/PASSWORD = '${MYSQL_PASSWORD}'/" "${BACKEND_DIR}/.env"
  sed -i "s/^DATABASE.*/DATABASE = ${MYSQL_DATABASE}/" "${BACKEND_DIR}/.env"
  sed -i "s/^REDIS_HOSTNAME.*/REDIS_HOSTNAME = redis/" "${BACKEND_DIR}/.env"
  sed -i "s/^PORT.*/PORT = 6379/" "${BACKEND_DIR}/.env"
  sed -i "s/^REDIS_PASSWORD.*/REDIS_PASSWORD = ''/" "${BACKEND_DIR}/.env"
  sed -i "s/^APP_DEBUG.*/APP_DEBUG = false/" "${BACKEND_DIR}/.env" || true
}

compose_up() {
  cd "${DEPLOY_DIR}"
  compose_cmd --env-file "${ENV_FILE}" -f docker-compose.yml up -d --build
}

wait_mysql() {
  for _ in {1..60}; do
    if docker exec crmeb-mysql mysqladmin ping -h 127.0.0.1 -uroot -p"${MYSQL_ROOT_PASSWORD}" --silent >/dev/null 2>&1; then
      return 0
    fi
    sleep 2
  done
  echo "MySQL 启动超时"
  exit 1
}

import_sql() {
  [[ -f "${SQL_FILE}" ]] || { echo "未找到 SQL 文件: ${SQL_FILE}"; return 0; }
  gzip -dc "${SQL_FILE}" | docker exec -i crmeb-mysql mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" "${MYSQL_DATABASE}"
}

configure_nginx_http() {
  local target_conf
  if [[ -d /etc/nginx/sites-available ]]; then
    target_conf="/etc/nginx/sites-available/default"
  else
    target_conf="/etc/nginx/conf.d/crmeb.conf"
  fi
  cat > "${target_conf}" <<'EOF'
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    root /opt/crmeb-prod/backend_src/public;
    index index.html;

    client_max_body_size 50m;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;

    gzip on;
    gzip_comp_level 5;
    gzip_min_length 1024;
    gzip_vary on;
    gzip_types text/plain text/css application/javascript application/json application/xml image/svg+xml;

    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # Frontend entry documents must not be cached. Mobile browsers should get
    # the latest Expo entry bundle after a normal refresh, without force refresh.
    location = / {
        add_header X-Content-Type-Options "nosniff" always;
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header Referrer-Policy "strict-origin-when-cross-origin" always;
        add_header Cache-Control "no-store" always;
        add_header Pragma "no-cache" always;
        add_header Expires "0" always;
        try_files /index.html @swoole;
    }

    location = /index.html {
        add_header X-Content-Type-Options "nosniff" always;
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header Referrer-Policy "strict-origin-when-cross-origin" always;
        add_header Cache-Control "no-store" always;
        add_header Pragma "no-cache" always;
        add_header Expires "0" always;
        try_files /index.html @swoole;
    }

    location ^~ /_expo/ {
        add_header X-Content-Type-Options "nosniff" always;
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header Referrer-Policy "strict-origin-when-cross-origin" always;
        add_header Cache-Control "public, max-age=31536000, immutable" always;
        try_files $uri @swoole;
    }

    location ^~ /assets/ {
        add_header X-Content-Type-Options "nosniff" always;
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header Referrer-Policy "strict-origin-when-cross-origin" always;
        add_header Cache-Control "public, max-age=31536000, immutable" always;
        try_files $uri @swoole;
    }

    # Prevent raw php source from being downloaded.
    location ~ \.php$ {
        return 404;
    }

    # Block hidden and sensitive files.
    location ~ /\.(?!well-known).* {
        deny all;
    }

    # API routes must always go to backend.
    location ^~ /api/ {
        proxy_pass http://127.0.0.1:20199;
        proxy_http_version 1.1;
        proxy_read_timeout 360s;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # Admin API routes must always go to backend.
    location ^~ /adminapi/ {
        proxy_pass http://127.0.0.1:20199;
        proxy_http_version 1.1;
        proxy_read_timeout 360s;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location @swoole {
        add_header X-Content-Type-Options "nosniff" always;
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header Referrer-Policy "strict-origin-when-cross-origin" always;
        add_header Cache-Control "no-store" always;
        add_header Pragma "no-cache" always;
        add_header Expires "0" always;
        proxy_pass http://127.0.0.1:20199;
        proxy_http_version 1.1;
        proxy_read_timeout 360s;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location / {
        try_files $uri $uri/ @swoole;
    }
}
EOF
  if [[ "${target_conf}" == "/etc/nginx/conf.d/crmeb.conf" && -e /etc/nginx/sites-enabled/default ]]; then
    rm -f /etc/nginx/sites-enabled/default
  fi
  nginx -t
  systemctl reload nginx
}

print_result() {
  local ip
  ip="$(curl -s --max-time 5 ifconfig.me || true)"
  cat <<EOF

部署完成：
- 目录: ${PROJECT_DIR}
- 应用端口: 127.0.0.1:20199
- 外部访问: http://${ip:-<服务器IP>}

数据库信息（请保存）：
- DB: ${MYSQL_DATABASE}
- User: ${MYSQL_USER}
- Password: ${MYSQL_PASSWORD}
- RootPassword: ${MYSQL_ROOT_PASSWORD}

查看日志：
docker compose --env-file ${ENV_FILE} -f ${DEPLOY_DIR}/docker-compose.yml logs -f app
若提示命令不存在则用：
docker-compose --env-file ${ENV_FILE} -f ${DEPLOY_DIR}/docker-compose.yml logs -f app
EOF
}

main() {
  [[ -d "${BACKEND_DIR}" ]] || { echo "缺少目录: ${BACKEND_DIR}"; exit 1; }
  install_docker_if_needed
  install_nginx_if_needed
  configure_firewall
  write_env_file
  update_app_env
  compose_up
  wait_mysql
  import_sql
  configure_nginx_http
  print_result
}

main "$@"
