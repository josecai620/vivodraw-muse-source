# CoreSettlement Phase49 Readonly Table Check Execution Request 2026-05-18

## Current Task

Phase49 prepares the execution request for a future readonly production table existence check.

Request only.
No production database connection was opened.
No SQL was executed.
No migration was run.
No deployment was executed.
No write path was enabled.

## Request Summary

```text
request_type: readonly_table_existence_check
target_environment: production or approved clone only
approval_required_before_execution: true
execution_allowed_in_phase49: false
write_sql_allowed: false
ddl_allowed: false
data_change_allowed: false
route_exposure_allowed: false
db_store_enable_allowed: false
```

This request asks for permission to run one readonly metadata query later.
It is not permission to execute the query in Phase49.
It is not permission to create tables.
It is not permission to deploy code.

## Tables To Check

```text
eb_core_point_transaction
eb_core_point_freeze
eb_core_point_rollback_request
eb_core_point_expiry_batch
eb_core_point_gateway_ai_operation_log
eb_core_point_gateway_approval_audit
eb_core_point_ai_operation_log
```

`eb_core_point_ai_operation_log` is legacy draft-only name from Phase23.
If it exists, report only and stop before any compatibility decision.

## Approved Query Shape For Later Phase

Do not run this in Phase49.
Run only after explicit user approval.

```sql
SELECT table_name
FROM information_schema.tables
WHERE table_schema = DATABASE()
  AND table_name IN (
    'eb_core_point_transaction',
    'eb_core_point_freeze',
    'eb_core_point_rollback_request',
    'eb_core_point_expiry_batch',
    'eb_core_point_gateway_ai_operation_log',
    'eb_core_point_gateway_approval_audit',
    'eb_core_point_ai_operation_log'
  )
ORDER BY table_name;
```

## Output Required From Future Execution

```text
mode: point_gateway_readonly_table_existence_result
target_environment: exact environment label
command_executed: redact credentials
readonly: true
tables_existing: list
tables_missing: list
legacy_draft_table_existing: yes/no
action_taken: none
next_required_approval: SQL draft or stop
```

## Stop Conditions

```text
database credentials unavailable
target environment unclear
query needs write privilege
table_schema cannot be confirmed
legacy draft table exists with rows
any command would expose secrets in logs
```

## Validation

```text
point_gateway_readonly_table_check_execution_request_assert
point_gateway_production_table_check_plan_assert
core_settlement_backend_package_assert
```
