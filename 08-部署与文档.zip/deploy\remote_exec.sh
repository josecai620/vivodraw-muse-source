#!/bin/bash
# 通用：在远程服务器上执行任意命令
# 用法：bash deploy/remote_exec.sh "你的命令"
# 示例：bash deploy/remote_exec.sh "docker ps"
#       bash deploy/remote_exec.sh "cd /www && ls -la"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG="$SCRIPT_DIR/remote_config"

if [ ! -f "$CONFIG" ]; then
    echo "未找到 remote_config"
    exit 1
fi

source "$CONFIG"

if [ -z "$REMOTE_HOST" ]; then
    echo "请在 remote_config 中设置 REMOTE_HOST"
    exit 1
fi

if [ -z "$1" ]; then
    echo "用法: bash deploy/remote_exec.sh \"命令\""
    exit 1
fi

SSH_OPTS=()
[ -n "$REMOTE_SSH_KEY" ] && [ -f "${REMOTE_SSH_KEY/#\~/$HOME}" ] && SSH_OPTS=(-i "${REMOTE_SSH_KEY/#\~/$HOME}")

echo ">>> $REMOTE_HOST : $*"
ssh "${SSH_OPTS[@]}" "$REMOTE_HOST" "$@"
exit $?
