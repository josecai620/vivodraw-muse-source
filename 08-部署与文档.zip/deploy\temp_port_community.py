# -*- coding: utf-8 -*-
import io, os
SRC = r'D:\eccomall\mobile-app-v3'
DST = r'D:\eccomall\mobile-app'

# API：只换 http 导入
s = io.open(os.path.join(SRC, 'lib', 'api', 'community.ts'), encoding='utf-8').read()
s = s.replace(
    'import { fetchAuthFormData, fetchAuthPost, fetchReadApi, normalizeRemoteImage, type ApiWriteResult } from "@/lib/api/http";',
    'import { fetchAuthFormData, fetchAuthPost, fetchReadApi, normalizeRemoteImage, type ApiWriteResult } from "@/lib/api/legacyHttp";',
)
io.open(os.path.join(DST, 'lib', 'api', 'community.ts'), 'w', encoding='utf-8', newline='\n').write(s)
print('api community.ts', len(s))

# hooks 原样
for name in ['useCommunityFeed.ts', 'useCommunityDetail.ts', 'useCommunityComposer.ts']:
    data = io.open(os.path.join(SRC, 'hooks', name), encoding='utf-8').read()
    io.open(os.path.join(DST, 'hooks', name), 'w', encoding='utf-8', newline='\n').write(data)
    print('hook', name)
