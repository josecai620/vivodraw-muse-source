-- 修复 3 个商城菜单名称乱码，并确保在顶部横向导航显示
-- 执行时需加：--default-character-set=utf8mb4

SET NAMES utf8mb4;

UPDATE `eb_system_menus` SET `menu_name` = '常规商城' WHERE `id` = 2200;
UPDATE `eb_system_menus` SET `menu_name` = '商品列表' WHERE `id` = 2201;
UPDATE `eb_system_menus` SET `menu_name` = '积分商城' WHERE `id` = 2202;
UPDATE `eb_system_menus` SET `menu_name` = '积分商品' WHERE `id` = 2203;
UPDATE `eb_system_menus` SET `menu_name` = '盲盒商城' WHERE `id` = 2204;
UPDATE `eb_system_menus` SET `menu_name` = '盲盒商品' WHERE `id` = 2205;

-- 确保 3 个父菜单为顶部导航项（pid=0, is_header=1）
UPDATE `eb_system_menus` SET `pid` = 0, `is_header` = 1, `path` = '' WHERE `id` IN (2200, 2202, 2204);
UPDATE `eb_system_menus` SET `path` = '2200' WHERE `id` = 2201;
UPDATE `eb_system_menus` SET `path` = '2202' WHERE `id` = 2203;
UPDATE `eb_system_menus` SET `path` = '2204' WHERE `id` = 2205;
