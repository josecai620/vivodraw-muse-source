# CJ 商品库存同步报告 — 2026-08-09

> 执行时间：2026-08-09 09:17 CST  
> 命令：`php think product:sync-cj-stock`  
> 服务器：8.166.115.27

---

## 摘要

| 指标 | 数量 |
|------|------|
| 检查商品总数 | 29 |
| 下架商品（缺货/CJ删除） | 0 |
| 恢复上架（回仓） | 0 |
| 库存下调 | 2 |
| 成本波动警报 | 8 |
| 查询失败 | 2 |

---

## 一、下架商品（unpublished）

无

---

## 二、恢复上架商品（republished）

无

---

## 三、库存下调（stock_lowered）

我方库存高于 CJ 库存，已自动下调防超卖。

| ID | 商品名 | 原库存 | 下调后库存 |
|----|--------|--------|-----------|
| 964 | Insulated Travel Tumbler | 80 | 39 |
| 1083 | Insulated Travel Tumbler | 999 | 39 |

---

## 四、成本波动警报（price_alerts）

CJ 成本与我方成本波动超过 15%，**仅报警未改价**。请根据下表人工判断是否需要调价或下架。

| ID | 商品名 | 我方成本 | CJ 现价 | 波动幅度 | 建议 |
|----|--------|---------|--------|---------|------|
| 960 | Mini Magnetic Wireless Power Bank | $19.89 | $5.73 | ↓ 71.2% | CJ 价格大幅下降，建议下调售价提升竞争力 |
| 1084 | Mini Magnetic Wireless Power Bank | $19.89 | $5.73 | ↓ 71.2% | CJ 价格大幅下降，建议下调售价提升竞争力 |
| 962 | Travel Toiletry Organizer Bag | $4.36 | $11.02 | ↑ 152.8% | CJ 价格大幅上涨，利润严重压缩，**建议下架或换供应商** |
| 1087 | Travel Toiletry Organizer Bag | $4.36 | $11.02 | ↑ 152.8% | CJ 价格大幅上涨，利润严重压缩，**建议下架或换供应商** |
| 964 | Insulated Travel Tumbler | $10.95 | $0.18 | ↓ 98.4% | CJ 价格异常接近零，**极可能是 CJ 数据错误，请人工核实** |
| 1083 | Insulated Travel Tumbler | $10.95 | $0.18 | ↓ 98.4% | CJ 价格异常接近零，**极可能是 CJ 数据错误，请人工核实** |
| 966 | Magnetic Cable Clip Set | $1.55 | $0.05 | ↓ 96.8% | CJ 价格异常接近零，**极可能是 CJ 数据错误，请人工核实** |
| 1074 | Magnetic Cable Clip Set | $1.55 | $0.05 | ↓ 96.8% | CJ 价格异常接近零，**极可能是 CJ 数据错误，请人工核实** |

---

## 五、查询失败（errors）

CJ 平台返回异常，未能在 CJ 侧查到对应商品信息。

| ID | 商品名 | 失败原因 | 建议 |
|----|--------|---------|------|
| 963 | Digital Kitchen Scale | Product has been removed from shelves, pid:1576401700574351360 | **CJ 已删除该商品**，建议下架处理 |
| 1081 | Digital Kitchen Scale | Product has been removed from shelves, pid:1576401700574351360 | **CJ 已删除该商品**，建议下架处理 |

> 备注：Digital Kitchen Scale（ID 963/1081）此前曾因 CJ 删除被下架，本次在 errors 中出现，说明 CJ 侧仍然无此商品数据。

---

## 六、处理建议汇总

1. **高优先级（立即处理）**：
   - Digital Kitchen Scale（963/1081）：CJ 已删除，**建议立即下架**。
   - Travel Toiletry Organizer Bag（962/1087）：CJ 成本暴涨 152.8%，**建议下架或更换供应商**。

2. **中优先级（需核实）**：
   - Insulated Travel Tumbler（964/1083）和 Magnetic Cable Clip Set（966/1074）：CJ 成本显示为 $0.05~$0.18，**极可能是 CJ 数据异常，请登录 CJ 后台人工确认实际价格**。

3. **低优先级（可优化）**：
   - Mini Magnetic Wireless Power Bank（960/1084）：CJ 价格下降 71.2%，可考虑下调售价以提高竞争力。

---

*报告自动生成，如有疑问请联系管理员。*
