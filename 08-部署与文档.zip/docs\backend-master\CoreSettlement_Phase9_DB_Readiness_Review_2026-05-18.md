# CoreSettlement Phase 9 DB Readiness Review 2026-05-18

## Current Task

Phase 9 只做 DB readiness review。

本轮未连接数据库，未执行 SQL，未执行 migration，未修改生产 DB，未修改业务代码。

## Conclusion

CoreSettlement 当前真实写入路径依赖 `eb_core_settlement_ledger` 和 5 个 `eb_system_config` shadow switch。

代码层默认安全：switch 缺失或值为空时，`sys_config(..., 0)` 会回落到 `0`，真实 ledger 写入保持关闭。

上线前仍不能直接开 switch。必须先只读确认目标环境存在 `eb_core_settlement_ledger`，再确认配置键存在且值为 `0`，最后按单场景逐个打开。

## Code Readiness Findings

### Ledger Table

Current write target:

- logical table: `core_settlement_ledger`
- physical table with current prefix: `eb_core_settlement_ledger`
- writer: `backend_src/app/services/core/LedgerService.php`
- method: `LedgerService::writeRealLedger()`

Required columns used by code:

- `scene`
- `action`
- `uid`
- `request_id`
- `amount`
- `direction`
- `reason`
- `meta`
- `add_time`

Required idempotency:

- unique key on `scene`, `request_id`

Tracked table draft exists:

- `backend_src/deploy/sql/checkin_core_settlement_ledger.sql`

Important drift:

- `docs/backend-master/CoreSettlement_SQL_Draft.sql` still defines the earlier broader draft tables:
  - `eb_core_settlement_record`
  - `eb_core_point_ledger`
- Current PHP real-write path does not write those two tables.
- Before any migration execution, SQL documentation must be reconciled so operators do not run the wrong CoreSettlement table plan.

### Config Switches

Required switches:

- `core_settlement_checkin_shadow`
- `core_settlement_pet_feed_shadow`
- `core_settlement_game_farm_shadow`
- `core_settlement_game_mine_shadow`
- `core_settlement_daily_task_shadow`

Current behavior:

- missing config key => `sys_config(..., 0)` returns default `0`
- `0` => dry-run / shadow only, no DB write
- `1` => controlled real ledger audit write only

Recommended default:

- every switch row should exist with `value = '0'`
- do not set any switch to `1` until target DB table readiness is confirmed

Cache note:

- `SystemConfigService` caches config reads.
- If a switch is inserted or updated later, clear system config cache before testing the new value.

## Readonly SQL Checks

The following SQL is for readonly review only.

Do not execute inside this phase without explicit approval.

### Table Presence

```sql
SELECT expected.table_name,
       CASE WHEN t.TABLE_NAME IS NULL THEN 'missing' ELSE 'present' END AS readiness
FROM (
  SELECT 'eb_core_settlement_ledger' AS table_name
  UNION ALL SELECT 'eb_core_settlement_record'
  UNION ALL SELECT 'eb_core_point_ledger'
) AS expected
LEFT JOIN information_schema.TABLES AS t
  ON t.TABLE_SCHEMA = DATABASE()
 AND t.TABLE_NAME = expected.table_name
ORDER BY expected.table_name;
```

Expected for current PHP real-write readiness:

- `eb_core_settlement_ledger` must be `present`
- `eb_core_settlement_record` and `eb_core_point_ledger` are optional for current PHP path

### Ledger Columns

```sql
SELECT COLUMN_NAME,
       COLUMN_TYPE,
       IS_NULLABLE,
       COLUMN_DEFAULT,
       COLUMN_KEY,
       EXTRA
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'eb_core_settlement_ledger'
ORDER BY ORDINAL_POSITION;
```

Minimum expected column set:

- `id`
- `scene`
- `action`
- `uid`
- `request_id`
- `amount`
- `direction`
- `reason`
- `meta`
- `add_time`

### Ledger Indexes

```sql
SELECT INDEX_NAME,
       NON_UNIQUE,
       GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS columns_in_index
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'eb_core_settlement_ledger'
GROUP BY INDEX_NAME, NON_UNIQUE
ORDER BY INDEX_NAME;
```

Minimum expected index:

- unique index on `scene,request_id`

### Switch Presence

```sql
SELECT expected.menu_name,
       CASE WHEN cfg.menu_name IS NULL THEN 'missing' ELSE 'present' END AS readiness,
       cfg.value,
       cfg.status,
       cfg.type,
       cfg.input_type,
       cfg.config_tab_id
FROM (
  SELECT 'core_settlement_checkin_shadow' AS menu_name
  UNION ALL SELECT 'core_settlement_pet_feed_shadow'
  UNION ALL SELECT 'core_settlement_game_farm_shadow'
  UNION ALL SELECT 'core_settlement_game_mine_shadow'
  UNION ALL SELECT 'core_settlement_daily_task_shadow'
) AS expected
LEFT JOIN eb_system_config AS cfg
  ON cfg.menu_name = expected.menu_name
ORDER BY expected.menu_name;
```

Expected:

- all five rows should be `present`
- default `value` should decode to integer `0`
- no switch should be `1` before ledger table readiness passes

### Switch Missing List

```sql
SELECT expected.menu_name AS missing_menu_name
FROM (
  SELECT 'core_settlement_checkin_shadow' AS menu_name
  UNION ALL SELECT 'core_settlement_pet_feed_shadow'
  UNION ALL SELECT 'core_settlement_game_farm_shadow'
  UNION ALL SELECT 'core_settlement_game_mine_shadow'
  UNION ALL SELECT 'core_settlement_daily_task_shadow'
) AS expected
LEFT JOIN eb_system_config AS cfg
  ON cfg.menu_name = expected.menu_name
WHERE cfg.menu_name IS NULL
ORDER BY expected.menu_name;
```

Expected:

- empty result

## Execution Gate For Later Phase

Do not execute any write SQL until all items are true:

1. Target environment is named.
2. DB backup path is confirmed.
3. `eb_core_settlement_ledger` schema matches the PHP writer.
4. All switch rows exist and remain `0`.
5. System config cache clear path is confirmed.
6. One switch is opened at a time.
7. Rollback is defined as setting the switch back to `0`.

Recommended opening order after DB readiness:

1. `core_settlement_checkin_shadow`
2. `core_settlement_pet_feed_shadow`
3. `core_settlement_game_farm_shadow`
4. `core_settlement_game_mine_shadow`
5. `core_settlement_daily_task_shadow`

## Forbidden Areas

Do not touch without explicit approval:

- `backend_src/app/controller/api/v1/manghe/MangheController.php`
- payment
- order
- real inventory deduction
- SQL execution
- migration execution
- production DB
- server `.env`
- `game/*`
- `mobile-app/*`
- `mobile-app-v3/*`
- unrelated dirty worktree changes

## Next Task

Phase 10 should be a no-execution migration readiness package.

Recommended next step:

1. Reconcile `CoreSettlement_SQL_Draft.sql` with current `eb_core_settlement_ledger` writer.
2. Draft safe insert SQL for missing switch rows with default `0`.
3. Keep it as a draft only.
4. Do not execute SQL.
5. Require explicit target environment and backup confirmation before any live DB operation.

## NEXT WINDOW HANDOFF PACKAGE

- Role: Backend Master Controller
- Phase: Phase 10 migration readiness package
- Completed: Phase 9 DB readiness review
- Key Findings: current PHP writer needs `eb_core_settlement_ledger`; older draft table names differ; switch rows should exist but default off
- Key Files: `backend_src/app/services/core/LedgerService.php`, `backend_src/deploy/sql/checkin_core_settlement_ledger.sql`, this review file
- Dirty Worktree Notes: unrelated game/mobile/v3/docs deletions remain; do not stage broad changes
- Forbidden Areas: payment/order/Manghe/SQL execution/migration/prod DB/game/mobile/v3
- Next Step: reconcile SQL draft and write no-execution switch seed draft
- Validation: docs-only `git diff --check`; no DB query executed
- Risks: missing ledger table or config rows in target env; config cache may hide switch changes until cleared
