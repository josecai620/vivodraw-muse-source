#!/usr/bin/env bash
# 一键部署后台前端到服务器
# 从您的本机终端执行此脚本（需已配置 SSH 免密到 186.241.72.176）
# 用法: ./deploy/一键部署后台前端.sh
set -euo pipefail

SERVER="186.241.72.176"
REMOTE="/opt/crmeb-prod"
LOCAL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "==> 连接服务器并执行构建与部署..."
ssh root@${SERVER} "bash -s" << 'REMOTE_SCRIPT'
set -euo pipefail
PROJECT_DIR="/opt/crmeb-prod"
ADMIN_SRC="${PROJECT_DIR}/backend_src/view/admin"
PUBLIC_DIR="${PROJECT_DIR}/backend_src/public"
ADMIN_PUBLIC="${PUBLIC_DIR}/admin"

echo "==> 1. 检查 dist 是否已存在"
if [[ -d "${ADMIN_SRC}/dist" ]] && [[ -f "${ADMIN_SRC}/dist/index.html" ]]; then
  echo "dist 已存在，直接部署"
else
  echo "==> 2. 进入目录并安装依赖"
  cd "${ADMIN_SRC}"
  if ! command -v node >/dev/null 2>&1; then
    echo "错误: 未找到 Node.js"
    exit 1
  fi
  if [[ ! -d node_modules ]] || [[ ! -f node_modules/.package-lock.json ]]; then
    rm -rf node_modules package-lock.json 2>/dev/null || true
    npm install --registry=https://registry.npmmirror.com --legacy-peer-deps
  fi
  echo "==> 3. 构建"
  export NODE_OPTIONS=--openssl-legacy-provider
  npm run build
fi

echo "==> 4. 部署到 public/admin"
mkdir -p "${ADMIN_PUBLIC}"
rsync -av --delete "${ADMIN_SRC}/dist/" "${ADMIN_PUBLIC}/"
echo "==> 完成"
REMOTE_SCRIPT

echo ""
echo "==> 部署完成！请访问 http://${SERVER}/admin/ 验证"
