# -*- coding: utf-8 -*-
import glob, re, os
os.chdir(r'D:\eccomall\mobile-app')
EMOJI = re.compile(r'[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF]')
n = 0
for f in glob.glob(r'components/**/*.tsx', recursive=True) + glob.glob(r'components/**/*.ts', recursive=True):
    for i, line in enumerate(open(f, encoding='utf-8'), 1):
        code = line.split('//')[0]
        if EMOJI.search(code):
            if re.search(r'["\'>][^"\']*[\U0001F000-\U0001FAFF\u2600-\u27BF]', code):
                print(f.replace('\\', '/'), 'L%d' % i, line.strip()[:100])
                n += 1
print('total emoji lines in components:', n)
