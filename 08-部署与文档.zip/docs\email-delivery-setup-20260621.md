# VivoDraw Official Email + Verification Mail Setup

## Decision

Use two channels:

- Human mailbox: `support@vivodraw.com` on Google Workspace.
- Transactional sending: `no-reply@vivodraw.com` through Resend first. Amazon SES is the cheaper scale option later, but Resend is faster to launch.

Do not use a normal Gmail inbox to send verification codes. It has worse deliverability, harder audit trails, and easier account lockouts.

## DNS Records

Keep the existing `A`/`CNAME` records for `vivodraw.com` untouched.

Add only provider-required mail records:

- Google Workspace: MX records for receiving `support@vivodraw.com`.
- Resend: DKIM/SPF records from the Resend domain page.
- DMARC: start with monitoring policy, then tighten after delivery is stable.

Recommended first DMARC:

```txt
v=DMARC1; p=none; rua=mailto:support@vivodraw.com
```

## Readiness Gate

Before using `support@vivodraw.com`, `agents@vivodraw.com`, or any `@vivodraw.com` CTA in public acquisition, run:

```bash
DOMAIN=vivodraw.com bash deploy/ops/check_us_lead_capture_readiness.sh
```

The gate is read-only. It checks:

- `support@vivodraw.com` and `no-reply@vivodraw.com` are documented.
- The current v4 support page has both email and in-app messaging fallback.
- Public app source does not expose `agents@vivodraw.com` before the agent mailbox is ready.
- DNS-over-HTTPS can prove MX, SPF, and DMARC records.

Do not run paid traffic or public recruitment into email CTAs until this passes. Losing leads silently is not a funnel; it is a shredder.

## Backend Config

Set these through production `.env` or `eb_system_config` keys. Do not commit real API keys.

ThinkPHP `.env` format:

```ini
[EMAIL]
ENABLED = true
DEFAULT = resend
FROM = no-reply@vivodraw.com
FROM_NAME = VivoDraw
REPLY_TO = support@vivodraw.com
RESEND_API_KEY = replace_with_resend_key
VERIFY_EXPIRE_MINUTES = 10
MAX_EMAIL_COUNT = 10
MAX_IP_COUNT = 50
MAX_MINUTE_COUNT = 20
```

SMTP fallback if a verified domain mailbox is used instead of Resend:

```ini
[EMAIL]
ENABLED = true
DEFAULT = smtp
FROM = no-reply@vivodraw.com
FROM_NAME = VivoDraw
REPLY_TO = support@vivodraw.com
SMTP_HOST = smtp.gmail.com
SMTP_PORT = 587
SMTP_USERNAME = no-reply@vivodraw.com
SMTP_PASSWORD = replace_with_mailbox_app_password
SMTP_ENCRYPTION = tls
```

Use SMTP only with a verified `@vivodraw.com` mailbox or alias. Do not put normal Gmail credentials here.

Equivalent `sys_config` keys:

- `email_send_enabled`
- `email_provider`
- `email_from`
- `email_from_name`
- `email_reply_to`
- `resend_api_key`
- `resend_api_url`
- `email_smtp_host`
- `email_smtp_port`
- `email_smtp_username`
- `email_smtp_password`
- `email_smtp_encryption`
- `email_verify_expire_time`
- `email_max_email_count`
- `email_max_ip_count`
- `email_max_minute_count`

## API

```http
GET /api/email/verify_code
POST /api/email/verify
POST /api/login/email
```

`POST /api/email/verify` body:

```json
{
  "email": "user@example.com",
  "type": "register",
  "key": "key from /api/email/verify_code",
  "code": "captcha only after repeated sends"
}
```

After repeated sends with the same key, use:

```http
GET /api/email_captcha?key=<same-key>
```

Email registration reuses existing account registration:

```http
POST /api/register
```

Body:

```json
{
  "account": "user@example.com",
  "captcha": "email code",
  "password": "user password",
  "spread": 0
}
```

Email-code login:

```json
{
  "email": "user@example.com",
  "captcha": "email code",
  "spread": 0
}
```

`mobile-app-v3` unified account entry now routes email addresses through the email endpoints and US mobile numbers through the existing SMS endpoints.
Register mode sends `type=register`; login/recover mode sends `type=login`.
The email-code login endpoint auto-creates a new account when the verified email is not registered, matching the current mobile-code login behavior.

## Safety

- Email sending is disabled until `EMAIL_ENABLED=true` or `email_send_enabled=1`.
- Verification codes are cached only; no production DDL is needed.
- Log provider is available only for local/dev when explicitly enabled. Do not enable it on production because codes enter logs.
