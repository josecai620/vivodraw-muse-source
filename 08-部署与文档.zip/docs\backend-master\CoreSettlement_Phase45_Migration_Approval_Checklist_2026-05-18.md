# CoreSettlement Phase 45 Migration Approval Checklist 2026-05-18

## Current Task

Phase 45 defines the migration approval checklist for Point Gateway tables.

Checklist only.
No SQL file was created.
No SQL was executed.
No migration was run.
No production database connection was opened.
No deployment was executed.
No write path was enabled.

## Approval Gates

```text
explicit user approval required: true
readonly table existence report required first: true
backup confirmation required first: true
rollback plan required first: true
maintenance window required first: true
SQL review required first: true
dry-run asserts required first: true
route exposure approval required separately: true
DbPointTransactionStore enable approval required separately: true
production switch approval required separately: true
```

Approval to prepare SQL is not approval to execute SQL.
Approval to create tables is not approval to enable writes.
Approval to expose readonly routes is not approval to enable mutation endpoints.

## Target Tables For Future Approval

```text
eb_core_point_transaction
eb_core_point_freeze
eb_core_point_rollback_request
eb_core_point_expiry_batch
eb_core_point_gateway_ai_operation_log
eb_core_point_gateway_approval_audit
```

## Name Reconciliation Required

Phase23 contains legacy draft table name:

```text
eb_core_point_ai_operation_log
```

Phase41 and Phase43 use current table name:

```text
eb_core_point_gateway_ai_operation_log
```

Before any SQL file is created, choose one final table name and document the compatibility decision.
Do not create both names unless user explicitly approves a compatibility alias strategy.

## Preflight Checklist

```text
1. Run readonly production table existence check after explicit approval.
2. Confirm whether any target table already exists.
3. Confirm MySQL version and TEXT vs JSON compatibility.
4. Confirm charset and collation policy for utf8mb4.
5. Confirm backup exists and restore path is known.
6. Confirm table creation can be rolled back by dropping only empty new core tables.
7. Confirm deploy SQL file path and naming before file creation.
8. Confirm no existing deploy/install SQL contains Point Gateway table names.
9. Run point_transaction_migration_readiness_assert.
10. Run point_gateway_production_table_check_plan_assert.
11. Run core_settlement_backend_package_assert.
```

## Future SQL File Rules

```text
deploy path must be approved first
SQL file must contain CREATE TABLE IF NOT EXISTS only
SQL file must not contain INSERT
SQL file must not contain UPDATE
SQL file must not contain DELETE
SQL file must not contain DROP
SQL file must not contain TRUNCATE
SQL file must not modify eb_user
SQL file must not modify user_bill
SQL file must not modify order/payment/manghe tables
```

## Future Execution Rules

```text
execute only after explicit user approval
run on approved target environment only
capture command and output
stop on first error
do not retry with edited SQL without review
do not enable DbPointTransactionStore after table creation
do not expose mutation endpoints after table creation
do not turn on production switches after table creation
```

## Rollback Contract

```text
rollback applies only to newly created empty core tables
never drop legacy user_bill
never update eb_user integral
never delete point ledger rows
if any table contains rows, stop and ask user before rollback
```

## Validation

```text
point_gateway_migration_approval_checklist_assert
point_transaction_migration_readiness_assert
core_settlement_backend_package_assert
```
