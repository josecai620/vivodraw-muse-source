# -*- coding: utf-8 -*-
import json
en = json.load(open(r'D:\eccomall\mobile-app\lib\i18n\locales\en.json', encoding='utf-8'))
for p in [('hall','maxValue'),('checkin','todayChecked'),('probability','viewDetail'),
          ('shipping','freight'),('shipping','confirm'),('auth','multipleErrors'),
          ('profile','pointsMultiplier'),('groupLottery','memberWon'),('groupLottery','youWon'),
          ('groupLottery','shippedStatus'),('groupLottery','recycledStatus'),('activity','boostRarity'),
          ('checkin','taskProgress')]:
    cur = en
    for k in p: cur = cur[k]
    print('.'.join(p), '=>', repr(cur))
# 非 ASCII 字符全量列出（en 中只允许合法标点/emoji）
bad = []
def walk(o, path=''):
    if isinstance(o, dict):
        for k,v in o.items(): walk(v, path+'.'+k)
    elif isinstance(o, str):
        for ch in o:
            if ord(ch) > 0x2FFF and not (0x1F300 <= ord(ch) <= 0x1FAFF):
                bad.append((path, ch, hex(ord(ch))))
walk(en)
for b in bad: print('NONASCII', b)
print('total suspicious:', len(bad))
