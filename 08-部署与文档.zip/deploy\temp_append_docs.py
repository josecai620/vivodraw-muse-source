# -*- coding: utf-8 -*-
import io, os

SECTION_RELEASE = """

---

## 七、Release 20260915_004009：v3/v4 功能对账 P0–P3 全部补齐（2026-09-15 凌晨）

### 背景
v3/v4 路由与功能对账（报告 `deploy/v3-v4功能对账报告-20260914.md`）确认 v4 真缺失 7 项 + 外部游戏缺入口 2 项，用户拍板 P0–P3 全做。本次一次性补齐并上线，设计严格沿用方向 C（白底白浮卡柔影、teal #04A8AE 立体主按钮、黑色线性 lucide 图标、无彩色 emoji）。

### 新增页面（app/，全部方向 C 重写，非搬运 v3 暖棕组件）
| 优先级 | 路由 | 说明 |
|---|---|---|
| P0 | /profile/delete-account | 注销账号，走后端 /api/cancel/user，DELETE 确认词 + Alert 二次确认 |
| P1 | /coin-exchange | 游戏金币 → 平台积分，/api/reward_coin/summary、/exchange |
| P1 | /game-wallet | 游戏补币双向兑换，/api/game_wallet/state、/exchange（mine/pearl/farm） |
| P1 | /point-purchase | 美元余额买积分，/api/point_purchase/state、/buy |
| P1 | /wallet | 根级 Stripe 充值宿主，/api/recharge/recharge、checkpay，固定回跳 + 5/10/25 快捷金额 |
| P1 | /pearl | 海底寻珠（游戏 teal 海底场景为内容色，保留），/api/pearl/* |
| P1 | /pet-deck | 桌宠世界（像素舞台深色为游戏内容），/api/user/pet-world/* |
| P2 | /community、/community/[id]、/community/new | 社区广场聚合 + 详情 + 发帖（限 jpg/png/webp、2MB、≤6 张） |
| P2 | /play | 「互动乐园」聚合 10 入口（外链 mine/farm 在 web 用 window.location.assign） |
| P3 | /farm1 | 极简农场纯试玩原型（PRACTICE_MODE，收成只存本机，正式版以 /farm 为准） |
| P3 | /pick-your-prize | 每日选奖概念页（硬编码奖品/增益，纯 useState，无账号写入） |

### 兼容层与移植架构
- `lib/api/legacyHttp.ts`：对齐 v3「不抛错、返回 {ok,data,message,status}」契约；token 取 zustand useAuthStore；同源 baseURL；固定带 `X-Client: mobile-app`（**不带此头后端返 403「客户端已升级」**）；同时发 Authorization 与 Authori-zation 双拼写兼容 CRMEB；含 fetchAuthFormData（上传）与 normalizeRemoteImage。
- v3 API 模块机械移植到 lib/api（中文文件名改英文）；纯逻辑/幂等恢复移植到 lib/game；状态 hook 到 hooks（token 改读 zustand，用 useAuthStore.subscribe 替代 SESSION_UPDATED_EVENT）。
- i18n：en.json / zh-TW.json 各新增 coinExchange(26) / gameWallet(48) / pointPurchase(45) / walletRecharge(30) + deleteAccount(20) 词条，插值统一 i18next {{}}；两语言各 66 个 top key，漏键审计归零。

### 新素材
assets/海底寻珠（9 图）、assets/pets（avatars 14 + sheets 127 + 根级 *_clean.png 14 + animation-config.json）、assets/极简农场（24 webp）、assets/products（ps5/headset/mystery 3 jpg）。

### 入口串联
- profile 新增「Play & community / 玩樂與社區」菜单区（/play、/community）。
- 首页 DailyRewardsCard 加第三个 pill「Play & rewards」→ /play。

### 质量门
- `npx tsc --noEmit` 0 错（顺带修了阶段 4 遗留：lib/boxTheme.ts 补 BoxShadows.raisedSm；profile 路由联合类型补 /play、/community；pet-theme 存储键由 eccomall:v3:* 改名 vivodraw:v4:* 避免同域撞键）。
- 预览构建 dist-v4（base /v4）→ 8091 逐页截图验收 14 页 + 2 入口：未登录态引导、方向 C、双语无乱码、素材加载、farm1 试玩收成交互均通过；控制台无应用侧错误（仅浏览器扩展噪声），无 404/500。

### 发布
- 根构建 dist-root（无 /v4 前缀，index.html 引用全为根绝对路径），pack_root.py 打平 556 文件 12.6MB。
- 服务器原子发布：releases/20260915_004009，current 软链切换，保留最近 5 版。
- nginx `set $v4rel "20260915_004009";` 同步更新并 reload（脚本 deploy/remote-bump-v4rel.sh，避免 sed 跨 shell 引号问题；改前自动备份）。
- 线上复扫：/play /coin-exchange /game-wallet /point-purchase /wallet /pearl /pet-deck /community/new /farm1 /pick-your-prize /profile/delete-account 全 200；/community→/community/ 301（正常）；/v4/play→/play 301；/v3/ 200 旧版完好；HTML 资源均带 ?v=20260915_004009。
- 后端对接实测（带 X-Client: mobile-app）：/api/community/posts 200 lists:[]；/api/pearl/rules 200 返回真实规则；需登录端点未带 token 返 410000 请登录（与未登录引导一致）。

### 仍待办
- 登录态深验：兑换/购买/充值/寻珠/桌宠/社区发帖/box 背包等需测试账号登录后验数据与回执。
- v4 源码仍未 git commit（冻结）；v3 源码未动。
"""

SECTION_HANDOFF = """

---

# 【20260915_004009 增量】P0–P3 功能补齐上线

> 本段为 2026-09-15 凌晨增量，承接上文阶段 0–4 换皮。线上 current = releases/20260915_004009，nginx $v4rel 同戳。

## 补齐内容（v3 有、v4 缺，全部移植并按方向 C 重写）
- P0 注销账号 /profile/delete-account（/api/cancel/user）
- P1 资金四连：/coin-exchange、/game-wallet、/point-purchase、/wallet（Stripe）
- P1 游戏：/pearl 海底寻珠、/pet-deck 桌宠世界
- P2：/community 社区广场三页、/play 互动乐园聚合（含 mine/farm 外链入口）
- P3 纯试玩：/farm1（本地收成不写账）、/pick-your-prize（概念选奖）
- 入口：profile「玩樂與社區」区、首页 DailyRewardsCard 第三 pill

## 关键架构（新 Agent 必读）
- v4 axios（lib/http.ts，非 2xx reject）与 v3 fetchAuth*（不抛错、{ok,data,message,status}）契约不同 → 统一走兼容层 **lib/api/legacyHttp.ts**；必须带 **X-Client: mobile-app**，否则后端 403；token 来自 useAuthStore.getState().token；CRMEB 双 Authorization 拼写。
- 移植的 v3 逻辑在 lib/game（幂等恢复）、hooks（zustand 订阅）、lib/api（英文文件名）。
- i18n 只有 en.json + zh-TW.json（indent=2，繁体），新增四命名空间共约 149 键×2；漏键审计脚本 deploy/temp_locale_audit.py（只覆盖资金页，扩页要加 PAGES）。
- pet-theme 本地存储键已改 vivodraw:v4:*，禁止回退成 eccomall:v3:*（同域撞 v3）。

## 发版闭环（本次验证过的命令）
1. `npx tsc --noEmit` 必须 0 错。
2. 预览：`$env:EXPO_WEB_BASE_URL='/v4'; npx expo export --platform web --output-dir dist-v4 --no-bytecode`，8091（静态服务 dist-v4）截图。
3. 根版：`Remove-Item Env:EXPO_WEB_BASE_URL; npx expo export --platform web --output-dir dist-root --no-bytecode` → `python deploy/pack_root.py`。
4. scp 到服务器 /root（不要传 /tmp，有 uid 501 残留）→ `bash /tmp/remote-release-root.sh <yyyyMMdd_HHmmss>`。
5. **必须**同步：`bash /root/remote-bump-v4rel.sh <同时间戳>` 改 nginx $v4rel 并 reload，否则用户缓存旧引导 chunk 会白屏。
6. 线上 curl 全路由 200 + HTML 带 ?v=新戳 + 浏览器实拍 + /api 带 X-Client 抓包。

## 本次踩坑
- PowerShell `python -c` 内嵌双引号/中文必炸，复杂逻辑一律写 deploy/temp_*.py 文件执行；路径含 [id].tsx 用 -LiteralPath 或 Python。
- 跨 PowerShell→ssh→bash 的 sed 引号会被多层拆坏，改配置用服务器端 python3（见 remote-bump-v4rel.sh）。
- expo export 不会因为 tsc 类型错而失败（metro/babel 不类型检查），但缺静态资源（require 解析不到）会直接构建失败；新增素材后用 deploy/temp_check_requires.py 全量校验。
- 桌宠素材除 sheets/avatars 外，还有根级 animation-config.json 与 14 张 *_clean.png，漏了会 Unable to resolve。

## 状态
- 线上：v4 在 `/`、v3 在 `/v3/`、/v4 301 跳根，首页「旧界面V3」按钮保留。
- 未做：登录态深验（需测试账号）；git 仍冻结（不 commit、不 push、不碰 v3 源码）。
"""

targets = [
    (r'D:\eccomall\deploy\线上切换记录-20260914-v4根路径.md', SECTION_RELEASE),
    (r'D:\eccomall\V4前端换皮-交接包-20260914.md', SECTION_HANDOFF),
]
for path, section in targets:
    assert os.path.exists(path), path
    with io.open(path, 'r', encoding='utf-8') as f:
        cur = f.read()
    marker = '20260915_004009'
    if marker in cur:
        print('already appended:', path); continue
    with io.open(path, 'a', encoding='utf-8', newline='\n') as f:
        f.write(section)
    print('appended:', path, os.path.getsize(path))
