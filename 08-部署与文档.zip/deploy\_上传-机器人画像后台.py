# -*- coding: utf-8 -*-
"""机器人画像：把后台源码（机器人账户页 + api）与构建脚本按清单传到线上，然后重建 admin-v2。"""
import hashlib
import os
import subprocess
import tempfile
import time

KEY = os.path.expanduser(r"~\.ssh\vivodraw_windows_ed25519")
PORT = "49375"
HOST = "root@186.241.72.176"
REMOTE_DIR = "/opt/crmeb-prod"
ROOT = r"D:\eccomall"
FILES = [
    "backend_src/view/admin/src/pages/yunmall/robots/index.vue",
    "backend_src/view/admin/src/api/yunmall.js",
]
BUILD_SH = "deploy/_构建-机器人画像后台.sh"
STAGING = os.path.join(tempfile.gettempdir(), "t29-robot-admin-src")

SSH = ["ssh", "-i", KEY, "-p", PORT, "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes", "-o", "ServerAliveInterval=15", HOST]
SCP = ["scp", "-O", "-i", KEY, "-P", PORT, "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes"]


def run(cmd, timeout=900):
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
    if proc.returncode != 0:
        raise SystemExit("命令失败：%s\n%s\n%s" % (cmd[0], proc.stdout, proc.stderr))
    return proc.stdout.strip()


def stage(rel):
    src = os.path.join(ROOT, rel.replace("/", os.sep))
    dest = os.path.join(STAGING, rel.replace("/", os.sep))
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    data = open(src, "rb").read().replace(b"\r\n", b"\n")
    open(dest, "wb").write(data)
    return dest, hashlib.sha256(data).hexdigest()


def main():
    sha, staged = {}, {}
    for rel in FILES:
        staged[rel], sha[rel] = stage(rel)
    build_dest, build_sha = stage(BUILD_SH)

    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = "mkdir -p %s/deploy_backups && cd %s && tar --ignore-failed-read -czf deploy_backups/机器人画像后台源码-%s.tar.gz %s && echo BACKUP_OK" % (
        REMOTE_DIR, REMOTE_DIR, stamp, " ".join(FILES))
    print(run(SSH + [backup]), flush=True)

    for rel in FILES:
        print(run(SCP + [staged[rel], "%s:%s/%s" % (HOST, REMOTE_DIR, rel)]), flush=True)
    print(run(SCP + [build_dest, "%s:/root/t29-build.sh" % HOST]), flush=True)

    remote_sha = run(SSH + ["cd %s && sha256sum %s" % (REMOTE_DIR, " ".join(FILES))])
    remote_map = dict((line.split()[1], line.split()[0]) for line in remote_sha.splitlines() if len(line.split()) == 2)
    bad = [rel for rel in FILES if remote_map.get(rel) != sha[rel]]
    if bad:
        raise SystemExit("上传后 SHA256 不一致：" + ", ".join(bad))
    print("后台源码 SHA256 一致", flush=True)

    print(run(SSH + ["bash /root/t29-build.sh"], timeout=900), flush=True)
    print("ADMIN_DEPLOY_OK", flush=True)


if __name__ == "__main__":
    main()
