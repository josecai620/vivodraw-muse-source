-- ============================================================
-- 开盒记录：创建 eb_box_order、eb_user_box 表及菜单
-- 表前缀默认 eb_，执行前请确认
-- 执行：mysql -u用户 -p 数据库 < 本文件
-- ============================================================

-- 1. 盲盒订单表（开盒记录）
CREATE TABLE IF NOT EXISTS `eb_box_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(32) NOT NULL DEFAULT '' COMMENT '订单号',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID/机器人ID',
  `cate_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '盲盒分类ID',
  `cate_name` varchar(100) NOT NULL DEFAULT '' COMMENT '盲盒分类名',
  `cate_image` varchar(255) NOT NULL DEFAULT '' COMMENT '盲盒分类图',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '盲盒单价',
  `num` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '开盒数量',
  `money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '订单金额',
  `pay_money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '实付金额',
  `pay_type` varchar(32) NOT NULL DEFAULT '' COMMENT '支付方式',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态 0未支付 1已支付',
  `pay_time` int(11) NOT NULL DEFAULT '0' COMMENT '支付时间',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `is_jiqiren` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否机器人 0否1是',
  `point_deduction_money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '积分抵扣金额',
  `point_deduction_num` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '积分抵扣数量',
  `user_coupon_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户优惠券ID',
  `coupon_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '优惠券ID',
  `discounts_money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '优惠金额',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `cate_id` (`cate_id`),
  KEY `pay_status` (`pay_status`),
  KEY `createtime` (`createtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='盲盒订单表（开盒记录）';

-- 2. 用户开盒奖品表
CREATE TABLE IF NOT EXISTS `eb_user_box` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '盲盒订单ID',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `cate_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '盲盒分类ID',
  `cate_name` varchar(100) NOT NULL DEFAULT '' COMMENT '盲盒分类名',
  `cate_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '盲盒价格',
  `product_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '开出的商品ID',
  `product_name` varchar(255) NOT NULL DEFAULT '' COMMENT '商品名',
  `product_image` varchar(255) NOT NULL DEFAULT '' COMMENT '商品图',
  `product_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '商品价格',
  `freight_money` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '运费',
  `brand_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '品牌ID',
  `tag` tinyint(1) NOT NULL DEFAULT '4' COMMENT '稀有度 1-4',
  `rand_num` int(11) NOT NULL DEFAULT '0' COMMENT '随机数',
  `createtime` int(11) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(11) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `is_jiqiren` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否机器人 0否1是',
  `is_tanchu` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已弹出展示 0否1是',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态 0未兑换 1已兑换/发货 2已换',
  `is_box_order` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否生成发货单 0否1是',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `uid` (`uid`),
  KEY `cate_id` (`cate_id`),
  KEY `product_id` (`product_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户开盒奖品记录';

-- 3. 开盒记录菜单（商品菜单 pid=1 下）
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 1, 1, 'md-cube-outline', '开盒记录', 'admin', 'product.BoxLog', 'index', 'product/boxlist', 'GET', '[]', 5, 1, 0, 1, '/admin/product/openbox_list', '1', 1, 'product', 1, 'admin-product-openbox-list', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/product/openbox_list' AND `is_del` = 0);
