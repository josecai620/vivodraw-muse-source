-- Disable second-level affiliate commission.
-- Requested 2026-06-16: platform keeps first-level commission only.
--
-- This only updates two system config rows:
--   brokerage_level: 1
--   store_brokerage_two: 0
--
-- After running this SQL, clear cache (`php think clear:cache`) and restart PHP-FPM.

SELECT 'before' AS phase, menu_name, value
FROM eb_system_config
WHERE menu_name IN ('brokerage_level', 'store_brokerage_two', 'store_brokerage_ratio')
ORDER BY menu_name;

UPDATE eb_system_config
SET value = '"1"'
WHERE menu_name = 'brokerage_level';

UPDATE eb_system_config
SET value = '"0"'
WHERE menu_name = 'store_brokerage_two';

SELECT 'after' AS phase, menu_name, value
FROM eb_system_config
WHERE menu_name IN ('brokerage_level', 'store_brokerage_two', 'store_brokerage_ratio')
ORDER BY menu_name;
