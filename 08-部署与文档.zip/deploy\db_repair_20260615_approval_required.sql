-- Backend/database repair plan generated from 2026-06-15 read-only audit.
--
-- APPROVAL REQUIRED.
-- Do not run this during peak traffic.
-- Required before execution:
--   1. Verified database backup.
--   2. Run deploy/db_audit_20260615_readonly.sql and save output.
--   3. Confirm target database with SELECT DATABASE().
--   4. Run on staging first when available.
--
-- This script is guarded where practical, but it still performs DDL.

SET @schema_name = DATABASE();

SELECT 'target_database', @schema_name;

-- 1) Keep legacy reveal table as production truth.
-- The codebase now uses eb_store_product_kaijiang_log. Add optional card-code
-- columns used by admin set_kami if they are missing.
SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product_kaijiang_log` ADD COLUMN `kami_account` varchar(255) NOT NULL DEFAULT '''' COMMENT ''Card code account'' AFTER `is_kami`',
    'SELECT ''skip: eb_store_product_kaijiang_log.kami_account exists''')
  FROM information_schema.columns
  WHERE table_schema = @schema_name
    AND table_name = 'eb_store_product_kaijiang_log'
    AND column_name = 'kami_account'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product_kaijiang_log` ADD COLUMN `kami_pass` varchar(255) NOT NULL DEFAULT '''' COMMENT ''Card code password'' AFTER `kami_account`',
    'SELECT ''skip: eb_store_product_kaijiang_log.kami_pass exists''')
  FROM information_schema.columns
  WHERE table_schema = @schema_name
    AND table_name = 'eb_store_product_kaijiang_log'
    AND column_name = 'kami_pass'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 2) Add missing composite indexes for current largest/high-traffic tables.
SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_user_box` ADD INDEX `idx_user_box_uid_product_status_id` (`uid`, `product_id`, `status`, `id`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_user_box_uid_product_status_id exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_user_box' AND index_name = 'idx_user_box_uid_product_status_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_user_box` ADD INDEX `idx_user_box_uid_cate_status_product` (`uid`, `cate_id`, `status`, `product_id`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_user_box_uid_cate_status_product exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_user_box' AND index_name = 'idx_user_box_uid_cate_status_product'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_user_box` ADD INDEX `idx_user_box_huanqu_id` (`huanqu_id`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_user_box_huanqu_id exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_user_box' AND index_name = 'idx_user_box_huanqu_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_box_order` ADD INDEX `idx_box_order_uid_id` (`uid`, `id`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_box_order_uid_id exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_box_order' AND index_name = 'idx_box_order_uid_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_box_order` ADD INDEX `idx_box_order_order_sn` (`order_sn`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_box_order_order_sn exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_box_order' AND index_name = 'idx_box_order_order_sn'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_box_order` ADD INDEX `idx_box_order_pay_status_id` (`pay_status`, `id`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_box_order_pay_status_id exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_box_order' AND index_name = 'idx_box_order_pay_status_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log_unique` ADD INDEX `idx_hq_unique_draw_lookup` (`product_id`, `bianhao`, `status`, `isset`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_hq_unique_draw_lookup exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_integral_product_huanqu_log_unique' AND index_name = 'idx_hq_unique_draw_lookup'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log_unique` ADD INDEX `idx_hq_unique_huanqu_isset` (`huanqu_id`, `isset`, `is_jiqiren`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_hq_unique_huanqu_isset exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_integral_product_huanqu_log_unique' AND index_name = 'idx_hq_unique_huanqu_isset'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log` ADD INDEX `idx_hq_log_product_bianhao_id` (`product_id`, `bianhao`, `id`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_hq_log_product_bianhao_id exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_integral_product_huanqu_log' AND index_name = 'idx_hq_log_product_bianhao_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log` ADD INDEX `idx_hq_log_uid_boxcate_id` (`uid`, `box_cate_id`, `id`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_hq_log_uid_boxcate_id exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_integral_product_huanqu_log' AND index_name = 'idx_hq_log_uid_boxcate_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product_kaijiang_log` ADD INDEX `idx_kaijiang_product_bianhao` (`product_id`, `bianhao`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_kaijiang_product_bianhao exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_product_kaijiang_log' AND index_name = 'idx_kaijiang_product_bianhao'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product_kaijiang_log` ADD INDEX `idx_kaijiang_status_time_id` (`status`, `kaijiang_time`, `id`), ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_kaijiang_status_time_id exists''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_product_kaijiang_log' AND index_name = 'idx_kaijiang_status_time_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 3) Remove exact duplicate id indexes where a PRIMARY KEY already exists.
SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_system_attachment_category` DROP INDEX `id`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: eb_system_attachment_category.id duplicate index missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name
    AND table_name = 'eb_system_attachment_category'
    AND index_name = 'id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_user_level` DROP INDEX `id`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: eb_user_level.id duplicate index missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name
    AND table_name = 'eb_user_level'
    AND index_name = 'id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 4) Convert the only MyISAM table to InnoDB.
SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_wechat_key` ENGINE=InnoDB',
    'SELECT ''skip: eb_wechat_key is not MyISAM or missing''')
  FROM information_schema.tables
  WHERE table_schema = @schema_name
    AND table_name = 'eb_wechat_key'
    AND engine = 'MyISAM'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- 5) Add a real key to product descriptions when no duplicates exist.
SET @duplicate_product_description_rows = (
  SELECT COUNT(*)
  FROM (
    SELECT product_id, type
    FROM eb_store_product_description
    GROUP BY product_id, type
    HAVING COUNT(*) > 1
  ) d
);
SET @product_description_pk_exists = (
  SELECT COUNT(*)
  FROM information_schema.table_constraints
  WHERE table_schema = @schema_name
    AND table_name = 'eb_store_product_description'
    AND constraint_type = 'PRIMARY KEY'
);
SET @sql = IF(
  @duplicate_product_description_rows = 0 AND @product_description_pk_exists = 0,
  'ALTER TABLE `eb_store_product_description` ADD PRIMARY KEY (`product_id`, `type`), ALGORITHM=INPLACE, LOCK=NONE',
  'SELECT ''skip: eb_store_product_description primary key blocked by existing pk or duplicates'''
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

ANALYZE TABLE
  `eb_user_box`,
  `eb_box_order`,
  `eb_store_integral_product_huanqu_log_unique`,
  `eb_store_integral_product_huanqu_log`,
  `eb_store_product_kaijiang_log`,
  `eb_store_product_description`;
