# CoreSettlement Phase 31 Point Admin Filter Contract Hardening 2026-05-18

Readonly admin transaction filters expanded.

Added filters:

```text
source_module
biz_type
biz_id
error_code
direction
idempotency_status
operator_type
legacy_user_bill_id
created_at_start
created_at_end
```

No route exposure.
No DB query.
No DB write.
No mutation endpoint.
