-- Approval-required internal real-data test switches for farm/mine.
-- Safe default: creates switches OFF with empty UID allowlists.
--
-- To enable a scoped real-data test after owner approval, run a separate
-- targeted UPDATE with explicit internal tester uid(s), for example:
--   UPDATE `eb_system_config` SET `value` = '1'
--   WHERE `menu_name` IN ('game_farm_test_enabled', 'game_mine_test_enabled');
--   UPDATE `eb_system_config` SET `value` = '1,2'
--   WHERE `menu_name` IN ('game_farm_test_uids', 'game_mine_test_uids');
--
-- Keep global live switches OFF during internal testing:
--   game_farm_live_enabled = 0
--   game_mine_live_enabled = 0

START TRANSACTION;

INSERT INTO `eb_system_config`
  (`is_store`, `menu_name`, `type`, `input_type`, `config_tab_id`, `parameter`, `value`, `info`, `desc`, `sort`, `status`)
SELECT
  0,
  'game_farm_test_enabled',
  'radio',
  'radio',
  0,
  '0=>Off\n1=>Internal test only',
  '0',
  'Farm internal real-data test switch',
  'Keep 0 unless explicit owner approval and game_farm_test_uids is set.',
  0,
  1
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_system_config` WHERE `menu_name` = 'game_farm_test_enabled' LIMIT 1
);

INSERT INTO `eb_system_config`
  (`is_store`, `menu_name`, `type`, `input_type`, `config_tab_id`, `parameter`, `value`, `info`, `desc`, `sort`, `status`)
SELECT
  0,
  'game_farm_test_uids',
  'text',
  'input',
  0,
  '',
  '',
  'Farm internal tester uid allowlist',
  'Comma-separated backend-authenticated uid list. Example: 1,2',
  0,
  1
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_system_config` WHERE `menu_name` = 'game_farm_test_uids' LIMIT 1
);

INSERT INTO `eb_system_config`
  (`is_store`, `menu_name`, `type`, `input_type`, `config_tab_id`, `parameter`, `value`, `info`, `desc`, `sort`, `status`)
SELECT
  0,
  'game_mine_test_enabled',
  'radio',
  'radio',
  0,
  '0=>Off\n1=>Internal test only',
  '0',
  'Mine internal real-data test switch',
  'Keep 0 unless explicit owner approval and game_mine_test_uids is set.',
  0,
  1
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_system_config` WHERE `menu_name` = 'game_mine_test_enabled' LIMIT 1
);

INSERT INTO `eb_system_config`
  (`is_store`, `menu_name`, `type`, `input_type`, `config_tab_id`, `parameter`, `value`, `info`, `desc`, `sort`, `status`)
SELECT
  0,
  'game_mine_test_uids',
  'text',
  'input',
  0,
  '',
  '',
  'Mine internal tester uid allowlist',
  'Comma-separated backend-authenticated uid list. Example: 1,2',
  0,
  1
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_system_config` WHERE `menu_name` = 'game_mine_test_uids' LIMIT 1
);

UPDATE `eb_system_config`
SET `value` = '0'
WHERE `menu_name` IN ('game_farm_test_enabled', 'game_mine_test_enabled')
  AND `value` NOT IN ('0', '1');

SELECT `menu_name`, `value`
FROM `eb_system_config`
WHERE `menu_name` IN (
  'game_farm_live_enabled',
  'game_mine_live_enabled',
  'game_farm_test_enabled',
  'game_farm_test_uids',
  'game_mine_test_enabled',
  'game_mine_test_uids'
)
ORDER BY `menu_name`;

COMMIT;
