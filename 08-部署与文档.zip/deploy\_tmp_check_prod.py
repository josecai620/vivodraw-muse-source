from pathlib import Path
for p in [
    "/opt/crmeb-prod/backend_src/app/services/yunmall/WalletService.php",
    "/opt/crmeb-prod/backend_src/route/api.php",
    "/opt/crmeb-prod/backend_src/app/services/user/UserMoneyServices.php",
]:
    t = Path(p).read_text(encoding="utf-8", errors="replace")
    print("==", p)
    print("pet_found", "pet_found_points" in t)
    print("pay_desk_pet", "pay_desk_pet" in t)
    print("claimUnlock", "claimUnlock" in t)
    print("post unlocks", "pet-world/unlocks" in t)
    if "pet-world/unlocks" in t:
        for i,line in enumerate(t.splitlines()):
            if "pet-world/unlocks" in line:
                print(i+1, line.strip())
