#!/bin/bash
# 通过 SSH 在远程服务器上清理 CRMEB 缓存
# 用法：bash deploy/remote_clear_cache.sh
# 前置：配置 deploy/remote_config（见 remote_config.example）

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
CONFIG="$SCRIPT_DIR/remote_config"

if [ ! -f "$CONFIG" ]; then
    echo "未找到 remote_config，请先配置："
    echo "  cp deploy/remote_config.example deploy/remote_config"
    echo "  编辑 deploy/remote_config 填入服务器和命令"
    exit 1
fi

source "$CONFIG"

if [ -z "$REMOTE_HOST" ] || [ -z "$REMOTE_CLEAR_CMD" ]; then
    echo "请在 remote_config 中设置 REMOTE_HOST 和 REMOTE_CLEAR_CMD"
    exit 1
fi

SSH_OPTS=()
[ -n "$REMOTE_SSH_KEY" ] && [ -f "${REMOTE_SSH_KEY/#\~/$HOME}" ] && SSH_OPTS=(-i "${REMOTE_SSH_KEY/#\~/$HOME}")
echo "正在连接 $REMOTE_HOST 执行: $REMOTE_CLEAR_CMD"
ssh "${SSH_OPTS[@]}" "$REMOTE_HOST" "$REMOTE_CLEAR_CMD"
exit $?
