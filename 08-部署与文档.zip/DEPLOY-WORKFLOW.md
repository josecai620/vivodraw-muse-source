# 开发与部署流程

更新日期：2026-09-17。云端作业以 GitHub `main` 为准。Windows 历史接手步骤见 [工作区更新说明](docs/Windows工作区更新与接手说明.md)。

## 当前基线

- 统一仓库：`https://github.com/josecai620/eccomall`，当前工作分支 `main`。
- 生产服务器：`root@186.241.72.176`，SSH 端口 `49375`，项目 `/opt/crmeb-prod`。
- 商城：`https://vivodraw.com`；公司官网：`https://altanexgroup.vip`。
- 用户前台源码 `mobile-app/`（v4，线上根路径）。`mobile-app-v3/` 保留停用，不要当默认改动入口。
- 后端 `backend_src/`，后台源码 `backend_src/view/admin/`；游戏 `game/`；云购改造 `yunmall-hybrid/`。
- 云端 Agent 不要 SSH、不要从服务器覆盖、不要提交 `.env` 与密钥。v4 发版脚本以 `yunmall-hybrid/STATUS.md` 为准（`dist-root → pack_root.py → remote-release-root.sh`），不要只看下面的 v3 脚本当现役入口。

## 工作区同步

云端：`git pull origin main` 即可。

本机跨机交接曾从 Gitee 获取 Mac 代码；当前远端已切到 GitHub。旧 Windows 独有改动先保留，参见工作区更新说明。后续开发前按 AGENTS.md 核对。先 `git status --short --branch` 判断改动归属；有未提交成果不得直接运行服务器同步覆盖。该脚本只负责服务器代码，不提供前台源码。云端不要跑同步脚本。

提交只选择本任务明确路径，禁止 `git add -A` 混入其他 Agent 成果。推送前 fetch 并同步当前分支，推送后复查 `HEAD...origin/当前分支` 为 `0 0`。

## 发布入口

前台从根目录运行：

```bash
./deploy-frontend.sh
```

当前入口转交 `deploy/deploy-frontend-v3.sh`；支持 `--support-page-only` 专门发布技术支持页面。不要使用旧 Uniapp 或旧 mobile-app 的脚本替换入口。

后端从根目录运行：

```bash
bash deploy/update_online.sh 186.241.72.176
```

运行前审查当前脚本的实际范围。禁止用生产目录 git pull/reset 替代发布。不得覆盖服务器 `.env`、数据库、上传、备份、运行态目录和 `public/install/install.lock`。不得未经明确授权执行线上 SQL、改服务器配置或重写 Git 历史。

## 最小验活

```bash
curl -I https://vivodraw.com/
curl -H "X-Client: mobile-app" https://vivodraw.com/api/category
```

首页和当时首页实际引用的 `/_expo/static/js/web/entry-*.js` 须 HTTP 200，分类接口 JSON 须 status=200；另检查本次具体变更流程。不要复用历史主 JS 文件名。

图片、视频、声音素材按用户要求不在当前 Git 中。Windows 发布前先补齐需要的资源并验证，不能在缺少资源时将不完整构建发布到线上。

## 历史资料与配置

旧文档中的其他服务器、GitHub 仓库、旧分支、旧前台目录不再作为当前入口。证书、DNS、数据库等现行配置需按任务只读核实；不把旧 SSL 事故说明当成当前环境结论。真实凭证单独保管，不写进仓库。
