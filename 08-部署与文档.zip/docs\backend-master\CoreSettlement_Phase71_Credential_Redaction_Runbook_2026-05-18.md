# CoreSettlement Phase71 Credential Redaction Runbook 2026-05-18

## Current Task

Phase71 defines credential redaction requirements for future SQL preflight and execution logs.

Runbook only.
No SQL was executed.
No production database connection was opened.

## Redaction Required

```text
DB password: always redact
full DSN with password: always redact
.env contents: never print
cookie/session/token/key: never print
command summary: allowed
credential-bearing command text: forbidden
```

## Exposure Response

```text
credential printed: stop
write incident note
assess rotation requirement
do not continue SQL execution
```

## Phase71 Guards

```text
credential_redaction_runbook_created: true
sql_executed: false
production_connection_opened: false
credentials_printed: false
database_writes: false
```
