-- 查询常规商城(2200)、商品(pid=1)、以及可能相关的菜单结构
SELECT id, pid, menu_name, menu_path, path, header, is_header, is_del
FROM eb_system_menus 
WHERE (pid = 2200 OR pid = 1 OR id = 1 OR id = 2200 OR id = 2201)
  AND is_del = 0
ORDER BY pid, sort, id;
