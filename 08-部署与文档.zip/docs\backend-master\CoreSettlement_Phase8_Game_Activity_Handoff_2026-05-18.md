# CoreSettlement Phase 8 Game Activity Handoff 2026-05-18

## Current Task

Phase 8 已完成农场、矿洞、每日任务接入 CoreSettlement 的后端旁路审计链路。

本轮只做服务层 shadow / 受控 ledger 审计，不执行 SQL，不跑 migration，不写生产 DB，不改 `game/` 或 `mobile-app/` 前端。

## Completed Commits

- `122aed30 backend: add game activity settlement shadow`
- `b374889b backend: fix game settlement write status`
- `4ab19d53 backend: assert game settlement write failure`
- `7d44755f backend: assert game settlement real write`

## Key Files

- `backend_src/app/services/core/GameActivitySettlementService.php`
- `backend_src/app/services/game/farm/FarmSettlementServices.php`
- `backend_src/app/services/game/mine/MineSettlementServices.php`
- `backend_src/scripts/game_activity_core_settlement_shadow_assert.php`
- `backend_src/scripts/game_activity_core_settlement_write_failure_assert.php`
- `backend_src/scripts/game_activity_core_settlement_real_write_assert.php`

## Integration Scope

### game_farm

Hook point:

- `FarmSettlementServices::writeLog()`

Covered actions:

- `plant`
- `harvest`
- `harvest_all`
- `steal`
- `guard`
- `purchase_mall_reward`
- other farm log actions with non-zero `pointsDelta`

Ledger scene:

- `game_farm`

Config switch:

- `core_settlement_game_farm_shadow`

### daily_task

Hook point:

- `FarmSettlementServices::writeLog()` when action is `claim_task`

Ledger scene:

- `daily_task`

Config switch:

- `core_settlement_daily_task_shadow`

Notes:

- Current daily task scope is farm task reward only.
- `MangheController` daily task logic remains untouched and forbidden.

### game_mine

Hook point:

- `MineSettlementServices::writeLog()`

Covered actions:

- `collect`
- `collect_all`
- `lab_claim`
- `worker_recall`
- `friend_assist`
- other mine log actions with non-zero `pointsDelta` or non-zero `item_delta`

Ledger scene:

- `game_mine`

Config switch:

- `core_settlement_game_mine_shadow`

## Behavior

Default behavior when switch is off:

- dry-run only
- no DB write from CoreSettlement
- legacy farm / mine paths keep working as before

When switch is on:

- writes only audit ledger through `LedgerService::writeRealLedger()`
- target logical table name is `core_settlement_ledger` through ThinkPHP table prefix
- does not grant points
- does not deduct inventory
- does not touch payment or order
- does not replace `eb_user_bill`

Failure behavior:

- real ledger write failure is swallowed and logged at result level
- result mode remains `dry_run_shadow`
- `guards.database_writes=false`
- legacy business result is not blocked

## Validation

Run from repo root:

```bash
php backend_src/scripts/game_activity_core_settlement_real_write_assert.php
php backend_src/scripts/game_activity_core_settlement_write_failure_assert.php
php backend_src/scripts/game_activity_core_settlement_shadow_assert.php
php backend_src/scripts/core_settlement_dry_run_assert.php
php backend_src/scripts/checkin_core_settlement_shadow_assert.php
php backend_src/scripts/pet_feed_core_settlement_shadow_assert.php
```

Latest confirmed:

- game activity real-write assert: 21/21
- game activity write-failure assert: 7/7
- game activity shadow assert: 22/22
- core dry-run assert: 20/20
- checkin shadow assert: 13/13
- pet feed shadow assert: 17/17
- `HEAD...origin/codex/pet-world-v2`: `0 0`

## Forbidden Areas

Do not touch without explicit approval:

- `backend_src/app/controller/api/v1/manghe/MangheController.php`
- payment
- order
- real inventory deduction
- SQL execution
- migration execution
- production DB
- server `.env`
- `game/*`
- `mobile-app/*`
- `mobile-app-v3/*`
- existing unrelated dirty worktree changes

## Dirty Worktree Notes

Current repo still has unrelated dirty work from other windows:

- `game/*`
- `mobile-app/*`
- `mobile-app-v3/*`
- `.gitignore`
- `AGENTS.md`
- untracked `deploy/fix_*.sql`
- deleted tracked docs under `docs/backend-master/*`

Backend Master must stage only explicit backend-master files and must not restore, delete, or commit unrelated changes unless acting as total sync controller with a new approval.

## Next Task

Phase 9 should be DB readiness review only.

Recommended next step:

1. Review whether `eb_core_settlement_ledger` exists in target environments.
2. Review whether config keys exist or need safe default insertion:
   - `core_settlement_game_farm_shadow`
   - `core_settlement_game_mine_shadow`
   - `core_settlement_daily_task_shadow`
3. Draft readonly SQL checks for table/config presence.
4. Do not execute SQL.
5. If execution is later approved, require backup path, target environment, rollback notes, and one switch at a time.

## NEXT WINDOW HANDOFF PACKAGE

- Role: Backend Master Controller
- Phase: Phase 9 DB readiness review
- Completed: Phase 8 game activity CoreSettlement shadow + real-write assertions
- Key Findings: farm/mine/daily task can be audited through CoreSettlement without changing frontend, payment, order, inventory, or Manghe
- Key Files: listed above
- Dirty Worktree Notes: unrelated game/mobile/v3/docs deletions remain; do not stage broad changes
- Forbidden Areas: payment/order/Manghe/SQL execution/migration/prod DB/game/mobile/v3
- Next Step: write readonly DB readiness review for `eb_core_settlement_ledger` and config switches
- Validation: run six PHP assert scripts listed above
- Risks: table/config may not exist in target env; real switches must stay off until DB readiness is confirmed
