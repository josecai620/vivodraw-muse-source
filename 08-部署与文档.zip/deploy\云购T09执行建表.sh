#!/usr/bin/env bash
# 云购 T09 建表执行脚本（需用户明确批准后再运行）
# 用法：ssh -p 49375 root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/云购T09执行建表.sh"
# 行为：先备份两张现役参与表的结构，再执行 deploy/云购T09建表-需批准后执行.sql，最后清应用缓存。
# 不覆盖 .env、上传文件、数据库其他表。

set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
SQL_FILE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/云购T09建表-需批准后执行.sql"
[[ -f "$SQL_FILE" ]] || { echo "找不到 SQL 文件：$SQL_FILE"; exit 1; }

ENV_FILE="${PROJECT_DIR}/backend_src/.env"
read_env() { grep -E "^\s*$1\s*=" "$ENV_FILE" 2>/dev/null | head -1 | sed 's/^[^=]*=\s*//; s/^["'"'"']//; s/["'"'"']\s*$//; s/\s*$//'; }
DB_HOST="$(read_env HOSTNAME)"; DB_HOST="${DB_HOST:-127.0.0.1}"
DB_PORT="$(read_env HOSTPORT)"; DB_PORT="${DB_PORT:-3306}"
DB_NAME="$(read_env DATABASE)"
DB_USER="$(read_env USERNAME)"
DB_PASS="$(read_env PASSWORD)"
[[ -n "$DB_NAME" && -n "$DB_USER" ]] || { echo "读取 backend_src/.env 数据库配置失败"; exit 1; }

BACKUP_DIR="${PROJECT_DIR}/db_backup"
mkdir -p "$BACKUP_DIR"
STAMP="$(date +%Y%m%d-%H%M%S)"

run_mysql() {
  if command -v mysql >/dev/null 2>&1; then
    MYSQL_PWD="$DB_PASS" mysql -u"$DB_USER" -h"$DB_HOST" -P"$DB_PORT" --default-character-set=utf8mb4 "$DB_NAME" "$@"
    return
  fi
  local c
  c="$(docker ps --format '{{.Names}}' | grep -Ei 'mysql|mariadb' | head -1 || true)"
  [[ -n "$c" ]] || { echo "本机没有 mysql 客户端，也没有 mysql 容器；请手动执行 SQL"; exit 1; }
  docker exec -i "$c" mysql -u"$DB_USER" -p"$DB_PASS" --default-character-set=utf8mb4 "$DB_NAME" "$@"
}

echo "==> 备份现役参与表结构到 ${BACKUP_DIR}/云购T09前-表结构-${STAMP}.sql"
if command -v mysqldump >/dev/null 2>&1; then
  MYSQL_PWD="$DB_PASS" mysqldump -u"$DB_USER" -h"$DB_HOST" -P"$DB_PORT" --no-data \
    "$DB_NAME" eb_store_integral_product_huanqu_log eb_store_integral_product_huanqu_log_unique \
    > "${BACKUP_DIR}/云购T09前-表结构-${STAMP}.sql"
else
  echo "（没有 mysqldump，跳过结构备份；SQL 本身只建新表和改索引，不删数据）"
fi

echo "==> 执行 ${SQL_FILE}"
run_mysql < "$SQL_FILE"

echo "==> 核对七张新表"
run_mysql -N -e "SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name IN ('eb_wallet_request','eb_cloud_buy_request','eb_cloud_buy_code_pool','eb_lucky_value_log','eb_draw_snapshot','eb_draw_snapshot_input','eb_store_integral_cart') ORDER BY table_name"

echo "==> 清应用缓存（切换 CloudBuyService 新路径的开关读的是表是否存在，缓存 60 秒）"
docker exec crmeb-php-fpm sh -c 'cd /var/www/backend && php think clear' 2>/dev/null || true
echo "==> 完成。60 秒内 exchange / exchange_all 自动切到新路径。"
