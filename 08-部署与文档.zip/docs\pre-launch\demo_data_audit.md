# 上线前演示数据审计

**审计时间**：2026-04-20
**目标环境**：生产服 `8.166.115.27` DB `manghehoutai_qhe`
**执行人**：审计完成 / **清理 SQL 待 joe 确认后手动执行**

---

## 结论速览

| 类别 | 表 | 当前记录 | 建议操作 |
|------|------|---------|---------|
| 拼团抽奖 demo 活动 | `eb_group_lottery` | 3 | 🗑 删 |
| 拼团抽奖 demo 开团 | `eb_group_lottery_pink` | 3 | 🗑 删（级联） |
| 拼团抽奖机器人（中文名） | `eb_group_lottery_robot` | 20 | 🗑 **必删**（小明/阿花/大壮） |
| 拼团抽奖 demo 成员 | `eb_group_lottery_member` | 5 | 🗑 删（级联） |
| 幸运抽奖 demo（"测试"/"aaa"） | `eb_luck_lottery` | 4 | 🗑 删 |
| 拼团 demo 商品 | `eb_store_combination` | 1 | ⚠️ 人工确认（只有 1 条，可能是示例） |
| 盲盒 demo 活动 | `eb_box_activity` | 1 | ⚠️ 人工确认（只有 1 条） |
| 秒杀 | `eb_store_seckill` | 0 | — 已空 |
| 店铺拼团 | `eb_store_pink` | 0 | — 已空 |
| Pet FAQ 中文种子 | `eb_pet_faq` | 9 中文 + 1 英文 | 🗑 **必换**（目前是中文示例 FAQ） |
| Pet Flow 引导 | `eb_pet_flow` | 3 | ✅ 保留（标题已英文，trigger_words 双语 OK） |
| 用户盲盒 | `eb_user_box` | 352,077 | ⛔ **切勿删除**（真实用户资产） |

---

## 详细证据

### 1. `eb_group_lottery` — 3 条明显 demo

```
id=1  iPhone 16 Pro Max 256GB 钛色拼团抽奖   status=1
id=2  AirPods Pro 2 无线降噪耳机拼团          status=1
id=3  Starbucks $50 电子券拼团（入门体验）    status=1
```

中文标题 + 品牌示例商品，**严禁上线**。

### 2. `eb_group_lottery_robot` — 20 个中文机器人

```
id=1  小明     is_active=1
id=2  阿花     is_active=1
id=3  大壮     is_active=1
id=4  甜甜     is_active=1
...
```

美国市场**绝对不能留中文机器人**。要换就用英文名（Alex/Jessica/Chris...），数量可以保留 20。

### 3. `eb_luck_lottery` — 4 条测试数据

```
id=1  测试  type=1  status=0
id=2  测试  type=1  status=1
id=4  aaa   type=1  status=0
id=5  aaa   type=1  status=1
```

名字就是 "测试" / "aaa"，开发时留的。

### 4. `eb_pet_faq` — 9 中文 + 1 英文混杂

前 9 条全中文（"网站有哪些功能？"、"积分怎么拿？" 等），第 10 条开始英文。
**必须全部替换为英文 FAQ**（主语言）+ 繁中版本（副语言），符合 i18n 硬约束。

### 5. `eb_pet_flow` — 3 条引导（✅ OK）

```
id=1  Blind Box Tour          trigger: box_flow,开盲盒教程,盲盒教程
id=2  Group Lottery Tour      trigger: group_lottery_flow,拼团抽奖教程
id=3  Points Redemption Tour  trigger: points_flow,积分兑换教程
```

标题已英文；trigger_words 双语是设计需要（中英用户都能触发），**保留**。

---

## 清理 SQL（待人工确认后执行）

> ⚠️ 执行前务必 `mysqldump` 整库备份。每条命令都写成幂等、可独立审阅的形式。

```sql
-- 备份命令（shell，非 SQL）：
-- ssh root@8.166.115.27 "mysqldump -uroot manghehoutai_qhe > /opt/crmeb-prod/backup_pre_demo_purge_$(date +%Y%m%d).sql"

USE manghehoutai_qhe;

-- 1. 拼团抽奖整链级联清理（先清子表）
DELETE FROM eb_group_lottery_member WHERE lottery_id IN (1, 2, 3);
DELETE FROM eb_group_lottery_pink   WHERE lottery_id IN (1, 2, 3);
DELETE FROM eb_group_lottery        WHERE id IN (1, 2, 3);

-- 2. 机器人清空（上线前要换英文名种子）
-- 暂不保留，待替换方案确定再 INSERT 新数据
DELETE FROM eb_group_lottery_robot;

-- 3. 幸运抽奖测试记录
DELETE FROM eb_luck_lottery_record WHERE lottery_id IN (1, 2, 4, 5);
DELETE FROM eb_luck_lottery        WHERE id IN (1, 2, 4, 5);

-- 4. Pet FAQ — 全表清空后用英文种子重建
--   （英文种子由 joe 提供后再写 INSERT）
DELETE FROM eb_pet_faq;
-- 后续 INSERT 新英文 FAQ ...

-- 5. 以下两条单条 demo，建议人工通过后台管理页面检查截图后再删：
--   - eb_store_combination (1 条拼团商品，看 product_id 是否真实商品)
--   - eb_box_activity     (1 条盲盒活动，看 title 是否示例)
-- 不在自动脚本里处理。

-- 6. 事后验证
SELECT COUNT(*) AS group_lottery_remain FROM eb_group_lottery;
SELECT COUNT(*) AS pink_remain          FROM eb_group_lottery_pink;
SELECT COUNT(*) AS robot_remain         FROM eb_group_lottery_robot;
SELECT COUNT(*) AS luck_remain          FROM eb_luck_lottery;
SELECT COUNT(*) AS pet_faq_remain       FROM eb_pet_faq;
-- 期望全 0
```

---

## 待办（上线前闭环）

- [ ] joe 确认 `eb_store_combination.id=1` 和 `eb_box_activity.id=1` 是不是 demo（命中就删）
- [ ] 提供 **英文版 Pet FAQ 种子**（至少 10 条），我来写 INSERT
- [ ] 提供 **英文机器人昵称列表**（20 个），我来写 INSERT
- [ ] 执行清理 SQL 前必须先 `mysqldump` 备份
- [ ] 清完后在 AdminUI 视觉验证拼团/抽奖/盲盒专区无 demo 痕迹
