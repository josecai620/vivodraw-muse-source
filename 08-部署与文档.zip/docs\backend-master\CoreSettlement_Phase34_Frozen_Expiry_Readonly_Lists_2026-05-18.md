# CoreSettlement Phase 34 Frozen Expiry Readonly Lists 2026-05-18

## Current Task

Phase 34 adds readonly frozen point and expiry batch list contracts.

No route exposure was added.
No DB table query was added.
No DB write was added.
No freeze/unfreeze mutation was added.
No expiry execution was added.
No production deployment was executed.

## Implementation

Updated:

```text
backend_src/app/services/core/PointGatewayAdminReadService.php
backend_src/app/services/core/contracts/PointGatewayAdminReadServiceInterface.php
backend_src/app/controller/admin/v1/core/PointGateway.php
backend_src/scripts/point_gateway_admin_read_assert.php
backend_src/scripts/point_gateway_admin_controller_assert.php
backend_src/scripts/point_gateway_admin_route_contract_assert.php
backend_src/scripts/core_settlement_backend_package_assert.php
docs/backend-master/CoreSettlement_Phase29_Point_Admin_Route_Contract_2026-05-18.md
```

## Readonly Surfaces

Added service methods:

```text
frozenPoints(filters, page, limit)
expiryBatches(filters, page, limit)
```

Added controller methods:

```text
frozen_points()
expiry_batches()
```

Current data source:

```text
DryRunPointTransactionStore transactions
```

Explicit reason markers:

```text
freeze_table_not_connected
expiry_table_not_connected
```

## Guard

```text
route exposed=false
database writes=false
mutation endpoints=false
rollback execution=false
expiry execution=false
production deploy=false
```

## Validation

Passed:

```bash
php backend_src/scripts/point_gateway_admin_read_assert.php
php backend_src/scripts/point_gateway_admin_controller_assert.php
php backend_src/scripts/point_gateway_admin_route_contract_assert.php
php backend_src/scripts/core_settlement_backend_package_assert.php
```

Note:

```text
direction=expense now includes deduct and expire in the readonly fixture.
```

## Not Done

- no route exposure
- no DB-backed frozen table query
- no DB-backed expiry table query
- no unfreeze button
- no expiry execution
- no export

## Next Step

Phase 35 should add AI operation log draft contract, still readonly/no route exposure.
