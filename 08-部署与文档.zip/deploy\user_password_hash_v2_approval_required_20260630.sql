-- VivoDraw user password hash v2 migration.
-- Approval required: do not auto-run from deploy scripts.
--
-- Purpose:
-- 1. Expand eb_user.pwd so bcrypt/password_hash() output is not truncated.
-- 2. Enable the explicit app switch only after the column length is verified.
--
-- Rollback note:
-- Do not shrink eb_user.pwd back to varchar(32). That would destroy any upgraded
-- bcrypt hashes. To disable v2 hashing, set user_password_hash_v2_enabled to 0.

ALTER TABLE `eb_user`
  MODIFY COLUMN `pwd` varchar(100) NOT NULL DEFAULT '' COMMENT '用户密码';

INSERT INTO `eb_system_config`
  (`is_store`, `menu_name`, `type`, `input_type`, `config_tab_id`, `parameter`, `upload_type`, `required`, `width`, `high`, `value`, `info`, `desc`, `sort`, `status`)
VALUES
  (0, 'user_password_hash_v2_enabled', 'radio', 'input', 0, '0=>关闭\n1=>开启', 0, '', 100, 0, '1', '用户密码强哈希开关', '仅在 eb_user.pwd 字段长度 >= 60 后开启', 0, 0)
ON DUPLICATE KEY UPDATE
  `value` = '1',
  `parameter` = VALUES(`parameter`),
  `info` = VALUES(`info`),
  `desc` = VALUES(`desc`);

SELECT
  TABLE_SCHEMA,
  TABLE_NAME,
  COLUMN_NAME,
  CHARACTER_MAXIMUM_LENGTH
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'eb_user'
  AND COLUMN_NAME = 'pwd';

SELECT `menu_name`, `value`
FROM `eb_system_config`
WHERE `menu_name` = 'user_password_hash_v2_enabled';
