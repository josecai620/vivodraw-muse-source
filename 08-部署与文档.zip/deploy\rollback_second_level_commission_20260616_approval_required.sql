-- Rollback helper for deploy/disable_second_level_commission_20260616.sql.
--
-- APPROVAL REQUIRED.
-- Only run if the platform intentionally restores two-level commission.

SELECT 'before_rollback' AS phase, menu_name, value
FROM eb_system_config
WHERE menu_name IN ('brokerage_level', 'store_brokerage_two', 'store_brokerage_ratio')
ORDER BY menu_name;

UPDATE eb_system_config
SET value = '"2"'
WHERE menu_name = 'brokerage_level';

UPDATE eb_system_config
SET value = '"5"'
WHERE menu_name = 'store_brokerage_two';

SELECT 'after_rollback' AS phase, menu_name, value
FROM eb_system_config
WHERE menu_name IN ('brokerage_level', 'store_brokerage_two', 'store_brokerage_ratio')
ORDER BY menu_name;
