# CoreSettlement Phase66 Operator Stop Conditions Matrix 2026-05-18

## Current Task

Phase66 prepares the operator stop conditions matrix for future approved SQL execution.

Matrix only.
No SQL was executed.
No production database connection was opened.
No deployment was executed.

## Stop Conditions

```text
approval missing: stop
approval ambiguous: stop
checksum mismatch: stop
backup missing: stop
restore path unknown: stop
readonly precheck missing: stop
target table already exists unexpectedly: stop
forbidden SQL marker found: stop
credentials printed: stop
mysql error: stop
partial table creation: stop
postcheck mismatch: stop
dirty worktree unclear: stop
```

## No-Retry Rule

```text
do not edit SQL inline
do not retry after mysql error
do not continue after partial state
do not fix forward without a new review
```

## Phase66 Guards

```text
operator_stop_conditions_matrix_created: true
sql_executed: false
production_connection_opened: false
database_writes: false
deployment_executed: false
```
