#!/usr/bin/env bash
# 在服务器上执行，添加「排版管理」菜单到后台
# 用法：bash deploy/run_add_layout_menu.sh
# 或从本机：ssh root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/run_add_layout_menu.sh"
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/opt/crmeb-prod}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SQL_FILE="${SCRIPT_DIR}/add_layout_menu.sql"

# 从 docker-compose 或 backend .env 获取数据库配置
for envf in "${PROJECT_DIR}/.env" "${PROJECT_DIR}/backend_src/.env"; do
  if [[ -f "${envf}" ]]; then
    set -a
    # shellcheck disable=SC1090
    source "${envf}" 2>/dev/null || true
    set +a
    break
  fi
done

# 兼容不同 env 变量名
MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-${MYSQL_PASSWORD:-${PASSWORD:-}}}"
MYSQL_DATABASE="${MYSQL_DATABASE:-${DATABASE:-}}"

if [[ -z "${MYSQL_ROOT_PASSWORD}" || -z "${MYSQL_DATABASE}" ]]; then
  echo "请设置 MYSQL_ROOT_PASSWORD 和 MYSQL_DATABASE 环境变量，或确保 .env 中存在"
  echo "也可手动执行: docker exec -i crmeb-mysql mysql -uroot -p<密码> <数据库名> < ${SQL_FILE}"
  exit 1
fi

if [[ ! -f "${SQL_FILE}" ]]; then
  echo "未找到 ${SQL_FILE}"
  exit 1
fi

echo "==> 添加「排版管理」菜单到数据库 ${MYSQL_DATABASE}"
docker exec -i crmeb-mysql mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" "${MYSQL_DATABASE}" < "${SQL_FILE}"
echo "==> 完成。请刷新后台页面，点击顶部「装修」→ 左侧应出现「排版管理」"
