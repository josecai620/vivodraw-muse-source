#!/usr/bin/env bash
# Atomic, isolated release for the v4 preview frontend.
# Args: BASE TS [KEEP]
# Uploaded and executed by deploy-frontend-v4.ps1. Never writes live paths.
set -euo pipefail

BASE="$1"
TS="$2"
KEEP="${3:-5}"

for F in /opt/crmeb-prod/frontend-v3-root /opt/crmeb-prod/backend_src/public /opt/crmeb-prod/frontend-v2 /opt/crmeb-prod/frontend-v3-preview; do
  case "$BASE" in
    "$F"|"$F"/*) echo "REFUSE_LIVE_PATH $BASE"; exit 2;;
  esac
done

test -f "$BASE/v4-bundle.tar.gz"
mkdir -p "$BASE/releases/$TS"
tar -xzf "$BASE/v4-bundle.tar.gz" -C "$BASE/releases/$TS"
test -f "$BASE/releases/$TS/index.html"
test -d "$BASE/releases/$TS/_expo"
grep -q '/v4/_expo' "$BASE/releases/$TS/index.html"

# atomic symlink swap
ln -sfn "releases/$TS" "$BASE/current"

# prune old releases, keep newest KEEP
cd "$BASE/releases"
ls -1dt */ 2>/dev/null | tail -n "+$((KEEP+1))" | while IFS= read -r d; do rm -rf "$d"; done

rm -f "$BASE/v4-bundle.tar.gz"
echo "V4_RELEASED=$TS"
readlink -f "$BASE/current"
find "$BASE/current/_expo/static/js/web" -maxdepth 1 -name 'entry-*.js' | head -n 1
