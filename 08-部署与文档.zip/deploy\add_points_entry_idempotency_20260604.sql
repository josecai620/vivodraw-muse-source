-- Points entry idempotency patch.
-- Safe to rerun. Adds only the client request key used to prevent duplicate point deductions.

SET @schema_name = DATABASE();

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log` ADD COLUMN `client_request_id` varchar(64) DEFAULT NULL COMMENT ''Client idempotency key'' AFTER `is_jiqiren`',
    'SELECT ''eb_store_integral_product_huanqu_log.client_request_id exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name
    AND TABLE_NAME = 'eb_store_integral_product_huanqu_log'
    AND COLUMN_NAME = 'client_request_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log` ADD UNIQUE KEY `uniq_uid_client_request_id` (`uid`, `client_request_id`)',
    'SELECT ''eb_store_integral_product_huanqu_log.uniq_uid_client_request_id exists''')
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = @schema_name
    AND TABLE_NAME = 'eb_store_integral_product_huanqu_log'
    AND INDEX_NAME = 'uniq_uid_client_request_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
