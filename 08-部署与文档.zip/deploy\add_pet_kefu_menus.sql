-- ============================================================
-- 宠物客服 后台菜单 + 权限（顶级菜单版）
-- 父菜单 "宠物客服" 为顶级 header='pet_kefu'，与 营销/设置 同级
-- 执行：mysql -u用户 -p 数据库 < 本文件
-- 幂等：使用 NOT EXISTS 判断，可重复执行
-- ============================================================
SET NAMES utf8mb4;

-- 1. 父菜单（顶级）：宠物客服
-- type=1 / pid=0 / header=pet_kefu / is_header=1 / sort=-10（排在设置右边最末）
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 0, 1, 'md-paw', '宠物客服', 'admin', '', '', '', 'GET', '[]', -10, 1, 0, 1, '/admin/pet_kefu', '1', 1, 'pet_kefu', 1, 'admin-marketing-pet_kefu', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `unique_auth` = 'admin-marketing-pet_kefu' AND `is_del` = 0);

SET @pet_pid = (SELECT `id` FROM `eb_system_menus` WHERE `unique_auth` = 'admin-marketing-pet_kefu' AND `is_del` = 0 LIMIT 1);

-- 2. 基础配置
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @pet_pid, 1, 'md-settings', '基础配置', 'admin', 'marketing.pet_kefu.PetKefuAdmin', 'config', 'marketing/pet_kefu/config', 'GET', '[]', 10, 1, 1, 1, '/admin/pet_kefu/config', '1', 1, 'pet_kefu', 0, 'marketing-pet_kefu-config', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `unique_auth` = 'marketing-pet_kefu-config' AND `is_del` = 0);

-- 3. FAQ 管理
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @pet_pid, 1, 'md-help-circle', 'FAQ 管理', 'admin', 'marketing.pet_kefu.PetKefuAdmin', 'faqList', 'marketing/pet_kefu/faq', 'GET', '[]', 20, 1, 1, 1, '/admin/pet_kefu/faq', '1', 1, 'pet_kefu', 0, 'marketing-pet_kefu-faq', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `unique_auth` = 'marketing-pet_kefu-faq' AND `is_del` = 0);

-- 4. 引导流程
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @pet_pid, 1, 'md-map', '引导流程', 'admin', 'marketing.pet_kefu.PetKefuAdmin', 'flowList', 'marketing/pet_kefu/flow', 'GET', '[]', 30, 1, 1, 1, '/admin/pet_kefu/flow', '1', 1, 'pet_kefu', 0, 'marketing-pet_kefu-flow', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `unique_auth` = 'marketing-pet_kefu-flow' AND `is_del` = 0);

-- 5. 触发规则
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @pet_pid, 1, 'md-notifications', '主动触发', 'admin', 'marketing.pet_kefu.PetKefuAdmin', 'triggerList', 'marketing/pet_kefu/trigger', 'GET', '[]', 40, 1, 1, 1, '/admin/pet_kefu/trigger', '1', 1, 'pet_kefu', 0, 'marketing-pet_kefu-trigger', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `unique_auth` = 'marketing-pet_kefu-trigger' AND `is_del` = 0);

-- 6. 对话记录 / 统计
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @pet_pid, 1, 'md-chatbubbles', '对话记录', 'admin', 'marketing.pet_kefu.PetKefuAdmin', 'sessionList', 'marketing/pet_kefu/session_log', 'GET', '[]', 50, 1, 1, 1, '/admin/pet_kefu/statistics', '1', 1, 'pet_kefu', 0, 'marketing-pet_kefu-log', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `unique_auth` = 'marketing-pet_kefu-log' AND `is_del` = 0);

-- 超级管理员权限（仅在 rules 为空时才覆盖为 *）
UPDATE `eb_system_admin` SET `level` = 0, `roles` = '1' WHERE `account` = 'admin' AND `is_del` = 0;
UPDATE `eb_system_role` SET `rules` = '*' WHERE `id` = 1 AND `status` = 1 AND (IFNULL(`rules`,'') = '' OR `rules` IS NULL);

-- 查看结果
SELECT `id`, `pid`, `menu_name`, `menu_path`, `type`, `header`, `unique_auth`, `is_show`, `is_del`
FROM `eb_system_menus`
WHERE `unique_auth` LIKE '%pet_kefu%'
  AND `is_del` = 0
ORDER BY `pid`, `sort`, `id`;
