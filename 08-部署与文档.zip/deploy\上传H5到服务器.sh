#!/usr/bin/env bash
# 把本机 H5 发行结果上传到服务器 public（请先在 HBuilderX 中：发行 → 网站-H5）
# 用法：双击运行，或在终端执行：./deploy/上传H5到服务器.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
# 未指定时优先用 npm 构建产出 h5，其次 HBuilderX 产出 web
if [[ -z "${H5_OUTPUT:-}" ]]; then
  for dir in "backend_src/view/uniapp/unpackage/dist/build/h5" "backend_src/view/uniapp/unpackage/dist/build/web"; do
    if [[ -d "${PROJECT_ROOT}/${dir}" ]] && [[ -f "${PROJECT_ROOT}/${dir}/index.html" ]]; then
      H5_OUTPUT="${PROJECT_ROOT}/${dir}"
      break
    fi
  done
fi
H5_OUTPUT="${H5_OUTPUT:-${PROJECT_ROOT}/backend_src/view/uniapp/unpackage/dist/build/web}"
SERVER="root@186.241.72.176"
REMOTE_DIR="/opt/crmeb-prod/backend_src/public"
BACKUP_BASE="/opt/crmeb-prod/deploy_backups"
ROLLBACK_DIR=""

if [[ ! -d "${H5_OUTPUT}" ]] || [[ ! -f "${H5_OUTPUT}/index.html" ]]; then
  echo "❌ 未找到 H5 发行结果。请先执行：bash deploy/构建并上传H5.sh（或 HBuilderX 发行 → 网站-H5）"
  echo "   预期路径：.../unpackage/dist/build/h5 或 .../web"
  echo "   自定义：H5_OUTPUT=/你的/h5/路径 bash deploy/上传H5到服务器.sh"
  exit 1
fi

echo "==> 正在上传 H5 到服务器（需输入 root 密码）..."
echo "==> 备份线上前台静态资源..."
ROLLBACK_DIR="${BACKUP_BASE}/h5_frontend_$(date +%Y%m%d_%H%M%S)"
ssh "${SERVER}" "
  set -e
  mkdir -p '${ROLLBACK_DIR}'
  mkdir -p '${REMOTE_DIR}'
  [ -f '${REMOTE_DIR}/index.html' ] && cp -a '${REMOTE_DIR}/index.html' '${ROLLBACK_DIR}/index.html' || true
  [ -d '${REMOTE_DIR}/_expo' ] && cp -a '${REMOTE_DIR}/_expo' '${ROLLBACK_DIR}/_expo' || true
  [ -d '${REMOTE_DIR}/assets' ] && cp -a '${REMOTE_DIR}/assets' '${ROLLBACK_DIR}/assets' || true
"

rsync -avz "${H5_OUTPUT}/" "${SERVER}:${REMOTE_DIR}/"

echo "==> 发布后验活..."
HTML="$(curl -fsS "http://186.241.72.176/")" || true
ENTRY="$(python3 -c "import re,sys; html=sys.stdin.read(); m=re.search(r'(_expo/static/js/web/entry-[a-f0-9]+\\.js)', html); print(m.group(1) if m else '')" <<< "${HTML}")"
if [[ -n "${ENTRY}" ]]; then
  curl -fsS -I "http://186.241.72.176/${ENTRY}" >/dev/null || {
    echo "❌ 验活失败，开始自动回滚..."
    ssh "${SERVER}" "
      set -e
      [ -f '${ROLLBACK_DIR}/index.html' ] && cp -a '${ROLLBACK_DIR}/index.html' '${REMOTE_DIR}/index.html' || true
      if [ -d '${ROLLBACK_DIR}/_expo' ]; then
        rm -rf '${REMOTE_DIR}/_expo'
        cp -a '${ROLLBACK_DIR}/_expo' '${REMOTE_DIR}/_expo'
      fi
      if [ -d '${ROLLBACK_DIR}/assets' ]; then
        rm -rf '${REMOTE_DIR}/assets'
        cp -a '${ROLLBACK_DIR}/assets' '${REMOTE_DIR}/assets'
      fi
    "
    exit 1
  }
fi

echo ""
echo "✅ 上传完成。请访问 http://186.241.72.176/ 或 http://186.241.72.176/static/html/pc.html 验证。"
