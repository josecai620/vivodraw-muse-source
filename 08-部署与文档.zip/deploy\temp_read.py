# -*- coding: utf-8 -*-
import io, os
base = r'D:\eccomall\mobile-app-v3\features\积分购买'
for p in ['充值返回.ts']:
    s = io.open(os.path.join(base, p), encoding='utf-8').read()
    print('=' * 25, p, len(s))
    print(s)
