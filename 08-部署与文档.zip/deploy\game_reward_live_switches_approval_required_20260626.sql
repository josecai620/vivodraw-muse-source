-- Approval-required live-service switches for farm/mine.
-- Run only after:
--   1. deploy/db_audit_game_rewards_readonly_20260626.sql passes,
--   2. farm/mine table migrations are verified,
--   3. owner approves production writes.
--
-- This script creates explicit OFF switches. It does not enable live rewards.

START TRANSACTION;

INSERT INTO `eb_system_config`
  (`is_store`, `menu_name`, `type`, `input_type`, `config_tab_id`, `parameter`, `value`, `info`, `desc`, `sort`, `status`)
SELECT
  0,
  'game_farm_live_enabled',
  'radio',
  'radio',
  0,
  '0=>Off\n1=>On',
  '0',
  'Farm live service switch',
  'Keep 0 until reward DB, idempotency, daily cap, and audit SQL pass.',
  0,
  1
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_system_config` WHERE `menu_name` = 'game_farm_live_enabled' LIMIT 1
);

INSERT INTO `eb_system_config`
  (`is_store`, `menu_name`, `type`, `input_type`, `config_tab_id`, `parameter`, `value`, `info`, `desc`, `sort`, `status`)
SELECT
  0,
  'game_mine_live_enabled',
  'radio',
  'radio',
  0,
  '0=>Off\n1=>On',
  '0',
  'Mine live service switch',
  'Keep 0 until reward DB, idempotency, daily cap, and audit SQL pass.',
  0,
  1
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_system_config` WHERE `menu_name` = 'game_mine_live_enabled' LIMIT 1
);

UPDATE `eb_system_config`
SET `value` = '0'
WHERE `menu_name` IN ('game_farm_live_enabled', 'game_mine_live_enabled');

SELECT `menu_name`, `value`
FROM `eb_system_config`
WHERE `menu_name` IN ('game_farm_live_enabled', 'game_mine_live_enabled')
ORDER BY `menu_name`;

COMMIT;

-- Final live enable is intentionally not included.
-- If all launch gates pass and owner approves, enable with a separate scoped SQL:
-- UPDATE `eb_system_config` SET `value` = '1' WHERE `menu_name` IN ('game_farm_live_enabled', 'game_mine_live_enabled');
