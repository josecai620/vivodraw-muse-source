#!/usr/bin/env bash
# Prepare legacy V3 build for serving under /v3/ without rebuilding:
# copy the root-built V3 export and rewrite absolute asset prefixes
# (/_expo/ -> /v3/_expo/, /assets/ -> /v3/assets/) in html/js/css.
# Idempotent: rebuilds frontend-v3/current from frontend-v3-root/current.
set -euo pipefail

SRC=/opt/crmeb-prod/frontend-v3-root/current
DST=/opt/crmeb-prod/frontend-v3/current

test -f "$SRC/index.html" || { echo "FATAL: v3 source missing: $SRC"; exit 1; }

rm -rf "$DST"
mkdir -p "$DST"
cp -a "$SRC/." "$DST/"

# Rewrite runtime asset references. Run once on a fresh copy, so prefixing once is correct.
find "$DST" -type f \( -name '*.html' -o -name '*.js' -o -name '*.css' \) -print0 \
  | xargs -0 sed -i -e 's#/_expo/#/v3/_expo/#g' -e 's#/assets/#/v3/assets/#g'

# Self-check: no bare root-absolute expo references may remain in entry HTML/JS.
LEFT=$(grep -rl -F '"/_expo/' "$DST" 2>/dev/null | wc -l)
if [ "$LEFT" -ne 0 ]; then
  echo "FATAL: $LEFT files still contain bare /_expo references"
  grep -rl -F '"/_expo/' "$DST" | head
  exit 1
fi

echo "v3 subpath copy ready at $DST"
du -sh "$DST"
