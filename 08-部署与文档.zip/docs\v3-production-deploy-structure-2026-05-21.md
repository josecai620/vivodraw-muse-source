# v3 Production Deploy Structure (2026-05-21)

## Current Routing

- Main site: `https://vivodraw.com/` -> v3 static frontend.
- Legacy v2: `https://vivodraw.com/v2/` -> old v2 frontend.
- API: `https://vivodraw.com/api/` -> PHP backend on `127.0.0.1:20199`.
- Admin APIs: `https://vivodraw.com/adminapi/` -> PHP backend on `127.0.0.1:20199`.
- Temporarily closed game routes:
  - `/curator-run` -> `404`
  - `/prize-atelier` -> `404`

Desktop pet and mini-game routes are not part of the v3 production deploy until their owners hand off finished pages.

## Server Paths

- Server: `root@8.166.115.27`
- Stable deploy SSH port: `2222`
- v3 static root: `/opt/crmeb-prod/frontend-v3-root/current`
- v3 backup parent: `/opt/crmeb-prod/frontend-v3-root/`
- v2 static root: `/opt/crmeb-prod/frontend-v2/current`
- backend public root: `/opt/crmeb-prod/backend_src/public`
- nginx enabled configs:
  - `/etc/nginx/sites-enabled/default`
  - `/etc/nginx/sites-enabled/vivodraw.com.conf`
- nginx v3 dynamic-route snippet:
  - `/etc/nginx/snippets/v3-dynamic-routes.conf`
- nginx manual backups: `/etc/nginx/codex-backups/`

Do not upload v3 files into `/opt/crmeb-prod/backend_src/public`.

## Deploy Command

Build v3 locally and rsync static files to the server:

```bash
cd /Users/joe/eccomall
EXPO_PUBLIC_API_BASE_URL=https://vivodraw.com ./deploy/deploy-frontend-v3.sh
```

Defaults in `deploy/deploy-frontend-v3.sh`:

- server: `8.166.115.27`
- user: `root`
- ssh port: `2222`
- remote v3 dir: `/opt/crmeb-prod/frontend-v3-root/current`
- remote backup before upload: `/opt/crmeb-prod/frontend-v3-root/backup-before-v3-deploy-YYYYMMDDHHMMSS`

Override only when necessary:

```bash
DEPLOY_SSH_PORT=2222 REMOTE_V3_DIR=/opt/crmeb-prod/frontend-v3-root/current ./deploy/deploy-frontend-v3.sh
```

## Verification

After deploy:

```bash
curl -I https://vivodraw.com/
curl -I https://vivodraw.com/v2/
curl -s -H "X-Client: mobile-app" https://vivodraw.com/api/category
curl -I https://vivodraw.com/curator-run
curl -I https://vivodraw.com/prize-atelier
```

Expected:

- `/` returns `200`.
- `/v2/` returns `200`.
- `/api/category` returns JSON with `status=200`.
- `/curator-run` and `/prize-atelier` return `404` until those pages are officially handed off.
- Dynamic v3 pages such as `/product/:id`, `/box/:id`, `/points/:id`, and `/orders/:id` must serve their Expo static `[id].html` files, not fall back to `/index.html`.
- Directory index pages that also have dynamic children, such as `/points` and `/box`, must serve their own `index.html`, not the sibling `[id].html`.

## Operating Rules

- Build on the Mac, not on the 2C/2G server.
- Deploy only static files through rsync.
- Keep v3 and v2 physically separate.
- Keep backend `.env`, uploads, database, backups, and runtime files untouched.
- When the working tree contains active desktop pet or game changes, build from a clean Git commit or a clean worktree, not from the dirty tree.
- Do not re-enable `/curator-run` or `/prize-atelier` until their developers hand off final v3 pages.
