# WebSocket 推送协议约定（方案 A）

**状态**：阶段 1.2 定稿 / 阶段 1.4 端到端验证
**适用范围**：ECCOMALL 前后端 WebSocket 实时推送，基于 Pusher 协议 + Soketi 服务

---

## 协议栈

```
[ 业务代码 ]
   │  SocketPush::admin()->to(5)->type('NEW_ORDER')->data([...])->push()
   ▼
[ SocketPushAdapter ]
   │  RedisBroadcastPushAdapter::push()
   ▼
[ Redis PUBLISH ]
   │  channel: "{APP_ID}:private-admin.5"
   │  payload: '{"event":"NEW_ORDER","data":"<json>","channel":"private-admin.5"}'
   ▼
[ Soketi WS 服务 ]  订阅 Redis pub/sub
   │  推送给所有订阅 private-admin.5 的 WS 客户端
   ▼
[ 前端 pusher-js ]
   │  channel.bind('NEW_ORDER', (data) => { ... })
```

---

## Channel 命名约定

| 用途 | Channel 名 | 示例 | 类型 |
|------|-----------|------|------|
| 推给单个管理员 | `private-admin.{uid}` | `private-admin.5` | 私有（需鉴权） |
| 广播给所有管理员 | `admin` | `admin` | 公共 |
| 推给单个用户 | `private-user.{uid}` | `private-user.123` | 私有 |
| 广播给所有用户 | `user` | `user` | 公共 |
| 推给单个客服 | `private-kefu.{uid}` | `private-kefu.3` | 私有 |
| 广播给所有客服 | `kefu` | `kefu` | 公共 |
| 推给单个门店 | `private-store.{store_id}` | `private-store.12` | 私有 |
| 广播给所有门店 | `store` | `store` | 公共 |
| 推给单个供应商 | `private-supplier.{supplier_id}` | `private-supplier.4` | 私有 |

### private- vs public channel

- **private-** 开头的 channel 需要**鉴权**（前端连接时 Soketi 会向后端 `/broadcasting/auth` 端点发鉴权请求）
- 无前缀的是**公共 channel**，任何连接的客户端都能订阅
- ECCOMALL 约定：**单播一律用 private-**（涉及用户隐私），**广播用公共**

---

## Event 名称（从代码 grep 出的现有事件，保持不变）

| Event | 说明 | 推送目标 | 触发点 |
|-------|------|----------|--------|
| `NEW_ORDER` | 新订单 | admin / store / supplier | 下单成功后 |
| `WITHDRAW` | 提现申请 | admin | 用户申请提现 |
| `NEW_REFUND_ORDER` | 新退款订单 | store / admin / supplier | 用户申请退款 |
| `WAIT_DELIVER_ORDER` | 待发货 | supplier | 已支付待发货 |
| `PAY_SMS_SUCCESS` | 支付短信发送成功 | admin | 支付回调 |
| `ADMIN_NEW_PUSH` | 管理员通知 | admin | 业务通知 |
| `STORE_STOCK` | 库存预警 | admin | 商品库存低阈值 |
| `reply` | 客服回复 | admin / user | 客服聊天 |
| `mssage_num` | 消息数 | kefu | 未读计数更新 |
| `to_transfer` | 用户被转接 | user | 客服转接 |
| `transfer` | 客服间转接 | kefu | 客服转接 |

> 新增事件请追加到本表，并在前端对应的 `.bind(event, handler)` 同步注册。

---

## Payload 格式

Pusher 协议约定的一条消息：

```json
{
  "event": "NEW_ORDER",
  "data": "{\"order_id\":12345,\"amount\":99.99}",
  "channel": "private-admin.5"
}
```

注意：
- `data` 字段是 **JSON 字符串**（不是嵌套 object），这是 Pusher 协议强制的
- 前端 pusher-js 会自动把 `data` 反序列化成 object 传给 callback

---

## 后端发送示例

业务代码调用方式**完全不变**：

```php
// 单播
SocketPush::admin()->to(5)
    ->type('NEW_ORDER')
    ->data(['order_id' => 12345, 'amount' => 99.99])
    ->push();

// 广播
SocketPush::admin()
    ->type('ADMIN_NEW_PUSH')
    ->data(['message' => 'All hands meeting at 3 PM'])
    ->push();
```

Adapter 层会根据 `targetId` 是否为 null 自动选 private 或 public channel。

---

## 前端订阅示例

### Vue 后台（pusher-js）

```js
import Pusher from 'pusher-js';

const pusher = new Pusher('eccomall-key', {
  cluster: 'mt1',
  wsHost: window.location.hostname,
  wsPort: 443,
  wssPort: 443,
  forceTLS: true,
  enabledTransports: ['wss'],
  auth: {
    headers: { 'X-Auth-Token': localStorage.getItem('admin_token') }
  }
});

// 私有 channel（需鉴权）
const channel = pusher.subscribe(`private-admin.${adminId}`);

channel.bind('NEW_ORDER', (data) => {
  showToast(`New order: #${data.order_id}`);
  refreshOrderList();
});

channel.bind('WITHDRAW', (data) => {
  showToast(`User withdrawal request: $${data.amount}`);
});
```

### Expo RN 前台

```js
import Pusher from 'pusher-js/react-native';
// 同上，API 一致
```

---

## 鉴权（private channel）

Soketi 订阅 `private-*` channel 时会向后端发一个 POST 请求：

```
POST /broadcasting/auth
Authorization: Bearer <user-token>
Body: socket_id=12345.67890&channel_name=private-admin.5
```

后端要验证：**当前 token 的用户是否有权订阅这个 channel**。

- `private-admin.{uid}` → 只允许 uid 等于当前管理员 id 的人订阅
- `private-store.{store_id}` → 只允许该门店的员工订阅
- `private-user.{uid}` → 只允许 uid 等于当前用户 id 的人订阅

后端返回 Pusher 格式的 auth 签名：

```json
{
  "auth": "eccomall-key:<hmac-sha256-signature>"
}
```

**待办**（阶段 4 做）：实现 `app/controller/api/BroadcastingAuthController.php`。

---

## Redis 连接约定

Adapter 用 `Cache::store('redis')->handler()` 拿到 \Redis 实例，沿用现有 `.env` 的 REDIS_HOSTNAME 配置。

Soketi 也连同一个 Redis（`SOKETI_DEFAULT_APP_PUB_SUB_REDIS_HOST=redis`），双方通过 Redis pub/sub 桥接。

---

## Soketi App 配置

`.env` 里新增（阶段 1.3 时生效）：

```ini
[SOKETI]
APP_ID     = eccomall
APP_KEY    = eccomall-key            ; 前端 pusher-js new Pusher(APP_KEY) 时用
APP_SECRET = <32-char-random>        ; 后端签 auth token 时用
HOST       = 0.0.0.0
PORT       = 6001
```

---

## 端到端验证脚本

阶段 1.4 会跑：
1. 后端调 `SocketPush::admin()->to(5)->type('TEST')->data(['msg' => 'hello'])->push()`（driver=redis_broadcast）
2. PHP 端 Redis 命令 `MONITOR` 观察到 `PUBLISH eccomall:private-admin.5 ...`
3. Soketi 订阅了该 channel，转发到前端
4. Pusher-js 客户端收到 `NEW_ORDER` 事件

脚本：`tests/integration/ws_pusher_e2e.sh`
