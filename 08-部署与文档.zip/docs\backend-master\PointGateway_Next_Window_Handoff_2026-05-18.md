# PointGateway Next Window Handoff 2026-05-18

## Current Goal

Continue after Point Gateway hard-lock and final freeze.

Plain meaning: Point Gateway is ready as a read-only/audit structure, but it must not write real data until formal testing starts.

## Completed

```text
Point Gateway tables: created
Point Gateway table row counts: all 0
Point Gateway admin read page: built and deployed
Point Gateway admin menu: inserted
Point Gateway backend routes: GET only
Point Gateway DB writes: hard-locked in code
Production hard-lock deploy: done
Final freeze package: done
```

Key commits for this backend line:

```text
5df7c3c7 backend: read point gateway review tables
33504c21 backend: hard lock point gateway db writes
928c70e6 backend: align package assert with point gateway hard lock
6cb671ed backend: freeze point gateway hard lock state
```

Current branch is `codex/pet-world-v2`.
Newer HEAD commits may be v3/frontend work and are not part of this backend handoff.

## Key Files

```text
backend_src/app/services/core/PointTransactionService.php
backend_src/app/services/core/stores/DbPointTransactionStore.php
backend_src/app/controller/admin/v1/core/PointGateway.php
backend_src/app/services/core/PointGatewayAdminReadService.php
backend_src/scripts/point_gateway_final_freeze_package_assert.php
backend_src/scripts/point_gateway_shadow_write_assert.php
backend_src/scripts/core_settlement_backend_package_assert.php
docs/backend-master/CoreSettlement_Phase90_PointGateway_Final_Freeze_Package_2026-05-18.md
deploy/core_point_gateway_tables_approval_required.sql
deploy/point_gateway_admin_read_menu_draft.sql
```

## Production Evidence

```text
production_host: 8.166.115.27
production_root: /opt/crmeb-prod
hard_lock_backup: /opt/crmeb-prod/deploy_backups/point-gateway-hard-lock-20260518152827
hard_lock_probe: passed
forced switch all-on probe: blocked
forced DbPointTransactionStore save: blocked
database_writes: false
online verify: passed
```

Production Point Gateway table row counts at freeze:

```text
eb_core_point_transaction: 0
eb_core_point_freeze: 0
eb_core_point_rollback_request: 0
eb_core_point_expiry_batch: 0
eb_core_point_gateway_ai_operation_log: 0
eb_core_point_gateway_approval_audit: 0
```

Production switches at freeze:

```text
core_point_gateway_db_store_enabled: 0
core_point_gateway_db_read_enabled: 0
core_point_gateway_db_write_enabled: 0
core_point_gateway_write_shadow: not configured
core_point_gateway_write_live: not configured
```

## Forbidden Areas

```text
do not enable core_point_gateway_* switches
do not write Point Gateway DB rows
do not add POST/PUT/DELETE Point Gateway routes
do not connect farm/mine/checkin/payment/order writes before formal testing
do not modify YuePayServices.php without separate explicit payment approval
do not treat empty Point Gateway tables as a bug
do not run full server sync/deploy scripts while local/server trees are dirty
do not touch v3/frontend/game dirty work from other windows
```

## Validation Commands

Local:

```bash
php backend_src/scripts/point_gateway_final_freeze_package_assert.php
php backend_src/scripts/core_settlement_backend_package_assert.php
php backend_src/scripts/point_gateway_shadow_write_assert.php
php backend_src/scripts/point_gateway_admin_read_assert.php
git diff --check -- backend_src/scripts docs/backend-master
```

Production read-only checks:

```bash
bash deploy/verify_online.sh 8.166.115.27
# Re-run hard-lock probe only; do not mutate production data.
```

## Next Work

Preferred next task before formal testing:

```text
only read-only patrol or documentation cleanup
no write path
no production SQL
no deployment unless fixing hard-lock drift
```

When formal testing starts, first writing task must begin with plain-language approval:

```text
1. which single business path writes Point Gateway
2. what fields are written
3. how it compares with user_bill and user.integral
4. rollback plan
5. explicit production write approval
```

Recommended first pilot when testing starts: daily check-in or pet feed, not payment.

## Known Remaining Work

```text
Point Gateway real write pilot: deferred until formal testing
YuePayServices payment point audit: separate explicit approval required
Point Gateway operational dashboard with real rows: deferred
user_bill / user.integral / Point Gateway reconciliation: deferred
```

## Dirty Tree Warning

This workspace has many unrelated dirty files from other windows, especially v3/frontend/game/docs.
Do not stage with `git add -A`.
Only stage exact backend target files.
