-- Read-only database audit for backend/database workflow.
-- Usage:
--   mysql <database> < deploy/db_audit_20260615_readonly.sql
--
-- This script does not modify data or schema.

SELECT 'mysql_runtime' AS section;
SELECT
  VERSION() AS mysql_version,
  @@sql_mode AS sql_mode,
  @@time_zone AS time_zone,
  @@character_set_server AS character_set_server,
  @@collation_server AS collation_server;

SELECT 'database_size' AS section;
SELECT
  table_schema,
  COUNT(*) AS table_count,
  ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size_mb
FROM information_schema.tables
WHERE table_schema = DATABASE()
GROUP BY table_schema;

SELECT 'largest_tables' AS section;
SELECT
  table_name,
  engine,
  table_rows,
  ROUND(data_length / 1024 / 1024, 2) AS data_mb,
  ROUND(index_length / 1024 / 1024, 2) AS index_mb,
  ROUND((data_length + index_length) / 1024 / 1024, 2) AS total_mb,
  ROUND(data_free / 1024 / 1024, 2) AS free_mb
FROM information_schema.tables
WHERE table_schema = DATABASE()
ORDER BY data_length + index_length DESC
LIMIT 30;

SELECT 'non_innodb_tables' AS section;
SELECT table_name, engine
FROM information_schema.tables
WHERE table_schema = DATABASE()
  AND table_type = 'BASE TABLE'
  AND engine <> 'InnoDB'
ORDER BY table_name;

SELECT 'tables_without_primary_key' AS section;
SELECT
  t.table_name,
  t.table_rows,
  ROUND((t.data_length + t.index_length) / 1024 / 1024, 3) AS total_mb
FROM information_schema.tables t
LEFT JOIN information_schema.table_constraints c
  ON c.table_schema = t.table_schema
 AND c.table_name = t.table_name
 AND c.constraint_type = 'PRIMARY KEY'
WHERE t.table_schema = DATABASE()
  AND t.table_type = 'BASE TABLE'
  AND c.constraint_name IS NULL
ORDER BY total_mb DESC, t.table_name;

SELECT 'duplicate_index_candidates' AS section;
SELECT
  table_name,
  GROUP_CONCAT(index_name ORDER BY index_name) AS indexes,
  column_list
FROM (
  SELECT
    table_name,
    index_name,
    GROUP_CONCAT(column_name ORDER BY seq_in_index) AS column_list
  FROM information_schema.statistics
  WHERE table_schema = DATABASE()
  GROUP BY table_name, index_name
) x
GROUP BY table_name, column_list
HAVING COUNT(*) > 1
ORDER BY table_name, column_list;

SELECT 'kaijiang_schema_compatibility' AS section;
SELECT
  table_name,
  table_type,
  engine,
  table_rows
FROM information_schema.tables
WHERE table_schema = DATABASE()
  AND table_name IN (
    'eb_store_product_kaijiang_log',
    'eb_store_integral_product_kaijiang_log',
    'eb_store_product_kaijiang_shaidan',
    'eb_store_integral_product_kaijiang_shaidan'
  )
ORDER BY table_name;

SELECT 'phase6_index_presence' AS section;
SELECT
  table_name,
  index_name,
  GROUP_CONCAT(column_name ORDER BY seq_in_index) AS columns
FROM information_schema.statistics
WHERE table_schema = DATABASE()
  AND table_name IN (
    'eb_store_integral_product_huanqu_log_unique',
    'eb_store_integral_product_huanqu_log',
    'eb_store_product_kaijiang_log',
    'eb_user_box',
    'eb_box_order'
  )
GROUP BY table_name, index_name
ORDER BY table_name, index_name;

SELECT 'product_description_duplicate_key_check' AS section;
SELECT product_id, type, COUNT(*) AS duplicate_count
FROM eb_store_product_description
GROUP BY product_id, type
HAVING COUNT(*) > 1
LIMIT 20;
