# 项目协作说明

## 跨机器 / 云端最新入口（2026-09-17）

- **代码基线**：GitHub `https://github.com/josecai620/eccomall`，分支 `main`。云端 Cursor、Grok Bot、其他 Agent 都拉这个仓，不要再默认走 Gitee 或 `codex/pet-world-v2`。
- **当前前台**：`mobile-app/`（v4，线上 `https://vivodraw.com/` 根）。`mobile-app-v3/` 保留停用，不要当默认改动入口。下文积分商城保护清单里的 `mobile-app/` 按现役 v4 理解。
- **云购改造工作区**：`yunmall-hybrid/`。进场读 `yunmall-hybrid/项目说明.md`、`SPEC.md`、`STATUS.md`、`TASKS.md`。
- **云端没有的东西**：生产 `.env`、数据库、SSH、图片/视频/声音。缺图时仍可改逻辑，不得宣称页面视觉已完整。实现云购玩法时对照仓库内 SPEC / adapters / 模块 design，禁止把外部 PHP 整包拷进本仓。
- **云端不要做**：SSH 登录生产、从服务器 rsync 覆盖、执行线上 SQL、提交密钥。本地 Windows 更新仍可读 `docs/Windows工作区更新与接手说明.md`（2026-09-14 历史步骤保留，当前远端以 GitHub `main` 为准）。
- 图片、视频和声音不入 Git；资源缺口见 `docs/跨机同步/需另行补齐的媒体文件清单.tsv`。
- 目标核对使用仓库内 `docs/工作目标核对技能/SKILL.md`。本机 `/Users/joe/...` 路径在 Windows 和云端都不通用。

历史：2026-09-14 曾以 Gitee `codex/pet-world-v2`、前台 `mobile-app-v3/` 为旧入口不能覆盖本节。


## 项目入口与边界

- 任务涉及本项目时，先读 `AGENTS.md`、`CLAUDE.md`、`DEPLOY-WORKFLOW.md`、`docs/网站开发工作流-架构师版.md`，再按需查 `docs/`、`deploy/`、`mobile-app/*.md`。
- 本项目规则优先于全局偏好；能通过项目文档和代码确认的问题，不要反问用户。
- 默认技术栈：后端 PHP 8.1 + ThinkPHP 6，后台 Vue2，用户前台 Expo/React Native Web；旧 Uniapp H5 已弃用。
- 前端、后台、PHP 后端改动要按项目部署脚本处理，并做最小验活；不要临时发明部署流程。
- 服务器 `.env`、上传文件、数据库、备份、运行态目录不要被本地文件覆盖。
- 涉及 `mall_type`、积分商城、盲盒商城、鉴权、支付、密钥、上线前清理时，必须先查对应文档和源码确认。

## 自主探索文档（核心工作方法，必须遵守）

开发过程中，Agent 必须**主动、自主**地探索项目文档体系，而非被动等待用户指路。具体要求：

1. **按需读文档**：遇到不熟悉的业务模块、接口、表结构时，先去 `docs/`、`deploy/`、代码注释、`README` 等找答案，不要猜测。
2. **跟踪引用链**：读到文档 A 引用了文档 B 时，必须跳转去读文档 B，逐层构建完整理解。例如：
   - `AGENTS.md` → `DEPLOY-WORKFLOW.md` → `docs/网站开发工作流-架构师版.md`
   - `docs/网站开发工作流-架构师版.md` → `docs/数据库获取说明.md`
   - `盲盒商城开发文档.md` → 对应的 PHP 控制器源码
3. **自建推理链**：根据任务需要，自行决定读什么文档、读到什么深度。不需要用户逐步指引。
4. **不懂就查**：对业务概念（如 `mall_type`、`store_integral_*`、盲盒回收比例等）有疑问时，去源码和数据库文档中确认，而非假设。
5. **文档优先于提问**：能通过文档和代码自行解答的问题，不要反问用户。

> 这条规则的目标：每个 Agent 都能独立理解整套系统的业务结构，像一个真正熟悉项目的开发者一样工作。

## 工作目标核对：每次新窗口必读

- 每次新窗口开始任何任务时，必须先读取并遵守 `/Users/joe/.codex/skills/工作目标核对/SKILL.md`；其他机器使用项目副本 `docs/工作目标核对技能/SKILL.md`。无需用户再次点名，按任务规模执行核对，简单任务也须保持目标一致。
- 保留用户原话、明确排除项和后续纠正，在方案选择、首次样品后、扩大投入前和交付前对照实际成果核对；不能以技术检查替代需求验收。
- 已发生偏移或有实质不同的解释时，按技能用独立分身核对。主 Agent 自行处理授权内的修正；清楚的小任务直接完成，不新增逐步批准流程。
- 本入口是任务执行规则，不改变既有模型、权限、部署或 Git 边界，也不代表已安装自动阻断操作的 hooks。

## 模型使用

- 本项目默认使用 **GPT-6 Astra**（`gpt-6-astra`），除非用户明确指定其他模型。
- 推理等级统一使用当前 Codex 的六档名称：**轻度（low）/ 中（medium）/ 高（high）/ 极高（xhigh）/ 最高（max）/ ultra**。推荐时使用这些名称，不再使用旧的“低 / 中 / 高 / 超高”四档命名。
- 当任务需要切换到其他模型时，请**先告知用户**，征得同意后再执行；沿用当前模型的分身协作仍按本文件的多 Agent 长期授权执行。

## 本地 Skill 触发约定

- 用户说“图标矢量图”时，默认启用 `.agents/skills/pixel2motion`。
- 用户要求把图片、logo、icon 生成动态 SVG、矢量图、动态矢量图、logo reveal、动效 HTML 时，也默认启用 `.agents/skills/pixel2motion`。
- `pixel2motion` 输出优先放在任务素材目录或用户指定目录；没有源图时先要求用户提供图片，不要凭空生成所谓矢量图，别把算命当设计。

## 新视频任务默认技能

- 每次制作新视频（包括广告、宣传片、短片），开始创意、分镜或素材制作前，必须读取并应用 `/Users/joe/.codex/skills/AI导演生产工作流/SKILL.md` 和 `/Users/joe/.codex/skills/广告创作与样片验收/SKILL.md`；新窗口同样适用，无需用户手动点名。
- 导演技能负责镜头、空间、动作和连续性；广告技能按当前视频用途应用创意与样片验收方法。用户的主题、参考、明确排除项和后续纠正优先，不自行把其他视频改成广告。
- VivoDraw 广告沿用已确定的顺序：导演规划 → Blender 镜头预演 → Higgsfield 生成 → 样片验收。Blender 用于验证运镜、调度与节奏，不能把用户要求的运镜预演替换成三维商城界面演示。
- 单纯查找、播放、复制或转码已有视频不触发这两个制作技能；仍遵守工作目标核对。

## 开发任务推理等级确认流程（GPT-6 Astra）

- 用户发布开发任务后，Agent 必须先只评估任务所需的推理深度，从上述六档中建议一个推理等级，并用一句话说明原因；不要再用“难度：高 / 超高”代替推理等级建议。
- 对用户的推荐格式为：“模型：GPT-6 Astra；建议推理等级：极高；原因：……”。等级按任务实际需要选择，不默认一律推荐最高档。
- 评估后必须停止，不读代码、不改文件、不执行实现命令。
- 等用户调整好推理等级并明确回复“继续”或“1”后，Agent 才能开始读文件、写代码、运行测试或执行后续开发步骤。
- 用户单独回复“1”时，等同于“继续 / 开始 / 下一步 / 执行 / 开工 / 开搞”。
- 非开发类简单问答可直接回答；若任务会修改代码、文档、配置、设计资产或运行构建/测试，必须先走上述确认流程。

## 前端部署

用户需在**线上环境**验收。云端 Agent 改完 `mobile-app/` 后推 GitHub `main` 即可，**不要**对生产服务器 rsync。

本机要发线上时：v4 发版以 `yunmall-hybrid/STATUS.md` 为准（`dist-root → pack_root.py → remote-release-root.sh`）。`./deploy-frontend.sh` 是旧 v3 入口，不要当现役 v4 发布命令。

### 前台发布硬边界（永久）

1. **只允许发布当前 Agent 明确负责的文件**。发布前必须在独立 worktree 或干净副本中执行 `python deploy/发布前边界检查.py --allow <repo-relative-file>... --manifest <temp-manifest.json>`；检查清单外存在任何已修改、未跟踪或删除文件时，发布必须中止。
2. **禁止用整站包覆盖他人改动**。个人中心、单页、单模块等局部任务只能使用带清单的 scoped overlay；不得直接上传当前工作区的 `dist-root`、旧 `v4-root-bundle.tar.gz` 或未核对来源的整站包。
3. **根版本切换默认拒绝**。`remote-release-root.sh` 只适用于用户明确授权的整站发布；局部发布必须从线上 `current` 复制出新 release，只解压清单列出的产物，再切换版本标记。
4. **清单必须可审计**。清单记录基线 commit、允许的源文件、实际产物、生成时间和包 SHA256；上传前后均核对，发现基线变化、额外文件或 SHA256 不一致立即停止。
5. **不确定归属就不发布**。看到其他 Agent 的未提交改动、活跃任务标记或无法证明线上基线与本地基线一致时，暂停上传并先做只读汇总；不得用“当前源码重新构建”替代归属核对。
6. **禁止绕过检查**。不得通过手工 `scp`、`rsync`、服务器 `git reset --hard`、删除 release 或修改 nginx 来规避清单；生产 `.env`、数据库、上传文件、运行态目录和后端静态目录始终不在前台发布范围内。

执行入口：`deploy/发布前边界检查.py`。完整根发布必须额外取得用户对“整站覆盖”的明确授权，并使用单独的 full-site 清单；没有清单或清单模式不匹配时，上传脚本必须直接失败。

## 生产服务器（2026-08-22 起生效）

- **生产服务器已迁移至美国 VDS**：`root@186.241.72.176`，SSH 端口 `49375`，密钥免密登录（本机 `~/.ssh/id_ed25519`）。
- 旧广州阿里云服务器 `8.166.115.27` 已停用为生产环境，仅保留作临时回滚参考，禁止再向其部署。
- 国内访问不再需要备案（服务器在境外）；域名仍为 `vivodraw.com`（商城）与 `altanexgroup.vip`（公司官网）。

## 前台部署防错（必须遵守）

1. 禁止把“代码回滚”与“前台静态资源部署”混为一体。
   服务器 `git reset --hard` 后，必须重新检查 `backend_src/public/index.html` 与 `backend_src/public/_expo` 是否匹配。
2. 仅允许使用项目根目录脚本 `./deploy-frontend.sh` 部署前台，不要临时改用其他目录的构建脚本。
3. 前台 API 基址统一使用 `https://vivodraw.com`；生产域名访问目标为 `https://vivodraw.com`。禁止继续使用旧服务器 IP `8.166.115.27` 作为 API/部署目标。
4. 每次前台部署后，必须做最小验收：
   - 访问 `https://vivodraw.com/` 返回 `200`
   - 检查页面主 JS 资源（`/_expo/static/js/web/entry-*.js`）返回 `200`
   - `curl -H "X-Client: mobile-app" https://vivodraw.com/api/category` 返回 `status=200`

## 域名硬规则（永久）

- 旧服务器 `旧服务器 IP` 已废弃，禁止作为前台/后端/API/回调/资源地址继续使用。
- 旧域名/IP `旧域名 IP` 已废弃，禁止作为前台/后端/API/回调/资源地址继续使用。
- 旧广州阿里云服务器 `8.166.115.27`（2026-08-22 起停用），禁止作为部署/API/回调地址继续使用。
- 发现上述旧 IP 时，必须统一替换为生产服务器 `186.241.72.176` 或正式域名 `vivodraw.com`（协议按当前环境规则使用）。
- 任何上线前检查中，若仍发现旧 IP，视为未通过，必须修正后再发布。

## 新窗口启动流程（强制）

每次新开窗口开始开发前，必须先读关键文档，再动代码：`AGENTS.md`、`DEPLOY-WORKFLOW.md`、`docs/网站开发工作流-架构师版.md`。云购任务还要读 `yunmall-hybrid/项目说明.md`。

**云端 Cursor / Grok Bot：** 以 GitHub `main` 为基线。不要执行服务器同步脚本，不要 SSH，不要假定能连生产库。`git pull` 当前分支即可。

**本机有 SSH 的窗口**才走下面 2–4；云端跳过。

2. **先以服务器为准同步到本地**（仅本机）
 - 在项目根目录执行：`bash deploy/从服务器同步到本地.sh 186.241.72.176`
 - 同步后先检查差异，再继续开发。
3. **再同步 Git 最新**
 - `git pull origin main`（当前工作分支）。
4. **确认基线再开发**
 - 本机：当前开发基线 = 服务器最新 + Git 最新。
 - 云端：当前开发基线 = GitHub `main`。

注意：服务器不保存 `mobile-app` 源码，`mobile-app` 以仓库版本为准；`backend_src/deploy` 以服务器同步结果为准。

## 新窗口长期授权（2026-05-17 起生效）

- 每次切换新窗口或新 Agent 接手本项目时，默认允许主 Agent 自行开分身 / 多 Agent 并行作业；分身数量由主 Agent 按任务复杂度、文件边界和风险控制自行决定。
- 默认允许部署、提交、推送到当前工作分支；完成后必须按本文件的部署验活、Git 同步和改动范围检查规则执行。
- 多 Agent 作业必须先明确分工和写入范围，避免多个分身同时改同一文件；最终由主 Agent 统一汇总验证、提交、推送。
- 上述长期授权不解除硬禁区：禁止强推、回滚历史、删除重要文件、执行线上 SQL、修改服务器配置、覆盖服务器 `.env` / 上传文件 / 数据库 / 运行态目录，除非用户明确点名要求。
- 如果发现无法判断改动归属、存在冲突、可能覆盖其他活跃 Agent 成果，必须暂停提交并先做只读汇总。

## 多 Agent Git 同步规则（强制）

本项目以 GitHub 远端 `origin`（`https://github.com/josecai620/eccomall.git`，分支 `main`）作为 Mac、Windows、云端 Agent、`game/`、商城网站的统一代码基线。所有 Agent 开发完成后，必须把可交付代码推到 GitHub 当前工作分支；不要只留在本地或只部署到服务器。Gitee 旧仓仅作历史，不能覆盖 GitHub `main`。

### 单个 Agent 独立开发完成后

1. 提交前先检查改动范围：
   ```bash
   git status --short --branch
   git diff --stat
   git diff --name-only
   ```
2. 确认没有误提交以下内容：
   - 真实 cookie/session/token/key/password
   - `.env`、数据库备份、服务器上传文件、运行态目录、构建缓存
   - 旧服务器 `旧服务器 IP` 或旧 IP `旧域名 IP`
   - 与本任务无关的大量格式化、回滚、删除
3. 按改动类型做最小验证：
   - PHP：`php -l <changed.php>`
   - `game/`：优先跑 `npm run typecheck`（在 `game/`）
   - `mobile-app/`：优先跑 `npm run typecheck`（在 `mobile-app/`）
   - 文档/SQL：至少跑 `git diff --check`
4. 提交前同步远端，避免覆盖别人的新提交：
   ```bash
   git fetch origin
   git pull --rebase origin "$(git branch --show-current)"
   ```
5. 提交并推送到当前分支：
   ```bash
   git add -A
   git commit -m "简短说明本次改动"
   git push origin "$(git branch --show-current)"
   ```
6. 推送后复查：
   ```bash
   git status --short --branch
   git rev-list --left-right --count HEAD...origin/$(git branch --show-current)
   ```
   结果应为工作区干净，且左右差异为 `0 0`。

### 多 Agent 或多窗口同时开发时

- 如果多个 Agent 正在同一区域开发（尤其 `game/`、`mobile-app/`、`backend_src/`），各 Agent 只提交自己负责的明确范围；不要批量回滚、清理、格式化别人的文件。
- 看到他人新提交时，先 `git pull --rebase`，解决冲突后再继续；禁止强推。
- 发现冲突、无法判断归属、或可能覆盖活跃开发成果时，停止提交，交给总同步端统一整合。
- `game/` 是活跃开发区，除非用户明确要求，禁止删除、回滚、批量移动、格式化整个 `game/` 目录。

### 总同步端职责

总同步端用于统一整合 `game/`、商城网站、服务器同步产物、Windows 端开发成果：

1. 先只读检查：
   ```bash
   git fetch origin
   git status --short --branch
   git diff --stat
   git diff --name-only
   git log --oneline --decorate -8
   ```
2. 若本地有未提交改动，先判断来源和风险；不得直接 `git pull` 或服务器 rsync 覆盖未提交成果。
3. 先清理敏感内容和明显临时文件，再提交必要同步产物。
4. 提交前必须扫旧 IP、cookie/session、密钥痕迹；发现旧 IP 必须替换为 `186.241.72.176` 或 `vivodraw.com`。
5. 推送前执行 `git pull --rebase origin "$(git branch --show-current)"`，推送后确认本地与远端一致。
6. 总同步端可以提交别人已经完成但未入库的迁移脚本、部署脚本、文档和资源；但不执行数据库 SQL、不改服务器配置，除非用户明确要求。

### 服务器部署与 Git 的边界

- GitHub 同步不等于线上部署。云端改完 `mobile-app/` 后推到 `main` 即可，不要假装已经发到 vivodraw.com。本机要线上验收时，v4 发版以 `yunmall-hybrid/STATUS.md` 为准，不要只跑旧的 `./deploy-frontend.sh`（那是 v3 入口）。
- PHP 后端发布走项目脚本，不要临时发明部署命令；服务器 `.env`、上传文件、数据库、备份、运行态目录必须保留。
- 服务器上产生的 nginx 备份、cookie 文件、缓存、临时日志不得入 Git；必要时写进 `.gitignore`。

## 积分商城对接保护（2026-03-17 起生效）

积分商城已完成全面前后端对接 + 后端缺陷修复，业务完整闭环（31 个 API 函数、31 个 Hook、21+ 个页面文件、7 个后端修复文件）。以下文件为积分商城核心依赖，**禁止回滚到 2026-03-17 之前的版本**：

**前端核心文件：**
- `mobile-app/constants/api.ts` — 积分商城全部端点定义
- `mobile-app/lib/api/points.ts` — 积分商城全部 API 函数
- `mobile-app/hooks/usePoints.ts` — 积分商城全部 Hook
- `mobile-app/hooks/index.ts` — Hook 导出（缺少任何一个导出都会导致对应页面白屏）

**后端核心文件：**
- `backend_src/app/controller/api/v1/integral/StoreProductController.php` — 积分商品评价/晒单/揭晓详情
- `backend_src/app/controller/api/v1/integral/IntegralController.php` — 新版积分商品列表（修复表名）
- `backend_src/app/controller/api/v1/integral/OrderController.php` — 积分订单（修复表名）
- `backend_src/app/controller/api/v1/integral/CollectController.php` — 积分收藏（修复表名）
- `backend_src/app/listener/integral/Kaijiang.php` — 开奖监听（修复表名）
- `backend_src/app/listener/integral/Jiqiren.php` — 机器人监听（修复表名）
- `backend_src/app/listener/integral/Manghe.php` — 盲盒监听（修复表名）

详细清单见 `docs/网站开发工作流-架构师版.md` 的积分商城保护说明。

## 盲盒商城对接保护（2026-03-17 起生效）

盲盒商城已完成全面前后端对接 + 后端 10 处缺陷修复，业务闭环（32 个 Hook、17 个新 API 函数、13 个页面文件、1 个后端修复文件）。以下文件为盲盒商城核心依赖，**禁止回滚到 2026-03-17 之前的版本**：

**前端核心文件：**
- `mobile-app/constants/api.ts` — 盲盒端点定义（17 个新增）
- `mobile-app/lib/api/box.ts` — 盲盒全部 API 函数（32 个）
- `mobile-app/hooks/useBox.ts` — 盲盒全部 Hook（32 个）
- `mobile-app/hooks/index.ts` — Hook 导出
- `mobile-app/app/box/` — 全部 13 个盲盒页面文件

**后端核心文件：**
- `backend_src/app/controller/api/v1/manghe/MangheController.php` — 盲盒控制器（10 处 bug fix）

详细清单见 `docs/盲盒商城开发文档.md`。

## 游戏工作流开发保护（2026-05-08 起生效）

- `game/` 目录是游戏工作流 Agent 的活跃开发区，当前开发内容包括新版宠物世界、深渊矿洞、水晶花园、新版水晶/钻石风格商城 UI。
- 禁止删除、回滚、格式化、批量移动 `game/` 目录内文件，除非用户明确点名要求。
- 游戏工作流可能会在 `mobile-app/`、`backend_src/`、数据库、接口、入口页面中加入联动代码；看到宠物世界、深渊矿洞、水晶花园、水晶/钻石 UI 相关入口或接口时，默认视为活跃开发依赖，不能作为冗余清理。
- 后端减肥、旧 H5 清理、旧支付清理时，必须避开上述游戏工作流相关文件、接口、表结构和配置。
- 只有确认某个文件属于旧版废弃农场/旧采矿/旧宠物残留，且不属于当前游戏工作流开发范围后，才允许列入清理候选。

# 宠物账号归属硬规则

- 用户宠物只允许在注册成功后由服务器/数据库随机生成并固定到账号。
- 前端禁止本地随机分配宠物，禁止用本地存储决定账号宠物身份。
- 用户换设备登录时必须以后端返回的账号宠物为准；无账号或接口异常时只能展示默认兜底宠物，不能生成新的随机宠物。
- 若未来支持重新随机宠物，必须走后端接口更新账号绑定，不能前端自行改。

## Imported Claude Cowork project instructions

## 用户长期偏好：中文命名（2026-09-07）

- 用户看不懂英文。以后新建的文件夹和文件，名称主体一律使用清楚易懂的中文，不以英文或拼音代替中文。
- 示例：`成品视频/商城平台演示-第三版-52秒.mp4`、`商城界面截图素材包/首页截图.png`、`制作说明.md`。
- 保留 `.mp4`、`.png`、`.pdf` 等标准扩展名；技术工具强制的固定文件名（如 `AGENTS.md`、`package.json`）保留规定名称，其余采用中文。
- 面向用户的文件链接标签和说明也用中文。未经要求，不批量改名已有代码或依赖文件。
