# CoreSettlement Phase 33 Reconciliation Mapper Wiring 2026-05-18

## Current Task

Phase 33 wires the legacy `user_bill` readonly mapper into the Point Gateway reconciliation skeleton.

No DB read was added.
No DB write was added.
No `user_bill` update was added.
No `user.integral` update was added.
No production deployment was executed.

## Implementation

Updated:

```text
backend_src/app/services/core/PointGatewayReconciliationService.php
backend_src/scripts/point_gateway_reconciliation_assert.php
backend_src/scripts/core_settlement_backend_package_assert.php
```

## Behavior

Reconciliation now normalizes legacy bill rows through:

```text
LegacyPointBillMapperService
```

Matching contract:

```text
primary: legacy_user_bill_id
fallback: uid + amount + direction + created_at_window + legacy_write_path
mode: readonly_contract_only
```

## Guard

```text
readonly=true
database_writes=false
legacy_bill_updates=false
user_integral_updates=false
rollback_execution=false
```

## Validation

Passed:

```bash
php backend_src/scripts/point_gateway_reconciliation_assert.php
php backend_src/scripts/core_settlement_backend_package_assert.php
```

## Not Done

- no DB-backed reconciliation
- no route exposure
- no export
- no auto-fix

## Next Step

Phase 34 should add readonly frozen/expiry list contracts.
