const { localizeAccountLogTitle } = await import("../mobile-app/lib/account-log-title.ts");

const cases = [
  ["金币兑换积分", "Farm coins to points"],
  ["金幣兌換積分", "Farm coins to points"],
  ["深渊矿洞奖励", "Abyss Mine reward"],
  ["深淵礦洞獎勵", "Abyss Mine reward"],
  ["海底寻珠奖励", "Pearl Lagoon reward"],
  ["积分兑换矿币", "Points to mine coins"],
  ["积分兑换贝壳币", "Points to shell coins"],
  ["贝壳币兑换积分", "Shell coins to points"],
  ["美元余额购买积分", "Bought points with USD"],
  ["签到奖励", "Check-in reward"],
  ["云购参与", "Cloud Buy entry"],
  ["盲盒每日签到", "Blind box daily check-in"],
  ["盲盒每日任务", "Blind box daily task"],
  ["盲盒每日任務", "Blind box daily task"],
  ["用户充值余额", "Wallet top-up"],
  ["桌宠默契·逗宠", "Bond · play"],
  ["桌寵默契·逗寵", "Bond · play"],
  ["桌宠解锁·原进度保留", "Desk pet unlock · progress kept"],
];

const zhCases = [
  ["金币兑换积分", "金幣兌換積分"],
  ["深渊矿洞奖励", "深淵礦洞獎勵"],
  ["积分兑换贝壳币", "積分兌換貝殼幣"],
  ["盲盒每日任务", "盲盒每日任務"],
];

let failed = 0;
for (const [title, en] of cases) {
  const got = localizeAccountLogTitle({ title, zh: false });
  if (got !== en) {
    failed += 1;
    console.log("EN FAIL", title, "=>", got, "want", en);
  }
}
for (const [title, zh] of zhCases) {
  const got = localizeAccountLogTitle({ title, zh: true });
  if (got !== zh) {
    failed += 1;
    console.log("ZH FAIL", title, "=>", got, "want", zh);
  }
}
if (failed) {
  console.log("failed", failed);
  process.exit(1);
}
console.log("ok", cases.length + zhCases.length);
