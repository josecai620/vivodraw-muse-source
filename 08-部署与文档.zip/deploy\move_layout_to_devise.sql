-- 将「排版管理」从 装修 下移到「首页装修」下
-- 执行方式：mysql -u用户 -p 数据库名 < move_layout_to_devise.sql

UPDATE `eb_system_menus`
SET `pid` = 657, `path` = '12/656/657', `is_header` = 0
WHERE `menu_path` = '/admin/setting/pages/layout' AND `is_del` = 0;
