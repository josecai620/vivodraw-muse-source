#!/usr/bin/env bash
# 从本机 SSH 到服务器，执行后台前端的构建与部署
# 用法: ./deploy/run_admin_build_on_server.sh [服务器IP]
# 示例: ./deploy/run_admin_build_on_server.sh 186.241.72.176
set -euo pipefail

SERVER_IP="${1:-186.241.72.176}"
SSH_USER="${2:-root}"
SSH_PORT="${3:-49375}"
REMOTE_DIR="/opt/crmeb-prod"
LOCAL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "==> 上传构建脚本到服务器"
scp -P "${SSH_PORT}" "${LOCAL_ROOT}/deploy/build_and_deploy_admin.sh" \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/deploy/"

echo "==> 在服务器上执行构建与部署"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" \
  "chmod +x ${REMOTE_DIR}/deploy/build_and_deploy_admin.sh && PROJECT_DIR=${REMOTE_DIR} bash ${REMOTE_DIR}/deploy/build_and_deploy_admin.sh"

echo "==> 完成"
echo "请访问 http://${SERVER_IP}/admin/ 验证"
