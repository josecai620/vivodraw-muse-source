# CoreSettlement Phase 32 Legacy User Bill Readonly Mapper 2026-05-18

## Current Task

Phase 32 adds a readonly mapper for legacy `user_bill` point rows.

No DB read was added.
No DB write was added.
No `user_bill` update was added.
No `user.integral` update was added.
No production deployment was executed.

## Implementation

Added:

```text
backend_src/app/services/core/LegacyPointBillMapperService.php
backend_src/app/services/core/contracts/LegacyPointBillMapperServiceInterface.php
backend_src/scripts/legacy_point_bill_mapper_assert.php
```

Updated:

```text
backend_src/scripts/core_settlement_backend_package_assert.php
```

## Mapping

Legacy fields:

```text
id
uid
link_id
pm
title
category
type
number
balance
mark
add_time
status
```

Normalized fields:

```text
legacy_user_bill_id
uid
link_id
category
type
title
mark
direction
amount
balance
status
created_at
is_integral
```

Direction mapping:

```text
pm=1 -> income
pm=0 -> expense
```

Non-integral rows are marked:

```text
is_integral=false
```

## Guard

```text
readonly=true
database_writes=false
legacy_bill_updates=false
user_integral_updates=false
```

## Validation

Passed:

```bash
php backend_src/scripts/legacy_point_bill_mapper_assert.php
php backend_src/scripts/core_settlement_backend_package_assert.php
```

## Not Done

- no DB-backed mapper
- no `user_bill` DAO query
- no reconciliation route
- no export
- no auto-fix

## Next Step

Phase 33 should connect this mapper to the reconciliation skeleton using fixture/assert only.

Do not read production DB yet.
