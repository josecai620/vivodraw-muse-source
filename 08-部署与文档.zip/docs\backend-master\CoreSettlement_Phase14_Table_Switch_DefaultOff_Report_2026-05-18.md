# CoreSettlement Phase 14 Table And Switch Default-Off Report 2026-05-18

## Current Task

Phase 14 executed only the approved minimal DB readiness SQL:

- create `eb_core_settlement_ledger`
- insert missing CoreSettlement switch rows with `value = 0`

This phase did not open any switch, did not write ledger rows, did not modify business code, did not touch payment/order/inventory/Manghe.

## Backup Gate

Backup artifact confirmed before execution:

- `/Users/joe/eccomall/db_backup/db_20260518_050233.sql.gz`
- `gzip -t`: passed
- compressed: `920809` bytes
- uncompressed: `6437960` bytes

Backup artifact remains ignored by Git and was not staged.

## Pre-Check

Target:

- host: `8.166.115.27`
- DB: `manghehoutai_qhe`
- DB user: `crmeb`
- MySQL: `8.0.45-0ubuntu0.24.04.1`
- `@@read_only`: `0`
- `@@super_read_only`: `0`

Before execution:

```text
eb_core_settlement_ledger  missing
core_settlement_checkin_shadow     missing
core_settlement_daily_task_shadow  missing
core_settlement_game_farm_shadow   missing
core_settlement_game_mine_shadow   missing
core_settlement_pet_feed_shadow    missing
```

## SQL Executed

Executed only:

- `CREATE TABLE IF NOT EXISTS eb_core_settlement_ledger (...)`
- `INSERT INTO eb_system_config (...) SELECT ... WHERE NOT EXISTS (...)`

Not executed:

- no ledger `UPDATE`
- no ledger `DELETE`
- no ledger `TRUNCATE`
- no ledger `DROP`
- no switch value `1`
- no payment/order/inventory SQL

## Post-Check

Table presence:

```text
eb_core_settlement_ledger present
```

Columns:

```text
id          int unsigned       primary, auto_increment
scene       varchar(64)        not null
action      varchar(64)        not null
uid         int unsigned       not null default 0
request_id  varchar(128)       not null
amount      int                not null default 0
direction   tinyint unsigned   not null default 1
reason      varchar(64)        not null
meta        text               nullable
add_time    int unsigned       not null default 0
```

Indexes:

```text
PRIMARY        unique  id
uk_request_id  unique  scene,request_id
idx_uid        nonuniq uid
idx_add_time   nonuniq add_time
```

Switch rows:

```text
core_settlement_checkin_shadow     present  0  status=1
core_settlement_daily_task_shadow  present  0  status=1
core_settlement_game_farm_shadow   present  0  status=1
core_settlement_game_mine_shadow   present  0  status=1
core_settlement_pet_feed_shadow    present  0  status=1
```

Ledger row count:

```text
0
```

## Decision

Phase 14 passed.

Current production DB readiness:

- writer table exists
- writer columns match current PHP writer
- idempotency unique key `scene + request_id` exists
- required switch rows exist
- all switches remain off
- ledger is empty

Runtime activation remains **NO-GO** until a separate switch activation phase.

## Cache Note

Config cache was not cleared in this phase.

Reason:

- switch values are default `0`
- no activation was intended
- stale cache can only keep effective behavior off

Before any future switch activation:

- clear system config cache
- re-read switch value
- activate only one switch

## Rollback

Rollback remains config-only for future activation:

```sql
UPDATE `eb_system_config`
SET `value` = '0'
WHERE `menu_name` = '<one_core_settlement_switch>';
```

Do not mutate ledger history.

If this Phase 14 schema itself ever needs rollback, stop and require a new approval package; do not drop the table casually because it is an append-only audit ledger.

## Forbidden Areas

Do not touch without explicit approval:

- `backend_src/app/controller/api/v1/manghe/MangheController.php`
- payment
- order
- real inventory deduction
- ledger history mutation
- switch activation
- server `.env`
- `game/*`
- `mobile-app/*`
- `mobile-app-v3/*`
- unrelated dirty worktree changes

## Next Task

Phase 15 should be switch activation planning or one-switch activation.

Recommended safe next phase:

1. run PHP asserts again
2. clear config cache only immediately before activation
3. open only `core_settlement_checkin_shadow`
4. trigger or simulate only one low-risk checkin path if approved
5. verify one append-only ledger row shape
6. verify duplicate idempotency
7. roll back switch to `0` if any error appears

Do not activate farm, mine, daily task, or pet feeding in the same phase.

## NEXT WINDOW HANDOFF PACKAGE

- Role: Backend Master Controller
- Phase: Phase 15 one-switch activation planning
- Completed: Phase 14 table and switch default-off DB readiness
- Key Findings: table exists; switches exist and remain `0`; ledger row count is `0`
- Key Files: this report, `docs/backend-master/CoreSettlement_Phase13_Backup_Artifact_Report_2026-05-18.md`, `docs/backend-master/CoreSettlement_Phase10_NoExecution_Migration_Readiness_2026-05-18.md`
- Backup Artifact: `/Users/joe/eccomall/db_backup/db_20260518_050233.sql.gz`
- Dirty Worktree Notes: unrelated game/mobile/v3/docs deletions remain; do not stage broad changes
- Forbidden Areas: payment/order/Manghe/switch activation without explicit phase/ledger mutation/game/mobile/v3
- Next Step: plan or execute one-switch checkin activation only after explicit approval
- Validation: backup verified, pre-check, SQL execution, post-check
- Risks: config cache not cleared; activation must be separate and one switch at a time
