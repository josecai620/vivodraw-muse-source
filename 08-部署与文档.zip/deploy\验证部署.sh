#!/usr/bin/env bash
# 本机验证后台部署是否成功
# 用法: ./deploy/验证部署.sh
echo "==> 验证 http://186.241.72.176/admin/"
code=$(curl -s -o /tmp/admin_verify.html -w "%{http_code}" --connect-timeout 10 --max-time 20 http://186.241.72.176/admin/)
echo "HTTP 状态码: $code"
if [[ "$code" == "200" ]]; then
  echo "✅ 后台可访问"
  grep -q "index.html\|vue\|iview" /tmp/admin_verify.html 2>/dev/null && echo "✅ 页面内容正常" || echo "⚠️ 请手动打开 http://186.241.72.176/admin/ 检查"
else
  echo "❌ 状态码异常或超时，请检查网络后访问: http://186.241.72.176/admin/"
fi
