#!/usr/bin/env bash
# 首页装修：数据库中的布局 JSON 补齐「拼团抽奖 + 积分余额」块（已有则跳过）
# 在服务器项目根目录执行：
#   cd /opt/crmeb-prod && bash deploy/run_home_inject_promo_blocks.sh
# 依赖容器名 crmeb-app（与 clear_cache.sh 一致），后端工作目录 /var/www/backend
set -euo pipefail

# 线上常见为 crmeb-php-fpm；历史文档里曾用 crmeb-app，自动探测
PHP_CONTAINER="${PHP_CONTAINER:-}"
if [[ -z "$PHP_CONTAINER" ]]; then
  if docker ps --format '{{.Names}}' | grep -qx 'crmeb-php-fpm'; then
    PHP_CONTAINER='crmeb-php-fpm'
  elif docker ps --format '{{.Names}}' | grep -qx 'crmeb-app'; then
    PHP_CONTAINER='crmeb-app'
  fi
fi
BACKEND_DIR="${BACKEND_DIR:-/var/www/backend}"

if [[ -z "$PHP_CONTAINER" ]] || ! docker ps --format '{{.Names}}' | grep -qx "$PHP_CONTAINER"; then
  echo "未找到 PHP 容器，请设置 PHP_CONTAINER。当前容器："
  docker ps --format '{{.Names}}'
  exit 1
fi

echo "==> docker exec $PHP_CONTAINER php think home:inject-promo-blocks"
docker exec "$PHP_CONTAINER" sh -c "cd '$BACKEND_DIR' && php think home:inject-promo-blocks"
echo "==> 完成。请刷新「装修 → 首页装修」预览；若前台无变化可再执行 deploy/clear_cache.sh"
