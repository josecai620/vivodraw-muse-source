#!/usr/bin/env bash
# 确保 Docker 服务正常运行（用于 crontab 或手动执行）
# 用法：bash deploy/ensure_services.sh [服务器IP]
# 建议在服务器 crontab: */5 * * * * cd /opt/crmeb-prod && bash deploy/ensure_services.sh
set -euo pipefail

do_ensure() {
  echo "[$(date '+%Y-%m-%d %H:%M:%S')] ensure_services"

  # 0. 磁盘健康检查与预警（根分区使用率超过 90% 给出提示）
  DISK_LINE=$(df -P / | awk 'NR==2{print $2" "$3" "$4" "$5}')
  TOTAL_BLOCKS=$(echo "$DISK_LINE" | awk '{print $1}')
  USED_BLOCKS=$(echo "$DISK_LINE" | awk '{print $2}')
  AVAIL_BLOCKS=$(echo "$DISK_LINE" | awk '{print $3}')
  USE_PERCENT=$(echo "$DISK_LINE" | awk '{print $4}')

  echo "disk: total_blocks=$TOTAL_BLOCKS used_blocks=$USED_BLOCKS avail_blocks=$AVAIL_BLOCKS use=$USE_PERCENT"

  AVAIL=${AVAIL_BLOCKS:-0}
  if [ "$AVAIL" -lt 1048576 ]; then
    echo "磁盘空间不足(<4G)，尝试清理容器日志与未使用镜像..."
    for f in /var/lib/docker/containers/*/*-json.log; do [ -f "$f" ] && truncate -s 0 "$f"; done
    docker system prune -f 2>/dev/null || true
  fi

  # 2. 按顺序启动 Redis -> MySQL -> App（使用实际容器名）
  for name in $(docker ps -a --format '{{.Names}}' | grep -E 'crmeb-redis|crmeb-mysql'); do
    status=$(docker inspect -f '{{.State.Status}}' "$name" 2>/dev/null || echo "none")
    if [ "$status" = "exited" ]; then
      echo "启动 $name"
      docker start "$name"
      sleep 3
    fi
  done
  # Redis 持久化失败时拒绝写入导致 500，启动后解除该限制
  if docker ps --format '{{.Names}}' | grep -q crmeb-redis; then
    docker run --rm --network host redis:7-alpine redis-cli -h 127.0.0.1 -p 6379 CONFIG SET stop-writes-on-bgsave-error no 2>/dev/null && echo "Redis stop-writes-on-bgsave-error=no" || true
  fi
  # 确保 app 的依赖先启动
  status=$(docker inspect -f '{{.State.Status}}' crmeb-app 2>/dev/null || echo "none")
  if [ "$status" = "exited" ]; then
    echo "启动 crmeb-app"
    docker start crmeb-app
  fi

  # 3. 若 app 运行中但 API 异常，尝试重启
  app_status=$(docker inspect -f '{{.State.Status}}' crmeb-app 2>/dev/null || echo "none")
  if [ "$app_status" = "running" ]; then
    code=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:20199/api/get_copyright 2>/dev/null || echo "000")
    if [ "$code" != "200" ]; then
      echo "API 异常(code=$code)，重启 crmeb-app"
      docker restart crmeb-app
    fi
  fi
}

if [ "${1:-}" = "remote" ]; then
  do_ensure
elif [ -n "${1:-}" ]; then
  # 带 IP：SSH 到服务器执行
  ssh -p 22 root@"$1" 'bash -s' << 'REMOTE'
echo "[$(date '+%Y-%m-%d %H:%M:%S')] ensure_services"
AVAIL=$(df / | awk "NR==2 {print \$4}")
if [ "${AVAIL:-0}" -lt 1048576 ]; then
  for f in /var/lib/docker/containers/*/*-json.log; do [ -f "$f" ] && truncate -s 0 "$f"; done
  docker system prune -f 2>/dev/null || true
fi
for name in $(docker ps -a --format "{{.Names}}" | grep -E "crmeb-redis|crmeb-mysql"); do
  status=$(docker inspect -f "{{.State.Status}}" "$name" 2>/dev/null || echo "none")
  [ "$status" = "exited" ] && docker start "$name" && sleep 3
done
[ -n "$(docker ps --format '{{.Names}}' | grep crmeb-redis)" ] && docker run --rm --network host redis:7-alpine redis-cli -h 127.0.0.1 -p 6379 CONFIG SET stop-writes-on-bgsave-error no 2>/dev/null || true
status=$(docker inspect -f "{{.State.Status}}" crmeb-app 2>/dev/null || echo "none")
[ "$status" = "exited" ] && docker start crmeb-app
app_status=$(docker inspect -f "{{.State.Status}}" crmeb-app 2>/dev/null || echo "none")
if [ "$app_status" = "running" ]; then
  code=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:20199/api/get_copyright 2>/dev/null || echo "000")
  [ "$code" != "200" ] && docker restart crmeb-app
fi
REMOTE
else
  do_ensure
fi
