-- 诊断：检查三个商城菜单是否已入库
-- 在 phpmyadmin 或 mysql 客户端执行后，看是否返回 6 条记录

SELECT id, menu_name, pid, is_header, header, menu_path 
FROM eb_system_menus 
WHERE id IN (2200, 2201, 2202, 2203, 2204, 2205) AND is_del = 0;

-- 若返回空，说明 SQL 未在【当前使用的数据库】执行，请导入 add_mall_nav_menus.sql
