# Mystery Box Mall — UI Design Specification for Figma Make

> Target: Western market (EN interface) | Style: HypeDrop dark + Genshin gacha VFX
> Platform: Mobile App + H5 (375px viewport base)
> Theme: Dark-first, neon accents, bold typography, immersive animations

---

## 1. Design Tokens

### 1.1 Color Palette — Dark Theme (Primary)

| Token | Hex | Usage |
|-------|-----|-------|
| `bg-primary` | `#0A0A0A` | Page background |
| `bg-card` | `#1A1A1A` | Card surfaces |
| `bg-elevated` | `#242424` | Modals, sheets, elevated surfaces |
| `bg-input` | `#1F1F1F` | Input fields, search bars |
| `border-default` | `#333333` | Card borders, dividers |
| `border-subtle` | `#2A2A2A` | Subtle separators |
| `text-primary` | `#FFFFFF` | Headlines, primary text |
| `text-secondary` | `#9CA3AF` | Descriptions, meta info |
| `text-tertiary` | `#6B7280` | Placeholder, disabled |
| `accent-gold` | `#FBBF24` | Primary accent (CTA, highlights) |
| `accent-glow` | `#FBBF2440` | Glow effects (40% opacity) |
| `gradient-from` | `#18181B` | Header gradient start |
| `gradient-to` | `#27272A` | Header gradient end |
| `success` | `#22C55E` | Success states |
| `error` | `#EF4444` | Error states |
| `warning` | `#F59E0B` | Warning states |

### 1.2 Rarity Color System

Each rarity tier has a distinct color used across badges, glows, particles, and borders.

| Tier | English | Color | Glow (20% opacity) | Particle Color |
|------|---------|-------|---------------------|----------------|
| Common | Common | `#9CA3AF` | `#9CA3AF33` | Light gray sparks |
| Uncommon | Uncommon | `#3B82F6` | `#3B82F633` | Blue sparkles |
| Rare | Rare | `#A855F7` | `#A855F733` | Purple aurora |
| Epic | Epic | `#F97316` | `#F9731633` | Orange flames |
| Legendary | Legendary | `#EAB308` | `#EAB30833` | Gold particle rain |
| Secret | Secret | `#EC4899` | `#EC489933` | Rainbow storm |

### 1.3 Typography

Font family: `Inter` (primary), `SF Pro Display` (iOS fallback), system sans-serif

| Level | Size | Weight | Line Height | Usage |
|-------|------|--------|-------------|-------|
| Hero | 32px | 900 (Black) | 40px | Hero numbers, pity counter |
| H1 | 24px | 800 (ExtraBold) | 32px | Page titles |
| H2 | 20px | 700 (Bold) | 28px | Section titles |
| H3 | 18px | 700 (Bold) | 24px | Card titles |
| Body | 14px | 400 (Regular) | 20px | Body text |
| Body Bold | 14px | 700 (Bold) | 20px | Emphasized body |
| Caption | 12px | 600 (Semibold) | 16px | Labels, meta |
| Micro | 10px | 700 (Bold) | 14px | Badges, tags |

### 1.4 Spacing Scale

`4px` / `8px` / `12px` / `16px` / `20px` / `24px` / `32px` / `48px`

### 1.5 Border Radius

| Element | Radius |
|---------|--------|
| Page-level cards | `24px` |
| Standard cards | `16px` |
| Buttons | `12px` |
| Input fields | `12px` |
| Tags/Badges | `8px` |
| Pill shapes | `9999px` |
| Avatars | `50%` (circle) |

### 1.6 Shadows & Glows

- Card hover: `0 8px 32px rgba(0,0,0,0.4)`
- Neon glow (accent): `0 0 20px #FBBF2440, 0 0 60px #FBBF2420`
- Rarity glow: `0 0 24px {rarity-color}40`

---

## 2. Component Library

### 2.1 RarityBadge

Small pill displaying item rarity tier.

- **Size**: height 22px, padding 8px horizontal
- **Background**: `{rarity-color}20` (20% opacity)
- **Text**: `{rarity-color}`, Micro weight 700
- **Border**: 1px solid `{rarity-color}30`
- **States**: default only (no interaction)

### 2.2 ItemCard

Displays a backpack/box item with image, name, rarity.

- **Size**: min-width 45%, aspect flexible
- **Background**: `bg-card` with 1px `border-default`
- **Image area**: top section, `bg-primary`, centered emoji or product image, 128px height
- **Info area**: padding 12px. Item name (Body Bold, white), RarityBadge below, price at bottom (H3, accent-gold)
- **Hover/Press**: scale(0.97) with spring animation, subtle glow of rarity color
- **States**: default, pressed, loading (skeleton shimmer)

### 2.3 ActionButton

Primary call-to-action button.

- **Size**: full-width, height 56px, border-radius 12px
- **Primary**: background `accent-gold`, text black weight 700
- **Secondary**: background `bg-card`, border 1px `border-default`, text white
- **Ghost**: background transparent, text `accent-gold`
- **Disabled**: background `#333333`, text `text-tertiary`
- **Press animation**: scale(0.95) spring, ripple effect from touch point
- **Loading**: centered spinner, text "Processing..."

### 2.4 ProgressBar

Horizontal progress indicator (used for pity, collection, tasks).

- **Height**: 8px (standard) / 12px (prominent) / 4px (compact)
- **Track**: `bg-elevated`, border-radius 9999px
- **Fill**: gradient from `{color}` to `{color}CC`, border-radius 9999px
- **Animation**: fill slides in with easing over 600ms on mount
- **Glow variant**: add `box-shadow: 0 0 8px {color}40` on fill

### 2.5 CountdownTimer

Displays time remaining for limited events / orders.

- **Layout**: horizontal row of segments: `DD : HH : MM : SS`
- **Each segment**: `bg-elevated` rounded-lg, monospace font, H3 size
- **Separator**: `:` in `text-secondary`
- **Urgency**: when < 1 hour, color shifts to `error`, pulse animation
- **Label**: Caption below, e.g., "Ends in" or "Auto-cancel in"

### 2.6 MarqueeBanner

Horizontal scrolling feed of recent wins.

- **Background**: `accent-gold` at 10% opacity, full width
- **Height**: 40px
- **Content**: infinite scroll of pill badges: "👤 Username won [ItemName] (RarityBadge)"
- **Animation**: translateX loop, 30s duration, smooth linear

### 2.7 QuickActionButton

Circular icon button for the quick-access toolbar.

- **Size**: 44px circle icon area + label below
- **Icon area**: `accent-gold` at 10% opacity background, 1px `accent-gold` at 20% border
- **Icon**: 18px lucide icon in `accent-gold`
- **Label**: Micro, `text-secondary`, centered below
- **Press**: icon area scales to 0.9, background brightens to 20%

### 2.8 TabBar

Horizontal scrollable filter tabs.

- **Active tab**: background `gradient-from`, text white, no border
- **Inactive tab**: background `bg-primary`, 1px `border-default`, text `text-primary`
- **Badge**: min-width 18px circle overlay, background `accent-gold` at 30%, Micro text
- **Animation**: active indicator slides between tabs, spring easing

### 2.9 EmptyState

Displayed when a list has no content.

- **Layout**: centered vertically, icon (48px, `text-secondary`) + title (Body Bold) + description (Caption, `text-secondary`) + optional CTA button
- **Spacing**: 16px between elements

### 2.10 SkeletonLoader

Shimmer placeholder while data loads.

- **Shape**: matches target component layout (card, list item, etc.)
- **Colors**: `bg-card` base with `bg-elevated` shimmer sweeping left-to-right
- **Animation**: 1.5s infinite ease-in-out

---

## 3. Information Architecture

### 3.1 Page Hierarchy

```
/box (Mystery Box Mall)
├── index ..................... Hall / Lobby (main entry)
├── [id] ..................... Box Detail
│   └── [id]/opening ........ Opening Animation + Result
├── backpack ................. My Backpack (inventory)
├── recycle .................. Recycle Items for Points
├── shipping ................. Request Shipping
├── orders ................... Order List
├── order-detail ............. Order Detail
├── history .................. Opening History
├── draws .................... Draw Records
├── brands ................... Brand List
├── brand/[id] ............... Brand Detail
├── collection ............... Collection Album
├── checkin .................. Daily Check-in & Tasks
├── leaderboard .............. Rankings
├── exchange ................. Trading Market
├── synthesis ................ Item Fusion
├── wishlist ................. Wish Pool
├── pity ..................... Pity System / Guarantee
├── probability .............. Odds Disclosure
├── replay ................... Opening Replay (planned)
└── friends .................. Friends & Social (planned)
```

### 3.2 Navigation Flow

```mermaid
flowchart TD
    MainApp[Main Mall Homepage] -->|"Box icon in header"| Hall[Mystery Box Hall]
    Hall --> BoxDetail["Box Detail [id]"]
    BoxDetail --> Opening["Opening Animation"]
    Opening --> Backpack[My Backpack]
    Opening -->|"Open Another"| BoxDetail
    Hall --> Checkin[Daily Check-in]
    Hall --> Leaderboard[Rankings]
    Hall --> Exchange[Trading Market]
    Hall --> Synthesis[Item Fusion]
    Hall --> Wishlist[Wish Pool]
    Hall --> Pity[Pity System]
    Hall --> Probability[Odds Disclosure]
    Hall --> Orders[My Orders]
    Hall --> Draws[Draw Records]
    Hall --> Brands[Brand Series]
    Hall --> Collection[Collection Album]
    Hall --> Shipping[Request Shipping]
    Backpack --> Recycle[Recycle]
    Backpack --> Shipping
    Brands --> BrandDetail["Brand Detail"]
    BrandDetail --> BoxDetail
```

---

## 4. Page-by-Page Design Prompts (for Figma Make)

### 4.1 Hall / Lobby — `index`

```
Design a dark-themed mystery box mall lobby screen for a mobile app (375px wide).

HEADER (top, sticky):
- Background: linear gradient from #18181B to #27272A
- Left: back arrow icon (white)
- Center: title "Mystery Box" in H1 bold white, below it a small row showing a sparkle icon + "12,500 pts" in Caption gold (#FBBF24)
- Right: theme toggle icon

QUICK ACCESS BAR (below header, horizontal scroll):
- Background: #1A1A1A with bottom border #333
- Row of 13 circular icon buttons (44px each) with labels below:
  Backpack | Check-in | Orders | Draws | Rankings | Trade | Fusion | Wishlist | Pity | Odds | Brands | Collection | Shipping
- Each: circle with #FBBF24 at 10% bg, icon in gold, label in gray micro text
- Horizontally scrollable, slight fade at edges

MARQUEE (below quick access):
- Full width strip, background #FBBF24 at 10%
- Scrolling pills: "👤 Alex won AirPods Pro [Epic]" with rarity-colored badge
- Smooth infinite horizontal scroll animation

NOTIFICATION BANNER (conditional):
- Rounded-xl card, #FBBF24 at 10% bg, 1px gold border at 20%
- Star icon + announcement text in gold

HOT BOX CARD (hero section):
- Large rounded-3xl card, #FBBF24 at 30% bg, 1px gold border at 50%
- Top-left: red-orange gradient pill "🔥 HOT PICK"
- Layout: left side has large box emoji/image (80px), right side has:
  - Box name in H1 white
  - Description in Body secondary
  - Progress bar (opened/total) with gold fill
  - Price in Hero gold + "pts" suffix
  - "Open Now" button with lightning icon, gold bg, black text
- Bottom: thin rarity distribution bar (colored segments)

ALL SERIES GRID (below hot box):
- Section header: "All Series" H2 left, "View All >" link right in gold
- 2-column grid of box cards:
  - Each: rounded-2xl, #1A1A1A bg, 1px #333 border
  - Top: image area (bg-primary, centered emoji, 128px)
  - Bottom: name (Body Bold), description (Caption), rarity bar, price (H3 gold), arrow button
  - "Opened 1,234 times" micro text at bottom

FOOTER: 32px bottom padding, no tab bar

NEW USER GUIDE MODAL (first visit only):
- Dark overlay 70% opacity
- Centered card 360px max width, rounded-3xl
- Top section: gradient header with large emoji + title + description
- Bottom: step indicators (dots) + Next/Previous buttons
- 5 steps walking through app features
- Final step: "Start Exploring" gold CTA
```

### 4.2 Box Detail — `[id]`

```
Design a dark mystery box detail screen (375px wide).

HEADER:
- Gradient background #18181B to #27272A
- Back arrow, title "Box Detail" centered, theme toggle right

BOX INFO CARD (hero):
- Full-width rounded-2xl with gradient from #18181B to #27272A
- Centered: box image (96px in rounded container with 20% white bg)
- Box name H1 white, description Body white 90% opacity
- Rarity distribution bar (colored segments, 8px tall, rounded)
- Stats row: "Opened 5,432" left, "Max ¥2,999" right, Caption white 80%

OPEN OPTIONS CARD:
- bg-card rounded-2xl, 1px border, padding 20px
- Title "Open Options" H3
- 4 option buttons in a row: "Single" / "3x Draw" / "5x Draw" / "10x Draw"
  - Selected: gradient bg, white text
  - Unselected: bg-primary, 1px border, white text
- Cost display: bg-primary rounded-xl, "Total: 500 pts" in H1 gold
- Payment method: two cards side by side "Points (12,500 pts)" and "Balance ($45.00)"
  - Selected: gradient bg, white text + value
  - Unselected: bg-primary, 1px border
- Discount row (conditional): gold tinted row showing "Yuanqi Discount: 85%"

POSSIBLE ITEMS LIST:
- Section header: Package icon + "Possible Items" H2
- Card with rounded-2xl, bg-card, 1px border
- Each item row: image (48px rounded-xl) + name (Body Bold) + RarityBadge + probability% right
- Separated by 1px border-default dividers

RECENT OPENINGS:
- Section header: Sparkle icon + "Recent Openings" H2
- Same card style as items list
- Each row: avatar (32px circle) + "Username opened" + item name in rarity-colored pill + time right

STICKY BOTTOM BAR:
- Fixed at bottom, bg-card, top border #333, padding 12px horizontal + 32px bottom (safe area)
- Left: current selection label (Caption) + total cost (H2 gold)
- Right: "Open Now" button with lightning icon, gold bg, black text, 48px tall
- Disabled state: gray bg, gray text when can't afford
```

### 4.3 Opening Animation — `[id]/opening`

```
Design a full-screen dark opening animation result screen (375px wide).

HEADER:
- Gradient background, back arrow left, "Opening..." / "Opened!" center, theme toggle right

ANIMATION STAGES (center of screen):
Stage 1 - Shake: Large box emoji (64px) in gradient rounded container, shaking left-right
Stage 2 - Crack: Box scales up 1.2x-1.5x, crack lines appear
Stage 3 - Reveal: Box fades out, item appears in a circle with rarity-colored border (4px)
  - Circle: 140px, rarity-color bg at 30%, rarity-color border
  - Item emoji/image centered inside
Stage 4 - Result: Full result card

RESULT CARD (after animation):
- Centered card, bg-card, rounded-3xl, 1px border, padding 32px
- Item circle: 120px, rarity-colored border 4px, rarity glow shadow
- Item image/emoji inside (56px)
- Item name: H1 white, bold
- Rarity badge: pill shape, rarity-colored, H3 text

ACTION BUTTONS (below card):
- "Share Result" button: rarity-colored border 2px, rarity-colored text, Share2 icon
  - This is the FIRST button (most prominent)
- "Go to Backpack" button: gold bg, white text, ShoppingBag icon
- "Open Another" button: bg-card, 2px border, white text, Package icon
- All buttons: 52px height, rounded-xl, full width, 12px gap between

PARTICLE EFFECTS (per rarity — described for developer):
- Common: none
- Uncommon: blue sparkle dots floating up
- Rare: purple aurora ring expanding outward
- Epic: orange flame particles bursting from center
- Legendary: gold particle rain falling + light beam from top + screen flash
- Secret: rainbow particle storm + full-screen chromatic aberration + continuous glow
```

### 4.4 Backpack — `backpack`

```
Design a dark inventory/backpack screen (375px wide).

HEADER: gradient, "My Backpack" title

TAB FILTER BAR (horizontal scroll):
- 4 tabs: All | Pending | Shipped | Recyclable
- Each tab: pill shape, icon + label + count badge
- Active: gradient bg, white text, badge white 30% bg
- Inactive: bg-primary, 1px border, text-primary, badge gold 30% bg
- Count badge: 18px min-width circle, Micro text

ITEM LIST:
- Each item: rounded-2xl card, bg-card, 1px border
- Layout: 64px image square left + name (H3), RarityBadge, source text ("BoxName · Recycle 50 pts") + status badge right + action buttons
- Status badges: Shipped (green), Pending (amber), Recyclable (gray)
- Action buttons: "Ship" (outline), "Recycle" (gold) — contextual per status
- Spacing: 12px gap between cards

EMPTY STATE: package icon + "Your backpack is empty" + "Go open some boxes" CTA
```

### 4.5 Daily Check-in & Tasks — `checkin`

```
Design a dark-themed daily check-in and tasks screen (375px wide).

HEADER: gradient, "Check-in & Quests" title

STATS BANNER:
- Rounded-3xl card with gold gradient (30% to 10%)
- Left: "Streak" label + Hero number + "days"
- Right: "Total" label + H2 number + "days"

7-DAY CALENDAR:
- Row of 7 circles (42px each):
  - Past days: gold bg, white checkmark icon
  - Today (not checked): gold border 2px, transparent bg, pulsing glow animation
  - Today (checked): gold bg, checkmark
  - Future: gray bg 60%, gray text "+15" showing reward
  - Day 7 special: gift icon instead of number
- Labels below each: "Day 1" through "Day 7" in Micro

CHECK-IN BUTTON:
- Full width, 48px, rounded-xl
- Not checked: gold bg, "Check in — Earn 20 pts" white text + Calendar icon
- Checked: gray bg, "Checked in ✓" gray text
- Press: confetti particle burst animation

DAILY QUESTS SECTION:
- Header: Target icon + "Daily Quests" H2 + "3/5 done · 35/85 pts" Caption right
- Overall progress bar: gold fill, 8px

- Quest cards (5 items):
  - Each: rounded-2xl, bg-card, 1px border, horizontal layout
  - Left: 40px icon square (themed bg 20%)
  - Middle: quest title (Body Bold) + description (Caption) + mini progress bar
  - Right: "+5 pts" gold label + status (completed badge or "0/3" progress)
  - Completed items: 70% opacity, gold tinted border
  
  Quests:
  1. "Open 1 Box" — Package icon — +5 pts
  2. "Browse 3 Series" — Eye icon — +5 pts
  3. "Open 3 Boxes" — Repeat icon — +15 pts
  4. "Share a Result" — Star icon — +10 pts
  5. "Open 10 Boxes" — Trophy icon — +50 pts
```

### 4.6 Leaderboard — `leaderboard`

```
Design a dark-themed rankings screen (375px wide).

HEADER: gradient, "Leaderboard" title

TAB BAR (3 tabs, equal width):
- "🔥 Lucky" | "🏆 Active" | "👑 Rare"
- Active: gradient bg, inactive: bg-primary + border

RANKING LIST:
- Top 3 entries have special styling:
  - #1: gold tinted bg (#FFD700 at 10%), gold medal icon, gold border
  - #2: silver tinted bg (#C0C0C0 at 10%), silver medal
  - #3: bronze tinted bg (#CD7F32 at 10%), bronze medal
- Regular entries: bg-card, 1px border

Each entry row (rounded-2xl, padding 16px):
- Rank indicator: medal icon (top 3) or number (rest)
- Avatar: 36px circle, gray bg, 👤 emoji
- Username (Body Bold white)
- Secondary info: RarityBadge + best item name (Lucky tab), or count (Active tab)
- Right: stat number in gold ("12 wins" / "50 opens")
- Spacing: 8px gap between rows
```

### 4.7 Trading Market — `exchange`

```
Design a dark-themed item trading marketplace screen (375px wide).

HEADER: gradient, "Trading Market" title, + (plus) icon button right for creating listing

SEARCH & FILTER:
- Search bar: bg-primary, 1px border, rounded-xl, 40px height, search icon + placeholder "Search items..."
- Filter pills: horizontal scroll row of rarity filters (All, Uncommon, Rare, Epic, Legendary, Secret)
  - Active: rarity-colored bg 30%, rarity border
  - Inactive: bg-primary, 1px border

LISTING COUNTER: "42 listings" Caption text

TRADE CARDS:
- Each: rounded-2xl, bg-card, 1px border
- Top: poster avatar + username (Body Bold) + date (Micro right)
- Middle: 3-column layout:
  - Left: offering item (64px rounded-2xl card with rarity bg, emoji, name, RarityBadge)
  - Center: trade icon (Repeat2, gold) + "Trade" label
  - Right: wanted item (64px dashed-border card, "❓" emoji, want description, rarity badge "Wants Epic")
- Bottom: "Request Trade" button, gold tinted bg 20%, gold border 40%, gold text

CREATE LISTING PANEL (inline expandable):
- Bordered card with accent border 2px
- "Post a Trade" H3 title
- Horizontal scroll of user's items (selectable, rarity-colored border when selected)
- Text input for want description
- Cancel + Post buttons row

EMPTY STATE: Repeat2 icon + "No listings yet" + "Post the first one" CTA
```

### 4.8 Item Fusion — `synthesis`

```
Design a dark-themed item fusion/synthesis screen (375px wide).

HEADER: gradient, "Item Fusion" title

RECIPE SELECTOR (horizontal scroll):
- Cards showing fusion recipes: "3x Common → Uncommon" with from/to color circles
- Active: target rarity bg 20%, 2px target-color border
- Shows success rate percentage

FUSION DISPLAY (hero section):
- Large rounded-3xl card, target rarity gradient bg
- Center: visual formula — "×3" in from-color rounded square + sparkle icon + "×1" in to-color rounded square
- Labels: from-rarity name left, to-rarity name right
- Stats: "60% Success" and "2/3 Selected" in Hero numbers

MATERIAL SELECTION:
- "Select Materials (Rare)" H2 section title
- Grid of items (4 per row, square aspect):
  - Each: rounded-xl, rarity bg when selected, 2px border
  - Selected: rarity border + green checkmark overlay top-right
  - Content: emoji (24px) + name (Micro) below
- Empty state: "No Rare items in backpack" + "Go open boxes" CTA

RESULT DISPLAY (after fusion):
- Success: target-color tinted card, "✨" large emoji, "Fusion Successful!" H1, item description
- Failure: gray card, "💨" emoji, "Fusion Failed" H1, "Materials consumed" Body

WARNING: Info icon + "Failed fusions consume materials" Caption

STICKY BOTTOM BUTTON:
- Fixed bottom bar, "Fuse (2/3)" ActionButton
- Enabled when material count = recipe requirement
- Loading state: spinner + "Fusing..."
```

### 4.9 Wish Pool — `wishlist`

```
Design a dark-themed wishlist/wish pool screen (375px wide).

HEADER: gradient, "Wish Pool" title

STATS BANNER:
- Gold gradient card, Star icon + "My Wishes" H2
- Left: Hero number of total wishes
- Right: row of rarity mini-pills showing count per tier

ADD WISH BUTTON:
- Dashed border card, Heart icon + "Add a Wish" gold text
- Tap to expand selection panel

SELECTION PANEL (expandable):
- List of available box series from API
- Each: rounded-xl, bg-primary, 1px border
  - Left: box emoji + name + price
  - Right: "Wish" gold pill button
- Adds wished item to list below

WISH LIST:
- Each card: rounded-2xl, bg-card, 1px rarity-colored border at 30%
- Left: 48px square, rarity-colored bg, item emoji
- Middle: item name (Body Bold) + rarity badge + "From BoxName" Caption
- Right: bell icon (gold = notify on, gray = off) + trash icon (red)

EMPTY STATE: Star icon + "Your wish pool is empty" + description about getting notified on probability-up events
```

### 4.10 Pity System — `pity`

```
Design a dark-themed pity/guarantee system screen (375px wide).

HEADER: gradient, "Pity System" title

PITY PROGRESS CARD (hero):
- Rounded-3xl, gold gradient bg (30% to 10%)
- Shield icon + "My Pity Progress" H2
- Center: Hero number (huge, gold) = consecutive pulls without rare
- Label: "consecutive non-rare pulls" Caption

4 PROGRESS TIERS:
- Each tier row:
  - Left: colored dot + tier name "Rare Guarantee" (Body Bold)
  - Right: "7 more" or "Triggered!" (Caption, colored when triggered)
  - Below: full-width progress bar (8px) with tier color fill
  - Thresholds: Rare (10), Epic (30), Legendary (60), Secret (90)

RULES SECTION: "How it Works" H2
- 4 rule cards in a list:
  1. TrendingUp icon (blue) — "Cumulative Guarantee" + description
  2. Zap icon (orange) — "Trigger Points" + "10/30/60/90 pull thresholds"
  3. Gift icon (green) — "Reset on Hit" + description
  4. Shield icon (purple) — "Cross-Box Tracking" + description
- Each: bg-card, icon square left (themed bg), title + description right

FAQ SECTION: "FAQ" H2
- Accordion-style Q&A pairs
- Q: Body Bold, A: Caption secondary
- Separated by 1px dividers
```

### 4.11 Odds Disclosure — `probability`

```
Design a dark-themed probability disclosure screen (375px wide).

HEADER: gradient, "Odds Disclosure" title

COMPLIANCE NOTICE:
- Gold-tinted card, ShieldCheck icon
- "Probability Disclosure Statement" title
- Legal text explaining the odds system

GLOBAL RATES TABLE:
- "Base Odds Overview" H2
- bg-card rounded-2xl, divided rows:
  - Each: rarity dot (40px square, themed bg) + tier name + description + rate percentage (H2, rarity-colored)
  - Rates: Common 45% / Uncommon 30% / Rare 15% / Epic 7% / Legendary 2.5% / Secret 0.5%

VISUAL DISTRIBUTION BAR:
- "Odds Distribution" H2
- Single horizontal bar (32px tall, rounded-full) with colored segments proportional to rates
- Legend below: colored squares + labels + percentages

PER-SERIES RATES (if available):
- "Series-Specific Odds" H2
- Collapsible cards per box series
- Each: box name + "View details →" link + mini rarity bar + percentage labels

LEGAL FOOTER:
- Gray tinted card, Info icon
- 4 numbered legal notes about independent random events, pity system reference, periodic updates, customer service
```

### 4.12 Orders — `orders`

```
Design a dark order list screen (375px). FlatList with infinite scroll.
Header: gradient, "My Orders".
Each order card: bg-card rounded-2xl, order ID + date header, item list preview, 
status badge (Pending=amber with countdown "Auto-cancel in MM:SS", Paid=green, Shipped=blue, Completed=gray),
total amount in gold. Tap to go to order detail.
Empty: FileText icon + "No orders yet".
```

### 4.13 Order Detail — `order-detail`

```
Order detail screen. Header gradient "Order Detail".
Order info card: ID, creation time, status with colored badge.
Items list with images and rarity badges.
Payment info: method, amount, discount.
Pending orders: countdown timer + "Pay Now" gold CTA.
Shipping info section (if shipped): tracking number, address.
```

### 4.14 Shipping — `shipping`

```
Shipping request screen. Header gradient "Request Shipping".
Address selector: dropdown of saved addresses, default auto-selected.
"Manage Addresses" link in gold.
Item selection: checkboxes for backpack items eligible for shipping.
Summary: selected count + estimated shipping fee.
"Submit Shipping Request" gold CTA at bottom (sticky).
```

### 4.15 Recycle — `recycle`

```
Item recycling screen. Header gradient "Recycle".
Recycle ratio display card: "Current rate: 80%" in gold.
Item grid with multi-select checkboxes (rarity-colored borders when selected).
Bottom summary bar: "X items selected · Y pts return" + "Confirm Recycle" gold button.
Warning text: "Recycled items cannot be recovered."
```

### 4.16 History — `history`

```
Opening history screen with FlatList infinite scroll. Header "Opening History".
Stats card at top: total opens, total spent, best rarity ever.
Timeline list: each entry shows box name, item won (with rarity badge), timestamp.
Tap entry to replay opening animation (future: links to /replay).
```

### 4.17 Draw Records — `draws`

```
Draw/lottery records screen. Header "Draw Records". FlatList infinite scroll.
Each record: draw ID, box name, status (pending/revealed/claimed), 
result preview with rarity badge, timestamp.
Pending draws show "Awaiting reveal" amber badge.
```

### 4.18 Brands — `brands`

```
Brand series list. Header "Brand Series".
Grid or list of brand cards: brand logo/image, brand name (H3),
box count ("12 boxes"), brief description.
Tap to enter brand detail page.
```

### 4.19 Brand Detail — `brand/[id]`

```
Brand detail page. Header with brand name.
Brand hero: large image/logo, description, stats.
Box grid below: all boxes in this brand series, same card style as Hall grid.
```

### 4.20 Collection Album — `collection`

```
Collection/album screen. Header "Collection".
Series cards, each showing:
- Series name + box image + "5/8 collected" progress
- Progress bar (accent color when complete)
- Item grid (4 per row, square): unlocked items show image+name+rarity, locked show 🔒+"???"
- Completion reward: "Claim 100 pts Reward" gold CTA when 100% complete
```

### 4.21 Opening Replay — `replay` (Planned)

```
Opening replay screen. Header "Replay".
List of past openings from history.
Each row: box name, item won, rarity badge, "Replay ▶" button.
Tapping replay triggers the same 4-stage opening animation (shake/crack/reveal/result)
using the historical result data. Share button on result.
```

### 4.22 Friends & Social — `friends` (Planned)

```
Friends screen. Header "Friends".
Tab bar: "Friends" | "Activity" | "Add".
Friends tab: list of friends with avatar, username, online status, "View Backpack" link.
Activity tab: feed of friend opening results (realtime), each showing avatar + "opened [item]" + rarity + time.
Add tab: search bar + user search results + "Add Friend" button.
```

---

## 5. User Flows

### 5.1 Core: Open a Box

```mermaid
flowchart TD
    Start[Hall Lobby] --> Browse[Browse Series Grid]
    Browse --> Select[Tap a Box]
    Select --> Detail[Box Detail Page]
    Detail --> ChooseCount["Choose: 1x / 3x / 5x / 10x"]
    ChooseCount --> ChoosePay["Choose: Points or Balance"]
    ChoosePay --> TapOpen[Tap Open Now]
    TapOpen --> CreateOrder["API: createOrder"]
    CreateOrder --> OpenBox["API: addBox"]
    OpenBox --> Animation["Opening Animation (4 stages)"]
    Animation --> Result[Result Screen]
    Result --> Share[Share Result]
    Result --> Backpack[Go to Backpack]
    Result --> Again[Open Another]
```

### 5.2 Daily Engagement

```mermaid
flowchart TD
    Enter[Enter Hall] --> Guide{First Visit?}
    Guide -->|Yes| Tutorial[5-step Guide Modal]
    Tutorial --> Reward["Claim 50pts Welcome Bonus"]
    Guide -->|No| Checkin[Daily Check-in]
    Checkin --> SignIn[Tap Check-in Button]
    SignIn --> Points["Earn 10-100pts based on streak"]
    Points --> Tasks[View Daily Quests]
    Tasks --> Complete[Complete Quests]
    Complete --> BonusPts[Earn Quest Rewards]
```

### 5.3 Item Lifecycle

```mermaid
flowchart TD
    Open[Open Box] --> Backpack[Item in Backpack]
    Backpack --> Ship[Request Shipping]
    Backpack --> Recycle[Recycle for Points]
    Backpack --> Fuse[Use as Fusion Material]
    Backpack --> Trade[List on Trading Market]
    Ship --> PayFreight[Pay Shipping Fee]
    PayFreight --> Delivered[Item Delivered]
    Recycle --> PointsBack[Points Returned]
    Fuse --> FuseResult{Success?}
    FuseResult -->|Yes| HigherItem[Higher Rarity Item]
    FuseResult -->|No| MaterialsLost[Materials Consumed]
    Trade --> Matched[Someone Requests Trade]
    Matched --> Exchanged[Items Exchanged]
```

---

## 6. Motion & VFX Specification

### 6.1 Technology Stack

- **react-native-reanimated**: 60fps native animations (already used)
- **Canvas / WebGL**: H5 particle systems
- **Lottie**: After Effects exported complex animations
- **Haptic Feedback**: device vibration on App (expo-haptics)

### 6.2 Opening Animation — Rarity-Scaled VFX

| Stage | Duration | Common | Uncommon | Rare | Epic | Legendary | Secret |
|-------|----------|--------|----------|------|------|-----------|--------|
| Shake | 1.2s | Gentle sway | Moderate shake | Strong shake | Violent shake | Intense + screen tremor | Chaotic + chromatic aberration |
| Crack | 0.5s | Simple split | Blue cracks | Purple lightning cracks | Orange fire cracks | Gold shattering | Rainbow explosion |
| Reveal | 0.7s | Fade in | Blue sparkles rise | Purple aurora ring | Orange flame burst | Gold rain + light beam | Full-screen rainbow storm |
| Result | Hold | Plain card | Subtle blue glow | Purple pulse glow | Orange fire border | Gold particle rain continues | Rainbow cycling border + stars |
| Haptic | - | None | Light tap | Medium | Strong | Heavy + repeat | Continuous pattern |
| Sound | - | Click | Chime | Sparkle | Explosion | Fanfare | Epic orchestral |

### 6.3 Page Transitions

- All pages: `slide_from_right` (300ms, spring easing)
- Modal: `fade` (200ms) + backdrop blur
- Tab switch: content `fade` (150ms) + indicator `spring` slide

### 6.4 Micro-interactions

| Element | Interaction | Animation |
|---------|------------|-----------|
| ActionButton | Press | scale(0.95) spring + ripple from touch point |
| ItemCard | Press | scale(0.97) + subtle rarity glow pulse |
| QuickAction | Press | scale(0.9) + bg opacity bump |
| TabBar | Switch | indicator slides with spring, content crossfade |
| ProgressBar | Mount | fill slides from 0 to target over 600ms ease-out |
| MarqueeBanner | Always | translateX loop, 30s linear |
| Check-in button | Success | confetti burst (40 particles, gold + white, 1.5s) |
| Fusion success | Trigger | light beam from bottom (1s) + item bounce-in |
| Fusion failure | Trigger | item shatters outward (0.8s) + fade to dust |
| Countdown | Each second | digit flip animation (transform rotateX) |
| Hot box card | Idle | subtle breathing glow on border (2s pulse loop) |
| New badge | Appear | pop-in with overshoot spring |

### 6.5 Ambient Effects

- **Hall background**: slowly drifting golden light particles (very subtle, 10-15 particles, 0.3 opacity)
- **Box detail hero**: rarity-colored soft glow pulsing behind box image
- **Leaderboard top 3**: gentle shimmer effect on medal icons
- **Pity near threshold**: progress bar glows and pulses faster as count approaches threshold

---

## 7. Responsive Notes

- Base viewport: 375px (iPhone SE / standard mobile)
- Max content width: 420px (center on tablets)
- Grid: 2 columns for item grids, 1 column for list views
- Bottom safe area: 32px padding for home indicator
- Top safe area: 48px for status bar (handled by `pt-12` class)

---

## 8. Accessibility

- All interactive elements: minimum 44px touch target
- Color contrast: all text meets WCAG AA on dark backgrounds
- Rarity information: conveyed by both color AND text label (not color-only)
- Loading states: skeleton shimmer + "Loading..." text
- Error states: clear error message + retry action
- Screen reader: all icons have aria-labels

---

*End of specification. Feed each section or individual page prompt to Figma Make for generation.*
