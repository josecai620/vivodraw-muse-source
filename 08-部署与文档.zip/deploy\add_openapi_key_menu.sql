-- Hermes / OpenAPI 密钥管理后台菜单
-- 执行：mysql -u 用户 -p 数据库 < add_openapi_key_menu.sql
-- 幂等：NOT EXISTS 守卫

-- 挂在「设置」(header='setting') 一级目录下
-- pid 取「设置」组的根 id；若不同环境 id 不同，可改为 SELECT 子查询
INSERT INTO `eb_system_menus`
  (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 0, 1, 'md-key', 'Hermes 密钥', 'admin', '', '', '', '', '[]', 50, 1, 1, 1, '/admin/openapi_key', '0', 1, 'setting', 0, 'admin-openapi-key', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/openapi_key' AND `is_del` = 0);
