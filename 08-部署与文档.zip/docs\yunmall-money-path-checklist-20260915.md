﻿# 积分买份/结算金钱路径检查清单（Phase 1）

对照 `OrderController::exchange` / `exchange_all`：

## 已有（需保留并加强）
- [x] 登录 uid
- [x] 手机绑定 `requireBoundPhone`（exchange + exchange_all）
- [x] 事务 `startTrans`
- [x] 行锁 `lock(true)`（用户与商品）
- [x] `client_request_id` 幂等（exchange 已有；exchange_all 2026-09-15 已补）
- [x] 扣积分写流水
- [x] exchange_all 购物车归属校验（`store_cart.uid`）
- [x] exchange_all 份数上限（cart_num 1..200）与 ids 数量上限（<=50）

## 必须补强
- [x] 剩余人次并发超卖复核（满员临界，条件更新）——T09 `CloudBuyService`：行锁 + `UPDATE … WHERE exchange_num + n <= price`；多进程并发测试通过（`yunmall-hybrid/modules/cloud-buy/任务目标记录-T09.md`）
- [x] 开奖前冻结当期参与快照（防改历史）——T09 `DrawService::scheduleReveal` 满员同事务写 `draw_snapshot`（按开奖口径决策：只留档不做门禁）
- [x] 公网接口限流（买份/结算）——T09 `CloudBuyRateLimiter`（Redis 固定窗口，每用户，fail-open）
- [ ] 管理端指定中奖/机器人接口必须强鉴权且默认关闭（T11 范围；T09 新路径不写 `setuid`/`isset`）
- [x] 幸运值规则公示且可审计——T05 定稿 +1/人次、T09 `lucky_value_log` 流水；加权已废弃（不进开奖）
- [ ] 金额/数量上限与异常监控告警（上限已有：份数 1..200、清单 ≤50；告警未做）
- [x] 可验算开奖公式（时间戳求和模运算）——`DrawService::compute` 与 `drawMath.ts` 对拍一致；`resolve` 落地随 T10 后置

> 以上 [x] 表示代码与测试就绪；线上生效以 `deploy/云购T09建表-需批准后执行.sql` 执行为准。

## 禁止
- 客户端提交中奖结果
- 未鉴权调试开奖
- 信任前端传来的 price/entryCost
