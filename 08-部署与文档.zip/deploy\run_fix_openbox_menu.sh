#!/usr/bin/env bash
# 在服务器上执行：修复开盒记录菜单路径
# 用法：ssh root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/run_fix_openbox_menu.sh"
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/opt/crmeb-prod}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SQL_FILE="${SCRIPT_DIR}/fix_openbox_menu.sql"

for envf in "${PROJECT_DIR}/deploy/.deploy.env" "${PROJECT_DIR}/deploy/.env"; do
  if [[ -f "${envf}" ]]; then
    set -a; source "${envf}" 2>/dev/null || true; set +a
    [[ -n "${MYSQL_DATABASE:-}" ]] && break
  fi
done
# 从 ThinkPHP backend_src/.env 解析
if [[ -z "${MYSQL_DATABASE}" ]] && [[ -f "${PROJECT_DIR}/backend_src/.env" ]]; then
  MYSQL_DATABASE=$(grep -E '^\s*DATABASE\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed 's/.*=\s*//;s/[[:space:]\x27\x22]*$//' | head -1)
fi
if [[ -z "${MYSQL_ROOT_PASSWORD}" ]] && [[ -f "${PROJECT_DIR}/backend_src/.env" ]]; then
  MYSQL_ROOT_PASSWORD=$(grep -E '^\s*PASSWORD\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed "s/.*=\s*['\"]*//;s/['\"]*[[:space:]]*$//" | head -1)
fi

MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-${MYSQL_PASSWORD:-${PASSWORD:-}}}"
MYSQL_DATABASE="${MYSQL_DATABASE:-${DATABASE:-}}"

# 若 root 不可用，尝试使用应用账号（从 backend_src/.env）
APP_USER=$(grep -E '^\s*USERNAME\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed 's/.*=\s*//;s/[[:space:]]*$//' | head -1)
APP_PASS=$(grep -E '^\s*PASSWORD\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed "s/.*=\s*['\"]*//;s/['\"]*[[:space:]]*$//" | head -1)

if [[ -z "${MYSQL_DATABASE}" ]]; then
  MYSQL_DATABASE="${DATABASE:-crmeb}"
  [[ -z "${MYSQL_DATABASE}" ]] && MYSQL_DATABASE=$(grep -E '^\s*DATABASE\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed 's/.*=\s*//;s/[[:space:]]*$//' | head -1)
fi

MYSQL_CONTAINER=$(docker ps --format '{{.Names}}' | grep -i mysql | head -1)
[[ -z "$MYSQL_CONTAINER" ]] && MYSQL_CONTAINER="crmeb-mysql"

echo "==> 修复开盒记录菜单"
run_ok=false
if [[ -n "${MYSQL_ROOT_PASSWORD}" ]] && docker exec -i "$MYSQL_CONTAINER" mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" "${MYSQL_DATABASE}" < "${SQL_FILE}" 2>/dev/null; then
  echo "==> 完成（root）"; run_ok=true
fi
if [[ "$run_ok" != "true" ]] && [[ -n "${APP_USER}" && -n "${APP_PASS}" ]] && docker exec -i "$MYSQL_CONTAINER" mysql -u"${APP_USER}" -p"${APP_PASS}" "${MYSQL_DATABASE}" < "${SQL_FILE}" 2>/dev/null; then
  echo "==> 完成（应用账号）"; run_ok=true
fi
if [[ "$run_ok" != "true" ]]; then
  echo "请设置 MYSQL_ROOT_PASSWORD 和 MYSQL_DATABASE，或确保 backend_src/.env 中 USERNAME/PASSWORD 可连接数据库"
  echo "或手动执行: docker exec -i crmeb-mysql mysql -u<用户> -p<密码> <数据库名> < deploy/fix_openbox_menu.sql"
  exit 1
fi
echo "==> 建议：1) docker exec crmeb-app php think clear  2) 退出后台重新登录"
echo "==> 或直接访问: https://你的域名/admin/product/openbox_list"
