# VivoDraw US Trust Surface Audit - 2026-06-21

## Scope

Read-only audit for the autonomous platform ops goal.

Checked whether US shoppers can see basic trust surfaces before paid traffic:

- Support path.
- Shipping / returns / refunds / privacy / terms path.
- Product-first framing.
- Checkout cost review.
- Refund workflow.
- Blind-box visible odds and non-cash recycle language.
- Legacy brand residue.

Not changed:

- No frontend deploy.
- No production SQL.
- No DNS or Nginx change.
- No payment, inventory, ledger, wallet, or marketing-spend action.

## Gate

Run:

```bash
bash deploy/ops/check_us_trust_surface.sh
```

Current expected result: passing for local trust-surface checks once user-facing brand residue stays fixed.

## Current Evidence

Passes:

- `/support` exists and points users to support before payment disputes.
- Support page references orders, delivery, refunds, account, email, ticket, and policy paths.
- `/agreement/[type]` exists.
- Agreement content includes shipping, returns/refunds, privacy, and support rows.
- Product detail says `Goods first. Rewards optional.`
- Product detail links delivery support and order tracking.
- Cart/checkout expose shipping, tax, rewards, and order review before payment.
- Refund route and order service workflow exist.
- Blind-box shelf/opening show visible odds before reveal.
- Recycle copy says points are not cash, not withdrawable, and not transferable.
- No obvious forbidden US-facing claims were found in app/features/components/lib for guaranteed income, cash out, jackpot, downline, or 40% revenue.

Brand residue fixed:

- Browser/page titles now use `VivoDraw`.
- Login membership eyebrow now uses `VivoDraw membership`.
- The trust gate now fails if `Eccomall` appears in user-facing `mobile-app-v3/app`, `features`, `components`, or `lib` source.

Warnings:

- `support@vivodraw.com` appears on the support page, but public health checks still do not prove `vivodraw.com` MX/TXT readiness.

## Operating Conclusion

The local trust routes mostly exist and user-facing brand residue is now guarded.

This does not make paid traffic safe by itself. Public domain, email, and agent surface gates still control launch readiness.

## Next Safe Fix

When the frontend deploy window is safe:

1. Keep backend/project names unchanged unless they are user-facing.
2. Keep `VivoDraw` as the public customer brand across frontend copy.
3. Run:

```bash
bash deploy/ops/check_us_trust_surface.sh
npm run typecheck --prefix mobile-app-v3
```

4. Deploy frontend only through the project-approved deploy script if the change is meant for online acceptance.
