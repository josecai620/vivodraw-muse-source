-- 将积分商城分类图标同步到「系统自带图片」（附件分类 pid=1）
-- 仅补充不存在的记录，不覆盖已有附件

INSERT INTO `eb_system_attachment` (
  `type`,
  `relation_id`,
  `name`,
  `att_dir`,
  `satt_dir`,
  `att_size`,
  `att_type`,
  `pid`,
  `time`,
  `image_type`,
  `module_type`,
  `real_name`
)
SELECT
  1 AS `type`,
  0 AS `relation_id`,
  CONCAT('points_category_', sc.id, '.png') AS `name`,
  CASE
    WHEN sc.pic LIKE '%/uploads/%' THEN SUBSTRING(sc.pic, LOCATE('/uploads/', sc.pic))
    ELSE sc.pic
  END AS `att_dir`,
  CASE
    WHEN sc.pic LIKE '%/uploads/%' THEN SUBSTRING(sc.pic, LOCATE('/uploads/', sc.pic))
    ELSE sc.pic
  END AS `satt_dir`,
  '0' AS `att_size`,
  'image/png' AS `att_type`,
  1 AS `pid`,
  UNIX_TIMESTAMP() AS `time`,
  1 AS `image_type`,
  1 AS `module_type`,
  CONCAT('points_category_', sc.id, '.png') AS `real_name`
FROM `eb_store_category` sc
WHERE sc.pic <> ''
  AND (COALESCE(sc.mall_type, 1) & 2) > 0
  AND NOT EXISTS (
    SELECT 1
    FROM `eb_system_attachment` sa
    WHERE sa.pid = 1
      AND sa.att_dir = (
      CASE
        WHEN sc.pic LIKE '%/uploads/%' THEN SUBSTRING(sc.pic, LOCATE('/uploads/', sc.pic))
        ELSE sc.pic
      END
    )
  );
