# Amazon Tiered Hot Product Candidates - 2026-06-06

Status: research shortlist only. No backend upload yet.

Market: US Amazon demand signals.

Rule: each row must have sales/search evidence before it can enter draft import. Amazon product photos are not approved storefront assets unless PA API / supplier / brand permission is confirmed.

## Price Tiers

- `low`: Amazon reference price roughly `$10-$80`; target platform price usually `$19-$99`.
- `mid`: Amazon reference price roughly `$100-$700`; target platform price usually `$149-$799`.
- `high`: Amazon reference price roughly `$1,000-$3,000`; target platform price usually `$1,199-$3,299`.

## Operating Notes

- Low-ticket goods can carry higher percentage markup because the absolute dollar difference is small.
- Mid-ticket goods need service, rewards, or bundle value. Do not add silly markup to transparent branded goods.
- High-ticket goods are better as premium reward anchors, limited drops, raffle pool anchors, or quoted-order products. Do not blind-upload bulky battery/freight items.
- For Amazon-sourced products, use Amazon as price and demand evidence first. Storefront image source should be CJ, authorized supplier, brand-approved media, or our own edited/reshot asset.

## Shortlist

| Category | Tier | Product direction | Amazon popularity signal | Reference price | Suggested sale price | Pricing analysis | Decision |
|---|---|---:|---|---:|---:|---|---|
| `Beauty & Self-care` | `low` | K-beauty hydrogel / collagen face mask kit | Red-light/face-mask report: top hydrogel mask row shows `100,000+` monthly orders at `$19.00` | `$19` | `$34` | Buy `$19` + ship/risk `$5` = landed `$24`; add service/reward `$10`; sell `$34`. User accepts because beauty replenishment + giftable photos. | `ready_if_rights_clear` |
| `Beauty & Self-care` | `mid` | Hair styling multi-tool / Shark FlexStyle style dryer | Shark FlexStyle keyword report: top hair tools `10,000+`; Shark FlexStyle listings show `$314-$339` | `$314` | `$399` | Buy `$314` + ship/risk `$25` = landed `$339`; add `$60`; sell `$399`. Transparent brand, so markup must be modest. | `watchlist_brand_rights` |
| `Beauty & Self-care` | `high` | Full-body wellness massage chair | Massage chair full-body report: keyword has `18,929` weekly search volume; `30.67%` of first-page ASINs are `$1,000+` | `$1,599` | `$1,999` | Buy `$1,599` + freight/risk `$200` = landed `$1,799`; add `$200`; sell `$1,999`. Use only with freight/returns/warranty plan. | `hold_freight_risk` |
| `Cute Desk / Home Lifestyle` | `low` | Clear drawer organizer set | Desk accessories report: organizer set row shows `70,000+` monthly orders at `$18.99` | `$18.99` | `$34` | Buy `$18.99` + ship/risk `$5` = landed `$23.99`; add `$10`; sell `$34`. Very strong desk/vanity demand and good visual fit. | `ready_if_image_rights_clear` |
| `Cute Desk / Home Lifestyle` | `mid` | Electric standing desk / desk upgrade | Standing desk report: ErGear standing desk row shows `6,000+` orders at `$102.99`; keyword has `133,389` weekly search volume | `$103-$199` | `$199-$299` | Buy `$149` average + ship/risk `$45` = landed `$194`; add `$45-$80`; sell `$239-$274`. Bulky, but user value is obvious. | `watchlist_shipping` |
| `Cute Desk / Home Lifestyle` | `high` | Premium home-office chair / desk bundle | Office chair reports show `217,928` weekly search volume; first-page market includes `$1,000+` segment | `$1,099` | `$1,299` | Buy `$1,099` + freight/risk `$120` = landed `$1,219`; add `$80-$180`; sell `$1,299-$1,399`. Better as bundle, not naked resale. | `watchlist_bundle_only` |
| `Game Gear` | `low` | Hall-effect PC/Xbox-style controller | Gaming controller report: GameSir Hall-effect row `6,000+` orders at `$39.99`; 8BitDo row `3,000+` at `$27.99` | `$28-$40` | `$59` | Buy `$40` + ship/risk `$8` = landed `$48`; add `$11`; sell `$59`. Clear feature value: anti-drift sticks. | `ready_if_compatibility_copy_clean` |
| `Game Gear` | `mid` | Meta Quest 3S / Quest 3 style VR headset | Meta Quest 3 report: Quest 3S row shows `30,000+` orders at `$296`; Quest 3 512GB row shows `10,000+` orders at `$491.99` | `$296-$492` | `$369-$579` | Buy `$492` + ship/risk `$45` = landed `$537`; add `$42-$82`; sell `$579`. Brand transparent; keep markup modest and use points value. | `watchlist_brand_price_transparency` |
| `Game Gear` | `high` | RTX gaming laptop / premium gaming laptop | Gaming laptop report: keyword has `142,786` weekly search volume; RTX 5060 rows show `500+` orders at `$1,099.99-$1,199.99`; `$1,000+` segment is `39.64%` | `$1,099-$1,199` | `$1,399` | Buy `$1,199` + ship/risk `$100` = landed `$1,299`; add `$100`; sell `$1,399`. High desire, but warranty/return exposure is real. | `hold_warranty_risk` |
| `Premium Tech` | `low` | Fast power bank / charging station | Portable power station report: INIU power bank row `10,000+` orders at `$19.99`; charging tower row `10,000+` at `$29.99` | `$20-$30` | `$39` | Buy `$25` + ship/risk `$6` = landed `$31`; add `$8`; sell `$39`. Utility clear, but battery/safety copy must be tight. | `watchlist_battery_cert` |
| `Premium Tech` | `mid` | Self-empty robot vacuum / robot mop | iRobot vacuum report: Roborock Qrevo row `7,000+` orders at `$399.99`; Shark row `4,000+` at `$479.99` | `$399-$480` | `$499-$599` | Buy `$400` + ship/risk `$55` = landed `$455`; add `$44-$94`; sell `$499-$549`. Good mid-ticket tech if return risk controlled. | `watchlist_returns` |
| `Premium Tech` | `high` | MacBook Pro / premium laptop | Apple MacBook Pro report: M5 MacBook Pro row `3,000+` orders at `$1,316.69`; 1TB row `1,000+` at `$1,799` | `$1,316-$1,799` | `$1,499-$2,099` | Buy `$1,317` + ship/risk `$90` = landed `$1,407`; add `$92-$192`; sell `$1,499-$1,599`. Price transparent, margin must be small. | `hold_brand_margin` |
| `Toys / Collectibles` | `low` | LEGO Botanical / small display building set | LEGO sets report: top rows show `30,000+` at `$15.97`; Botanicals Mini Orchid `10,000+` at `$23.99` | `$16-$24` | `$39` | Buy `$24` + ship/risk `$5` = landed `$29`; add `$10`; sell `$39`. Strong display/gift fit, but do not call generic bricks LEGO. | `ready_if_licensed_or_generic_safe` |
| `Toys / Collectibles` | `mid` | Adult collector building set / display model | LEGO Titanic query report shows Starry Night row `3,000+` at `$169.99`; collector sets support `$100-$200` band | `$170` | `$229` | Buy `$170` + ship/risk `$25` = landed `$195`; add `$34`; sell `$229`. Good reward display item, but IP/license matters. | `watchlist_ip_rights` |
| `Toys / Collectibles` | `high` | Arcade cabinet / premium collector play machine | Arcade1Up report: home arcade rows show `$317-$499`; market includes `12.91%` `$1,000+` segment | `$999-$1,499` | `$1,199-$1,699` | Buy `$1,099` + freight/risk `$120` = landed `$1,219`; add `$180`; sell `$1,399`. Good prize-anchor, bad blind upload. | `hold_freight_ip_risk` |
| `Outdoor / Travel` | `low` | Packing cubes / compression travel set | Packing cubes report: top vacuum packing set `30,000+` at `$33.99`; BAGAIL cubes `20,000+` at `$16.99` | `$17-$34` | `$49` | Buy `$34` + ship/risk `$6` = landed `$40`; add `$9`; sell `$49`. High travel demand, easy image styling. | `ready_if_supplier_images_clean` |
| `Outdoor / Travel` | `mid` | Carry-on suitcase / travel backpack | Carry-on luggage report: top travel backpack `10,000+` at `$17.98`; suitcase row `5,000+` at `$38.91`; market `$50-$200` dominates | `$80-$180` | `$129-$249` | Buy `$120` + ship/risk `$35` = landed `$155`; add `$44`; sell `$199`. Use for travel season, avoid supplements shown in noisy results. | `watchlist_shipping` |
| `Outdoor / Travel` | `high` | E-bike / electric dirt bike | Ebike report: keyword has `121,904` weekly search volume; high row `700+` orders at `$1,199.99`; `$1,000+` segment is `22.30%` | `$1,199` | `$1,499` | Buy `$1,199` + freight/risk `$180` = landed `$1,379`; add `$120`; sell `$1,499`. Only with UL/battery/freight return checks. | `hold_battery_freight_risk` |

## First Picks To Actually Source

1. `Clear drawer organizer set` - strongest volume, low risk, easy image.
2. `Packing cubes / compression set` - travel demand is strong and visually clean.
3. `Hall-effect controller` - good platform fit for rewards/gaming users.
4. `K-beauty mask kit` - strongest beauty sales signal, but rights/supplier source needed.
5. `Self-empty robot vacuum` - best mid-ticket practical tech candidate.
6. `MacBook Pro / gaming laptop` - only as premium limited drop or prize anchor, not normal markup bait.

## Image Rule

Amazon images stay as internal reference until rights are confirmed. Storefront assets must come from approved supplier media, PA API-compliant usage, manufacturer permission, or our edited/reshoot pipeline. Direct image scraping is not an operations plan; it is a copyright lottery with worse odds than our blind box.

## Sources

- ASINsight Desk Accessories: https://www.asinsight.com/report/US/desk-accessories
- ASINsight Gaming Controller For PC: https://www.asinsight.com/report/US/gaming-controller-for-pc
- ASINsight Red Light Therapy Mask: https://www.asinsight.com/report/US/red-light-therapy-mask
- ASINsight Shark FlexStyle: https://www.asinsight.com/report/US/shark-flexstyle
- ASINsight Standing Desk: https://www.asinsight.com/report/US/standing-desk
- ASINsight Meta Quest 3: https://www.asinsight.com/report/US/meta-quest-3
- ASINsight Gaming Laptop: https://www.asinsight.com/report/US/gaming-laptop
- ASINsight Portable Power Station: https://www.asinsight.com/report/US/portable-power-station
- ASINsight iRobot Vacuum: https://www.asinsight.com/report/US/irobot-vacuum
- ASINsight Apple MacBook Pro: https://www.asinsight.com/report/US/apple-macbook-pro
- ASINsight LEGO Sets: https://www.asinsight.com/report/US/lego-sets
- ASINsight LEGO Titanic / collector sets: https://www.asinsight.com/report/US/lego-titanic
- ASINsight Arcade1Up: https://www.asinsight.com/report/US/arcade-1up
- ASINsight Packing Cubes: https://www.asinsight.com/report/US/packing-cubes
- ASINsight Carry On Luggage: https://www.asinsight.com/report/US/carry-on-luggage
- ASINsight Ebike: https://www.asinsight.com/report/US/ebike
