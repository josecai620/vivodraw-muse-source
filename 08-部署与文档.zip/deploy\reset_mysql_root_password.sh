#!/usr/bin/env bash
# 在服务器上执行：重置 MySQL root 密码，并更新 .deploy.env，使后续脚本可正常连接
# 用法：ssh root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/reset_mysql_root_password.sh"
# 新 root 密码默认随机生成；也可通过环境变量 NEW_ROOT_PASSWORD 显式指定
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/opt/crmeb-prod}"
DEPLOY_DIR="${PROJECT_DIR}/deploy"
BACKEND_DIR="${PROJECT_DIR}/backend_src"
NEW_ROOT_PASSWORD="${NEW_ROOT_PASSWORD:-$(openssl rand -hex 24)}"
MYSQL_CONTAINER="crmeb-mysql"
MYSQL_IMAGE="mysql:8.0.36"

echo "==> 读取数据库名（从 backend_src/.env）"
MYSQL_DATABASE=""
if [[ -f "${BACKEND_DIR}/.env" ]]; then
  MYSQL_DATABASE=$(grep -E '^\s*DATABASE\s*=' "${BACKEND_DIR}/.env" 2>/dev/null | sed 's/.*=\s*//;s/[[:space:]\x27\x22]*$//' | head -1)
fi
[[ -z "${MYSQL_DATABASE}" ]] && MYSQL_DATABASE="crmeb"

echo "==> 获取数据目录（需在停止前获取）"
MYSQL_DATA_PATH=$(docker inspect "${MYSQL_CONTAINER}" --format '{{range .Mounts}}{{if eq .Destination "/var/lib/mysql"}}{{.Source}}{{.Name}}{{end}}{{end}}' 2>/dev/null || true)
if [[ -z "${MYSQL_DATA_PATH}" ]] || [[ ! -d "${MYSQL_DATA_PATH}" ]]; then
  # bind mount 为目录，volume 为名称
  MYSQL_DATA_PATH="${PROJECT_DIR}/mysql_data"
  [[ ! -d "${MYSQL_DATA_PATH}" ]] && MYSQL_DATA_PATH="/opt/crmeb-prod/mysql_data"
fi

echo "==> 停止 MySQL 容器"
docker stop "${MYSQL_CONTAINER}" 2>/dev/null || true

echo "==> 使用 --skip-grant-tables 临时启动，重置 root 密码"
TMP_CONTAINER="crmeb-mysql-reset-$$"
docker run --rm -d \
  --name "${TMP_CONTAINER}" \
  -v "${MYSQL_DATA_PATH}:/var/lib/mysql" \
  -e MYSQL_ROOT_PASSWORD=placeholder \
  "${MYSQL_IMAGE}" \
  mysqld --skip-grant-tables --skip-networking

sleep 5

echo "==> 执行 ALTER USER 重置密码"
docker exec "${TMP_CONTAINER}" mysql -uroot -e "
  FLUSH PRIVILEGES;
  ALTER USER 'root'@'localhost' IDENTIFIED BY '${NEW_ROOT_PASSWORD}';
  ALTER USER 'root'@'%' IDENTIFIED BY '${NEW_ROOT_PASSWORD}';
" 2>/dev/null || true

docker stop "${TMP_CONTAINER}" 2>/dev/null || true
sleep 2

echo "==> 更新 .deploy.env，再启动正式 MySQL 容器"
mkdir -p "${DEPLOY_DIR}"
APP_PASSWORD=$(grep -E '^\s*PASSWORD\s*=' "${BACKEND_DIR}/.env" 2>/dev/null | sed "s/.*=\s*['\"]*//;s/['\"]*[[:space:]]*$//" | head -1)
APP_USER=$(grep -E '^\s*USERNAME\s*=' "${BACKEND_DIR}/.env" 2>/dev/null | sed 's/.*=\s*//;s/[[:space:]]*$//' | head -1)
if [[ -z "${APP_PASSWORD}" ]]; then
  echo "ERROR: backend_src/.env 缺少 PASSWORD，拒绝写入弱默认 MYSQL_PASSWORD" >&2
  exit 1
fi
cat > "${DEPLOY_DIR}/.deploy.env" << EOF
MYSQL_ROOT_PASSWORD=${NEW_ROOT_PASSWORD}
MYSQL_DATABASE=${MYSQL_DATABASE}
MYSQL_USER=${APP_USER:-crmeb}
MYSQL_PASSWORD=${APP_PASSWORD}
EOF
chmod 600 "${DEPLOY_DIR}/.deploy.env" 2>/dev/null || true

echo "==> 重新启动正式 MySQL 容器"
cd "${DEPLOY_DIR}"
(docker compose --env-file .deploy.env -f docker-compose.yml up -d mysql 2>/dev/null) || \
(docker-compose --env-file .deploy.env -f docker-compose.yml up -d mysql 2>/dev/null) || true

echo "==> 等待 MySQL 就绪"
for i in {1..30}; do
  if docker exec "${MYSQL_CONTAINER}" mysqladmin ping -h 127.0.0.1 -uroot -p"${NEW_ROOT_PASSWORD}" --silent 2>/dev/null; then
    echo "==> MySQL 已就绪，root 密码已重置并写入 deploy/.deploy.env"
    echo "==> 可执行: bash deploy/run_fix_openbox_menu.sh"
    exit 0
  fi
  sleep 2
done

echo "==> 等待超时，请检查容器: docker ps -a"
exit 1
