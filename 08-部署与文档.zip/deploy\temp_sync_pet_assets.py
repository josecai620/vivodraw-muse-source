# -*- coding: utf-8 -*-
"""对比移植 pet 逻辑里 require 的全部 assets/pets 资源，缺什么从 v3 补什么。"""
import io, os, re, shutil

V4 = r'D:\eccomall\mobile-app'
V3 = r'D:\eccomall\mobile-app-v3'
SCAN = [
    'lib/pet-animation-assets.ts', 'lib/pet-animations.ts', 'lib/pets.ts',
    'lib/pet-gift-tiers.ts', 'lib/pet-unlock.ts',
]
req = re.compile(r'require\(["\']\.\./(assets/pets/[^"\']+)["\']\)')
missing = []
for rel in SCAN:
    p = os.path.join(V4, rel.replace('/', os.sep))
    if not os.path.exists(p):
        print('scan file missing', rel); continue
    s = io.open(p, encoding='utf-8').read()
    for asset in req.findall(s):
        dst = os.path.join(V4, asset.replace('/', os.sep))
        src = os.path.join(V3, asset.replace('/', os.sep))
        if os.path.exists(dst):
            continue
        if not os.path.exists(src):
            print('!! v3 也没有:', asset); missing.append(asset); continue
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
        print('copied', asset)
print('done, unresolved =', len(missing))
