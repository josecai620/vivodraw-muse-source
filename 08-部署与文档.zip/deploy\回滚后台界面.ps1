﻿# 后台界面回滚：把 app.js / vendors / css / index.html 换回指定备份版本
#
# 背景：客服相关界面采用「增量叠加」发布 ——
#   新 hash 文件全部落盘、旧 hash 文件全部保留，只切换 index.html。
#   因此回滚只需把入口文件换回某个备份版本，不涉及删除任何文件。
#
# 已发布版本（index.html SHA256 前缀）
#   398f2712   客服浮窗之前的旧后台
#   7061e6ad   客服浮动工作台（拖动/最小化/最大化/关闭）
#   088ccfde   客服浮动工作台 + 拖拽改大小（构建中含浏览器存储，已弃用）
#   97c7aaf0   客服浮动工作台 + 拖拽改大小
#   619bdd69   浮动工作台 + 拖拽改大小 + 顶部未读角标
#   4003508a   浮动工作台 + 拖拽改大小 + 未读角标 + 网站首页 + 在线人数
#   87341d01   再加在线人数详情弹窗
#   435925f5   在线详情去掉农场列（农场将下架）
#   e829b180   在线详情弹窗支持右下角拖拽改大小
#   32e6648a   未接管时显示解锁说明条（当前）
#
# 用法（本机 Windows PowerShell）
#   ./deploy/回滚后台界面.ps1                                   # 只读：列出备份与当前版本
#   ./deploy/回滚后台界面.ps1 -Apply                            # 回滚到最近一次发布前的版本
#   ./deploy/回滚后台界面.ps1 -Apply -Backup 20260920-102947    # 回滚到指定备份
[CmdletBinding()]
param(
    [switch]$Apply,
    [string]$Backup = '',
    [string]$SshHost = 'root@186.241.72.176',
    [int]$SshPort = 49375,
    [string]$IdentityPath = 'C:\Users\cai\.ssh\vivodraw_windows_ed25519'
)
$ErrorActionPreference = 'Stop'
$sshArgs = @('-i', $IdentityPath, '-p', "$SshPort", '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=accept-new')
$L = '/opt/crmeb-prod/backend_src/public/admin'

Write-Host '=== 当前线上 index.html ==='
$cur = (& ssh @sshArgs $SshHost "sha256sum $L/index.html | awk '{print `$1}'" 2>&1 | Out-String).Trim()
$ver = switch -Wildcard ($cur) {
    '398f2712*' { '客服浮窗之前的旧后台' }
    '7061e6ad*' { '客服浮动工作台（无拖拽改大小）' }
    '088ccfde*' { '客服浮动工作台 + 拖拽改大小（旧，含浏览器存储）' }
    '97c7aaf0*' { '客服浮动工作台 + 拖拽改大小' }
    '619bdd69*' { '浮动工作台 + 拖拽改大小 + 顶部未读角标' }
    '4003508a*' { '浮动工作台 + 拖拽改大小 + 未读角标 + 网站首页 + 在线人数' }
    '87341d01*' { '再加在线人数详情弹窗' }
    '435925f5*' { '在线详情去掉农场列' }
    'e829b180*' { '在线详情弹窗支持拖拽改大小' }
    '32e6648a*' { '未接管时显示解锁说明条（当前最新）' }
    default { '未知版本' }
}
Write-Host "  $cur"
Write-Host "  -> $ver" -ForegroundColor Cyan

Write-Host ''
Write-Host '=== 可用备份（用于回滚）==='
$listCmd = 'for d in $(ls -d /opt/crmeb-prod/deploy_backups/admin-2026* 2>/dev/null | sort); do echo "  $(basename $d)  index=$(sha256sum $d/index.html 2>/dev/null | cut -c1-16)"; done'
$list = (& ssh @sshArgs $SshHost $listCmd 2>&1 | Out-String).Trim()
if ($list) { Write-Host $list } else { Write-Host '  （未找到 admin-2026* 备份目录）' -ForegroundColor Yellow }

if (-not $Apply) {
    Write-Host ''
    Write-Host 'DRY-RUN：未做任何修改。' -ForegroundColor Cyan
    Write-Host '  回滚到最近备份：  ./deploy/回滚后台界面.ps1 -Apply'
    Write-Host '  回滚到指定备份：  ./deploy/回滚后台界面.ps1 -Apply -Backup <目录名后缀>'
    exit 0
}

Write-Host ''
Write-Host '=== 执行回滚 ==='
$bakPath = if ($Backup -ne '') { "/opt/crmeb-prod/deploy_backups/admin-$Backup" } else { '' }
$remote = 'set -e' + "`n" +
  'L=/opt/crmeb-prod/backend_src/public/admin' + "`n" +
  ('BAK="' + $bakPath + '"') + "`n" +
  'if [ -z "$BAK" ]; then BAK=$(ls -d /opt/crmeb-prod/deploy_backups/admin-2026* 2>/dev/null | sort | tail -1); fi' + "`n" +
  '[ -d "$BAK" ] || { echo "找不到备份目录: $BAK"; exit 1; }' + "`n" +
  'echo "使用备份: $BAK"' + "`n" +
  'cp -a $L/index.html /tmp/admin-index-before-rollback.html' + "`n" +
  'cp -a "$BAK/index.html" $L/index.html' + "`n" +
  'for f in $(cd "$BAK" && ls *.js 2>/dev/null); do cp -a "$BAK/$f" "$L/view_admin/js/$f"; echo "  还原 js  $f"; done' + "`n" +
  'for f in $(cd "$BAK" && ls *.css 2>/dev/null); do cp -a "$BAK/$f" "$L/view_admin/css/$f"; echo "  还原 css $f"; done' + "`n" +
  'chown www-data:www-data $L/index.html 2>/dev/null || true' + "`n" +
  'chmod 644 $L/index.html 2>/dev/null || true' + "`n" +
  'echo "--- 回滚后 index.html SHA ---"' + "`n" +
  'sha256sum $L/index.html | awk ''{print "  " $1}''' + "`n" +
  'echo "--- 引用 ---"' + "`n" +
  'grep -oE ''(app|chunk-vendors)\.[a-f0-9]+\.(js|css)'' $L/index.html | sed ''s/^/  /'''
$remote | & ssh @sshArgs $SshHost 'bash -s' 2>&1 | ForEach-Object { Write-Host "  $_" }

Write-Host ''
Write-Host '=== 回滚后验活 ==='
Start-Sleep -Seconds 2
$code = (curl.exe -s -o NUL -w '%{http_code}' -L 'https://vivodraw.com/admin-shop/' 2>&1 | Out-String).Trim()
Write-Host "  后台入口 HTTP $code"
Write-Host '  请用浏览器登录后台确认页面正常。'
