# -*- coding: utf-8 -*-
import os, tarfile, lzma
SRC = r'D:\eccomall\mobile-app\dist-root'
OUT = r'D:\eccomall\deploy\v4-root-bundle.tar.gz'
n = 0
with tarfile.open(OUT, 'w:gz') as tar:
    for root, dirs, files in os.walk(SRC):
        for f in files:
            full = os.path.join(root, f)
            arc = os.path.relpath(full, SRC).replace('\\', '/')
            tar.add(full, arcname=arc)
            n += 1
print('files:', n, 'size MB: %.1f' % (os.path.getsize(OUT)/1024/1024))
