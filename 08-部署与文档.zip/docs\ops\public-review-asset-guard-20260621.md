# Public Review Asset Guard - 2026-06-21

## Scope

Read-only guard for review/demo material that accidentally sits under deployable public web roots.

Original known risk:

```text
mobile-app-v3/public/agent-recruit-demo/
```

Expo Web can copy `mobile-app-v3/public` into the exported web build. If a review-only agent recruitment demo sits there, a normal v3 frontend deploy can publish it by accident.

That is not growth. That is leaving a half-built booth open during a trade show.

## Gate

Run:

```bash
bash deploy/ops/check_public_review_assets.sh
```

Current result after quarantine:

```text
Summary: 0 failure(s)
```

Reason: the untracked public copy was moved out of `mobile-app-v3/public/` into:

```text
prototypes/agent-recruit-demo-public-archive-20260621/
```

The reviewed current prototype remains:

```text
prototypes/agent-recruit-demo/
```

## Deployment Boundary

`deploy/deploy-frontend-v3.sh` now runs this guard before building `mobile-app-v3`.

Default behavior:

- If review-only public assets exist, the deploy stops.
- No files are deleted.
- No server is touched.

Temporary local-only bypass:

```bash
ALLOW_REVIEW_PUBLIC_ASSETS=1 bash deploy/deploy-frontend-v3.sh
```

Use that only with explicit owner approval. A bypass makes sense for a controlled internal preview, not public marketing traffic.

## Safe Resolution Options

Option A: Keep as prototype.

- Move or keep reviewed material under `prototypes/agent-recruit-demo/`.
- Remove the public copy from `mobile-app-v3/public/`.
- Run the guard again.

Option B: Promote to public landing asset.

- Decide the route intentionally.
- Verify domain, lead capture, agent-admin surface, copy compliance, and email readiness first.
- Add the asset as tracked production code, not untracked local debris.

Current recommendation: Option A until public domain, email, and agent growth surface are green.

## Quarantine Record

Moved on 2026-06-21:

- `mobile-app-v3/public/agent-recruit-demo/index.html`
- `mobile-app-v3/public/agent-recruit-demo/styles.css`
- `mobile-app-v3/public/agent-recruit-demo/demo.js`

New location:

- `prototypes/agent-recruit-demo-public-archive-20260621/`

This removes the accidental deploy path while preserving visual/reference material.
