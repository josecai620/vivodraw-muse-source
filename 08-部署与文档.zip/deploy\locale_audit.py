import json, re, os, glob

ROOT = r'D:\eccomall\mobile-app'
en = json.load(open(os.path.join(ROOT, 'lib/i18n/locales/en.json'), encoding='utf-8'))
zh = json.load(open(os.path.join(ROOT, 'lib/i18n/locales/zh-TW.json'), encoding='utf-8'))

def has(obj, path):
    cur = obj
    for p in path.split('.'):
        if isinstance(cur, dict) and p in cur:
            cur = cur[p]
        else:
            return False
    return True

key_re = re.compile(r'''(?:\bt|i18n\.t)\(\s*["'`]([A-Za-z0-9_.]+)["'`]''')
used = {}
for f in glob.glob(os.path.join(ROOT, 'app/box/**/*.tsx'), recursive=True):
    src = open(f, encoding='utf-8').read()
    for m in key_re.finditer(src):
        used.setdefault(m.group(1), set()).add(os.path.basename(f))

missing_en = sorted(k for k in used if not has(en, k))
missing_zh = sorted(k for k in used if not has(zh, k))
print('=== missing in EN (%d) ===' % len(missing_en))
for k in missing_en:
    print(k, '<-', ','.join(sorted(used[k])))
print('=== missing in ZH (%d) ===' % len(missing_zh))
for k in missing_zh:
    print(k, '<-', ','.join(sorted(used[k])))
