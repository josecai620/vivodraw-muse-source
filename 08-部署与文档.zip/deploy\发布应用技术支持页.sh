#!/usr/bin/env bash
# 由根 deploy-frontend.sh --support-page-only 调用，仅发布固定的独立支持文档。
# 不构建整站，不使用 rsync --delete，不修改服务器配置或业务数据。
set -euo pipefail
cd "$(dirname "$0")/.."
[[ $# -eq 0 ]] || { echo '此模式只发布至项目固定生产环境，不接受额外参数。'; exit 1; }
source_page='mobile-app-v3/public/app-support.html'
[[ -f "$source_page" ]] || { echo '缺少应用技术支持页面'; exit 1; }
page_digest="$(shasum -a 256 "$source_page" | awk '{print $1}')"
ssh_target='root@186.241.72.176'
ssh_port=49375
ssh -p "$ssh_port" "$ssh_target" 'mkdir -p /opt/crmeb-prod/.support-page-staging && chmod 700 /opt/crmeb-prod/.support-page-staging'
scp -q -P "$ssh_port" "$source_page" "$ssh_target:/opt/crmeb-prod/.support-page-staging/$page_digest.html"
ssh -p "$ssh_port" "$ssh_target" bash -s -- "$page_digest" <<'REMOTE'
set -euo pipefail
digest="$1"
[[ "$digest" =~ ^[a-f0-9]{64}$ ]]
current='/opt/crmeb-prod/frontend-v3-root/current'
root="$(readlink -f "$current")"
case "$root" in /opt/crmeb-prod/frontend-v3-root/*) ;; *) echo '发布目录不在前台范围'; exit 1;; esac
staging="/opt/crmeb-prod/.support-page-staging/$digest.html"
target="$root/app-support.html"
test -f "$root/index.html"
test -d "$root/_expo"
[[ "$(sha256sum "$staging" | awk '{print $1}')" == "$digest" ]]
exec 9>/opt/crmeb-prod/.support-page-staging/publish.lock
flock -x 9
before="$(sha256sum "$root/index.html" | awk '{print $1}')"
if [[ -f "$target" ]]; then
  previous="$(sha256sum "$target" | awk '{print $1}')"
  cp -p "$target" "/opt/crmeb-prod/.support-page-staging/backup-$previous.html"
fi
chmod 644 "$staging"
mv "$staging" "$target"
[[ "$(sha256sum "$target" | awk '{print $1}')" == "$digest" ]]
after="$(sha256sum "$root/index.html" | awk '{print $1}')"
[[ "$(readlink -f "$current")" == "$root" ]] || { echo '检测到主站目录同时发生切换，请复核并发发布。'; exit 1; }
[[ "$before" == "$after" ]] || { echo '检测到主站首页同时发生变化，请复核并发发布。'; exit 1; }
echo "支持页 SHA256: $digest"
echo "商城首页 SHA256 未变: $after"
REMOTE
verify_file="$(mktemp)"
trap 'rm -f "$verify_file"' EXIT
page_url='https://vivodraw.com/app-support.html'
curl -fsS --max-time 30 "$page_url" -o "$verify_file"
[[ "$(shasum -a 256 "$verify_file" | awk '{print $1}')" == "$page_digest" ]] || { echo '线上支持页与本地内容不一致'; exit 1; }
echo "公开页面已核验: $page_url"
