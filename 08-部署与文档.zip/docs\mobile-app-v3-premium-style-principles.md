# mobile-app-v3 Premium Style Principles

Date: 2026-05-19

## Direction

`mobile-app-v3` should feel like a warm premium commerce membership product, not a discount marketplace or a game portal. The site should immediately explain what the platform is: regular shopping, points lottery, blind box lottery, group lottery, free points earning, and two game loops: mine and farm.

## North Star

v3 is not moving v2 screens over. v3 repackages v2 functions into a premium, clear, narrative shopping and rewards platform.

v2's problem: it feels like a function-stacked mall. It has many features, but the visual language is cheap, dense, and close to a generic template site.

v3's direction: it should feel like a curated premium platform. Users should feel they have entered a place for selected products, reward mechanics, and a premium lottery club.

Core strategy: keep the functions, change the atmosphere.

## Style Memory Card

We are building a premium, artistic, international mobile commerce and rewards platform. v3 does not copy v2's cheap function stacking. It preserves v2 function coverage and re-presents it with higher-grade information architecture and visual narrative.

Core platform elements:

- Regular shopping.
- Points lottery.
- Blind box lottery.
- Group lottery.
- Check-in.
- Tasks.
- Mine.
- Farm.
- Two free points earning game loops.

Users should immediately understand these core plays from the homepage and know how to enter shopping, points lottery, blind box opening, group lottery, and free points earning paths.

Homepage role: explain the platform structure, not pile every function onto one screen. Keep it premium, restrained, clear, and spacious. The four core homepage entries should remain: regular store, points lottery, blind box, group lottery. Check-in, tasks, mine, farm, and game loops should be carried by Activity / play center / rewards club.

Activity role: in this project, Activity is not a social feed. It is the play center, rewards club, and free points earning hub. It carries points lottery, blind box, group lottery, check-in, tasks, mine, farm, and game entries.

Page roles:

- `Browse`: premium buyer-store product page.
- `Points`: premium rewards club, not a cheap points exchange page.
- `Box`: blind box reveal theater with ceremony.
- `Group Lottery`: group draw page with clear participants, unlock condition, and prize value.
- `Profile`: member asset center.

Visual keywords: premium, restrained, warm, clear, smooth, curated, spacious, international, rewarding, membership-oriented.

Avoid: cheap gradients, dense icon grids, full-screen icon walls, excessive animation, cheap spinning wheels, slot-machine feeling, noisy explosion effects.

Interaction principles:

- Users understand what the platform is at a glance.
- Core plays are reachable within two steps.
- Buttons give clear feedback.
- Loading uses skeletons.
- Cards have light press depth.
- Page transitions feel smooth.
- Core CTA stays clear.
- Do not let all modules compete for attention at once.

## Core Narrative

First screen goal: users should understand the whole platform in seconds.

- Regular shopping is the main commerce base.
- Points lottery is the reward club path.
- Blind box lottery is the reveal/opening path.
- Group lottery is the shared participation path.
- Mine and farm are free play loops that help users earn points.
- Check-in and tasks are lightweight daily earning paths.

The homepage should not copy v2 layout. v2 is the functional map. v3 is the premium curated expression.

## Visual Rules

- Keep the accepted v3 mood: Manrope, warm paper background, deep green ink, restrained green CTA, soft reward gold/rose, quiet borders.
- Avoid cheap density: no v2-style icon palace, no dense promo grid, no loud gradients, no sticker clutter.
- Use cards only for meaningful objects: product, entry, reward, service row. Do not nest cards inside cards.
- Use large surfaces sparingly. Hero explains the platform, child pages drive action.
- Keep text short and direct. English leads, Traditional Chinese supports through i18n.
- Product pages and commerce shelves should feel like a curated buyer store: real product images, clear value, visible reward hooks.

## UX Rules

- Core destinations must be one tap away: `/browse`, `/points`, `/box`, `/group-lottery`, `/activity`, `/profile`.
- Free earning paths must be easy to find: mine, farm, check-in, tasks.
- Points, blind box, and group lottery pages should feel playful but trustworthy: odds/rules visible, records visible, balances clear.
- Interactions should feel smooth, not noisy: fast route changes, clear press feedback, skeleton/empty states, no decorative waiting.
- Do not trigger real writes from homepage or preview pages: no payment, no production order, no inventory write, no ledger write.

## Page Roles

- `Home`: tells the whole platform story and points users to the right module.
- `Browse`: product-first commerce, with reward hooks attached to products.
- `Points`: international reward club, transparent lottery, balance, tasks, records.
- `Box`: reveal theater, opening path, recycle/record/wishlist.
- `Group Lottery`: team draw participation and shared prize momentum.
- `Activity`: hub for mine, farm, check-in, tasks, reveal, campaigns.
- `Profile`: assets and account control: points, wallet, coupons, orders, saved items, messages.

## Next Window Startup Note

Before continuing v3 UI work, read this file plus:

- `PRODUCT.md`
- `DESIGN.md`
- `mobile-app-v3/features/home/home-model.ts`
- `mobile-app-v3/features/home/index.tsx`

Preserve the accepted homepage direction. Expand the same premium system into child pages instead of adding more density to the homepage.
