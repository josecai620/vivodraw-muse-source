# -*- coding: utf-8 -*-
import io
p = r'D:\eccomall\mobile-app\app\pearl.tsx'
s = io.open(p, encoding='utf-8').read()
old = '{language === "en" ? options[1].shortLabel : "EN"}'
new = '{language === "en" ? "中" : "EN"}'
assert old in s, 'anchor missing'
s = s.replace(old, new)
io.open(p, 'w', encoding='utf-8', newline='').write(s)
print('fixed')
