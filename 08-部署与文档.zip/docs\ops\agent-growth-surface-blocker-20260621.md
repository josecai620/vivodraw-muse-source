# Agent Growth Surface Blocker - 2026-06-21

## Scope

Current blocker report for the autonomous platform ops goal.

No production SQL, DNS change, Nginx/server config change, payment/inventory/ledger write, deploy, or revert was performed.

## Current State

Command:

```bash
bash deploy/ops/check_agent_growth_surface.sh
```

Result:

- PASS: `backend_src/public/agent-admin/index.html`
- PASS: `backend_src/public/agent-admin/assets/app.js`
- PASS: `backend_src/public/agent-admin/assets/app.css`
- FAIL: `/agent-admin` Nginx redirect missing
- FAIL: `/agent-admin/` Nginx standalone route missing
- FAIL: `/agent-admin/index.html` fallback missing
- FAIL: `X-Frame-Options: DENY` for agent-admin route missing
- FAIL: CSP `frame-ancestors 'none'` for agent-admin route missing
- FAIL: `agentPromoSummaryApi`
- FAIL: `agentPromoWalletsApi`
- FAIL: `agentPromoLedgerApi`
- FAIL: `agentPromoCreditApi`
- FAIL: `agentPromoStatusApi`

Summary: `10 failure(s)`.

## Blocking Dirty Changes

Current local worktree has uncommitted deletions in:

```text
backend_src/view/admin/src/api/agent.js
deploy/nginx/eccomall.conf
```

Observed deletions:

- Platform-admin promo API helpers removed from `backend_src/view/admin/src/api/agent.js`.
- Standalone `/agent-admin/` Nginx route removed from `deploy/nginx/eccomall.conf`.

These are not harmless cleanup. They remove surfaces required by:

- `docs/agent-admin-standalone-20260616.md`
- `docs/agent-promo-wallet-mvp-20260616.md`
- `docs/autonomous-platform-ops-20260621.md`
- `docs/growth/us-acquisition-video-playbook-20260621.md`
- `prototypes/agent-recruit-demo/`

## Business Impact

Agent acquisition is not launch-safe while this remains unresolved.

Specific impact:

- New agent recruitment material has no safe operational backend to point to.
- `/agent-admin/` can disappear on deploy if the Nginx deletion ships.
- Platform admins can lose promo wallet summary, wallet, ledger, credit, and freeze/unfreeze helper calls if the admin API helper deletion ships.
- The guard correctly blocks deployment, but a human or another Agent still has to resolve the dirty change source.

Blunt version: running ads for agents while deleting the agent console is like opening a store and unscrewing the front door. Creative, but not commerce.

## Safe Resolution Options

### Option A - Preserve Agent Growth Surface

Use when the platform still wants first-level agents, promo budget, and `/agent-admin/`.

Required outcome:

- Restore `/agent-admin` and `/agent-admin/` route block in `deploy/nginx/eccomall.conf`.
- Restore `agentPromoSummaryApi`, `agentPromoWalletsApi`, `agentPromoLedgerApi`, `agentPromoCreditApi`, and `agentPromoStatusApi` in `backend_src/view/admin/src/api/agent.js`.
- Run:

```bash
bash deploy/ops/check_agent_growth_surface.sh
```

Pass condition:

```text
Summary: 0 failure(s)
```

Risk:

- This touches active uncommitted changes, so the owner or the Agent that made those deletions should confirm they were accidental before applying.

### Option B - Intentionally Retire Agent Promo Surface

Use only if the owner decides to stop the current agent-admin and promo-wallet plan.

Required follow-up:

- Update `docs/agent-admin-standalone-20260616.md`.
- Update `docs/agent-promo-wallet-mvp-20260616.md`.
- Update `docs/autonomous-platform-ops-20260621.md`.
- Update `docs/growth/us-acquisition-video-playbook-20260621.md`.
- Rewrite or remove `prototypes/agent-recruit-demo/`.
- Change `deploy/ops/check_agent_growth_surface.sh` to match the new strategy.

Risk:

- This contradicts the current autonomous ops direction, which prioritizes first-level agents as a near-term growth channel.
- It should not be done as incidental cleanup.

## Current Recommendation

Preserve the agent growth surface.

Reason:

- Current platform strategy repeatedly names first-level agents as a growth channel.
- The prototype and video playbook already depend on `/agent-admin/` and promo-budget framing.
- No current evidence says the owner intentionally retired the agent console or platform-admin promo controls.

Do not deploy while the guard fails unless the owner explicitly approves shipping without the agent growth surface.
