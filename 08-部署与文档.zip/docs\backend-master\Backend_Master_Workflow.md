# Backend Master Workflow

## 总控职责

Backend Master Controller 负责后端与数据库核心规范层总控。目标是保留 CRMEB 基础商城，建立旁路规范层，不重做整个后端，不重做数据库。

核心职责：

- 审计积分、奖励、库存、支付回调、风控、统计、统一结算链路。
- 设计并维护 CoreSettlement、Ledger、Reward、Lock、Log、Analytics 规范。
- 管控迁移草案、接入顺序、风险边界和交接包。
- 多 Agent 并行时负责最终裁决，禁止分身直接改核心链路。

## Phase 流程

### Phase 0：只读审计

目标：识别当前后端与数据库最大风险。

允许：

- 读文档、读源码、读 git 状态。
- 输出风险、可保留模块、必须重构模块、下一阶段建议。

禁止：

- 改代码。
- 改数据库。
- 执行迁移。
- 接入真实业务链路。

### Phase 0.5：基线确认

目标：确认工作树脏改来源，避免覆盖已有代码。

允许：

- `git status --short --branch`
- `git diff --stat`
- `git diff --name-only`
- 只读查看关键 diff。

禁止：

- `git pull`
- `git reset`
- `git checkout`
- 清理文件。
- 覆盖 game/mobile 活跃开发成果。

### Phase 1：核心规范层设计

目标：定义最小 CoreSettlement 规范，不写代码。

输出：

- CoreSettlement 最小职责。
- Ledger System 积分账本设计。
- Reward System 奖励记录设计。
- Reward Claim Lock 幂等领取锁设计。
- Inventory Lock / Inventory Ledger 库存锁与库存流水设计。
- Payment Webhook Log 支付回调日志设计。
- Risk Log 风控日志设计。
- Analytics Event 行为埋点设计。

### Phase 2：工作流固化

目标：形成长期可复用草案。

输出：

- `Backend_Master_Workflow.md`
- `CoreSettlement_SQL_Draft.sql`
- `CoreSettlement_Service_Interface.md`

### Phase 3：SQL Review 与文件落地准备

目标：只落地草案和审查 SQL，不执行。

检查项：

- 表名前缀是否符合 CRMEB `eb_` 习惯。
- 幂等唯一键是否明确。
- JSON 字段是否符合 MySQL 8。
- 索引是否覆盖查询路径。
- 是否明确旁路规范层，不替代旧表。

### Phase 4：旁路服务骨架

目标：只建空 service/interface 和 dry-run，不接旧业务主链路。

禁止：

- 不接 `MangheController`。
- 不接支付。
- 不接订单。
- 不扣真实库存。

### Phase 5：低风险试点

目标：先建立 dry-run 验证入口，再评估是否选择低风险动作接入旁路结算。

候选：

- `core:settlement-dry-run` 命令行验证入口。
- 后台 dry-run 结算记录。
- 低风险测试奖励。
- game 区稳定后，再评估农场或矿洞单动作。

禁止：

- 不接 `MangheController`。
- 不接支付。
- 不接订单。
- 不扣真实库存。
- 不写数据库。

### Phase 6：SQL Review 包与接入计划

目标：只审 SQL 草案和接入边界，不执行 SQL，不接真实业务。

输出：

- SQL Review 结论。
- 禁止接入清单。
- 下一阶段业务接入前置条件。

## 风险区

高风险文件与模块：

- `backend_src/public/index.php`
- `backend_src/app/controller/api/v1/manghe/MangheController.php`
- `backend_src/app/services/pay/*`
- `backend_src/app/services/order/*`
- `backend_src/app/controller/api/v1/integral/*`
- `backend_src/app/services/activity/group_lottery/*`
- `deploy/*.sql`
- 线上 `.env`、支付密钥、数据库、上传目录、备份、运行态目录

当前特别说明：

- `game/` 当前是活跃开发区，本工作流阶段不处理、不清理、不覆盖。
- `backend_src/public/index.php` 有未归属脏改，进入后端实现前必须确认或隔离。

## 禁止事项

- 禁止重写 CRMEB 基础商城。
- 禁止重做数据库。
- 禁止第一批接 `MangheController`。
- 禁止第一批接支付。
- 禁止第一批接订单。
- 禁止第一批接真实库存扣减。
- 禁止执行线上 SQL。
- 禁止执行迁移。
- 禁止强推、reset、checkout 覆盖他人改动。
- 禁止改 game 区当前开发代码。

## 旧表保留原则

以下旧表继续保留：

- `eb_user`
- `eb_user_bill`
- `eb_store_order`
- `eb_store_product`
- `eb_store_product_attr_value`
- `eb_store_integral_product*`
- `eb_store_integral_order*`
- `eb_box_order`
- `eb_user_box`
- `eb_group_lottery*`
- `game_farm_*`
- `game_mine_*`

新 `core_*` 表只做旁路规范层，不替代旧表，不直接承接线上真实业务。

## 分身 Agent 分工

Audit Agent：

- 只读审计旧链路和旧表。
- 不改代码，不出迁移。

SQL Draft Agent：

- 只写 SQL 草案。
- 不执行 SQL。

Interface Agent：

- 只写服务接口设计。
- 不接真实业务。

Risk Agent：

- 检查重复结算、重复领取、库存超扣、重复 webhook、风控漏记。

Master Controller：

- 统一收口。
- 决定是否进入下一 Phase。
- 输出 NEXT WINDOW HANDOFF PACKAGE。

## 交接包格式

```text
NEXT WINDOW HANDOFF PACKAGE
- Role:
- Phase:
- Completed:
- Key Findings:
- Key Files:
- Dirty Worktree Notes:
- Forbidden Areas:
- Next Step:
- Validation:
- Risks:
```
