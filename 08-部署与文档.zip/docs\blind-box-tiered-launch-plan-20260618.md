# Tiered Blind Box Launch Plan - 2026-06-18

## Scope

- Frontend surface: `/box` and `/box/:id`.
- Backend rule: categories with public odds in `store_category.tag1..tag6` use public probability draw.
- Recovery rule: unwanted prizes recycle into platform credits through existing `integral` ledger. Credits are non-withdrawable and for platform use only.
- Data seed: `deploy/seed_tiered_blind_boxes_20260618_approval_required.sql`.

## Box Levels

| Level | Box | Price | Common | Uncommon | Rare | Epic | Legendary | Secret |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | Starter Vault | `$4.99` | `68%` | `22%` | `8%` | `1.7%` | `0.25%` | `0.05%` |
| 2 | Daily Select Box | `$9.99` | `60%` | `25%` | `10%` | `4%` | `0.8%` | `0.2%` |
| 3 | Gift Vault | `$19.99` | `52%` | `28%` | `14%` | `5%` | `0.8%` | `0.2%` |
| 4 | Premium Vault | `$49.99` | `45%` | `30%` | `17%` | `6.5%` | `1.2%` | `0.3%` |
| 5 | Black Label Vault | `$99.00` | `40%` | `30%` | `20%` | `8%` | `1.8%` | `0.2%` |
| 6 | Signature Vault | `$199.00` | `35%` | `29%` | `22%` | `10%` | `3.5%` | `0.5%` |

## Prize Strategy

- Starter and Daily levels use impulse-friendly goods: charms, organizers, small desk goods, beauty tools, utility accessories.
- Gift and Premium levels shift toward giftable self-care, travel, desk, game, and premium tech accessories.
- Black Label and Signature levels use recognizable tech lanes: earbuds, speakers, smart watch drops, consoles, and high-value bundles.
- Avoid unsafe categories: supplements, ingestibles, baby safety products, fake branded goods, unlicensed IP collectibles.

## Recovery Rates

| Rarity | Recovery |
|---|---:|
| Common | `25%` of reference value |
| Uncommon | `28%` |
| Rare | `32%` |
| Epic | `35%` |
| Legendary | `38%` |
| Secret | `40%` |

The seed writes explicit `recovery_price`; backend recovery uses `recovery_price` first, then falls back to `cost`, then price-based rarity rate. Admin product edit must keep recovery at or below `40%` of reference value. Recovery is credited into the existing integer `integral` balance, so the final credited amount is rounded to whole platform points.

## Launch Gate

- Do not run the seed SQL without owner approval.
- Before SQL execution, confirm source product IDs still exist and images are acceptable.
- After SQL execution, verify `/api/manghe/boxTuijian` with `mall_type=6`, `/api/manghe/getBoxShop`, `/box`, and one authenticated open flow in a safe test account.
