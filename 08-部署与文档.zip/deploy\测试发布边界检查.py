# -*- coding: utf-8 -*-
"""在随机临时 Git 仓库验证发布守门；无网络、无生产连接、不修改真实仓库。"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch


CHECKER = Path(__file__).with_name("发布前边界检查.py").resolve()


class 发布边界检查测试(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="发布边界检查-")
        self.root = Path(self.temporary.name).resolve()
        self.repo = self.root / "仓库 空格"
        self.repo.mkdir()
        self.manifest = self.root / "发布清单.json"
        self.environment = dict(os.environ, GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull,
                                PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1")
        self.git("init", "--template=")
        self.git("config", "user.name", "Offline boundary test")
        self.git("config", "user.email", "boundary@example.invalid")
        self.git("config", "core.autocrlf", "false")
        self.git("config", "commit.gpgsign", "false")
        self.write("src/base.txt", b"baseline\n")
        self.git("add", "--all")
        self.git("commit", "-m", "isolated baseline")

    def tearDown(self) -> None:
        # 只清除此测试创建的随机目录；Git 与测试产物都从未写入项目工作区。
        self.temporary.cleanup()

    def git(self, *arguments: str) -> bytes:
        result = subprocess.run(["git", "-C", str(self.repo), *arguments], check=True,
                                capture_output=True, env=self.environment)
        return result.stdout

    def write(self, name: str, content: bytes = b"changed\n") -> Path:
        target = self.repo / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        return target

    def check(self, allowed: list[str], *extra: str, successful: bool = True) -> dict:
        result = subprocess.run([sys.executable, str(CHECKER), "--repo-root", str(self.repo),
                                 "--allow", *allowed, "--manifest", str(self.manifest), *extra],
                                capture_output=True, encoding="utf-8", env=self.environment)
        if successful:
            self.assertEqual(result.returncode, 0, result.stderr)
            return json.loads(self.manifest.read_text(encoding="utf-8"))
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("发布边界检查失败", result.stderr)
        return {"error": result.stderr}

    def assert_digest(self, manifest: dict, path: str, content: bytes) -> None:
        self.assertEqual(manifest["source_states"][path], {
            "deleted": False, "sha256": hashlib.sha256(content).hexdigest(), "size": len(content),
        })
        serialized = json.dumps(manifest["source_states"], ensure_ascii=False, sort_keys=True,
                                separators=(",", ":")).encode("utf-8")
        self.assertEqual(manifest["source_state_sha256"], hashlib.sha256(serialized).hexdigest())

    def test_chinese_spaces_and_arrow_are_literal_untracked_paths(self) -> None:
        path = "页面/中文 空格 客服.ts" if os.name == "nt" else "页面/中文 空格 -> 客服.ts"
        content = "export const label = '客服';\n".encode("utf-8")
        self.write(path, content)
        report = self.check([path], "--artifact", "_expo/中文 产物.js")
        self.assertEqual(report["actual_changed_paths"], [path])
        self.assertEqual(report["artifact_paths"], ["_expo/中文 产物.js"])
        self.assert_digest(report, path, content)
        self.assertEqual(report["schema"], 1)
        self.assertEqual(report["mode"], "scoped-overlay")

    def test_untracked_content_change_changes_state_digest(self) -> None:
        path = "src/new.js"
        self.write(path, b"first\n")
        first = self.check([path])
        self.write(path, b"second\n")
        second = self.check([path])
        self.assertNotEqual(first["source_state_sha256"], second["source_state_sha256"])
        self.assert_digest(second, path, b"second\n")

    def test_staged_and_unstaged_hashes_use_current_bytes(self) -> None:
        self.write("src/base.txt", b"staged\n")
        self.git("add", "src/base.txt")
        staged = self.check(["src/base.txt"])
        self.assert_digest(staged, "src/base.txt", b"staged\n")
        self.assertNotEqual(staged["diff_sha256"], hashlib.sha256(b"").hexdigest())
        self.write("src/base.txt", b"current after staging\n")
        current = self.check(["src/base.txt"])
        self.assert_digest(current, "src/base.txt", b"current after staging\n")
        self.assertNotEqual(staged["source_state_sha256"], current["source_state_sha256"])
        self.assertNotEqual(staged["diff_sha256"], current["diff_sha256"])

    def test_new_staged_file_hash(self) -> None:
        self.write("页面/已暂存.ts", b"new staged source\n")
        self.git("add", "--all")
        self.assert_digest(self.check(["页面/已暂存.ts"]), "页面/已暂存.ts", b"new staged source\n")

    def test_rename_requires_both_old_and_new_path(self) -> None:
        old = "src/旧文件 原名.txt" if os.name == "nt" else "src/旧文件 -> 原名.txt"
        new = "src/新文件 空格.txt"
        self.write(old, b"rename content\n")
        self.git("add", "--all")
        self.git("commit", "-m", "rename fixture")
        self.git("mv", old, new)
        denied = self.check([new], successful=False)
        self.assertIn("清单外改动", denied["error"])
        report = self.check([old, new])
        self.assertEqual(set(report["actual_changed_paths"]), {old, new})
        self.assertEqual(report["source_states"][old], {"deleted": True, "sha256": None, "size": 0})
        self.assert_digest(report, new, b"rename content\n")

    def test_deleted_file_is_recorded(self) -> None:
        self.git("rm", "src/base.txt")
        report = self.check(["src/base.txt"])
        self.assertEqual(report["source_states"]["src/base.txt"], {"deleted": True, "sha256": None, "size": 0})

    def test_extra_untracked_file_still_blocks(self) -> None:
        self.write("src/base.txt")
        self.write("src/其他人的改动.txt")
        self.assertIn("清单外改动", self.check(["src/base.txt"], successful=False)["error"])
        self.assertFalse(self.manifest.exists())

    def test_extra_staged_file_still_blocks(self) -> None:
        self.write("src/base.txt")
        self.write("src/其他人的暂存.txt")
        self.git("add", "src/其他人的暂存.txt")
        self.assertIn("清单外改动", self.check(["src/base.txt"], successful=False)["error"])

    def test_source_paths_cannot_traverse_or_use_absolute_names(self) -> None:
        invalid = ["", ".", "..", "../escape.ts", "./../escape.ts", "src/../../escape.ts",
                   "/absolute.ts", "C:\\outside.ts", "C:relative.ts", "\\\\server\\share\\x.ts",
                   "src//base.txt", "src/./base.txt", "src/base.txt:stream"]
        for path in invalid:
            with self.subTest(path=path):
                self.check([path], successful=False)

    def test_artifacts_cannot_traverse_or_use_sensitive_paths(self) -> None:
        invalid = ["../bundle.js", "/bundle.js", "C:\\bundle.js", "a/../../bundle.js",
                   "a//bundle.js", ".env", "assets/.ENV.production", ".git/config", "file.js:stream"]
        for path in invalid:
            with self.subTest(path=path):
                self.check(["src/base.txt"], "--artifact", path, successful=False)

    def test_sensitive_or_forbidden_sources_cannot_be_allowlisted(self) -> None:
        forbidden = [".env", ".env.production", "config/.env.local", "config/.ENV", ".git/config",
                     "GAME/source.ts", "backend_src/public/index.html", "backend_src/runtime/log.txt",
                     "backend_src/uploads/image.png", "mobile-app-v3/app.ts", "deploy/package.tar.gz"]
        for path in forbidden:
            with self.subTest(path=path):
                self.assertIn("禁止发布路径", self.check([path], successful=False)["error"])

    def test_sensitive_dirty_path_blocks_even_when_other_path_allowed(self) -> None:
        self.write("config/.env.private", b"placeholder only\n")
        self.assertIn("禁止路径", self.check(["src/base.txt"], successful=False)["error"])

    def test_old_address_in_untracked_source_blocks(self) -> None:
        self.write("src/new.txt", b"https://8.166.115.27/api\n")
        self.assertIn("废弃生产地址", self.check(["src/new.txt"], successful=False)["error"])

    def test_old_address_in_staged_source_blocks(self) -> None:
        self.write("src/base.txt", b"https://8.166.115.27/api\n")
        self.git("add", "src/base.txt")
        self.assertIn("废弃生产地址", self.check(["src/base.txt"], successful=False)["error"])

    def test_directory_is_not_a_source_file_allowance(self) -> None:
        self.assertIn("普通源文件", self.check(["src"], successful=False)["error"])

    def test_repeated_allow_option_preserves_all_paths(self) -> None:
        self.write("src/base.txt")
        self.write("src/第二个.txt")
        report = self.check(["src/base.txt"], "--allow", "src/第二个.txt")
        self.assertEqual(set(report["actual_changed_paths"]), {"src/base.txt", "src/第二个.txt"})

    def test_windows_relative_separator_remains_compatible(self) -> None:
        self.write("src/base.txt", b"windows relative\n")
        report = self.check([".\\src\\base.txt"])
        self.assertEqual(report["allowed_source_paths"], ["src/base.txt"])

    def test_manifest_cannot_overwrite_repository_file(self) -> None:
        self.check(["src/base.txt"], "--manifest", str(self.repo / "src/base.txt"), successful=False)
        self.assertEqual((self.repo / "src/base.txt").read_bytes(), b"baseline\n")

    def test_repo_root_must_not_be_a_subdirectory(self) -> None:
        self.check(["src/base.txt"], "--repo-root", str(self.repo / "src"), successful=False)

    def test_invalid_base_ref_fails_closed(self) -> None:
        self.check(["src/base.txt"], "--base-ref", "missing-ref", successful=False)

    def test_custom_baseline_checks_committed_changes_too(self) -> None:
        baseline = self.git("rev-parse", "HEAD").decode().strip()
        self.write("src/已提交但超出范围.txt", b"committed outside selected scope\n")
        self.git("add", "--all")
        self.git("commit", "-m", "new baseline fixture")
        self.assertIn("清单外改动", self.check(["src/base.txt"], "--base-ref", baseline, successful=False)["error"])
        report = self.check(["src/已提交但超出范围.txt"], "--base-ref", baseline)
        self.assertEqual(report["base_commit"], baseline)
        self.assert_digest(report, "src/已提交但超出范围.txt", b"committed outside selected scope\n")

    def test_source_directory_link_or_junction_is_rejected(self) -> None:
        outside = self.root / "仓库外的源文件"
        outside.mkdir()
        (outside / "file.txt").write_bytes(b"must stay outside\n")
        link = self.repo / "linked"
        try:
            os.symlink(outside, link, target_is_directory=True)
        except OSError:
            if os.name != "nt":
                self.skipTest("系统不允许创建符号链接")
            # Windows 不授予文件 symlink 权限时，用实际 junction 验证重解析目录。
            result = subprocess.run(["cmd", "/c", "mklink", "/J", str(link), str(outside)], capture_output=True)
            if result.returncode:
                self.skipTest("系统不允许创建符号链接或 junction")
        self.check(["linked/file.txt"], successful=False)
        self.assertEqual((outside / "file.txt").read_bytes(), b"must stay outside\n")

    def test_in_repo_symlink_is_not_an_allowed_source(self) -> None:
        link = self.repo / "src/linked.txt"
        try:
            os.symlink(self.repo / "src/base.txt", link)
        except OSError:
            self.skipTest("系统不允许创建文件符号链接；目录 junction 另有实测")
        self.assertIn("链接", self.check(["src/linked.txt"], successful=False)["error"])

    def test_nul_parser_preserves_arrow_newline_and_both_rename_sides(self) -> None:
        # Windows 不允许文件名含 > 或换行；直接验证真实解析函数，其他路径走真实 Git 测试。
        module = types.ModuleType("isolated_boundary_checker")
        module.__file__ = str(CHECKER)
        exec(compile(CHECKER.read_text(encoding="utf-8"), str(CHECKER), "exec"), module.__dict__)
        arrow_path = "页面/正常 -> 文件.txt"
        old_path = "src/旧名\n空格.txt"
        new_path = "src/新名 -> 空格.txt"
        raw = ("?? " + arrow_path + "\0R  " + new_path + "\0" + old_path + "\0").encode("utf-8")
        with patch.object(module, "run_git_bytes", return_value=raw):
            self.assertEqual(module.changed_paths(), {arrow_path, old_path, new_path})


if __name__ == "__main__":
    unittest.main(verbosity=2)
