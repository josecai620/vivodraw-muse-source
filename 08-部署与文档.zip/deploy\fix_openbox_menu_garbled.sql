-- 修复开盒记录菜单乱码（确保 menu_name 为正确 UTF-8 中文）
-- 执行：ssh root@8.166.115.27 "docker exec -i crmeb-mysql mysql -uroot -p<密码> <数据库> < deploy/fix_openbox_menu_garbled.sql"

SET NAMES utf8mb4;
UPDATE `eb_system_menus` SET `menu_name` = '开盒记录'
WHERE `menu_path` = '/admin/product/openbox_list' AND `is_del` = 0;
