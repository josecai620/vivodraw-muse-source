# -*- coding: utf-8 -*-
"""仅使用假凭据和临时 .env；不调用 SSH、不接触正式 DPAPI 或生产文件。"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch


WRITER = Path(__file__).with_name("安全写入客服配置.py").resolve()
WRAPPER = WRITER.parents[1] / "yunmall-hybrid/scripts/安全配置正式客服.ps1"
module = types.ModuleType("isolated_support_config_writer")
module.__file__ = str(WRITER)
exec(compile(WRITER.read_text(encoding="utf-8"), str(WRITER), "exec"), module.__dict__)
FAKE_KEY = "offline-fixture-not-a-real-key-123456"


class 客服配置写入测试(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="客服配置离线测试-")
        self.root = Path(self.temporary.name).resolve()
        self.target = self.root / ".env"
        self.original = (b'APP_DEBUG = false\r\n[DATABASE]\r\nPASSWORD="keep-this-placeholder"\r\n'
                         b'[SUPPORT]\r\n ENABLED  = 0 ; keep enabled comment\r\nAI_ENABLED=0\r\n'
                         b'API_KEY = "old-placeholder-key" # keep key comment\r\nALLOWED_UIDS = "99"\r\n'
                         b'DAILY_CALLS=0\r\ncustom_note = "keep support note"\r\n[OTHER]\r\nenabled=42\r\n')
        self.target.write_bytes(self.original)
        self.payload = {"enabled": 0, "ai_enabled": 0, "api_key": FAKE_KEY, "allowed_uid": 1, "daily_calls": 20}

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_dry_run_has_no_filesystem_writes(self) -> None:
        result = module.configure(self.target, self.payload)
        self.assertEqual(self.target.read_bytes(), self.original)
        self.assertEqual({item.name for item in self.root.iterdir()}, {".env"})
        self.assertTrue(result["changed"])
        self.assertFalse(result["applied"])

    def test_exact_five_values_change_and_comments_bytes_remain(self) -> None:
        expected = self.original.replace(b'"old-placeholder-key"', ('"' + FAKE_KEY + '"').encode())
        expected = expected.replace(b'ALLOWED_UIDS = "99"', b'ALLOWED_UIDS = "1"').replace(b'DAILY_CALLS=0', b'DAILY_CALLS=20')
        result = module.configure(self.target, self.payload, apply=True)
        self.assertEqual(self.target.read_bytes(), expected)
        self.assertEqual(result["before_sha256"], hashlib.sha256(self.original).hexdigest())
        self.assertEqual(result["after_sha256"], hashlib.sha256(expected).hexdigest())
        self.assertNotIn(FAKE_KEY, json.dumps(result))

    def test_backup_and_replacement_preserve_metadata(self) -> None:
        if os.name == "posix":
            self.target.chmod(0o640)
        before = self.target.stat()
        result = module.configure(self.target, self.payload, apply=True)
        backup = self.root / ".support-config-backups" / result["backup"]
        self.assertEqual(backup.read_bytes(), self.original)
        for path in (backup, self.target):
            info = path.stat()
            self.assertEqual((info.st_uid, info.st_gid, stat.S_IMODE(info.st_mode)),
                             (before.st_uid, before.st_gid, stat.S_IMODE(before.st_mode)))
        self.assertEqual(list(backup.parent.glob("pending-*")), [])
        if os.name == "posix":
            self.assertEqual(stat.S_IMODE(backup.parent.stat().st_mode), 0o700)

    def test_repeated_apply_is_idempotent_without_extra_backups(self) -> None:
        first = module.configure(self.target, self.payload, apply=True)
        second = module.configure(self.target, self.payload, apply=True)
        self.assertTrue(first["applied"])
        self.assertFalse(second["applied"])
        self.assertFalse(second["changed"])
        self.assertEqual(len(list((self.root / ".support-config-backups").iterdir())), 1)

    def test_explicit_enable_then_disable_is_reversible_without_other_changes(self) -> None:
        enabled = dict(self.payload, enabled=1, ai_enabled=1)
        module.configure(self.target, enabled, apply=True)
        self.assertIn(b" ENABLED  = 1 ;", self.target.read_bytes())
        self.assertIn(b"AI_ENABLED=1\r\n", self.target.read_bytes())
        result = module.configure(self.target, self.payload, apply=True)
        self.assertIn(b" ENABLED  = 0 ;", self.target.read_bytes())
        self.assertIn(b"AI_ENABLED=0\r\n", self.target.read_bytes())
        self.assertEqual(result["enabled"], 0)
        self.assertIn(b'[OTHER]\r\nenabled=42\r\n', self.target.read_bytes())

    def test_new_support_section_appends_without_changing_existing_bytes(self) -> None:
        for original in (b"[DATABASE]\npassword=keep", b"", b"\xef\xbb\xbfAPP_DEBUG=false\r\n"):
            with self.subTest(original=original):
                revised = module.rewrite_env(original, self.payload)
                self.assertTrue(revised.startswith(original))
                self.assertEqual(revised.count(b"[SUPPORT]"), 1)
                self.assertIn(b'ALLOWED_UIDS = "1"', revised)

    def test_missing_owned_keys_insert_before_next_section(self) -> None:
        original = b"[support]\ncustom_note=keep\n[DATABASE]\npassword=untouched\n"
        result = module.rewrite_env(original, self.payload)
        self.assertTrue(result.startswith(b"[support]\ncustom_note=keep\n"))
        self.assertTrue(result.endswith(b"[DATABASE]\npassword=untouched\n"))
        self.assertLess(result.index(b"DAILY_CALLS = 20"), result.index(b"[DATABASE]"))

    def test_invalid_payloads_do_not_create_lock_or_write(self) -> None:
        variants = [dict(self.payload, **{name: value}) for name, value in [
            ("allowed_uid", "1,2"), ("allowed_uid", "1"), ("allowed_uid", 0), ("allowed_uid", True),
            ("allowed_uid", 4294967296), ("daily_calls", 21), ("daily_calls", True),
            ("enabled", True), ("enabled", 2), ("ai_enabled", 1),
            ("api_key", 'bad";injected=true'), ("api_key", "short"), ("api_key", FAKE_KEY + "\n"),
        ]]
        variants += [dict(self.payload, user_daily_calls=100), {key: value for key, value in self.payload.items() if key != "api_key"}]
        for payload in variants:
            with self.subTest(payload_keys=list(payload)):
                with self.assertRaises(module.ConfigError):
                    module.configure(self.target, payload, apply=True)
                self.assertEqual(self.target.read_bytes(), self.original)
                self.assertEqual({item.name for item in self.root.iterdir()}, {".env"})

    def test_duplicate_or_ambiguous_configuration_rejected(self) -> None:
        invalid = [b"[SUPPORT]\nenabled=0\nENABLED=1\n", b"[SUPPORT]\n[Support]\n",
                   b"SUPPORT_API_KEY=old\n[SUPPORT]\n", b"support.enabled=1\n",
                   b"[SUPPORT]\napi_key[]=bad\n", b'[DATABASE]\npassword="multiline\n[SUPPORT]\n',
                   b"[SUPPORT bad]\n", b"[SUPPORT]\nmalformed\n", b"\xffinvalid"]
        for original in invalid:
            with self.subTest(original=original[:16]):
                with self.assertRaises(module.ConfigError):
                    module.rewrite_env(original, self.payload)

    def test_duplicate_json_fields_rejected(self) -> None:
        with self.assertRaises(module.ConfigError):
            json.loads('{"enabled":0,"enabled":1}', object_pairs_hook=module._unique_object)

    def test_expected_sha_mismatch_prevents_backup_or_replace(self) -> None:
        with self.assertRaises(module.ConfigError) as captured:
            module.configure(self.target, self.payload, apply=True, expected_sha256="0" * 64)
        self.assertEqual(captured.exception.stage, "compare_and_swap")
        self.assertEqual(self.target.read_bytes(), self.original)
        self.assertFalse((self.root / ".support-config-backups").exists())

    def test_concurrent_external_change_is_not_overwritten(self) -> None:
        actual_compare = module._assert_unchanged
        state = {}
        external = b"[DATABASE]\npassword=external-writer-fixture\n"
        def change_before_compare(path, content, info):
            path.write_bytes(external)
            actual_compare(path, content, info)
        with patch.object(module, "_assert_unchanged", side_effect=change_before_compare):
            with self.assertRaises(module.ConfigError) as captured:
                module.configure(self.target, self.payload, apply=True, state=state)
        self.assertEqual(captured.exception.stage, "compare_and_swap")
        self.assertFalse(state["applied"])
        self.assertEqual(self.target.read_bytes(), external)
        self.assertEqual((self.root / ".support-config-backups" / state["backup"]).read_bytes(), self.original)
        self.assertEqual(list((self.root / ".support-config-backups").glob("pending-*")), [])

    def test_lock_conflict_fails_without_writing_target(self) -> None:
        with module._locked(self.root / ".support-config.lock"):
            with self.assertRaises(module.ConfigError) as captured:
                module.configure(self.target, self.payload, apply=True)
        self.assertEqual(captured.exception.stage, "lock")
        self.assertEqual(self.target.read_bytes(), self.original)

    def test_atomic_replace_failure_preserves_original_and_backup(self) -> None:
        state = {}
        with patch.object(module.os, "replace", side_effect=OSError("fixture failure")):
            with self.assertRaises(OSError):
                module.configure(self.target, self.payload, apply=True, state=state)
        self.assertFalse(state["applied"])
        self.assertEqual(self.target.read_bytes(), self.original)
        self.assertEqual((self.root / ".support-config-backups" / state["backup"]).read_bytes(), self.original)

    def test_post_write_verification_failure_reports_applied_without_auto_rollback(self) -> None:
        state = {}
        actual_sync = module._sync_directory
        def change_after_replace(path):
            actual_sync(path)
            if path == self.root:
                self.target.write_bytes(b"new external change\n")
        with patch.object(module, "_sync_directory", side_effect=change_after_replace):
            with self.assertRaises(module.ConfigError) as captured:
                module.configure(self.target, self.payload, apply=True, state=state)
        self.assertEqual(captured.exception.stage, "verify")
        self.assertTrue(state["applied"])
        self.assertEqual(self.target.read_bytes(), b"new external change\n")
        self.assertEqual((self.root / ".support-config-backups" / state["backup"]).read_bytes(), self.original)

    def test_hardlinked_environment_file_rejected(self) -> None:
        os.link(self.target, self.root / "hardlink-fixture")
        with self.assertRaises(module.ConfigError):
            module.configure(self.target, self.payload, apply=True)
        self.assertEqual(self.target.read_bytes(), self.original)

    def test_linked_parent_or_junction_rejected(self) -> None:
        real = self.root / "real"
        real.mkdir()
        (real / ".env").write_bytes(self.original)
        linked = self.root / "linked"
        try:
            os.symlink(real, linked, target_is_directory=True)
        except OSError:
            if os.name != "nt":
                self.skipTest("系统不允许建立链接")
            result = subprocess.run(["cmd", "/c", "mklink", "/J", str(linked), str(real)], capture_output=True)
            if result.returncode:
                self.skipTest("系统不允许建立 junction")
        with self.assertRaises(module.ConfigError):
            module.configure(linked / ".env", self.payload, apply=True)
        self.assertEqual((real / ".env").read_bytes(), self.original)

    def test_cli_default_does_not_read_env_or_stdin(self) -> None:
        result = subprocess.run([sys.executable, str(WRITER)], input=FAKE_KEY.encode(), capture_output=True)
        self.assertEqual(result.returncode, 0)
        report = json.loads(result.stdout)
        self.assertFalse(report["stdin_read"])
        self.assertFalse(report["env_read"])
        self.assertFalse(report["applied"])
        self.assertEqual(report["target"], "/opt/crmeb-prod/backend_src/.env")
        self.assertNotIn(FAKE_KEY.encode(), result.stdout + result.stderr)

    def test_cli_rejects_arbitrary_target_without_echoing_arguments(self) -> None:
        result = subprocess.run([sys.executable, str(WRITER), "--target", FAKE_KEY], capture_output=True)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stdout)["stage"], "arguments")
        self.assertNotIn(FAKE_KEY.encode(), result.stdout + result.stderr)

    def test_cli_exception_output_never_contains_input_or_original_exception(self) -> None:
        # mock configure，绝不进入固定生产路径；只验证 CLI 异常输出边界。
        output = io.StringIO()
        stream = types.SimpleNamespace(buffer=io.BytesIO(json.dumps(self.payload).encode()))
        with patch.object(module.sys, "argv", ["writer", "--apply"]), patch.object(module.sys, "stdin", stream), \
                patch.object(module.os, "name", "posix"), patch.object(module, "configure", side_effect=OSError(FAKE_KEY)), \
                contextlib.redirect_stdout(output):
            self.assertEqual(module.main(), 1)
        self.assertNotIn(FAKE_KEY, output.getvalue())
        self.assertEqual(json.loads(output.getvalue())["stage"], "input")

    def test_powershell_bom_syntax_and_safe_default(self) -> None:
        raw = WRAPPER.read_bytes()
        self.assertTrue(raw.startswith(b"\xef\xbb\xbf"))
        text = raw.decode("utf-8-sig")
        self.assertIn("StandardInput.Write($payloadJson)", text)
        self.assertNotIn("EnvironmentVariables[", text)
        self.assertNotIn("WriteAllText", text)
        self.assertIn("StrictHostKeyChecking=yes", text)
        self.assertIn(".AreAccessRulesProtected", text)
        self.assertIn("ReparsePoint", text)
        self.assertLess(text.index("if (-not $Apply)"), text.index("$credentialRead = $true"))
        self.assertLess(len("python3 -c ") + len(WRITER.read_bytes()) * 4 // 3 + 500, 30000)
        powershell = shutil.which("powershell")
        if powershell:
            environment = dict(os.environ, PYTHONIOENCODING="utf-8")
            result = subprocess.run([powershell, "-NoProfile", "-NonInteractive", "-File", str(WRAPPER), "-AllowedUid", "1"],
                                    capture_output=True, env=environment)
            self.assertEqual(result.returncode, 0, (result.stdout + result.stderr).decode(errors="replace"))
            report = json.loads(result.stdout)
            self.assertFalse(report["CredentialRead"])
            self.assertEqual(report["NetworkRequests"], 0)
            self.assertFalse(report["ProductionChanged"])
            # 只加载系统模块并检查命令存在；不执行 Get-Acl/DPAPI 读取。
            probe = subprocess.run([powershell, "-NoProfile", "-NonInteractive", "-Command",
                                    "Import-Module (Join-Path $PSHOME 'Modules/Microsoft.PowerShell.Security/Microsoft.PowerShell.Security.psd1') -ErrorAction Stop; @(Get-Command Get-Acl,ConvertTo-SecureString).Count"],
                                   capture_output=True, env=environment)
            self.assertEqual(probe.returncode, 0)
            self.assertEqual(probe.stdout.strip(), b"2")


if __name__ == "__main__":
    unittest.main(verbosity=2)
