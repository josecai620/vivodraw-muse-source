# 已写入 __UNI__16C316E 仍报「appid 不存在」时请做

## 1. 让 HBuilderX 重新读 manifest

- 若当前打开了 **manifest.json** 的标签页：**关掉该标签页**，再在左侧项目树里**重新双击打开** manifest.json，确认里面显示的是 `__UNI__16C316E`。
- 或者：菜单 **文件 → 重新加载**（或关闭项目后重新「打开目录」打开 uniapp 项目），再试一次发行。

## 2. 确认 HBuilderX 登录的是「创建该应用」的账号

- 「appid 不存在」可能是：**当前登录的 DCloud 账号** 和 **在开发者中心创建 __UNI__16C316E 的账号** 不是同一个。
- 在 HBuilderX 里看右下角或 帮助/设置 里当前登录的账号，确保就是你在 https://dev.dcloud.net.cn/developer/app 创建应用时用的那个。
- 若不是同一账号：在 HBuilderX 里**退出当前账号**，再用「创建了 __UNI__16C316E 的那个账号」登录，然后再 发行 → 网站-PC Web或手机H5。

## 3. 确认应用在开发者中心里正常

- 浏览器打开 **https://dev.dcloud.net.cn/developer/app**，登录同一账号。
- 在「我的应用」里能看到 **AppID 为 __UNI__16C316E** 的应用，且没有「已删除」等异常状态。

## 4. 仍不行时：在 HBuilderX 里用「重新获取」覆盖一次

- 在 HBuilderX 打开 **manifest.json**，切到 **「基础配置」**。
- 在 **「应用标识(AppID)」** 后点 **「重新获取」**（用同一 DCloud 账号登录）。
- 若成功，会再次把当前账号下的 AppID 写回 manifest（可能仍是 __UNI__16C316E），然后再 发行 → 网站-PC Web或手机H5。

---

做完 1 和 2 后，多数「appid 不存在」会消失。若仍报错，按 3、4 检查。
