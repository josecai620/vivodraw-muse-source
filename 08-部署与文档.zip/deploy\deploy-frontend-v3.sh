#!/usr/bin/env bash
# v3 frontend deploy.
# Builds mobile-app-v3 locally and uploads only static files to the v3 root.
# It must not touch backend_src/public/index.html, backend_src/public/_expo, or current mobile-app.

set -euo pipefail

cd "$(dirname "$0")/.."

SERVER_IP="${1:-186.241.72.176}"
SSH_USER="${2:-root}"
SSH_PORT="${3:-${DEPLOY_SSH_PORT:-49375}}"

API_BASE_URL="${EXPO_PUBLIC_API_BASE_URL:-https://vivodraw.com}"
GOOGLE_CLIENT_ID="${EXPO_PUBLIC_GOOGLE_CLIENT_ID:-}"
STRIPE_CHECKOUT="${EXPO_PUBLIC_ENABLE_STRIPE_CHECKOUT:-0}"

LOCAL_APP_DIR="mobile-app-v3"
LOCAL_WEB_DIST="${LOCAL_APP_DIR}/dist"
REMOTE_V3_DIR="${REMOTE_V3_DIR:-/opt/crmeb-prod/frontend-v3-root/current}"
FORBIDDEN_PUBLIC_DIR="/opt/crmeb-prod/backend_src/public"
REMOTE_BACKUP_PARENT="$(dirname "${REMOTE_V3_DIR}")"

if [[ -n "${API_BASE_URL}" ]]; then
  case "${API_BASE_URL}" in
    https://vivodraw.com*|http://186.241.72.176*) ;;
    *)
      echo "API 基址只允许 https://vivodraw.com 或 http://186.241.72.176: ${API_BASE_URL}"
      exit 1
      ;;
  esac
fi

case "${REMOTE_V3_DIR}" in
  "${FORBIDDEN_PUBLIC_DIR}"|"${FORBIDDEN_PUBLIC_DIR}/"*|*/_expo|*/_expo/*|*/assets|*/assets/*)
    echo "禁止 v3 写入现网 public / _expo / assets: ${REMOTE_V3_DIR}"
    exit 1
    ;;
esac

if [[ ! -f "${LOCAL_APP_DIR}/package.json" ]]; then
  echo "缺少 ${LOCAL_APP_DIR}/package.json"
  exit 1
fi

if [[ -x "deploy/ops/check_public_review_assets.sh" ]]; then
  echo "=== 0. 检查 review-only public 资产 ==="
  bash deploy/ops/check_public_review_assets.sh
fi

echo "=== 1. 构建 mobile-app-v3 (Expo Web) ==="
cd "${LOCAL_APP_DIR}"
rm -rf dist
EXPO_PUBLIC_API_BASE_URL="${API_BASE_URL}" EXPO_PUBLIC_GOOGLE_CLIENT_ID="${GOOGLE_CLIENT_ID}" EXPO_PUBLIC_ENABLE_STRIPE_CHECKOUT="${STRIPE_CHECKOUT}" npx expo export --platform web
cd ..

echo "=== 2. 检查 v3 构建产物 ==="
[[ -f "${LOCAL_WEB_DIST}/index.html" ]] || { echo "缺少 ${LOCAL_WEB_DIST}/index.html"; exit 1; }
[[ -d "${LOCAL_WEB_DIST}/_expo" ]] || { echo "缺少 ${LOCAL_WEB_DIST}/_expo"; exit 1; }

echo "=== 2.05 抽取 HTML 内联 CSS 为可缓存文件 ==="
node "${LOCAL_APP_DIR}/tools/extract-inline-css.mjs" "${LOCAL_WEB_DIST}"

if [[ "${STRIPE_CHECKOUT}" == "1" || "${STRIPE_CHECKOUT}" == "true" ]]; then
  echo "=== 2.1 注入 Stripe runtime flag ==="
  python3 - "${LOCAL_WEB_DIST}" <<'PY'
from pathlib import Path
import sys

root = Path(sys.argv[1])
marker = "window.__ECOMALL_STRIPE_FLAG__=true;"
inject = (
    '<script>window.process=window.process||{};'
    'window.process.env=Object.assign({},window.process.env,{EXPO_PUBLIC_ENABLE_STRIPE_CHECKOUT:"1"});'
    f'{marker}</script>'
)
for html in root.rglob("*.html"):
    text = html.read_text()
    target = '<script src="/_expo/static/js/web/entry-'
    if marker not in text and target in text:
        html.write_text(text.replace(target, inject + target, 1))
PY
fi

echo "=== 3. 备份远端 v3 当前目录 ==="
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" "
  set -e
  test '${REMOTE_V3_DIR}' != '${FORBIDDEN_PUBLIC_DIR}'
  mkdir -p '${REMOTE_BACKUP_PARENT}'
  if [ -d '${REMOTE_V3_DIR}' ]; then
    backup_dir='${REMOTE_BACKUP_PARENT}/backup-before-v3-deploy-'\"\$(date +%Y%m%d%H%M%S)\"
    cp -a '${REMOTE_V3_DIR}' \"\${backup_dir}\"
    echo \"backup: \${backup_dir}\"
  fi
  mkdir -p '${REMOTE_V3_DIR}'
"

echo "=== 4. 上传到 v3 主站目录 ==="
rsync -avz --delete -e "ssh -p ${SSH_PORT}" \
  "${LOCAL_WEB_DIST}/" \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_V3_DIR}/"

echo "=== 5. 远端目录验活 ==="
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" "
  set -e
  test -f '${REMOTE_V3_DIR}/index.html'
  test -d '${REMOTE_V3_DIR}/_expo'
  echo 'v3 deployed at ${REMOTE_V3_DIR}'
"

if [[ -n "${VERIFY_URL:-}" ]]; then
  echo "=== 6. URL 验活: ${VERIFY_URL} ==="
  tmp_html="$(mktemp "${TMPDIR:-/tmp}/eccomall_v3_verify.XXXXXX")"
  curl -fsS "${VERIFY_URL%/}/" -o "${tmp_html}"
  entry="$(python3 -c "import re,sys; h=open(sys.argv[1]).read(); m=re.search(r'(_expo/static/js/web/entry-[^\"\\']+\\.js)', h); print(m.group(1) if m else '')" "${tmp_html}")"
  rm -f "${tmp_html}"
  [[ -n "${entry}" ]] || { echo "未找到 v3 entry js"; exit 1; }
  curl -fsS -I "${VERIFY_URL%/}/${entry}" >/dev/null
  curl -fsS -H "X-Client: mobile-app" "https://vivodraw.com/api/category" >/dev/null
fi

echo "=== v3 主站产物已上传；未修改 backend_src/public ==="
