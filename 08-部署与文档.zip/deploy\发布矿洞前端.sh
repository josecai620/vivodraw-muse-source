#!/usr/bin/env bash
# 矿洞专用发布：默认只生成本地准备包；核对包内容后显式 --publish。
# 农场仅显式 --prepare-with-farm 可追加完整5文件或含恢复模块的6文件；不改其他壳层、服务配置、SQL或依赖。
# 用法：bash deploy/发布矿洞前端.sh [--prepare [准备包.tar.gz [已验证线上快照目录 [已发布准备包.tar.gz]]]]
#       bash deploy/发布矿洞前端.sh --prepare-with-farm 准备包.tar.gz 线上快照目录 已发布准备包.tar.gz 农场页面修改前基线.tsx
#       矿石动画发布需在准备命令末尾追加 --ore-manifest 已验收十张资源清单.json
#       bash deploy/发布矿洞前端.sh --publish 准备包.tar.gz
#       bash deploy/发布矿洞前端.sh --status 已输出的发布任务编号
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MODE="${1:---prepare}"
PACKAGE="${2:-/tmp/矿洞前端准备包-$(date +%Y%m%d-%H%M%S)-$$.tar.gz}"
ONLINE_SNAPSHOT="${3:-}"
PREVIOUS_PACKAGE="${4:-}"
FARM_PAGE_BASE="${5:-}"
if [[ "$MODE" == "--publish" || "$MODE" == "--status" ]]; then
  if [[ "$MODE" == "--publish" ]]; then
    [[ $# == 2 && -f "$PACKAGE" ]] || { echo "请指定已检查的准备包。" >&2; exit 1; }
    python3 - "$PACKAGE" <<'PY_SIZE'
import pathlib, sys
assert pathlib.Path(sys.argv[1]).stat().st_size <= 10 * 1024**2, "准备包超过10MiB，拒绝上传"
PY_SIZE
    TASK_ID="mine-release-$(date +%Y%m%d%H%M%S)-$$"
    REMOTE_PACKAGE="/tmp/$TASK_ID.tar.gz"
    echo "发布任务：${TASK_ID}；掉线后仅查询：bash deploy/发布矿洞前端.sh --status ${TASK_ID}"
    scp -P 49375 -o BatchMode=yes "$PACKAGE" "root@186.241.72.176:$REMOTE_PACKAGE"
    # 只创建本次 transient unit；发布进程不再依赖 SSH 会话或其 stdout。
    if ! ssh -p 49375 -o BatchMode=yes -o ConnectTimeout=15 root@186.241.72.176 python3 - "$REMOTE_PACKAGE" "$TASK_ID" <<'PY_LAUNCH'
import json, pathlib, re, subprocess, sys, tarfile, time
package, task_id = sys.argv[1:]
assert re.fullmatch(r"mine-release-\d{14}-\d+", task_id)
assert pathlib.Path(package).stat().st_size <= 10 * 1024**2
with tarfile.open(package, "r:gz") as archive:
    assert len(archive.getmembers()) == 2 and set(archive.getnames()) == {"清单.json", "执行.py"}
    assert all(m.isfile() and m.size < 16 * 1024**2 for m in archive)
    payload = json.load(archive.extractfile("清单.json"))
    assert payload.get("version") == 3 and len(payload.get("assets", [])) in (3, 13), "请重新生成带可靠回退的新版包"
    compile(archive.extractfile("执行.py").read(), "矿洞发布执行器", "exec")
folder = pathlib.Path("/opt/crmeb-prod/deploy_backups") / ("矿洞发布任务-" + task_id)
folder.mkdir(exist_ok=False)
status = folder / "运行状态.json"
status.write_text(json.dumps({"state": "starting", "task_id": task_id, "started_at": time.time()}))
loader = r'''import json, os, pathlib, sys, tarfile, time, traceback
package, folder = sys.argv[1], pathlib.Path(sys.argv[2])
state = {"state": "running", "pid": os.getpid(), "started_at": time.time(), "task_id": folder.name.removeprefix("矿洞发布任务-")}
def save():
    staging = folder / "运行状态.tmp"
    staging.write_text(json.dumps(state, ensure_ascii=False))
    staging.replace(folder / "运行状态.json")
save()
try:
    with tarfile.open(package, "r:gz") as archive:
        payload = json.load(archive.extractfile("清单.json"))
        runner = archive.extractfile("执行.py").read()
    exec(compile(runner, "矿洞发布执行器", "exec"), {"payload": payload})
except BaseException:
    failure = traceback.format_exc()
    with (folder / "异常.log").open("a") as log:
        log.write(failure)
    state.update(state="failed", exit_code=1, error=failure[-6000:])
else:
    state.update(state="succeeded", exit_code=0)
state["finished_at"] = time.time()
save()
sys.exit(state["exit_code"])
'''
result = subprocess.run(["systemd-run", "--quiet", "--unit=" + task_id, "-p", "Type=exec",
    "-p", "WorkingDirectory=/opt/crmeb-prod", "-p", "StandardOutput=append:" + str(folder / "发布日志.log"),
    "-p", "StandardError=append:" + str(folder / "发布日志.log"),
    "/usr/bin/python3", "-u", "-c", loader, package, str(folder)], capture_output=True, text=True)
if result.returncode:
    status.write_text(json.dumps({"state": "failed", "exit_code": result.returncode, "error": result.stderr}))
    raise RuntimeError(result.stderr)
print("独立发布任务已启动；状态与日志：" + str(folder))
PY_LAUNCH
    then
      echo "启动连接未确认；只查询同一任务状态，绝不重复启动。" >&2
    fi
  else
    TASK_ID="$PACKAGE"
    [[ $# == 2 && "$TASK_ID" =~ ^mine-release-[0-9]{14}-[0-9]+$ ]] || { echo "请指定已输出的发布任务编号。" >&2; exit 1; }
  fi
  for ((attempt=0; attempt<90; attempt++)); do
    set +e
    ssh -p 49375 -o BatchMode=yes -o ConnectTimeout=15 root@186.241.72.176 python3 - "$TASK_ID" <<'PY_STATUS'
import json, pathlib, subprocess, sys, time
folder = pathlib.Path("/opt/crmeb-prod/deploy_backups") / ("矿洞发布任务-" + sys.argv[1])
for attempt in range(15):
    status = folder / "运行状态.json"
    state = json.loads(status.read_text()) if status.is_file() else {"state": "unknown"}
    result = subprocess.run(["systemctl", "show", sys.argv[1] + ".service", "--property=ActiveState,SubState,ExecMainStatus,LoadState"], capture_output=True, text=True)
    unit = dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)
    if state["state"] not in {"succeeded", "failed"} and unit.get("ActiveState") in {"failed", "inactive"}:
        state = json.loads(status.read_text()) if status.is_file() else state
        if state["state"] not in {"succeeded", "failed"}:
            state.update(state="interrupted", unit=unit)
    if state["state"] in {"succeeded", "failed", "interrupted", "unknown"}:
        print(json.dumps(state, ensure_ascii=False))
        if (folder / "发布日志.log").is_file():
            print((folder / "发布日志.log").read_text(errors="replace")[-8000:])
        sys.exit(0 if state["state"] == "succeeded" else 1)
    time.sleep(2)
print(json.dumps(state, ensure_ascii=False))
sys.exit(3)
PY_STATUS
    status_code=$?
    set -e
    [[ "$status_code" == 0 ]] && exit 0
    [[ "$status_code" == 1 ]] && exit 1
    if [[ "$status_code" != 3 ]]; then
      echo "状态连接暂不可用，发布任务仍独立运行；稍后读取同一任务。" >&2
      sleep 5
    fi
  done
  echo "等待状态超时，未终止独立发布；请用 --status $TASK_ID 查询。" >&2
  exit 2
fi
[[ "$MODE" == "--prepare" || "$MODE" == "--dry-run" || "$MODE" == "--prepare-with-farm" ]] || {
  echo "只支持 --prepare、--prepare-with-farm、--dry-run、--publish 或 --status；默认不会连接服务器。" >&2; exit 1;
}
ORE_MANIFEST=""
if [[ "$MODE" == "--prepare-with-farm" ]]; then
  [[ ( $# == 5 || ( $# == 7 && "${6:-}" == "--ore-manifest" && -f "${7:-}" ) ) && -d "$ONLINE_SNAPSHOT" && -f "$PREVIOUS_PACKAGE" && -f "$FARM_PAGE_BASE" ]] || { echo "农场模式必须指定真实快照、上一成功包和修改前页面基线。" >&2; exit 1; }
  ORE_MANIFEST="${7:-}"
else
  [[ $# -le 4 || ( $# == 6 && "${5:-}" == "--ore-manifest" && -f "${6:-}" ) ]] || { echo "准备命令仅可追加 --ore-manifest 已验收十张资源清单.json。" >&2; exit 1; }
  ORE_MANIFEST="${6:-}"
fi
STAGING="$(mktemp -d "${TMPDIR:-/tmp}/mine-package.XXXXXX")"
trap 'rm -rf "$STAGING"' EXIT
python3 - "$PROJECT_ROOT" "$STAGING" "$ONLINE_SNAPSHOT" "$PREVIOUS_PACKAGE" "$MODE" "$FARM_PAGE_BASE" "$ORE_MANIFEST" <<'PY'
import base64, hashlib, json, pathlib, re, subprocess, sys, tarfile, tempfile
root, out = map(pathlib.Path, sys.argv[1:3])
baseline = "efc3924011858cb47a6c331dbe0195ce7421b5f8"
paths = [
    "apps/web/app/mine/mine-page-client.tsx", "apps/web/app/mine/mine-page-motion-bridge.tsx",
    "apps/web/lib/mine/assets.ts", "apps/web/lib/mine/parallax.ts",
    "apps/web/lib/mine/矿洞接口.ts", "apps/web/lib/mine/矿洞状态.ts",
    "apps/web/app/globals.css", "apps/web/app/box/page.tsx", "apps/web/app/points/page.tsx",
    "apps/web/lib/mock-data.ts", "apps/web/app/providers.tsx",
    "packages/api-sdk/src/shared/fetch-transport.ts", "packages/api-sdk/src/shared/http.ts",
    "packages/config/src/env/public.ts",
    "apps/web/app/mine/矿工动画.tsx", "apps/web/app/mine/矿工动画.module.css",
    "apps/web/lib/mine/矿洞试玩.ts", "apps/web/lib/mine/矿洞动画节奏.ts",
    "apps/web/app/mine/mine-action-panel.tsx", "apps/web/app/mine/mine-page-layout-editor.tsx",
    "apps/web/lib/mine/layout.ts", "apps/web/lib/mine/mock-data.ts",
    "apps/web/lib/mine/rules.ts", "apps/web/lib/mine/types.ts",
]
changes = []
for index, rel in enumerate(paths):
    path = root / "game" / rel
    assert not path.is_symlink(), f"禁止打包符号链接：{rel}"
    base = subprocess.run(["git", "show", f"{baseline}:game/{rel}"], cwd=root, capture_output=True)
    before = base.stdout.decode() if base.returncode == 0 else None
    after = path.read_text() if path.is_file() else None
    assert (after is not None) == (index < 18), f"文件存在状态不符合矿洞清单：{rel}"
    assert before != after, f"缺少待发布差异：{rel}"
    changes.append({"path": rel, "base": before, "target": after})
# 可选矿洞新增源码只能逐项列举；没有按钮样式时仍生成原24路径矿洞清单。
button_css_path = "apps/web/app/mine/矿洞按钮动效.module.css"
mine_extra_paths = []
button_source = root / "game" / button_css_path
assert not button_source.is_symlink(), "禁止按钮CSS符号链接"
assert ('"./矿洞按钮动效.module.css"' in changes[0]["target"]) == button_source.is_file(), "按钮CSS与页面引用必须同时存在"
if button_source.exists():
    assert button_source.is_file() and button_source.resolve().is_relative_to((root / "game").resolve()), "按钮CSS路径异常"
    assert '"./矿洞按钮动效.module.css"' in changes[0]["target"], "矿洞页面未接入按钮CSS"
    mine_extra_paths.append(button_css_path)
    changes.append({"path": button_css_path, "base": None, "target": button_source.read_text()})
ore_source_paths = ["apps/web/app/mine/矿石动画.tsx", "apps/web/app/mine/矿石动画.module.css"]
ore_enabled = any((root / "game" / rel).exists() for rel in ore_source_paths)
assert ('"./矿石动画"' in changes[0]["target"]) == ore_enabled, "矿石组件与页面引用必须同时存在"
if ore_enabled:
    for rel in ore_source_paths:
        source = root / "game" / rel
        assert source.is_file() and not source.is_symlink() and source.resolve().is_relative_to((root / "game").resolve()), "矿石源码必须完整2文件：" + rel
        mine_extra_paths.append(rel)
        changes.append({"path": rel, "base": None, "target": source.read_text()})
    component = next(c["target"] for c in changes if c["path"] == ore_source_paths[0])
    settings = re.search(r"const animationSettings\s*=\s*\{([^}]+)\}", component)
    assert settings and dict(re.findall(r"(\w+)\s*:\s*(\d+)", settings[1])) == {"frameWidth": "256", "frameHeight": "256", "columns": "8", "rows": "9", "frameCount": "72", "fps": "12"}, "矿石播放器契约与已批准图集不同"
css = next(c for c in changes if c["path"].endswith("globals.css"))
assert css["target"].startswith(css["base"]), "本地 CSS 包含矿洞新增区以外的修改，请先拆分"
assert ".mine-page-slim" in css["target"][len(css["base"]):], "缺少矿洞精简样式"
def check_mine_css(text):
    stack = []
    for token in re.finditer(r"([^{}]*)\{|}", re.sub(r"/\*.*?\*/", "", text, flags=re.S)):
        if token.group() == "}":
            assert stack, "矿洞 CSS 花括号不完整"
            stack.pop()
            continue
        rule = token.group(1).strip()
        if stack and stack[-1] == "frames":
            assert re.fullmatch(r"[\d.%\s,]+|from|to", rule), "矿洞关键帧范围异常"
            stack.append("step")
        elif re.fullmatch(r"@keyframes mine[\w-]+", rule):
            stack.append("frames")
        else:
            assert rule.startswith("@media ") or all(s.strip().startswith(".mine-") for s in rule.split(",")), "追加区包含其他页面样式"
            stack.append("rule")
    assert not stack, "矿洞 CSS 花括号不完整"
check_mine_css(css["target"][len(css["base"]):])
evidence = []
if sys.argv[3]:
    snapshot = pathlib.Path(sys.argv[3])
    evidence = json.loads((snapshot / "快照与合并校验.json").read_text())
    record = next(item for item in evidence if item["path"] == css["path"])
    source = snapshot / css["path"]
    assert not source.is_symlink() and source.resolve().is_relative_to(snapshot.resolve()), "CSS 快照路径越界"
    content = source.read_bytes()
    assert record["exists"] and hashlib.sha256(content).hexdigest() == record["sha256"], "CSS 快照哈希不符"
    online_css = content.decode()
    assert online_css.startswith(css["base"]), "线上 CSS 已修改公共前缀，不能使用此快照"
    assert ".mine-page-slim" in online_css[len(css["base"]):], "快照不是已核实的矿洞追加区"
    check_mine_css(online_css[len(css["base"]):])
    # 两端公共前缀逐字一致，三方合并的变更边界仅在本次矿洞追加区。
    css["base"] = online_css
    print("采用已验证线上 CSS 快照：" + record["sha256"])
# 已上线后的局部追加，显式使用上一已发布包的目标作为这六个文件的基线。
# 同时核对真实线上快照，不能把任意本地文件冒作线上基线。
previous_digest = None
if sys.argv[4]:
    assert sys.argv[3], "提供旧发布包时必须同时提供已验证线上快照"
    previous_path = pathlib.Path(sys.argv[4])
    assert previous_path.stat().st_size <= 10 * 1024**2, "旧发布包过大"
    previous_digest = hashlib.sha256(previous_path.read_bytes()).hexdigest()
    with tarfile.open(previous_path, "r:gz") as archive:
        assert len(archive.getmembers()) == 2 and set(archive.getnames()) == {"清单.json", "执行.py"}
        assert all(m.isfile() and m.size < 16 * 1024**2 for m in archive)
        previous = json.load(archive.extractfile("清单.json"))
    expected = previous.pop("sha256")
    assert previous.get("version") == 3 and hashlib.sha256(json.dumps(previous, ensure_ascii=False, sort_keys=True).encode()).hexdigest() == expected, "旧发布包清单校验失败"
    for rel in ("apps/web/app/mine/mine-page-client.tsx", "apps/web/lib/mine/矿洞状态.ts",
                "apps/web/app/mine/矿工动画.tsx", "apps/web/lib/mine/矿洞试玩.ts",
                "apps/web/lib/mine/矿洞动画节奏.ts", "apps/web/lib/mine/矿洞接口.ts"):
        old = next(c for c in previous["changes"] if c["path"] == rel)["target"]
        record = next(item for item in evidence if item["path"] == rel)
        online = snapshot / rel
        assert record["exists"] and not online.is_symlink() and online.resolve().is_relative_to(snapshot.resolve()), "后续补丁快照路径异常"
        content = online.read_bytes()
        assert hashlib.sha256(content).hexdigest() == record["sha256"] and content.decode() == old, "线上文件不等于已发布包目标，停止：" + rel
        next(c for c in changes if c["path"] == rel)["base"] = old
    for rel in mine_extra_paths:
        record = next((item for item in evidence if item["path"] == rel), None)
        assert record is not None, "缺少新增矿洞源码的真实线上快照：" + rel
        online = snapshot / rel
        assert not online.is_symlink() and online.resolve().is_relative_to(snapshot.resolve()), "新增矿洞文件快照路径异常"
        assert online.is_file() == record["exists"], "新增矿洞文件快照状态不符"
        old = next((c for c in previous["changes"] if c["path"] == rel), None)
        if old is None:
            assert not record["exists"], "新增矿洞源码线上已有未核实内容，停止"
        else:
            assert isinstance(old["target"], str) and record["exists"], "上一矿洞新增源码基线不可用"
            content = online.read_bytes()
            assert hashlib.sha256(content).hexdigest() == record["sha256"] and content.decode() == old["target"], "新增矿洞源码偏离上一成功包，停止"
            next(c for c in changes if c["path"] == rel)["base"] = old["target"]
    print("局部追加基线取自已发布包：" + previous_digest)
assert not mine_extra_paths or previous_digest, "新增矿洞源码必须先核实上一成功包和真实线上快照"
for change in changes[10:14]:
    old_urls = set(re.findall(r'http://(?:\d{1,3}\.){3}\d{1,3}', change["base"]))
    assert len(old_urls) == 1, "共享域名补丁的旧默认地址不唯一"
    assert change["target"] == change["base"].replace(old_urls.pop(), "https://vivodraw.com"), "共享域名补丁包含额外修改"
# 农场只接收独立确认的5或6文件补丁。页面基线可包含他人既有视觉成果，先与真实线上快照合并。
farm_paths = ["apps/web/app/farm/page.tsx", "apps/web/app/farm/farm-ops-panels.tsx",
              "apps/web/lib/farm/state.ts", "apps/web/lib/farm/农场会话.ts", "packages/api-sdk/src/types.ts"]
farm_recovery_path = "apps/web/lib/farm/农场待结算.ts"
if (root / "game" / farm_recovery_path).is_file():
    farm_paths.append(farm_recovery_path)
farm_patch = None
if sys.argv[5] == "--prepare-with-farm":
    assert evidence and previous_digest, "农场发布缺少真实快照或上一成功包"
    page_base_path = pathlib.Path(sys.argv[6])
    assert page_base_path.is_file() and not page_base_path.is_symlink(), "农场页面修改前基线不可用"
    farm_patch = {"mode": "coin-wallet-v2" if farm_recovery_path in farm_paths else "coin-wallet-v1", "page_patch_base_sha256": hashlib.sha256(page_base_path.read_bytes()).hexdigest(), "targets": {}}
    for rel in farm_paths:
        source = root / "game" / rel
        assert source.is_file() and not source.is_symlink() and source.resolve().is_relative_to((root / "game").resolve()), "农场目标路径异常：" + rel
        target = source.read_text()
        if rel == farm_paths[0]:
            patch_base = page_base_path.read_text()
            # 这轮不包含农场图像/预加载更改；与他人视觉任务分离。
            visual = lambda text: re.findall(r'/farm/[^"\s\'<>]+?\.(?:png|webp|jpg|svg)', text)
            assert visual(patch_base) == visual(target), "本次农场补丁修改了素材引用"
            def preload(text):
                marker = text.index("    void preloadImageAssets(farmCriticalAssets")
                start = text.rindex("  useEffect(() => {", 0, marker)
                end = text.index("  }, []);", marker) + len("  }, []);")
                return text[start:end]
            assert preload(patch_base) == preload(target), "本次农场补丁混入预加载改动"
        else:
            old = subprocess.run(["git", "show", "HEAD:game/" + rel], cwd=root, capture_output=True)
            patch_base = old.stdout.decode() if old.returncode == 0 else None
        record = next(item for item in evidence if item["path"] == rel)
        online = snapshot / rel
        assert not online.is_symlink() and online.resolve().is_relative_to(snapshot.resolve()), "农场快照路径越界"
        assert online.is_file() == record["exists"], "农场快照存在状态不符"
        live = online.read_text() if record["exists"] else None
        if live is not None:
            assert hashlib.sha256(online.read_bytes()).hexdigest() == record["sha256"], "农场快照SHA不符"
        if live != target and live != patch_base:
            assert live is not None and patch_base is not None, "农场新增文件冲突：" + rel
            with tempfile.TemporaryDirectory(prefix="农场补丁合并-") as folder:
                files = [pathlib.Path(folder) / name for name in ("线上", "基线", "目标")]
                for file, value in zip(files, (live, patch_base, target)): file.write_text(value)
                merge = subprocess.run(["git", "merge-file", "-p", *map(str, files)], capture_output=True)
                assert merge.returncode == 0, "农场补丁与线上冲突，停止：" + rel
                target = merge.stdout.decode()
        changes.append({"path": rel, "base": live, "target": target})
        farm_patch["targets"][rel] = hashlib.sha256(target.encode()).hexdigest()
    print("追加完整5文件或含恢复模块的6文件农场金币补丁；目标已从真实线上快照三方合并。")
def check_ore_webp(data, atlas):
    # 无Pillow等生产依赖；检查RIFF块及图像头，像素内容由已验收SHA绑定。
    assert len(data) >= 30 and data[:4] == b"RIFF" and data[8:12] == b"WEBP" and int.from_bytes(data[4:8], "little") + 8 == len(data), "矿石不是完整WebP"
    chunks, cursor = {}, 12
    while cursor < len(data):
        assert cursor + 8 <= len(data), "WebP块头不完整"
        tag = data[cursor:cursor + 4]
        size = int.from_bytes(data[cursor + 4:cursor + 8], "little")
        end = cursor + 8 + size
        assert end <= len(data) and tag not in chunks, "WebP块越界或重复"
        chunks[tag] = data[cursor + 8:end]
        cursor = end + (size & 1)
    assert cursor == len(data) and b"ANIM" not in chunks and b"ANMF" not in chunks, "必须使用静态图集，不能是动画WebP"
    ext = chunks.get(b"VP8X", b"")
    assert len(ext) == 10 and ext[0] & 16 and not ext[0] & 2, "矿石WebP必须声明透明通道且无动画标志"
    dimensions = (1 + int.from_bytes(ext[4:7], "little"), 1 + int.from_bytes(ext[7:10], "little"))
    assert dimensions == ((2048, 2304) if atlas else (256, 256)), "矿石图集或静态图尺寸错误"
    assert (b"VP8 " in chunks) != (b"VP8L" in chunks), "WebP必须恰有一个图像编码块"
    if b"VP8 " in chunks:
        body = chunks[b"VP8 "]
        assert len(body) >= 10 and body[3:6] == b"\x9d\x01\x2a" and chunks.get(b"ALPH"), "WebP图像或alpha块损坏"
        encoded_size = (int.from_bytes(body[6:8], "little") & 0x3fff, int.from_bytes(body[8:10], "little") & 0x3fff)
    else:
        body = chunks[b"VP8L"]
        assert len(body) >= 5 and body[0] == 47, "无损WebP图像头损坏"
        bits = int.from_bytes(body[1:5], "little")
        assert bits >> 29 == 0 and bits & (1 << 28), "无损WebP版本或透明通道错误"
        encoded_size = ((bits & 0x3fff) + 1, ((bits >> 14) & 0x3fff) + 1)
    assert encoded_size == dimensions, "WebP扩展头与图像尺寸不一致"

ore_asset_paths = ["apps/web/public/mine/矿石动画/" + ore + kind + ".webp"
                   for ore in ("铁矿", "铜矿", "银矿", "金矿", "钻石") for kind in ("图集", "静态")]
ore_manifest_sha256, approved_ores = None, {}
ore_manifest_arg = sys.argv[7] if len(sys.argv) > 7 else ""
if ore_enabled:
    assert ore_manifest_arg and evidence and previous_digest, "矿石资源必须有已验收10张SHA清单、真实快照及上一成功包"
    approval_path = pathlib.Path(ore_manifest_arg)
    assert approval_path.is_file() and not approval_path.is_symlink() and approval_path.stat().st_size <= 64 * 1024, "矿石已验收清单路径或大小异常"
    approval_bytes = approval_path.read_bytes()
    approval = json.loads(approval_bytes)
    approved_items = approval.get("assets", [])
    assert len(approved_items) == 10 and {a["path"] for a in approved_items} == set(ore_asset_paths), "矿石已验收清单必须包含五种各图集和静态，共10张"
    approved_ores = {a["path"]: a for a in approved_items}
    ore_manifest_sha256 = hashlib.sha256(approval_bytes).hexdigest()
else:
    assert not ore_manifest_arg, "未接入矿石组件，不能附带矿石资源"
asset_paths = ["apps/web/public/mine/矿工动画/" + name for name in ("矿工挥镐图集.webp", "矿工待机.webp", "矿工动画参数.json")]
if ore_enabled: asset_paths.extend(ore_asset_paths)
assets = []
for rel in asset_paths:
    name = pathlib.PurePosixPath(rel).name
    source = root / "game" / rel
    assert source.is_file() and not source.is_symlink() and source.resolve().is_relative_to((root / "game").resolve()), "矿工资产缺失或路径异常：" + rel
    data = source.read_bytes()
    limit = 64 * 1024 if name.endswith(".json") else 2 * 1024**2
    assert 0 < len(data) <= limit, "矿工资产超过大小限制：" + rel
    if name.endswith(".webp"):
        assert data[:4] == b"RIFF" and data[8:12] == b"WEBP", "矿工图集不是WebP：" + rel
    else:
        assert isinstance(json.loads(data), dict), "矿工动画参数格式错误"
    if rel in approved_ores:
        approved = approved_ores[rel]
        assert len(data) == approved.get("size") and hashlib.sha256(data).hexdigest() == approved.get("sha256"), "矿石资源与已验收清单SHA或大小不符：" + rel
        assert "图集" in name or len(data) <= 128 * 1024, "矿石静态帧超过128KiB"
        check_ore_webp(data, "图集" in name)
    base_digest = None
    record = next((item for item in evidence if item["path"] == rel), None)
    if rel in approved_ores:
        assert record is not None, "缺少矿石资源的真实线上存在性快照：" + rel
        old_asset = next((a for a in previous["assets"] if a["path"] == rel), None)
        if old_asset is None:
            assert not record["exists"], "矿石同名资源线上已存在但不属于上一成功包：" + rel
        else:
            assert record["exists"] and record["sha256"] == old_asset["sha256"], "矿石资源偏离上一成功包：" + rel
    if record and record["exists"]:
        old = snapshot / rel
        assert not old.is_symlink() and old.resolve().is_relative_to(snapshot.resolve()), "资产快照路径异常"
        base_digest = hashlib.sha256(old.read_bytes()).hexdigest()
        assert base_digest == record["sha256"], "资产快照哈希不符"
    assets.append({"path": rel, "base_sha256": base_digest, "sha256": hashlib.sha256(data).hexdigest(),
                   "size": len(data), "data_base64": base64.b64encode(data).decode("ascii")})
assert sum(len(c["target"].encode()) for c in changes if c["target"] is not None) + sum(a["size"] for a in assets) <= 10 * 1024**2, "全部发布目标超过10MiB"
document = {"version": 3, "baseline": baseline, "previous_package_sha256": previous_digest, "changes": changes, "assets": assets, "farm_patch": farm_patch, "mine_extra_paths": mine_extra_paths, "ore_manifest_sha256": ore_manifest_sha256}
encoded = json.dumps(document, ensure_ascii=False, sort_keys=True).encode()
document["sha256"] = hashlib.sha256(encoded).hexdigest()
(out / "清单.json").write_text(json.dumps(document, ensure_ascii=False))
print("仅准备本地发布包：" + str(len(changes)) + " 个源码路径、" + str(len(assets)) + " 个严格白名单资产；未连接服务器。")
for change in changes:
    print(("删除 " if change["target"] is None else "合并 ") + "game/" + change["path"])
for asset in assets:
    print("资产 game/" + asset["path"] + "（" + str(asset["size"]) + " 字节）")
PY
cat > "$STAGING/执行.py" <<'PY'
import base64, builtins, fcntl, hashlib, html, json, os, pathlib, re, shutil, signal, socket, subprocess, sys, time, traceback, urllib.parse, urllib.request

ROOT = pathlib.Path("/opt/crmeb-prod")
LIVE = ROOT / "game"
SERVICE = "petworld-game.service"
ALLOWED = {
    "apps/web/app/mine/mine-page-client.tsx", "apps/web/app/mine/mine-page-motion-bridge.tsx",
    "apps/web/lib/mine/assets.ts", "apps/web/lib/mine/parallax.ts",
    "apps/web/lib/mine/矿洞接口.ts", "apps/web/lib/mine/矿洞状态.ts",
    "apps/web/app/globals.css", "apps/web/app/box/page.tsx", "apps/web/app/points/page.tsx",
    "apps/web/lib/mock-data.ts", "apps/web/app/providers.tsx",
    "packages/api-sdk/src/shared/fetch-transport.ts", "packages/api-sdk/src/shared/http.ts",
    "packages/config/src/env/public.ts",
    "apps/web/app/mine/矿工动画.tsx", "apps/web/app/mine/矿工动画.module.css",
    "apps/web/lib/mine/矿洞试玩.ts", "apps/web/lib/mine/矿洞动画节奏.ts",
    "apps/web/app/mine/mine-action-panel.tsx", "apps/web/app/mine/mine-page-layout-editor.tsx",
    "apps/web/lib/mine/layout.ts", "apps/web/lib/mine/mock-data.ts",
    "apps/web/lib/mine/rules.ts", "apps/web/lib/mine/types.ts",
}
ORE_SOURCES = {"apps/web/app/mine/矿石动画.tsx", "apps/web/app/mine/矿石动画.module.css"}
MINE_EXTRA_ALLOWED = {"apps/web/app/mine/矿洞按钮动效.module.css"} | ORE_SOURCES
ORE_ASSETS = {"apps/web/public/mine/矿石动画/" + ore + kind + ".webp"
              for ore in ("铁矿", "铜矿", "银矿", "金矿", "钻石") for kind in ("图集", "静态")}
FARM_ALLOWED = {"apps/web/app/farm/page.tsx", "apps/web/app/farm/farm-ops-panels.tsx",
                "apps/web/lib/farm/state.ts", "apps/web/lib/farm/农场会话.ts", "packages/api-sdk/src/types.ts"}
ASSET_ALLOWED = {"apps/web/public/mine/矿工动画/" + name for name in
                 ("矿工挥镐图集.webp", "矿工待机.webp", "矿工动画参数.json")}

def check_ore_webp(data, atlas):
    # 无Pillow等生产依赖；检查RIFF块及图像头，像素内容由已验收SHA绑定。
    assert len(data) >= 30 and data[:4] == b"RIFF" and data[8:12] == b"WEBP" and int.from_bytes(data[4:8], "little") + 8 == len(data), "矿石不是完整WebP"
    chunks, cursor = {}, 12
    while cursor < len(data):
        assert cursor + 8 <= len(data), "WebP块头不完整"
        tag = data[cursor:cursor + 4]
        size = int.from_bytes(data[cursor + 4:cursor + 8], "little")
        end = cursor + 8 + size
        assert end <= len(data) and tag not in chunks, "WebP块越界或重复"
        chunks[tag] = data[cursor + 8:end]
        cursor = end + (size & 1)
    assert cursor == len(data) and b"ANIM" not in chunks and b"ANMF" not in chunks, "必须使用静态图集，不能是动画WebP"
    ext = chunks.get(b"VP8X", b"")
    assert len(ext) == 10 and ext[0] & 16 and not ext[0] & 2, "矿石WebP必须声明透明通道且无动画标志"
    dimensions = (1 + int.from_bytes(ext[4:7], "little"), 1 + int.from_bytes(ext[7:10], "little"))
    assert dimensions == ((2048, 2304) if atlas else (256, 256)), "矿石图集或静态图尺寸错误"
    assert (b"VP8 " in chunks) != (b"VP8L" in chunks), "WebP必须恰有一个图像编码块"
    if b"VP8 " in chunks:
        body = chunks[b"VP8 "]
        assert len(body) >= 10 and body[3:6] == b"\x9d\x01\x2a" and chunks.get(b"ALPH"), "WebP图像或alpha块损坏"
        encoded_size = (int.from_bytes(body[6:8], "little") & 0x3fff, int.from_bytes(body[8:10], "little") & 0x3fff)
    else:
        body = chunks[b"VP8L"]
        assert len(body) >= 5 and body[0] == 47, "无损WebP图像头损坏"
        bits = int.from_bytes(body[1:5], "little")
        assert bits >> 29 == 0 and bits & (1 << 28), "无损WebP版本或透明通道错误"
        encoded_size = ((bits & 0x3fff) + 1, ((bits >> 14) & 0x3fff) + 1)
    assert encoded_size == dimensions, "WebP扩展头与图像尺寸不一致"

def print(*args, **kwargs):
    # 日志管道或终端断开不能改变发布/回退控制流；任务另有持久文件日志。
    try:
        builtins.print(*args, **kwargs)
    except (OSError, ValueError):
        # 避免解释器退出时再次刷新已断开的stdout并把成功状态改成120。
        try:
            fd = os.open(os.devnull, os.O_WRONLY)
            try:
                os.dup2(fd, sys.stdout.fileno())
            finally:
                os.close(fd)
        except (OSError, ValueError, AttributeError):
            pass

def run(args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None

def process_identity(pid):
    proc = pathlib.Path("/proc") / str(pid)
    fields = (proc / "stat").read_text().rsplit(")", 1)[1].split()
    return {"pid": pid, "ppid": int(fields[1]), "starttime": fields[19],
            "cwd": str((proc / "cwd").resolve()),
            "cmdline": (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode().strip(),
            "cgroup": (proc / "cgroup").read_text().strip()}

def port_listeners():
    return subprocess.check_output(["ss", "-H", "-lntp", "sport = :3010"], text=True).strip()

def inspect_runtime():
    properties = ["WorkingDirectory", "ExecStart", "ExecStartPre", "ExecStartPost", "ExecStop", "ExecStopPost", "ControlGroup", "MainPID", "ActiveState", "SubState"]
    raw = subprocess.check_output(["systemctl", "show", SERVICE, *["--property=" + key for key in properties]], text=True)
    state = dict(line.split("=", 1) for line in raw.splitlines() if "=" in line)
    assert state["WorkingDirectory"] == str(LIVE), "服务工作目录与已核实线上应用不符"
    command = re.search(r"argv\[\]=(.*?) ;", state["ExecStart"])
    assert command and command[1] == "/usr/bin/npm run start --workspace @petworld/web -- --hostname 127.0.0.1 --port 3010", "服务启动命令发生变化"
    assert not any(state.get(key) for key in ["ExecStartPre", "ExecStartPost", "ExecStop", "ExecStopPost"]), "服务存在未核实的启停附加命令"
    listeners = port_listeners()
    pids = set(re.findall(r"pid=(\d+)", listeners))
    assert len(listeners.splitlines()) == 1 and "127.0.0.1:3010" in listeners and len(pids) == 1, "3010监听无法唯一归属，停止"
    chain = [process_identity(int(next(iter(pids))))]
    chain.append(process_identity(chain[-1]["ppid"]))
    chain.append(process_identity(chain[-1]["ppid"]))
    app = str(LIVE / "apps/web")
    version = json.loads((LIVE / "node_modules/next/package.json").read_text())["version"]
    assert chain[0]["cwd"] == app and chain[0]["cmdline"] == f"next-server (v{version})", "监听进程不是已核实的线上Next应用"
    assert chain[1]["cwd"] == app and chain[1]["cmdline"] == "sh -c next start --hostname 127.0.0.1 --port 3010", "Next父进程链发生变化"
    npm = chain[2]
    assert npm["ppid"] == 1 and npm["cwd"] in {str(LIVE), app}, "npm父链或工作目录不符合既定部署"
    assert npm["cmdline"].startswith("npm run start") and "--hostname 127.0.0.1" in npm["cmdline"] and "--port 3010" in npm["cmdline"], "npm启动参数异常"
    groups = {item["cgroup"] for item in chain}
    assert len(groups) == 1, "进程父链跨越不同控制组，停止"
    group = next(iter(groups))
    if group == "0::" + state.get("ControlGroup", "") and state.get("ControlGroup"):
        assert state["ActiveState"] == "active" and state["SubState"] == "running" and int(state["MainPID"]) == npm["pid"], "服务主进程与3010监听不一致"
        mode = "service"
    else:
        assert re.fullmatch(r"0::/user.slice/user-0.slice/session-\d+\.scope", group), "独立进程不属于已核实的root会话"
        assert hasattr(os, "pidfd_open") and hasattr(signal, "pidfd_send_signal"), "缺少避免PID复用误杀的能力"
        mode = "detached"
    return {"mode": mode, "chain": chain}

def fingerprint():
    result = {}
    for directory, dirs, files in os.walk(LIVE):
        dirs[:] = sorted(d for d in dirs if d not in {"node_modules", ".next", ".git", ".cache"})
        for name in sorted(files):
            if name.endswith(".tsbuildinfo") or name.startswith(".tmp"):
                continue
            path = pathlib.Path(directory) / name
            result[str(path.relative_to(LIVE))] = os.readlink(path) if path.is_symlink() else digest(path)
    result[".next/BUILD_ID"] = digest(LIVE / "apps/web/.next/BUILD_ID")
    return result

def probe(base):
    page_assets, farm_assets = set(), set()
    routes = ("/mine", "/mine/mobile", "/farm") if farm_patch is not None else ("/mine", "/mine/mobile")
    for route in routes:
        with urllib.request.urlopen(base + route, timeout=15) as response:
            assert response.status == 200
            body = response.read().decode()
        if route == "/farm":
            assert 'class="farm-page' in body and 'data-testid="farm-wallet-bar"' in body, "农场页面缺少批准的正式余额入口"
        else:
            assert "mine-page-slim" in body and "data-mine-worker" in body, "页面缺少精简矿洞或视频矿工：" + route
        assert not re.search(r"ByteString|Cannot convert argument|data-dgst=|__next_error__|NEXT_HTTP_ERROR_FALLBACK|[0-9a-f]+:E\{", body), "页面包含SSR/流式渲染错误：" + route
        references = {html.unescape(x) for x in re.findall(r'(?:src|href)="([^"\s]+)"', body)}
        if route == "/farm":
            wallet_links = [urllib.parse.urlsplit(link) for link in references]
            assert any(not link.scheme and not link.netloc and link.path == "/game-wallet"
                       and urllib.parse.parse_qs(link.query, keep_blank_values=True) == {"game": ["farm"], "returnTo": ["/farm"]}
                       for link in wallet_links), "农场补币入口游戏归属或返回路径错误"
        route_assets = {x for x in references if x.startswith("/_next/") and re.search(r"\.(js|css)(?:\?|$)", x)}
        assert route_assets, "没有找到页面脚本/样式：" + route
        page_assets.update(route_assets)
        if route == "/farm":
            farm_assets.update(x for x in references if x.startswith("/farm/") and re.search(r"\.(png|webp|jpg|svg)(?:\?|$)", x))
            assert farm_assets, "农场页面没有可验活的场景素材"
    for asset in sorted(page_assets):
        with urllib.request.urlopen(base + asset, timeout=15) as response:
            assert response.status == 200
    for asset in sorted(farm_assets):
        public_path = urllib.parse.unquote(urllib.parse.urlsplit(asset).path)
        source = candidate / "apps/web/public" / public_path.lstrip("/")
        assert source.resolve().is_relative_to(candidate / "apps/web/public") and source.is_file(), "农场素材超出候选范围"
        with urllib.request.urlopen(base + urllib.parse.quote(asset, safe="/%?=&"), timeout=15) as response:
            assert response.status == 200
            content = response.read(source.stat().st_size + 1)
        assert hashlib.sha256(content).hexdigest() == digest(source), "农场公开素材与既有候选不一致：" + public_path
    for asset in payload["assets"]:
        public_path = asset["path"].removeprefix("apps/web/public")
        with urllib.request.urlopen(base + urllib.parse.quote(public_path, safe="/"), timeout=15) as response:
            content = response.read(asset["size"] + 1)
        assert len(content) == asset["size"] and hashlib.sha256(content).hexdigest() == asset["sha256"], "矿洞公开资产与发布包不一致"

def check_preview_log():
    text = (work / "候选验活.log").read_text(errors="replace")
    assert not re.search(r"TypeError|ByteString|Cannot convert argument|(?:^|\n).*⨯", text), "候选服务日志出现运行错误，停止发布"


def stop_preview():
    if preview and preview.poll() is None:
        os.killpg(preview.pid, signal.SIGTERM)
        try:
            preview.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(preview.pid, signal.SIGKILL)
            preview.wait()

expected_hash = payload.pop("sha256")
assert hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode()).hexdigest() == expected_hash
changes = payload["changes"]
farm_patch = payload.get("farm_patch")
if farm_patch is not None and farm_patch.get("mode") == "coin-wallet-v2":
    FARM_ALLOWED = FARM_ALLOWED | {"apps/web/lib/farm/农场待结算.ts"}
mine_extra_paths = payload.get("mine_extra_paths", [])
assert isinstance(mine_extra_paths, list) and all(isinstance(rel, str) for rel in mine_extra_paths), "矿洞新增源码清单格式错误"
assert len(mine_extra_paths) == len(set(mine_extra_paths)) and set(mine_extra_paths) <= MINE_EXTRA_ALLOWED, "矿洞新增源码超出明确白名单"
ore_sources = set(mine_extra_paths) & ORE_SOURCES
assert not ore_sources or ore_sources == ORE_SOURCES, "矿石组件源码必须完整2文件"
ore_enabled = bool(ore_sources)
if ore_enabled:
    assert re.fullmatch(r"[a-f0-9]{64}", payload.get("ore_manifest_sha256") or ""), "矿石已验收清单SHA缺失"
expected_paths = ALLOWED | set(mine_extra_paths) | (FARM_ALLOWED if farm_patch is not None else set())
assert payload.get("version") == 3 and len(changes) == len(expected_paths) and {c["path"] for c in changes} == expected_paths, "发布清单超出范围（农场只能0、完整5文件或含恢复模块的6文件）"
for change in changes:
    if change["path"] in mine_extra_paths:
        assert isinstance(change["target"], str) and change["target"].strip(), "新增矿洞源码不可为空或删除"
        assert change["base"] is None or isinstance(change["base"], str), "新增矿洞源码基线格式错误"
if farm_patch is not None:
    assert farm_patch.get("mode") in {"coin-wallet-v1", "coin-wallet-v2"} and set(farm_patch.get("targets", {})) == FARM_ALLOWED, "农场批准范围错误"
    assert re.fullmatch(r"[a-f0-9]{64}", farm_patch.get("page_patch_base_sha256", "")), "农场修改前基线记录缺失"
    for change in changes:
        if change["path"] in FARM_ALLOWED:
            assert isinstance(change["target"], str) and hashlib.sha256(change["target"].encode()).hexdigest() == farm_patch["targets"][change["path"]], "农场目标未获批准或哈希不一致"

assets = payload["assets"]
expected_assets = ASSET_ALLOWED | (ORE_ASSETS if ore_enabled else set())
assert len(assets) == len(expected_assets) and {a["path"] for a in assets} == expected_assets, "资产清单超出范围或五种矿石不完整"
asset_targets = {}
for asset in assets:
    data = base64.b64decode(asset["data_base64"], validate=True)
    limit = 64 * 1024 if asset["path"].endswith(".json") else 2 * 1024**2
    assert 0 < len(data) == asset["size"] <= limit and hashlib.sha256(data).hexdigest() == asset["sha256"], "资产大小或SHA-256不符"
    assert asset["base_sha256"] is None or re.fullmatch(r"[a-f0-9]{64}", asset["base_sha256"]), "资产基线哈希异常"
    if asset["path"].endswith(".webp"):
        assert data[:4] == b"RIFF" and data[8:12] == b"WEBP", "WebP资产格式异常"
    else:
        assert isinstance(json.loads(data), dict), "动画参数格式异常"
    if asset["path"] in ORE_ASSETS:
        assert "图集" in asset["path"] or len(data) <= 128 * 1024, "矿石静态帧超过128KiB"
        check_ore_webp(data, "图集" in asset["path"])
    asset_targets[asset["path"]] = data
assert sum(len(c["target"].encode()) for c in changes if c["target"] is not None) + sum(map(len, asset_targets.values())) <= 10 * 1024**2, "全部发布目标超过10MiB"
release_paths = [c["path"] for c in changes] + [a["path"] for a in assets]
lock = open("/tmp/eccomall-mine-release.lock", "w")
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
timing_base = next(c["base"] for c in changes if c["path"] == "apps/web/lib/mine/矿洞动画节奏.ts")
timing_path = LIVE / "apps/web/lib/mine/矿洞动画节奏.ts"
assert isinstance(timing_base, str) and payload.get("previous_package_sha256"), "必须提供上一成功发布包的节奏基线"
assert timing_path.is_file() and not timing_path.is_symlink() and timing_path.resolve().is_relative_to(LIVE), "线上节奏文件缺失或路径异常"
assert timing_path.read_bytes() == timing_base.encode(), "线上节奏文件与已验证发布基线不同，停止；不会任意覆盖"
api_change = next(c for c in changes if c["path"] == "apps/web/lib/mine/矿洞接口.ts")
api_path = LIVE / api_change["path"]
assert api_path.is_file() and not api_path.is_symlink() and api_path.read_text() in (api_change["base"], api_change["target"]), "矿洞接口偏离上一成功包基线"
runtime_before = inspect_runtime()
print("3010运行模式：" + runtime_before["mode"] + "；候选构建期间保持现有进程运行。", flush=True)
available_kib = int(re.search(r"^MemAvailable:\s+(\d+)", pathlib.Path("/proc/meminfo").read_text(), re.M)[1])
# macOS 同参数隔离构建实测进程树 RSS 峰值约 640 MiB；不代替 Linux cgroup 实际构建验证。
assert available_kib >= 896 * 1024, "可用内存不足 896 MiB，停止；不会停用线上服务来腾内存"
assert shutil.disk_usage(ROOT).free >= 3 * 1024**3, "可用磁盘不足 3 GiB，停止"
assert pathlib.Path("/sys/fs/cgroup/cgroup.controllers").exists() and shutil.which("systemd-run"), "缺少构建内存隔离能力"
with socket.socket() as sock:
    sock.bind(("127.0.0.1", 3011))
assert (LIVE / "apps/web/.next/BUILD_ID").is_file(), "没有可回退的线上构建"
before = fingerprint()
stamp = time.strftime("%Y%m%d-%H%M%S") + "-" + str(os.getpid())
work = ROOT / "deploy_backups" / ("矿洞前端-" + stamp)
candidate = work / "候选" / "game"
backup = work / "原版"
work.mkdir(parents=True, exist_ok=False)
print("候选与回退目录：" + str(work), flush=True)
# 只在服务器内部复制。复制依赖保留 workspace 的相对链接，不共享可写依赖目录。
shutil.copytree(LIVE, candidate, symlinks=True,
                ignore=shutil.ignore_patterns(".next", ".git", ".cache", "*.tsbuildinfo", ".tmp*"))
assert before == fingerprint(), "复制期间线上源文件发生变化，停止"
for change in changes:
    rel = change["path"]
    path = candidate / rel
    assert not path.is_symlink() and path.resolve().is_relative_to(candidate), "候选路径越界"
    current = path.read_text() if path.is_file() else None
    base, target = change["base"], change["target"]
    if rel in FARM_ALLOWED or rel in mine_extra_paths:
        assert current == base or current == target, "受保护源码偏离准备快照，请重新核对：" + rel
    if current == target:
        continue
    if target is None:
        assert current == base, f"已退役文件出现线上新改动，停止：{rel}"
        path.unlink()
    elif current == base:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(target)
    else:
        assert current is not None and base is not None, f"新增/缺失文件冲突：{rel}"
        merge_base, merge_target = work / "合并基线", work / "合并目标"
        merge_base.write_text(base)
        merge_target.write_text(target)
        merged = subprocess.run(["git", "merge-file", "-p", str(path), str(merge_base), str(merge_target)], capture_output=True)
        assert merged.returncode == 0, f"线上补丁冲突，未改线上文件：{rel}"
        path.write_bytes(merged.stdout)
# 新矿工图集先落候选；已有同名素材仅允许相同内容或经快照核实的基线。
for asset in assets:
    path = candidate / asset["path"]
    assert not path.is_symlink() and path.resolve().is_relative_to(candidate), "资产候选路径越界"
    current = digest(path)
    if current == asset["sha256"]:
        continue
    assert current == asset["base_sha256"], "同名矿工资产存在未知线上改动，停止：" + asset["path"]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(asset_targets[asset["path"]])
# 其他矿洞素材沿用服务器；缺素材时构建前停止，不上传其他工作流的资源。
asset_source = (candidate / "apps/web/lib/mine/assets.ts").read_text()
for asset in re.findall(r'"(/mine/[^"\n]+)"', asset_source):
    assert (candidate / "apps/web/public" / asset.lstrip("/")).is_file(), "线上缺少矿洞素材：" + asset
if farm_patch is not None:
    for rel in FARM_ALLOWED:
        source = (candidate / rel).read_text()
        for asset in re.findall(r'["\'](/farm/[^"\'\n]+?\.(?:png|webp|jpg|svg))["\']', source):
            assert (candidate / "apps/web/public" / asset.lstrip("/")).is_file(), "线上缺少农场既有素材：" + asset
config = candidate / "next.config.ts"
config_text = config.read_text()
assert config_text.count("export default nextConfig;") == 1, "无法限定候选构建 worker，停止"
config.write_text(config_text.replace("export default nextConfig;", "nextConfig.experimental = { ...nextConfig.experimental, cpus: 1, workerThreads: false, memoryBasedWorkersCount: false, webpackBuildWorker: false };\nexport default nextConfig;"))
# 临时 scope 只限制此次构建；不创建/修改任何持久服务配置。Webpack 避免另启 Turbopack worker。
with (work / "构建日志.log").open("w") as log:
    try:
        run(["systemd-run", "--scope", "--quiet", "--unit=mine-build-" + stamp,
             "-p", "MemoryMax=768M", "-p", "MemorySwapMax=0", "-p", "CPUQuota=100%",
             "env", "NODE_OPTIONS=--max-old-space-size=384", "NEXT_TELEMETRY_DISABLED=1",
             "npm", "run", "build", "--workspace", "@petworld/web", "--", "--webpack"],
            cwd=candidate, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
    except BaseException:
        subprocess.run(["systemctl", "stop", "mine-build-" + stamp + ".scope"], check=False)
        raise
config.write_text(config_text)
preview = None
switched = False
source_touched = False
runtime_stopped = False
farm_static_page = ROOT / "frontend-v3-root/current/farm.html"
farm_static_digest = digest(farm_static_page)
expected_farm = {rel: digest(candidate / rel) for rel in FARM_ALLOWED}
if farm_patch is not None:
    assert expected_farm == farm_patch["targets"], "候选农场不等于批准目标"
else:
    assert expected_farm == {rel: digest(LIVE / rel) for rel in FARM_ALLOWED}, "矿洞模式修改了农场源码"
try:
    with (work / "候选验活.log").open("w") as log:
        preview = subprocess.Popen(["npm", "run", "start", "--workspace", "@petworld/web", "--",
                                    "--hostname", "127.0.0.1", "--port", "3011"], cwd=candidate,
                                   stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        for attempt in range(30):
            try:
                probe("http://127.0.0.1:3011")
                break
            except Exception:
                if preview.poll() is not None or attempt == 29:
                    raise
                time.sleep(1)
    stop_preview()
    check_preview_log()
    assert before == fingerprint(), "构建期间线上源文件或构建已变化；保留候选，停止发布"
    # 完整备份所有将触碰的白名单源文件；农场仅显式批准的农场文件，不覆盖其他壳层/预加载/依赖。
    for rel in release_paths:
        source, saved = LIVE / rel, backup / rel
        if source.is_file():
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, saved)
    old_next, new_next = LIVE / "apps/web/.next", candidate / "apps/web/.next"
    new_build_digest = digest(new_next / "BUILD_ID")
    assert new_build_digest, "候选构建标识缺失"
    # 保留已打开页面使用的旧哈希静态文件。
    for source in (old_next / "static").rglob("*"):
        target = new_next / "static" / source.relative_to(old_next / "static")
        if source.is_file() and not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    assert before == fingerprint(), "备份期间线上发生变化，停止"
    assert inspect_runtime() == runtime_before, "构建期间3010进程身份/父链发生变化，停止"
    runtime_stopped = True
    run(["systemctl", "stop", SERVICE])
    if runtime_before["mode"] == "detached":
        assert inspect_runtime() == runtime_before, "停止空转服务后独立进程身份已变化，禁止发信号"
        listener = runtime_before["chain"][0]
        handle = os.pidfd_open(listener["pid"])
        try:
            assert process_identity(listener["pid"]) == listener, "PID身份变化，禁止发信号"
            signal.pidfd_send_signal(handle, signal.SIGTERM)
        finally:
            os.close(handle)
    for attempt in range(60):
        if not port_listeners():
            break
        time.sleep(0.25)
    assert not port_listeners(), "3010未释放，停止；不会升级信号或杀其他进程"
    assert before == fingerprint(), "接管进程期间线上源码/构建变化，停止"
    source_touched = True
    for rel in release_paths:
        target, source = LIVE / rel, candidate / rel
        if source.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            staged = target.with_name(target.name + ".mine-release")
            shutil.copy2(source, staged)
            os.replace(staged, target)
        elif target.exists():
            target.unlink()
    os.rename(old_next, work / "旧构建")
    switched = True
    os.rename(new_next, old_next)
    run(["systemctl", "start", SERVICE])
    for attempt in range(30):
        try:
            assert inspect_runtime()["mode"] == "service", "新版3010尚未由既有服务管理"
            probe("https://vivodraw.com")
            break
        except Exception:
            if attempt == 29:
                raise
            time.sleep(1)
    for route in ("/", "/farm"):
        with urllib.request.urlopen("https://vivodraw.com" + route, timeout=15) as response:
            assert response.status == 200
    request = urllib.request.Request("https://vivodraw.com/api/category", headers={"X-Client": "mobile-app"})
    with urllib.request.urlopen(request, timeout=15) as response:
        assert json.load(response)["status"] == 200
    assert digest(farm_static_page) == farm_static_digest, "商城静态农场入口发生变化"
    assert {rel: digest(LIVE / rel) for rel in FARM_ALLOWED} == expected_farm, "农场源码不等于批准候选"
    expected_after = dict(before)
    for rel in release_paths:
        if (candidate / rel).is_file(): expected_after[rel] = digest(candidate / rel)
        else: expected_after.pop(rel, None)
    expected_after[".next/BUILD_ID"] = new_build_digest
    assert fingerprint() == expected_after, "发布后存在批准清单以外的源文件漂移"
    assert inspect_runtime()["mode"] == "service", "发布后3010服务归属异常"
    print("矿洞前端发布与公开页面验活通过。真实账号结算仍需另行验证。备份：" + str(work), flush=True)
except BaseException:
    # 先记录首个异常；后续恢复日志/管道失败不能跳过重启旧服务。
    def record_failure(label):
        try:
            with (work / "发布异常.log").open("a") as log:
                log.write(label + "\n" + traceback.format_exc() + "\n")
        except OSError:
            pass
    record_failure("发布失败")
    try:
        stop_preview()
        if runtime_stopped:
            run(["systemctl", "stop", SERVICE])
        if source_touched:
            if switched:
                if (LIVE / "apps/web/.next").exists():
                    os.rename(LIVE / "apps/web/.next", work / "失败构建")
                os.rename(work / "旧构建", LIVE / "apps/web/.next")
            for rel in release_paths:
                target, saved = LIVE / rel, backup / rel
                if saved.is_file():
                    shutil.copy2(saved, target)
                elif target.exists():
                    target.unlink()
    except BaseException:
        record_failure("恢复构建或文件时失败")
    finally:
        if runtime_stopped:
            try:
                run(["systemctl", "start", SERVICE])
            except BaseException:
                record_failure("恢复服务启动失败，需查看持久日志")
    print("发布失败，已尝试恢复旧构建/源文件并启动服务；完整结果见：" + str(work), flush=True)
    raise
finally:
    stop_preview()
PY
python3 - "$STAGING" "$PACKAGE" <<'PY'
import pathlib, sys, tarfile
folder = pathlib.Path(sys.argv[1])
compile((folder / "执行.py").read_text(), "矿洞发布执行器", "exec")
# 使用 Python 打包，避免 macOS tar 自动加入 ._ AppleDouble 文件。
with tarfile.open(sys.argv[2], "w:gz") as archive:
    for name in ("清单.json", "执行.py"):
        archive.add(folder / name, arcname=name, recursive=False)
assert pathlib.Path(sys.argv[2]).stat().st_size <= 10 * 1024**2, "准备包超过10MiB"
PY
echo "准备包：$PACKAGE"
echo "此命令没有发布。核对准备包后执行：bash deploy/发布矿洞前端.sh --publish \"$PACKAGE\""
