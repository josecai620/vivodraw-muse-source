#!/bin/bash
# CRMEB 后端一键启动（Docker 方式，含 Swoole）
# 使用：cd deploy && bash start.sh
# 首次安装或重置数据库：bash start.sh --fresh

cd "$(dirname "$0")"

if [ ! -f .env ]; then
  echo "未找到 .env 文件，从 .env.example 复制..."
  cp .env.example .env
  echo "已创建 .env，使用默认密码。如需修改请编辑后重新执行。"
fi

if [ "$1" = "--fresh" ]; then
  echo "重置模式：停止并删除数据卷..."
  docker-compose down -v
fi

echo "启动 MySQL、Redis、App 容器..."
docker-compose up -d

echo ""
echo "等待服务启动（约 30 秒，首次需导入数据库）..."
sleep 30

if docker-compose ps | grep -q crmeb-app; then
  echo ""
  echo "✅ 后端已启动"
  echo "   API: http://127.0.0.1:20199"
  echo "   测试: curl http://127.0.0.1:20199/api/index"
else
  echo ""
  echo "⚠️ 请检查: docker-compose ps -a"
fi
