# -*- coding: utf-8 -*-
"""机器人画像（头像去重 + 手机号昵称）：按清单发布后端 PHP。

范围固定为 3 个文件，不整包同步：
  备份 → LF 规范化暂存 → scp → 容器内 php -l → 核对远端 SHA256 → 清路由缓存 → 重启 php-fpm → 线上验活。
"""
import hashlib
import os
import subprocess
import sys
import tempfile
import time

KEY = os.path.expanduser(r"~\.ssh\vivodraw_windows_ed25519")
PORT = "49375"
HOST = "root@186.241.72.176"
REMOTE_DIR = "/opt/crmeb-prod"
ROOT = r"D:\eccomall"
FILES = [
    "backend_src/app/services/yunmall/RobotAccountService.php",
    "backend_src/app/controller/admin/v1/yunmall/RobotPad.php",
    "backend_src/route/admin.php",
]
STAGING = os.path.join(tempfile.gettempdir(), "t29-robot-profile-lf")

SSH = ["ssh", "-i", KEY, "-p", PORT, "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes", "-o", "ServerAliveInterval=15", HOST]
SCP = ["scp", "-O", "-i", KEY, "-P", PORT, "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes"]


def run(cmd, timeout=240):
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout)
    if proc.returncode != 0:
        raise SystemExit("命令失败：%s\n%s\n%s" % (cmd[0], proc.stdout, proc.stderr))
    return proc.stdout.strip()


def sha256_local(path):
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def main():
    sha = {}
    for rel in FILES:
        src = os.path.join(ROOT, rel.replace("/", os.sep))
        if not os.path.isfile(src):
            raise SystemExit("缺少本地文件：" + src)
        dest = os.path.join(STAGING, rel.replace("/", os.sep))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(src, "rb") as fh:
            data = fh.read().replace(b"\r\n", b"\n")
        with open(dest, "wb") as fh:
            fh.write(data)
        sha[rel] = hashlib.sha256(data).hexdigest()
    print("待发布文件：" + ", ".join(FILES), flush=True)

    stamp = time.strftime("%Y%m%d-%H%M%S")
    backup = "mkdir -p %s/deploy_backups && cd %s && tar --ignore-failed-read -czf deploy_backups/机器人画像后端-%s.tar.gz %s && echo BACKUP_OK" % (
        REMOTE_DIR, REMOTE_DIR, stamp, " ".join(FILES))
    print(run(SSH + [backup]), flush=True)

    for rel in FILES:
        local = os.path.join(STAGING, rel.replace("/", os.sep))
        print(run(SCP + [local, "%s:%s/%s" % (HOST, REMOTE_DIR, rel)]), flush=True)

    remote_sha = run(SSH + ["cd %s && sha256sum %s" % (REMOTE_DIR, " ".join(FILES))])
    remote_map = {}
    for line in remote_sha.splitlines():
        parts = line.split()
        if len(parts) == 2:
            remote_map[parts[1]] = parts[0]
    bad = [rel for rel in FILES if remote_map.get(rel) != sha[rel]]
    if bad:
        raise SystemExit("上传后 SHA256 不一致，请人工核对：" + ", ".join(bad))
    print("远端 SHA256 全部一致", flush=True)

    lint = " && ".join("docker exec crmeb-php-fpm php -l /var/www/backend/" + rel.replace("backend_src/", "") for rel in FILES)
    print(run(SSH + [lint]), flush=True)

    restart = ("rm -f %s/backend_src/runtime/route_list.php && docker restart crmeb-php-fpm && sleep 6 && "
               "curl -fsS -o /dev/null -w 'vivodraw home: %%{http_code}\n' --max-time 30 https://vivodraw.com/") % REMOTE_DIR
    print(run(SSH + [restart]), flush=True)
    print("DEPLOY_OK", flush=True)


if __name__ == "__main__":
    main()
