# -*- coding: utf-8 -*-
"""对比 v3/v4 两套前端的 app 路由树（相对 app 目录的 tsx 路径集合）。"""
import os

V3 = r'D:\eccomall\mobile-app-v3\app'
V4 = r'D:\eccomall\mobile-app\app'

def routes(root):
    out = set()
    for dp, _, files in os.walk(root):
        for f in files:
            if not f.endswith('.tsx'):
                continue
            if f.startswith('.') or f.endswith('.bak'):
                continue
            full = os.path.join(dp, f)
            rel = os.path.relpath(full, root).replace('\\', '/')
            out.add(rel)
    return out

r3, r4 = routes(V3), routes(V4)
only3 = sorted(r3 - r4)
only4 = sorted(r4 - r3)
print('v3 pages:', len(r3), '| v4 pages:', len(r4))
print('\n=== 仅 v3 有、v4 没有（%d）===' % len(only3))
for x in only3:
    print(x)
print('\n=== 仅 v4 有、v3 没有（%d）===' % len(only4))
for x in only4:
    print(x)
