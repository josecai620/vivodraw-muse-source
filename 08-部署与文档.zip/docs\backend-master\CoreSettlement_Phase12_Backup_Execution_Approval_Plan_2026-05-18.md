# CoreSettlement Phase 12 Backup And Execution Approval Plan 2026-05-18

## Current Task

Phase 12 只做 backup-and-execution approval planning。

本轮未执行 SQL，未创建备份，未修改服务器，未修改生产 DB，未开启任何 switch。

## Decision

Current status is **NO-GO** for DB-changing execution.

Reasons:

1. Phase 11 confirmed target DB is reachable but writable.
2. `eb_core_settlement_ledger` is missing.
3. all five CoreSettlement switch rows are missing.
4. expected backup path `/opt/crmeb-prod/db_backup` was not confirmed present in Phase 11.
5. no fresh backup artifact has been created or verified for this change.

## Approved Planning Scope

Allowed in this phase:

- document backup candidates
- document execution gates
- document rollback gates
- document readonly checks
- document forbidden SQL and forbidden modules

Forbidden in this phase:

- create a backup
- execute table creation SQL
- execute switch seed SQL
- update any switch to `1`
- modify production DB
- modify or delete ledger history
- touch payment, order, inventory, or `MangheController`

## Backup Path Candidates

### Primary Candidate

`/opt/crmeb-prod/db_backup/manghehoutai_qhe_YYYYMMDD_HHMMSS.sql.gz`

Evidence:

- `deploy/daily_maintenance.sh` defines `DB_DIR=/opt/crmeb-prod/db_backup`
- it writes `manghehoutai_qhe_${TS}.sql.gz`
- it verifies with `gzip -t`
- it checks non-empty uncompressed size
- it keeps recent dumps and deletes older dumps past retention

Risk:

- Phase 11 did not confirm `/opt/crmeb-prod/db_backup` exists.
- retention may delete older backups.
- fresh backup must be created and verified in a separately approved phase.

### Local Export Candidate

`/Users/joe/eccomall/db_backup/db_YYYYMMDD_HHMMSS.sql.gz`

Evidence:

- `deploy/从服务器导出数据库.sh` exports remote DB to `/tmp/db_export_*.sql.gz`
- then downloads to local `db_backup/db_*.sql.gz`
- then removes the remote temporary dump

Risk:

- this creates a new backup artifact and must be explicitly approved before running
- local backup must be verified with `gzip -t`
- restore must be tested against a temporary DB before trusting it for rollback planning

### Ops Alternative

`/opt/crmeb-backups/YYYY-MM-DD_HHMMSS/db.sql.gz`

Evidence:

- `deploy/ops/backup_daily.sh` writes DB dump to `${BACKUP_DIR}/${TIMESTAMP}/db.sql.gz`
- default `BACKUP_DIR` is `/opt/crmeb-backups`

Risk:

- depends on `deploy/.deploy.env`
- default script assumes Docker container `crmeb-mysql`
- Phase 11 found no Docker MySQL container name
- not approved until env and restore path are confirmed

### Not Approved As Primary DB Change Backup

- `/opt/crmeb-prod/backend_src/backup`
  - CRMEB admin backup path
  - admin import / optimize / repair capabilities are DB-changing
  - not ideal for this gate
- `/opt/crmeb-prod/deploy_backups`
  - frontend/static deploy backup only
  - not a DB backup

## Required Backup Gate

Before any DB-changing CoreSettlement phase:

1. choose exactly one backup path
2. create a fresh full DB dump in an explicitly approved backup phase
3. verify `gzip -t`
4. verify file size is non-zero
5. record timestamp and absolute path
6. confirm retention will not delete it during rollout
7. test restore path against a temporary DB or provide a documented restore command
8. paste backup verification output into the handoff

No backup means no execution.

## Execution Gate

Before table or switch SQL may run:

1. backup gate passes
2. target environment is re-confirmed
3. readonly check confirms `eb_core_settlement_ledger` is still missing or matches approved schema
4. readonly check confirms all CoreSettlement switches are missing or `0`
5. no switch value is `1`
6. SQL plan contains no ledger mutation statements
7. config cache clear path is known
8. rollback is config-only and keeps ledger append-only

## SQL Execution Order For A Later Approved Phase

This is not approval to execute.

If a later phase is approved:

1. create `eb_core_settlement_ledger`
2. insert missing switch rows with `value='0'`
3. clear config cache only if needed
4. run readonly verification
5. keep all switches `0`
6. stop

Do not open any switch in the same phase as table creation.

## Switch Activation Gate

Switch activation must be a later separate phase.

Rules:

- open one switch at a time
- start with lowest-risk switch only
- confirm legacy business still works
- confirm one audit row shape
- confirm duplicate request returns existing row
- rollback by setting that one switch to `0`
- never modify ledger rows during rollback

## Append-Only Ledger Rule

Allowed:

- `INSERT` new audit row
- duplicate lookup by `scene + request_id`
- append future compensating row after explicit approval

Forbidden:

- `UPDATE eb_core_settlement_ledger`
- `DELETE FROM eb_core_settlement_ledger`
- `TRUNCATE TABLE eb_core_settlement_ledger`
- `DROP TABLE eb_core_settlement_ledger`
- rewriting historical `amount`, `direction`, `reason`, `meta`, or `add_time`

Current `settlement_event_id` contract:

- no separate `settlement_event_id` column exists
- current `request_id` is the settlement event id
- current unique key remains `scene + request_id`

## Current NO-GO Summary

Do not proceed to execution because:

- no approved fresh backup exists
- target DB table is missing
- switch rows are missing
- DB is writable
- execution approval has not been granted

## Forbidden Areas

Do not touch without explicit approval:

- `backend_src/app/controller/api/v1/manghe/MangheController.php`
- payment
- order
- real inventory deduction
- write SQL
- structure changes
- migration execution
- production DB mutation
- server `.env`
- `game/*`
- `mobile-app/*`
- `mobile-app-v3/*`
- unrelated dirty worktree changes

## Next Task

Phase 13 should be backup artifact creation approval only.

Recommended next step:

1. choose backup method
2. run exactly one approved backup command
3. verify backup artifact
4. do not execute table/switch SQL
5. write backup artifact report

## NEXT WINDOW HANDOFF PACKAGE

- Role: Backend Master Controller
- Phase: Phase 13 backup artifact creation approval
- Completed: Phase 12 backup and execution approval plan
- Key Findings: current status is NO-GO; primary backup candidate is `/opt/crmeb-prod/db_backup`; local export script is available but creates new artifact and needs explicit approval
- Key Files: this plan, `deploy/daily_maintenance.sh`, `deploy/从服务器导出数据库.sh`, `docs/backend-master/CoreSettlement_Phase11_TargetEnv_Readonly_Readiness_2026-05-18.md`
- Dirty Worktree Notes: unrelated game/mobile/v3/docs deletions remain; do not stage broad changes
- Forbidden Areas: payment/order/Manghe/write SQL/migration/prod DB mutation/game/mobile/v3
- Next Step: create and verify backup only after explicit approval
- Validation: docs-only diff check
- Risks: DB is writable; no fresh backup exists; switch activation must stay separate from table creation
