# -*- coding: utf-8 -*-
"""把 dist-root 的 html 产物映射成线上路由，输出待 curl 列表（动态段用样例值）。"""
import os, re, json
ROOT = r'D:\eccomall\mobile-app\dist-root'
SAMPLE = {
    '[id]': '325', '[type]': 'terms', '[...slug]': 'a/b',
}
routes = []
for dp, _, files in os.walk(ROOT):
    for f in files:
        if not f.endswith('.html'):
            continue
        rel = os.path.relpath(os.path.join(dp, f), ROOT).replace('\\', '/')
        if rel.startswith('(tabs)/'):
            rel = rel[len('(tabs)/'):]
        if rel in ('index.html', '+not-found.html', '_sitemap.html'):
            route = '/' if rel == 'index.html' else None
        else:
            route = '/' + rel[:-5]  # strip .html
            if route.endswith('/index'):
                route = route[:-len('/index')] or '/'
            for k, v in SAMPLE.items():
                route = route.replace(k, v)
        if route:
            routes.append(route)
routes = sorted(set(routes))
with open(r'D:\eccomall\deploy\routes.txt', 'w', encoding='utf-8') as fh:
    fh.write('\n'.join(routes))
print(len(routes), 'routes')
