-- ===========================================================
-- 三商城独立栏目重构 · 第二阶段
-- ===========================================================
-- 目标：
--   1) 各商城子菜单 path 增加 ?mall_type=N&lock=1，前端 productList/productAdd/productClassify
--      据此自动锁定 mall_type、隐藏选择器
--   2) 把"常规商城"侧栏下盲盒专属的菜单（开盒记录/盲盒中奖设置/盲盒赠送抽奖）软删除（盲盒商城已有相同 path）
--   3) 把"常规商城"侧栏下与商品类型无关的基础设置菜单（规格/评论/品牌/单位/标签/参数/保障服务）
--      挪到新独立顶栏「商品基础设置」（id=2330，header='product_base'）
--   4) 角色权限追加新菜单 id
--
-- mall_type 索引规约：
--   0=常规商城, 1=积分商城, 2=盲盒商城（与前端 Option value 对齐，与后端 1<<value 对齐）
-- ===========================================================

SET NAMES utf8mb4;

-- ===== 1. 常规商城（id=1）顶栏与子菜单 path 增加 lock=1 =====
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/product/product_list?mall_type=0&lock=1'   WHERE `id` = 1  AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/product/product_list?mall_type=0&lock=1'   WHERE `id` = 2  AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/product/product_classify?mall_type=0&lock=1' WHERE `id` = 3  AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/product/add_product?mall_type=0&lock=1'    WHERE `id` = 22 AND `is_del` = 0;

-- ===== 2. 盲盒商城（id=2310）顶栏与子菜单 path 增加 lock=1 =====
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_manghe/product_list?mall_type=2&lock=1' WHERE `id` = 2310 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_manghe/product_list?mall_type=2&lock=1' WHERE `id` = 2311 AND `is_del` = 0;
UPDATE `eb_system_menus` SET `menu_path` = '/admin-shop/mall_manghe/add_product?mall_type=2&lock=1'  WHERE `id` = 2312 AND `is_del` = 0;

-- ===== 3. 软删除常规商城侧栏下与盲盒重复的菜单（盲盒商城已挂同 path 的对应菜单）=====
-- id=1511 开盒记录       → 盲盒商城已有 id=2313 同 path
-- id=1509 盲盒中奖设置    → 盲盒商城已有 id=2314 同 path
-- id=1510 盲盒赠送抽奖中奖设置 → 盲盒商城已有 id=2315 同 path
UPDATE `eb_system_menus` SET `is_del` = 1 WHERE `id` IN (1509, 1510, 1511) AND `is_del` = 0;

-- ===== 4. 新建「商品基础设置」顶栏 id=2330 =====
INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2330, 0, 1, 'md-build', '商品基础设置', 'admin', 'product.base', 'index', '', '', '[]', 110, 1, 0, 1, '/admin-shop/product/product_attr', '', 1, 'product_base', 1, 'admin-product-base', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2330 AND `is_del` = 0);

-- ===== 5. 把基础设置类菜单挪到「商品基础设置」顶栏（pid=2330, header='product_base'）=====
-- id=99 商品规格、id=6 商品评论、id=1338 商品品牌、id=1349 商品单位、
-- id=1380 商品标签、id=1381 商品参数、id=1382 保障服务
UPDATE `eb_system_menus`
  SET `pid` = 2330, `header` = 'product_base'
  WHERE `id` IN (99, 6, 1338, 1349, 1380, 1381, 1382) AND `is_del` = 0;

-- ===== 6. 角色权限追加 2330 =====
UPDATE `eb_system_role`
  SET `rules` = CONCAT(IFNULL(`rules`, ''), ',2330')
  WHERE `status` = 1
    AND `rules` <> '*'
    AND `rules` IS NOT NULL
    AND `rules` NOT LIKE '%2330%';

-- ===== 验收 SQL =====
-- 常规商城下应只剩 id=2/3/22：
-- SELECT id, pid, menu_name, menu_path FROM eb_system_menus WHERE pid=1 AND is_del=0 ORDER BY sort DESC, id;
-- 商品基础设置下应有 7 项：
-- SELECT id, pid, menu_name, header FROM eb_system_menus WHERE pid=2330 AND is_del=0 ORDER BY sort DESC, id;
