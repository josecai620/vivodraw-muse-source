-- 云购 T09（超卖 + 限流落地）建表 SQL
-- 出处：yunmall-hybrid/modules/{wallet,cloud-buy,lucky-value,draw}/design.md
-- 需用户明确批准后再在生产库执行；执行前请先备份。
-- 执行方式：ssh -p 49375 root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/云购T09执行建表.sh"
-- 说明：六张新表全部建好之后，OrderController exchange / exchange_all 自动切到 CloudBuyService 新路径；
--       任一表缺失则继续走旧路径，不影响现役购买。

-- ---------------------------------------------------------------------------
-- wallet（T02 design §8）：单笔账务幂等，只 INSERT
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `eb_wallet_request` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `request_id` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '调用方幂等键',
  `direction` TINYINT NOT NULL DEFAULT 0 COMMENT '0 debit / 1 credit',
  `amount` INT UNSIGNED NOT NULL DEFAULT 0,
  `reason` VARCHAR(32) NOT NULL DEFAULT '',
  `bill_id` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'eb_user_bill.id',
  `balance_before` INT UNSIGNED NOT NULL DEFAULT 0,
  `balance_after` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_uid_request` (`uid`, `request_id`),
  KEY `idx_uid_time` (`uid`, `created_at`),
  KEY `idx_reason_time` (`reason`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='云购钱包账务幂等（append-only）';

-- ---------------------------------------------------------------------------
-- cloud-buy（T03 design §4 §6）
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `eb_cloud_buy_request` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `request_id` VARCHAR(64) NOT NULL DEFAULT '',
  `status` VARCHAR(16) NOT NULL DEFAULT 'pending' COMMENT 'pending / done',
  `response_json` MEDIUMTEXT DEFAULT NULL COMMENT '整单响应缓存，重放用',
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `done_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_uid_request` (`uid`, `request_id`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='云购结算幂等';

CREATE TABLE IF NOT EXISTS `eb_cloud_buy_code_pool` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `period_no` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'store_product.bianhao',
  `seq` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '块序号，每块 3000 个码',
  `start_offset` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '池内第 0 位对应的已售位置；新开期为 0，在途期靴带为建池时已售数',
  `codes_csv` MEDIUMTEXT NOT NULL COMMENT '打乱后的幸运码，逗号分隔',
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_product_period_seq` (`product_id`, `period_no`, `seq`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='云购每期打乱码池（对齐参考实现 shopcodes）';

-- ---------------------------------------------------------------------------
-- lucky-value（T05 design §6）
-- 唯一键比设计多一列 ref_id：同一次结算多项各写一行（T09 决策 D3）
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `eb_lucky_value_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `delta` INT NOT NULL DEFAULT 0 COMMENT '正加负减',
  `balance_after` INT NOT NULL DEFAULT 0,
  `reason` VARCHAR(32) NOT NULL DEFAULT '' COMMENT 'cloud_buy_join / cloud_buy_deduct / checkin / register / profile / invite / admin_adjust',
  `ref_id` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '期次 id / 订单号 / 操作人',
  `request_id` VARCHAR(64) NOT NULL DEFAULT '',
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_uid_request_reason_ref` (`uid`, `request_id`, `reason`, `ref_id`),
  KEY `idx_uid_time` (`uid`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='幸运值流水（对齐参考实现福分 account）';

-- ---------------------------------------------------------------------------
-- draw（T04 design §5）：满员时刻冻结，resolve 只读本表
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `eb_draw_snapshot` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `period_id` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '{product_id}-{bianhao}',
  `product_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `period_no` INT UNSIGNED NOT NULL DEFAULT 0,
  `total_shares` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '除数，冻结时从 store_product.price 复制',
  `formula_version` VARCHAR(32) NOT NULL DEFAULT 'huigou-public-v1',
  `window_size` SMALLINT UNSIGNED NOT NULL DEFAULT 100,
  `window_scope` VARCHAR(16) NOT NULL DEFAULT 'site',
  `window_count` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '实际 N',
  `mode` VARCHAR(8) NOT NULL DEFAULT 'sum100' COMMENT 'sum100 / x100',
  `tz` VARCHAR(32) NOT NULL DEFAULT 'Asia/Shanghai',
  `end_record_id` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '满员参与记录 huanqu_log.id',
  `end_record_at_ms` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `input_sum` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'S，冻结时预算',
  `content_hash` CHAR(64) NOT NULL DEFAULT '' COMMENT 'sha256(canonical_json(inputs))',
  `holders_hash` CHAR(64) NOT NULL DEFAULT '' COMMENT 'sha256(canonical_json(holders))',
  `legacy_jitter_count` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '窗口内时间键不是直接由毫秒重算得到一致结果的旧记录数（legacy_jitter/legacy_mismatch/legacy_seconds 合计，T09 决策 D2）',
  `frozen_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `reveal_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` TINYINT NOT NULL DEFAULT 0 COMMENT '0 冻结 / 1 已开奖 / 9 错误',
  `resolved_at` INT UNSIGNED DEFAULT NULL,
  `result_sum` BIGINT UNSIGNED DEFAULT NULL,
  `result_modulo` INT UNSIGNED DEFAULT NULL,
  `result_code` INT UNSIGNED DEFAULT NULL,
  `winner_uid` INT UNSIGNED DEFAULT NULL,
  `winner_record_id` BIGINT UNSIGNED DEFAULT NULL,
  `winner_is_robot` TINYINT DEFAULT NULL,
  `error_reason` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_period` (`period_id`),
  KEY `idx_status_reveal` (`status`, `reveal_at`),
  KEY `idx_product_period` (`product_id`, `period_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='可验算开奖快照（一期一行）';

CREATE TABLE IF NOT EXISTS `eb_draw_snapshot_input` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `snapshot_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `seq` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0 = 满员记录，按 id 倒序',
  `record_id` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'huanqu_log.id',
  `record_product_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `record_period_no` INT UNSIGNED NOT NULL DEFAULT 0,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `at_ms` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `time_key` CHAR(9) NOT NULL DEFAULT '' COMMENT 'HHmmss+mmm，从 at_ms 按 tz 重算',
  `time_key_source` VARCHAR(16) NOT NULL DEFAULT 'recomputed' COMMENT 'recomputed / legacy_jitter(≤5ms) / legacy_mismatch(>5ms) / legacy_seconds(无毫秒)',
  `display_name` VARCHAR(64) NOT NULL DEFAULT '' COMMENT '冻结时脱敏昵称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_snapshot_seq` (`snapshot_id`, `seq`),
  KEY `idx_record` (`record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='开奖窗口明细（N 行）';

-- ---------------------------------------------------------------------------
-- 心愿单（清单）表：StoreCartController 一直写 store_integral_cart，但生产库没有这张表，
-- 心愿单增删改查全部落到 cartUnavailable()；旧 exchange_all 又读的是 store_cart。
-- T09 统一为 store_integral_cart（对应 参考实现 cookie Cartlist），结算与心愿单读同一张表。
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `eb_store_integral_cart` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `product_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `product_type` TINYINT NOT NULL DEFAULT 0,
  `bianhao` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '加入时的期号（参考实现 cookie qishu）',
  `cart_num` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT '份数',
  `is_new` TINYINT NOT NULL DEFAULT 0,
  `add_time` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_uid_product` (`uid`, `product_id`),
  KEY `idx_product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='云购心愿单（清单）';

-- ---------------------------------------------------------------------------
-- 现役表调整：huanqu_log.client_request_id 由「幂等键」降为「审计冗余」
-- 多项结算每项都挂同一 requestId（T03 design §5.3 8.3），唯一键会撞，改普通索引。
-- 幂等判断已迁到 eb_cloud_buy_request。
-- ---------------------------------------------------------------------------
SET @has_uk := (SELECT COUNT(*) FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = DATABASE()
                   AND TABLE_NAME = 'eb_store_integral_product_huanqu_log'
                   AND INDEX_NAME = 'uniq_uid_client_request_id');
SET @sql := IF(@has_uk > 0,
  'ALTER TABLE `eb_store_integral_product_huanqu_log` DROP INDEX `uniq_uid_client_request_id`, ADD INDEX `idx_uid_client_request_id` (`uid`, `client_request_id`)',
  'SELECT ''uniq_uid_client_request_id already converted'' AS note');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 现役 huanqu_log(product_id, bianhao) 与 huanqu_log_unique(product_id, bianhao) 没有索引；
-- 结算限购累计、冻结持码读取、开奖都按这两列查，补索引（幂等）。
SET @has_idx1 := (SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE()
                    AND TABLE_NAME = 'eb_store_integral_product_huanqu_log'
                    AND INDEX_NAME = 'idx_product_period');
SET @sql := IF(@has_idx1 = 0,
  'ALTER TABLE `eb_store_integral_product_huanqu_log` ADD INDEX `idx_product_period` (`product_id`, `bianhao`)',
  'SELECT ''idx_product_period exists'' AS note');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @has_idx2 := (SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE()
                    AND TABLE_NAME = 'eb_store_integral_product_huanqu_log_unique'
                    AND INDEX_NAME = 'idx_product_period');
SET @sql := IF(@has_idx2 = 0,
  'ALTER TABLE `eb_store_integral_product_huanqu_log_unique` ADD INDEX `idx_product_period` (`product_id`, `bianhao`)',
  'SELECT ''idx_product_period exists'' AS note');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @has_idx3 := (SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE()
                    AND TABLE_NAME = 'eb_store_integral_product_huanqu_log_unique'
                    AND INDEX_NAME = 'idx_huanqu');
SET @sql := IF(@has_idx3 = 0,
  'ALTER TABLE `eb_store_integral_product_huanqu_log_unique` ADD INDEX `idx_huanqu` (`huanqu_id`)',
  'SELECT ''idx_huanqu exists'' AS note');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
