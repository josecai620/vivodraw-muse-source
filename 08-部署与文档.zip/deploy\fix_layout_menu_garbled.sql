-- 修复「排版管理」菜单乱码
-- 将 menu_name 更正为 UTF-8 中文
UPDATE `eb_system_menus` SET `menu_name` = '排版管理' WHERE `menu_path` = '/admin/setting/pages/layout' AND `is_del` = 0;
