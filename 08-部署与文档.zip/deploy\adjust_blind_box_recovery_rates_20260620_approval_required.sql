-- Approval required: normalize current blind-box recovery values to the safer 25%-40% range.
-- Do not run without owner approval. Dry-run SELECT first, then execute UPDATE inside a manual transaction.
--
-- Current target:
--   tag 1 Common    -> 25%
--   tag 2 Uncommon  -> 28%
--   tag 3 Rare      -> 32%
--   tag 4 Epic      -> 35%
--   tag 5 Legendary -> 38%
--   tag 6 Secret    -> 40%

SELECT
  id,
  store_name,
  price,
  tag,
  reference_price,
  recovery_discount AS old_recovery_discount,
  recovery_price AS old_recovery_price,
  CASE tag
    WHEN 1 THEN 25.00
    WHEN 2 THEN 28.00
    WHEN 3 THEN 32.00
    WHEN 4 THEN 35.00
    WHEN 5 THEN 38.00
    WHEN 6 THEN 40.00
    ELSE 25.00
  END AS new_recovery_discount,
  ROUND(
    COALESCE(NULLIF(reference_price, 0), price) *
    (CASE tag
      WHEN 1 THEN 0.25
      WHEN 2 THEN 0.28
      WHEN 3 THEN 0.32
      WHEN 4 THEN 0.35
      WHEN 5 THEN 0.38
      WHEN 6 THEN 0.40
      ELSE 0.25
    END),
    2
  ) AS new_recovery_price
FROM eb_store_product
WHERE is_recovery = 1
  AND is_del = 0
  AND (COALESCE(mall_type, 0) & 4) > 0
ORDER BY mall_type, id;

-- UPDATE eb_store_product
-- SET
--   reference_price = COALESCE(NULLIF(reference_price, 0), price),
--   recovery_discount = CASE tag
--     WHEN 1 THEN 25.00
--     WHEN 2 THEN 28.00
--     WHEN 3 THEN 32.00
--     WHEN 4 THEN 35.00
--     WHEN 5 THEN 38.00
--     WHEN 6 THEN 40.00
--     ELSE 25.00
--   END,
--   recovery_price = ROUND(
--     COALESCE(NULLIF(reference_price, 0), price) *
--     (CASE tag
--       WHEN 1 THEN 0.25
--       WHEN 2 THEN 0.28
--       WHEN 3 THEN 0.32
--       WHEN 4 THEN 0.35
--       WHEN 5 THEN 0.38
--       WHEN 6 THEN 0.40
--       ELSE 0.25
--     END),
--     2
--   )
-- WHERE is_recovery = 1
--   AND is_del = 0
--   AND (COALESCE(mall_type, 0) & 4) > 0;
