<?php
declare(strict_types=1);

// 默认只审查本地 SQL；显式 --create 才创建已批准的五张客服表。
// MySQL DDL 不能事务回滚；故拒绝已有任意目标表，不执行 ALTER/DROP 或业务数据写入。
$created = [];
$locked = false;
ini_set('display_errors', '0');
ini_set('log_errors', '0');
error_reporting(E_ALL & ~E_DEPRECATED);
set_error_handler(static function (int $severity): bool {
    if (!(error_reporting() & $severity)) return true;
    throw new RuntimeException('safe_schema_failure');
});
try {
    $args = getopt('', ['schema:', 'sha256:', 'create']);
    $file = (string)($args['schema'] ?? __DIR__ . '/客服表结构-需批准.sql');
    if (!is_file($file) || is_link($file) || filesize($file) > 20000) throw new RuntimeException('schema');
    $raw = file_get_contents($file);
    $sha = hash('sha256', $raw);
    $sql = preg_replace('/^--[^\r\n]*/m', '', $raw);
    $statements = array_values(array_filter(array_map('trim', explode(';', $sql))));
    $expected = ['eb_support_conversation', 'eb_support_message', 'eb_support_alert', 'eb_support_image', 'eb_support_budget'];
    if (count($statements) !== 5) throw new RuntimeException('count');
    foreach ($statements as $index => $statement) {
        if (!preg_match('/\ACREATE TABLE IF NOT EXISTS (eb_support_[a-z]+)\s*\([\s\S]+\) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4\z/', $statement, $match)
            || $match[1] !== $expected[$index] || preg_match('/\b(?:ALTER|DROP|TRUNCATE|INSERT|UPDATE|DELETE|TRIGGER|REFERENCES|SELECT|GRANT)\b/i', $statement)) throw new RuntimeException('scope');
    }
    if (!array_key_exists('create', $args)) {
        echo json_encode(['mode' => 'validate_only', 'tables' => $expected, 'sha256' => $sha, 'database_connected' => false]) . "\n";
        exit(0);
    }
    if (!hash_equals($sha, (string)($args['sha256'] ?? ''))) throw new RuntimeException('checksum');
    require '/var/www/backend/vendor/autoload.php';
    require '/var/www/backend/vendor/topthink/framework/src/helper.php';
    $app = new think\App('/var/www/backend');
    // 不启动 HTTP/console/业务服务，不写应用日志或 runtime。
    $app->env->load('/var/www/backend/.env');
    $database = require '/var/www/backend/config/database.php';
    if (($database['default'] ?? '') !== 'mysql' || ($database['connections']['mysql']['prefix'] ?? '') !== 'eb_'
        || (int)$app->env->get('support.enabled', 0) !== 0 || (int)$app->env->get('support.ai_enabled', 0) !== 0) throw new RuntimeException('precondition');
    $database['connections']['mysql']['debug'] = false;
    $database['connections']['mysql']['trigger_sql'] = false;
    $manager = new think\DbManager();
    $manager->setConfig($database);
    $app->instance('think\DbManager', $manager);
    $lock = think\facade\Db::query("SELECT GET_LOCK('support-schema-first-release', 5) AS acquired");
    if ((int)($lock[0]['acquired'] ?? 0) !== 1) throw new RuntimeException('lock');
    $locked = true;
    foreach ($expected as $table) {
        if (think\facade\Db::query('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?', [$table])) throw new RuntimeException('table_already_exists');
    }
    foreach ($statements as $index => $statement) {
        think\facade\Db::execute($statement);
        $created[] = $expected[$index];
    }
    echo json_encode(['mode' => 'created', 'tables' => $created, 'sha256' => $sha, 'ai_enabled' => false, 'business_data_changed' => false]) . "\n";
} catch (Throwable $e) {
    // 不输出框架错误、连接配置或异常堆栈；已建表保留，禁止自动删除或重试。
    echo json_encode(['mode' => 'stopped', 'created_tables' => $created, 'automatic_retry' => false]) . "\n";
    exit(1);
} finally {
    if ($locked) {
        try { think\facade\Db::query("SELECT RELEASE_LOCK('support-schema-first-release')"); } catch (Throwable $ignored) {}
    }
}
