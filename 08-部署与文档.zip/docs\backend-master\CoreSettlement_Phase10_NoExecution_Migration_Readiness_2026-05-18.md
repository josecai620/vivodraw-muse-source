# CoreSettlement Phase 10 No-Execution Migration Readiness 2026-05-18

## Current Task

Phase 10 只做 migration readiness package。

本轮允许分身只读审查；未连接数据库，未执行 SQL，未执行 migration，未修改生产 DB，未修改业务代码。

## Conclusion

Phase 10 当前只允许准备 no-execution package。

当前 PHP writer 的最小 DB 依赖是：

- `eb_core_settlement_ledger`
- 5 个 `eb_system_config` shadow switch，默认 `0`

旧 `CoreSettlement_SQL_Draft.sql` 是 legacy broad draft，不能作为当前执行计划。它没有创建 `eb_core_settlement_ledger`，而 PHP real-write path 只写 `core_settlement_ledger`。

Hard boundary:

- ledger is append-only
- no SQL may update, delete, truncate, or drop historical ledger rows
- rollback only changes config switch values back to `0`
- config seed must not auto-enable CoreSettlement writes

## Subagent Findings

### SQL Drift Review

只读 SQL 分身结论：

- `LedgerService::writeRealLedger()` 写 `Db::name('core_settlement_ledger')`。
- 当前物理表应是 `eb_core_settlement_ledger`。
- `docs/backend-master/CoreSettlement_SQL_Draft.sql` 只定义旧 9 表草案，包含 `eb_core_settlement_record` / `eb_core_point_ledger`，不包含当前 writer 目标表。
- PHP 写入字段是 `scene/action/uid/request_id/amount/direction/reason/meta/add_time`。
- 旧草案字段如 `meta_json`、`created_at`、`biz_type`、`biz_id`、`balance_before`、`balance_after` 与当前 writer 不匹配。
- PHP 幂等是 `scene + request_id`，当前 ledger draft 已用 `UNIQUE KEY uk_request_id (scene, request_id)`。

Operator warning:

- 执行旧 9 表草案会建错表，PHP 仍找不到 `eb_core_settlement_ledger`。
- 不要把 `meta` 改成 `meta_json`，不要把 `add_time` 改成 `created_at`，除非同步改 PHP writer。
- 当前 `LedgerService` 把 `$reason` 同时写入 `action` 和 `reason`，这是现状，不在 Phase 10 改业务代码。

### Config Switch Review

只读 config 分身结论：

- `core_settlement_checkin_shadow`
- `core_settlement_pet_feed_shadow`
- `core_settlement_game_farm_shadow`
- `core_settlement_game_mine_shadow`
- `core_settlement_daily_task_shadow`

All switches must default to `0`.

Important semantics:

- switch missing or empty => code reads default `0`
- `0` => no real audit ledger write
- `1` => CoreSettlement preview path may write real audit ledger through `LedgerService::writeRealLedger()`
- `1` is not pure dry-run
- inserting a missing switch with `value = '0'` does not auto-enable writes
- seed SQL must not overwrite an existing switch row
- if readonly checks find any switch already set to `1`, stop and do not proceed

Cache warning:

- `SystemConfigService` caches config reads for 30 days.
- After any later insert or update, operators must clear system config cache before testing.

## Append-Only Ledger Contract

`eb_core_settlement_ledger` is an audit ledger, not a mutable balance table.

Allowed future write pattern:

- `INSERT` a new audit row when a settlement event is first observed
- return the existing row for duplicate `scene + request_id`

Forbidden future write pattern:

- `UPDATE eb_core_settlement_ledger ...`
- `DELETE FROM eb_core_settlement_ledger ...`
- `TRUNCATE TABLE eb_core_settlement_ledger`
- `DROP TABLE eb_core_settlement_ledger`
- any data repair that rewrites `amount`, `direction`, `reason`, `meta`, or `add_time` on historical rows

If a bad ledger row appears later, remediation must be append-only:

- keep the original row
- add a compensating audit row in a later approved phase
- document the correction through `meta`

## Idempotency And Settlement Event ID

Current physical schema does not have a separate `settlement_event_id` column.

Current contract:

- `request_id` is the current settlement event id
- unique idempotency key is `scene + request_id`
- `LedgerService::writeRealLedger()` first queries `scene + request_id`
- duplicate settlement events must return the existing row, not insert another row

Current request id shapes:

- checkin: `checkin:{uid}:{date}`
- pet feeding: `feed:{uid}:{requestId}`
- game farm: `game_farm:{uid}:{requestHash}`
- game mine: `game_mine:{uid}:{requestHash}`
- daily task: `daily_task:{uid}:{requestHash}`

Future rename guidance:

- If operators want a visible `settlement_event_id`, treat it as an alias of current `request_id`.
- Do not add a new required column until PHP writer and asserts are changed in the same approved phase.
- Do not change the unique key from `scene + request_id` in Phase 10.

## No-Execution Current Writer Table Draft

This SQL is a draft only.

Do not execute in Phase 10.

```sql
-- CoreSettlement current writer ledger table draft.
-- DO NOT EXECUTE without explicit target env, DB backup, cache plan, and approval.

CREATE TABLE IF NOT EXISTS `eb_core_settlement_ledger` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `scene` varchar(64) NOT NULL DEFAULT '' COMMENT '场景：user_checkin / pet_feeding / game_farm / game_mine / daily_task',
  `action` varchar(64) NOT NULL DEFAULT '' COMMENT '当前 writer 写入 reason 值',
  `uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '用户ID',
  `request_id` varchar(128) NOT NULL DEFAULT '' COMMENT '幂等请求ID',
  `amount` int(11) NOT NULL DEFAULT 0 COMMENT '积分变动量绝对值',
  `direction` tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '方向：1=收入 0=支出',
  `reason` varchar(64) NOT NULL DEFAULT '' COMMENT '原因：checkin_integral / pet_feed_cost / game_* 等',
  `meta` text DEFAULT NULL COMMENT '额外元数据(JSON text)',
  `add_time` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_request_id` (`scene`, `request_id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_add_time` (`add_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='核心结算审计日志';
```

## No-Execution Switch Seed Draft

This SQL is a draft only.

Do not execute in Phase 10.

```sql
-- CoreSettlement shadow switches, default off.
-- DO NOT EXECUTE without explicit target env, DB backup, cache plan, and approval.

INSERT INTO `eb_system_config`
(`is_store`, `menu_name`, `type`, `input_type`, `config_tab_id`, `parameter`, `upload_type`,
 `required`, `width`, `high`, `value`, `info`, `desc`, `sort`, `status`)
SELECT 0, v.menu_name, 'radio', '', 0, '0=>关闭\n1=>开启', 0,
       '', 0, 0, '0', v.info, 'CoreSettlement Phase 10 switch; default off', v.sort, 1
FROM (
  SELECT 'core_settlement_checkin_shadow' AS menu_name, 'CoreSettlement 签到审计开关' AS info, 901 AS sort
  UNION ALL SELECT 'core_settlement_pet_feed_shadow', 'CoreSettlement 宠物喂养审计开关', 902
  UNION ALL SELECT 'core_settlement_game_farm_shadow', 'CoreSettlement 农场审计开关', 903
  UNION ALL SELECT 'core_settlement_game_mine_shadow', 'CoreSettlement 矿洞审计开关', 904
  UNION ALL SELECT 'core_settlement_daily_task_shadow', 'CoreSettlement 每日任务审计开关', 905
) AS v
WHERE NOT EXISTS (
  SELECT 1
  FROM `eb_system_config` AS c
  WHERE c.menu_name = v.menu_name
);
```

Reason for `WHERE NOT EXISTS`:

- `eb_system_config.menu_name` has a normal index, not a unique key.
- The draft must not create duplicate config rows.
- The draft must not overwrite existing switch values.

Reason for `value = '0'`:

- `SystemConfigServices::getConfigValue()` returns `json_decode(value, true)`.
- Stored value `0` decodes to integer `0`.
- All switches must remain off before table readiness and approval.

Auto-effect rule:

- This seed draft only inserts missing rows with `0`.
- It does not update existing rows.
- If a target environment already has a switch row with `1`, the correct action is to stop and report it.
- No Phase 10 SQL may set a switch to `1`.

## Required Readonly Verification Before Any Future Execution

Do not run write SQL until all readonly checks pass:

```sql
SELECT TABLE_NAME
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'eb_core_settlement_ledger';
```

```sql
SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT, COLUMN_KEY, EXTRA
FROM information_schema.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'eb_core_settlement_ledger'
ORDER BY ORDINAL_POSITION;
```

```sql
SELECT INDEX_NAME, NON_UNIQUE, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS columns_in_index
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME = 'eb_core_settlement_ledger'
GROUP BY INDEX_NAME, NON_UNIQUE
ORDER BY INDEX_NAME;
```

```sql
SELECT menu_name, value, status
FROM `eb_system_config`
WHERE menu_name IN (
  'core_settlement_checkin_shadow',
  'core_settlement_pet_feed_shadow',
  'core_settlement_game_farm_shadow',
  'core_settlement_game_mine_shadow',
  'core_settlement_daily_task_shadow'
)
ORDER BY menu_name;
```

Pass criteria:

- `eb_core_settlement_ledger` exists.
- The 9 writer columns exist: `scene/action/uid/request_id/amount/direction/reason/meta/add_time`.
- Unique key exists on `scene,request_id`.
- All 5 switch rows exist.
- All 5 switch values are `0`.
- No existing switch value is `1`.
- No planned SQL contains ledger `UPDATE`, `DELETE`, `TRUNCATE`, or `DROP`.

## Future Execution Gate

Phase 10 does not execute SQL.

A later execution phase requires:

1. Explicit target environment.
2. Confirmed DB backup path.
3. Confirmed rollback path.
4. Confirmed config cache clear command or admin action.
5. Readonly verification result pasted into handoff.
6. One switch opened at a time.
7. Immediate rollback if error appears in CoreSettlement real ledger audit path.

Rollback draft:

```sql
UPDATE `eb_system_config`
SET `value` = '0'
WHERE `menu_name` = '<one_core_settlement_switch>';
```

Rollback is config-only. Do not modify or delete ledger history during rollback.

After rollback:

- clear config cache
- re-read switch value
- confirm related business path still works through legacy logic

## Files Updated In This Phase

- `docs/backend-master/CoreSettlement_SQL_Draft.sql`
  - added Phase 10 warning that it is legacy broad draft only
- `docs/backend-master/CoreSettlement_Phase10_NoExecution_Migration_Readiness_2026-05-18.md`
  - added current writer table draft, switch seed draft, append-only ledger contract, settlement event id contract, verification gate, rollback notes

## Forbidden Areas

Do not touch without explicit approval:

- `backend_src/app/controller/api/v1/manghe/MangheController.php`
- payment
- order
- real inventory deduction
- SQL execution
- migration execution
- production DB
- server `.env`
- `game/*`
- `mobile-app/*`
- `mobile-app-v3/*`
- unrelated dirty worktree changes

## Next Task

Phase 11 should be manual target-env readiness collection.

Recommended next step:

1. Choose target environment.
2. Confirm DB backup path.
3. Run readonly checks only if explicitly approved.
4. Paste check result into a new Phase 11 handoff.
5. Keep all switches off until explicit execution approval.

## NEXT WINDOW HANDOFF PACKAGE

- Role: Backend Master Controller
- Phase: Phase 11 target-env readonly readiness collection
- Completed: Phase 10 no-execution migration readiness package
- Key Findings: current PHP writer needs `eb_core_settlement_ledger`; legacy broad draft is not execution plan; switch seed defaults must be `0`
- Key Files: this file, `docs/backend-master/CoreSettlement_SQL_Draft.sql`, `backend_src/deploy/sql/checkin_core_settlement_ledger.sql`, `backend_src/app/services/core/LedgerService.php`
- Dirty Worktree Notes: unrelated game/mobile/v3/docs deletions remain; do not stage broad changes
- Forbidden Areas: payment/order/Manghe/SQL execution/migration/prod DB/game/mobile/v3
- Next Step: collect target-env readonly readiness only after explicit approval
- Validation: docs-only diff check plus existing PHP asserts
- Risks: running old broad SQL creates wrong tables; setting switch to `1` writes real audit ledger, not pure dry-run; ledger history must stay append-only
