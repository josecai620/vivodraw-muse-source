#!/usr/bin/env bash
# 修复 nginx 使 /admin 和 /admin/ 能正常访问（解决 403 directory index forbidden）
# 用法：bash deploy/fix_nginx_admin.sh 186.241.72.176
set -euo pipefail

SERVER="${1:-186.241.72.176}"
SSH="ssh -p 22 root@${SERVER}"

echo "==> 在服务器上添加 /admin 专用 location 块..."

$SSH bash -s << 'REMOTE'
for f in /etc/nginx/sites-enabled/default /etc/nginx/sites-enabled/vivodraw.com.conf; do
  [ -f "$f" ] || continue
  if grep -q "location = /admin {" "$f"; then
    echo "  $f 已有 admin 配置，跳过"
  else
    # 在 "location / {" 之前插入
    perl -i -0pe 's/(\s+)(location \/ \{)/
    location = \/admin {\n        return 301 \$scheme:\/\/\$host\/admin\/;\n    }\n    location ^~ \/admin\/ {\n        try_files \$uri \$uri\/ \/admin\/index.html;\n    }\n\n    $1$2/s' "$f"
    echo "  已修改 $f"
  fi
done
REMOTE

echo "==> 检查 nginx 配置..."
$SSH 'nginx -t'

echo "==> 重载 nginx..."
$SSH 'systemctl reload nginx'

echo ""
echo "✅ 完成。请访问 http://${SERVER}/admin 或 https://vivodraw.com/admin 验证"
