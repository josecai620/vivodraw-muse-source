# -*- coding: utf-8 -*-
"""固定目标的客服配置写入器；默认只报告计划，不读取 .env 或标准输入。"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
import re
import secrets
import stat
import sys
from pathlib import Path


TARGET_TEXT = "/opt/crmeb-prod/backend_src/.env"
TARGET = Path(TARGET_TEXT)
OWNED_KEYS = ("enabled", "ai_enabled", "api_key", "allowed_uids", "daily_calls")
MAX_FILE_BYTES = 1024 * 1024
# 成本保险：全站每日模型调用上限的硬顶，防止误配置造成账单失控（正常运营远达不到）。
MAX_DAILY_CALLS = 100000


class ConfigError(Exception):
    def __init__(self, stage: str):
        # 异常只携带固定阶段名，不携带 .env、输入或底层异常原文。
        super().__init__(stage)
        self.stage = stage


def validate_payload(payload: object) -> dict:
    names = {"enabled", "ai_enabled", "api_key", "allowed_uid", "daily_calls"}
    if not isinstance(payload, dict) or set(payload) != names:
        raise ConfigError("input")
    if any(type(payload[name]) is not int or payload[name] not in (0, 1) for name in ("enabled", "ai_enabled")):
        raise ConfigError("input")
    if payload["ai_enabled"] > payload["enabled"]:
        raise ConfigError("input")
    if type(payload["allowed_uid"]) is not int or not 0 < payload["allowed_uid"] <= 4294967295:
        raise ConfigError("input")
    # 运营额度可调；保留区间校验与上限，避免误填天文数字导致账单失控。
    if type(payload["daily_calls"]) is not int or not 1 <= payload["daily_calls"] <= MAX_DAILY_CALLS:
        raise ConfigError("input")
    if not isinstance(payload["api_key"], str) or not re.fullmatch(r"[A-Za-z0-9._-]{12,512}", payload["api_key"]):
        raise ConfigError("input")
    return {"enabled": str(payload["enabled"]), "ai_enabled": str(payload["ai_enabled"]),
            "api_key": '"' + payload["api_key"] + '"', "allowed_uids": '"' + str(payload["allowed_uid"]) + '"',
            "daily_calls": str(payload["daily_calls"])}


def _suffix(value: str) -> str:
    quote = None
    escaped = False
    for index, char in enumerate(value):
        if escaped:
            escaped = False
            continue
        if quote and char == "\\":
            escaped = True
        elif quote and char == quote:
            quote = None
        elif not quote and char in "\"'":
            quote = char
        elif not quote and char in ";#":
            prefix = value[:index]
            return prefix[len(prefix.rstrip(" \t")):] + value[index:]
    if quote or escaped:
        raise ConfigError("parse")  # 不改写多行引号配置，避免误认其中的节名。
    return value[len(value.rstrip(" \t")):]


def rewrite_env(original: bytes, payload: dict) -> bytes:
    values = validate_payload(payload)
    if len(original) > MAX_FILE_BYTES or b"\0" in original:
        raise ConfigError("parse")
    bom = b"\xef\xbb\xbf" if original.startswith(b"\xef\xbb\xbf") else b""
    try:
        text = original[len(bom):].decode("utf-8", errors="strict")
    except UnicodeError:
        raise ConfigError("parse") from None
    lines = text.splitlines(keepends=True)
    newline = "\r\n" if "\r\n" in text else "\n"
    section = None
    support_start = None
    support_end = len(lines)
    found = set()
    for index, line in enumerate(lines):
        body = line.rstrip("\r\n")
        ending = line[len(body):]
        stripped = body.lstrip(" \t")
        if not stripped or stripped.startswith((";", "#")):
            continue
        if stripped.startswith("["):
            match = re.fullmatch(r"[ \t]*\[([A-Za-z_][A-Za-z0-9_.-]*)\][ \t]*(?:[;#].*)?", body)
            if not match:
                raise ConfigError("parse")
            new_section = match.group(1).casefold()
            if section == "support":
                support_end = index
            if new_section == "support":
                if support_start is not None:
                    raise ConfigError("duplicate")
                support_start = index
            section = new_section
            continue
        match = re.fullmatch(r"([ \t]*)([A-Za-z_][A-Za-z0-9_.-]*)([ \t]*=[ \t]*)(.*)", body)
        if not match:
            # 无法辨认的配置行可能改变 INI 语义，保守拒绝整次写入。
            raise ConfigError("parse")
        name = match.group(2).casefold()
        trailing = _suffix(match.group(4))
        if section is None and name in {"support_" + key for key in OWNED_KEYS} | {"support." + key for key in OWNED_KEYS}:
            raise ConfigError("duplicate")
        if section == "support" and name in OWNED_KEYS:
            if name in found:
                raise ConfigError("duplicate")
            found.add(name)
            lines[index] = match.group(1) + match.group(2) + match.group(3) + values[name] + trailing + ending
    missing = [name for name in OWNED_KEYS if name not in found]
    if support_start is None:
        result = "".join(lines)
        if result and not result.endswith(("\n", "\r")):
            result += newline
        result += "[SUPPORT]" + newline
        result += "".join(name.upper() + " = " + values[name] + newline for name in OWNED_KEYS)
    else:
        prefix = "".join(lines[:support_end])
        if missing and prefix and not prefix.endswith(("\n", "\r")):
            prefix += newline
        result = prefix + "".join(name.upper() + " = " + values[name] + newline for name in missing) + "".join(lines[support_end:])
    return bom + result.encode("utf-8")


def _plain_path(path: Path) -> None:
    for item in (path, *path.parents):
        try:
            info = item.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
            raise ConfigError("path")


def _open(path: Path, flags: int, mode: int = 0o600) -> int:
    _plain_path(path)
    return os.open(path, flags | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0), mode)


def _identity(info: os.stat_result) -> tuple:
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns,
            info.st_uid, info.st_gid, stat.S_IMODE(info.st_mode))


def _snapshot(path: Path) -> tuple[bytes, os.stat_result]:
    descriptor = _open(path, os.O_RDONLY)
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_size > MAX_FILE_BYTES:
            raise ConfigError("path")
        content = stream.read(MAX_FILE_BYTES + 1)
        after = os.fstat(stream.fileno())
        if len(content) > MAX_FILE_BYTES or _identity(before) != _identity(after):
            raise ConfigError("snapshot")
    return content, after


def _assert_unchanged(path: Path, expected: bytes, info: os.stat_result) -> None:
    content, current = _snapshot(path)
    if _identity(info) != _identity(current) or hashlib.sha256(content).digest() != hashlib.sha256(expected).digest():
        raise ConfigError("compare_and_swap")


@contextlib.contextmanager
def _locked(path: Path):
    descriptor = _open(path, os.O_CREAT | os.O_RDWR)
    stream = os.fdopen(descriptor, "r+b")
    locked = False
    try:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ConfigError("lock")
        try:
            if os.name == "posix":
                if info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o600:
                    raise ConfigError("lock")
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            else:
                # 仅供 Windows 临时目录离线测试；生产 CLI 只接受 Linux/POSIX。
                import msvcrt
                if info.st_size == 0:
                    stream.write(b"\0")
                    stream.flush()
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            raise ConfigError("lock") from None
        locked = True
        yield
    finally:
        if locked:
            if os.name == "posix":
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
            else:
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        stream.close()


def _sync_directory(path: Path) -> None:
    if os.name == "posix":
        descriptor = _open(path, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)


def _private_backup_directory(parent: Path) -> Path:
    directory = parent / ".support-config-backups"
    _plain_path(directory)
    try:
        directory.mkdir(mode=0o700)
    except FileExistsError:
        pass
    info = directory.lstat()
    if not stat.S_ISDIR(info.st_mode):
        raise ConfigError("backup")
    if os.name == "posix" and (info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o700):
        raise ConfigError("backup")
    return directory


def _write_preserving_metadata(path: Path, content: bytes, info: os.stat_result) -> None:
    descriptor = _open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(content)
        stream.flush()
        if os.name == "posix":
            os.fchown(stream.fileno(), info.st_uid, info.st_gid)
            os.fchmod(stream.fileno(), stat.S_IMODE(info.st_mode))
        else:
            os.chmod(path, stat.S_IMODE(info.st_mode))
        os.fsync(stream.fileno())


def configure(target: Path, payload: dict, *, apply: bool = False, expected_sha256: str | None = None,
              state: dict | None = None) -> dict:
    """内部函数允许离线测试注入临时目标；CLI 从不接受目标路径参数。"""
    state = state if state is not None else {}
    state.update(stage="input", applied=False)
    validate_payload(payload)
    if expected_sha256 is not None and not re.fullmatch(r"[0-9a-fA-F]{64}", expected_sha256):
        raise ConfigError("input")
    state["stage"] = "snapshot"
    if not apply:
        original, _ = _snapshot(target)
        planned = rewrite_env(original, payload)
        return {"ok": True, "mode": "dry_run", "applied": False, "changed": planned != original,
                "before_sha256": hashlib.sha256(original).hexdigest(), "after_sha256": hashlib.sha256(planned).hexdigest()}
    state["stage"] = "lock"
    with _locked(target.parent / ".support-config.lock"):
        state["stage"] = "snapshot"
        original, info = _snapshot(target)
        before_hash = hashlib.sha256(original).hexdigest()
        if expected_sha256 is not None and before_hash != expected_sha256.lower():
            raise ConfigError("compare_and_swap")
        state["stage"] = "parse"
        replacement = rewrite_env(original, payload)
        after_hash = hashlib.sha256(replacement).hexdigest()
        result = {"ok": True, "mode": "apply", "applied": False, "changed": replacement != original,
                  "before_sha256": before_hash, "after_sha256": after_hash, "backup": None,
                  "enabled": payload["enabled"], "ai_enabled": payload["ai_enabled"],
                  "allowed_uid": payload["allowed_uid"], "daily_calls": payload["daily_calls"]}
        if replacement == original:
            _assert_unchanged(target, original, info)
            return result
        state["stage"] = "backup"
        directory = _private_backup_directory(target.parent)
        identifier = secrets.token_hex(16)
        backup = directory / ("env-" + identifier + ".bak")
        temporary = directory / ("pending-" + identifier)
        _write_preserving_metadata(backup, original, info)
        backup_content, backup_info = _snapshot(backup)
        if backup_content != original or (backup_info.st_uid, backup_info.st_gid, stat.S_IMODE(backup_info.st_mode)) != (info.st_uid, info.st_gid, stat.S_IMODE(info.st_mode)):
            raise ConfigError("backup")
        result["backup"] = backup.name
        state["backup"] = backup.name
        _sync_directory(directory)
        try:
            state["stage"] = "prepare"
            _write_preserving_metadata(temporary, replacement, info)
            if _snapshot(temporary)[0] != replacement:
                raise ConfigError("prepare")
            state["stage"] = "compare_and_swap"
            _assert_unchanged(target, original, info)
            os.replace(temporary, target)
            state["applied"] = True
            result["applied"] = True
            state["stage"] = "verify"
            _sync_directory(target.parent)
            actual, actual_info = _snapshot(target)
            if hashlib.sha256(actual).hexdigest() != after_hash or (actual_info.st_uid, actual_info.st_gid, stat.S_IMODE(actual_info.st_mode)) != (info.st_uid, info.st_gid, stat.S_IMODE(info.st_mode)):
                raise ConfigError("verify")
            return result
        finally:
            # 只删除本次独占创建的临时文件；备份永远保留，不自动覆盖后续他人修改。
            if temporary.exists():
                temporary.unlink()


class _Arguments(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise ConfigError("arguments")


def _unique_object(pairs: list) -> dict:
    result = {}
    for name, value in pairs:
        if name in result:
            raise ConfigError("input")
        result[name] = value
    return result


def main() -> int:
    state = {"stage": "arguments", "applied": False}
    try:
        parser = _Arguments(description=__doc__)
        parser.add_argument("--apply", action="store_true")
        parser.add_argument("--expected-sha256")
        args = parser.parse_args()
        if not args.apply:
            print(json.dumps({"ok": True, "mode": "dry_run", "applied": False, "target": TARGET_TEXT,
                              "keys": OWNED_KEYS, "stdin_read": False, "env_read": False, "network_requests": 0}))
            return 0
        if os.name != "posix":
            raise ConfigError("platform")
        state["stage"] = "input"
        raw = sys.stdin.buffer.read(8193)
        if len(raw) > 8192:
            raise ConfigError("input")
        payload = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object)
        result = configure(TARGET, payload, apply=True, expected_sha256=args.expected_sha256, state=state)
        print(json.dumps(result, separators=(",", ":")))
        return 0
    except Exception as error:
        stage = error.stage if isinstance(error, ConfigError) else state["stage"]
        print(json.dumps({"ok": False, "stage": stage, "applied": state["applied"], "backup": state.get("backup"),
                          "automatic_retry": False}, separators=(",", ":")))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
