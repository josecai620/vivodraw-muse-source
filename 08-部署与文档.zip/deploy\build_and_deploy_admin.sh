#!/usr/bin/env bash
# 在服务器上构建后台前端并部署到 public/admin
# 用法：在服务器上执行: bash /opt/crmeb-prod/deploy/build_and_deploy_admin.sh
# 或从本机执行: ssh root@186.241.72.176 "bash /opt/crmeb-prod/deploy/build_and_deploy_admin.sh"
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/opt/crmeb-prod}"
ADMIN_SRC="${PROJECT_DIR}/backend_src/view/admin"
PUBLIC_DIR="${PROJECT_DIR}/backend_src/public"
ADMIN_PUBLIC="${PUBLIC_DIR}/admin"

echo "==> 1. 进入后台前端目录: ${ADMIN_SRC}"
cd "${ADMIN_SRC}"

echo "==> 2. 检查 Node.js"
if ! command -v node >/dev/null 2>&1; then
  echo "错误: 未找到 Node.js，请先安装: apt install -y nodejs"
  exit 1
fi
node -v && npm -v

echo "==> 3. 安装依赖（若无 node_modules）"
if [[ ! -d node_modules ]] || [[ ! -f node_modules/.package-lock.json ]]; then
  rm -rf node_modules package-lock.json 2>/dev/null || true
  npm install --registry=https://registry.npmmirror.com --legacy-peer-deps
else
  echo "node_modules 已存在，跳过 npm install"
fi

echo "==> 4. 构建生产版本"
# Vue CLI + stylus 深嵌套需要大栈；默认栈会 RangeError (见 productAdd/index.vue 3500+ 行样式)
# --stack-size 只能通过 node 直跑 bin，不能放 NODE_OPTIONS
export NODE_OPTIONS=--openssl-legacy-provider
node --stack-size=16000 ./node_modules/.bin/vue-cli-service build --mode=production

echo "==> 5. 部署到 public/admin"
if [[ ! -d dist ]] || [[ ! -f dist/index.html ]]; then
  echo "错误: dist 目录或 index.html 不存在，构建可能失败"
  exit 1
fi

mkdir -p "${ADMIN_PUBLIC}"
rsync -av --delete dist/ "${ADMIN_PUBLIC}/"

echo "==> 6. 完成"
echo "后台已更新，请访问 http://<服务器IP>/admin/ 验证"
