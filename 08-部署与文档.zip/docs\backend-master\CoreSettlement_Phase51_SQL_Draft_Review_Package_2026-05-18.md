# CoreSettlement Phase51 SQL Draft Review Package 2026-05-18

## Current Task

Phase51 prepares the SQL draft review package for Point Gateway tables.

Review package only.
No deploy SQL file was created.
No SQL was executed.
No migration was run.
No production database connection was opened.
No deployment was executed.
No write path was enabled.

## Source Inputs

```text
Phase46 final AI log table name: eb_core_point_gateway_ai_operation_log
Phase50 readonly table check: target tables do not exist
Phase47 deploy candidate path: deploy/core_point_gateway_tables_approval_required.sql
```

The SQL below is for review only.
Do not copy to `deploy/` or execute without explicit approval.

## SQL Draft For Review

```sql
CREATE TABLE IF NOT EXISTS `eb_core_point_transaction` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `scene` VARCHAR(64) NOT NULL DEFAULT '',
  `action` VARCHAR(32) NOT NULL DEFAULT '',
  `request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `target_request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `amount` INT NOT NULL DEFAULT 0,
  `direction` TINYINT NOT NULL DEFAULT 0,
  `status` VARCHAR(24) NOT NULL DEFAULT 'success',
  `error_code` VARCHAR(64) NOT NULL DEFAULT '',
  `source_module` VARCHAR(64) NOT NULL DEFAULT '',
  `biz_type` VARCHAR(64) NOT NULL DEFAULT '',
  `biz_id` VARCHAR(96) NOT NULL DEFAULT '',
  `operator_type` VARCHAR(32) NOT NULL DEFAULT '',
  `operator_id` VARCHAR(64) NOT NULL DEFAULT '',
  `legacy_user_bill_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `meta_json` TEXT DEFAULT NULL,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_scene_request` (`scene`, `request_id`),
  KEY `idx_uid_time` (`uid`, `created_at`),
  KEY `idx_status_time` (`status`, `created_at`),
  KEY `idx_target` (`target_request_id`),
  KEY `idx_source_biz` (`source_module`, `biz_type`, `biz_id`),
  KEY `idx_legacy_bill` (`legacy_user_bill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway canonical transaction ledger';

CREATE TABLE IF NOT EXISTS `eb_core_point_freeze` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `scene` VARCHAR(64) NOT NULL DEFAULT '',
  `freeze_request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `amount` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` VARCHAR(24) NOT NULL DEFAULT 'frozen',
  `expire_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_freeze_request` (`scene`, `freeze_request_id`),
  KEY `idx_uid_status` (`uid`, `status`),
  KEY `idx_expire` (`status`, `expire_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway frozen point records';

CREATE TABLE IF NOT EXISTS `eb_core_point_rollback_request` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `rollback_request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `target_request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `amount` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` VARCHAR(24) NOT NULL DEFAULT 'draft',
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_rollback_request` (`rollback_request_id`),
  UNIQUE KEY `uk_target_once` (`target_request_id`),
  KEY `idx_uid_status` (`uid`, `status`),
  KEY `idx_status_time` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway rollback approval requests';

CREATE TABLE IF NOT EXISTS `eb_core_point_expiry_batch` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `expire_batch` VARCHAR(96) NOT NULL DEFAULT '',
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `source_request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `amount` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` VARCHAR(24) NOT NULL DEFAULT 'pending',
  `expire_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_batch_source` (`expire_batch`, `uid`, `source_request_id`),
  KEY `idx_uid_status` (`uid`, `status`),
  KEY `idx_expire` (`status`, `expire_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway expiry batch items';

CREATE TABLE IF NOT EXISTS `eb_core_point_gateway_ai_operation_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `proposal_no` VARCHAR(96) NOT NULL DEFAULT '',
  `approval_request_id` VARCHAR(96) NOT NULL DEFAULT '',
  `operation` VARCHAR(64) NOT NULL DEFAULT '',
  `scene` VARCHAR(64) NOT NULL DEFAULT '',
  `request_id` VARCHAR(160) NOT NULL DEFAULT '',
  `target_table` VARCHAR(64) NOT NULL DEFAULT '',
  `target_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `decision` VARCHAR(24) NOT NULL DEFAULT 'suggested',
  `status` VARCHAR(32) NOT NULL DEFAULT 'suggested',
  `risk_level` VARCHAR(24) NOT NULL DEFAULT 'low',
  `summary` VARCHAR(255) NOT NULL DEFAULT '',
  `payload_hash` VARCHAR(64) NOT NULL DEFAULT '',
  `payload_json` TEXT DEFAULT NULL,
  `evidence_json` TEXT DEFAULT NULL,
  `policy_version` VARCHAR(32) NOT NULL DEFAULT '',
  `created_by_type` VARCHAR(32) NOT NULL DEFAULT '',
  `created_by_id` VARCHAR(64) NOT NULL DEFAULT '',
  `approved_by` INT UNSIGNED NOT NULL DEFAULT 0,
  `approved_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `expires_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `updated_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_proposal_no` (`proposal_no`),
  KEY `idx_target` (`target_table`, `target_id`),
  KEY `idx_uid_status` (`uid`, `status`),
  KEY `idx_operation_decision` (`operation`, `decision`),
  KEY `idx_approval_request` (`approval_request_id`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway AI operation log';

CREATE TABLE IF NOT EXISTS `eb_core_point_gateway_approval_audit` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `approval_request_id` VARCHAR(96) NOT NULL DEFAULT '',
  `source_log_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `operation` VARCHAR(64) NOT NULL DEFAULT '',
  `target_table` VARCHAR(64) NOT NULL DEFAULT '',
  `target_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `status` VARCHAR(32) NOT NULL DEFAULT 'pending_review',
  `risk_level` VARCHAR(24) NOT NULL DEFAULT 'low',
  `requested_by_type` VARCHAR(32) NOT NULL DEFAULT '',
  `requested_by_id` VARCHAR(64) NOT NULL DEFAULT '',
  `reviewed_by_admin_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `reviewed_by_admin_name` VARCHAR(64) NOT NULL DEFAULT '',
  `review_note` VARCHAR(255) NOT NULL DEFAULT '',
  `evidence_hash` VARCHAR(64) NOT NULL DEFAULT '',
  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `reviewed_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `expired_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_approval_request` (`approval_request_id`),
  KEY `idx_status_time` (`status`, `created_at`),
  KEY `idx_uid_status` (`uid`, `status`),
  KEY `idx_target` (`target_table`, `target_id`),
  KEY `idx_source_log` (`source_log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Point Gateway approval audit';
```

## Explicit Non-Inclusions

```text
no eb_core_point_ai_operation_log table
no INSERT
no UPDATE
no DELETE
no DROP
no TRUNCATE
no ALTER
no route/admin.php change
no DbPointTransactionStore enablement
```

## Review Questions Before Deploy SQL Creation

```text
1. Confirm `payload_json` and `evidence_json` stay TEXT for current MySQL compatibility.
2. Confirm `source_module`, `biz_type`, `biz_id`, and `legacy_user_bill_id` are acceptable in transaction ledger.
3. Confirm no compatibility alias for `eb_core_point_ai_operation_log` is needed.
4. Confirm deploy SQL file path before any file is created.
5. Confirm execution approval remains separate from file creation approval.
```

## Guards

```text
deploy_sql_created: false
sql_executed: false
migration_run: false
production_connection_opened: false
database_writes: false
deployment_executed: false
db_store_enabled: false
```

## Validation

```text
point_gateway_sql_draft_review_package_assert
point_gateway_sql_draft_package_boundary_assert
core_settlement_backend_package_assert
```
