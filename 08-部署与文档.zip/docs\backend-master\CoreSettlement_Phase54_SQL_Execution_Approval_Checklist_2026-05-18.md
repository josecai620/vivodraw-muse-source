# CoreSettlement Phase54 SQL Execution Approval Checklist 2026-05-18

## Current Task

Phase54 prepares the explicit execution approval checklist for the existing Point Gateway table SQL file.

Checklist only.
No SQL was executed.
No migration was run.
No production database connection was opened.
No deployment was executed.
No write path was enabled.
No SQL file content was changed.

## Target SQL File

```text
deploy/core_point_gateway_tables_approval_required.sql
```

## Target Environment

```text
production database target: not approved in Phase54
approved executor: not assigned in Phase54
approved maintenance window: not assigned in Phase54
rollback owner: not assigned in Phase54
```

## Required Explicit Approval Text

Execution must not proceed unless the user provides a separate approval message after reviewing this checklist.

The minimum acceptable approval must include:

```text
I approve executing deploy/core_point_gateway_tables_approval_required.sql on the production database.
I understand this creates six Point Gateway tables.
I approve a pre-execution backup/restore confirmation.
I approve stopping on first SQL error with no automatic retry.
I do not approve enabling DbPointTransactionStore in the same step.
I do not approve route exposure or production switches in the same step.
```

Any shorter approval is not enough to run SQL.
Approval to create this checklist is not approval to execute SQL.
Approval to execute table creation is not approval to enable production writes.

## Pre-Execution Gates

```text
1. Confirm current branch and commit hash.
2. Confirm working tree changes are unrelated and will not be staged.
3. Re-run readonly table existence check against information_schema.tables.
4. Confirm all six target tables are still absent.
5. Confirm legacy draft table eb_core_point_ai_operation_log is still absent or intentionally ignored.
6. Confirm backup exists and restore command/path is known.
7. Confirm MySQL target database name before execution.
8. Confirm SQL file checksum before execution.
9. Confirm SQL file still contains exactly six CREATE TABLE IF NOT EXISTS statements.
10. Confirm SQL file contains no INSERT/UPDATE/DELETE/DROP/TRUNCATE/ALTER/RENAME.
11. Confirm no route/admin.php change is included.
12. Confirm DbPointTransactionStore remains disabled.
13. Confirm all production switches remain default 0.
14. Confirm command output will redact credentials.
15. Confirm operator will stop on first error.
```

## Exact SQL Safety Contract

```text
allowed SQL category: CREATE TABLE IF NOT EXISTS only
allowed table count: 6
allowed target tables:
  eb_core_point_transaction
  eb_core_point_freeze
  eb_core_point_rollback_request
  eb_core_point_expiry_batch
  eb_core_point_gateway_ai_operation_log
  eb_core_point_gateway_approval_audit
forbidden legacy table: eb_core_point_ai_operation_log
forbidden write SQL: INSERT, UPDATE, DELETE
forbidden destructive SQL: DROP, TRUNCATE, ALTER, RENAME
forbidden programmable SQL: TRIGGER, PROCEDURE, EVENT
forbidden permission SQL: GRANT, REVOKE
```

## Execution Command Policy

```text
command may be prepared only after explicit approval
command must read credentials without printing them
command must target the confirmed production database
command must run the checked SQL file exactly as committed
command must capture success/failure output
command must not pipe generated SQL
command must not edit SQL inline
command must not retry after failure without a new review
```

## Post-Execution Gates

If execution is approved and later succeeds, the next phase must still remain verification only:

```text
1. Re-run information_schema.tables readonly check.
2. Confirm all six tables exist.
3. Confirm legacy draft table eb_core_point_ai_operation_log was not created.
4. Confirm tables are empty unless MySQL metadata reports otherwise.
5. Run Point Gateway asserts.
6. Do not enable DbPointTransactionStore.
7. Do not expose admin routes.
8. Do not enable production switches.
9. Write execution result doc with command summary and redacted output.
```

## Rollback Boundary

Rollback is not pre-approved in Phase54.

```text
rollback requires separate approval
rollback applies only to newly created empty Point Gateway tables
rollback must never touch eb_user
rollback must never touch user_bill
rollback must never touch order/payment/manghe tables
rollback must stop if any target table contains rows
```

## Phase54 Guards

```text
approval_checklist_created: true
sql_executed: false
migration_run: false
production_connection_opened: false
database_writes: false
deployment_executed: false
sql_file_changed: false
db_store_enabled: false
route_exposure: false
production_switch_enabled: false
rollback_preapproved: false
separate_execution_approval_required: true
```

## Validation

```text
point_gateway_sql_execution_approval_checklist_assert
point_gateway_deploy_sql_file_creation_assert
core_settlement_backend_package_assert
git diff --check -- deploy/core_point_gateway_tables_approval_required.sql docs/backend-master backend_src/scripts
```
