# Opus 4.6 Max 协作说明（Windows Cursor）

本文档面向在 **Windows Cursor** 中使用 **Opus 4.6 Max** 参与 eccomall 项目开发的 AI 与开发者。

> **首次参与必读**：先阅读 **[docs/项目交接-Opus主力开发说明.md](项目交接-Opus主力开发说明.md)**，该文档为项目完整交接说明。

---

## 一、项目概览

- **仓库**：https://github.com/josecai2023/eccomall
- **工作分支**：`assist/mobile-batch-01`
- **技术栈**：PHP 后端（ThinkPHP）、Vue2 后台、Expo 前台（React Native Web）

---

## 二、目录结构

```
eccomall/
├── backend_src/           # PHP 后端
│   ├── app/               # 控制器、服务、模型
│   ├── public/            # 入口、静态资源
│   └── view/
│       ├── admin/         # Vue2 后台管理
│       └── supplier/      # 供应商端
├── mobile-app/            # Expo 用户端前台
├── deploy/                # 部署与运维脚本
└── docs/                  # 文档
```

---

## 三、首次参与流程

1. **克隆代码**
   ```bash
   git clone https://github.com/josecai2023/eccomall.git
   cd eccomall
   git checkout assist/mobile-batch-01
   ```

2. **获取数据库**  
   见 [docs/数据库获取说明.md](数据库获取说明.md)。推荐执行：
   ```bash
   bash deploy/从服务器导出数据库.sh 8.166.115.27
   ```
   再导入到本地 MySQL。

3. **配置环境**  
   按 [docs/Windows开发环境搭建.md](Windows开发环境搭建.md) 配置 .env、Node、PHP 等。

---

## 四、开发约定（AI 助手必读）

1. **跨端/跨栈联调**：改动涉及 mobile-app、Vue2 后台、PHP 时，需保证前后端一致。
2. **部署**：
   - 只改双语文案：`bash deploy/同步双语到服务器public.sh`
   - 改 mobile-app：`bash deploy/构建并上传前台Expo.sh`
   - 改 Admin：`bash deploy/本机构建并上传后台前端.sh`
   - 只改 PHP：`bash deploy/update_online.sh 8.166.115.27`
3. **数据库**：表前缀 `eb_`，数据库名 `manghehoutai_qhe`。
4. **服务器**：8.166.115.27，项目路径 `/opt/crmeb-prod`。

---

## 五、常用脚本（Git Bash / WSL）

| 操作           | 命令 |
|----------------|------|
| 同步服务器代码 | `bash deploy/从服务器同步到本地.sh 8.166.115.27` |
| 导出服务器数据库 | `bash deploy/从服务器导出数据库.sh 8.166.115.27` |
| 发布 PHP 后端   | `bash deploy/update_online.sh 8.166.115.27` |
| 发布 Expo 前台  | `bash deploy/构建并上传前台Expo.sh` |
| 发布 Admin 后台 | `bash deploy/本机构建并上传后台前端.sh` |

---

## 六、与 Mac 侧协作

- Mac 侧：Cursor + 本助手
- Windows 侧：Cursor + Opus 4.6 Max
- 共同分支：`assist/mobile-batch-01`
- 协作方式：各自 `git pull` → 修改 → `git commit` → `git push`

复杂业务逻辑（Listener、开奖、数据迁移等）建议由 Opus 4.6 Max 负责设计与实现，本助手负责审查与收尾。
