# CoreSettlement Phase 15 Checkin Activation Attempt Report 2026-05-18

## Current Task

Phase 15 attempted one-switch activation for:

- `core_settlement_checkin_shadow`

Scope stayed narrow:

- no payment/order/inventory changes
- no Manghe changes
- no farm/mine/daily/pet switch activation
- no historical ledger update/delete/truncate/drop
- no server code deployment

## Safety Gate

Backup artifact from Phase 13 remains the restore gate:

- `/Users/joe/eccomall/db_backup/db_20260518_050233.sql.gz`
- `gzip -t`: passed in Phase 13
- compressed: `920809` bytes
- uncompressed: `6437960` bytes

## Runtime Readiness Check

Target runtime:

- host: `8.166.115.27`
- container: `crmeb-php-fpm`
- backend path: `/var/www/backend`
- PHP: `8.1.34`
- PHP redis extension: present
- ThinkPHP console: available

Readonly runtime class check:

```text
class_exists=app\services\core\CheckinSettlementService -> no
```

This means the production runtime does not currently contain the CoreSettlement checkin service class needed for safe app-path activation.

## Activation Attempt

The controlled script attempted:

1. read current `core_settlement_checkin_shadow`
2. set only `core_settlement_checkin_shadow = 1`
3. clear config cache through app runtime when possible
4. call `CheckinSettlementService::previewDailyCheckin(...)` twice with the same synthetic request id
5. verify exactly one append-only ledger row
6. verify duplicate idempotency
7. rollback switch on any failure

Synthetic request:

```text
uid=10001
date=phase15-20260518-051658
request_id=checkin:10001:phase15-20260518-051658
```

## Result

The attempt failed before any service call because the runtime class is missing:

```text
think\exception\ClassNotFoundException: class not exists: app\services\core\CheckinSettlementService
```

Automatic rollback executed.

Post-rollback verification:

```text
switch=0
ledger_count=0
class_exists=no
```

## Decision

Phase 15 is **NO-GO for runtime activation**.

Reason:

- production DB is ready
- production PHP runtime can run ThinkPHP and Redis-backed cache
- production backend code is not at the CoreSettlement service baseline

No switch remains enabled.

No ledger row was written.

No historical ledger data was modified.

## Local Baseline Validation

Local dry-run assertions still pass:

```text
core_settlement_dry_run_assert: passed, 20/20
checkin_core_settlement_shadow_assert: passed, 13/13
pet_feed_core_settlement_shadow_assert: passed, 17/17
```

## Risk

The next blocker is deployment readiness, not DB readiness.

Deploying backend code to production is a higher-risk step than opening the DB switch. It must be treated as a separate phase with:

- readonly diff between local committed backend code and `/var/www/backend`
- deploy plan
- rollback plan
- no DB mutation
- no switch activation during the deploy-readiness phase

## Forbidden Areas

Still forbidden without explicit approval:

- `backend_src/app/controller/api/v1/manghe/MangheController.php`
- payment
- order
- real inventory deduction
- ledger history mutation
- opening more than one switch
- deleting or rewriting ledger rows
- server `.env`
- `game/*`
- `mobile-app/*`
- `mobile-app-v3/*`
- unrelated dirty worktree changes

## Next Task

Phase 16 should be **target-runtime backend code readiness collection**:

1. compare local committed CoreSettlement backend files with production `/var/www/backend`
2. list exactly which classes are missing or stale
3. produce backend deploy/rollback plan
4. do not deploy yet
5. do not change DB
6. keep all CoreSettlement switches off
