# Next Window Handoff: Stripe Checkout

Date: 2026-06-10
Branch: `codex/pet-world-v2`
Current HEAD observed: `be48517c Localize pet world web shell`

## Current Goal

Continue Stripe payment integration for VivoDraw/Eccomall.

Owner intent:

- Do not wait for Stripe approval before coding.
- Platform is still in testing, so live payment testing is allowed when live keys exist.
- Keep implementation small. No Stripe Connect, no marketplace split settlement, no payment architecture circus.

## Done In This Window

Backend:

- Added Stripe as an order payment type in `backend_src/app/services/pay/PayServices.php`.
- Added order gateway switch mapping: `pay_stripe_open`.
- Added Stripe payment initiation through `backend_src/app/services/pay/OrderPayServices.php`.
- Added order gateway allow-check in `backend_src/app/services/order/StoreOrderServices.php`.
- Wired `payType=stripe` into:
  - `POST /api/order/create/:key`
  - `POST /api/order/pay`
- Wired Stripe webhook endpoint:
  - `POST /api/pay/notify/stripe`
- Added `backend_src/app/services/pay/StripePaymentServices.php`.
  - Creates Stripe Checkout Sessions with cURL.
  - Uses hosted Stripe checkout, not local card collection.
  - Verifies Stripe webhook signatures.
  - Marks paid orders through `StoreOrderSuccessServices::paySuccess`.
  - Supports both `sk_test_` and `sk_live_` by key prefix.

Frontend:

- Added checkout payment launcher in `mobile-app-v3/lib/api/checkout.ts`.
- Checkout page can call Stripe when there is:
  - live cart
  - checkout order key
  - synced address id
- Frontend Stripe button is disabled by default.
  - Enable it only with `EXPO_PUBLIC_ENABLE_STRIPE_CHECKOUT=1` or `true` after Stripe keys are ready.
- Backend still requires `pay_stripe_open=1` or `PAY_STRIPE_OPEN=1`.

Docs:

- Added/updated `docs/stripe-test-mode-payment-workflow.md`.
  - Name is legacy-ish, content now covers both test and live key flows.

## Important Current Behavior

Stripe mode:

- `STRIPE_SECRET_KEY=sk_test_xxx` -> Stripe test mode.
- `STRIPE_SECRET_KEY=sk_live_xxx` -> Stripe live mode.
- No extra `STRIPE_LIVE_ENABLED` gate remains.

Backend gateway:

- Must set `pay_stripe_open=1` in config or `PAY_STRIPE_OPEN=1` in env.
- If closed, backend returns `Stripe checkout is disabled`.

Webhook:

- Endpoint: `/api/pay/notify/stripe`
- Events handled:
  - `checkout.session.completed`
  - `payment_intent.succeeded`
- Required env/config:
  - `STRIPE_WEBHOOK_SECRET=whsec_xxx`

## Validation Already Run

Backend syntax:

- `php -l backend_src/app/services/pay/StripePaymentServices.php`
- `php -l backend_src/app/services/pay/PayServices.php`
- `php -l backend_src/app/services/pay/OrderPayServices.php`
- `php -l backend_src/app/services/order/StoreOrderServices.php`
- `php -l backend_src/app/controller/api/v1/order/StoreOrderController.php`
- `php -l backend_src/app/controller/api/v1/PayController.php`

Frontend:

- `npm run typecheck` in `mobile-app-v3`
- `npm run route:smoke` in `mobile-app-v3`
- `EXPO_PUBLIC_API_BASE_URL=http://8.166.115.27 npx expo export --platform web --output-dir .qa-export`

Latest quick re-check after final switch change:

- `npm run typecheck`
- `npm run route:smoke`

## Not Done

- Not deployed to server.
- No Stripe account or real Stripe key configured.
- No Stripe Dashboard webhook configured.
- No real payment end-to-end test run.
- No commit/push from this window.
- No production DB/config write.
- No PayPal integration yet.
- No Stripe refund flow yet.
- No procurement task auto-create after paid order verified.

## Dirty Worktree Warning

The repo is already heavily dirty from many unrelated areas:

- reward economy
- support/chat
- product uploads
- admin pages
- game files
- docs
- deployment scripts

Do not blindly commit everything. Scope commits by file list.

Payment-relevant files to inspect/stage if continuing:

- `backend_src/app/services/pay/StripePaymentServices.php`
- `backend_src/app/services/pay/PayServices.php`
- `backend_src/app/services/pay/OrderPayServices.php`
- `backend_src/app/services/order/StoreOrderServices.php`
- `backend_src/app/controller/api/v1/order/StoreOrderController.php`
- `backend_src/app/controller/api/v1/PayController.php`
- `backend_src/config/pay.php`
- `mobile-app-v3/lib/api/checkout.ts`
- `mobile-app-v3/app/checkout/index.tsx`
- `mobile-app-v3/constants/env.ts`
- `docs/stripe-test-mode-payment-workflow.md`
- `docs/next-window-handoff-stripe-checkout-2026-06-10.md`

Related frontend cleanup from immediately before payment work:

- `backend_src/app/controller/api/v1/store/StoreProductController.php`
- `mobile-app-v3/lib/api/catalog.ts`
- `mobile-app-v3/app/search.tsx`
- `mobile-app-v3/app/points/index.tsx`
- `mobile-app-v3/lib/i18n.ts`
- `mobile-app-v3/tools/mobile-visual-smoke.mjs`

## Recommended Next Steps

1. Verify the current diff carefully:

```bash
git status --short
git diff -- backend_src/app/services/pay/StripePaymentServices.php backend_src/app/services/pay/PayServices.php backend_src/app/services/pay/OrderPayServices.php backend_src/app/services/order/StoreOrderServices.php backend_src/app/controller/api/v1/order/StoreOrderController.php backend_src/app/controller/api/v1/PayController.php backend_src/config/pay.php mobile-app-v3/lib/api/checkout.ts mobile-app-v3/app/checkout/index.tsx mobile-app-v3/constants/env.ts docs/stripe-test-mode-payment-workflow.md
```

2. Run full local validation:

```bash
php -l backend_src/app/services/pay/StripePaymentServices.php
cd mobile-app-v3
npm run typecheck
npm run route:smoke
EXPO_PUBLIC_API_BASE_URL=http://8.166.115.27 npx expo export --platform web --output-dir .qa-export
```

3. Prepare test environment values:

```bash
STRIPE_SECRET_KEY=sk_test_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
STRIPE_CURRENCY=usd
PAY_STRIPE_OPEN=1
```

4. Run one test payment through Stripe Checkout.

5. Confirm webhook changes order state to paid.

6. Only after test proof, decide whether to deploy and run one low-value live payment.

## New Window Startup Instruction

Start in `/Users/joe/eccomall` on branch `codex/pet-world-v2`. Read `docs/next-window-handoff-stripe-checkout-2026-06-10.md` first. Continue Stripe checkout integration. Do not commit or deploy blindly because the worktree is dirty. First verify scoped diffs for the payment files, then run PHP lint and `mobile-app-v3` typecheck/route smoke. Next practical task: run Stripe test checkout end-to-end with `PAY_STRIPE_OPEN=1`, `STRIPE_SECRET_KEY`, and `STRIPE_WEBHOOK_SECRET`, then verify `/api/pay/notify/stripe` marks the order paid.
