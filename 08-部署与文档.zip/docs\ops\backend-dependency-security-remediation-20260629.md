# Backend Dependency Security Remediation - 2026-06-29

Scope: local dependency security triage for `backend_src`. No production SQL, migration, service restart, deployment, firewall change, or switch change was executed.

## Current status

- `composer audit --format=summary` previously reported 37 advisories across 8 packages; this is stale and no longer the controlling evidence.
- 2026-06-30 `composer audit --locked` reports 54 advisories across 11 packages, plus 2 abandoned packages. This is the current controlling lock-file evidence.
- Advisory concentration by package: `phpoffice/phpspreadsheet` 26, `guzzlehttp/guzzle` 7, `topthink/framework` 5, `guzzlehttp/psr7` 5, `symfony/http-foundation` 3, `symfony/process` 2, and one each in `firebase/php-jwt`, `league/flysystem`, `mtdowling/jmespath.php`, `nesbot/carbon`, `symfony/polyfill-intl-idn`.
- Abandoned packages: `guzzle/guzzle` should move to `guzzlehttp/guzzle`; `topthink/think-factory` has no suggested replacement.
- `composer audit --locked` exits non-zero, so dependency security is not launch-clean.
- `composer validate --strict` fails because `composer.lock` is not aligned with `composer.json`.
- `vendor/` does not fully match `composer.lock`; for example `symfony/http-foundation` is installed as `v5.4.3`, while `composer.lock --locked` reports `v3.4.28`.
- `composer.json` uses the Aliyun Composer mirror, which did not expose newer security versions during this audit. A temporary official Packagist dry-run showed newer versions such as `guzzlehttp/guzzle 7.12.x` and `phpoffice/phpspreadsheet 1.30.5/5.x`.
- 2026-06-30 targeted dependency dry-run still fails: current constraints pin vulnerable `firebase/php-jwt ^5`, `guzzlehttp/guzzle 6.5.5`, `topthink/framework 6.0.9`, and mirror/platform state blocks newer safe packages. Local CLI also lacks `ext-swoole`, so dependency remediation must run in a clean production-like PHP 8.1 platform.

## Evidence commands

```bash
cd backend_src
composer validate --strict
composer audit --format=summary
composer audit --locked
composer outdated --direct --strict --ignore-platform-req=php --ignore-platform-req=ext-swoole
composer show symfony/http-foundation
composer show symfony/http-foundation --locked
composer update --dry-run -W --no-scripts --ignore-platform-req=php --ignore-platform-req=ext-swoole
```

## Blockers

- `topthink/framework` is pinned to `6.0.9`; Composer blocks it because of security advisories. The highest available `6.0.x` line still carries at least one advisory, while moving to `8.x` conflicts with current ThinkPHP ecosystem packages and is a framework migration, not a patch.
- `guzzlehttp/guzzle` is pinned to `6.5.5`; safe `7.12.x` requires coordinated updates and official Packagist availability. Current mirror data is stale.
- `phpoffice/phpspreadsheet` is `1.13.0`; safer versions require a broader dependency update and PHP-platform validation.
- `firebase/php-jwt` is `5.0.0`; `composer audit --locked` includes a critical algorithm confusion advisory fixed by moving to the 6.x line.
- `symfony/http-foundation` lock/install drift makes the advisory picture ambiguous; normalize `composer.lock` before judging it fixed.
- Legacy packages previously identified for US-edition removal still constrain upgrades: `alipaysdk/easysdk`, `overtrue/wechat`, `overtrue/socialite`, `xiaodi/think-pullword`, and related Swoole/Guzzle packages.
- User password hashes are still MD5-compatible because `eb_user.pwd` is defined as `varchar(32)` in `backend_src/public/install/crmeb.sql`; moving to `password_hash()` requires an approved database field expansion and staged login migration, not a blind code-only change.

## Done in this run

- Added explicit Composer plugin policy:

```json
"allow-plugins": false
```

There are no `composer-plugin` packages in the current lock file, so disabling plugin execution reduces supply-chain risk without changing runtime code.
- 2026-06-30 local hardening added runtime mitigations around spreadsheet imports and remote image fetching: safe reader creation, extension/size/path checks, `LIBXML_NONET`, remote image MIME allowlist, and private/reserved IP URL rejection. These reduce exploitability but do not replace dependency upgrades.
- 2026-06-30 `mobile-app-v3` non-force `npm audit fix --omit=dev` updated `undici` from `6.26.0` to `6.27.0` and `js-yaml` from `3.14.2` to `3.15.0`. `npm audit --audit-level=high --omit=dev` now passes; remaining moderate Expo-chain advisories require a breaking Expo 56 upgrade.
- 2026-06-30 user password code now verifies both legacy MD5 and future `password_hash()` hashes. Strong hashes stay off until `deploy/user_password_hash_v2_approval_required_20260630.sql` is explicitly approved and applied.
- 2026-06-30 public `sms/pay/notify` now requires `sms_pay_notify_key` or `SMS_PAY_NOTIFY_KEY` and uses `hash_equals`; unauthenticated callback spam is rejected with 403.

## Approval-required fix path

1. Create a dedicated dependency remediation branch or clean worktree; do not mix with current dirty frontend/backend changes.
2. Switch Composer repository resolution to official Packagist for the update run, or confirm Aliyun mirror has synced required security releases.
3. First normalize `composer.lock` against `composer.json` under the production PHP 8.1 platform.
4. Remove or replace US-disabled legacy packages if still unused: Alipay, WeChat, Socialite, `xiaodi/think-pullword`, Swoole-only helpers.
5. Upgrade high-risk packages in a controlled batch:
   - `firebase/php-jwt`
   - `guzzlehttp/guzzle`
   - `guzzlehttp/psr7`
   - `phpoffice/phpspreadsheet`
   - `symfony/http-foundation`
   - ThinkPHP framework and companion packages
6. Run backend regression before any deploy:

```bash
cd backend_src
composer validate --strict
composer audit
php think route:list
php -l app/common.php
php -l crmeb/services/SpreadsheetExcelService.php
php -l crmeb/services/FileService.php
```

Production deployment, package install on server, or framework migration requires separate explicit approval.
