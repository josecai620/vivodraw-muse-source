# VivoDraw App Store Release Workflow - 2026-06-21

Latest verification: 2026-07-03.

## Scope

This workflow packages `mobile-app-v3` as the VivoDraw iOS and Android app. It does not modify production DNS, payments, inventory, ledgers, SQL, or server config.

## Current App Target

- App source: `mobile-app-v3/`
- App name: `VivoDraw`
- iOS bundle identifier: `com.vivodraw.app`
- Android application id: `com.vivodraw.app`
- Production API base: `https://vivodraw.com`
- Build system: Expo EAS
- EAS project id: `1f4b9e56-ab89-487a-be4e-d0b1d210d6b2`
- App icon: `mobile-app-v3/assets/app/icon.png`
- Android adaptive foreground: `mobile-app-v3/assets/app/adaptive-icon.png`
- Splash image: `mobile-app-v3/assets/app/splash-icon.png`
- In-app account deletion route: `/account/delete`
- Public deletion URL target: `https://vivodraw.com/account/delete`

## Current App-Readiness Evidence

Verified on 2026-07-03:

- `npm run typecheck` passes in `mobile-app-v3`.
- `npx expo config --type public` resolves VivoDraw app identity, bundle id, package id, app assets, Expo SDK 54, and EAS project id.
- `npx expo-doctor` passes all 18 checks.
- `https://vivodraw.com/` returns `200`.
- `https://vivodraw.com/api/category` with `X-Client: mobile-app` returns `status=200`.
- Required public pages return `200`: privacy, terms, shipping, returns, support, and account deletion.
- DNS now exposes MX, SPF, and DMARC records for `vivodraw.com`.
- Android preview APK build succeeded on 2026-07-03:
  - Build id: `089e345d-0206-4886-86eb-63be4a70eac2`
  - Profile: `preview`, distribution: `INTERNAL`, version: `1.0.0`, build: `1`
  - Install URL: `https://expo.dev/accounts/josecai/projects/vivodraw/builds/089e345d-0206-4886-86eb-63be4a70eac2`
  - APK artifact: `https://expo.dev/artifacts/eas/dgJe6FDQfxOTHDvEgE2iYxOnC3zalUYU_xwtPx9uU5g.apk`
- Android production AAB build succeeded on 2026-07-03:
  - Build id: `a54fa282-f654-49fe-bec8-0f386cf4aabd`
  - Profile: `production`, distribution: `STORE`, version: `1.0.0`, build: `2`
  - AAB artifact: `https://expo.dev/artifacts/eas/r284WZpcyEY5Nctojo_K3mnhT1661R7UxzwXXQklYvc.aab`
- iOS production build attempt reached EAS credential setup but stopped because the distribution certificate is not validated for non-interactive builds. Re-run in interactive mode with the Apple Developer account holder present.

## Hard Blockers Before Store Review

1. Re-run the public-domain and DNS checks immediately before submission. The 2026-07-03 check passes, but store review should not rely on old evidence.
2. Verify `support@vivodraw.com` can receive and send real mail, not only that MX/SPF/DMARC exist.
3. App account deletion must exist in-app and as a public web URL because VivoDraw supports account creation.
4. Privacy policy, terms, shipping, refund, support, and data deletion pages must be stable public URLs.
5. Blind box / randomized reward flows must disclose odds before purchase and avoid gambling-like cash redemption language.
6. Physical goods checkout can use Stripe/card handoff, but paid digital goods, sold points, or consumed in-app currency can trigger Apple/Google in-app billing rules.
7. Apple uploads after 2026-04-28 need to satisfy Apple's active SDK minimums. Verify the EAS iOS build image before submitting.
8. Google Play new app submissions must target the current required Android API level. Verify target SDK from the built AAB before submitting.
9. EAS build and submit still require owner Expo, Apple Developer, and Google Play account access.
10. iOS build and TestFlight distribution require interactive Apple credential validation before the first successful archive.

## Local Work Completed

- `app.json` defines app identity, iOS bundle ID, Android package ID, icon, splash, adaptive icon, and iOS export-compliance flag.
- `eas.json` defines preview and production profiles with `https://vivodraw.com` API base and write-risk switches kept closed.
- Runtime API fallback defaults to `https://vivodraw.com` when no build env is supplied, so native app builds do not silently fall back to a cleartext IP origin.
- `/account/delete` provides authenticated account deletion with explicit `DELETE` confirmation and clears the local session after success.
- Profile, Support, route registry, and Privacy agreement pages link to the account deletion flow.
- Store metadata draft lives in `docs/app-store-metadata-vivodraw-20260621.md`.

## Build Commands

```bash
cd /Users/joe/eccomall/mobile-app-v3
npm run typecheck
npx expo-doctor
npm run eas:build:preview:android
npm run eas:build:preview:ios
npm run eas:build:prod
```

## Submit Commands

```bash
cd /Users/joe/eccomall/mobile-app-v3
npm run eas:submit:prod
```

## Owner-Only Actions

- Expo/EAS project creation or linking, which writes the real `extra.eas.projectId`.
- Apple Developer Program enrollment and App Store Connect app creation.
- Google Play Console account setup and app creation.
- Bundle ID / package name reservation if the stores reject `com.vivodraw.app`.
- Certificates, signing credentials, and store account permissions.
- DNS, SPF, DKIM, DMARC, HTTPS, and provider-console changes.
- Production payment enablement.

## Store Metadata Checklist

- App name, subtitle, short description, full description.
- Category: shopping or lifestyle, final choice after review of blind box wording.
- App icon, adaptive icon, splash art, and screenshots.
- Privacy policy URL and data safety/privacy nutrition answers.
- Support URL and account deletion URL.
- Review credentials that bypass one-time verification.
- Age rating questionnaire with randomized rewards answered honestly.
- TestFlight / internal testing evidence before public review.

Draft copy and data-safety notes are in `docs/app-store-metadata-vivodraw-20260621.md`.

## Release Gate

Do not submit to Apple or Google until all checks pass:

```bash
cd /Users/joe/eccomall
bash deploy/ops/vivodraw_daily_ops_report.sh

cd /Users/joe/eccomall/mobile-app-v3
npm run typecheck
npx expo-doctor
```

For final artifacts, also inspect the built iOS archive / Android AAB metadata for app version, bundle id, package id, target SDK, permissions, and API base.

## Official References Checked 2026-06-21

- Expo EAS Submit: `https://docs.expo.dev/deploy/submit-to-app-stores/`
- Apple SDK minimum requirements: `https://developer.apple.com/news/upcoming-requirements/`
- Apple App Privacy fields: `https://developer.apple.com/help/app-store-connect/reference/app-information/app-privacy/`
- Google Play target API policy: `https://support.google.com/googleplay/android-developer/answer/17105854`
- Google Play Data safety: `https://support.google.com/googleplay/android-developer/answer/10787469`
- Google Play account deletion policy announcement: `https://support.google.com/googleplay/android-developer/announcements/13412212`
