# H5 构建并上传到服务器（一次到位）

当你需要让**线上网页**显示最新的前端（含双语）时，按下面做一次即可。

---

## 方式一：一键构建并上传（推荐，无需 HBuilderX）

在项目**根目录**执行：

```bash
bash deploy/构建并上传H5.sh
```

脚本会依次：1）在 `backend_src/view/uniapp` 下执行 `npm run build:h5` 生成 H5 包；2）将产物上传到服务器。按提示输入服务器密码即可。

**说明**：若本机 `npm run build:h5` 报错（如缺少 HBuilderX 相关依赖），可改用下方「方式二」在 HBuilderX 里发行，再由助手或你本机执行 `bash deploy/上传H5到服务器.sh` 完成上传。后续需要「发布 H5 / 部署到线上」时，可直接让助手执行构建并上传或仅上传。

---

## 方式二：在 HBuilderX 里发行 H5 再上传

1. **打开项目**  
   用 HBuilderX 打开目录：`backend_src/view/uniapp`（或从项目根打开该文件夹）。

2. **处理 AppID（若曾报错「appid 不存在」）**  
   - 打开 **manifest.json**，切到 **「基础配置」**。  
   - 在 **「应用标识(AppID)」** 后点 **「重新获取」**，用已登录的 DCloud 账号获取并保存。

3. **发行**  
   - 菜单 **发行 → 网站-PC Web或手机H5**。  
   - 在弹窗里点 **「发行」**，等编译完成（控制台无报错即可）。

4. **确认产出**  
   本机应出现目录：  
   `backend_src/view/uniapp/unpackage/dist/build/h5`  
   且其中有 `index.html`、`static/` 等。

---

## 二、上传到服务器

在项目**根目录**（`海外版crmeb框架`）下执行：

```bash
bash deploy/上传H5到服务器.sh
```

按提示输入服务器 root 密码（若已配置免密则直接完成）。脚本会把上一步的 H5 打包结果同步到服务器 `public/`。

---

## 三、验证

浏览器访问：

- http://8.166.115.27/
- 或 http://8.166.115.27/static/html/pc.html

应能看到最新前端与双语。

---

**说明**：当前 H5 已支持「运行时加载双语」（从 `/static/locale/*.json` 拉取）。因此：
- **第一次**或**改了非双语文案的前端代码**：按上面做一次发行 + 上传。
- **之后只改双语**：在项目根执行 `bash deploy/同步双语到服务器public.sh`，把最新 `locale/*.json` 同步到服务器 `public/static/locale/`，刷新网页即可，无需再发行。
