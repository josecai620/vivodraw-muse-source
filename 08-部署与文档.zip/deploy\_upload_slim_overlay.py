# -*- coding: utf-8 -*-
"""把 dist-root 的 index.html + _expo 叠到线上 current，再切 $v4rel。带 sha256 校验。"""
import hashlib
import json
import os
import subprocess
import tarfile
from datetime import datetime
from pathlib import Path


manifest_path = os.environ.get("RELEASE_MANIFEST")
if not manifest_path:
    raise SystemExit("refusing overlay upload: RELEASE_MANIFEST is required")
manifest = json.loads(Path(manifest_path).read_text(encoding="utf-8"))
if manifest.get("mode") != "scoped-overlay":
    raise SystemExit("refusing overlay upload: manifest mode must be scoped-overlay")
artifact_paths = manifest.get("artifact_paths") or []
if not artifact_paths:
    raise SystemExit("refusing overlay upload: manifest artifact_paths is empty")

key = os.path.expanduser(r"~\.ssh\vivodraw_windows_ed25519")
host = "root@186.241.72.176"
port = "49375"
ssh = [
    "ssh", "-i", key, "-p", port,
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
    "-o", "ServerAliveInterval=15",
    host,
]
scp = [
    "scp", "-O", "-i", key, "-P", port,
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
]

src = Path(os.environ.get("RELEASE_SOURCE_ROOT", r"D:\eccomall\mobile-app\dist-root")).resolve()
if not src.is_dir():
    raise SystemExit("release source root is missing: %s" % src)

ts = datetime.now().strftime("%Y%m%d_%H%M%S")
bundle = Path(os.environ.get("RELEASE_BUNDLE_PATH", r"D:\eccomall\deploy\v4-slim-overlay.tar.gz")).resolve()
if bundle.exists():
    bundle.unlink()

n = 0
with tarfile.open(bundle, "w:gz") as tar:
    for item in artifact_paths:
        rel = Path(item)
        full = (src / rel).resolve()
        if src.resolve() not in full.parents or not full.is_file():
            raise SystemExit("artifact is missing or outside dist-root: %s" % item)
        tar.add(full, arcname=rel.as_posix())
        n += 1

data = bundle.read_bytes()
digest = hashlib.sha256(data).hexdigest()
print("ts", ts, "files", n, "bytes", len(data), "sha256", digest, flush=True)

chunks_dir = Path(os.environ.get("RELEASE_CHUNKS_DIR", r"D:\eccomall\deploy\v4-slim-chunks")).resolve()
chunks_dir.mkdir(exist_ok=True)
for old in chunks_dir.glob("part-*"):
    old.unlink()
size = 900_000
parts = []
for i in range(0, len(data), size):
    name = "part-%03d" % (i // size)
    chunk = data[i : i + size]
    (chunks_dir / name).write_bytes(chunk)
    parts.append((name, len(chunk)))
print("parts", len(parts), flush=True)

subprocess.check_call(ssh + ["rm -f /tmp/v4-slim-bundle.tar.gz /tmp/v4-slim-part-*"])
for name, expected in parts:
    dest = "%s:/tmp/v4-slim-%s" % (host, name)
    print("scp", name, expected, flush=True)
    rc = subprocess.call(scp + [str(chunks_dir / name), dest])
    if rc != 0:
        raise SystemExit("scp failed " + name)
    remote_size = subprocess.check_output(
        ssh + ["wc -c < /tmp/v4-slim-%s" % name], timeout=30
    ).decode().strip()
    if int(remote_size) != expected:
        subprocess.check_call(ssh + ["truncate -s %d /tmp/v4-slim-%s" % (expected, name)])
        remote_size = subprocess.check_output(
            ssh + ["wc -c < /tmp/v4-slim-%s" % name], timeout=30
        ).decode().strip()
        if int(remote_size) != expected:
            raise SystemExit("size mismatch %s local=%s remote=%s" % (name, expected, remote_size))

cat = (
    "cat "
    + " ".join("/tmp/v4-slim-%s" % name for name, _ in parts)
    + " > /tmp/v4-slim-bundle.tar.gz && rm -f /tmp/v4-slim-part-* && "
    + "python3 - <<'PY'\n"
    + "import hashlib, pathlib\n"
    + "p=pathlib.Path('/tmp/v4-slim-bundle.tar.gz')\n"
    + "b=p.read_bytes()\n"
    + "print(len(b), hashlib.sha256(b).hexdigest())\n"
    + "PY"
)
out = subprocess.check_output(ssh + [cat], timeout=180).decode(errors="replace")
print("remote", out, flush=True)
if digest not in out:
    raise SystemExit("sha256 mismatch")

release = (
    "set -euo pipefail; "
    "APP=/opt/crmeb-prod/frontend-root; "
    "TS=%s; "
    "rm -rf \"$APP/releases/$TS\"; "
    "mkdir -p \"$APP/releases\"; "
    "cp -a \"$APP/current/.\" \"$APP/releases/$TS/\"; "
    "tar -xzf /tmp/v4-slim-bundle.tar.gz -C \"$APP/releases/$TS\"; "
    "test -f \"$APP/releases/$TS/index.html\"; "
    "test -d \"$APP/releases/$TS/_expo\"; "
    "ln -sfn \"releases/$TS\" \"$APP/current.new\"; "
    "mv -Tf \"$APP/current.new\" \"$APP/current\"; "
    "ls -1t \"$APP/releases\" | tail -n +6 | while read -r old; do rm -rf \"$APP/releases/$old\"; done; "
    "rm -f /tmp/v4-slim-bundle.tar.gz; "
    "echo overlay_ok $TS"
) % ts
print(subprocess.check_output(ssh + [release], timeout=180).decode(errors="replace"), flush=True)
print(subprocess.check_output(ssh + ["bash /root/remote-bump-v4rel.sh %s" % ts], timeout=60).decode(errors="replace"), flush=True)
Path(os.environ.get("RELEASE_LAST_TS_PATH", r"D:\eccomall\deploy\.last_ts")).write_text(ts, encoding="utf-8")
print("LIVE", ts, flush=True)
