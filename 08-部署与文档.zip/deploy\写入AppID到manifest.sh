#!/usr/bin/env bash
# 把 DCloud AppID 写入 uniapp 的 manifest.json（解决「appid 不存在」）
# 用法：先到 https://dev.dcloud.net.cn/developer/app 创建应用，复制 AppID，然后执行：
#   bash deploy/写入AppID到manifest.sh __UNI__XXXXXXXX
set -euo pipefail

NEW_APPID="${1:-}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
MANIFEST="${SCRIPT_DIR}/../backend_src/view/uniapp/manifest.json"

if [[ -z "${NEW_APPID}" ]]; then
  echo "用法: bash deploy/写入AppID到manifest.sh <AppID>"
  echo "示例: bash deploy/写入AppID到manifest.sh __UNI__8A1B2C3D"
  echo "请先到 https://dev.dcloud.net.cn/developer/app 创建应用并复制 AppID"
  exit 1
fi

if [[ ! -f "${MANIFEST}" ]]; then
  echo "未找到 manifest.json: ${MANIFEST}"
  exit 1
fi

# 替换 appid 字段（保持 "appid" : "xxx", 格式）
if grep -q '"appid"' "${MANIFEST}"; then
  sed -i.bak "s/\"appid\"[[:space:]]*:[[:space:]]*\"__UNI__[^\"]*\"/\"appid\" : \"${NEW_APPID}\"/" "${MANIFEST}"
  rm -f "${MANIFEST}.bak"
  echo "已写入 AppID: ${NEW_APPID}"
  echo "请在 HBuilderX 中重新发行 → 网站-PC Web或手机H5"
else
  echo "未在 manifest 中找到 appid 字段"
  exit 1
fi
