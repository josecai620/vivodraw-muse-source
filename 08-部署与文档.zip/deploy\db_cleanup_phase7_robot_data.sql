-- Phase 7 robot/test data cleanup.
--
-- DEPRECATED:
-- This historical cleanup references stale reveal-log table names and deletes
-- data. Do not run it against current production. Re-audit and create a new
-- approval-required cleanup plan if robot cleanup is needed again.
SIGNAL SQLSTATE '45000'
  SET MESSAGE_TEXT = 'Deprecated script: create a fresh approval-required cleanup plan';
--
-- IMPORTANT:
-- 1. Run only after creating a full DB backup and a robot-row archive:
--      bash deploy/db_archive_robot_data_phase7.sh 8.166.115.27
-- 2. This deletes only rows with is_jiqiren = 1 from the five target tables.
-- 3. It intentionally does not touch non-robot rows, users, products, menus, store_order,
--    or system logs.
-- 4. Execute during low traffic and monitor MySQL disk/CPU.
--
-- Expected robot rows from the 2026-05-02 audit:
-- - eb_store_integral_product_huanqu_log_unique: 12,721,643
-- - eb_store_integral_product_huanqu_log: 609,513
-- - eb_store_integral_product_kaijiang_log: 45,835
-- - eb_user_box: 351,346
-- - eb_box_order: 206,153

SET SESSION lock_wait_timeout = 60;
SET SESSION innodb_lock_wait_timeout = 60;

-- Preflight counts. Abort manually if any non-robot relationship count is not 0.
SELECT 'user_box_robot_missing_robot_order' AS check_name, COUNT(*) AS count_value
FROM eb_user_box ub
LEFT JOIN eb_box_order bo ON bo.id = ub.order_id AND bo.is_jiqiren = 1
WHERE ub.is_jiqiren = 1 AND ub.order_id > 0 AND bo.id IS NULL
UNION ALL
SELECT 'user_box_real_to_robot_order', COUNT(*)
FROM eb_user_box ub
JOIN eb_box_order bo ON bo.id = ub.order_id AND bo.is_jiqiren = 1
WHERE ub.is_jiqiren = 0
UNION ALL
SELECT 'huanqu_robot_missing_robot_order', COUNT(*)
FROM eb_store_integral_product_huanqu_log h
LEFT JOIN eb_box_order bo ON bo.id = h.box_order_id AND bo.is_jiqiren = 1
WHERE h.is_jiqiren = 1 AND h.box_order_id > 0 AND bo.id IS NULL
UNION ALL
SELECT 'huanqu_real_to_robot_order', COUNT(*)
FROM eb_store_integral_product_huanqu_log h
JOIN eb_box_order bo ON bo.id = h.box_order_id AND bo.is_jiqiren = 1
WHERE h.is_jiqiren = 0
UNION ALL
SELECT 'unique_robot_missing_robot_huanqu', COUNT(*)
FROM eb_store_integral_product_huanqu_log_unique u
LEFT JOIN eb_store_integral_product_huanqu_log h ON h.id = u.huanqu_id AND h.is_jiqiren = 1
WHERE u.is_jiqiren = 1 AND u.huanqu_id > 0 AND h.id IS NULL
UNION ALL
SELECT 'unique_real_to_robot_huanqu', COUNT(*)
FROM eb_store_integral_product_huanqu_log_unique u
JOIN eb_store_integral_product_huanqu_log h ON h.id = u.huanqu_id AND h.is_jiqiren = 1
WHERE u.is_jiqiren = 0
UNION ALL
SELECT 'kaijiang_robot_missing_robot_huanqu', COUNT(*)
FROM eb_store_integral_product_kaijiang_log k
LEFT JOIN eb_store_integral_product_huanqu_log h ON h.id = k.huanqu_id AND h.is_jiqiren = 1
WHERE k.is_jiqiren = 1 AND k.huanqu_id > 0 AND h.id IS NULL
UNION ALL
SELECT 'kaijiang_real_to_robot_huanqu', COUNT(*)
FROM eb_store_integral_product_kaijiang_log k
JOIN eb_store_integral_product_huanqu_log h ON h.id = k.huanqu_id AND h.is_jiqiren = 1
WHERE k.is_jiqiren = 0;

DELIMITER $$

DROP PROCEDURE IF EXISTS cleanup_robot_table_by_id $$
CREATE PROCEDURE cleanup_robot_table_by_id(
  IN p_table_name VARCHAR(128),
  IN p_batch_size INT,
  OUT p_deleted_total BIGINT
)
BEGIN
  DECLARE v_min_id BIGINT DEFAULT 0;
  DECLARE v_max_id BIGINT DEFAULT 0;
  DECLARE v_lo BIGINT DEFAULT 0;
  DECLARE v_hi BIGINT DEFAULT 0;
  DECLARE v_deleted BIGINT DEFAULT 0;

  SET @sql_minmax = CONCAT(
    'SELECT COALESCE(MIN(id), 0), COALESCE(MAX(id), 0) ',
    'INTO @cleanup_min_id, @cleanup_max_id ',
    'FROM `', p_table_name, '` WHERE is_jiqiren = 1'
  );
  PREPARE stmt_minmax FROM @sql_minmax;
  EXECUTE stmt_minmax;
  DEALLOCATE PREPARE stmt_minmax;

  SET v_min_id = @cleanup_min_id;
  SET v_max_id = @cleanup_max_id;
  SET v_lo = v_min_id;
  SET p_deleted_total = 0;

  WHILE v_lo > 0 AND v_lo <= v_max_id DO
    SET v_hi = v_lo + p_batch_size;
    SET @cleanup_lo = v_lo;
    SET @cleanup_hi = v_hi;
    SET @sql_delete = CONCAT(
      'DELETE FROM `', p_table_name, '` ',
      'WHERE id >= ? AND id < ? AND is_jiqiren = 1'
    );

    PREPARE stmt_delete FROM @sql_delete;
    EXECUTE stmt_delete USING @cleanup_lo, @cleanup_hi;
    SET v_deleted = ROW_COUNT();
    DEALLOCATE PREPARE stmt_delete;

    SET p_deleted_total = p_deleted_total + v_deleted;
    SET v_lo = v_hi;
    DO SLEEP(0.02);
  END WHILE;
END $$

DELIMITER ;

CALL cleanup_robot_table_by_id('eb_store_integral_product_huanqu_log_unique', 50000, @deleted_hq_unique);
CALL cleanup_robot_table_by_id('eb_store_integral_product_kaijiang_log', 10000, @deleted_kaijiang);
CALL cleanup_robot_table_by_id('eb_user_box', 20000, @deleted_user_box);
CALL cleanup_robot_table_by_id('eb_store_integral_product_huanqu_log', 20000, @deleted_huanqu_log);
CALL cleanup_robot_table_by_id('eb_box_order', 20000, @deleted_box_order);

SELECT
  @deleted_hq_unique AS deleted_hq_unique,
  @deleted_kaijiang AS deleted_kaijiang,
  @deleted_user_box AS deleted_user_box,
  @deleted_huanqu_log AS deleted_huanqu_log,
  @deleted_box_order AS deleted_box_order;

DROP PROCEDURE IF EXISTS cleanup_robot_table_by_id;

ANALYZE TABLE
  `eb_store_integral_product_huanqu_log_unique`,
  `eb_store_integral_product_huanqu_log`,
  `eb_store_integral_product_kaijiang_log`,
  `eb_user_box`,
  `eb_box_order`;

-- Post-check: all values should be 0.
SELECT 'eb_store_integral_product_huanqu_log_unique' AS table_name, COUNT(*) AS robot_rows
FROM eb_store_integral_product_huanqu_log_unique
WHERE is_jiqiren = 1
UNION ALL
SELECT 'eb_store_integral_product_huanqu_log', COUNT(*)
FROM eb_store_integral_product_huanqu_log
WHERE is_jiqiren = 1
UNION ALL
SELECT 'eb_store_integral_product_kaijiang_log', COUNT(*)
FROM eb_store_integral_product_kaijiang_log
WHERE is_jiqiren = 1
UNION ALL
SELECT 'eb_user_box', COUNT(*)
FROM eb_user_box
WHERE is_jiqiren = 1
UNION ALL
SELECT 'eb_box_order', COUNT(*)
FROM eb_box_order
WHERE is_jiqiren = 1;
