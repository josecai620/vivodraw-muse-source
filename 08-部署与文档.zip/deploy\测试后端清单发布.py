# -*- coding: utf-8 -*-
"""临时目录 + 强制导出的 shell 函数，离线执行 scoped 发布流程。

曾发现 Git Bash 不可靠地优先采用 PATH 假 ssh；因此只允许保留测试域名，
并在子 Bash 内先断言函数拦截与执行探针，绝不依赖 PATH 遮蔽真实网络工具。
"""
from __future__ import annotations

import hashlib
import json
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SOURCE = Path(__file__).with_name("update_online.sh").resolve()
BASH = Path("C:/Program Files/Git/bin/bash.exe") if os.name == "nt" else Path(shutil.which("bash") or "/bin/bash")
MOCK = r'''import json, os, shutil, sys
from pathlib import Path
kind = sys.argv[1]
args = sys.argv[2:]
local = Path(os.environ['MOCK_LOCAL_ROOT'])
remote = Path(os.environ['MOCK_REMOTE_ROOT'])
log = Path(os.environ['MOCK_LOG'])
if args == ['--offline-probe']:
    with Path(os.environ['MOCK_PROBE_LOG']).open('a', encoding='utf-8') as stream:
        stream.write(kind + '\n')
    raise SystemExit(0)
with log.open('a', encoding='utf-8') as stream:
    stream.write(json.dumps({'tool': kind, 'args': args}, ensure_ascii=False) + '\n')
if kind == 'ssh':
    if len(args) < 2 or args[-2] != 'root@support-release.test.invalid':
        raise SystemExit('Mock refuses any non-fixture SSH destination')
    command = args[-1]
    content = sys.stdin.read()
    if command == 'python3 -':
        expected = "Path('/opt/crmeb-prod')"
        if content.count(expected) != 1:
            raise SystemExit('Mock refuses unexpected remote program')
        content = content.replace(expected, 'Path(' + repr(str(remote)) + ')')
        exec(compile(content, '<offline-remote-check>', 'exec'), {})
    elif 'tar --ignore-failed-read' in command:
        if os.environ.get('MOCK_MUTATE_LOCAL') == '1':
            (local / 'backend_src/route/api.php').write_bytes(b'concurrent edit\n')
        if os.environ.get('MOCK_MUTATE_LIST') == '1':
            Path(os.environ['DEPLOY_BACKEND_FILES_FILE']).write_text('backend_src/app/extra.php\n', encoding='utf-8')
        if os.environ.get('MOCK_MUTATE_MANIFEST') == '1':
            manifest = Path(os.environ['DEPLOY_BACKEND_MANIFEST'])
            manifest.write_bytes(manifest.read_bytes() + b' ')
    elif 'docker restart crmeb-php-fpm' not in command:
        raise SystemExit('Mock refuses unexpected SSH command')
elif kind == 'rsync':
    if args[-1] != 'root@support-release.test.invalid:/opt/crmeb-prod/':
        raise SystemExit('Mock refuses any non-fixture rsync destination')
    if '--files-from=-' not in args or '--delete' in args:
        raise SystemExit('Mock refuses broad rsync')
    for name in sys.stdin.read().splitlines():
        source = local / name
        target = remote / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        if os.environ.get('MOCK_CORRUPT_UPLOAD') == '1':
            target.write_bytes(b'corrupted upload fixture\n')
elif kind != 'curl':
    raise SystemExit('Unexpected mock tool')
'''


@unittest.skipUnless(BASH.is_file(), "需要本地 Bash；不会使用任何真实 SSH 工具")
class 后端清单发布测试(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="scoped-backend-test-")
        self.root = Path(self.temporary.name).resolve()
        self.local = self.root / "workspace"
        self.remote = self.root / "remote-fixture"
        for directory in (self.local / "deploy", self.remote):
            directory.mkdir(parents=True)
        (self.local / "deploy/update_online.sh").write_bytes(SOURCE.read_bytes())
        self.list = self.root / "files.txt"
        self.manifest = self.root / "manifest.json"
        self.log = self.root / "calls.jsonl"
        self.probe = self.root / "interception-confirmed.txt"
        self.probe_log = self.root / "interception-probes.txt"
        self.identity = self.root / "fixture identity"
        self.identity.write_text("offline-not-a-private-key-" + os.urandom(24).hex(), encoding="utf-8")
        mock = self.root / "mock.py"
        mock.write_text(MOCK, encoding="utf-8")
        self.environment = dict(os.environ)
        for name in list(self.environment):
            if name.startswith("DEPLOY_") or name.startswith("MOCK_") or name in ("BASH_ENV", "ENV"):
                del self.environment[name]
        self.environment.update({
            "PYTHONIOENCODING": "utf-8", "DEPLOY_PYTHON": "scoped_test_python",
            "DEPLOY_BACKEND_FILES_FILE": self.list.as_posix(), "DEPLOY_BACKEND_MANIFEST": self.manifest.as_posix(),
            "DEPLOY_REQUIRE_MANIFEST": "1", "DEPLOY_SSH_IDENTITY": self.identity.as_posix(),
            "MOCK_LOCAL_ROOT": str(self.local), "MOCK_REMOTE_ROOT": str(self.remote), "MOCK_LOG": str(self.log),
            "MOCK_PYTHON": Path(sys.executable).as_posix(), "MOCK_SCRIPT": mock.as_posix(),
            "MOCK_DEPLOY": (self.local / "deploy/update_online.sh").as_posix(),
            "MOCK_PROBE": self.probe.as_posix(), "MOCK_PROBE_LOG": self.probe_log.as_posix(),
        })
        self.prepare([("backend_src/route/api.php", b"new PHP fixture\n", b"old PHP fixture\n")])

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def prepare(self, files: list[tuple[str, bytes, bytes | None]]) -> None:
        records = []
        for name, current, previous in files:
            source = self.local / name
            source.parent.mkdir(parents=True, exist_ok=True)
            source.write_bytes(current)
            if previous is not None:
                target = self.remote / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(previous)
            records.append({"path": name, "local_sha256": hashlib.sha256(current).hexdigest(),
                            "remote_sha256": hashlib.sha256(previous).hexdigest() if previous is not None else None})
        self.list.write_text("\n".join(name for name, _, _ in files) + "\n", encoding="utf-8")
        self.manifest.write_text(json.dumps({"schema": 1, "files": records}, ensure_ascii=False), encoding="utf-8")

    def run_scoped(self, successful: bool = True) -> list[dict]:
        for previous in (self.probe, self.probe_log):
            if previous.exists():
                previous.unlink()
        # 子 shell 在 source 发布脚本前证明函数已继承；所有网络命令都由函数消费。
        harness = r'''
set -euo pipefail
ssh() { MSYS2_ARG_CONV_EXCL='*' "$MOCK_PYTHON" "$MOCK_SCRIPT" ssh "$@"; }
rsync() { MSYS2_ARG_CONV_EXCL='*' "$MOCK_PYTHON" "$MOCK_SCRIPT" rsync "$@"; }
curl() { MSYS2_ARG_CONV_EXCL='*' "$MOCK_PYTHON" "$MOCK_SCRIPT" curl "$@"; }
scoped_test_python() { "$MOCK_PYTHON" "$@"; }
export -f ssh rsync curl scoped_test_python
"$BASH" --noprofile --norc -c '
  for tool in ssh rsync curl scoped_test_python; do
    [[ "$(type -t "$tool")" == function ]] || exit 87
  done
  : > "$MOCK_PROBE_LOG"
  ssh --offline-probe
  rsync --offline-probe
  curl --offline-probe
  printf "shell-functions-confirmed\n" > "$MOCK_PROBE"
  source "$0" "$@"
' "$MOCK_DEPLOY" support-release.test.invalid root 49375
'''
        result = subprocess.run([str(BASH), "--noprofile", "--norc", "-c", harness],
                                capture_output=True, env=self.environment, timeout=45)
        output = (result.stdout + result.stderr).decode("utf-8", errors="replace")
        self.assertTrue(self.probe.is_file(), "子 shell 未确认网络函数拦截：" + output)
        self.assertEqual(self.probe.read_text(encoding="utf-8"), "shell-functions-confirmed\n")
        self.assertEqual(self.probe_log.read_text(encoding="utf-8").splitlines(), ["ssh", "rsync", "curl"])
        if successful:
            self.assertEqual(result.returncode, 0, output)
        else:
            self.assertNotEqual(result.returncode, 0, output)
        events = [json.loads(line) for line in self.log.read_text(encoding="utf-8").splitlines()] if self.log.exists() else []
        for event in events:
            if event["tool"] == "ssh":
                self.assertEqual(event["args"][-2], "root@support-release.test.invalid")
            self.assertNotIn("vivodraw_windows_ed25519", json.dumps(event))
        return events

    def test_success_uses_same_identity_and_required_ssh_safety_options(self) -> None:
        events = self.run_scoped()
        self.assertEqual([event["tool"] for event in events], ["ssh", "ssh", "rsync", "ssh", "ssh", "curl"])
        ssh_events = [event for event in events if event["tool"] == "ssh"]
        for event in ssh_events:
            self.assertEqual(event["args"][event["args"].index("-i") + 1], self.identity.as_posix())
            for option in ("BatchMode=yes", "IdentitiesOnly=yes", "StrictHostKeyChecking=yes"):
                self.assertIn(option, event["args"])
        rsync = next(event for event in events if event["tool"] == "rsync")
        remote_shell = shlex.split(rsync["args"][rsync["args"].index("-e") + 1])
        self.assertEqual(remote_shell, ["ssh", *ssh_events[0]["args"][:-2]])
        self.assertEqual((self.remote / "backend_src/route/api.php").read_bytes(), b"new PHP fixture\n")

    def test_chinese_new_file_absence_and_existing_route_both_verified(self) -> None:
        self.prepare([("backend_src/route/api.php", b"new route\n", b"old route\n"),
                      ("backend_src/app/services/客服 测试.php", b"new support source\n", None)])
        self.run_scoped()
        self.assertEqual((self.remote / "backend_src/app/services/客服 测试.php").read_bytes(), b"new support source\n")

    def test_local_sha_mismatch_stops_before_any_ssh(self) -> None:
        (self.local / "backend_src/route/api.php").write_bytes(b"unexpected local change\n")
        self.assertEqual(self.run_scoped(successful=False), [])

    def test_remote_baseline_mismatch_stops_before_backup_and_rsync(self) -> None:
        (self.remote / "backend_src/route/api.php").write_bytes(b"other deployment\n")
        self.assertEqual([event["tool"] for event in self.run_scoped(successful=False)], ["ssh"])

    def test_expected_absent_file_cannot_overwrite_existing_remote_file(self) -> None:
        self.prepare([("backend_src/app/new.php", b"new\n", None)])
        (self.remote / "backend_src/app").mkdir(parents=True, exist_ok=True)
        (self.remote / "backend_src/app/new.php").write_bytes(b"someone else created this\n")
        self.assertEqual([event["tool"] for event in self.run_scoped(successful=False)], ["ssh"])

    def test_manifest_and_file_list_must_match_exactly(self) -> None:
        self.list.write_text("backend_src/route/api.php\nbackend_src/app/extra.php\n", encoding="utf-8")
        (self.local / "backend_src/app").mkdir(parents=True)
        (self.local / "backend_src/app/extra.php").write_bytes(b"extra\n")
        self.assertEqual(self.run_scoped(successful=False), [])

    def test_required_manifest_cannot_be_omitted(self) -> None:
        del self.environment["DEPLOY_BACKEND_MANIFEST"]
        self.assertEqual(self.run_scoped(successful=False), [])

    def test_old_t27_scoped_call_without_manifest_remains_compatible(self) -> None:
        del self.environment["DEPLOY_BACKEND_MANIFEST"]
        del self.environment["DEPLOY_REQUIRE_MANIFEST"]
        events = self.run_scoped()
        self.assertEqual([event["tool"] for event in events], ["ssh", "rsync", "ssh", "curl"])

    def test_support_configuration_source_requires_explicit_permission_and_manifest(self) -> None:
        self.prepare([("backend_src/config/support.php", b"support config source\n", None)])
        self.assertEqual(self.run_scoped(successful=False), [])
        self.environment["DEPLOY_SUPPORT_CONFIG"] = "1"
        self.run_scoped()

    def test_support_configuration_cannot_use_legacy_unhashed_mode(self) -> None:
        self.environment["DEPLOY_SUPPORT_CONFIG"] = "1"
        del self.environment["DEPLOY_BACKEND_MANIFEST"]
        del self.environment["DEPLOY_REQUIRE_MANIFEST"]
        self.assertEqual(self.run_scoped(successful=False), [])

    def test_concurrent_local_edit_after_backup_stops_before_rsync(self) -> None:
        self.environment["MOCK_MUTATE_LOCAL"] = "1"
        events = self.run_scoped(successful=False)
        self.assertEqual([event["tool"] for event in events], ["ssh", "ssh"])
        self.assertEqual((self.remote / "backend_src/route/api.php").read_bytes(), b"old PHP fixture\n")

    def test_mutated_list_or_manifest_cannot_change_upload_scope(self) -> None:
        for variable in ("MOCK_MUTATE_LIST", "MOCK_MUTATE_MANIFEST"):
            with self.subTest(variable=variable):
                self.prepare([("backend_src/route/api.php", b"new PHP fixture\n", b"old PHP fixture\n")])
                if self.log.exists():
                    self.log.unlink()
                self.environment[variable] = "1"
                events = self.run_scoped(successful=False)
                self.assertEqual([event["tool"] for event in events], ["ssh", "ssh"])
                del self.environment[variable]

    def test_post_upload_sha_mismatch_does_not_restart_or_auto_rollback(self) -> None:
        self.environment["MOCK_CORRUPT_UPLOAD"] = "1"
        events = self.run_scoped(successful=False)
        self.assertEqual([event["tool"] for event in events], ["ssh", "ssh", "rsync", "ssh"])
        self.assertEqual((self.remote / "backend_src/route/api.php").read_bytes(), b"corrupted upload fixture\n")

    def test_traversal_sensitive_and_non_php_paths_rejected(self) -> None:
        for name in ("backend_src/app/../route/api.php", "backend_src/.env", "backend_src/app/config.txt",
                     "/backend_src/app/a.php", "backend_src/app//a.php", "backend_src/app/./a.php",
                     "backend_src/app\\a.php", "backend_src/app/C:a.php", "backend_src/app/a.php:secret"):
            with self.subTest(name=name):
                self.list.write_text(name + "\n", encoding="utf-8")
                self.assertEqual(self.run_scoped(successful=False), [])

    def test_malformed_manifest_fails_before_any_ssh(self) -> None:
        original = self.manifest.read_text(encoding="utf-8")
        valid = json.loads(original)
        mutations = [
            "{", original.replace('"schema": 1', '"schema": 1, "schema": 1'),
            json.dumps({**valid, "schema": True}),
            json.dumps({**valid, "files": [valid["files"][0], valid["files"][0]]}),
            json.dumps({"schema": 1, "files": [{**valid["files"][0], "local_sha256": "A" * 64}]}),
            json.dumps({"schema": 1, "files": [{**valid["files"][0], "remote_sha256": ""}]}),
            json.dumps({"schema": 1, "files": [{**valid["files"][0], "extra": True}]}),
        ]
        for content in mutations:
            with self.subTest(content=content):
                self.manifest.write_text(content, encoding="utf-8")
                self.assertEqual(self.run_scoped(successful=False), [])

    def test_bom_crlf_file_list_remains_compatible(self) -> None:
        self.list.write_bytes(b"\xef\xbb\xbfbackend_src/route/api.php\r\n")
        self.run_scoped()

    def test_empty_duplicate_and_missing_file_list_fail_before_any_ssh(self) -> None:
        for content in ("", "backend_src/route/api.php\nbackend_src/route/api.php\n", "backend_src/app/missing.php\n"):
            with self.subTest(content=content):
                self.list.write_text(content, encoding="utf-8")
                self.assertEqual(self.run_scoped(successful=False), [])

    def test_default_identity_selection_remains_compatible(self) -> None:
        del self.environment["DEPLOY_SSH_IDENTITY"]
        events = self.run_scoped()
        for event in events:
            if event["tool"] == "ssh":
                self.assertNotIn("-i", event["args"])

    def test_missing_identity_stops_before_ssh(self) -> None:
        self.environment["DEPLOY_SSH_IDENTITY"] = (self.root / "missing-identity").as_posix()
        self.assertEqual(self.run_scoped(successful=False), [])

    def make_directory_link(self, link: Path, target: Path) -> None:
        if os.name == "nt":
            # 只创建临时测试目录内的 junction；不依赖管理员 symlink 权限。
            result = subprocess.run(["cmd.exe", "/d", "/c", "mklink", "/J", str(link), str(target)],
                                    capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr.decode(errors="replace"))
        else:
            link.symlink_to(target, target_is_directory=True)

    def test_local_linked_parent_rejected_before_ssh(self) -> None:
        route = self.local / "backend_src/route"
        moved = self.root / "local-route-fixture"
        route.rename(moved)
        self.make_directory_link(route, moved)
        try:
            self.assertEqual(self.run_scoped(successful=False), [])
        finally:
            route.rmdir() if os.name == "nt" else route.unlink()

    def test_remote_linked_parent_rejected_before_backup(self) -> None:
        route = self.remote / "backend_src/route"
        moved = self.root / "remote-route-fixture"
        route.rename(moved)
        self.make_directory_link(route, moved)
        try:
            events = self.run_scoped(successful=False)
            self.assertEqual([event["tool"] for event in events], ["ssh"])
            self.assertEqual((moved / "api.php").read_bytes(), b"old PHP fixture\n")
        finally:
            route.rmdir() if os.name == "nt" else route.unlink()

    def test_non_scoped_branch_unchanged_and_bash_syntax_valid(self) -> None:
        source = SOURCE.read_bytes()
        tail = source[source.index(b"\nhealth_check()") :]
        self.assertEqual(hashlib.sha256(tail).hexdigest(), "9361f39144535085656721eeaa7a10863b294fb02403ca8a1245d5ec614bf729")
        result = subprocess.run([str(BASH), "-n", str(SOURCE)], capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr.decode(errors="replace"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
