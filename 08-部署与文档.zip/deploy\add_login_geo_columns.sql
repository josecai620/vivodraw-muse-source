-- 登录IP与归属地（国家/省州/城市）字段升级
-- 覆盖：后台管理员 eb_system_admin、用户 eb_user

-- ========== eb_system_admin ==========
SET @admin_table := 'eb_system_admin';

SET @admin_last_ip_len := (
  SELECT IFNULL(CHARACTER_MAXIMUM_LENGTH, 16)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = @admin_table
    AND COLUMN_NAME = 'last_ip'
  LIMIT 1
);
SET @admin_ip_ddl := IF(
  @admin_last_ip_len < 45,
  CONCAT('ALTER TABLE `', @admin_table, '` MODIFY COLUMN `last_ip` VARCHAR(45) NOT NULL DEFAULT '''' COMMENT ''后台管理员最后一次登录ip'''),
  'SELECT 1'
);
PREPARE stmt_admin_ip FROM @admin_ip_ddl;
EXECUTE stmt_admin_ip;
DEALLOCATE PREPARE stmt_admin_ip;

SET @admin_add_country := (
  SELECT COUNT(1) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @admin_table AND COLUMN_NAME = 'login_country'
);
SET @admin_country_ddl := IF(
  @admin_add_country = 0,
  CONCAT('ALTER TABLE `', @admin_table, '` ADD COLUMN `login_country` VARCHAR(64) NOT NULL DEFAULT '''' COMMENT ''登录国家'' AFTER `last_ip`'),
  'SELECT 1'
);
PREPARE stmt_admin_country FROM @admin_country_ddl;
EXECUTE stmt_admin_country;
DEALLOCATE PREPARE stmt_admin_country;

SET @admin_add_province := (
  SELECT COUNT(1) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @admin_table AND COLUMN_NAME = 'login_province'
);
SET @admin_province_ddl := IF(
  @admin_add_province = 0,
  CONCAT('ALTER TABLE `', @admin_table, '` ADD COLUMN `login_province` VARCHAR(64) NOT NULL DEFAULT '''' COMMENT ''登录省州'' AFTER `login_country`'),
  'SELECT 1'
);
PREPARE stmt_admin_province FROM @admin_province_ddl;
EXECUTE stmt_admin_province;
DEALLOCATE PREPARE stmt_admin_province;

SET @admin_add_city := (
  SELECT COUNT(1) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @admin_table AND COLUMN_NAME = 'login_city'
);
SET @admin_city_ddl := IF(
  @admin_add_city = 0,
  CONCAT('ALTER TABLE `', @admin_table, '` ADD COLUMN `login_city` VARCHAR(64) NOT NULL DEFAULT '''' COMMENT ''登录城市'' AFTER `login_province`'),
  'SELECT 1'
);
PREPARE stmt_admin_city FROM @admin_city_ddl;
EXECUTE stmt_admin_city;
DEALLOCATE PREPARE stmt_admin_city;

SET @admin_add_location := (
  SELECT COUNT(1) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @admin_table AND COLUMN_NAME = 'login_location'
);
SET @admin_location_ddl := IF(
  @admin_add_location = 0,
  CONCAT('ALTER TABLE `', @admin_table, '` ADD COLUMN `login_location` VARCHAR(255) NOT NULL DEFAULT '''' COMMENT ''登录归属地拼接文本'' AFTER `login_city`'),
  'SELECT 1'
);
PREPARE stmt_admin_location FROM @admin_location_ddl;
EXECUTE stmt_admin_location;
DEALLOCATE PREPARE stmt_admin_location;

SET @admin_add_source := (
  SELECT COUNT(1) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @admin_table AND COLUMN_NAME = 'login_location_source'
);
SET @admin_source_ddl := IF(
  @admin_add_source = 0,
  CONCAT('ALTER TABLE `', @admin_table, '` ADD COLUMN `login_location_source` VARCHAR(32) NOT NULL DEFAULT '''' COMMENT ''归属地来源 geolite2/cf-header/local'' AFTER `login_location`'),
  'SELECT 1'
);
PREPARE stmt_admin_source FROM @admin_source_ddl;
EXECUTE stmt_admin_source;
DEALLOCATE PREPARE stmt_admin_source;

-- ========== eb_user ==========
SET @user_table := 'eb_user';

SET @user_last_ip_len := (
  SELECT IFNULL(CHARACTER_MAXIMUM_LENGTH, 16)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = @user_table
    AND COLUMN_NAME = 'last_ip'
  LIMIT 1
);
SET @user_ip_ddl := IF(
  @user_last_ip_len < 45,
  CONCAT('ALTER TABLE `', @user_table, '` MODIFY COLUMN `last_ip` VARCHAR(45) NOT NULL DEFAULT '''' COMMENT ''最后一次登录ip'''),
  'SELECT 1'
);
PREPARE stmt_user_ip FROM @user_ip_ddl;
EXECUTE stmt_user_ip;
DEALLOCATE PREPARE stmt_user_ip;

SET @user_add_ip_len := (
  SELECT IFNULL(CHARACTER_MAXIMUM_LENGTH, 16)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = @user_table
    AND COLUMN_NAME = 'add_ip'
  LIMIT 1
);
SET @user_add_ip_ddl := IF(
  @user_add_ip_len < 45,
  CONCAT('ALTER TABLE `', @user_table, '` MODIFY COLUMN `add_ip` VARCHAR(45) NOT NULL DEFAULT '''' COMMENT ''添加ip'''),
  'SELECT 1'
);
PREPARE stmt_user_add_ip FROM @user_add_ip_ddl;
EXECUTE stmt_user_add_ip;
DEALLOCATE PREPARE stmt_user_add_ip;

SET @user_add_country := (
  SELECT COUNT(1) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @user_table AND COLUMN_NAME = 'login_country'
);
SET @user_country_ddl := IF(
  @user_add_country = 0,
  CONCAT('ALTER TABLE `', @user_table, '` ADD COLUMN `login_country` VARCHAR(64) NOT NULL DEFAULT '''' COMMENT ''登录国家'' AFTER `login_city`'),
  'SELECT 1'
);
PREPARE stmt_user_country FROM @user_country_ddl;
EXECUTE stmt_user_country;
DEALLOCATE PREPARE stmt_user_country;

SET @user_add_province := (
  SELECT COUNT(1) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @user_table AND COLUMN_NAME = 'login_province'
);
SET @user_province_ddl := IF(
  @user_add_province = 0,
  CONCAT('ALTER TABLE `', @user_table, '` ADD COLUMN `login_province` VARCHAR(64) NOT NULL DEFAULT '''' COMMENT ''登录省州'' AFTER `login_country`'),
  'SELECT 1'
);
PREPARE stmt_user_province FROM @user_province_ddl;
EXECUTE stmt_user_province;
DEALLOCATE PREPARE stmt_user_province;

SET @user_add_location := (
  SELECT COUNT(1) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @user_table AND COLUMN_NAME = 'login_location'
);
SET @user_location_ddl := IF(
  @user_add_location = 0,
  CONCAT('ALTER TABLE `', @user_table, '` ADD COLUMN `login_location` VARCHAR(255) NOT NULL DEFAULT '''' COMMENT ''登录归属地拼接文本'' AFTER `login_province`'),
  'SELECT 1'
);
PREPARE stmt_user_location FROM @user_location_ddl;
EXECUTE stmt_user_location;
DEALLOCATE PREPARE stmt_user_location;

SET @user_add_source := (
  SELECT COUNT(1) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @user_table AND COLUMN_NAME = 'login_location_source'
);
SET @user_source_ddl := IF(
  @user_add_source = 0,
  CONCAT('ALTER TABLE `', @user_table, '` ADD COLUMN `login_location_source` VARCHAR(32) NOT NULL DEFAULT '''' COMMENT ''归属地来源 geolite2/cf-header/local'' AFTER `login_location`'),
  'SELECT 1'
);
PREPARE stmt_user_source FROM @user_source_ddl;
EXECUTE stmt_user_source;
DEALLOCATE PREPARE stmt_user_source;
