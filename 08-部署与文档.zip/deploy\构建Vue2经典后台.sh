#!/usr/bin/env bash
# 构建 Vue2 经典后台，输出到 backend_src/public/admin-v2/
# 用于直接访问 /admin-shop/ 或通过 update_online.sh 同步到服务器
# 用法: bash deploy/构建Vue2经典后台.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
ADMIN_SRC="${PROJECT_DIR}/backend_src/view/admin"
PUBLIC_ADMIN_V2="${PROJECT_DIR}/backend_src/public/admin-v2"

echo "==> 1. 进入 Vue2 后台目录: ${ADMIN_SRC}"
cd "${ADMIN_SRC}"

echo "==> 2. 检查 Node.js"
if ! command -v node >/dev/null 2>&1; then
  echo "错误: 未找到 Node.js"
  exit 1
fi

echo "==> 3. 安装依赖（若无）"
if [[ ! -d node_modules ]]; then
  npm install --registry=https://registry.npmmirror.com --legacy-peer-deps
fi

echo "==> 4. 构建 Vue2 经典后台 (VUE_APP_LEGACY=1, 输出到 public/admin-v2)"
export VUE_APP_LEGACY=1
export NODE_OPTIONS=--openssl-legacy-provider
npm run build:legacy

if [[ ! -d "${PUBLIC_ADMIN_V2}" ]] || [[ ! -f "${PUBLIC_ADMIN_V2}/index.html" ]]; then
  echo "错误: 构建输出不存在，请检查 backend_src/view/admin/src/setting.env.js 中的 outputDir"
  exit 1
fi

echo "==> 5. 完成"
echo "Vue2 经典后台已构建到: ${PUBLIC_ADMIN_V2}"
echo "访问路径: /admin-shop/"
echo ""
echo "部署到服务器后，访问 /admin-shop/ 即可使用 Vue2 经典后台。"
