# CoreSettlement Phase 29 Point Admin Route Contract 2026-05-18

No route was added.
Do not expose these routes until approved.

Proposed readonly GET routes:

```text
GET adminapi/core/point_gateway/overview
GET adminapi/core/point_gateway/transactions
GET adminapi/core/point_gateway/detail
GET adminapi/core/point_gateway/rollback_requests
GET adminapi/core/point_gateway/frozen_points
GET adminapi/core/point_gateway/expiry_batches
GET adminapi/core/point_gateway/ai_operation_logs
```

Permission keys:

```text
point_gateway.overview.view
point_gateway.transactions.view
point_gateway.transactions.detail
point_gateway.rollback_requests.view
point_gateway.frozen_points.view
point_gateway.expiry_batches.view
point_gateway.ai_operation_logs.view
```

Forbidden:

```text
POST adminapi/core/point_gateway/*
PUT adminapi/core/point_gateway/*
DELETE adminapi/core/point_gateway/*
rollback_execute
fix_user_points
manual_adjust
```
