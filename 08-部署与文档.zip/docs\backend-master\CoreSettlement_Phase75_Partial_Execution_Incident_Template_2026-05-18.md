# CoreSettlement Phase75 Partial Execution Incident Template 2026-05-18

## Current Task

Phase75 prepares a template for partial execution incidents if future SQL execution fails midway.

Template only.
No SQL was executed.
No incident occurred.
No production database connection was opened.

## Future Incident Fields

```text
incident_status: draft|open|resolved
mysql_exit_code:
tables_created:
tables_missing:
error_summary_redacted:
credentials_printed: false
operator_window_id:
next_action_requires_user: true
```

## Incident Rules

```text
do not retry automatically
do not edit SQL inline
do not enable runtime writes
do not rollback without separate approval
document exact table state
```

## Phase75 Guards

```text
partial_execution_incident_template_created: true
sql_executed: false
incident_created: false
production_connection_opened: false
database_writes: false
```
