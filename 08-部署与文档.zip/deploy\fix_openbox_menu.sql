-- 修复开盒记录菜单：确保菜单存在、路径正确、层级与可见性正确
-- 执行：bash deploy/run_fix_openbox_menu.sh 或手动导入

SET NAMES utf8mb4;

-- 0. 获取商品菜单 id（用于 pid）
SET @product_pid = (SELECT `id` FROM `eb_system_menus` WHERE (`header` = 'product' OR `menu_path` = '/admin/product') AND `is_del` = 0 LIMIT 1);
SET @product_pid = IFNULL(@product_pid, 1);

-- 1. 若开盒记录菜单已存在，修正路径、层级、可见性（header='product' 必须在商品下显示）
UPDATE `eb_system_menus` SET
  `menu_path` = '/admin/product/openbox_list',
  `unique_auth` = 'admin-product-openbox-list',
  `api_url` = 'product/boxlist',
  `menu_name` = '开盒记录',
  `pid` = @product_pid,
  `header` = 'product',
  `is_show_path` = 0,
  `is_header` = 0
WHERE (`menu_name` = '开盒记录' OR `menu_path` = '/admin/product/openbox_list') AND `is_del` = 0;

-- 2. 若不存在则插入（挂到商品菜单下）
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @product_pid, 1, 'md-cube-outline', '开盒记录', 'admin', 'product.BoxLog', 'index', 'product/boxlist', 'GET', '[]', 5, 1, 0, 1, '/admin/product/openbox_list', '1', 1, 'product', 0, 'admin-product-openbox-list', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/product/openbox_list' AND `is_del` = 0);

-- 3. 为超级管理员角色(id=1)添加开盒记录菜单权限（若 rules 非 '*'）
-- 注：level=0 的超级管理员不受 role rules 限制；其他角色需在 设置→权限管理 中勾选「开盒记录」
