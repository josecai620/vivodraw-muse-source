# CoreSettlement Phase 46 AI Log Table Naming Decision 2026-05-18

## Current Task

Phase 46 resolves the AI operation log table naming decision before any SQL draft.

Decision only.
No SQL file was created.
No SQL was executed.
No migration was run.
No production database connection was opened.
No deployment was executed.
No write path was enabled.

## Decision

Final table name:

```text
eb_core_point_gateway_ai_operation_log
```

Approval audit table name:

```text
eb_core_point_gateway_approval_audit
```

Deprecated draft-only name:

```text
eb_core_point_ai_operation_log
```

## Rationale

```text
gateway name matches Point Gateway scope
gateway name avoids conflict with older Phase23 draft wording
gateway name aligns with Phase41 operation log schema
approval audit table pairs with gateway operation log
legacy draft name must not be created unless compatibility alias is explicitly approved
```

## Compatibility Rule

```text
do not create eb_core_point_ai_operation_log by default
do not create both names by default
if legacy draft table already exists in production, report only
if legacy draft table already contains rows, stop and ask user before any migration decision
renaming legacy draft table requires separate approval
```

## Docs To Treat As Current

```text
docs/backend-master/CoreSettlement_Phase41_AI_Operation_Log_Table_Draft_2026-05-18.md
docs/backend-master/CoreSettlement_Phase43_Readonly_Production_Table_Check_Plan_2026-05-18.md
docs/backend-master/CoreSettlement_Phase45_Migration_Approval_Checklist_2026-05-18.md
```

Phase23 remains historical design context for earlier table drafts.
Phase46 naming decision supersedes the Phase23 `eb_core_point_ai_operation_log` draft name for future SQL.

## Guards

```text
sql_file_created: false
sql_executed: false
migration_run: false
production_connection_opened: false
database_writes: false
deployment_executed: false
db_store_enabled: false
compatibility_alias_approved: false
```

## Validation

```text
point_gateway_ai_log_table_naming_decision_assert
core_settlement_backend_package_assert
```
