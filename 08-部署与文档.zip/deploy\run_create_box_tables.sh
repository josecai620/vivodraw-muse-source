#!/usr/bin/env bash
# 在服务器上执行：创建开盒记录相关表及菜单
# 用法：bash deploy/run_create_box_tables.sh
# 或从本机：ssh root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/run_create_box_tables.sh"
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/opt/crmeb-prod}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SQL_FILE="${SCRIPT_DIR}/create_box_tables_and_menu.sql"

# 从 deploy env 或 backend .env 获取数据库配置
for envf in "${PROJECT_DIR}/deploy/.deploy.env" "${PROJECT_DIR}/deploy/.env" "${PROJECT_DIR}/.env" "${PROJECT_DIR}/backend_src/.env"; do
  if [[ -f "${envf}" ]]; then
    set -a
    # shellcheck disable=SC1090
    source "${envf}" 2>/dev/null || true
    set +a
    break
  fi
done

MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-${MYSQL_PASSWORD:-${PASSWORD:-}}}"
MYSQL_DATABASE="${MYSQL_DATABASE:-${DATABASE:-}}"

if [[ -z "${MYSQL_ROOT_PASSWORD}" || -z "${MYSQL_DATABASE}" ]]; then
  echo "请设置 MYSQL_ROOT_PASSWORD 和 MYSQL_DATABASE"
  echo "或手动执行: docker exec -i crmeb-mysql mysql -uroot -p<密码> <数据库名> < ${SQL_FILE}"
  exit 1
fi

if [[ ! -f "${SQL_FILE}" ]]; then
  echo "未找到 ${SQL_FILE}"
  exit 1
fi

MYSQL_CONTAINER=$(docker ps --format '{{.Names}}' | grep -i mysql | head -1)
[[ -z "$MYSQL_CONTAINER" ]] && MYSQL_CONTAINER="crmeb-mysql"

echo "==> 创建开盒记录表及菜单 (数据库: ${MYSQL_DATABASE}, 容器: ${MYSQL_CONTAINER})"
docker exec -i "$MYSQL_CONTAINER" mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" "${MYSQL_DATABASE}" < "${SQL_FILE}"
echo "==> 完成。请刷新后台，在「商品」下查看「开盒记录」"
