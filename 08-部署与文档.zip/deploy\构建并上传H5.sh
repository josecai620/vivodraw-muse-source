#!/usr/bin/env bash
# 一键：构建 H5（npm）并上传到服务器。无需再在 HBuilderX 里手动发行。
# 用法：在项目根目录执行  bash deploy/构建并上传H5.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
UNIAPP_DIR="${PROJECT_ROOT}/backend_src/view/uniapp"
H5_OUT_DIR="${UNIAPP_DIR}/unpackage/dist/build/h5"

echo "==> 1/2 构建 H5（npm run build:h5）..."
cd "${UNIAPP_DIR}"
npm run build:h5

if [[ ! -d "${H5_OUT_DIR}" ]] || [[ ! -f "${H5_OUT_DIR}/index.html" ]]; then
  echo "❌ 构建产物未找到：${H5_OUT_DIR}"
  exit 1
fi

echo ""
echo "==> 2/2 上传 H5 到服务器..."
export H5_OUTPUT="${H5_OUT_DIR}"
bash "${SCRIPT_DIR}/上传H5到服务器.sh"

echo ""
echo "✅ 构建并上传完成。请用手机浏览器访问 https://你的域名/ 或 /static/html/pc.html 验证。"
