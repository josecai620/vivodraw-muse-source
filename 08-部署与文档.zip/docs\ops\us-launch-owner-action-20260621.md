# VivoDraw 美国推广上线检查

状态核对日期：2026-10-21

本文替换 2026-06-21 的旧入口检查结论。生产地址和公开推广结论以本次核对与现行 `deploy/ops/` 检查为准；没有生产配置、DNS、数据库或服务器改动。

## 当前证据

- **公共入口**：本次 Windows 环境访问 `https://vivodraw.com` 时 TLS 握手失败，无法确认线上首页和 JS 入口是否正常。这不能证明网站宕机；需要从另一条可访问网络再验首页、`/_expo/static/js/web/entry-*.js` 和 `/api/category`。
- **DNS 邮件记录**：系统 DNS 返回 MX `mxbiz2.qq.com`、`mxbiz1.qq.com`，SPF `include:spf.mail.qq.com`，DMARC `p=none`。本环境无法解析 Google/Cloudflare DoH 域名，因此 DoH 闸门结果为“未验证”；发件服务、DKIM 对齐和验证码送达仍未知。
- **注册和推荐**：v4 注册表单已连接邮箱验证码及现有 `spread` 注册字段；尚未从线上完成真实邮件注册验收。
- **结账信任**：购物车显示 `$50` 以下订单运费 `$5.99`，结账页显示免费运费并按 `$0` 计算。获客信任检查会阻止推广，直到实际规则得到确认并统一。
- **渠道归因**：推荐 UID 可关联推荐注册；UTM 目前不会与账号或订单关联，分析服务尚未配置。
- **素材**：以素材权利台账为准；未核实权利的商品/品牌素材不能公开发布。

## 推广前只读闸门

```bash
bash deploy/ops/check_us_public_launch_readiness.sh
bash deploy/ops/vivodraw_daily_ops_report.sh
```

获客邮件检查：

```bash
DOMAIN=vivodraw.com bash deploy/ops/check_us_lead_capture_readiness.sh
```

若当前环境无法访问 DoH，结果会保持未验证并阻断邮件获客；不要把解析失败当成 DNS 记录不存在，也不要手写供应商 DNS 记录。

## 负责人待办

1. 从可访问生产域名的网络确认公共首页、主 JS 和分类 API 均可用。
2. 确认 `support@vivodraw.com` 和验证码实际使用的邮件服务商；按供应商控制台校准 MX、SPF、DKIM，并完成验证码送达测试。
3. 决定正式运费规则，再由负责人安排购物车、结账和后端价格显示的一致性修复。
4. 若要按渠道统计注册/订单，先确定分析服务与隐私说明，再实施 UTM 到账号/订单的关联。
5. 清理上线工作区中的无关改动，并核实公开素材权利后，再评估自然流量或付费推广。

未完成以上检查前，不启动付费投放或公开代理招募；内容实验保持内部审核状态。
