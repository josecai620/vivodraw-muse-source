-- ============================================================
-- 宠物客服 Pet Assistant：6 张表 + 预置种子数据
-- 执行：mysql -u crmeb -p manghehoutai_qhe < create_pet_kefu_tables.sql
-- 幂等：IF NOT EXISTS 建表；种子数据只在表为空时插入
-- ============================================================
SET NAMES utf8mb4;

-- ===================== 1. eb_pet_config（KV 配置） =====================
CREATE TABLE IF NOT EXISTS `eb_pet_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cfg_key` varchar(64) NOT NULL DEFAULT '' COMMENT '配置键',
  `cfg_value` text NULL COMMENT '配置值（JSON 或字符串）',
  `cfg_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型 1=string 2=json 3=bool 4=int',
  `comment` varchar(255) NOT NULL DEFAULT '' COMMENT '说明',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cfg_key` (`cfg_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='宠物客服配置KV';

-- ===================== 2. eb_pet_faq（FAQ 知识库） =====================
CREATE TABLE IF NOT EXISTS `eb_pet_faq` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL DEFAULT '' COMMENT '分类: navigation/purchase/points/group_lottery/box/farm/mining/other',
  `question` varchar(255) NOT NULL DEFAULT '' COMMENT '主问题',
  `keywords` varchar(500) NOT NULL DEFAULT '' COMMENT '关键词逗号分隔',
  `answer` text NOT NULL COMMENT '答案（支持简 Markdown）',
  `quick_replies` varchar(1000) NOT NULL DEFAULT '' COMMENT 'JSON 数组：[{text,action,value}]',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0停用1启用',
  `hit_count` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '命中次数',
  `lang` varchar(10) NOT NULL DEFAULT 'zh-TW' COMMENT 'zh-TW/en',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_status_sort` (`status`, `sort`),
  KEY `idx_category` (`category`),
  KEY `idx_lang` (`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='宠物客服FAQ';

-- ===================== 3. eb_pet_flow（引导流程） =====================
CREATE TABLE IF NOT EXISTS `eb_pet_flow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '流程标题',
  `trigger_words` varchar(500) NOT NULL DEFAULT '' COMMENT '触发关键词',
  `page_url` varchar(200) NOT NULL DEFAULT '*' COMMENT '页面路径，支持通配',
  `steps` text NOT NULL COMMENT 'JSON: [{selector,title,desc,placement}]',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_status_sort` (`status`, `sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='宠物客服引导流程';

-- ===================== 4. eb_pet_trigger（主动气泡触发） =====================
CREATE TABLE IF NOT EXISTS `eb_pet_trigger` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `page_url` varchar(200) NOT NULL DEFAULT '*' COMMENT '页面路径，支持通配',
  `condition_type` varchar(20) NOT NULL DEFAULT 'stay_seconds' COMMENT 'first_visit/stay_seconds/scroll/idle',
  `condition_value` varchar(100) NOT NULL DEFAULT '' COMMENT '数值或参数',
  `bubble_text` varchar(255) NOT NULL DEFAULT '',
  `action` varchar(500) NOT NULL DEFAULT '' COMMENT 'JSON: {type,value}',
  `priority` int(11) NOT NULL DEFAULT '100',
  `cooldown_hours` int(11) NOT NULL DEFAULT '24',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_status_priority` (`status`, `priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='宠物客服主动气泡触发';

-- ===================== 5. eb_pet_session（会话） =====================
CREATE TABLE IF NOT EXISTS `eb_pet_session` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '0=游客',
  `client_id` varchar(64) NOT NULL DEFAULT '' COMMENT '设备指纹',
  `lang` varchar(10) NOT NULL DEFAULT 'zh-TW',
  `page_url` varchar(200) NOT NULL DEFAULT '',
  `user_agent` varchar(255) NOT NULL DEFAULT '',
  `msg_count` int(11) unsigned NOT NULL DEFAULT '0',
  `cost_cents` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '累计费用(分)',
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_last_time` (`last_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='宠物客服会话';

-- ===================== 6. eb_pet_message（消息） =====================
CREATE TABLE IF NOT EXISTS `eb_pet_message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_id` int(11) unsigned NOT NULL DEFAULT '0',
  `role` varchar(20) NOT NULL DEFAULT 'user' COMMENT 'user/assistant',
  `msg_type` varchar(20) NOT NULL DEFAULT 'text' COMMENT 'text/faq/flow/ai',
  `content` text NOT NULL,
  `match_source` varchar(30) NOT NULL DEFAULT '' COMMENT 'faq:123 / flow:5 / ai',
  `tokens_in` int(11) unsigned NOT NULL DEFAULT '0',
  `tokens_out` int(11) unsigned NOT NULL DEFAULT '0',
  `cost_cents` int(11) unsigned NOT NULL DEFAULT '0',
  `helpful` tinyint(1) NULL DEFAULT NULL COMMENT 'NULL未评 1有用 0无用',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_session` (`session_id`),
  KEY `idx_add_time` (`add_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='宠物客服消息';


-- ============================================================
-- 预置配置（幂等：INSERT IGNORE）
-- ============================================================
INSERT IGNORE INTO `eb_pet_config` (`cfg_key`, `cfg_value`, `cfg_type`, `comment`, `update_time`) VALUES
('enabled',              '1',                                                                   3, '是否启用宠物客服', UNIX_TIMESTAMP()),
('mascot_name',          '小豆',                                                                1, '宠物昵称',         UNIX_TIMESTAMP()),
('mascot_image',         'https://api.dicebear.com/7.x/bottts/png?seed=xiaodou',               1, '宠物头像URL',      UNIX_TIMESTAMP()),
('welcome_text',         'Hi! 我是小豆，有什么能帮你的？点我问问题 👋',                           1, '欢迎语',           UNIX_TIMESTAMP()),
('enable_ai_fallback',   '1',                                                                   3, '未命中FAQ时是否调用AI', UNIX_TIMESTAMP()),
('provider',             'claude',                                                              1, 'AI 服务商：claude / openai_compatible（Kimi等）', UNIX_TIMESTAMP()),
('api_base_url',         '',                                                                    1, 'openai_compatible 时的 API Base URL（留空默认 Kimi）', UNIX_TIMESTAMP()),
('model',                'claude-sonnet-4-5-20250929',                                          1, '模型名',    UNIX_TIMESTAMP()),
('max_tokens',           '512',                                                                 4, 'AI 单次最大token', UNIX_TIMESTAMP()),
('daily_call_limit',     '50',                                                                  4, '单用户每日AI调用上限', UNIX_TIMESTAMP()),
('claude_api_key',       '',                                                                    1, 'Claude API Key（后台填写，前端不回传）', UNIX_TIMESTAMP()),
('system_prompt_extra',  '',                                                                    1, '附加 system prompt（可选）', UNIX_TIMESTAMP()),
('kefu_handover_url',    '/profile/service',                                                    1, '转人工入口URL',    UNIX_TIMESTAMP());


-- ============================================================
-- 预置 FAQ 种子（只在 faq 表为空时插入）
-- ============================================================
INSERT INTO `eb_pet_faq` (`category`,`question`,`keywords`,`answer`,`quick_replies`,`sort`,`status`,`lang`,`add_time`,`update_time`)
SELECT * FROM (SELECT
 'navigation' AS `category`,
 '网站有哪些功能？' AS `question`,
 '网站,功能,有什么,能干嘛,介绍' AS `keywords`,
 '本站主要有 **积分商城、盲盒、拼团抽奖、农场、挖矿** 五大玩法 🎉\n\n- 积分商城：用积分换商品\n- 盲盒：开盒抽奖品\n- 拼团抽奖：组团参与超值抽奖\n- 农场/挖矿：边玩边攒积分' AS `answer`,
 '[{"text":"带我看盲盒","action":"navigate","value":"/box"},{"text":"积分怎么拿","action":"faq","value":"积分怎么拿"},{"text":"拼团抽奖怎么玩","action":"faq","value":"拼团抽奖怎么玩"}]' AS `quick_replies`,
 10 AS `sort`, 1 AS `status`, 'zh-TW' AS `lang`, UNIX_TIMESTAMP() AS `add_time`, UNIX_TIMESTAMP() AS `update_time`
) t WHERE NOT EXISTS (SELECT 1 FROM `eb_pet_faq` LIMIT 1);

INSERT INTO `eb_pet_faq` (`category`,`question`,`keywords`,`answer`,`quick_replies`,`sort`,`status`,`lang`,`add_time`,`update_time`) VALUES
('points',       '积分怎么拿？',           '积分,怎么拿,赚积分,获得,来源',
 '获取积分主要有 3 种方式：\n1. **每日签到** —— 连续签到积分翻倍\n2. **购买商品** —— 消费返积分\n3. **农场/挖矿** —— 每日任务领取\n4. **活动赠送** —— 新人注册/邀请好友',
 '[{"text":"去签到","action":"navigate","value":"/points"},{"text":"去农场","action":"navigate","value":"/farm"}]',
 20, 1, 'zh-TW', UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),

('points',       '积分怎么用？',           '积分,怎么用,兑换,消费,花',
 '积分可以用来：\n- **积分商城兑换商品**（积分专区）\n- **抵扣购买价格**（结算时可用）\n- **参与积分拼团抽奖**（更高中奖概率）',
 '[{"text":"去积分商城","action":"navigate","value":"/points"}]',
 30, 1, 'zh-TW', UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),

('box',          '怎么开盲盒？',           '盲盒,怎么开,开盒,开箱,买盲盒',
 '开盲盒 4 步走：\n1. 进入 **盲盒专区**\n2. 选一个喜欢的盒子分类\n3. 点"立即开盒"\n4. 收到稀有度奖品，可选"留下发货"或"回收换积分" 🎁',
 '[{"text":"带我开盒","action":"start_flow","value":"box_flow"},{"text":"去看盲盒","action":"navigate","value":"/box"}]',
 40, 1, 'zh-TW', UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),

('group_lottery','拼团抽奖怎么玩？',        '拼团,抽奖,拼购,拼团抽奖,怎么玩',
 '拼团抽奖 = 拼团 + 开奖：\n1. **选商品**（积分/美元两种定价）\n2. **开团或加入团**\n3. **人满开奖**：1 人中奖拿商品，其他人全额退款 + 额外奖励 %',
 '[{"text":"带我了解","action":"start_flow","value":"group_lottery_flow"},{"text":"去逛逛","action":"navigate","value":"/group-lottery"}]',
 50, 1, 'zh-TW', UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),

('purchase',     '怎么购买？',             '购买,下单,买,怎么买,流程',
 '购买流程：\n1. 浏览商品 → 加购或直接购买\n2. 填写收货地址\n3. 选择支付方式（积分 / 美元）\n4. 确认订单 → 等待发货 📦',
 '[{"text":"去购物","action":"navigate","value":"/"}]',
 60, 1, 'zh-TW', UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),

('navigation',   '现在有什么活动？',        '活动,优惠,赠送,促销,福利',
 '当前福利：\n🎁 **新人注册送积分**\n🎁 **每日签到累积奖励**\n🎁 **邀请好友双方得积分**\n🎁 **拼团抽奖未中奖者额外奖励%**\n具体活动请看首页 Banner。',
 '[{"text":"去看首页","action":"navigate","value":"/"}]',
 70, 1, 'zh-TW', UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),

('other',        '怎么联系人工客服？',      '人工,客服,真人,帮助,投诉',
 '我暂时解决不了的问题可以点下面按钮找人工客服哦 👇',
 '[{"text":"联系人工客服","action":"navigate","value":"/profile/service"}]',
 80, 1, 'zh-TW', UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),

('other',        '收货地址怎么填？',        '收货,地址,填写,怎么填,改地址',
 '在"我的 → 收货地址"里新增或编辑地址，**下单前请先设置一个默认地址**。',
 '[{"text":"去设置地址","action":"navigate","value":"/profile"}]',
 90, 1, 'zh-TW', UNIX_TIMESTAMP(), UNIX_TIMESTAMP());


-- 英文 FAQ（基础版）
INSERT INTO `eb_pet_faq` (`category`,`question`,`keywords`,`answer`,`quick_replies`,`sort`,`status`,`lang`,`add_time`,`update_time`) VALUES
('navigation',   'What can I do on this site?',  'features,what,intro',
 'This site offers **Points Mall, Blind Box, Group Lottery, Farm, Mining** — earn points, open boxes, join group draws, play & earn 🎉',
 '[{"text":"Open a box","action":"navigate","value":"/box"},{"text":"Earn points","action":"faq","value":"How to earn points"}]',
 10, 1, 'en', UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),

('points',       'How to earn points?',           'earn points,get points',
 '3 ways to earn: 1) Daily check-in 2) Purchase cashback 3) Farm/Mining daily tasks 4) Event rewards.',
 '[{"text":"Check in","action":"navigate","value":"/points"}]',
 20, 1, 'en', UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),

('box',          'How to open a blind box?',      'blind box,open,how',
 '4 steps: 1) Go to Blind Box. 2) Pick a category. 3) Click "Open". 4) Get a rare item — ship it or recycle for points 🎁',
 '[{"text":"Tour","action":"start_flow","value":"box_flow"}]',
 40, 1, 'en', UNIX_TIMESTAMP(), UNIX_TIMESTAMP());


-- ============================================================
-- 预置 Flow 种子
-- ============================================================
-- 注：CSS attribute selector 使用 [attr='val'] 语法（单引号），避免 MySQL 字符串
-- 内部双引号转义复杂性。SQL 里 '' 代表一个单引号字面量。
INSERT INTO `eb_pet_flow` (`title`, `trigger_words`, `page_url`, `steps`, `sort`, `status`, `add_time`)
SELECT * FROM (SELECT
 '开盲盒 4 步教程' AS `title`,
 'box_flow,开盲盒教程,盲盒教程' AS `trigger_words`,
 '/box' AS `page_url`,
 '[{"selector":"[data-tour=''box-category'']","title":"第 1 步：选分类","desc":"挑一个你喜欢的盒子分类","placement":"bottom"},{"selector":"[data-tour=''box-open-btn'']","title":"第 2 步：开盒","desc":"点这里立即开盒","placement":"top"},{"selector":"[data-tour=''box-reveal'']","title":"第 3 步：查看奖品","desc":"看看你抽到什么","placement":"left"},{"selector":"[data-tour=''box-action'']","title":"第 4 步：留下/回收","desc":"选择发货或换积分","placement":"top"}]' AS `steps`,
 10 AS `sort`, 1 AS `status`, UNIX_TIMESTAMP() AS `add_time`
) t WHERE NOT EXISTS (SELECT 1 FROM `eb_pet_flow` LIMIT 1);

INSERT INTO `eb_pet_flow` (`title`, `trigger_words`, `page_url`, `steps`, `sort`, `status`, `add_time`) VALUES
('拼团抽奖 3 步教程', 'group_lottery_flow,拼团抽奖教程', '/group-lottery',
 '[{"selector":"[data-tour=''gl-product'']","title":"第 1 步：选商品","desc":"选一个你想拼的抽奖商品","placement":"bottom"},{"selector":"[data-tour=''gl-join'']","title":"第 2 步：加入团","desc":"开团或加入现有团","placement":"top"},{"selector":"[data-tour=''gl-result'']","title":"第 3 步：等开奖","desc":"人满自动开奖，未中也有奖励","placement":"top"}]',
 20, 1, UNIX_TIMESTAMP()),
('积分兑换 3 步教程', 'points_flow,积分兑换教程', '/points',
 '[{"selector":"[data-tour=''pt-list'']","title":"第 1 步：选商品","desc":"浏览积分专区","placement":"bottom"},{"selector":"[data-tour=''pt-redeem'']","title":"第 2 步：兑换","desc":"点立即兑换","placement":"top"},{"selector":"[data-tour=''pt-address'']","title":"第 3 步：填地址","desc":"确认收货地址提交","placement":"top"}]',
 30, 1, UNIX_TIMESTAMP());


-- ============================================================
-- 预置 Trigger 种子
-- ============================================================
INSERT INTO `eb_pet_trigger` (`page_url`, `condition_type`, `condition_value`, `bubble_text`, `action`, `priority`, `cooldown_hours`, `status`, `add_time`)
SELECT * FROM (SELECT
 '/' AS `page_url`,
 'stay_seconds' AS `condition_type`,
 '8' AS `condition_value`,
 '第一次来？我带你逛一圈 👋' AS `bubble_text`,
 '{"type":"open_chat","value":"新手指南"}' AS `action`,
 100 AS `priority`, 24 AS `cooldown_hours`, 1 AS `status`, UNIX_TIMESTAMP() AS `add_time`
) t WHERE NOT EXISTS (SELECT 1 FROM `eb_pet_trigger` LIMIT 1);

INSERT INTO `eb_pet_trigger` (`page_url`, `condition_type`, `condition_value`, `bubble_text`, `action`, `priority`, `cooldown_hours`, `status`, `add_time`) VALUES
('/box',            'first_visit', '',  '要不要一步步教你开盒？', '{"type":"start_flow","value":"box_flow"}',            90,  24, 1, UNIX_TIMESTAMP()),
('/group-lottery',  'first_visit', '',  '拼团抽奖规则看我介绍 👀',  '{"type":"start_flow","value":"group_lottery_flow"}',  90,  24, 1, UNIX_TIMESTAMP()),
('/points',         'stay_seconds','10','积分不知道怎么用？我来告诉你',   '{"type":"open_chat","value":"积分怎么用"}',            80,  24, 1, UNIX_TIMESTAMP());


-- ============================================================
-- 验证
-- ============================================================
SELECT '=== 表 ===' AS info;
SELECT table_name, table_rows FROM information_schema.tables
  WHERE table_schema = DATABASE() AND table_name LIKE 'eb_pet_%';

SELECT '=== 配置项 ===' AS info;
SELECT cfg_key, LEFT(cfg_value, 40) AS val_preview, cfg_type FROM eb_pet_config ORDER BY id;

SELECT '=== FAQ 条数 ===' AS info;
SELECT lang, COUNT(*) AS cnt FROM eb_pet_faq GROUP BY lang;

SELECT '=== Flow / Trigger ===' AS info;
SELECT COUNT(*) AS flow_count FROM eb_pet_flow;
SELECT COUNT(*) AS trigger_count FROM eb_pet_trigger;
