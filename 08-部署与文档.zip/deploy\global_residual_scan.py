# -*- coding: utf-8 -*-
"""全局换皮残留扫描：JSX/字符串字面量里的 emoji、离群硬编码色、暗场底。"""
import glob, re, collections, os

os.chdir(r'D:\eccomall\mobile-app')

EMOJI = re.compile(r'[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF]')
HEX = re.compile(r'#([0-9A-Fa-f]{6})\b')

# 方向 C 合法色板（含中性阶梯、语义色）
ALLOWED = {
    '04A8AE','33C6CC','07858C','08AEB4','7FD8DC','D6F4F5','ECFBFB','E6F7F8','078E93',
    '171A1A','2C2E2D','4A4A48','5E5F5E','787976','919290','AAAAA8','C0C0BE',
    'FFFFFF','F5F7F7','F7F9F9','F6F8F8','EBEEEE','EDEFF0','F0F2F2','ECEFEF',
    '0C1F1F','EF4444','FF3B30','22C55E','16A34A','F59E0B','EAB308','000000',
}
# 语义色（成功绿/警告琥珀/危险红）允许出现的文件关键词白名单外仍需人工看
DARK_BG = re.compile(r'backgroundColor\s*:\s*["\']#(0[0-9A-Fa-f]{5}|1[0-6][0-9A-Fa-f]{4}|2[0-3][0-9A-Fa-f]{4})["\']')

emoji_hits = collections.defaultdict(list)
color_hits = collections.defaultdict(collections.Counter)
dark_hits = collections.defaultdict(list)

for f in glob.glob(r'app/**/*.tsx', recursive=True):
    for i, line in enumerate(open(f, encoding='utf-8'), 1):
        code = line.split('//')[0]
        if EMOJI.search(code):
            # 只报 JSX 文本或字符串字面量中的 emoji，不报注释/正则
            if re.search(r'>[^<{}]*[\U0001F000-\U0001FAFF\u2600-\u27BF]', code) or \
               re.search(r'["\'][^"\']*[\U0001F000-\U0001FAFF\u2600-\u27BF]', code):
                emoji_hits[f].append((i, line.strip()[:100]))
        for m in HEX.finditer(code):
            c = m.group(1).upper()
            if c not in ALLOWED:
                color_hits[f][c] += 1
        if DARK_BG.search(code):
            dark_hits[f].append((i, line.strip()[:100]))

print('=== EMOJI 残留：%d 文件' % len(emoji_hits))
for f, v in emoji_hits.items():
    print(f.replace('\\', '/'), 'x%d' % len(v))
    for x in v[:3]:
        print('   L%d %s' % x)

print()
print('=== 离群硬编码色：%d 文件' % len(color_hits))
for f, cc in sorted(color_hits.items()):
    print(f.replace('\\', '/'), dict(cc))

print()
print('=== 深色背景嫌疑：%d 文件' % len(dark_hits))
for f, v in dark_hits.items():
    print(f.replace('\\', '/'), 'x%d' % len(v))
    for x in v[:3]:
        print('   L%d %s' % x)
