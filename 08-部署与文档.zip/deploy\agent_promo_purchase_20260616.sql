-- Agent purchase request workflow for VivoDraw medal marketing credits.
-- Scope: additive table only. Run after agent_promo_wallet_20260616.sql.
-- Safe to run more than once.

CREATE TABLE IF NOT EXISTS `eb_agent_promo_purchase_request` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `request_no` varchar(64) NOT NULL DEFAULT '' COMMENT 'Stable purchase request number',
  `agent_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Agent user uid',
  `package_code` varchar(64) NOT NULL DEFAULT '' COMMENT 'Requested medal package code',
  `package_name` varchar(120) NOT NULL DEFAULT '' COMMENT 'Package name snapshot',
  `medal_level` varchar(32) NOT NULL DEFAULT '' COMMENT 'Medal level snapshot',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT 'Package sale price snapshot',
  `promo_points` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Marketing credits to add after approval',
  `status` varchar(16) NOT NULL DEFAULT 'pending' COMMENT 'pending, approved, rejected, cancelled',
  `payment_method` varchar(32) NOT NULL DEFAULT 'manual' COMMENT 'manual until automated payments are enabled',
  `payment_reference` varchar(120) NOT NULL DEFAULT '' COMMENT 'Invoice, wire, check, or external payment reference',
  `client_request_id` varchar(64) DEFAULT NULL COMMENT 'Agent-side idempotency key',
  `agent_note` varchar(500) NOT NULL DEFAULT '' COMMENT 'Agent payment/contact note',
  `admin_note` varchar(500) NOT NULL DEFAULT '' COMMENT 'Admin confirmation note',
  `ledger_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'agent_promo_ledger id after approval',
  `operator_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Admin uid for approval/rejection',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_agent_promo_purchase_request_no` (`request_no`),
  UNIQUE KEY `uk_agent_promo_purchase_client_request` (`agent_uid`,`client_request_id`),
  KEY `idx_agent_promo_purchase_agent_status` (`agent_uid`,`status`,`id`),
  KEY `idx_agent_promo_purchase_status_time` (`status`,`add_time`,`id`),
  KEY `idx_agent_promo_purchase_package` (`package_code`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Agent medal package purchase requests';
