-- Compatibility fix for legacy reveal queries.
--
-- IMPORTANT:
-- Do not drop `eb_store_product_kaijiang_log` blindly. Production may still use
-- it as a real base table. This script only creates a compatibility view when
-- the old table name is absent and the newer table exists.

SET @schema_name = DATABASE();

SET @old_log_base_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
  WHERE TABLE_SCHEMA = @schema_name
    AND TABLE_NAME = 'eb_store_product_kaijiang_log'
    AND TABLE_TYPE = 'BASE TABLE'
);
SET @old_log_any_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
  WHERE TABLE_SCHEMA = @schema_name
    AND TABLE_NAME = 'eb_store_product_kaijiang_log'
);
SET @new_log_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
  WHERE TABLE_SCHEMA = @schema_name
    AND TABLE_NAME = 'eb_store_integral_product_kaijiang_log'
);

SET @sql = CASE
  WHEN @old_log_base_exists > 0 THEN 'SELECT ''skip: eb_store_product_kaijiang_log is a base table'''
  WHEN @new_log_exists = 0 THEN 'SELECT ''skip: eb_store_integral_product_kaijiang_log missing'''
  WHEN @old_log_any_exists = 0 THEN 'CREATE VIEW eb_store_product_kaijiang_log AS SELECT * FROM eb_store_integral_product_kaijiang_log'
  ELSE 'SELECT ''skip: eb_store_product_kaijiang_log already exists'''
END;
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @old_shaidan_base_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
  WHERE TABLE_SCHEMA = @schema_name
    AND TABLE_NAME = 'eb_store_product_kaijiang_shaidan'
    AND TABLE_TYPE = 'BASE TABLE'
);
SET @old_shaidan_any_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
  WHERE TABLE_SCHEMA = @schema_name
    AND TABLE_NAME = 'eb_store_product_kaijiang_shaidan'
);
SET @new_shaidan_exists = (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
  WHERE TABLE_SCHEMA = @schema_name
    AND TABLE_NAME = 'eb_store_integral_product_kaijiang_shaidan'
);

SET @sql = CASE
  WHEN @old_shaidan_base_exists > 0 THEN 'SELECT ''skip: eb_store_product_kaijiang_shaidan is a base table'''
  WHEN @new_shaidan_exists = 0 THEN 'SELECT ''skip: eb_store_integral_product_kaijiang_shaidan missing'''
  WHEN @old_shaidan_any_exists = 0 THEN 'CREATE VIEW eb_store_product_kaijiang_shaidan AS SELECT * FROM eb_store_integral_product_kaijiang_shaidan'
  ELSE 'SELECT ''skip: eb_store_product_kaijiang_shaidan already exists'''
END;
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
