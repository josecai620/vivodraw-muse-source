# 项目交接 - Opus 4.6 Max 主力开发说明

> **定位**：你是本系统的**主力开发 AI**。Mac 侧助手仅做交接与收尾，具体开发均由你负责。

---

## 一、项目概览

| 项 | 值 |
|----|-----|
| 仓库 | https://gitee.com/caiweizhou/eccomall |
| 分支 | `assist/mobile-batch-01` |
| 服务器 | 8.166.115.27，路径 `/opt/crmeb-prod` |
| 数据库 | manghehoutai_qhe，表前缀 `eb_` |

**技术栈**：
- 后端：PHP 8.1（ThinkPHP 6）+ MySQL + Redis
- 后台管理：Vue2（`backend_src/view/admin/`）
- 用户前台：Expo / React Native Web（`mobile-app/`）
- 旧 Uniapp H5 已弃用，勿再部署

---

## 二、目录与职责

```
eccomall/
├── backend_src/                 # PHP 后端
│   ├── app/
│   │   ├── controller/
│   │   │   ├── admin/           # 后台接口（需登录）
│   │   │   └── api/             # 用户端 API（/api/xxx）
│   │   ├── services/            # 业务逻辑
│   │   ├── dao/                 # 数据访问
│   │   └── route/               # 路由定义
│   ├── public/                  # 入口、静态资源、已构建的 admin/、_expo/
│   └── view/
│       ├── admin/               # Vue2 后台源码
│       └── supplier/            # 供应商端
├── mobile-app/                  # Expo 用户端源码
│   ├── app/                     # 页面（file-based routing）
│   ├── components/
│   ├── lib/api/                 # API 封装
│   └── constants/api.ts         # API 基址、端点
├── deploy/                      # 部署脚本（必读）
└── docs/                        # 文档
```

---

## 三、核心业务概念

### 1. 商城类型（mall_type）
- `0` = 常规商城
- `2` = 盲盒商城
商品、订单、分类等需按 `mall_type` 过滤，避免数据串线。

### 2. 积分商城（store_integral_*）
积分商城相关表：`store_integral_product`、`store_integral_order` 等。修改时注意与普通商品表的区分。

### 3. API 鉴权
- 用户端：`Authorization: Bearer <token>`
- 后台：Session/Cookie，登录后访问 `/adminapi/xxx`

---

## 四、前后端对照

| 前端 | 后端入口 | 说明 |
|------|----------|------|
| mobile-app（Expo） | `app/controller/api/` | 用户端接口 `/api/xxx` |
| view/admin（Vue2） | `app/controller/admin/` | 后台接口 `/adminapi/xxx` |

**API 基址**：`mobile-app/constants/api.ts` 中 `API_BASE_URL`，默认 `8.166.115.27`。

**接口契约**：见 `mobile-app/M1_接口契约快照_v1.md`。

---

## 五、部署流程（改了什么就执行对应命令）

| 改动类型 | 命令 |
|----------|------|
| 只改双语文案 | `bash deploy/同步双语到服务器public.sh` |
| 改 mobile-app（Expo） | `bash deploy/构建并上传前台Expo.sh` |
| 改 Admin（Vue2） | `bash deploy/本机构建并上传后台前端.sh` |
| 只改 PHP 后端 | `bash deploy/update_online.sh 8.166.115.27` |

**禁止**：勿执行 `构建并上传H5.sh`、`上传H5到服务器.sh`（旧 Uniapp 已断）。

**详细**：`deploy/前端修改-最少步骤（助手必读）.md`、`deploy/稳定性与发布清单.md`。

---

## 六、数据库

- **获取方式**：`bash deploy/从服务器导出数据库.sh 8.166.115.27`，导入本地。
  详见 `docs/数据库获取说明.md`。

- **常见表**：`eb_store_product`、`eb_store_order`、`eb_store_category`、`eb_system_config`、`eb_system_menus` 等。

- **开发环境**：`backend_src/.env` 配置 `DATABASE`、`USERNAME`、`PASSWORD`；可复制 `.example.env` 为 `.env`。

---

## 七、开发规范与注意事项

1. **跨端联调**：改 API 时同步检查 mobile-app、Admin 的调用与参数。
2. **mall_type 过滤**：商品、订单、分类等查询需加 `mall_type` 条件。
3. **store_integral_***：涉及积分商城时，确认表名与业务逻辑正确。
4. **缓存**：改菜单/配置后需清缓存：`php think clear` 或 `bash deploy/remote_clear_cache.sh`。
5. **Windows 脚本**：deploy 下的 `.sh` 需在 Git Bash 或 WSL 中运行。

---

## 八、首次参与：克隆 → 环境 → 开发

1. `git clone` → `git checkout assist/mobile-batch-01`
2. 按 `docs/Windows开发环境搭建.md` 配置 Node、PHP、MySQL、Redis
3. 按 `docs/数据库获取说明.md` 导出并导入数据库
4. 配置 `backend_src/.env`
5. 开始开发，改完按「五、部署流程」发布

---

## 九、相关文档索引

| 文档 | 用途 |
|------|------|
| `docs/Windows开发环境搭建.md` | 环境、依赖、常用命令 |
| `docs/数据库获取说明.md` | 数据库获取与导入 |
| `docs/Opus协作说明.md` | 与 Mac 侧协作方式 |
| `deploy/前端修改-最少步骤（助手必读）.md` | 前端发布步骤 |
| `deploy/稳定性与发布清单.md` | 发布清单与异常排查 |
| `mobile-app/M1_接口契约快照_v1.md` | API 契约 |

---

## 十、与 Mac 侧分工

- **Mac 侧**：交接、收尾、规则检查；不做主力开发。
- **你（Opus）**：全部功能开发、业务逻辑、前后端联调、部署验证。
- **协作**：共同分支 `assist/mobile-batch-01`，`git pull` → 修改 → `git push`。

---

## 十一、项目结构说明

项目已扁平化，`mobile-app/` 在项目根目录，无需额外同步。

---

## 十二、积分商城前后端对接进度（2026-03-17，勿覆盖）

> **重要警告**：以下功能均已开发完成并部署上线。新开发者接手时，**切勿回滚或覆盖**这些文件，否则会导致积分商城页面白屏崩溃。

### 已完成的功能对接

#### 1. 基础设施层（必须保留，不可删除）

| 文件 | 新增内容 | 用途 |
|------|---------|------|
| `constants/api.ts` | 15 个积分商城端点路径 | 订单确认/创建/删除、帮助中心、晒单详情/评论/点赞/发布、返现列表、兑换详情、确认地址、回收 |
| `lib/api/points.ts` | 15 个 API 调用函数 | 每个端点对应一个函数，如 `integralOrderConfirm`、`getShaidanDetail`、`getHuandeInfo` 等 |
| `hooks/usePoints.ts` | 15 个 React Hook | 如 `useIntegralOrderConfirm`、`useShaidanDetail`、`useHuandeInfo` 等 |
| `hooks/index.ts` | 上述 15 个 Hook 的导出 | 页面通过 `import { xxx } from "@/hooks"` 使用 |

**如果删除以上任何一个导出，以下页面将立刻白屏**：
- `points/confirm.tsx`、`points/help.tsx`、`points/help-detail.tsx`
- `points/cashback.tsx`、`points/review-detail.tsx`、`points/redemption-info.tsx`

#### 2. 页面级功能（已完成并上线）

| 页面文件 | 功能描述 | 对接的后端接口 |
|----------|---------|---------------|
| `points/orders.tsx` | 订单列表使用真实 API + 删除订单 | `/api/integral/order/list`、`/api/integral/order/del` |
| `points/reviews.tsx` | 晒单列表 + 发布晒单 + 点赞 + 我的晒单 | `/api/integral/shaidan_lists`、`shaidan_edit`、`shaidan_dianzhan`、`user_shaidan_lists` |
| `points/review-detail.tsx` | 晒单详情 + 评论 + 点赞 | `/api/integral/shaidan_detail`、`shaidan_detail_pinglun`、`shaidan_add_pinglun`、`shaidan_dianzhan` |
| `points/redemption-info.tsx` | 兑换详情 + 确认收货地址 + 回收换积分 | `/api/integral/huande_info`、`huande_info_address`、`huishou` |
| `points/confirm.tsx` | 积分订单确认 + 下单 | `/api/integral/order/confirm`、`/api/integral/order/create` |
| `points/help.tsx` / `help-detail.tsx` | 帮助中心列表与详情 | `/api/integral/help`、`help_detail` |
| `points/cashback.tsx` | 返现记录 | `/api/integral/user_fanxian_lists` |
| `points/me.tsx` | 积分个人中心（新增：我的晒单、返现记录、帮助分类入口） | 聚合页，无直接 API |
| `points/product.tsx` | 商品详情（全部改为 API 数据，无假数据） | `/api/store_integral/detail/:id` |
| `points/tasks.tsx` | 赚积分任务（签到数据从 API 获取） | `/api/sign/config` |
| `reveal/[id]/countdown.tsx` | 揭晓倒计时（商品信息从 API 获取） | `/api/integral/jiexiao_detail` |
| `reveal/[id]/result.tsx` | 揭晓结果（中奖信息从 API 获取） | `/api/integral/jiexiao_detail` |

#### 3. 第二批对接（2026-03-17 晚，完整闭环）

> 本批次将所有剩余后端接口全部对接到前端，积分商城业务完整闭环。

**基础设施层新增**：16 个端点 + 16 个 API 函数 + 16 个 Hook

| 页面文件 | 功能描述 | 对接的后端接口 |
|----------|---------|---------------|
| `points/wishlist.tsx` | 心愿单批量一键兑换 | `/api/integral/order/exchange_all` |
| `points/transfer.tsx` **（新建）** | 积分互转（余额转账/余额兑积分/积分转账） | `/api/integral/huzuan` |
| `(tabs)/points.tsx` | 弹窗活动推送（中奖通知） | `/api/integral/get_tanchuang` |
| `points/exchange-records.tsx` **（新建）** | 换取记录列表（全部/我的） | `/api/integral/hqjl_lists`、`user_hqjl_lists` |
| `points/exchange-record-detail.tsx` **（新建）** | 换取记录详情 | `/api/integral/hqjl_info` |
| `points/product.tsx` | 历史换取者 + 商品晒单 + 评价统计 | `detail_lshqz`、`detail_shaidan_list`、`reply/config` |
| `reveal/algorithm.tsx` **（新建）** | 揭晓算法计算详情 | `detail_jsxq`、`detail_jsxq_lists` |
| `reveal/[id]/result.tsx` | 新增"查看算法详情"按钮 | 导航到 `/reveal/algorithm` |
| `points/categories.tsx` | 新版分类+商品列表数据源 | `newcategory`、`newlist` |
| `points/checkin.tsx` | 签到月历视图（真实历史记录） | `/api/sign/month` |
| `points/me.tsx` | 新增"积分互转"和"换取记录"入口 | 聚合页 |
| `(tabs)/points.tsx` | 商品点击传 ID | 修复导航参数 |
| `points/categories.tsx` | 商品点击传 ID | 修复导航参数 |

#### 4. 保持静态内容的页面（无需对接后端）

| 页面 | 原因 |
|------|------|
| `points/rules.tsx` | 纯规则说明文本，后端无对应 API |
| `reveal/rules.tsx` | 揭晓规则说明，同上 |
| `points/help-categories.tsx` | 分类列表为静态 4 项，后端无独立分类列表接口 |

#### 5. 后端修复记录（2026-03-17 第三批）

以下后端缺陷已全部修复并上线验证通过：

| 修复项 | 原因 | 解决方案 | 涉及文件 |
|--------|------|----------|----------|
| `reply_list` / `reply_config` 404 | integral 控制器缺少这两个方法，路由指向空方法 | 从 store 控制器移植对应方法到 integral 控制器 | `StoreProductController.php` |
| `detail_shaidan_list` 使用未定义 `$where` | 原代码查 `store_product` 表且 `$where` 未赋值 | 改为查 `store_product_kaijiang_shaidan` 表，按 `product_id` 过滤，返回晒单详情+总数 | `StoreProductController.php` |
| `detail_love` 同样 `$where` 未定义 | 与上同因 | 补充 `$where` 定义 | `StoreProductController.php` |
| `detail_jsxq` 空数据崩溃 | 记录不存在时直接访问 null 数组导致 PHP 报错 | 添加空值守卫，记录不存在返回友好错误 | `StoreProductController.php` |
| `newlist` jindu_bili 未定义 | 查询 `store_product` 表但该表无 `jindu_bili` 字段 | 改为查询 `store_integral_product` 表 | `IntegralController.php` |
| `detail_hqjl` 表不存在 | 代码引用 `store_product_huanqu_log` 但实际表名为 `store_integral_product_huanqu_log` | 全局替换表名（含 `_unique` 后缀） | `StoreProductController.php`、`OrderController.php`、`Kaijiang.php`、`Jiqiren.php`、`Manghe.php` |
| 收藏列表 `jindu_bili` 报错 | `CollectController` JOIN `store_product` 访问不存在的字段 | 改为 JOIN `store_integral_product` | `CollectController.php` |

共修复 **7 个后端文件**，全部已部署并通过 API 验证。

### 新开发者注意事项

1. **不要删除 `hooks/index.ts` 中的任何导出**——每一个导出都对应至少一个页面的正常运行
2. **不要回滚 `constants/api.ts`**——里面的 31 个积分端点是积分商城正常运行的基础
3. **修改 `lib/api/points.ts` 或 `hooks/usePoints.ts` 时**，务必检查是否影响已上线功能
4. **部署前端时**，执行 `./deploy-frontend.sh` 即可
5. **前端改动文件清单**（共 21+ 个文件）：
   - 基础层：`constants/api.ts`、`lib/api/points.ts`、`hooks/usePoints.ts`、`hooks/index.ts`
   - 第一批页面：`app/points/orders.tsx`、`reviews.tsx`、`review-detail.tsx`、`redemption-info.tsx`、`confirm.tsx`、`help.tsx`、`help-detail.tsx`、`cashback.tsx`、`me.tsx`、`product.tsx`、`tasks.tsx`
   - 第二批页面：`app/points/transfer.tsx`、`exchange-records.tsx`、`exchange-record-detail.tsx`、`wishlist.tsx`、`checkin.tsx`、`categories.tsx`
   - 揭晓模块：`app/reveal/algorithm.tsx`、`app/reveal/[id]/result.tsx`、`app/reveal/[id]/countdown.tsx`
   - 主入口：`app/(tabs)/points.tsx`
6. **后端改动文件清单**（共 7 个文件）：
   - integral 控制器：`StoreProductController.php`、`IntegralController.php`、`OrderController.php`、`CollectController.php`
   - integral 监听器：`Kaijiang.php`、`Jiqiren.php`、`Manghe.php`

---

**以上为本系统开发所需的全部上下文。请优先阅读本文档，再根据需要查阅上述索引文档。**
