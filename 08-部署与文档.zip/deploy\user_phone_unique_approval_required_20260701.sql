-- VivoDraw user phone uniqueness hardening.
-- Approval required: do not auto-run from deploy scripts.
-- Purpose: enforce "one mobile number can belong to only one account" at DB level.
-- Preconditions:
--   1. Read-only duplicate check returns zero rows.
--   2. Application code with phone identity lock has already been deployed.
--   3. Run during a maintenance window and keep a DB backup.

-- Preflight: must return zero rows before applying the index.
SELECT phone, COUNT(*) AS account_count, GROUP_CONCAT(uid ORDER BY uid) AS uids
FROM eb_user
WHERE phone IS NOT NULL AND phone <> ''
GROUP BY phone
HAVING account_count > 1;

-- MySQL allows multiple NULL values in a UNIQUE index.
-- Existing app stores unbound phone as '', so use generated NULLIF(phone, '').
ALTER TABLE eb_user
  ADD COLUMN phone_identity_unique varchar(32)
    GENERATED ALWAYS AS (NULLIF(phone, '')) STORED;

CREATE UNIQUE INDEX uk_eb_user_phone_identity_unique
  ON eb_user (phone_identity_unique);

-- Verification: must return zero rows after applying.
SELECT phone_identity_unique, COUNT(*) AS account_count, GROUP_CONCAT(uid ORDER BY uid) AS uids
FROM eb_user
WHERE phone_identity_unique IS NOT NULL
GROUP BY phone_identity_unique
HAVING account_count > 1;

-- Rollback if needed:
-- DROP INDEX uk_eb_user_phone_identity_unique ON eb_user;
-- ALTER TABLE eb_user DROP COLUMN phone_identity_unique;
