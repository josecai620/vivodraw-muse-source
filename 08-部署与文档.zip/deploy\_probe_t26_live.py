# -*- coding: utf-8 -*-
import os, re, urllib.request

base = os.environ["TEMP"]
for name in ["t26-checkin.html", "t26-tasks.html"]:
    path = os.path.join(base, name)
    t = open(path, encoding="utf-8", errors="replace").read()
    js = re.findall(r"/_expo/static/js/web/(?:checkin|tasks|__common|entry)-[a-f0-9]+\.js", t)
    print(name, "len", len(t), "js", js[:8])

html = open(os.path.join(base, "t26-checkin.html"), encoding="utf-8", errors="replace").read()
js = sorted(set(re.findall(r"/_expo/static/js/web/(?:checkin|tasks|__common)-[a-f0-9]+\.js", html)))
out = os.path.join(base, "t26js")
os.makedirs(out, exist_ok=True)
keys = ["SignPrizeOpenOverlay", "pointsCheckin", "pointsTasks", "Daily Check-in", "Earn Points", "prizeReady"]
for p in js:
    dest = os.path.join(out, os.path.basename(p))
    urllib.request.urlretrieve("https://vivodraw.com" + p, dest)
    text = open(dest, encoding="utf-8", errors="replace").read()
    hits = [k for k in keys if k in text]
    print(os.path.basename(p), "size", os.path.getsize(dest), "hits", hits)
