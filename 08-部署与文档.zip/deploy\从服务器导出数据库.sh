#!/usr/bin/env bash
# 从线上服务器导出数据库到本地 db_backup/
# 用法: bash deploy/从服务器导出数据库.sh [服务器IP]
# 示例: bash deploy/从服务器导出数据库.sh 186.241.72.176
set -euo pipefail

SERVER_IP="${1:-186.241.72.176}"
SSH_USER="${2:-root}"
SSH_PORT="${3:-49375}"
REMOTE_DIR="/opt/crmeb-prod"
LOCAL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BACKUP_DIR="${LOCAL_ROOT}/db_backup"

mkdir -p "${BACKUP_DIR}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
REMOTE_FILE="/tmp/db_export_${TIMESTAMP}.sql.gz"
LOCAL_FILE="${BACKUP_DIR}/db_${TIMESTAMP}.sql.gz"

echo "==> 在服务器 ${SERVER_IP} 上导出数据库"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" bash -s "${REMOTE_FILE}" "${REMOTE_DIR}" << 'REMOTE_SCRIPT'
  REMOTE_FILE="$1"
  REMOTE_DIR="$2"
  set -euo pipefail

  get_ini() {
    local section="$1"
    local key="$2"
    local file="$3"
    awk -v section="$section" -v key="$key" '
      BEGIN { in_section=0 }
      /^\[/ { in_section = ($0 == "[" section "]"); next }
      in_section && $0 ~ "^[[:space:]]*" key "[[:space:]]*=" {
        sub(/^[^=]*=[[:space:]]*/, "");
        sub(/[[:space:]]*$/, "");
        print;
        exit;
      }
    ' "$file"
  }

  set -a
  [ -f "${REMOTE_DIR}/deploy/.env" ] && source "${REMOTE_DIR}/deploy/.env"
  [ -f "${REMOTE_DIR}/deploy/.deploy.env" ] && source "${REMOTE_DIR}/deploy/.deploy.env"
  set +a

  BACKEND_ENV="${REMOTE_DIR}/backend_src/.env"
  DB_HOST="$(get_ini DATABASE HOSTNAME "${BACKEND_ENV}" 2>/dev/null || true)"
  DB_NAME="$(get_ini DATABASE DATABASE "${BACKEND_ENV}" 2>/dev/null || true)"
  DB_USER="$(get_ini DATABASE USERNAME "${BACKEND_ENV}" 2>/dev/null || true)"
  DB_PASS="$(get_ini DATABASE PASSWORD "${BACKEND_ENV}" 2>/dev/null || true)"
  DB_PORT="$(get_ini DATABASE HOSTPORT "${BACKEND_ENV}" 2>/dev/null || true)"
  DB_CHARSET="$(get_ini DATABASE CHARSET "${BACKEND_ENV}" 2>/dev/null || true)"

  DB_HOST="${DB_HOST:-127.0.0.1}"
  DB_NAME="${DB_NAME:-${MYSQL_DATABASE:-manghehoutai_qhe}}"
  DB_USER="${DB_USER:-crmeb}"
  DB_PORT="${DB_PORT:-3306}"
  DB_CHARSET="${DB_CHARSET:-utf8mb4}"

  TMP_FILE="${REMOTE_FILE}.tmp"
  rm -f "${TMP_FILE}"

  if docker ps --format '{{.Names}}' | grep -qx 'crmeb-mysql'; then
    echo "==> 使用 Docker MySQL 容器导出: ${DB_NAME}"
    docker exec -e MYSQL_PWD="${MYSQL_ROOT_PASSWORD:-}" crmeb-mysql \
      mysqldump -uroot "${DB_NAME}" \
        --single-transaction --quick --no-tablespaces --default-character-set="${DB_CHARSET}" \
      | gzip -9 > "${TMP_FILE}"
  else
    echo "==> 使用 host MySQL 导出: ${DB_USER}@${DB_HOST}:${DB_PORT}/${DB_NAME}"
    MYSQL_PWD="${DB_PASS}" mysqldump -h"${DB_HOST}" -P"${DB_PORT}" -u"${DB_USER}" "${DB_NAME}" \
      --single-transaction --quick --no-tablespaces --default-character-set="${DB_CHARSET}" \
      | gzip -9 > "${TMP_FILE}"
  fi

  gzip -t "${TMP_FILE}"
  test -s "${TMP_FILE}"
  mv "${TMP_FILE}" "${REMOTE_FILE}"
REMOTE_SCRIPT

echo "==> 下载到本地 ${LOCAL_FILE}"
rsync -avz -e "ssh -p ${SSH_PORT}" \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_FILE}" \
  "${LOCAL_FILE}"

echo "==> 清理服务器临时文件"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" "rm -f ${REMOTE_FILE}" 2>/dev/null || true

echo "==> 完成"
echo "本地文件: ${LOCAL_FILE}"
echo "导入示例: gunzip -c ${LOCAL_FILE} | mysql -u root -p manghehoutai_qhe"
echo "或 Docker: gunzip -c ${LOCAL_FILE} | docker exec -i crmeb-mysql mysql -uroot -p<密码> manghehoutai_qhe"
