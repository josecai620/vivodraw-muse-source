#!/usr/bin/env bash
# Archive robot/test draw and box data before phase 7 cleanup.
# Usage: bash deploy/db_archive_robot_data_phase7.sh [server_ip] [ssh_user] [ssh_port]
set -euo pipefail

SERVER_IP="${1:-186.241.72.176}"
SSH_USER="${2:-root}"
SSH_PORT="${3:-49375}"
REMOTE_DIR="/opt/crmeb-prod"
LOCAL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ARCHIVE_ROOT="${LOCAL_ROOT}/db_backup/robot_cleanup"

mkdir -p "${ARCHIVE_ROOT}"
TIMESTAMP="$(date +%Y%m%d_%H%M%S)"
REMOTE_ARCHIVE_DIR="/tmp/robot_cleanup_${TIMESTAMP}"
LOCAL_ARCHIVE_DIR="${ARCHIVE_ROOT}/${TIMESTAMP}"

echo "==> Archiving robot/test rows from ${SERVER_IP}"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" bash -s "${REMOTE_ARCHIVE_DIR}" "${REMOTE_DIR}" << 'REMOTE_SCRIPT'
  REMOTE_ARCHIVE_DIR="$1"
  REMOTE_DIR="$2"
  set -euo pipefail

  get_ini() {
    local section="$1"
    local key="$2"
    local file="$3"
    awk -v section="$section" -v key="$key" '
      BEGIN { in_section=0 }
      /^\[/ { in_section = ($0 == "[" section "]"); next }
      in_section && $0 ~ "^[[:space:]]*" key "[[:space:]]*=" {
        sub(/^[^=]*=[[:space:]]*/, "");
        sub(/[[:space:]]*$/, "");
        print;
        exit;
      }
    ' "$file"
  }

  BACKEND_ENV="${REMOTE_DIR}/backend_src/.env"
  DB_HOST="$(get_ini DATABASE HOSTNAME "${BACKEND_ENV}" 2>/dev/null || true)"
  DB_NAME="$(get_ini DATABASE DATABASE "${BACKEND_ENV}" 2>/dev/null || true)"
  DB_USER="$(get_ini DATABASE USERNAME "${BACKEND_ENV}" 2>/dev/null || true)"
  DB_PASS="$(get_ini DATABASE PASSWORD "${BACKEND_ENV}" 2>/dev/null || true)"
  DB_PORT="$(get_ini DATABASE HOSTPORT "${BACKEND_ENV}" 2>/dev/null || true)"
  DB_CHARSET="$(get_ini DATABASE CHARSET "${BACKEND_ENV}" 2>/dev/null || true)"

  DB_HOST="${DB_HOST:-127.0.0.1}"
  DB_NAME="${DB_NAME:-manghehoutai_qhe}"
  DB_USER="${DB_USER:-crmeb}"
  DB_PORT="${DB_PORT:-3306}"
  DB_CHARSET="${DB_CHARSET:-utf8mb4}"

  rm -rf "${REMOTE_ARCHIVE_DIR}"
  mkdir -p "${REMOTE_ARCHIVE_DIR}"

  mysql_cmd() {
    MYSQL_PWD="${DB_PASS}" mysql -h"${DB_HOST}" -P"${DB_PORT}" -u"${DB_USER}" \
      --default-character-set="${DB_CHARSET}" "$@"
  }

  dump_table() {
    local table="$1"
    local where="$2"
    echo "==> Dumping ${table}"
    MYSQL_PWD="${DB_PASS}" mysqldump -h"${DB_HOST}" -P"${DB_PORT}" -u"${DB_USER}" "${DB_NAME}" "${table}" \
      --single-transaction --quick --no-tablespaces --default-character-set="${DB_CHARSET}" \
      --no-create-info --skip-triggers --insert-ignore --where="${where}" \
      | gzip -9 > "${REMOTE_ARCHIVE_DIR}/${table}.sql.gz"
  }

  cat > "${REMOTE_ARCHIVE_DIR}/manifest.txt" <<EOF
created_at=$(date '+%F %T %Z')
database=${DB_NAME}
where=is_jiqiren = 1
restore=gunzip -c <table>.sql.gz | mysql -u<user> -p ${DB_NAME}
EOF

  mysql_cmd "${DB_NAME}" -N -B -e "
    SELECT 'eb_store_integral_product_huanqu_log_unique', COUNT(*) FROM eb_store_integral_product_huanqu_log_unique WHERE is_jiqiren = 1
    UNION ALL SELECT 'eb_store_integral_product_huanqu_log', COUNT(*) FROM eb_store_integral_product_huanqu_log WHERE is_jiqiren = 1
    UNION ALL SELECT 'eb_store_integral_product_kaijiang_log', COUNT(*) FROM eb_store_integral_product_kaijiang_log WHERE is_jiqiren = 1
    UNION ALL SELECT 'eb_user_box', COUNT(*) FROM eb_user_box WHERE is_jiqiren = 1
    UNION ALL SELECT 'eb_box_order', COUNT(*) FROM eb_box_order WHERE is_jiqiren = 1;
  " > "${REMOTE_ARCHIVE_DIR}/counts.tsv"

  MYSQL_PWD="${DB_PASS}" mysqldump -h"${DB_HOST}" -P"${DB_PORT}" -u"${DB_USER}" "${DB_NAME}" \
    eb_store_integral_product_huanqu_log_unique \
    eb_store_integral_product_huanqu_log \
    eb_store_integral_product_kaijiang_log \
    eb_user_box \
    eb_box_order \
    --no-data --no-tablespaces --default-character-set="${DB_CHARSET}" \
    | gzip -9 > "${REMOTE_ARCHIVE_DIR}/schema.sql.gz"

  dump_table "eb_store_integral_product_huanqu_log_unique" "is_jiqiren = 1"
  dump_table "eb_store_integral_product_huanqu_log" "is_jiqiren = 1"
  dump_table "eb_store_integral_product_kaijiang_log" "is_jiqiren = 1"
  dump_table "eb_user_box" "is_jiqiren = 1"
  dump_table "eb_box_order" "is_jiqiren = 1"

  gzip -t "${REMOTE_ARCHIVE_DIR}"/*.sql.gz
REMOTE_SCRIPT

echo "==> Downloading archive to ${LOCAL_ARCHIVE_DIR}"
mkdir -p "${LOCAL_ARCHIVE_DIR}"
rsync -avz -e "ssh -p ${SSH_PORT}" "${SSH_USER}@${SERVER_IP}:${REMOTE_ARCHIVE_DIR}/" "${LOCAL_ARCHIVE_DIR}/"

echo "==> Cleaning remote temp files"
ssh -p "${SSH_PORT}" "${SSH_USER}@${SERVER_IP}" "rm -rf ${REMOTE_ARCHIVE_DIR}" 2>/dev/null || true

echo "==> Archive complete"
echo "Local archive: ${LOCAL_ARCHIVE_DIR}"
