# CoreSettlement Phase52 SQL Review Hardening Package 2026-05-18

## Current Task

Phase52 hardens the Phase51 SQL draft review package before any deploy SQL file is created.

Hardening package only.
No deploy SQL file was created.
No SQL was executed.
No migration was run.
No production database connection was opened.
No deployment was executed.
No write path was enabled.

## Hardening Decisions

```text
final AI log table: eb_core_point_gateway_ai_operation_log
legacy draft AI log table: excluded
payload_json storage: TEXT
evidence_json storage: TEXT
table charset: utf8mb4
engine: InnoDB
idempotency key: uk_scene_request(scene, request_id)
rollback one-time key: uk_target_once(target_request_id)
approval request key: uk_approval_request(approval_request_id)
deploy SQL file: not created
```

## Required Review Gates Before Deploy SQL File Creation

```text
1. Phase51 SQL draft review package assert passes.
2. Phase50 readonly table result remains valid for target environment.
3. Phase46 naming decision remains unchanged.
4. No target SQL exists under deploy or backend_src/public/install.
5. User explicitly approves deploy SQL file creation.
6. User explicitly understands file creation is not SQL execution approval.
```

## Required Checks For Future SQL File

```text
contains exactly six CREATE TABLE IF NOT EXISTS statements
contains no INSERT
contains no UPDATE
contains no DELETE
contains no DROP
contains no TRUNCATE
contains no ALTER
contains no RENAME
contains no CREATE TRIGGER
contains no CREATE PROCEDURE
contains no CREATE EVENT
contains no GRANT
contains no REVOKE
does not create eb_core_point_ai_operation_log
does not modify eb_user
does not modify user_bill
does not modify order/payment/manghe tables
```

## Future File Location

```text
deploy/core_point_gateway_tables_approval_required.sql
```

This file path is reserved for later approval.
It must not exist after Phase52.

## Manual Review Notes

```text
source_module, biz_type, biz_id, and legacy_user_bill_id are included for admin filtering and legacy reconciliation.
payload_json and evidence_json stay TEXT until production MySQL JSON behavior is approved.
all tables are append-only or request-state tables; no legacy table writes are part of this package.
table creation alone does not enable DbPointTransactionStore.
```

## Guards

```text
deploy_sql_created: false
sql_executed: false
migration_run: false
production_connection_opened: false
database_writes: false
deployment_executed: false
db_store_enabled: false
route_exposure: false
```

## Validation

```text
point_gateway_sql_review_hardening_package_assert
point_gateway_sql_draft_review_package_assert
core_settlement_backend_package_assert
```
