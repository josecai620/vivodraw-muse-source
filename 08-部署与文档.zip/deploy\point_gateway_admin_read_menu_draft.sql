-- Point Gateway admin read page menu draft.
-- DO NOT execute automatically. Requires operator approval and DB backup.
-- Scope: menu/permission rows only. No point balance, ledger, payment, order, or switch writes.

SET NAMES utf8mb4;

-- 1. Top header for /admin/core.
INSERT INTO `eb_system_menus`
  (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 0, 1, 'md-pulse', 'Core', 'admin', '', '', '', '', '[]', 80, 1, 0, 1, '/admin/core', '', 1, 'core', 1, 'admin-core', 0
FROM DUAL
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_system_menus`
  WHERE `unique_auth` = 'admin-core' AND `is_del` = 0
);

SET @core_header_id = (
  SELECT `id` FROM `eb_system_menus`
  WHERE `unique_auth` = 'admin-core' AND `is_del` = 0
  LIMIT 1
);

-- 2. Visible read-only page. Frontend route already exists at /admin/core/point_gateway.
INSERT INTO `eb_system_menus`
  (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @core_header_id, 1, 'ios-list-box-outline', '积分账本', 'admin', '', '', '', '', '[]', 1, 1, 0, 1, '/admin/core/point_gateway', CAST(@core_header_id AS CHAR), 1, 'core', 0, 'admin-core-point-gateway', 0
FROM DUAL
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_system_menus`
  WHERE `unique_auth` = 'admin-core-point-gateway' AND `is_del` = 0
);

SET @point_gateway_menu_id = (
  SELECT `id` FROM `eb_system_menus`
  WHERE `unique_auth` = 'admin-core-point-gateway' AND `is_del` = 0
  LIMIT 1
);
SET @point_gateway_path = CONCAT(@core_header_id, '/', @point_gateway_menu_id);

-- 3. GET-only API permission rows. No mutation endpoints.
INSERT INTO `eb_system_menus`
  (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @point_gateway_menu_id, 1, '', `menu_name`, 'admin', '', '', `api_url`, 'GET', '[]', `sort`, 0, 0, 1, '', @point_gateway_path, 2, 'core', 0, `unique_auth`, 0
FROM (
  SELECT 'Point Gateway 总览' AS `menu_name`, 'core/point_gateway/overview' AS `api_url`, 1 AS `sort`, 'core-point-gateway-overview' AS `unique_auth`
  UNION ALL SELECT 'Point Gateway 流水列表', 'core/point_gateway/transactions', 2, 'core-point-gateway-transactions'
  UNION ALL SELECT 'Point Gateway 流水详情', 'core/point_gateway/detail', 3, 'core-point-gateway-detail'
  UNION ALL SELECT 'Point Gateway 回滚申请', 'core/point_gateway/rollback_requests', 4, 'core-point-gateway-rollback-requests'
  UNION ALL SELECT 'Point Gateway 冻结积分', 'core/point_gateway/frozen_points', 5, 'core-point-gateway-frozen-points'
  UNION ALL SELECT 'Point Gateway 到期批次', 'core/point_gateway/expiry_batches', 6, 'core-point-gateway-expiry-batches'
  UNION ALL SELECT 'Point Gateway AI 操作日志', 'core/point_gateway/ai_operation_logs', 7, 'core-point-gateway-ai-operation-logs'
) AS rows_to_insert
WHERE NOT EXISTS (
  SELECT 1 FROM `eb_system_menus`
  WHERE `unique_auth` = rows_to_insert.`unique_auth` AND `is_del` = 0
);

-- 4. Operator preview after execution.
SELECT `id`, `pid`, `menu_name`, `menu_path`, `api_url`, `methods`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`
FROM `eb_system_menus`
WHERE `unique_auth` IN (
  'admin-core',
  'admin-core-point-gateway',
  'core-point-gateway-overview',
  'core-point-gateway-transactions',
  'core-point-gateway-detail',
  'core-point-gateway-rollback-requests',
  'core-point-gateway-frozen-points',
  'core-point-gateway-expiry-batches',
  'core-point-gateway-ai-operation-logs'
)
ORDER BY `id`;
