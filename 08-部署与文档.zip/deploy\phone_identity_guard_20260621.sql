-- Requires explicit approval before production execution.
-- Guards non-empty eb_user.phone values with a unique generated column.

DROP PROCEDURE IF EXISTS apply_phone_identity_guard_20260621;
DELIMITER //
CREATE PROCEDURE apply_phone_identity_guard_20260621()
BEGIN
    IF EXISTS (
        SELECT 1 FROM (
            SELECT TRIM(phone) AS phone_value, COUNT(*) AS duplicate_count
            FROM eb_user
            WHERE TRIM(phone) <> ''
            GROUP BY TRIM(phone)
            HAVING duplicate_count > 1
        ) duplicate_phones
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Duplicate non-empty eb_user.phone values exist. Resolve before adding unique guard.';
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'eb_user'
            AND COLUMN_NAME = 'phone_unique'
    ) THEN
        ALTER TABLE eb_user
            ADD COLUMN phone_unique VARCHAR(20)
            GENERATED ALWAYS AS (NULLIF(TRIM(phone), '')) STORED
            COMMENT 'Unique guard for non-empty bound mobile numbers';
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM INFORMATION_SCHEMA.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = 'eb_user'
            AND INDEX_NAME = 'uniq_user_phone_unique'
    ) THEN
        ALTER TABLE eb_user
            ADD UNIQUE KEY uniq_user_phone_unique (phone_unique);
    END IF;
END//
DELIMITER ;

CALL apply_phone_identity_guard_20260621();
DROP PROCEDURE IF EXISTS apply_phone_identity_guard_20260621;
