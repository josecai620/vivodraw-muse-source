# -*- coding: utf-8 -*-
import json, os, collections

L = r'D:\eccomall\mobile-app\lib\i18n\locales'

EN = {
  "auth": {"loginRequired": "Sign in for full access",
           "loginHint": "Unboxing, check-in, backpack and more require sign-in"},
  "backpack": {"emptyHint": "Open blind boxes, and your items will show up here",
               "goExplore": "Explore Boxes"},
  "collection": {"empty": "No Collection Yet",
                 "emptyHint": "Open boxes to build your collection.",
                 "openBoxes": "Open Boxes"},
  "common": {"yes": "Yes", "no": "No"},
  "detail": {"each": "each", "openLabel": "Draw", "pityProgress": "Pity Progress"},
  "exchange": {"accept": "Accept", "decline": "Decline",
               "cancelConfirm": "Cancel this listing?",
               "confirmTitle": "Confirm swap",
               "confirmMsg": "Approve this swap request?",
               "createFirst": "Create first",
               "noMyListings": "No listings yet",
               "noOffers": "No swap offers",
               "statusActive": "Active", "statusPending": "In review",
               "statusDone": "Completed", "statusCancelled": "Cancelled",
               "wantsToSwap": "Wants to swap"},
  "freeDraw": {"title": "Daily Free Draw", "dailyFree": "Daily Free Draw",
               "description": "Draw once every day for free",
               "drawNow": "Draw Now", "alreadyDrawn": "Already drawn today",
               "comeBackTomorrow": "Come back tomorrow",
               "rareCongrats": "Lucky! You got a rare item",
               "goToBackpack": "View Backpack",
               "resetsDaily": "Resets every day at 00:00"},
  "invite": {"title": "Invite Friends", "heroTitle": "Invite friends, earn rewards",
             "heroDesc": "Invite friends to register and shop, and both sides earn points rewards",
             "yourCode": "Your invite code", "invited": "Invited",
             "paidUsers": "Paid users", "inviteN": "Invite {{n}} friends",
             "level1": "Level 1", "level2": "Level 2", "level3": "Level 3",
             "level4": "Level 4", "level5": "Level 5",
             "notYet": "Not reached", "rewards": "Invite Rewards",
             "claim": "Claim", "shareNow": "Share Now",
             "shareTitle": "Invite to Vivodraw",
             "shareMessage": "Join Vivodraw via my invite link, pick real products and earn points:"},
  "wishlist": {"notifications": "Notify me on rate-up"},
}

ZH = {
  "auth": {"loginRequired": "登入解鎖完整功能",
           "loginHint": "開盒、簽到、背包等功能需要先登入"},
  "backpack": {"emptyHint": "開啟盲盒後，物品會顯示在這裡",
               "goExplore": "去逛逛"},
  "collection": {"empty": "尚無圖鑑",
                 "emptyHint": "開啟盲盒來收集你的圖鑑。",
                 "openBoxes": "去開盒"},
  "common": {"yes": "是", "no": "否"},
  "detail": {"each": "件", "openLabel": "抽", "pityProgress": "保底進度"},
  "exchange": {"accept": "接受", "decline": "拒絕",
               "cancelConfirm": "確定要取消此掛單嗎？",
               "confirmTitle": "確認交換",
               "confirmMsg": "確定接受這筆交換申請嗎？",
               "createFirst": "立即發布",
               "noMyListings": "尚無掛單",
               "noOffers": "尚無交換申請",
               "statusActive": "進行中", "statusPending": "審核中",
               "statusDone": "已完成", "statusCancelled": "已取消",
               "wantsToSwap": "想要交換"},
  "freeDraw": {"title": "每日免費抽", "dailyFree": "每日免費一抽",
               "description": "每天都可以免費抽一次",
               "drawNow": "立即抽取", "alreadyDrawn": "今天已抽過",
               "comeBackTomorrow": "明天再來看看",
               "rareCongrats": "太幸運了！獲得稀有物品",
               "goToBackpack": "查看背包",
               "resetsDaily": "每日 00:00 重置"},
  "invite": {"title": "邀請好友", "heroTitle": "邀好友 賺獎勵",
             "heroDesc": "邀請好友註冊並消費，雙方都能獲得積分獎勵",
             "yourCode": "我的邀請碼", "invited": "已邀請",
             "paidUsers": "已付費用戶", "inviteN": "邀請 {{n}} 位好友",
             "level1": "第1階", "level2": "第2階", "level3": "第3階",
             "level4": "第4階", "level5": "第5階",
             "notYet": "尚未達成", "rewards": "邀請獎勵",
             "claim": "領取", "shareNow": "立即分享",
             "shareTitle": "邀請你加入 Vivodraw",
             "shareMessage": "透過我的邀請連結加入 Vivodraw，挑選真實商品還能賺積分："},
  "wishlist": {"notifications": "概率提升時通知我"},
}

for fname, add in [("en.json", EN), ("zh-TW.json", ZH)]:
    p = os.path.join(L, fname)
    data = json.load(open(p, encoding='utf-8'), object_pairs_hook=collections.OrderedDict)
    added = 0
    for ns, kv in add.items():
        node = data.setdefault(ns, collections.OrderedDict())
        for k, v in kv.items():
            if k not in node:
                node[k] = v
                added += 1
    with open(p, 'w', encoding='utf-8', newline='\n') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')
    # verify
    json.load(open(p, encoding='utf-8'))
    print(fname, 'added', added, 're-parsed OK')
