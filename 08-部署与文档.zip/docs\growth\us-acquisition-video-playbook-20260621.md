# VivoDraw US Acquisition Video Playbook - 2026-06-21

## Purpose

Create first practical ad/video package for US consumers and first-level agents.

This is pre-production. Do not launch paid traffic until:

- `deploy/ops/vivodraw-ops-health.sh` passes for `vivodraw.com`.
- Lead capture works through a real form or verified inbox.
- Email DNS has receiving and sending records in place.
- Landing pages show clear business, shipping, refund, support, and offer terms.

Current blunt truth: IP storefront works; public domain path still fails. Paid ads into `403 Beaver` is not growth. It is expensive comedy.

## Sources Checked

Official compliance/policy sources checked on 2026-06-21:

- FTC influencer disclosure guide: https://www.ftc.gov/business-guidance/resources/disclosures-101-social-media-influencers
- FTC digital disclosures guidance: https://www.ftc.gov/business-guidance/resources/com-disclosures-how-make-effective-disclosures-digital-advertising
- Meta Advertising Standards overview: https://www.facebook.com/business/help/488043719226449
- Meta unacceptable business practices: https://transparency.meta.com/policies/ad-standards/fraud-scams/unacceptable-business-practices/
- TikTok misleading and false content policy: https://ads.tiktok.com/help/article/tiktok-ads-policy-misleading-and-false-content
- TikTok deceptive practices policy: https://ads.tiktok.com/help/article/tiktok-ads-policy-deceptive-practices
- Google Ads misrepresentation policy: https://support.google.com/adspolicy/answer/6020955

Operational rule derived from those sources:

- Disclose paid/affiliate relationships clearly and early.
- Do not promise guaranteed income, guaranteed prizes, instant results, or risk-free wins.
- Do not hide material offer terms behind tiny footer copy.
- Ads and landing pages must match. If video says `40% of platform net profit`, landing page must also say `qualified first-level orders`, not some fake-rich nonsense.

## Launch Gate

Before any public campaign:

```bash
deploy/ops/vivodraw-ops-health.sh
deploy/ops/check_us_lead_capture_readiness.sh
```

Required result:

- Both commands return `0 failure(s)`.
- `vivodraw.com` returns app/Nginx path, not `Beaver`.
- TLS/SNI returns HTTP response.
- Email MX/TXT warnings resolved before using `@vivodraw.com` as CTA.

If gate fails, use local/internal review only. No paid traffic.

## Campaign A - US Consumer Product Hook

Goal: make VivoDraw feel like a product discovery shop with rewards, not a weird lottery site.

Audience:

- US shoppers who buy cute desk items, self-care, collectible toys, small tech, and giftable lifestyle products.
- Organic TikTok/Reels/Shorts first. Paid later after domain gate passes.

Format:

- 9:16, 1080x1920.
- 22-28 seconds.
- Fast product cuts, real site screenshots, no AI-fake product imagery.

Hook options:

- "Tiny desk upgrades that feel less boring than Amazon scroll."
- "I found a shop for cute desk stuff, self-care picks, and reward points in one place."
- "If your cart needs personality, this is the kind of store I mean."

Script:

| Time | Visual | Voiceover | On-screen text |
| --- | --- | --- | --- |
| 0-2s | Fast close-up montage: desk item, beauty item, collectible, site homepage | "Your cart does not need another boring duplicate." | "Cute finds. Real products." |
| 2-6s | VivoDraw category grid by IP/local capture, no broken domain in frame | "VivoDraw is a product discovery shop for desk life, self-care, collectibles, and small tech." | "Beauty / Desk / Collectibles / Tech" |
| 6-12s | Product card scroll, product detail, price/spec area | "You browse real products, check details, and keep your rewards tied to your account." | "Browse -> pick -> earn rewards" |
| 12-18s | Points/rewards surface, avoid cash language | "Rewards are for platform activity, not cash promises. Simple, visible, inside the site." | "Rewards stay in-platform" |
| 18-24s | Cart/profile/order tracking screenshot | "Start with one useful thing. If the experience is good, come back for the fun part." | "Shop first. Fun second." |
| 24-28s | CTA card | "VivoDraw. Product finds with a little extra game." | "Open VivoDraw" |

Compliance notes:

- Do not say `free money`, `cash back guaranteed`, `win every time`, or `guaranteed value`.
- If creator is paid/compensated, first 2 seconds must show `Paid partnership with VivoDraw` or equivalent.
- Use real product footage or licensed catalog images only.

## Campaign B - Blind Box / Reveal Hook

Goal: present blind box as transparent entertainment layered on top of product commerce.

Audience:

- Collectible/toy/gift buyers.
- People who like reveal mechanics, but are skeptical of sketchy mystery boxes.

Format:

- 9:16, 1080x1920.
- 25-35 seconds.
- High-contrast reveal rhythm; show odds/rules before reveal.

Hook options:

- "Mystery boxes are only fun when the rules are visible."
- "Before the reveal, I want to see the odds. VivoDraw actually puts the rules in front."
- "One box, clear rules, reveal, then choose what to do next."

Script:

| Time | Visual | Voiceover | On-screen text |
| --- | --- | --- | --- |
| 0-2s | Closed box, quick flash of odds/rules panel | "Mystery boxes should not feel like a magic trick with missing rules." | "Show rules first." |
| 2-7s | Blind box shelf, price, odds/rule label | "On VivoDraw, the box flow is simple: see the box, read the rules, then decide." | "Box -> rules -> decide" |
| 7-13s | Payment/reveal path as UI capture, no gambling language | "You open one box, reveal the result, and track it in your account." | "One box. One reveal." |
| 13-21s | Prize result and owned-prize view | "If you keep it, it stays tied to your order flow. If recycle is available, the credit stays inside the platform." | "Keep or recycle in-platform" |
| 21-29s | Product/prize montage, clear disclaimer card | "It is not cash, not guaranteed profit, and not a financial product. It is a product reveal mechanic." | "No cash promise. No guaranteed profit." |
| 29-35s | CTA card | "Try it when you want the reveal, not the fine print headache." | "VivoDraw blind box" |

Compliance notes:

- Avoid `gamble`, `bet`, `cash out`, `profit`, `risk-free`, `guaranteed`, `investment`, `jackpot`.
- Show rules/odds before reveal in video and landing page.
- Recycle credit must be described as in-platform only.

## Campaign C - First-Level Agent Recruitment

Goal: recruit serious first-level agents without sounding like MLM fog.

Audience:

- US micro-creators, niche community sellers, Discord/community operators, campus/group organizers.
- People who can bring buyers, not people chasing passive-income fantasies.

Format:

- 9:16, 1080x1920.
- 30-45 seconds.
- Talking-head plus UI overlay. Founder/operator tone beats corporate promo sludge.

Hook options:

- "If you can bring real buyers, VivoDraw can track your first-level profit share."
- "No inventory. No payment handling. No second-level commission maze."
- "This is not 40% of revenue. It is 40% of platform net profit from qualified first-level orders."

Script:

| Time | Visual | Voiceover | On-screen text |
| --- | --- | --- | --- |
| 0-3s | Person-to-camera, plain background | "This is for people who can bring real buyers, not people looking for fake passive income." | "Real buyers only" |
| 3-8s | Agent demo hero or `/agent-admin/` screenshot | "VivoDraw handles catalog, order flow, and tracking. You focus on first-level buyers." | "No inventory. No payment handling." |
| 8-16s | Formula animation: order revenue - costs = net profit x 40% | "The offer is 40% of platform net profit from qualified first-level orders." | "40% of net profit, not revenue" |
| 16-24s | Qualification timeline: paid, delivered, non-refunded, reviewed | "Qualified means paid, delivered, non-refunded, and reviewable. Boring sentence, useful later." | "Qualified orders only" |
| 24-32s | Agent-admin preview: members, orders, ledger | "You get a separate agent console to see members, orders, ledger, requests, and promo activity." | "Tracked in agent-admin" |
| 32-40s | CTA card, no broken domain until gate passes | "When applications open, apply with your channel, audience, and buyer plan." | "Apply when public gate passes" |

Required disclaimers:

- `Income is not guaranteed.`
- `Qualified first-level orders only.`
- `40% is platform net profit share, not order revenue.`
- `Marketing Credits are not cash, not withdrawable, and not transferable.`

Landing/page requirements before public CTA:

- Working domain.
- Working application form or verified inbox.
- Clear terms: first-level only, qualification rules, payout review, refund window, cost definition.
- No second-level language.
- No stored-value/recharge/transferable coin language.

## Creator Brief Template

Use this for UGC creators:

```text
You are making a VivoDraw short video.

Must disclose relationship in first 2 seconds:
"Paid partnership with VivoDraw" or platform-native paid partnership tag.

Tone:
Real shopper/operator. No fake luxury, no get-rich line, no casino energy.

Must say:
- Real products / product discovery.
- Rewards or credits stay inside the platform.
- Agent offer, if mentioned, is 40% of platform net profit from qualified first-level orders.

Must not say:
- Guaranteed income.
- Guaranteed prize.
- Cash out points/credits.
- 40% of sales or 40% of revenue.
- Risk-free, instant profit, investment, jackpot, gambling.

CTA:
Use only approved landing link after `deploy/ops/vivodraw-ops-health.sh` passes.
```

## Asset Checklist

Need before first video build:

- Review prototype: `prototypes/agent-recruit-demo/`
- 6-10 real product clips or licensed stills.
- Product asset requests: `docs/growth/us-video-asset-rights-request-20260621.tsv`
- 3-5 real mobile/web UI captures from working route.
- One agent-admin demo capture with fake-safe data.
- Brand voiceover in US English, 120-150 words per 45 seconds.
- Subtitle style: large, high-contrast, bottom-safe, max 5 words per chunk for short-form.
- Final export targets: `1080x1920`, `30fps`, `H.264 mp4`, plus source project in an `edit/` folder if using `video-use`.

## First 7 Organic Tests

Do not start with paid ads. First organic tests:

1. TikTok/Reels: product discovery hook, no blind box, no agent.
2. TikTok/Reels: blind box transparency hook, rules before reveal.
3. YouTube Shorts: agent recruitment, operator explanation.
4. Instagram Reel: cute desk/home product montage.
5. Discord/community post: agent program explainer with no income hype.
6. Reddit-style text post draft only after community rule review.
7. Short landing-page screen recording for partners once domain works.

Success signals:

- 3-second hold rate above weak baseline.
- Comments ask about product/rules, not "is this a scam?"
- Clicks reach a working landing page.
- Email/form lead capture receives test submission.

## Current Blockers

- Public `vivodraw.com` path still fails in health check.
- `@vivodraw.com` mail records fail the lead-capture readiness gate: MX is visible, but SPF and DMARC are still missing.
- Agent Growth Surface Guard currently passes, but public agent recruitment still stays blocked until lead capture works.

## Next Safe Moves

Without owner approval:

- Use this playbook to record voiceover or build storyboard assets.
- Polish the local agent recruitment demo, but do not publish it as public CTA.
- Capture product/UI footage from IP/local routes for review.
- Keep daily health gate running.
- Keep all video CTAs as internal review language until public entry and lead-capture gates pass.

Needs owner/account approval:

- DNS/cloud edge/WAF/ICP fix.
- Real email inbox and transactional DNS setup.
- Paid ad account launch.
- Public landing page CTA switch.
