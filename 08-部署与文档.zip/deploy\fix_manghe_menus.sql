-- 修复盲盒中奖设置、盲盒赠送抽奖中奖设置菜单（路径、权限、编码）
SET NAMES utf8mb4;

-- 1. 盲盒中奖设置：确保路径为 /admin/marketing/integral/zhongjiangset
UPDATE `eb_system_menus` SET
  `menu_path` = '/admin/marketing/integral/zhongjiangset',
  `unique_auth` = 'admin-integral-zhongjiangset',
  `menu_name` = '盲盒中奖设置',
  `api_url` = 'integral/zhongjiangset'
WHERE (`menu_name` = '盲盒中奖设置' OR `menu_path` LIKE '%zhongjiang%') AND `is_del` = 0;

-- 若不存在则插入（挂到营销 marketing 下）
SET @marketing_pid = (SELECT `id` FROM `eb_system_menus` WHERE (`header` = 'marketing' OR `menu_path` = '/admin/marketing') AND `is_del` = 0 LIMIT 1);
SET @marketing_pid = IFNULL(@marketing_pid, 1);
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @marketing_pid, 1, 'md-settings', '盲盒中奖设置', 'admin', 'integral.zhongjiangset', 'index', 'integral/zhongjiangset', 'GET', '[]', 50, 1, 0, 1, '/admin/marketing/integral/zhongjiangset', '1', 1, 'marketing', 0, 'admin-integral-zhongjiangset', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/marketing/integral/zhongjiangset' AND `is_del` = 0);

-- 2. 盲盒赠送抽奖中奖设置：确保路径为 /admin/user/choujiang_list
UPDATE `eb_system_menus` SET
  `menu_path` = '/admin/user/choujiang_list',
  `unique_auth` = 'admin-user-choujiang-list',
  `menu_name` = '盲盒赠送抽奖中奖设置',
  `api_url` = 'user/user/choujiang_list'
WHERE (`menu_name` LIKE '%盲盒赠送%' OR `menu_name` LIKE '%抽奖中奖%' OR `menu_path` LIKE '%choujiang%') AND `is_del` = 0;

-- 若不存在则插入（挂到用户 user 下）
SET @user_pid = (SELECT `id` FROM `eb_system_menus` WHERE (`header` = 'user' OR `menu_path` = '/admin/user') AND `is_del` = 0 LIMIT 1);
SET @user_pid = IFNULL(@user_pid, 1);
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @user_pid, 1, 'md-gift', '盲盒赠送抽奖中奖设置', 'admin', 'user.user', 'choujiang_list', 'user/user/choujiang_list', 'GET', '[]', 55, 1, 0, 1, '/admin/user/choujiang_list', '1', 1, 'user', 0, 'admin-user-choujiang-list', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/user/choujiang_list' AND `is_del` = 0);

-- 3. 确保 admin 超级管理员有权限
UPDATE `eb_system_admin` SET `level` = 0, `roles` = '1' WHERE `account` = 'admin' AND `is_del` = 0;
UPDATE `eb_system_role` SET `rules` = '*' WHERE `id` = 1 AND `status` = 1 AND (IFNULL(`rules`,'') = '' OR `rules` IS NULL);
