# Autonomous Platform Ops Plan - 2026-06-21

## Goal

Codex should act as an autonomous operating partner for Eccomall/VivoDraw, covering:

1. Platform maintenance and launch safety.
2. Acquisition and partner/agent growth.
3. Ad and video material production.

This is an operating workflow, not permission to run high-risk production changes. Production SQL, DNS, server config, payment, inventory, ledger writes, and irreversible Git actions still need explicit owner approval.

## Current Evidence Snapshot

- Branch: `codex/pet-world-v2`
- Commit: `57aed478dba4b51af3fc154bcdfa595b977b6f7f`
- Worktree status at audit time:
  - Clean.
  - Remote parity `HEAD...origin/codex/pet-world-v2`: `0 0`.
- Quarantined: old public demo copy moved from `mobile-app-v3/public/agent-recruit-demo/` to `prototypes/agent-recruit-demo-public-archive-20260621/`
- IP storefront health:
  - `http://8.166.115.27/` returned `200`
  - `GET /api/category` with `X-Client: mobile-app` returned `status=200` and six bilingual categories
  - `http://8.166.115.27/agent-admin/` returned `200`
- Domain risk:
  - External `Host: vivodraw.com` path still returns `403` with `Server: Beaver`.
  - External TLS/SNI path still returns HTTP `000`.
  - Google and Cloudflare DNS-over-HTTPS both include `A 8.166.115.27`.
  - Server-local Nginx/TLS path passes for `vivodraw.com`; the remaining public-entry fault is outside the local app/Nginx path.
- Lead capture risk:
  - Google and Cloudflare DNS-over-HTTPS both see MX `1 smtp.google.com.`.
  - Root SPF TXT is still missing.
  - `_dmarc.vivodraw.com` TXT is still missing.

## First Operating Conclusions

1. Storefront by IP is alive, so the platform is not down.
2. `vivodraw.com` is not a safe public entry right now. This blocks ads, partner links, and any launch-facing traffic.
3. Agent growth has real artifacts already: `/agent-admin/`, promo wallet docs, and reviewed prototype material under `prototypes/`.
4. Lead capture is partially moving because MX is visible, but SPF and DMARC still block public CTA use.
5. External account/provider work is now the critical path; random app-code poking is not operations, it is cosplay.

## Latest Gate Update - 2026-06-21 09:11 CST

Command:

```bash
REPORT_FILE=.codex-artifacts/vivodraw-daily-ops-current.md bash deploy/ops/vivodraw_daily_ops_report.sh
```

Result:

- Worktree clean on `codex/pet-world-v2`.
- Remote parity `HEAD...origin/codex/pet-world-v2`: `0 0`.
- PASS: Agent Growth Surface Guard, including `/agent-admin/` Nginx route, CSP/frame protection, and platform-admin promo API helpers.
- PASS: US Customer Journey, including storefront, category API, 143 live products, product detail, product image, checkout route, support route, and unauthenticated cart boundary `410000`.
- PASS: US Growth Experiment Ledger and US Video Production Queue, including first-level net-profit and lead-capture gate framing for agent CTAs.
- FAIL: Public Entry Health. `vivodraw.com` still returns `403 Beaver` on Host-header path and HTTP `000` on TLS/SNI, while DNS-over-HTTPS includes `8.166.115.27`.
- FAIL: US Lead Capture Readiness. MX is visible, but SPF and DMARC are still missing.

Operating decision: paid traffic and public agent recruitment stay blocked until public entry and lead capture both pass or the owner explicitly approves a narrower internal-only action.

## Latest Domain Diagnostic - 2026-06-21

Command:

```bash
SERVER_IP=8.166.115.27 SSH_PORT=2222 DOMAIN=vivodraw.com bash deploy/ops/check_vivodraw_domain_remote.sh
```

Result:

- PASS: server-local HTTP `Host: vivodraw.com` returns `301`.
- PASS: server-local HTTPS with SNI `vivodraw.com` returns `200`.
- PASS: server-side DNS A record is `8.166.115.27`.
- PASS: server-side DNS MX record is `1 smtp.google.com.`.
- WARN: server-side DNS TXT is empty.
- PASS: Nginx has `/etc/nginx/sites-enabled/vivodraw.com.conf` with `server_name vivodraw.com www.vivodraw.com`, `listen 80`, `listen 443 ssl`, and Let's Encrypt certificate paths.
- PASS: certificate covers `vivodraw.com` and `www.vivodraw.com`, valid until `2026-08-13`.
- PASS: server listens on `80`, `443`, and `20199`.

Conclusion: local app/Nginx/TLS path is healthy. The remaining public-domain blocker is outside local Nginx, likely cloud edge/WAF/ICP/provider gateway/network ACL. Stop poking random app code for this; it has an alibi.

## Latest Lead Capture Diagnostic - 2026-06-21

Command:

```bash
DOMAIN=vivodraw.com bash deploy/ops/check_us_lead_capture_readiness.sh
```

Result:

- PASS: Email setup decision doc exists.
- PASS: `support@vivodraw.com` human mailbox and `no-reply@vivodraw.com` sender are documented.
- PASS: Support page exposes email and ticket fallback.
- PASS: Public app source does not expose `agents@vivodraw.com` as a lead sink.
- PASS: Google and Cloudflare DNS-over-HTTPS both found MX `1 smtp.google.com.`.
- FAIL: DNS-over-HTTPS found no SPF TXT on root domain.
- FAIL: DNS-over-HTTPS found no DMARC TXT on `_dmarc.vivodraw.com`.

Operating decision: do not use `@vivodraw.com` as a public acquisition CTA until MX/SPF/DMARC are configured and this gate passes. A lead form that drops mail is not a funnel. It is a shredder with branding.

## Maintenance Loop

Run read-only unless the owner approves a high-risk action.

Primary daily gate:

```bash
deploy/ops/vivodraw_daily_ops_report.sh
```

The daily report treats dirty worktree scope as a blocking maintenance signal, not just a background Git note.

Short operator board:

```bash
deploy/ops/vivodraw_operator_board.sh
```

Use this for the one-page daily decision view. It reads the action ledger, growth distribution ledger, video script pack, and asset-rights queue, then prints blockers, owner/account actions, Codex-safe work, distribution status, video readiness, and the current go/no-go decision.

Core documentation/workflow gate:

```bash
deploy/ops/check_core_docs.sh
```

US launch action ledger gate:

```bash
deploy/ops/check_us_launch_action_ledger.sh
```

US public launch readiness gate:

```bash
deploy/ops/check_us_public_launch_readiness.sh
```

This gate also requires a clean worktree and `HEAD...origin/<branch>` parity before public launch. If the tree is dirty, use a scoped commit or clean temp worktree; do not launch from a mixed local state.

Dirty worktree scope gate:

```bash
deploy/ops/check_dirty_worktree_scope.sh
```

Use this when public launch fails on dirty worktree. It classifies dirty paths by backend, deploy/ops, mobile, docs, and severity so the next action is scoped instead of broad-sync theater.

Auth verification safety gate:

```bash
deploy/ops/check_auth_verification_safety.sh
```

Use this before backend auth deploys. It verifies registration, reset, mobile login, and email login still clear generic and typed verification-code cache keys, and that register copy still acknowledges email accounts.

Offshore public-entry package gate:

```bash
deploy/ops/check_offshore_entry_package.sh
```

Use this before owner-side Cloudflare Pages review or upload. It verifies the offshore package remains direct-upload only, keeps DNS/mail rollback notes visible, proxies API/assets to the origin IP without forwarding `vivodraw.com` as the mainland Host, and avoids deploy/server/DB/Git write commands.

Individual health gate:

```bash
deploy/ops/vivodraw-ops-health.sh
```

Read-only remote domain diagnostic:

```bash
deploy/ops/check_vivodraw_domain_remote.sh
```

Agent growth deploy gate:

```bash
deploy/ops/check_agent_growth_surface.sh
```

US growth experiment gate:

```bash
deploy/ops/check_us_growth_experiments.sh
```

US growth distribution gate:

```bash
deploy/ops/check_us_growth_distribution.sh
```

US consumer trust gate:

```bash
deploy/ops/check_us_trust_surface.sh
```

US customer journey gate:

```bash
deploy/ops/check_us_customer_journey.sh
```

US lead capture readiness gate:

```bash
deploy/ops/check_us_lead_capture_readiness.sh
```

Public review asset guard:

```bash
deploy/ops/check_public_review_assets.sh
```

US video production gate:

```bash
deploy/ops/check_us_video_queue.sh
```

US video script pack gate:

```bash
deploy/ops/check_us_video_script_pack.sh
```

US video shot capture gate:

```bash
deploy/ops/check_us_video_shot_capture.sh
```

US video product shortlist gate:

```bash
deploy/ops/check_us_video_product_shortlist.sh
```

US video asset rights gate:

```bash
deploy/ops/check_us_video_asset_rights.sh
```

Review-only UI capture helper:

```bash
deploy/ops/capture_us_video_ui_shots.sh
```

Current action ledger: `docs/ops/us-launch-action-ledger-20260621.tsv`
Current blocker report: `docs/ops/agent-growth-surface-blocker-20260621.md`
Agent surface restore package: `docs/ops/agent-growth-surface-restore-plan-20260621.md`
Domain entry remediation package: `docs/ops/vivodraw-domain-entry-remediation-20260621.md`
Owner action package: `docs/ops/us-launch-owner-action-20260621.md`
Offshore public-entry package: `deploy/offshore-entry/`
Current trust report: `docs/ops/us-trust-surface-audit-20260621.md`
Current public-asset report: `docs/ops/public-review-asset-guard-20260621.md`

Daily checks:

```bash
git status --short --branch
git diff --stat
curl -I --max-time 12 http://8.166.115.27/
curl -I --max-time 12 http://8.166.115.27/_expo/static/js/web/entry-dd91218d68579ae0ce2255243333034c.js
curl -fsS --max-time 12 -H 'X-Client: mobile-app' http://8.166.115.27/api/category
curl -I --max-time 12 http://8.166.115.27/agent-admin/
curl -I --max-time 12 https://vivodraw.com/
```

The scripted gate supersedes ad-hoc curl checks for day-to-day operation because it reports storefront, API, `/agent-admin/`, domain edge, TLS/SNI, mail DNS, public resolver, DNS-over-HTTPS status, US customer journey readiness, and lead-capture readiness in one place.
It checks public DNS evidence, so a local proxy address such as `198.18.0.73` does not get mistaken for clean public launch evidence.

Weekly checks:

- Review `.claude/memory/launch_checklist.md` before launch-facing work.
- Run scoped audit using `docs/codex-full-audit-workflow.md` when there is system risk.
- Keep production DB work read-only by default, following `docs/backend-database-workflow-20260615.md`.
- Confirm frontend deploys still use `./deploy-frontend.sh` and backend deploys use the project scripts.

High-risk stop points:

- DNS or HTTPS changes.
- Nginx/server config changes.
- Production SQL or migration execution.
- Payment, inventory, point ledger, commission, or wallet writes.
- Broad deploy while worktree is dirty.

## Growth Loop

Primary near-term growth angle:

- Recruit first-level agents/partners who can bring buyers.
- Copy must say `40% of platform net profit from qualified first-level orders`.
- Copy must not say `40% of order revenue`, second-level commission, transferable coins, recharge balance, or cash-like stored value.
- Promo budget language should stay as `marketing credits` / `promo budget`.

Operational assets already present:

- `docs/agent-admin-standalone-20260616.md`
- `docs/agent-promo-wallet-mvp-20260616.md`
- `prototypes/agent-recruit-demo/`
- `prototypes/agent-recruit-demo-public-archive-20260621/`

Next growth checks:

1. Keep agent demo material out of deployable `mobile-app-v3/public/` until it is intentionally promoted.
2. Verify agent links point to a working domain before sending traffic.
3. Keep agent admin separate at `/agent-admin/`; do not bury it in the customer app or platform admin.
4. Track every growth experiment with source, target page, CTA, and result.

## Ad And Video Loop

Default content direction:

- Real opportunity, real site screenshots, clear earning path.
- Founder/operator tone is better than corporate promo fog.
- Target social formats first: `1080x1920`, 20-45 seconds, direct hook in first 2 seconds.

Video production guardrails from `video-use`:

- Ask for or inspect source material first.
- Confirm strategy before editing.
- Never cut inside a word.
- Add subtitles last in the render chain.
- Output every video project into the source material directory's `edit/`.
- Verify rendered output before presenting.

First three ad concepts:

1. Agent recruitment: "Bring buyers, VivoDraw handles catalog and tracking."
2. Product plus rewards: "Buy real products, earn points, use points for draws or blind boxes."
3. Blind box reveal: "One box, clear odds, reveal, keep or recycle into platform credits."

Execution brief:

- `docs/growth/us-acquisition-video-playbook-20260621.md`
- `docs/growth/us-consumer-acceptance-sprint-20260621.md`
- `docs/growth/us-growth-experiment-ledger-20260621.tsv`
- `docs/growth/us-growth-distribution-ledger-20260621.tsv`
- `docs/growth/us-video-production-kit-20260621.md`
- `docs/growth/us-video-production-queue-20260621.tsv`
- `docs/growth/us-video-script-pack-20260621.tsv`
- `docs/growth/us-video-asset-rights-request-20260621.tsv`
- `docs/growth/us-video-product-shortlist-20260621.tsv`
- `docs/growth/us-video-shot-capture-manifest-20260621.tsv`
- `docs/growth/us-video-ui-capture-log-20260621.md`
- Use it for first US short-form scripts, segment-level subtitles, distribution labels, creator briefs, compliance guardrails, and shot lists.
- Do not launch paid traffic until `deploy/ops/vivodraw-ops-health.sh` passes and lead capture works.
- Before paid traffic, public agent recruitment, public creator CTA, or public product video, run `deploy/ops/check_us_public_launch_readiness.sh`.

## Seven-Day Next Plan

Day 1: Owner/account action: inspect domain edge/CDN/WAF/provider gateway for `403 Beaver` and TLS HTTP `000`.

Day 2: Owner/account action: finish mail DNS by adding provider SPF/DKIM and initial DMARC, then wait for Google and Cloudflare DoH to agree.

Day 3: Re-run `vivodraw_daily_ops_report.sh`, `check_vivodraw_domain_remote.sh`, and `check_us_lead_capture_readiness.sh`; update blocker docs from evidence, not optimism.

Day 4: Keep `docs/ops/us-launch-action-ledger-20260621.tsv` current, then create one short-form agent recruitment script and shot list using the net-profit-first-level rule.

Day 5: Pick 5 candidate products using `docs/product-upload-maintenance-workflow.md`: trend evidence, margin reason, image rights status, reward fit.

Day 6: Run a customer journey smoke: homepage -> product -> cart/checkout entry, plus `/agent-admin/` login surface.

Day 7: Produce a short operating report: uptime checks, domain status, trust surface, growth asset status, top blockers, next three actions.

## Default Codex Behavior For This Goal

When continuing this goal, Codex should:

1. Start with current state: Git status, live health checks, and relevant docs.
2. Separate maintenance, growth, and video work.
3. Fix blockers before making more creative assets when blockers kill conversion.
4. Keep all risky actions explicit: execute or not, writes DB or not, affects production or not, rollback path.
5. Leave a concise handoff after each major phase.
