-- 确保 admin 超级管理员有开盒记录权限
-- 用法：bash deploy/run_fix_openbox_menu.sh 后再执行本脚本，或合并执行

SET NAMES utf8mb4;

-- 1. 确保开盒记录菜单存在（与 fix_openbox_menu.sql 一致）
SET @product_pid = (SELECT `id` FROM `eb_system_menus` WHERE (`header` = 'product' OR `menu_path` = '/admin/product') AND `is_del` = 0 LIMIT 1);
SET @product_pid = IFNULL(@product_pid, 1);

UPDATE `eb_system_menus` SET
  `menu_path` = '/admin/product/openbox_list',
  `unique_auth` = 'admin-product-openbox-list',
  `api_url` = 'product/boxlist',
  `menu_name` = '开盒记录',
  `pid` = @product_pid,
  `header` = 'product',
  `is_show_path` = 0,
  `is_header` = 0
WHERE (`menu_name` = '开盒记录' OR `menu_path` = '/admin/product/openbox_list') AND `is_del` = 0;

INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @product_pid, 1, 'md-cube-outline', '开盒记录', 'admin', 'product.BoxLog', 'index', 'product/boxlist', 'GET', '[]', 5, 1, 0, 1, '/admin/product/openbox_list', '1', 1, 'product', 0, 'admin-product-openbox-list', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/product/openbox_list' AND `is_del` = 0);

-- 2. 确保 admin 账号为超级管理员（level=0）
UPDATE `eb_system_admin` SET `level` = 0, `roles` = '1'
WHERE `account` = 'admin' AND `is_del` = 0;

-- 3. 确保超级管理员角色(id=1)的 rules 为 '*'（全部权限）
UPDATE `eb_system_role` SET `rules` = '*'
WHERE `id` = 1 AND `status` = 1 AND (`rules` = '' OR `rules` IS NULL);
