#!/bin/bash
# 机器人画像：重打包 admin-v2（机器人账户页新增「重排头像/名字」）。只动后台静态包，不动前台与后端 PHP。
set -euo pipefail
ADMIN=/opt/crmeb-prod/backend_src/view/admin
PUB=/opt/crmeb-prod/backend_src/public/admin-v2
STAMP=$(date +%Y%m%d-%H%M%S)
LOG=/tmp/t29-admin-build.log

{
  echo "==> $STAMP node=$(node -v 2>/dev/null || true)"
  grep -q yunmallRobotReprofile "$ADMIN/src/api/yunmall.js"
  grep -q reprofileModal "$ADMIN/src/pages/yunmall/robots/index.vue"
  cd "$ADMIN"
  export NODE_OPTIONS=--openssl-legacy-provider
  node --stack-size=16000 ./node_modules/.bin/vue-cli-service build --mode=production
  test -f "$ADMIN/dist/index.html"
  mkdir -p /opt/crmeb-prod/backend_src/public/admin-backups
  cp -a "$PUB/index.html" "/opt/crmeb-prod/backend_src/public/admin-backups/index.html.$STAMP" || true
  rsync -a --delete "$ADMIN/dist/" "$PUB/"
  ln -sfn admin-v2 /opt/crmeb-prod/backend_src/public/admin
  ln -sfn admin-v2 /opt/crmeb-prod/backend_src/public/admin-shop
  APPJS=$(ls "$PUB"/view_admin/js/app.*.js | head -1)
  echo "APPJS=$APPJS"
  for kw in "重排头像/名字" "重排头像与名字" "机器人账户"; do
    echo -n "$kw count="; grep -o "$kw" "$APPJS" | wc -l
  done
  stat -c '%y %n' "$PUB/index.html"
  echo "DONE_STAMP=$STAMP"
} 2>&1 | tee "$LOG"
