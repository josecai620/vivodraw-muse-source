#!/usr/bin/env bash
# 确保 admin 超级管理员有开盒记录权限
# 用法：ssh root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/run_fix_admin_openbox.sh"
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
SQL_FILE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/migrations/20260516_consolidated_menu_fixes.sql"

for envf in "${PROJECT_DIR}/deploy/.deploy.env" "${PROJECT_DIR}/deploy/.env"; do
  [[ -f "${envf}" ]] && { set -a; source "${envf}" 2>/dev/null || true; set +a; [[ -n "${MYSQL_DATABASE:-}" ]] && break; }
done
[[ -z "${MYSQL_DATABASE}" ]] && [[ -f "${PROJECT_DIR}/backend_src/.env" ]] && {
  MYSQL_DATABASE=$(grep -E '^\s*DATABASE\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed 's/.*=\s*//;s/[[:space:]\x27\x22]*$//' | head -1)
  MYSQL_ROOT_PASSWORD=$(grep -E '^\s*PASSWORD\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed "s/.*=\s*['\"]*//;s/['\"]*[[:space:]]*$//" | head -1)
}
MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-${MYSQL_PASSWORD:-${PASSWORD:-}}}"
MYSQL_DATABASE="${MYSQL_DATABASE:-${DATABASE:-crmeb}}"
APP_USER=$(grep -E '^\s*USERNAME\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed 's/.*=\s*//;s/[[:space:]]*$//' | head -1)
APP_PASS=$(grep -E '^\s*PASSWORD\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed "s/.*=\s*['\"]*//;s/['\"]*[[:space:]]*$//" | head -1)
MYSQL_CONTAINER=$(docker ps --format '{{.Names}}' | grep -i mysql | head -1)
[[ -z "$MYSQL_CONTAINER" ]] && MYSQL_CONTAINER="crmeb-mysql"

echo "==> 修复 admin 开盒记录权限"
run_ok=false
if [[ -n "${MYSQL_ROOT_PASSWORD}" ]] && docker exec -i "$MYSQL_CONTAINER" mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" "${MYSQL_DATABASE}" < "${SQL_FILE}" 2>/dev/null; then
  echo "==> 完成（root）"; run_ok=true
fi
if [[ "$run_ok" != "true" ]] && [[ -n "${APP_USER}" && -n "${APP_PASS}" ]] && docker exec -i "$MYSQL_CONTAINER" mysql -u"${APP_USER}" -p"${APP_PASS}" "${MYSQL_DATABASE}" < "${SQL_FILE}" 2>/dev/null; then
  echo "==> 完成（应用账号）"; run_ok=true
fi
if [[ "$run_ok" != "true" ]]; then
  echo "请确保 MYSQL 可连接，或手动执行: docker exec -i $MYSQL_CONTAINER mysql -u<用户> -p<密码> <数据库名> < deploy/migrations/20260516_consolidated_menu_fixes.sql"
  exit 1
fi
echo "==> 自动清理应用缓存..."
docker exec crmeb-app php think clear 2>/dev/null || true
echo "==> 完成。请退出后台重新登录后访问: http://186.241.72.176/admin/product/openbox_list"
