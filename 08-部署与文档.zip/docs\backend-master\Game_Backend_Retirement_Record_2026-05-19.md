# Game Backend Retirement Record 2026-05-19

## Scope

This record covers backend and database handling for these retired game lines:

- Pet World
- Farm
- Mine

Plain meaning: these backend gameplay and point-writing paths are closed. The v2 frontend game pages are intentionally kept for reference while v3 is still in progress.

## Current Decision

```text
v2 frontend pages: keep
backend gameplay writes: closed
database deletion: not approved
nginx /mine proxy removal: not approved
payment/order/inventory changes: none
Point Gateway switches: remain off
```

Do not remove `/pet`, `/farm`, `/mine`, or `/mine/mobile` from v2 frontend only because this backend record exists. Those pages may still be used as API and UX references during v3 work.

## Backend State

Commit:

```text
d9d1d19a backend: retire pet farm mine game services
```

Files changed:

```text
backend_src/app/services/game/pet/PetWorldServices.php
backend_src/app/services/game/farm/FarmServices.php
backend_src/app/services/game/mine/MineServices.php
```

Behavior after retirement:

```text
Pet World profile/feed/dialogue: returns retired state
Pet World user payload hook: returns null
Pet World starter profile creation: blocked by service-level retired gate
Farm snapshot/actions: return retired state, accepted=false
Mine snapshot/actions: return retired state, accepted=false
```

Important: this is a soft close. Routes may still exist, but service methods return before legacy write paths.

## Database State

Production read-only check after deployment:

```text
eb_game_mine_profile: exists, rows=0
eb_game_mine_node: exists, rows=0
eb_game_mine_inventory: exists, rows=0
eb_game_mine_lab_recipe: exists, rows=0
eb_game_mine_worker: exists, rows=0
eb_game_mine_log: exists, rows=0
eb_game_farm_profile: not exists
eb_user_pet_profile: not exists
game-related user_bill rows: 0
```

No DROP, TRUNCATE, DELETE, UPDATE, migration, or production SQL cleanup was executed for this retirement.

## Switch State

Production switch check after deployment:

```text
core_point_gateway_db_read_enabled: 0
core_point_gateway_db_store_enabled: 0
core_point_gateway_db_write_enabled: 0
core_settlement_game_farm_shadow: 0
core_settlement_game_mine_shadow: 0
core_settlement_pet_feed_shadow: 0
```

Point Gateway remains frozen. Do not enable `core_point_gateway_*` as part of game cleanup.

## Validation

Local validation:

```text
php -l backend_src/app/services/game/farm/FarmServices.php
php -l backend_src/app/services/game/mine/MineServices.php
php -l backend_src/app/services/game/pet/PetWorldServices.php
git diff --check -- backend_src/app/services/game/farm/FarmServices.php backend_src/app/services/game/mine/MineServices.php backend_src/app/services/game/pet/PetWorldServices.php
```

Production validation:

```text
bash deploy/verify_online.sh 8.166.115.27
service direct check: farm=retired, mine=retired, pet=retired
read-only DB row-count check: no game rows created
```

Deployment note: `deploy/update_online.sh` hit rsync code 23 during a large sync. Follow-up remediation restored `public/admin` symlink, `desk-pets` static assets, cleared route cache, restarted PHP-FPM, and online verification passed.

## Guardrails

Do not do these without separate explicit approval:

```text
delete game DB tables
run game migration SQL
remove v2 frontend /pet /farm /mine pages
remove nginx /mine proxy
reconnect retired services to user_bill or user.integral
turn on core_settlement_game_*_shadow switches
turn on core_point_gateway_* switches
touch payment/order/inventory code for this cleanup
```

## Future Cleanup Path

If later approved, recommended order:

```text
1. Confirm v3 no longer needs v2 reference pages.
2. Hide frontend entry buttons first, not backend DB.
3. Review nginx /mine proxy separately as server config.
4. Take backup and confirm row counts again.
5. Only then consider dropping empty mine tables.
```

Until then, leave v2 frontend available and keep backend retired gates in place.
