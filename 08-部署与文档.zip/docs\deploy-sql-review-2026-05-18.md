# Deploy SQL Review 2026-05-18

## 结论

本轮只做只读 review，不执行任何 SQL。

`deploy/fix_*.sql` 这 10 个文件属于后台菜单、权限、编码和兼容视图修复草案。可以保留为候选脚本，但不能在当前总同步阶段直接执行，也不建议和 `game/mobile` 巨量改动混在同一个提交里。

## 当前文件

- `deploy/fix_admin_openbox_permission.sql`
- `deploy/fix_layout_menu_garbled.sql`
- `deploy/fix_mall_menu_encoding.sql`
- `deploy/fix_mall_menu_hex.sql`
- `deploy/fix_manghe_menus.sql`
- `deploy/fix_marketing_permission.sql`
- `deploy/fix_openbox_menu.sql`
- `deploy/fix_openbox_menu_garbled.sql`
- `deploy/fix_regular_mall_menu.sql`
- `deploy/fix_store_product_kaijiang_log_view.sql`

## 风险分级

### 高风险

`deploy/fix_admin_openbox_permission.sql`

- 会更新 `eb_system_admin` 的 `admin` 为 `level=0`、`roles='1'`。
- 会更新 `eb_system_role.id=1` 的 `rules='*'`。
- 风险：权限扩大，必须确认目标环境和管理员策略。

`deploy/fix_manghe_menus.sql`

- 会插入/更新盲盒中奖设置、盲盒赠送抽奖中奖设置菜单。
- 会更新 `admin` 超级管理员权限。
- 风险：同时改菜单和权限，必须先查线上菜单现状。

`deploy/fix_marketing_permission.sql`

- 会修营销父菜单、积分商品路径，并提升 admin/role 权限。
- 风险：权限扩大；路径修正可能影响后台侧边栏。

`deploy/fix_store_product_kaijiang_log_view.sql`

- 会 `DROP VIEW IF EXISTS` 并创建兼容视图：
  - `eb_store_product_kaijiang_log`
  - `eb_store_product_kaijiang_shaidan`
- 风险：如果线上已有同名表而不是 view，执行会失败或需要人工处理；必须先查 `SHOW FULL TABLES`。

### 中风险

`deploy/fix_openbox_menu.sql`

- 插入/更新开盒记录菜单。
- 风险：依赖商品父菜单查找逻辑，需确认 `header='product'` 与后台路由。

`deploy/fix_mall_menu_encoding.sql`

- 直接按 `id=2200..2205` 更新菜单名称和层级。
- 风险：强依赖线上菜单 id，需先查 id 是否一致。

`deploy/fix_mall_menu_hex.sql`

- 直接按 `id=2200..2205` 用 hex 写中文菜单名。
- 风险：同上，适合编码修复，但必须先确认 id。

`deploy/fix_regular_mall_menu.sql`

- 直接修改 `id=2200`、`id=2201`。
- 风险：强依赖固定 id，需先查线上菜单结构。

### 低风险但仍需备份

`deploy/fix_layout_menu_garbled.sql`

- 按 `menu_path='/admin/setting/pages/layout'` 修中文名。
- 风险较低，但仍是线上 DB 写入。

`deploy/fix_openbox_menu_garbled.sql`

- 按 `menu_path='/admin/product/openbox_list'` 修中文名。
- 文件注释含手动 ssh/mysql 执行示例；提交前不应带真实密码。

## 执行前置条件

执行任意脚本前必须另开 DB phase，并完成：

1. 明确目标环境：local / staging / production。
2. 备份 DB，并记录备份路径。
3. 只读查询当前菜单和视图状态。
4. 写 rollback 或恢复步骤。
5. 用户明确批准执行。

建议只读查询：

```sql
SELECT id, pid, menu_name, menu_path, unique_auth, header, is_header, is_del
FROM eb_system_menus
WHERE id IN (2200,2201,2202,2203,2204,2205)
   OR menu_path IN (
     '/admin/product/openbox_list',
     '/admin/setting/pages/layout',
     '/admin/marketing',
     '/admin/marketing/store_integral/index',
     '/admin/marketing/integral/zhongjiangset',
     '/admin/user/choujiang_list',
     '/admin/product/product_list?mall_type=0'
   )
   OR header IN ('product','marketing','user');

SELECT id, account, level, roles, is_del
FROM eb_system_admin
WHERE account = 'admin';

SELECT id, role_name, rules, status
FROM eb_system_role
WHERE id = 1;

SHOW FULL TABLES LIKE 'eb_store_product_kaijiang_log';
SHOW FULL TABLES LIKE 'eb_store_product_kaijiang_shaidan';
SHOW FULL TABLES LIKE 'eb_store_integral_product_kaijiang_log';
SHOW FULL TABLES LIKE 'eb_store_integral_product_kaijiang_shaidan';
```

## 提交建议

- 当前阶段不要执行 SQL。
- 当前阶段不要把这些 SQL 与 `game/mobile` 改动混合提交。
- 若要入库，建议单独提交 `deploy/fix_*.sql` + 本 review 文档。
- 提交前再扫敏感信息、旧 IP、`git diff --check`。

## 当前处理结果

- `backend_src/public/index.php` 风险已修：恢复 PHP 8.1 warning/deprecated 屏蔽，避免接口 JSON 被污染。
- `deploy/fix_*.sql` 未执行、未修改、未 stage。
- 本文档仅记录 review 结论。
