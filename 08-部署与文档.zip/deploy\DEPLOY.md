# ECCOMALL 部署架构说明

**目标读者**：未来接手 / 重新部署这套系统的人（包括几周后的自己）
**最后更新**：2026-04-21（PHP 8.1 + FPM + 独立 Soketi WS 架构上线后）

---

## 一句话概括

**全 Docker 部署，PHP 8.1 FPM + Nginx + 独立 Soketi WS + 5 个独立 Queue Workers**。MySQL 因为历史数据留在 host（未来可按需搬进容器）。

---

## 架构图

```
Client ─HTTP─▶ Nginx:20199 ──FastCGI:9001──▶ PHP-FPM 8.1
                │                                  │
                └── /ws/* ──▶ Soketi:6001 ◀────────┘ HTTP POST / Pusher API
                                  │
                                  └── pub/sub ──▶ Redis:6379

Queue jobs:  Redis ◀── push ── PHP-FPM
                  ▲
                  │ BLPOP
                  │
          Queue workers x5 (systemd @instance)
          CRMEB_PRO / _BATCH / _TASK / _ERP / _LOG

MySQL 8.0: host systemd（127.0.0.1:3306）, databases 全部 utf8mb4_unicode_ci
```

---

## 所有容器

| 容器 | 镜像 | 端口 | 职责 |
|------|------|------|------|
| `crmeb-nginx` | `nginx:1.25-alpine` | 20199 → host | HTTP 反代 PHP-FPM |
| `crmeb-php-fpm` | `eccomall-php81-fpm:latest` | 9001 | PHP 8.1 FPM 进程池 |
| `crmeb-soketi` | `quay.io/soketi/soketi:1.6-16-debian` | 6001 (WS) + 9601 (metrics) | Pusher 协议 WS 服务 |
| `crmeb-redis` | `redis:7-alpine` | 6379 | 缓存 + queue + pub/sub |
| `crmeb-queue-CRMEB_PRO` | `eccomall-php81-fpm:latest` | - | 主 queue worker |
| `crmeb-queue-CRMEB_PRO_BATCH` | 同上 | - | 批处理 queue |
| `crmeb-queue-CRMEB_PRO_TASK` | 同上 | - | 任务 queue |
| `crmeb-queue-CRMEB_PRO_LOG` | 同上 | - | 日志 queue |

所有容器用 `network_mode: host`，所以内部都用 `127.0.0.1:port` 互相访问。

---

## 目录布局

```
/opt/crmeb-prod/
├── backend_src/                    # ThinkPHP 代码（PHP 8.1 版本）
│   ├── app/
│   ├── config/
│   ├── public/
│   ├── vendor/                     # composer 装的包
│   ├── runtime/                    # 写时缓存（www-data 可写）
│   └── .env                        # 核心配置
├── backend_src_old_php74/          # 旧 PHP 7.4 版本备份（稳定后可删）
├── deploy/
│   ├── docker-compose.yml
│   ├── nginx/eccomall.conf
│   ├── docker/
│   │   ├── php81-fpm/Dockerfile    # 当前用这个
│   │   ├── php81-swoole/Dockerfile # 弃用（think-swoole 死包）
│   │   └── php74-swoole/Dockerfile # 弃用
│   └── systemd/
│       └── eccomall-queue@.service # Queue worker 模板
├── backups/                        # 手动 mysqldump 备份
└── archived_swoole_loader/         # swoole_loader 旧 .so 归档
```

---

## systemd 单元

### Queue Workers（模板单元，4 个实例）

```bash
# 启用某一个
systemctl enable --now eccomall-queue@CRMEB_PRO.service

# 看状态
for q in CRMEB_PRO CRMEB_PRO_BATCH CRMEB_PRO_TASK CRMEB_PRO_LOG; do
  echo -n "$q: "
  systemctl is-active "eccomall-queue@$q.service"
done

# 看日志
tail -f /var/log/eccomall-queue-CRMEB_PRO.log
```

模板在 `/etc/systemd/system/eccomall-queue@.service`，每个实例 `docker run --rm` 跑 `php think queue:work`。

### 历史已下线

- `crmeb-swoole.service`（PHP 7.4 + think-swoole，2026-04-21 停）
- think-swoole 死包、PHP 7.4 EOL → 全面切 FPM

---

## 端口表

| 端口 | 监听 | 协议 | 用途 |
|------|------|------|------|
| **20199** | 0.0.0.0 | HTTP + WS | Nginx 主入口：反代 PHP-FPM（/api /adminapi）+ 反代 Soketi（/app /apps）|
| 9001 | 0.0.0.0 | FastCGI | PHP-FPM 进程池 |
| 6001 | 127.0.0.1 | WS + HTTP | Soketi WebSocket + Pusher API（只内部，不对外）|
| 9601 | 127.0.0.1 | HTTP | Soketi Prometheus metrics |
| 6379 | 127.0.0.1 | TCP | Redis |
| 3306 | 127.0.0.1 | TCP | Host MySQL |

所有容器以 `network_mode: host` 跑，所以端口都在 host。

**前端 WS 连接路径**：`ws://{host}:20199/app/{app_key}?protocol=7&client=js&version=8.4`
  Nginx 会把 `/app/*` 和 `/apps/*` 反代到 Soketi（带 WebSocket Upgrade header 支持）。
  这样前端不需要访问 6001 端口，不用跨域，一个域名搞定。

---

## 关键配置

### `backend_src/.env`

```ini
APP_DEBUG = false

[APP]
DEFAULT_TIMEZONE = UTC
APP_KEY = <32-char hex>

[DATABASE]
TYPE = mysql
HOSTNAME = 127.0.0.1
HOSTPORT = 3306
USERNAME = crmeb
PASSWORD = <40-char hex>
DATABASE = manghehoutai_qhe
PREFIX = eb_
CHARSET = utf8mb4                  ; ⚠ 不能写 utf8（= utf8mb3 alias，和表 collation 冲突）
DEBUG = false

[REDIS]
REDIS_HOSTNAME = 127.0.0.1
PORT = 6379
REDIS_PASSWORD = 
SELECT = 0

[CACHE]
DRIVER = redis
PREFIX = manghex
TAG_PREFIX = manghex

[LANG]
default_lang = en-us                ; 主语言英文；?lang=zh-cn 切中文

[PUSH]
driver = soketi                     ; ⚠ 不能写 think_swoole（包已删）

[SOKETI]
app_id     = eccomall
app_key    = eccomall-key
app_secret = <32-char secret>
ws_host    = 127.0.0.1
ws_port    = 6001
```

### `config/push.php`

两种 driver：
- `soketi`：HTTP POST Pusher API → Soketi → WS 客户端（**现用**）
- `think_swoole`：老路径，已弃（think-swoole 包不在 vendor）

### PHP 8.x 兼容

- `php81-fpm/Dockerfile` 的 `98-custom.ini` 里硬设 `error_reporting=8181`（屏蔽 DEPRECATED/NOTICE/WARNING/USER_DEPRECATED）。
- `app/AppService.php::boot()` 里再次 override：ThinkPHP framework 的 `initializer/Error.php` 会硬重置为 E_ALL，必须在 service boot 阶段反压。
- CRMEB 代码里大量 `ltrim(null)`、`strpos(null, ...)` 等 null→string PHP 8.1 deprecated，需要逐步修，短期靠 error_reporting 屏蔽。

### MySQL

- Collation：**全库统一 utf8mb4_unicode_ci**（2026-04-21 一次性 ALTER 303 表）
- Bind：`127.0.0.1`（只对 host loopback）。容器用 `network_mode: host` 访问
- `crmeb` 用户两个 host 版本：`crmeb@localhost` + `crmeb@172.17.%`（备用）

---

## 起停命令

```bash
# 全部起
cd /opt/crmeb-prod/deploy && docker-compose up -d
for q in CRMEB_PRO CRMEB_PRO_BATCH CRMEB_PRO_TASK CRMEB_PRO_LOG; do
  systemctl start "eccomall-queue@$q.service"
done

# 全部停
for q in CRMEB_PRO CRMEB_PRO_BATCH CRMEB_PRO_TASK CRMEB_PRO_LOG; do
  systemctl stop "eccomall-queue@$q.service"
done
cd /opt/crmeb-prod/deploy && docker-compose down

# 看状态
docker ps --format "table {{.Names}}\t{{.Status}}"
systemctl list-units 'eccomall-queue@*'

# 重启某个服务（FPM 代码改动后要重启容器清 opcache）
docker restart crmeb-php-fpm
# 或更温和：
docker exec crmeb-php-fpm php -r 'opcache_reset();'
```

---

## 故障排查

| 症状 | 定位步骤 |
|------|---------|
| API 返回 500 | `docker logs crmeb-php-fpm` + `runtime/log/*_error.log` |
| API 返回 HTML 不是 JSON | 检查 Nginx location `/api/*` rewrite 到 `/index.php?s=$1`（critical）|
| Push 不到客户端 | (1) Soketi `docker logs crmeb-soketi` (2) `.env [PUSH] driver = soketi` (3) `docker exec crmeb-redis redis-cli MONITOR` 看 PUBLISH |
| Queue 消息堆积 | `redis-cli LLEN queues:CRMEB_PRO`；看 `/var/log/eccomall-queue-*.log` |
| MySQL "Conversion from collation" 错 | 检查 `.env CHARSET=utf8mb4`（不是 utf8），表 `SELECT TABLE_COLLATION FROM information_schema.TABLES` |
| FPM 撑不住 | `/usr/local/etc/php-fpm.d/zz-eccomall.conf` `pm.max_children` 从 20 → 更高 |

---

## 升级 / 部署流程

### 代码更新

```bash
cd /opt/crmeb-prod/backend_src
git pull   # 或 rsync

# 如果 composer.json 变了
docker exec crmeb-php-fpm composer install --no-dev -o --no-scripts

# 清 opcache
docker exec crmeb-php-fpm php -r 'opcache_reset();'

# 如果改了 service provider 或监听器，跑 discover
docker exec crmeb-php-fpm php think service:discover

# 重启 queue workers（让它们加载新代码）
for q in CRMEB_PRO CRMEB_PRO_BATCH CRMEB_PRO_TASK CRMEB_PRO_LOG; do
  systemctl restart "eccomall-queue@$q.service"
done
```

### 镜像更新（Dockerfile 改后）

```bash
cd /opt/crmeb-prod/deploy/docker/php81-fpm
docker build -t eccomall-php81-fpm:latest .

# 重启使用新镜像的容器
docker restart crmeb-php-fpm
for q in CRMEB_PRO CRMEB_PRO_BATCH CRMEB_PRO_TASK CRMEB_PRO_LOG; do
  systemctl restart "eccomall-queue@$q.service"
done
```

---

## 回滚

如果 PHP 8.1 出大问题要回滚 PHP 7.4：

```bash
# 停 PHP 8.1 栈
cd /opt/crmeb-prod/deploy && docker-compose down
for q in CRMEB_PRO CRMEB_PRO_BATCH CRMEB_PRO_TASK CRMEB_PRO_LOG; do
  systemctl stop "eccomall-queue@$q.service"
  systemctl disable "eccomall-queue@$q.service"
done

# 恢复老代码
mv /opt/crmeb-prod/backend_src /opt/crmeb-prod/backend_src_failed_php81
mv /opt/crmeb-prod/backend_src_old_php74 /opt/crmeb-prod/backend_src

# 起回 host PHP 7.4 + swoole
systemctl enable --now crmeb-swoole.service

# 起 Redis + Soketi（Soketi 可选，7.4 老代码走 think_swoole）
cd /opt/crmeb-prod/deploy && docker-compose up -d redis soketi
```

---

## 参考

- `docs/php81-migration/README.md` — PHP 8.1 迁移全流程记录
- `docs/php81-migration/websocket_protocol.md` — WS 协议约定 + channel 命名
- `docs/swoole-loader-removal/README.md` — 去 swoole_loader 加密过程
