#!/usr/bin/env bash
# 在本机构建后台前端并上传到服务器
# 用法: bash deploy/本机构建并上传后台前端.sh
set -euo pipefail

SERVER="186.241.72.176"
SSH_USER="root"
SSH_PORT="${SSH_PORT:-49375}"
REMOTE_DIR="/opt/crmeb-prod/backend_src/public/admin"
REMOTE_V2_DIR="/opt/crmeb-prod/backend_src/public/admin-v2"
ADMIN_SRC="backend_src/view/admin"
ADMIN_BUILD_DIR="backend_src/public/admin-v2"

cd "$(dirname "$0")/.."

echo "==> 1. 安装后台前端依赖 (如已安装会很快)"
cd "$ADMIN_SRC"
if [ ! -d node_modules ]; then
  npm install --registry=https://registry.npmmirror.com --legacy-peer-deps
fi

echo "==> 2. 构建后台前端"
export NODE_OPTIONS=--openssl-legacy-provider
export VUE_APP_LEGACY=1
# 使用 node --stack-size 避免 productAdd 等大文件的 Stylus 编译栈溢出
node --stack-size=8192 ./node_modules/.bin/vue-cli-service build --mode=production

echo "==> 3. 上传后台静态资源到服务器 $SERVER:$REMOTE_V2_DIR"
cd - >/dev/null
ssh -p "${SSH_PORT}" ${SSH_USER}@${SERVER} "mkdir -p ${REMOTE_V2_DIR}"
rsync -av --delete -e "ssh -p ${SSH_PORT}" "$ADMIN_BUILD_DIR/" "${SSH_USER}@${SERVER}:${REMOTE_V2_DIR}/"
ssh -p "${SSH_PORT}" ${SSH_USER}@${SERVER} "cd /opt/crmeb-prod/backend_src/public && ln -sfn admin-v2 admin-shop && ln -sfn admin-v2 admin"

echo "==> 完成，后台已使用最新前端代码。请刷新后台页面验收上传图片弹窗。"
