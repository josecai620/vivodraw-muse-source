# CoreSettlement Phase 37 Point Gateway Staging Manifest 2026-05-18

## Current Task

Phase 37 defines the exact commit boundary for Point Gateway / CoreSettlement work.

No file was staged.
No commit was created.
No push was executed.
No deployment was executed.
No SQL was executed.

## Include In Point Gateway Commit

```text
backend_src/app/controller/admin/v1/core/PointGateway.php
backend_src/app/services/core/LegacyPointBillMapperService.php
backend_src/app/services/core/PointGatewayAdminReadService.php
backend_src/app/services/core/PointGatewayAiOperationLogService.php
backend_src/app/services/core/PointGatewayReconciliationService.php
backend_src/app/services/core/PointTransactionService.php
backend_src/app/services/core/contracts/LegacyPointBillMapperServiceInterface.php
backend_src/app/services/core/contracts/PointGatewayAdminReadServiceInterface.php
backend_src/app/services/core/contracts/PointGatewayAiOperationLogServiceInterface.php
backend_src/app/services/core/contracts/PointGatewayReconciliationServiceInterface.php
backend_src/app/services/core/contracts/PointTransactionServiceInterface.php
backend_src/app/services/core/contracts/PointTransactionStoreInterface.php
backend_src/app/services/core/stores/DbPointTransactionStore.php
backend_src/app/services/core/stores/DryRunPointTransactionStore.php
backend_src/app/services/game/farm/FarmSettlementServices.php
backend_src/app/services/game/mine/MineSettlementServices.php
backend_src/app/services/user/UserSignServices.php
backend_src/scripts/core_settlement_backend_package_assert.php
backend_src/scripts/legacy_point_bill_mapper_assert.php
backend_src/scripts/point_gateway_admin_controller_assert.php
backend_src/scripts/point_gateway_admin_permission_contract_assert.php
backend_src/scripts/point_gateway_admin_read_assert.php
backend_src/scripts/point_gateway_admin_route_contract_assert.php
backend_src/scripts/point_gateway_ai_operation_log_assert.php
backend_src/scripts/point_gateway_ai_approval_policy_assert.php
backend_src/scripts/point_gateway_operation_log_schema_assert.php
backend_src/scripts/point_gateway_reconciliation_assert.php
backend_src/scripts/point_gateway_staging_manifest_assert.php
backend_src/scripts/point_transaction_gateway_assert.php
backend_src/scripts/point_transaction_migration_readiness_assert.php
backend_src/scripts/point_transaction_persistence_assert.php
docs/backend-master/CoreSettlement_Phase38_AI_Approval_Policy_2026-05-18.md
docs/backend-master/CoreSettlement_Phase39_Admin_Read_Sensitive_Field_Whitelist_2026-05-18.md
docs/backend-master/CoreSettlement_Phase40_Admin_Permission_Menu_Contract_2026-05-18.md
docs/backend-master/CoreSettlement_Phase41_AI_Operation_Log_Table_Draft_2026-05-18.md
docs/backend-master/CoreSettlement_Phase23_Point_Ledger_Table_Design_2026-05-18.md
docs/backend-master/CoreSettlement_Phase29_Point_Admin_Route_Contract_2026-05-18.md
docs/backend-master/CoreSettlement_Phase30_Point_Reconciliation_Readonly_Skeleton_2026-05-18.md
docs/backend-master/CoreSettlement_Phase31_Point_Admin_Filter_Contract_Hardening_2026-05-18.md
docs/backend-master/CoreSettlement_Phase32_Legacy_User_Bill_Readonly_Mapper_2026-05-18.md
docs/backend-master/CoreSettlement_Phase33_Reconciliation_Mapper_Wiring_2026-05-18.md
docs/backend-master/CoreSettlement_Phase34_Frozen_Expiry_Readonly_Lists_2026-05-18.md
docs/backend-master/CoreSettlement_Phase35_AI_Operation_Log_Draft_2026-05-18.md
docs/backend-master/CoreSettlement_Phase36_Point_Gateway_Index_And_Gate_2026-05-18.md
docs/backend-master/CoreSettlement_Phase37_Point_Gateway_Staging_Manifest_2026-05-18.md
docs/backend-master/Backend_Master_Phase29_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase30_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase31_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase32_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase33_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase34_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase35_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase36_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase37_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase38_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase39_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase40_Handoff_2026-05-18.md
docs/backend-master/Backend_Master_Phase41_Handoff_2026-05-18.md
```

## Force Add Required

`.gitignore` ignores `scripts/`, and `git check-ignore` confirms it matches `backend_src/scripts/*`.

Use explicit force add for assert scripts:

```bash
git add -f backend_src/scripts/
```

Do not use `git add -A` while this worktree contains unrelated active changes.

## Exclude From This Commit

```text
route/admin.php
deploy/*.sql
game/
mobile-app/
mobile-app-v3/
backend_src/public/
backend_src/runtime/
.env
db_backup/
mysql_data/
redis_data/
```

## Current Guards

```text
route/admin.php changed: false
PointGateway route exposed: false
deploy executed: false
SQL executed: false
DB store enabled: false
Manghe/order/payment connected: false
```

## Pre-Commit Validation

```bash
php backend_src/scripts/point_gateway_staging_manifest_assert.php
php backend_src/scripts/point_gateway_ai_approval_policy_assert.php
php backend_src/scripts/core_settlement_backend_package_assert.php
git diff --check -- backend_src/app/controller/admin/v1/core backend_src/app/services/core backend_src/scripts docs/backend-master
```
