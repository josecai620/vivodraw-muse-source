# Game Asset Pipeline

这份文档给 `game/` 外的 Agent、Windows 端、后续新窗口协作者看。以后只要碰 `game` 资源导入、切图、VFX、Spine、atlas、WebP、preview、移动端贴图优化，先读这里。

## 目标

建立 Web 手游资源工业化系统，统一管理：

- UI
- VFX
- Spine
- 粒子
- Shader
- 宝箱
- 矿石
- 宠物
- 图标
- 音效

## Source Of Truth

- 源资源目录：`/Users/joe/eccomall/game/assets/`
- 生成产物目录：`/Users/joe/eccomall/game/assets/build/`
- 流水线配置：`/Users/joe/eccomall/game/assets/pipeline.config.json`
- 构建脚本：`/Users/joe/eccomall/game/scripts/game_asset_pipeline.mjs`
- 命令：
  - `cd /Users/joe/eccomall/game && npm run assets:pipeline`
  - `cd /Users/joe/eccomall/game && npm run assets:pipeline:check`
  - `cd /Users/joe/eccomall/game && npm run assets:pipeline:preview`
  - `cd /Users/joe/eccomall/game && npm run assets:pipeline:ingest`
  - `cd /Users/joe/eccomall/game && npm run assets:pipeline:clean`
  - `cd /Users/joe/eccomall/game && npm run assets:pipeline:watch`
  - `cd /Users/joe/eccomall/game && npm run assets:pipeline:test`
  - `cd /Users/joe/eccomall/game && npm run assets:pipeline:ci`

## 目录结构

以后新资源按下面这组目录直接落，不再走 `assets/source/`。`assets/source/` 视为废弃旧路径，不再继续往里放新资源。

```text
assets/
  ui/
  vfx/
  spine/
  particles/
  shaders/
  ores/
  chests/
  pets/
  icons/
  audio/
  build/
```

其中：

- `assets/build/` 是流水线输出，不是人工素材目录
- `assets/vfx/` 首层必须再分：
  - `glow/`
  - `spark/`
  - `fire/`
  - `wave/`

## 自动能力

### 1. 命名规范检查

- 文件名和子目录名必须是小写 `snake_case`
- 示例：
  - 合法：`ore_fire_epic.png`
  - 禁止：`final.png`
  - 禁止：`new.png`
- 还会检查分类前缀，例如：
  - `ore_...`
  - `chest_...`
  - `pet_...`
  - `icon_...`
  - `vfx_...`

### 2. 自动图片压缩

- 支持 `png/jpg/jpeg/svg/webp` 进入统一导出
- 自动生成对应 `webp`

### 3. 自动 atlas 合图

- 默认对这些分类做 atlas：
  - `ui`
  - `vfx`
  - `particles`
  - `ores`
  - `chests`
  - `pets`
  - `icons`
- `spine` 不走通用 atlas 重打包，只做 Spine 原生 bundle 校验

### 4. 自动透明背景检查

- 默认要求有 alpha
- 默认要求边缘存在透明安全边距，避免贴边和实底污染

### 5. 自动尺寸检查

- `ui` 强制 `512x512`
- `icons` 强制 `128x128`
- 其他分类按配置中的最小/最大限制检查

### 6. 自动资源预览

生成：

- `assets/build/previews/index.html`

里面会展示：

- 分类
- 缩略图
- atlas 信息
- duplicate 标记
- Spine bundle 状态

### 7. 自动检测重复资源

- 对图片做像素级 hash 检测
- 对文本/音频做文件 hash 检测
- 重复结果写入：
  - `assets/build/reports/summary.json`
  - preview 页
  - 各分类 manifest

### 8. Spine 资源检查

自动检测：

- atlas 丢失
- json/skel 丢失
- png/webp/jpg 贴图丢失
- atlas 引用的 page 文件不存在

### 9. Mobile Optimization

自动生成：

- webp
- 压缩后导出
- mipmaps
- texture size limit 后的移动端尺寸

## 输出物

### 1. Asset Pipeline Manager

- `assets/pipeline.config.json`

### 2. Validation System

- `scripts/game_asset_pipeline.mjs`
- `assets/build/reports/summary.json`
- `assets/build/reports/inventory.json`
- `assets/build/reports/state.json`

### 3. Preview Tool

- `assets/build/previews/index.html`

### 4. Build Script

- `npm run assets:pipeline`
- `npm run assets:pipeline:check`
- `npm run assets:pipeline:preview`
- `npm run assets:pipeline:ingest`
- `npm run assets:pipeline:clean`
- `npm run assets:pipeline:watch`
- `npm run assets:pipeline:test`
- `npm run assets:pipeline:ci`

## 当前游戏怎么用

如果是把你们现在项目里已经存在的真资源接进来，先跑：

```bash
cd /Users/joe/eccomall/game
npm run assets:pipeline:ingest
npm run assets:pipeline
```

当前 `ingest` 已经会把这些真实资源导进托管目录：

- 矿石：`apps/web/public/mine/ores/*` -> `assets/ores/`
- 宝箱：`demos/pixi-ore-effect-demo/assets/box-chests/*` -> `assets/chests/`
- VFX：`apps/web/public/mine/vfx/*` 与 `apps/web/public/farm/vfx/*` -> `assets/vfx/`
- 宠物：`apps/web/public/desk-pets/v1/*/*.webm` -> `assets/pets/`

导入后预览页直接看：

- `assets/build/previews/index.html`

### 5. Asset Rules Document

- 当前这份：`/Users/joe/eccomall/docs/game-asset-pipeline.md`

## 协作规则

- 任何 Agent 在 `game` 里新增、替换、整理资源前，先读这份文档。
- 不要手改 `assets/build/`。
- 校验失败时先修源资源，不要绕过脚本。
- 想改尺寸阈值、前缀、VFX 分类、texture limit、mipmap 数量，统一改 `assets/pipeline.config.json`。
- 提交前 hook 会对受管资产自动跑 `assets:pipeline:check`。
- 日常开发优先用缓存构建；想强制全量重建时跑 `assets:pipeline:clean`。
- 需要监听持续导入时跑 `assets:pipeline:watch`，需要回归门禁时跑 `assets:pipeline:ci`。
