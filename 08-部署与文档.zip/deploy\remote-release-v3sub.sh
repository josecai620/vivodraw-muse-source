#!/usr/bin/env bash
# Deploy properly-baseUrl'd V3 build (baseUrl=/v3) as frontend-v3/current.
set -euo pipefail
TS="$(date +%Y%m%d_%H%M%S)"
ROOT=/opt/crmeb-prod/frontend-v3
BUNDLE=/tmp/v3sub-bundle.tar.gz
test -f "$BUNDLE"
mkdir -p "$ROOT/releases"
REL="$ROOT/releases/$TS"
rm -rf "$REL" && mkdir "$REL"
tar -xzf "$BUNDLE" -C "$REL"
test -f "$REL/index.html" || { echo "FATAL: index missing"; exit 1; }
test -d "$REL/_expo" || { echo "FATAL: _expo missing"; exit 1; }

# Retire previous sed-rewritten real directory once, keep as backup.
if [ -d "$ROOT/current" ] && [ ! -L "$ROOT/current" ]; then
  mv "$ROOT/current" "$ROOT/sedcopy-bak-$TS"
fi
ln -sfn "releases/$TS" "$ROOT/current.new"
mv -Tf "$ROOT/current.new" "$ROOT/current"
ls -1t "$ROOT/releases" | tail -n +4 | while read -r old; do rm -rf "$ROOT/releases/$old"; done
rm -f "$BUNDLE"
echo "v3 current -> $(readlink -f "$ROOT/current")"
