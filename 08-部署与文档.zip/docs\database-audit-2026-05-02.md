# 数据库只读审计报告（2026-05-02）

审计对象：测试服务器 `8.166.115.27`，数据库 `manghehoutai_qhe`。

本次只读审计未改表、未删数据、未执行索引变更。审计前已重新导出有效备份：

- `db_backup/db_20260502_182104_host.sql.gz`
- 压缩后约 168MB，解压后约 2.76GB
- 已通过 `gzip -t`，SQL 结尾包含 `Dump completed`

## 基础状态

- MySQL：`8.0.45-0ubuntu0.22.04.1`
- 表数量：311
- 数据库总大小：约 4.08GB
- 数据体积：约 3.06GB
- 索引体积：约 1.01GB
- 服务器内存：约 3.5GB
- `innodb_buffer_pool_size`：128MB，明显偏小
- 慢查询日志：关闭
- `long_query_time`：10s

## 最大的表

| 表 | 行数 | 总大小 | 说明 |
| --- | ---: | ---: | --- |
| `eb_store_integral_product_huanqu_log_unique` | 12,486,913+ | 3.61GB | 积分/抽奖唯一号明细，占库体积绝大部分 |
| `eb_store_integral_product_huanqu_log` | 597,824+ | 210.75MB | 积分换取日志 |
| `eb_user_box` | 345,512+ | 145.17MB | 用户盲盒资产 |
| `eb_box_order` | 203,817+ | 51.56MB | 盲盒订单 |
| `eb_store_integral_product_kaijiang_log` | 45,056+ | 16MB | 开奖日志 |
| `eb_system_log` | 65,712+ | 12.06MB | 后台系统日志 |

## 数据性质

大表里绝大多数是机器人/测试数据：

| 表 | 机器人/测试行 | 非机器人行 |
| --- | ---: | ---: |
| `eb_store_integral_product_huanqu_log_unique` | 12,721,643 | 822 |
| `eb_store_integral_product_huanqu_log` | 609,513 | 228 |
| `eb_store_integral_product_kaijiang_log` | 45,835 | 8 |
| `eb_user_box` | 351,346 | 846 |
| `eb_box_order` | 206,153 | 392 |

这些数据主要集中在 2024-08 到 2025-06。上线前如果确认只是测试/机器人数据，应按业务关系成组归档或清理，不能只删某一张表。

## 主要问题

1. `eb_user_box` 缺少高频查询索引
   - 代码大量按 `uid + product_id + status`、`uid + cate_id + status`、`order_id` 查询。
   - 当前只有主键和 `claim_action` 索引。
   - `EXPLAIN` 显示多条查询会扫 34 万行。

2. `eb_box_order` 缺少订单查询索引
   - 当前只有主键。
   - 按 `order_sn` 查订单会扫 20 万行。
   - 按 `uid` 查列表只能反向扫主键再过滤。

3. 积分抽奖日志缺复合索引
   - `huanqu_log_unique` 查询 `product_id + bianhao + status + isset` 走 `index_merge`。
   - `huanqu_log` 查询 `product_id + bianhao order by id desc` 走 `index_merge + filesort`。

4. 开奖日志按商品期号查询全表扫
   - `eb_store_integral_product_kaijiang_log` 按 `product_id + bianhao` 查询，当前没有对应索引。
   - `EXPLAIN` 显示扫描约 45,056 行。

5. 慢查询观测不足
   - 慢查询日志关闭，`long_query_time=10s` 偏高。
   - 建议测试环境先开启 1-2 秒慢查询窗口，观察真实访问。

6. MySQL buffer pool 偏小
   - 当前数据库 4GB，InnoDB buffer pool 只有 128MB。
   - 服务器可用内存约 1.8GB，可考虑提升到 512MB 或 1GB，需结合 PHP/Redis 占用谨慎调整。

7. 仍有少量 MyISAM 表
   - `eb_user_bank`
   - `eb_user_jiqiren`
   - `eb_user_jiqiren_touxiang`
   - `eb_wechat_key`
   - 低频表，优先级不高，但长期建议转 InnoDB。

## 建议执行顺序

1. 修复备份脚本，确保以后不会导出 20 字节空备份。
2. 在低峰期执行索引 migration 草案。
3. 执行 `ANALYZE TABLE` 刷新统计信息。
4. 开启测试环境慢查询日志，观察 1-2 天。
5. 上线前单独做测试/机器人数据清理方案。
6. 调整 MySQL buffer pool，并观察内存水位。

索引草案见：`deploy/db_optimize_phase6_indexes.sql`。
