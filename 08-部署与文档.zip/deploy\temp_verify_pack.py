# -*- coding: utf-8 -*-
import io, re, os, subprocess, sys
idx = io.open(r'D:\eccomall\mobile-app\dist-root\index.html', encoding='utf-8').read()
for m in re.findall(r'(?:src|href)="([^"]+)"', idx)[:12]:
    print(m)
print('has /v4/:', '/v4/' in idx)
subprocess.run([sys.executable, r'D:\eccomall\deploy\pack_root.py'], check=True)
