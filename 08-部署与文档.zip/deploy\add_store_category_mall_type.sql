-- 商品分类增加商城归属字段：1=常规商城，2=积分商城，4=盲盒商城
-- 兼容历史数据：默认常规商城，并根据已有商品关联回填积分/盲盒分类归属

SET @table_name := 'eb_store_category';
SET @exists_col := (
  SELECT COUNT(1)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = @table_name
    AND COLUMN_NAME = 'mall_type'
);

SET @ddl := IF(
  @exists_col = 0,
  CONCAT(
    'ALTER TABLE `', @table_name, '` ',
    'ADD COLUMN `mall_type` TINYINT(4) NOT NULL DEFAULT 1 COMMENT ''商城类型位标识：1常规 2积分 4盲盒'' AFTER `big_pic`, ',
    'ADD KEY `idx_mall_type` (`mall_type`)'
  ),
  'SELECT 1'
);
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

UPDATE `eb_store_category` c
JOIN (
  SELECT cid, BIT_OR(mt) AS mall_bits
  FROM (
    SELECT spc.cate_pid AS cid, COALESCE(sp.mall_type, 0) AS mt
    FROM `eb_store_product_cate` spc
    INNER JOIN `eb_store_product` sp ON sp.id = spc.product_id
    WHERE spc.cate_pid > 0
    UNION ALL
    SELECT spc.cate_id AS cid, COALESCE(sp.mall_type, 0) AS mt
    FROM `eb_store_product_cate` spc
    INNER JOIN `eb_store_product` sp ON sp.id = spc.product_id
    WHERE spc.cate_id > 0
  ) t
  GROUP BY cid
) m ON m.cid = c.id
SET c.mall_type = IF(m.mall_bits > 0, m.mall_bits, c.mall_type);
