# Agent Promo Wallet MVP

## Scope

- Standalone agent console route: `/agent-admin/`
- Customer frontend route: none. Agent operations must not live inside `mobile-app-v3`.
- User APIs: `/api/v2/agent/promo/*`
- Admin APIs: `/adminapi/agent/promo/*`
- SQL: `deploy/agent_promo_wallet_20260616.sql`
- Purchase request SQL: `deploy/agent_promo_purchase_20260616.sql`
- Rollback: `deploy/rollback_agent_promo_wallet_20260616_approval_required.sql`
- Purchase request rollback: `deploy/rollback_agent_promo_purchase_20260616_approval_required.sql`

## Business Flow

1. Admin approves a user as a creator/agent.
2. Agent requests a VivoDraw physical medal package from `/agent-admin/`.
3. Admin confirms payment/fulfillment and approves the request through `POST /adminapi/agent/promo/purchase_requests/:id/approve`.
4. Approval credits that agent promo budget through the same `medal_credit` ledger path used by `POST /adminapi/agent/promo/credit`.
5. Agent grants promo points only to first-level members where `eb_user.spread_uid = agent_uid`.
6. Grant writes:
   - `eb_agent_promo_wallet.used_points`
   - `eb_agent_promo_ledger`
   - `eb_user.integral`
   - `eb_user_bill` through `UserBillServices::incomeIntegral()`

Product copy should use `marketing credits` or `promo budget`, not transferable coins or stored-value language.

## Seed Packages

- `bronze_medal_500`: $500, 500 promo points
- `silver_medal_1500`: $1500, 1500 promo points
- `gold_medal_3000`: $3000, 3000 promo points

## Admin Credit Example

```http
POST /adminapi/agent/promo/credit
Content-Type: application/json

{
  "uid": 123,
  "points": 500,
  "package_code": "bronze_medal_500",
  "ref_id": "medal-order-10001",
  "reason": "Bronze medal purchase confirmed"
}
```

`ref_id` is used as an idempotency reference for medal credit. Reusing it will not double-credit.

## Purchase Request Examples

```http
POST /api/v2/agent/promo/purchase_requests
X-Client: agent-admin
Authorization: Bearer <agent-token>
Content-Type: application/json

{
  "package_code": "bronze_medal_500",
  "agent_note": "Invoice to creator@example.com",
  "client_request_id": "agent-purchase:unique-id"
}
```

```http
POST /adminapi/agent/promo/purchase_requests/1/approve
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "payment_reference": "wire-20260616-001",
  "admin_note": "Payment confirmed. Bronze medal fulfillment queued."
}
```

Approval creates a `medal_credit` ledger entry with `ref_id = request_no`.

## Safety Rules

- No second-level member scope.
- No self-grant.
- No grant outside first-level downline.
- No grant when wallet is frozen.
- No grant above available budget.
- No wallet credit from a purchase request until admin approval.
- Agents can cancel only pending purchase requests.
- Every grant uses `client_request_id` idempotency from the standalone agent console.
