# -*- coding: utf-8 -*-
import io, os, shutil

SRC = r'D:\eccomall\mobile-app-v3'
DST = r'D:\eccomall\mobile-app'

# 1) 素材
src_assets = os.path.join(SRC, 'assets', '海底寻珠')
dst_assets = os.path.join(DST, 'assets', '海底寻珠')
os.makedirs(dst_assets, exist_ok=True)
for f in os.listdir(src_assets):
    if f.endswith(('.png', '.webp', '.jpg')):
        shutil.copy2(os.path.join(src_assets, f), os.path.join(dst_assets, f))
        print('asset', f)

# 2) 视觉/随机组件 → components/pearl（相对路径 ../../assets 深度不变，无需改）
pearl_dir = os.path.join(DST, 'components', 'pearl')
os.makedirs(pearl_dir, exist_ok=True)
visuals = ['动效组件.tsx', '场景光效.tsx', '海底舞台.tsx', '珍珠蚌图集.tsx', '试玩随机.ts']
for name in visuals:
    s = io.open(os.path.join(SRC, 'features', '海底寻珠', name), encoding='utf-8').read()
    s = s.replace('@/lib/api/海底寻珠', '@/lib/api/pearl')
    # 海底舞台的 useI18n t 仅做英文直取，替换为恒等函数
    if name == '海底舞台.tsx':
        s = s.replace('import { useI18n } from "@/lib/i18n";', '')
        s = s.replace('const { t } = useI18n();', 'const t = (key: string) => key;')
    io.open(os.path.join(pearl_dir, name), 'w', encoding='utf-8', newline='\n').write(s)
    print('visual', name, len(s))

# 3) 待结算探索 → lib/game/pearlPending.ts
s = io.open(os.path.join(SRC, 'features', '海底寻珠', '待结算探索.ts'), encoding='utf-8').read()
io.open(os.path.join(DST, 'lib', 'game', 'pearlPending.ts'), 'w', encoding='utf-8', newline='\n').write(s)
print('logic pearlPending', len(s))

# 4) 主页面 → app/pearl.tsx
page = io.open(os.path.join(SRC, 'features', '海底寻珠', '寻珠页面.tsx'), encoding='utf-8').read()
repls = [
    ('@/lib/api/海底寻珠', '@/lib/api/pearl'),
    ('@/hooks/useSessionReadModel', '@/store/auth'),
    ('import { useI18n } from "@/lib/i18n";',
     'import { useTranslation } from "react-i18next";'),
    ('const { t, language, setLanguage, options } = useI18n();',
     'const { i18n: pearlI18n } = useTranslation();\n'
     '  const language = pearlI18n.language?.startsWith("zh") ? "zh-Hant" : "en";\n'
     '  const setLanguage = (code: string) => { void pearlI18n.changeLanguage(code === "en" ? "en" : "zh-TW"); };\n'
     '  const t = (key: string) => key;'),
    ('const { session, tokenPresent } = useSessionReadModel();',
     'const authToken = useAuthStore((s) => s.token);\n'
     '  const session = authToken ? { token: authToken } : null;\n'
     '  const tokenPresent = !!authToken;'),
    ('useSessionReadModel', 'useAuthStore'),
    ('./海底舞台', '@/components/pearl/海底舞台'),
    ('./场景光效', '@/components/pearl/场景光效'),
    ('./动效组件', '@/components/pearl/动效组件'),
    ('./待结算探索', '@/lib/game/pearlPending'),
    ('./试玩随机', '@/components/pearl/试玩随机'),
    ('../../assets/海底寻珠/', '../assets/海底寻珠/'),
]
for a, b in repls:
    page = page.replace(a, b)
io.open(os.path.join(DST, 'app', 'pearl.tsx'), 'w', encoding='utf-8', newline='\n').write(page)
print('page app/pearl.tsx', len(page))
