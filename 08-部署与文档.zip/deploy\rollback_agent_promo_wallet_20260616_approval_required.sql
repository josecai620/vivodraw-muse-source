-- Rollback for deploy/agent_promo_wallet_20260616.sql.
-- Destructive: drops agent promo wallet tables and their ledger.
-- Run only after exporting these tables if any real test records matter.

DROP TABLE IF EXISTS `eb_agent_member_note`;
DROP TABLE IF EXISTS `eb_agent_promo_ledger`;
DROP TABLE IF EXISTS `eb_agent_promo_wallet`;
DROP TABLE IF EXISTS `eb_agent_promo_package`;
