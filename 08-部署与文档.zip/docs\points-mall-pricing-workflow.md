# Points Mall Pricing Workflow

## Policy

- `1 point = 1 USD`.
- Check-in can grant small points: weekly schedule is `1,1,2,2,3,4,5 = 18 points`.
- Games, pet, mine, and farm grant reward coins; `10 coins = 1 point`.
- Legacy points mall display treated `100 points` as roughly `1 USD`. After the new `1 point = 1 USD` policy, old points mall prices should default to `old_price / 100`.

## Pricing Formula

For existing points draw products:

```text
suggested_points_price = ceil(current_points_price / divisor)
default divisor = 100
```

Use this as a migration formula for already-priced points mall products. If operations wants a softer transition, run the dry-run with `--divisor 10`, review the output, and only then apply.

Examples:

| Old price | Suggested new price |
| --- | --- |
| 680 points | 7 points |
| 780 points | 8 points |
| 1600 points | 16 points |
| 1800 points | 18 points |
| 2200 points | 22 points |

## Backend Dry Run

Run from `backend_src`:

```bash
php think points:mall-reprice
```

Useful options:

```bash
php think points:mall-reprice --limit 20
php think points:mall-reprice --id 123
php think points:mall-reprice --divisor 10
php think points:mall-reprice --divisor 100
```

The command defaults to dry-run and writes JSON. It targets `store_product` rows where `mall_type & 2` is enabled.

## Apply Rules

Only run apply after reviewing dry-run output:

```bash
php think points:mall-reprice --apply
```

Default safety:

- Skips products where `exchange_num > 0`, because a started pool should not be repriced mid-round.
- Skips products missing both `cost` and `ot_price`.
- Updates `price` and recalculates `jindu_bili`.

If a started pool must be repriced, close that round or create a new product/period first. Do not use `--include-started` unless the operator has checked user participation records and accepted the customer support risk.
