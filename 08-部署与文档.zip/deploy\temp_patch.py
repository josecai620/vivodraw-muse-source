# -*- coding: utf-8 -*-
import io, json, collections

EN = r'D:\eccomall\mobile-app\lib\i18n\locales\en.json'
TW = r'D:\eccomall\mobile-app\lib\i18n\locales\zh-TW.json'

en_add = {
    "title": "Delete Account",
    "heroSignedIn": "Delete your Vivodraw account",
    "heroSignInRequired": "Sign in required",
    "heroBody": "This starts permanent account deletion through the authenticated backend. It cannot be undone from the app.",
    "signIn": "Sign in",
    "contactSupport": "Contact support instead",
    "beforeTitle": "Before deleting",
    "note1": "Deletes the member login and removes access to wallet, points, coupons, saved picks, and service history.",
    "note2": "Completed orders, refund records, fraud-prevention logs, and tax records may be retained where law or dispute handling requires it.",
    "note3": "If you only need order help, contact support instead. Account deletion is not a refund shortcut.",
    "confirmTitle": "Confirm deletion",
    "confirmHint": "Type DELETE below, then submit. This protects real accounts from one-tap mistakes.",
    "deleteBtn": "Delete account",
    "finalAlertTitle": "Permanently delete this account?",
    "finalAlertBody": "Wallet, points, coupons and saved data will be removed. This cannot be undone.",
    "keepAccount": "Keep account",
    "confirmDelete": "Delete now",
    "deleted": "Account deletion submitted. Local session cleared.",
    "failed": "Account deletion failed. Contact support.",
    "readPrivacy": "Read privacy policy",
}
tw_add = {
    "title": "註銷帳號",
    "heroSignedIn": "註銷你的 Vivodraw 帳號",
    "heroSignInRequired": "請先登入",
    "heroBody": "此操作將透過已驗證的後端啟動永久註銷流程，App 內無法復原。",
    "signIn": "前往登入",
    "contactSupport": "改為聯絡客服",
    "beforeTitle": "註銷前須知",
    "note1": "將刪除會員登入，並清除錢包、積分、優惠券、收藏與客服記錄的存取權限。",
    "note2": "已完成訂單、退款記錄、防詐風控日誌及稅務記錄，會在法律或爭議處理要求的範圍內保留。",
    "note3": "若只是需要訂單協助請聯絡客服，註銷帳號並非退款捷徑。",
    "confirmTitle": "確認註銷",
    "confirmHint": "請在下方輸入 DELETE 後再提交，避免一鍵誤刪真實帳號。",
    "deleteBtn": "註銷帳號",
    "finalAlertTitle": "確定永久註銷此帳號？",
    "finalAlertBody": "錢包、積分、優惠券與收藏資料將被移除，且無法復原。",
    "keepAccount": "再想想",
    "confirmDelete": "立即註銷",
    "deleted": "註銷申請已提交，本地登入已清除。",
    "failed": "註銷失敗，請聯絡客服。",
    "readPrivacy": "查看隱私權政策",
}

def patch(path, block, setting_label):
    s = io.open(path, encoding='utf-8').read()
    indent = 2
    data = json.loads(s, object_pairs_hook=collections.OrderedDict)
    data.setdefault('settings', collections.OrderedDict())['deleteAccount'] = setting_label
    if 'deleteAccount' in data:
        data['deleteAccount'].update(block)
    else:
        data['deleteAccount'] = collections.OrderedDict(block)
    out = json.dumps(data, ensure_ascii=False, indent=indent) + '\n'
    io.open(path, 'w', encoding='utf-8', newline='\n').write(out)
    print(path, 'ok, top keys', len(data))

patch(EN, en_add, "Delete account")
patch(TW, tw_add, "註銷帳號")
