# US Hot Product Candidate Shortlist

> Date checked: 2026-06-06
> Market: US users first
> Rule: hot signal is required before upload. Image rights and supplier availability still decide final publish.

## Source Snapshot

1. Amazon US Best Sellers, Electronics
   - Strong signals: AirTag, AirPods, Fire TV Stick, Echo Dot, Kindle Paperwhite, surge protector / USB power strip, earbuds, Bluetooth speaker
   - Fit: `Premium Tech`, `Outdoor / Travel`, `Cute Desk / Home Lifestyle`
   - Risk: brand items have transparent prices, so markup must be small or bundled with rewards/service
   - URL: `https://www.amzn.com/Best-Sellers-Line-Conditioners/zgbs/electronics/`
2. Amazon US Best Sellers, Perfumes & Fragrances
   - Strong signals: body mist, vanilla fragrance, affordable perfume, travel-size fragrance
   - Fit: `Beauty & Self-care`
   - Risk: beauty counterfeits and brand rights. Prefer authorized suppliers or generic beauty tools if rights unclear
   - URL: `https://www.amzn.com/Best-Sellers-Perfumes-Fragrances/zgbs/beauty/11056591`
3. Amazon US desk accessories data
   - Strong signals: drawer organizer, electric air duster, LEGO Botanicals desk decor
   - Fit: `Cute Desk / Home Lifestyle`, `Toys / Collectibles`
   - Risk: avoid food/drinks even if they appear in desk queries
   - URL: `https://www.asinsight.com/report/US/desk-accessories`
4. CJdropshipping Winning Products
   - Strong signals: CJ maintains 2026 winning-product and monthly trending lists
   - Fit: sourcing validation after Amazon US demand check
   - Risk: CJ trend blog is not enough by itself. Need product-level supplier cost and images
   - URL: `https://cjdropshipping.com/blogs/winning-products/`
5. GamesRadar 2026 Toys
   - Strong signals: LEGO minifigures, Super Mario range, Fortnite toys, plush/interactive collectibles
   - Fit: `Toys / Collectibles`, blind-box-adjacent rewards
   - Risk: IP goods need licensed sourcing. No random unlicensed copies
   - URL: `https://www.gamesradar.com/toys-collectibles/best-toys/`

## First Upload Bias

| Category | Candidate type | Why US users may accept it | Pricing posture | Decision |
|---|---|---|---|---|
| `Beauty & Self-care` | Body mist / fragrance-style gift | Amazon fragrance best sellers sit in impulse/gift price bands | medium markup if rights clear | `watchlist` |
| `Beauty & Self-care` | LED vanity mirror / beauty tool | Beauty use case + visual product card + CJ sourcing possible | higher markup allowed | `ready_if_image_pass` |
| `Cute Desk / Home Lifestyle` | Drawer organizer set | US desk accessory data shows high order volume and low price | moderate markup, bundle-friendly | `ready_if_supplier_margin_ok` |
| `Cute Desk / Home Lifestyle` | Electric air duster | Practical desk/keyboard use, higher ticket than organizers | moderate markup | `watchlist` |
| `Cute Desk / Home Lifestyle` | Warm desk lamp / decor light | Visual-first, good for mobile cards and TikTok-style videos | higher markup if image strong | `ready_if_trend_confirmed` |
| `Game Gear` | Hall-effect controller | Gaming accessory demand, low warranty complexity vs consoles | moderate markup | `watchlist` |
| `Game Gear` | Gaming headset | Broad user need, giftable, bundleable | moderate markup | `ready_if_reviews_good` |
| `Premium Tech` | AirTag / tracker | Top Amazon electronics signal, easy to understand | low markup only | `watchlist` |
| `Premium Tech` | Kindle / reading device | Strong gift and premium tech fit | low markup only | `watchlist` |
| `Premium Tech` | GaN charger / power strip | Strong everyday utility, desk/travel fit | medium markup if non-brand supplier works | `ready_if_safety_cert_ok` |
| `Toys / Collectibles` | LEGO-style botanicals / desk decor | Desk query and toy trend overlap, strong gift/display angle | moderate markup | `watchlist` |
| `Toys / Collectibles` | Plush charm / blind-box collectible | Strong visual and reward compatibility | higher markup if licensed/generic safe | `ready_if_ip_safe` |
| `Outdoor / Travel` | Power bank / travel charger | Utility is obvious, pairs with gaming/travel | medium markup if safety certified | `ready_if_safety_cert_ok` |
| `Outdoor / Travel` | Sunglasses / travel organizer | Seasonal and easy to photograph | moderate markup | `watchlist` |

## Reject Until Proven

1. Supplements, ingestible beauty, baby safety products
2. Unlicensed IP toys, fake Labubu-style copies, fake branded collectibles
3. Expensive branded electronics with no bundle/service value
4. Products with ugly supplier images and no affordable image-editing path
5. Any product without US demand evidence
