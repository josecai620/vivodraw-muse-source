# VivoDraw US Video Production Kit - 2026-06-21

## Purpose

Turn the acquisition playbook into a production queue for short-form video.

No video is rendered in this pass because no source footage has been provided and `video-use` requires strategy confirmation before editing. This package is pre-production: scripts, shot lists, CTA gates, and validation.

## Queue

Primary tracker:

```bash
docs/growth/us-video-production-queue-20260621.tsv
```

Shot capture manifest:

```bash
docs/growth/us-video-shot-capture-manifest-20260621.tsv
```

Segment-level script pack:

```bash
docs/growth/us-video-script-pack-20260621.tsv
```

Product candidate shortlist:

```bash
docs/growth/us-video-product-shortlist-20260621.tsv
```

Asset rights request:

```bash
docs/growth/us-video-asset-rights-request-20260621.tsv
```

Validation:

```bash
bash deploy/ops/check_us_video_queue.sh
bash deploy/ops/check_us_video_script_pack.sh
bash deploy/ops/check_us_video_shot_capture.sh
bash deploy/ops/check_us_video_product_shortlist.sh
bash deploy/ops/check_us_video_asset_rights.sh
```

Review-only UI capture:

```bash
bash deploy/ops/capture_us_video_ui_shots.sh
```

Output goes to `.codex-artifacts/us-video-ui-captures/` and stays out of Git.
Capture evidence log: `docs/growth/us-video-ui-capture-log-20260621.md`.

## Production Rules

- Format: `9:16`, `1080x1920`, `30fps`, H.264 mp4.
- Use real product clips, licensed catalog images, or real UI captures.
- Do not show `vivodraw.com` in frame until the public entry gate passes.
- Do not use public agent recruitment CTA until agent surface and lead capture pass.
- Paid or compensated creator videos must disclose the relationship in the first 2 seconds.
- Subtitles: large, high contrast, bottom safe, max 5 words per chunk.
- Source footage and final renders must live in the source material folder's `edit/` directory if video editing begins.

## First Batch

### VQ-001 Product Discovery

Goal: make VivoDraw feel like a real product discovery shop before rewards or game mechanics.

Voiceover:

```text
VivoDraw is a product discovery shop for desk life, self-care picks, collectibles, and small tech. Browse real products, check details, and keep member rewards tied to your account. Start with one useful thing. If the experience is good, come back for the fun part.
```

Shots:

1. Product closeups.
2. Mobile homepage.
3. Category grid.
4. Product detail price/specs.
5. Cart or support trust row.
6. VivoDraw CTA card.

### VQ-002 Blind Box Transparency

Goal: present blind box as visible-rules entertainment, not betting fog with prettier icons.

Voiceover:

```text
On VivoDraw, the box flow is simple: see the box, read the rules, then decide. Open one box, reveal the result, and track it in your account. If recycle is available, credit stays inside the platform.
```

Shots:

1. Box shelf.
2. Visible odds panel.
3. Opening preview.
4. Prize result.
5. Recycle center disclaimer.
6. Rules-first CTA card.

### VQ-003 First-Level Agent Recruitment

Goal: recruit operators who can bring buyers without MLM smell.

Voiceover:

```text
This is for people who can bring real buyers, not passive-income tourists. VivoDraw handles catalog, order flow, and tracking. You focus on first-level buyers. The offer is 40 percent of platform net profit from qualified first-level orders.
```

Shots:

1. Talking head.
2. Formula board.
3. Qualified order timeline.
4. Agent-admin preview.
5. Application gate card.

Required on-screen disclaimers:

- First-level only.
- Qualified orders only.
- Net profit, not revenue.
- Marketing Credits stay in-platform.

## Current Readiness

- VQ-001 has a pre-capture manifest for 6 product shots and 3 UI/trust shots.
- VQ-001, VQ-002, and VQ-003 now have segment-level script rows with timecodes, on-screen text, visual direction, disclaimers, launch gates, and status.
- VQ-001 has 6 live product candidates mapped to `SC-001..SC-006`; all remain rights-review candidates, not public ad assets.
- VQ-001 has 6 owner-facing asset requests; all are still `requested`, so public render remains blocked until footage or supplier permission arrives.
- VQ-002 is draft until live box rules/recycle wording is rechecked.
- VQ-003 is blocked until public entry and lead capture pass.

Blunt version: product video can move first. Agent video waits unless we enjoy recruiting people into an application path that cannot receive leads. Beautiful nonsense, still nonsense.
