-- 去掉「盲盒」二字：盲盒商品→商品，盲盒列表→列表

UPDATE `eb_system_menus` SET `menu_name` = 0xE59586E59381 WHERE `id` IN (2, 2205);
UPDATE `eb_system_menus` SET `menu_name` = 0xE58897E8A1A8 WHERE `id` = 3;
