#!/usr/bin/env bash
# 在服务器 Nginx 中启用 gzip 压缩，减少 JS/CSS 传输体积（约可减半）
# 用法：bash deploy/enable_gzip_nginx.sh 186.241.72.176
set -euo pipefail

SERVER="${1:-186.241.72.176}"
SSH="ssh -p 22 root@${SERVER}"

echo "==> 检查并启用 Nginx Gzip 压缩..."

$SSH bash -s << 'REMOTE'
for f in /etc/nginx/sites-enabled/default /etc/nginx/sites-enabled/vivodraw.com.conf /etc/nginx/conf.d/default.conf; do
  [ -f "$f" ] || continue
  if grep -q "gzip on;" "$f"; then
    echo "  $f 已启用 gzip，跳过"
  else
    # 在 server { 后插入 gzip 配置
    if grep -q "server {" "$f"; then
      perl -i -0pe 's/(server \{\s*\n)/$1    gzip on;\n    gzip_comp_level 5;\n    gzip_min_length 1024;\n    gzip_vary on;\n    gzip_types text\/plain text\/css application\/javascript application\/json application\/x-javascript application\/xml image\/svg+xml;\n\n/' "$f" 2>/dev/null || true
      if grep -q "gzip on;" "$f"; then
        echo "  已在 $f 中添加 gzip 配置"
      else
        echo "  ⚠️ $f 修改失败，请手动添加 gzip 配置"
      fi
    fi
  fi
done

nginx -t 2>/dev/null && systemctl reload nginx && echo "✅ Nginx 已重载" || echo "⚠️ 请检查 nginx 配置后手动重载"
REMOTE

echo ""
echo "完成。前端 JS/CSS 传输体积预计可减少约 50%。"
