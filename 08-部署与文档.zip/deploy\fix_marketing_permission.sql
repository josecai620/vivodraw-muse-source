-- 确保 admin 超级管理员有营销模块权限
-- 用法：在服务器执行 mysql < fix_marketing_permission.sql 或通过 phpmyadmin 导入，执行后运行: docker exec crmeb-app php think clear

SET NAMES utf8mb4;

-- 1. 确保营销父菜单存在且 path 正确
UPDATE `eb_system_menus` SET
  `menu_path` = '/admin/marketing',
  `unique_auth` = 'admin-marketing',
  `header` = 'marketing',
  `is_header` = 1
WHERE `header` = 'marketing' AND `is_del` = 0;

-- 1b. 修正错误路径：/admin/integral/product_list -> 积分商品正确路径
UPDATE `eb_system_menus` SET `menu_path` = '/admin/marketing/store_integral/index'
WHERE `menu_path` = '/admin/integral/product_list' AND `is_del` = 0;

-- 2. 确保 admin 账号为超级管理员（level=0）
UPDATE `eb_system_admin` SET `level` = 0, `roles` = '1'
WHERE `account` = 'admin' AND `is_del` = 0;

-- 3. 确保超级管理员角色(id=1)的 rules 为 '*'（全部权限）
UPDATE `eb_system_role` SET `rules` = '*'
WHERE `id` = 1 AND `status` = 1 AND (`rules` = '' OR `rules` IS NULL);
