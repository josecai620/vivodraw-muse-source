# Live Product Upload Record - 2026-06-07

Status: executed on production server `8.166.115.27`.

## Scope

- Target lane: regular mall (`mall_type` includes `1`)
- Existing live regular products before this run: `954`, `955`, `956`, `957`
- New products created in this run: `958`, `959`, `960`
- Payment, orders, ledger, and inventory settlement were not changed.

## Backups

- PHP/config backup: `/opt/crmeb-prod/backups/product-upload-20260607001858`
- Product table backup: `/opt/crmeb-prod/db_backup/product_upload_pre_20260607002131.sql.gz`

## New Live Products

| ID | Product | Category | Price | Stock | mall_type | Image | Source |
|---:|---|---|---:|---:|---:|---|---|
| `958` | `Desktop LED Light Makeup Mirror` | `Beauty & Self-care` | `$59.00` | `60` | `7` | `/uploads/attach/2026/06/07/2aac1c02fd8097df71e3fcf88ad8a90d.png` | CJ page |
| `959` | `Cordless Air Duster` | `Cute Desk / Home Lifestyle` | `$49.00` | `50` | `3` | `/uploads/attach/2026/06/07/750aa0f8a9ef1ac1bcb6e47cef903ee1.png` | CJ page |
| `960` | `Mini Magnetic Wireless Power Bank` | `Outdoor / Travel` | `$39.00` | `80` | `3` | `/uploads/attach/2026/06/07/3a0a83a398aa58226daafd798f6cc5ff.png` | CJ page |

## Execution Notes

- Server code was missing `product:import-drafts`, so only the command file and console registration were synced before import.
- First execute attempt created no products because CJ API key failed when fetching supplier images.
- Temporary warm storefront placeholder images were generated and uploaded to `/uploads/attach/2026/06/07/`.
- Import then created draft products with `is_show=0`.
- Image fields were normalized from `http://localhost/...` to relative `/uploads/...`.
- Products `958`, `959`, and `960` were then set to `is_show=1`.

## Verification

- `GET /api/products?page=1&limit=20&mall_type=0` returned all 7 live regular products.
- New product images returned `HTTP 200` with `Content-Type: image/png`.
- `php think clear` ran after publish.

## Remaining Risk

- The three new images are own-edited temporary placeholders, not final supplier photos.
- Server database does not currently expose `integral_quota` / `manghe_quota` columns on `eb_store_product`; quota behavior should be verified before relying on these products for points or blind-box allocation.
- Amazon-only candidates from `amazon-tiered-hot-products-20260606.csv` were not uploaded because image rights and supplier fulfillment are not cleared.
