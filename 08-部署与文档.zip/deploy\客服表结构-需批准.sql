-- T29：仅供审核，禁止未经批准在生产执行；不包含开关启用或既有业务表修改。
-- 仅新建客服表；默认前缀 eb_，不同部署前缀须由管理员核对。
-- 本版包含 message.review_meta；若测试环境曾建旧表，CREATE IF NOT EXISTS 不会补列，须另审迁移。
CREATE TABLE IF NOT EXISTS eb_support_conversation (
 uid INT UNSIGNED NOT NULL PRIMARY KEY,
 mode VARCHAR(16) NOT NULL DEFAULT 'ai',
 language VARCHAR(8) NOT NULL DEFAULT 'en',
 memory_enabled TINYINT NOT NULL DEFAULT 1,
 memory_after_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
 version INT UNSIGNED NOT NULL DEFAULT 0,
 busy_until INT UNSIGNED NOT NULL DEFAULT 0,
 upload_window INT UNSIGNED NOT NULL DEFAULT 0,
 upload_attempts INT UNSIGNED NOT NULL DEFAULT 0,
 updated_at INT UNSIGNED NOT NULL DEFAULT 0,
 INDEX idx_support_mode (mode, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS eb_support_message (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 uid INT UNSIGNED NOT NULL,
 role VARCHAR(16) NOT NULL,
 kind VARCHAR(16) NOT NULL DEFAULT 'text',
 content TEXT NOT NULL,
 attachment_id VARCHAR(32) NOT NULL DEFAULT '',
 navigation TEXT NOT NULL,
 review_meta TEXT NULL,
 client_key VARCHAR(128) NULL,
 request_hash CHAR(64) NOT NULL DEFAULT '',
 blocked TINYINT NOT NULL DEFAULT 0,
 read_at INT UNSIGNED NOT NULL DEFAULT 0,
 admin_id INT UNSIGNED NOT NULL DEFAULT 0,
 created_at INT UNSIGNED NOT NULL,
 UNIQUE KEY uq_support_request (uid, client_key),
 INDEX idx_support_history (uid, id),
 INDEX idx_support_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS eb_support_alert (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 uid INT UNSIGNED NOT NULL,
 category VARCHAR(40) NOT NULL,
 severity VARCHAR(12) NOT NULL,
 excerpt VARCHAR(600) NOT NULL,
 source_key CHAR(64) NOT NULL,
 occurrences INT UNSIGNED NOT NULL DEFAULT 1,
 acknowledged TINYINT NOT NULL DEFAULT 0,
 ack_by INT UNSIGNED NOT NULL DEFAULT 0,
 ack_at INT UNSIGNED NOT NULL DEFAULT 0,
 created_at INT UNSIGNED NOT NULL,
 updated_at INT UNSIGNED NOT NULL,
 UNIQUE KEY uq_support_alert (source_key),
 INDEX idx_support_alert_open (acknowledged, severity, updated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS eb_support_image (
 id CHAR(32) NOT NULL PRIMARY KEY,
 uid INT UNSIGNED NOT NULL,
 mime VARCHAR(20) NOT NULL,
 width INT UNSIGNED NOT NULL,
 height INT UNSIGNED NOT NULL,
 size INT UNSIGNED NOT NULL,
 used TINYINT NOT NULL DEFAULT 0,
 created_at INT UNSIGNED NOT NULL,
 INDEX idx_support_image_owner (uid, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS eb_support_budget (
 day CHAR(10) NOT NULL PRIMARY KEY,
 calls INT UNSIGNED NOT NULL DEFAULT 0,
 tokens BIGINT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
