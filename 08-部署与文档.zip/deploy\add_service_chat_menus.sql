-- 后台人工客服工作台菜单（A 方案 · 挂在"宠物客服"顶级栏目下）
-- 父菜单在 eb_system_menus: id=1519 (宠物客服, pid=0)

-- 父菜单：人工客服工作台 页面
INSERT INTO eb_system_menus
  (pid, type, icon, menu_name, module, controller, action, api_url, methods, params, sort, is_show, is_show_path, access, menu_path, path, auth_type, header, is_header, unique_auth, is_del)
VALUES
  (1519, 1, '', '人工客服工作台', '', '', '', '', '', '[]', 5, 1, 0, 1, '/admin/pet_kefu/service_chat', '', 0, '', 0, 'marketing-pet_kefu-service_chat', 0);

SET @chat_pid = LAST_INSERT_ID();

-- 挂接口权限 (type=2)
INSERT INTO eb_system_menus
  (pid, type, icon, menu_name, module, controller, action, api_url, methods, params, sort, is_show, is_show_path, access, menu_path, path, auth_type, header, is_header, unique_auth, is_del)
VALUES
  (@chat_pid, 2, '', '用户列表',  '', '', '', 'app/service/chat/users',     'GET',  '[]', 1, 1, 0, 1, '', '', 0, '', 0, 'service-chat-users',     0),
  (@chat_pid, 2, '', '消息记录',  '', '', '', 'app/service/chat/messages',  'GET',  '[]', 2, 1, 0, 1, '', '', 0, '', 0, 'service-chat-messages',  0),
  (@chat_pid, 2, '', '发送消息',  '', '', '', 'app/service/chat/send',      'POST', '[]', 3, 1, 0, 1, '', '', 0, '', 0, 'service-chat-send',      0),
  (@chat_pid, 2, '', '标记已读',  '', '', '', 'app/service/chat/mark_read', 'POST', '[]', 4, 1, 0, 1, '', '', 0, '', 0, 'service-chat-mark_read', 0);

SELECT id, pid, menu_name, api_url, methods, menu_path, unique_auth
FROM eb_system_menus
WHERE pid = 1519 OR pid = @chat_pid
ORDER BY pid, sort;
