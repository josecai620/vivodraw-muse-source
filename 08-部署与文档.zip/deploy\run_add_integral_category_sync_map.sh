#!/usr/bin/env bash
# 创建并执行积分分类 -> 商品分类同步映射
# 用法：ssh root@186.241.72.176 "cd /opt/crmeb-prod && bash deploy/run_add_integral_category_sync_map.sh"

set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
SQL_FILE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/add_integral_category_sync_map.sql"

for envf in "${PROJECT_DIR}/deploy/.deploy.env" "${PROJECT_DIR}/deploy/.env"; do
  [[ -f "${envf}" ]] && { set -a; source "${envf}" 2>/dev/null || true; set +a; [[ -n "${MYSQL_DATABASE:-}" ]] && break; }
done
[[ -z "${MYSQL_DATABASE:-}" ]] && [[ -f "${PROJECT_DIR}/backend_src/.env" ]] && {
  MYSQL_DATABASE=$(grep -E '^\s*DATABASE\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed 's/.*=\s*//;s/[[:space:]\x27\x22]*$//' | head -1)
  MYSQL_ROOT_PASSWORD=$(grep -E '^\s*PASSWORD\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed "s/.*=\s*['\"]*//;s/['\"]*[[:space:]]*$//" | head -1)
}

MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-${MYSQL_PASSWORD:-${PASSWORD:-}}}"
MYSQL_DATABASE="${MYSQL_DATABASE:-${DATABASE:-crmeb}}"
APP_USER=$(grep -E '^\s*USERNAME\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed 's/.*=\s*//;s/[[:space:]]*$//' | head -1)
APP_PASS=$(grep -E '^\s*PASSWORD\s*=' "${PROJECT_DIR}/backend_src/.env" 2>/dev/null | sed "s/.*=\s*['\"]*//;s/['\"]*[[:space:]]*$//" | head -1)
MYSQL_CONTAINER=$(docker ps --format '{{.Names}}' | grep -Ei 'mysql|mariadb' | head -1 || true)
[[ -z "$MYSQL_CONTAINER" ]] && MYSQL_CONTAINER="crmeb-mysql"

echo "==> 执行积分分类同步映射 SQL"
run_ok=false
if [[ -n "${MYSQL_ROOT_PASSWORD}" ]] && docker exec -i "$MYSQL_CONTAINER" mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" --default-character-set=utf8mb4 "${MYSQL_DATABASE}" < "${SQL_FILE}" 2>/dev/null; then
  echo "==> SQL 完成（root）"; run_ok=true
fi
if [[ "$run_ok" != "true" ]] && [[ -n "${APP_USER}" && -n "${APP_PASS}" ]] && docker exec -i "$MYSQL_CONTAINER" mysql -u"${APP_USER}" -p"${APP_PASS}" --default-character-set=utf8mb4 "${MYSQL_DATABASE}" < "${SQL_FILE}" 2>/dev/null; then
  echo "==> SQL 完成（应用账号）"; run_ok=true
fi
if [[ "$run_ok" != "true" ]] && command -v mysql >/dev/null 2>&1 && [[ -n "${APP_USER}" && -n "${APP_PASS}" ]]; then
  if MYSQL_PWD="${APP_PASS}" mysql -u"${APP_USER}" -h127.0.0.1 -P3306 --default-character-set=utf8mb4 "${MYSQL_DATABASE}" < "${SQL_FILE}" 2>/dev/null; then
    echo "==> SQL 完成（本机 mysql 客户端）"; run_ok=true
  fi
fi
if [[ "$run_ok" != "true" ]]; then
  echo "请手动执行: mysql -u<用户> -p<密码> <数据库> < deploy/add_integral_category_sync_map.sql"
  exit 1
fi

echo "==> 清理应用缓存..."
docker exec crmeb-app php think clear 2>/dev/null || true
echo "==> 完成。请刷新后台页面"
