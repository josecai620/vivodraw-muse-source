# 商品上传与维护工作流

> 适用范围：`/Users/joe/eccomall`
> 当前目标：明天先上「热销商品正常卖 + 下单返积分 + 用户再去抽奖/玩盲盒」这条主链路
> 默认边界：先走后台人工/半人工上传；**不默认开启生产自动写库**
> 经营模式：无货源，用户下单后再从 Amazon / CJ 等供应源采购履约

## 1. 先说结论

明天这批商品不要按“纯常规商城”处理，也不要按“纯盲盒奖池”处理。

默认应分成两类：

1. **热销直售商品**
   - 目标：用户正常下单购买
   - 必须有：售价、库存、主图、详情、返积分值
   - 推荐商城位：`常规商城 + 积分商城`
2. **兼容刺激玩法的商品**
   - 目标：既能卖，也能作为积分抽奖/盲盒奖池的一部分
   - 必须额外补：积分可售配额、盲盒可售配额
   - 推荐商城位：`常规商城 + 积分商城 + 盲盒商城`

一句人话：

> 主链路先卖货，积分和盲盒是后续刺激，不是反过来把正常商品都伪装成赌桌。

无货源补充：

> 前台卖的是我们整理后的商品和体验；后端采购可以来自 Amazon / CJ，但商品图、标题、价格、库存不能像复制粘贴批发网页。那不是运营，是把别人后台搬到自己脸上。

代购加价补充：

> 我们可以按代购/精选采购模式加差价。用户能接受的前提是：商品好看、价格不离谱、交付清楚、积分和盲盒权益明确。只加价不做体验包装，那叫让用户替我们交智商税，别这么朴素。

## 2. 现平台真实基线

以下是当前仓库里已经存在的东西，不是空想：

1. 后台商品列表在 `backend_src/view/admin/src/pages/product/productList/index.vue`
   - 已支持 `添加商品`
   - 已支持 `商品采集`
   - 已支持 `导入ERP商品`
   - 已支持 `批量上/下架`、`导出`
2. 后台商品编辑页在 `backend_src/view/admin/src/pages/product/productAdd/index.vue`
   - 已支持 `mall_type`
   - 已支持 `integral_quota`
   - 已支持 `manghe_quota`
3. 商品保存校验在 `backend_src/app/services/product/StoreProductServicesTrait.php`
   - `integral_quota` 不能大于总库存
   - `manghe_quota` 不能大于总库存
   - 两者之和也不能大于总库存
4. 前台 v3 商品浏览当前吃的是 `mall_type=2` 商品流
   - 文件：`mobile-app-v3/lib/api/catalog.ts`
   - 这意味着：**你明天要让商品出现在当前 v3 前台，至少要打上积分商城位**
5. 仓库里虽然有 `backend_src/app/controller/openapi/Product.php`
   - 但 `backend_src/route/openapi.php` 现在直接返回 `410`
   - 结论：**现在不能假装已经有稳定对外自动上传接口**
6. `backend_src/app/controller/openapi/Product.php` 里已有 CJ 采集逻辑雏形
   - 可读取 CJ 商品信息和图片
   - 但因为 `openapi` 路由停用，当前不能当成生产可用自动入口

## 2.5 无货源采购与图片来源规则

默认采购优先级：

1. `CJ`
   - 用于可长期履约、可查库存、可拿商品图集的商品
   - CJ API 商品详情里有 `bigImage` 和 `productImageSet`
   - 适合做稳定货源和图片主来源
2. `Amazon`
   - 用于热销参考、价格参考、临时采购、品牌商品补货
   - Amazon 图片不能默认直接下载后放前台
   - 合规方式是官方 PA API / Associates Program 授权内容，或品牌/供应商可复用素材
3. `Manufacturer / Brand site`
   - 用于品牌商品的官方图、尺寸图、包装图
   - 必须记录来源链接
4. `Own edited images`
   - 用供应商授权图做裁切、背景统一、场景化处理
   - 不能改错真实商品结构、型号、Logo

图片抓取原则：

1. 商品首图和轮播图必须是实物图；AI 生成图、抽象图、纯氛围图、概念渲染图不能作为前台商品图
2. CJ：优先抓 `bigImage` + `productImageSet`
3. Amazon：优先抓 ASIN、采购链接、价格、评分、规格；图片只进入 `needs_rights_check`
4. 品牌/供应商：能证明可复用才进 `pass`
5. 不确定版权：不上传到前台

图片来源状态：

- `authorized`：可用于前台
- `cj_api`：来自 CJ API，可作为待处理图
- `pa_api`：来自 Amazon PA API/Associates 授权内容
- `supplier_permission`：供应商明确允许
- `needs_rights_check`：只能做内部选品参考
- `reject`：不能用

## 2.6 代购定价规则

无货源定价不要只看采购价。每个商品按这条公式走：

```text
landed_cost = procurement_cost + shipping_buffer + risk_buffer
markup_amount = service_margin + reward_cost_buffer
sale_price = landed_cost + markup_amount
markup_rate = markup_amount / landed_cost
give_integral = floor(markup_amount * 0.6)
```

字段含义：

1. `procurement_cost`
   - Amazon / CJ 当前采购价
2. `shipping_buffer`
   - 运费、汇率、临时涨价缓冲
3. `service_margin`
   - 我们的代购/精选/履约服务差价
4. `reward_cost_buffer`
   - 返积分、抽奖、盲盒玩法成本缓冲
5. `risk_buffer`
   - 退款、缺货、补差价、售后风险
6. `pricing_note`
   - 写清楚“采购多少钱、加价多少钱、为什么用户能接受”

返积分规则：

- 常规商城商品只能按利润返积分，不能按售价返。
- `give_integral` 默认取 `markup_amount * 60%` 后向下取整。
- 如果 `markup_amount` 缺失，才用 `price - landed_cost`；再缺失才用 `price - cost`。
- 例：采购价 `$70`，售价 `$100`，利润 `$30`，最多返 `18` 积分；售价 `$120`，利润 `$50`，最多返 `30` 积分。
- 不允许 `$100` 商品直接返 `100` 积分，除非我们准备顺手开一家慈善基金会。

每个商品必须写出价格分析。最低格式：

```text
采购价 $32 + 运费/风险 $10 = 落地成本 $42；服务/奖励加价 $27；售价 $69；加价率 64.3%。理由：礼物感强、图好看、返积分明确。
```

建议价格带：

1. `Impulse`
   - `$19-$49`
   - 适合 cute desk、beauty mini、小礼物
   - 可加较高百分比差价，但绝对金额别刺眼
2. `Giftable`
   - `$49-$129`
   - 适合香氛、化妆镜、耳机、桌搭套装
   - 用户更看包装、图感、积分权益
3. `Mid`
   - `$129-$499`
   - 适合主机、手柄、电子大件
   - 差价要收敛，必须说明配送和权益
4. `High`
   - `$1,000-$3,000`
   - 适合 MacBook / gaming laptop / e-bike / massage chair / premium reward anchor
   - 默认只做 `watchlist` 或 `quoted-order`，不直接批量上架
   - 差价通常控制在 `6%-12%` 或 `$80-$300`，别把透明大牌硬加价加成诈骗味
   - 必须提前确认：运费、退货、保修、缺货补差价、图片授权、是否可回滚下架

上架价判断：

1. Amazon 同款价格太透明的大牌商品
   - 差价别太猛
   - 靠积分、礼盒、服务、活动权益补价值
2. CJ / 非强品牌商品
   - 可做更强视觉包装和组合销售
   - 但别把廉价图包装成奢侈品，用户不是没网
3. 可进盲盒/抽奖池商品
   - 额外留 `reward_cost_buffer`
   - 别把全部毛利用返积分吃光

定价状态：

- `ready`：价格、成本、缓冲都清楚
- `needs_cost_check`：采购价/运费不稳
- `needs_margin_review`：差价过高，需要人工确认
- `reject`：价格没有用户接受理由

## 2.7 美国热销选品门槛

上传商品前必须先查美国用户热销，不准凭“我觉得这个可爱”上架。可爱不是 SKU 审核标准，最多算一票。

每个商品至少要过 3 个门：

1. `trend_signal`
   - Amazon US Best Sellers / CJ Winning Products / TikTok Shop US / Google Trends US / 美国类目榜单里有证据
2. `acceptance_signal`
   - 评分、评论、销量、价格带、复购属性里至少有 2 个站得住
3. `platform_fit`
   - 图片能做美，价格能加差价，能自然挂积分/抽奖/盲盒权益

默认证据源：

1. `Amazon Best Sellers`
   - 用来判断美国用户是否已经接受这个品类
   - 官方榜单会频繁更新，所以每次批次都要重新查
2. `CJ Winning Products / CJ product data`
   - 用来判断无货源履约和供应可行性
3. `Amazon/CJ price + rating + review count`
   - 用来判断定价空间
4. `TikTok / Reels / Shorts trend`
   - 用来判断图片和视频获客潜力

当前美国热销参考清单：

```text
docs/us-hot-product-candidate-shortlist-20260606.md
```

选品状态：

- `ready`：热销证据、价格、图片、货源都过关
- `watchlist`：热销但价格/图片/货源未过关
- `needs_trend_check`：还没查，不能上传
- `reject`：用户接受度弱、图难看、价格没理由、版权/货源风险大

第一批倾向：

1. `Beauty & Self-care`
   - 香氛/身体喷雾、护肤小工具、美妆镜、旅行清洁用品
2. `Cute Desk / Home Lifestyle`
   - 桌面收纳、氛围灯、桌面清洁、电源/充电、可展示小物
3. `Game Gear`
   - 手柄、耳机、Switch/PS5 配件、收纳包、屏幕保护
4. `Premium Tech`
   - AirTag/追踪器、Kindle/阅读器、耳机、GaN 充电器、智能显示/投屏
5. `Toys / Collectibles`
   - LEGO/积木、盲盒小摆件、毛绒挂件、游戏/IP 收藏小物
6. `Outdoor / Travel`
   - 旅行充电、便携电源、收纳、太阳镜、露营灯

明确不做：

- 热销但图丑
- 热销但侵权风险高
- 热销但价格透明到没法加差价
- 热销但售后坑大
- 平台已有玩法接不上的纯低价杂货

## 3. 明天建议先上的类目

先收窄，不要又想卖全世界。正式先上 6 个：

1. `Beauty & Self-care`
2. `Cute Desk / Home Lifestyle`
3. `Game Gear`
4. `Premium Tech`
5. `Toys / Collectibles`
6. `Outdoor / Travel`

这 6 个是当前平台第一批正式类目。不要临时加 `Fashion`、`Food`、`Baby`、`Health supplement` 这类坑位。

原因很简单：

- 购买欲高，图容易做美
- 适合代购差价和积分权益包装
- 能接抽奖/盲盒玩法
- 不会把站子做成“啥都卖但啥都不强”的杂货铺

暂缓类目：

1. `Fashion / Shoes`
   - 尺码、退换货、图差异麻烦
2. `Food / Supplements`
   - 合规、保质期、真假风险高
3. `Baby Products`
   - 安全责任高，不适合第一批
4. `Large Appliances`
   - 履约、售后、运费压力大

## 3.5 明天建议先上的货

如果你让我直接拍板，我会优先上这些“购买欲更高”的东西：

1. `Beauty & Self-care`
   - 化妆镜
   - 美妆工具
   - 护发工具
   - 香氛/护理礼盒
   - mini gift set
2. `Cute Desk / Home Lifestyle`
   - 桌面氛围灯
   - 收纳
   - 香薰
   - 杯子
   - 小家电
3. `Game Gear`
   - PS5/Switch 配件
   - 高颜值手柄
   - 头戴耳机
   - 便携手柄充电底座
4. `Premium Tech`
   - PS5 Slim
   - Switch OLED
   - Kindle
   - 移动 SSD
   - 智能屏
5. `Toys / Collectibles`
   - LEGO 风积木
   - blind box 摆件
   - AI toys
   - plush charm
   - 收藏小物
6. `Outdoor / Travel`
   - 便携电源
   - 旅行收纳
   - 墨镜
   - 露营灯
   - 车载小物

明天不要把首批全做成“硬核 3C 配件大卖场”。

原因不是我矫情，是大众购买欲就没那么高。能冲动下单的，往往是：

- 礼物感强
- 自用也舒服
- 价格带清楚
- 看图就能理解价值

高价电子可以有，但必须放在 `Premium Tech` 少量做，不是让整站都像数码批发城。

## 3.6 前后台类目维护规则

正式后台类目用 `store_category`。首批类目种子脚本：

```text
deploy/seed_v3_product_categories_20260606.sql
```

规则：

1. 类目中文名给后台工人看，英文名给 v3 前台显示
2. 首批 6 个类目默认 `mall_type=7`
3. `mall_type=7` 表示常规商城、积分商城、盲盒商城都可见
4. 后台商品可继续用现有能力上架、下架、改价格、改库存、改类目
5. 不要把所有商品塞进 `Blind Box` 旧类目，盲盒是玩法，不是正常商品分类垃圾桶

## 3.7 商品图标准

图片必须先过关。商品再热，图丑也会把购买欲打没。

首图硬标准：

1. 商品主体必须清楚、完整、第一眼能认出来
2. 主体占画面约 `70%-85%`
3. 背景干净，有质感，但不能抢商品
4. 移动端商品卡里不能变成一坨小图
5. 不用低清、暗光、糊图、拼接海报、水印图
6. 不用满屏文字图，商品图不是小红书封面比赛

轮播图最低组合：

1. `Hero`：最吸引人的首图
2. `Detail`：材质、接口、容量、颜色、做工等关键细节
3. `Scale`：让用户知道大小和使用场景
4. `Package`：套装/礼盒/配件清楚展示
5. `Reward`：能自然表达“买了有积分/可参与玩法”，但不能假造中奖暗示

图片拒收规则：

1. 主体被切掉
2. 商品太小
3. 背景比商品更抢眼
4. 图上有平台水印、价格贴纸、无关促销字
5. 品牌/型号看起来像假的
6. AI 生成图把真实品牌商品画错
7. 透明图没有 alpha，只是棋盘格假透明

## 3.8 后台草稿导入命令

批量 CSV 先走命令，不直接手写 SQL。SQL 很快，也很会把后台写成事故现场。

命令：

```bash
cd backend_src
php think product:import-drafts ../docs/product-batches/us-hot-products-batch-20260606.csv
```

默认只 dry-run：读 CSV、查分类、查重复 `soure_link`，不创建商品。

真正写入草稿：

```bash
cd backend_src
php think product:import-drafts ../docs/product-batches/us-hot-products-batch-20260606.csv --execute
```

硬规则：

1. 永远强制 `is_show=0`
2. 只处理 `source_platform=cj`
3. 默认跳过 `watchlist`
4. 默认跳过 `needs_cost_check`
5. 默认跳过 `image_status` 不是 `pass` 的商品
6. 用 `soure_link` 防重复导入
7. 商品图优先用 CSV 里的合规 URL；没有 URL 时才用 CJ API 拉供应商图

临时草稿例外：

```bash
php think product:import-drafts ../docs/product-batches/us-hot-products-batch-20260606.csv --execute --allow-unpolished-images
```

这只适合内部草稿排版，不准直接上架。图没过审就上架，转化率会像石头一样沉，别装作没发生。

发布前必须做一次移动端图检：

1. `390px` 宽商品卡看首图
2. 商品详情首屏看主图
3. 确认主体完整、不贴边、不糊、不露奇怪背景
4. 不合格先修图/换图，不进上架批次

## 3.7 平台视觉匹配

商品图必须融入当前 v3 的 `warm editorial commerce`，不能像随便从供应商后台扒来的白底小图。

平台图感方向：

1. 暖、干净、稍微高级
2. 商品主体真实可信
3. 背景有生活感或礼物感
4. 色调适合奶油白、深绿墨色、暖橘、柔金 UI
5. 图片看起来像精品会员商城，不像低价批发页

首图优先级：

1. `Beauty & Self-care` / `Cute Desk / Home Lifestyle`
   - 优先生活方式图、礼盒图、柔和桌面场景
   - 避免廉价粉色、过度贴纸、满屏卖点字
2. `Game Gear` / `Premium Tech`
   - 优先真实产品特写、干净桌面、套装陈列
   - 避免灰黑冷硬、电竞霓虹、杂乱线缆
3. `Outdoor / Travel`
   - 优先使用场景和尺寸感
   - 避免硬邦邦参数海报
4. `Prize-compatible`
   - 图要让人觉得“这个奖值得抽”
   - 但不能暗示用户必中奖，也不能做博彩感视觉

图片统一规则：

1. 色温偏暖，不要冷蓝灰
2. 背景复杂度低，主体最强
3. 同一批图尽量统一构图比例
4. 商品详情可用白底清晰图，但首图必须更有吸引力
5. 如果只有供应商白底图，先做二次裁切/背景处理，再进批次
6. AI 辅助图只能做背景/氛围，不允许篡改真实商品结构、品牌、型号

一句话：

> 用户第一眼要觉得“这东西我想要”，不是“这张图从哪个批发网站抠来的”。

无货源图处理顺序：

1. 先从 CJ / 供应商 / 官方授权渠道拿原图
2. 先确认原图是真实商品照片，不是 AI 图、插画、抽象场景图或概念渲染图
3. 再选首图，裁到平台卡片能展示
4. 再做暖调、干净背景、轻场景化
5. 最后才进入上传批次

Amazon 图特殊处理：

1. 不直接把 Amazon 页面图下载后放前台
2. 可以用 Amazon 做选品判断和采购链接
3. 如果走 Amazon Associates / PA API，按其授权范围展示
4. 如果没有授权，改找 CJ / 品牌官网 / 供应商图

## 4. 商城位规则

后台 `mall_type` 是位运算：

- `1` = 常规商城
- `2` = 积分商城
- `4` = 盲盒商城

明天默认规则：

1. **普通热销直售商品**
   - 用 `3`
   - 即：`1 + 2`
   - 含义：正常卖，同时在当前 v3 商品流可见
2. **既卖货又允许进入盲盒/抽奖池的商品**
   - 用 `7`
   - 即：`1 + 2 + 4`
3. **纯盲盒奖池商品**
   - 只在明确需要时才用 `4`
   - 明天不建议拿它做主力上传批次

## 5. 字段最低要求

每个商品至少给我这些字段：

| 字段 | 必填 | 说明 |
|---|---|---|
| `action` | 是 | `create` / `update` / `stock` / `price` / `unpublish` |
| `product_key` | 是 | 你的外部唯一键，别让我靠商品名猜你是谁 |
| `store_name` | 是 | 前台商品名 |
| `category` | 是 | 使用 6 个正式类目之一 |
| `mall_type_bits` | 是 | 推荐默认 `3` 或 `7` |
| `source_platform` | 是 | `cj` / `amazon` / `brand` / `manual_supplier` |
| `source_product_id` | 建议 | CJ product id / Amazon ASIN / supplier SKU |
| `market_region` | 是 | 第一批默认 `US` |
| `trend_sources` | 是 | Amazon US / CJ / TikTok US / Google Trends US 等证据源 |
| `trend_evidence` | 是 | 榜单、销量、评分、评论、价格带证据 |
| `acceptance_signal` | 是 | `high` / `medium` / `low`，按美国用户接受度判断 |
| `trend_status` | 是 | `ready` / `watchlist` / `needs_trend_check` / `reject` |
| `procurement_cost` | 是 | 当前采购价 |
| `shipping_buffer` | 是 | 运费/涨价缓冲 |
| `service_margin` | 是 | 我们加的代购/精选服务差价 |
| `reward_cost_buffer` | 是 | 积分/抽奖/盲盒成本缓冲 |
| `risk_buffer` | 是 | 退款、缺货、涨价、售后风险缓冲 |
| `landed_cost` | 是 | `procurement_cost + shipping_buffer + risk_buffer` |
| `markup_amount` | 是 | `service_margin + reward_cost_buffer` |
| `markup_rate` | 是 | `markup_amount / landed_cost` |
| `pricing_status` | 是 | `ready` / `needs_cost_check` / `needs_margin_review` / `reject` |
| `price` | 创建必填 | 售价 |
| `ot_price` | 建议 | 划线价 |
| `cost` | 建议 | 成本价 |
| `stock` | 创建必填 | 总库存 |
| `give_integral` | 是 | 用户购买后返的积分，默认 `floor(markup_amount * 0.6)`，不能按售价填写 |
| `integral_quota` | 条件必填 | `mall_type_bits` 含 `2` 时建议填写 |
| `manghe_quota` | 条件必填 | `mall_type_bits` 含 `4` 时必须填写 |
| `unit_name` | 是 | 如 `piece` / `set` |
| `image` | 是 | 首图 |
| `slider_images` | 是 | 轮播图，多张用 `|` 分隔 |
| `image_brief` | 是 | 商品图要表达的卖点 |
| `visual_fit` | 是 | `warm_premium` / `giftable` / `premium_tech` / `lifestyle` |
| `image_rights_status` | 是 | `authorized` / `cj_api` / `pa_api` / `supplier_permission` / `needs_rights_check` / `reject` |
| `image_status` | 是 | `pass` / `needs_reshoot` / `needs_cutout` / `reject` |
| `source_link` | 建议 | 采购链接/来源链接 |
| `publish` | 是 | `0`=先不上架，`1`=直接上架 |
| `pricing_note` | 是 | 一句话写清成本、加价、用户接受理由 |

## 6. 你怎么把任务交给我

以后直接给我两种东西之一：

1. 一份表
   - 用 [docs/templates/product-batch-intake.csv](/Users/joe/eccomall/docs/templates/product-batch-intake.csv)
2. 一段消息
   - 按这个顺序贴：`类目 / 商品名 / 美国热销证据 / 采购价 / 运费缓冲 / 加价 / 售价 / 库存 / 返积分 / 是否进盲盒池 / 图片 / 来源链接 / 定价理由`

我接手后的动作固定为：

1. 补齐字段并归类
2. 判断该商品用 `3` 还是 `7`
3. 算积分位和盲盒位配额
4. 生成待上传批次
5. 上传前给你一份“本批次摘要”
6. 你确认后，再做实际上架动作

## 7. 明天的执行顺序

### A. 批次准备

先把商品按这 3 组分开：

1. `Main sellers`
   - 真正承担销售额
   - 默认 `mall_type_bits=3`
2. `Prize-compatible sellers`
   - 既卖也可做奖池
   - 默认 `mall_type_bits=7`
3. `Do not upload tomorrow`
   - 图不行
   - 成本不清
   - 供应链不稳
   - 详情没法写

### B. 上传策略

明天建议按批次来，不要一口气灌满：

1. 第一批：`5-10` 个核心热销款
2. 第二批：`3-5` 个可进奖池的高感知商品
3. 第三批：补图、补库存、补描述，不急着上架

### C. 上架策略

默认不要“录完就上”。

先走：

1. 建商品
2. 不上架 `publish=0`
3. 检查前台是否展示正确
4. 再统一切 `publish=1`

不然前台一边露丑一边卖，用户比你还先发现。

首页展示默认规则：

1. 商品上架后必须带常规商城位，即 `mall_type` 包含 `1`
2. 首页默认读取常规商城商品流 `/api/products?page=1&limit=24&mall_type=0`
3. 首页默认展示最新 `8` 个常规商城商品
4. 如果商品已上架但首页没出现，先查 `is_show`、`mall_type`、图片 URL、商品排序，再查前端
5. 不要只把商品塞进后台列表就说“上架完成”，用户看不到就等于没上架

## 8. 我接手后的维护范围

你把商品交给我后，我可以持续维护这些动作：

1. 新建商品批次
2. 补图、改标题、改副标题、改价格
3. 调整 `give_integral`
4. 调整 `integral_quota`
5. 调整 `manghe_quota`
6. 上下架
7. 生成“明天要补哪些货”的清单

## 9. 维护节奏

建议固定成 3 个循环：

1. **日更**
   - 价格
   - 库存
   - 上下架
2. **周更**
   - 热销款替换
   - 积分回报力度
   - 奖池配额
3. **活动前**
   - 盲盒池单独复核
   - 高价值商品库存复核
   - 前台展示复核

## 10. 明天的上传判断规则

满足下面 4 条才进明天批次：

1. 图能用
2. 价格和成本都清楚
3. 库存不是瞎填
4. 能明确说出它卖货价值，不只是“能当奖品”

只适合做奖池、不适合正常卖的，别混进第一批热销款。

图片补充规则：

- `image_status=not_real_photo`：不是实物图，不上传
- `image_status=reject`：不上传
- `image_status=needs_reshoot`：先找图/重拍，不上传
- `image_status=needs_cutout`：先抠图/裁图，不上传
- `image_status=pass`：才进入待上传批次
- `image_rights_status=needs_rights_check`：只能内部参考，不上传前台
- `source_platform=amazon` 且没有 `pa_api` / `supplier_permission`：不上传 Amazon 图

## 11. 风险边界

当前我能先稳定接手的是：

1. `商品整理`
2. `批次编排`
3. `上传清单生成`
4. `后台人工/半人工录入协助`
5. `上架前检查`
6. `后续维护清单`

当前还**不应该默认承诺**的是：

1. 直接对生产自动批量写库
2. 依赖已停用的 `openapi/outapi`
3. 未登录后台情况下的真上传

## 12. 明天你只要这样给我

最省事的格式：

> 给你第一批 8 个商品，主类目是 consoles / game gear / electronics。  
> 其中 5 个走 `3`，3 个走 `7`。  
> 我先给你表和图片，你帮我整理成待上传批次。

我收到后就按这份流程干，不再来回猜你意思。
