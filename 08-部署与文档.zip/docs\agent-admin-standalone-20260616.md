# Standalone Agent Admin Console

## Decision

Agent operations now live in a separate static console at `/agent-admin/`.

This console is not part of:

- Customer frontend: `mobile-app-v3`
- Platform admin: `/admin-shop`

The customer app no longer exposes `/creator` or a `Creator desk` profile entry.

## Files

- Static console: `backend_src/public/agent-admin/index.html`
- Console styles: `backend_src/public/agent-admin/assets/app.css`
- Console logic: `backend_src/public/agent-admin/assets/app.js`
- Nginx route template: `deploy/nginx/eccomall.conf`

## API Boundary

Agent-facing APIs:

- `POST /api/login`
- `GET /api/v2/agent/promo/dashboard`
- `GET /api/v2/agent/promo/members`
- `GET /api/v2/agent/promo/ledger`
- `GET /api/v2/agent/promo/orders`
- `GET /api/v2/agent/promo/recoveries`
- `GET /api/v2/agent/promo/purchase_requests`
- `POST /api/v2/agent/promo/purchase_requests`
- `POST /api/v2/agent/promo/purchase_requests/:id/cancel`
- `POST /api/v2/agent/promo/grant`
- `POST /api/v2/agent/promo/member_note`

Platform-admin APIs stay under `/adminapi/agent/promo/*` for approval, wallet credit, wallet status, and audits.

## Deployment Notes

The console is committed as build-free static files so it can be served directly from `backend_src/public/agent-admin`.

Before live use:

1. Run `deploy/agent_promo_wallet_20260616.sql` on the target database.
2. Run `deploy/agent_promo_purchase_20260616.sql` on the target database.
3. Publish `backend_src/public/agent-admin` with the backend public assets.
4. Apply the `/agent-admin/` Nginx route from `deploy/nginx/eccomall.conf`.
5. Log in with an approved `is_promoter = 1` user.

## Guardrails

- Agents can only see first-level members.
- Agents can only grant points to first-level members.
- Grants write `eb_user.integral`, `eb_user_bill`, and `eb_agent_promo_ledger`.
- Agents can request medal package marketing credits, but wallet credit happens only after platform-admin approval.
- The console has no platform-admin controls and no second-level commission surface.
