#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/opt/crmeb-prod}"
DOMAIN="${DOMAIN:-}"
EMAIL="${EMAIL:-}"
PUBLIC_IP="${PUBLIC_IP:-$(curl -s --max-time 8 ifconfig.me || true)}"
TARGET_CONF="${TARGET_CONF:-/etc/nginx/sites-available/default}"

if [[ -z "${DOMAIN}" || -z "${EMAIL}" ]]; then
  echo "用法: DOMAIN=example.com EMAIL=admin@example.com bash deploy/enable_https.sh"
  exit 1
fi

need_cmd() {
  command -v "$1" >/dev/null 2>&1
}

pkg_manager() {
  if need_cmd apt-get; then
    echo "apt"
    return
  fi
  if need_cmd dnf; then
    echo "dnf"
    return
  fi
  echo "unknown"
}

install_certbot() {
  if need_cmd certbot; then
    return 0
  fi
  case "$(pkg_manager)" in
    apt)
      apt-get update
      apt-get install -y certbot python3-certbot-nginx
      ;;
    dnf)
      dnf install -y certbot python3-certbot-nginx
      ;;
    *)
      echo "不支持的系统，无法自动安装 certbot"
      exit 1
      ;;
  esac
}

check_domain_dns() {
  local resolved
  if need_cmd dig; then
    resolved="$(dig +short "${DOMAIN}" A | tail -n1 || true)"
    if [[ -z "${resolved}" ]]; then
      resolved="$(dig +short "www.${DOMAIN}" A | tail -n1 || true)"
    fi
  else
    resolved="$(getent hosts "${DOMAIN}" | awk '{print $1}' | head -n1 || true)"
    if [[ -z "${resolved}" ]]; then
      resolved="$(getent hosts "www.${DOMAIN}" | awk '{print $1}' | head -n1 || true)"
    fi
  fi
  if [[ -z "${resolved}" ]]; then
    echo "未解析到 ${DOMAIN} 的 A 记录，请先配置 DNS。"
    exit 1
  fi
  if [[ -n "${PUBLIC_IP}" && "${resolved}" != "${PUBLIC_IP}" ]]; then
    echo "域名解析 IP (${resolved}) 与服务器公网 IP (${PUBLIC_IP}) 不一致。"
    echo "请先把 ${DOMAIN} 指向 ${PUBLIC_IP} 后重试。"
    exit 1
  fi
}

install_certbot
check_domain_dns

certbot certonly --nginx -d "${DOMAIN}" -d "www.${DOMAIN}" --agree-tos -m "${EMAIL}" --non-interactive --redirect || \
certbot certonly --nginx -d "${DOMAIN}" --agree-tos -m "${EMAIL}" --non-interactive --redirect

CRT="/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
KEY="/etc/letsencrypt/live/${DOMAIN}/privkey.pem"

cat > "${TARGET_CONF}" <<EOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name ${DOMAIN} www.${DOMAIN};
    return 301 https://\$host\$request_uri;
}

# 限流
limit_req_zone $binary_remote_addr zone=api_limit:10m rate=30r/s;
limit_req_zone $binary_remote_addr zone=login_limit:10m rate=5r/m;
limit_conn_zone $binary_remote_addr zone=conn_limit:10m;

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name ${DOMAIN} www.${DOMAIN};

    ssl_certificate ${CRT};
    ssl_certificate_key ${KEY};
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers on;
    ssl_session_tickets off;

    root ${PROJECT_DIR}/backend_src/public;
    index index.html;
    client_max_body_size 50m;
    limit_conn conn_limit 20;
    sendfile on;

    gzip on;
    gzip_comp_level 5;
    gzip_min_length 1024;
    gzip_vary on;
    gzip_types text/plain text/css application/javascript application/json application/xml image/svg+xml;

    add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Permissions-Policy "camera=(), microphone=(), geolocation=()" always;

    location ~ \\.php$ {
        return 404;
    }

    location ~ /\\.(?!well-known).* {
        deny all;
    }

    location ^~ /api/ {
        proxy_pass http://127.0.0.1:20199;
        proxy_http_version 1.1;
        proxy_read_timeout 360s;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    }

    location ^~ /adminapi/ {
        proxy_pass http://127.0.0.1:20199;
        proxy_http_version 1.1;
        proxy_read_timeout 360s;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    }

    location / {
        try_files \$uri \$uri/ @swoole;
    }

    location @swoole {
        proxy_pass http://127.0.0.1:20199;
        proxy_http_version 1.1;
        proxy_read_timeout 360s;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    }
}
EOF

nginx -t
systemctl reload nginx

if command -v systemctl >/dev/null 2>&1; then
  systemctl enable certbot.timer >/dev/null 2>&1 || true
  systemctl start certbot.timer >/dev/null 2>&1 || true
fi
certbot renew --dry-run || true

echo "HTTPS 已启用: https://${DOMAIN}"
