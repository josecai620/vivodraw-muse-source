#!/usr/bin/env bash
# 一键：调用根目录安全前台发布脚本（含自动备份/验活/失败回滚）
# 用法：bash server-code/deploy/构建并上传前台Expo.sh [server_ip] [ssh_user] [ssh_port]
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SAFE_SCRIPT="$(cd "${SCRIPT_DIR}/.." && pwd)/deploy-frontend.sh"
SERVER_IP="${1:-186.241.72.176}"
SSH_USER="${2:-root}"
SSH_PORT="${3:-49375}"

if [[ ! -x "${SAFE_SCRIPT}" ]]; then
  echo "❌ 未找到安全发布脚本: ${SAFE_SCRIPT}"
  exit 1
fi

echo "==> 调用安全发布脚本: ${SAFE_SCRIPT}"
bash "${SAFE_SCRIPT}" "${SERVER_IP}" "${SSH_USER}" "${SSH_PORT}"
