# -*- coding: utf-8 -*-
"""检查指定目录/文件里所有相对 require 的静态资源在 v4 是否存在。"""
import io, os, re

V4 = r'D:\eccomall\mobile-app'
SCAN_DIRS = ['components/pearl', 'components/pets', 'components/farm-demo', 'lib', 'hooks', 'store', 'app']
req = re.compile(r'require\(["\']([^"\']+)["\']\)')
bad = []
for d in SCAN_DIRS:
    base = os.path.join(V4, d.replace('/', os.sep))
    for root, _, files in os.walk(base):
        for fn in files:
            if not fn.endswith(('.ts', '.tsx')):
                continue
            fp = os.path.join(root, fn)
            relfile = os.path.relpath(fp, V4)
            s = io.open(fp, encoding='utf-8').read()
            for m in req.findall(s):
                if m.startswith('@/'):
                    target = os.path.join(V4, m[2:].replace('/', os.sep))
                    cand = [target + ext for ext in ('.ts', '.tsx', '.js', '.json')] + [os.path.join(target, 'index.tsx'), os.path.join(target, 'index.ts')]
                    ok = os.path.exists(target) or any(os.path.exists(c) for c in cand)
                elif m.startswith('.'):
                    target = os.path.normpath(os.path.join(os.path.dirname(fp), m))
                    ok = os.path.exists(target)
                else:
                    continue
                if not ok:
                    bad.append((relfile, m))
for f, m in bad:
    print('UNRESOLVED', f, '->', m)
print('total unresolved =', len(bad))
