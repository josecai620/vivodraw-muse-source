#!/usr/bin/env bash
# 仅把本机 uniapp 的 locale 双语 JSON 同步到服务器 public/static/locale/
# 前提：H5 已改为「运行时加载双语」，且至少发行并上传过一遍；之后改双语只需运行本脚本，无需再发行
# 用法: ./deploy/同步双语到服务器public.sh [服务器IP]
set -euo pipefail

SERVER_IP="${1:-186.241.72.176}"
SSH_USER="${SSH_USER:-root}"
REMOTE_DIR="/opt/crmeb-prod/backend_src/public"
LOCAL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOCALE_SRC="${LOCAL_ROOT}/backend_src/view/uniapp/locale"

echo "==> 同步双语 JSON 到 ${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/static/locale/"
ssh "${SSH_USER}@${SERVER_IP}" "mkdir -p ${REMOTE_DIR}/static/locale"
rsync -avz --progress \
  "${LOCALE_SRC}/" \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/static/locale/" \
  --include='*.json' --exclude='*'

echo "==> 完成"
echo "服务器 public/static/locale/ 已更新，刷新 H5 页面即可看到新双语（无需重新发行）。"
