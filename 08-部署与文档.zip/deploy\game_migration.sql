-- ============================================
-- 挖矿游戏 + 农场游戏 数据库迁移
-- ============================================

-- 1. 用户挖矿统计表
CREATE TABLE IF NOT EXISTS `eb_user_mining_stats` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `level` tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '矿工等级 1-5',
  `level_name` varchar(20) DEFAULT '普通矿工' COMMENT '等级名称',
  `today_count` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '今日挖矿次数',
  `daily_limit` int(10) unsigned NOT NULL DEFAULT 5 COMMENT '今日次数上限',
  `total_count` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '总挖矿次数',
  `total_consumed` decimal(12,2) NOT NULL DEFAULT 0.00 COMMENT '累计消费金额',
  `today_consumed` decimal(10,2) NOT NULL DEFAULT 0.00 COMMENT '今日消费金额',
  `consecutive_days` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '连续挖矿天数',
  `last_mining_date` date DEFAULT NULL COMMENT '上次挖矿日期',
  `best_ore` varchar(50) DEFAULT NULL COMMENT '挖到过的最好矿石',
  `total_points` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '累计获得积分',
  `vip_activated_at` datetime DEFAULT NULL COMMENT 'VIP激活时间',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `level` (`level`),
  KEY `total_count` (`total_count`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户挖矿统计';

-- 2. 挖矿记录表
CREATE TABLE IF NOT EXISTS `eb_user_mining_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `ore_type` varchar(20) NOT NULL COMMENT '矿石类型',
  `ore_name` varchar(50) NOT NULL COMMENT '矿石名称',
  `points` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '获得积分',
  `is_lucky` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否幸运镐',
  `depth` int(10) unsigned NOT NULL DEFAULT 1 COMMENT '深度',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='挖矿记录';

-- 3. 挖矿周排行榜表
CREATE TABLE IF NOT EXISTS `eb_mining_weekly_rank` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `week_start` date NOT NULL COMMENT '周开始日期',
  `total_points` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '本周获得积分',
  `diamond_count` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '本周钻石数',
  `mining_count` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '本周挖矿次数',
  `rank` int(10) unsigned DEFAULT NULL COMMENT '排名',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_week` (`user_id`, `week_start`),
  KEY `week_start_points` (`week_start`, `total_points`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='挖矿周排行榜';

-- 4. 用户农场表
CREATE TABLE IF NOT EXISTS `eb_user_farm` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `level` tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '农场等级 1-5',
  `level_name` varchar(20) DEFAULT '小农场' COMMENT '等级名称',
  `total_plots` int(10) unsigned NOT NULL DEFAULT 6 COMMENT '总地块数',
  `total_harvest` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '累计收获次数',
  `total_steal` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '累计偷菜次数',
  `total_stolen` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '累计被偷次数',
  `total_steal_value` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '累计偷取价值',
  `total_stolen_value` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '累计被偷价值',
  `has_dog` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否有看门狗',
  `dog_expire_at` datetime DEFAULT NULL COMMENT '看门狗过期时间',
  `daily_steal_count` int(10) unsigned NOT NULL DEFAULT 0 COMMENT '今日偷菜次数',
  `last_steal_date` date DEFAULT NULL COMMENT '最后偷菜日期',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户农场信息';

-- 5. 农场地块表
CREATE TABLE IF NOT EXISTS `eb_farm_plots` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `plot_index` int(10) unsigned NOT NULL COMMENT '地块编号 1-20',
  `crop_type` varchar(20) DEFAULT NULL COMMENT '作物类型',
  `crop_name` varchar(50) DEFAULT NULL COMMENT '作物名称',
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=空地 1=生长中 2=可收获 3=枯萎',
  `planted_at` datetime DEFAULT NULL,
  `mature_at` datetime DEFAULT NULL,
  `wither_at` datetime DEFAULT NULL,
  `harvest_value` int(10) unsigned DEFAULT NULL,
  `stolen_count` int(10) unsigned NOT NULL DEFAULT 0,
  `stolen_value` int(10) unsigned NOT NULL DEFAULT 0,
  `stealer_ids` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_plot` (`user_id`, `plot_index`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='农场地块';

-- 6. 农场操作记录表
CREATE TABLE IF NOT EXISTS `eb_farm_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `target_user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(20) NOT NULL,
  `crop_type` varchar(20) DEFAULT NULL,
  `crop_name` varchar(50) DEFAULT NULL,
  `plot_index` int(10) unsigned DEFAULT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `message` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='农场操作记录';

-- 7. 好友偷菜记录表
CREATE TABLE IF NOT EXISTS `eb_farm_steal_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `target_user_id` bigint(20) unsigned NOT NULL,
  `plot_index` int(10) unsigned NOT NULL,
  `steal_date` date NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `steal_unique` (`user_id`, `target_user_id`, `plot_index`, `steal_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='好友偷菜记录';

-- ============================================
-- 系统配置数据（挖矿 + 农场）
-- ============================================

DELETE FROM `eb_system_config` WHERE `menu_name` LIKE 'mining_%';
DELETE FROM `eb_system_config` WHERE `menu_name` LIKE 'farm_%';

INSERT INTO `eb_system_config` (`menu_name`, `value`, `info`, `desc`) VALUES
('mining_daily_free_count', '5', '每日免费挖矿次数', '挖矿游戏'),
('mining_vip_threshold', '100', '消费满金额成为VIP', '挖矿游戏'),
('mining_vip_bonus_count', '30', 'VIP当日额外挖矿次数', '挖矿游戏'),
('mining_prob_stone_min', '47', '石头概率最小值%', '挖矿游戏'),
('mining_prob_stone_max', '56', '石头概率最大值%', '挖矿游戏'),
('mining_prob_copper_min', '28', '铜矿概率最小值%', '挖矿游戏'),
('mining_prob_copper_max', '33', '铜矿概率最大值%', '挖矿游戏'),
('mining_prob_silver_min', '12', '银矿概率最小值%', '挖矿游戏'),
('mining_prob_silver_max', '18', '银矿概率最大值%', '挖矿游戏'),
('mining_prob_gold_min', '2', '金矿概率最小值%', '挖矿游戏'),
('mining_prob_gold_max', '6', '金矿概率最大值%', '挖矿游戏'),
('mining_prob_diamond_min', '0.5', '钻石概率最小值%', '挖矿游戏'),
('mining_prob_diamond_max', '2', '钻石概率最大值%', '挖矿游戏'),
('mining_points_stone', '1', '石头积分', '挖矿游戏'),
('mining_points_copper', '5', '铜矿积分', '挖矿游戏'),
('mining_points_silver', '20', '银矿积分', '挖矿游戏'),
('mining_points_gold', '100', '金矿积分', '挖矿游戏'),
('mining_points_diamond', '500', '钻石积分', '挖矿游戏'),
('mining_level_1_name', '普通矿工', '等级1名称', '挖矿游戏'),
('mining_level_1_limit', '5', '等级1每日次数', '挖矿游戏'),
('mining_level_1_threshold', '0', '等级1升级门槛', '挖矿游戏'),
('mining_level_2_name', '青铜矿工', '等级2名称', '挖矿游戏'),
('mining_level_2_limit', '10', '等级2每日次数', '挖矿游戏'),
('mining_level_2_threshold', '100', '等级2升级门槛', '挖矿游戏'),
('mining_level_2_bonus_copper', '2', '等级2铜矿加成%', '挖矿游戏'),
('mining_level_3_name', '白银矿工', '等级3名称', '挖矿游戏'),
('mining_level_3_limit', '20', '等级3每日次数', '挖矿游戏'),
('mining_level_3_threshold', '500', '等级3升级门槛', '挖矿游戏'),
('mining_level_3_bonus_silver', '3', '等级3银矿加成%', '挖矿游戏'),
('mining_level_4_name', '黄金矿工', '等级4名称', '挖矿游戏'),
('mining_level_4_limit', '30', '等级4每日次数', '挖矿游戏'),
('mining_level_4_threshold', '2000', '等级4升级门槛', '挖矿游戏'),
('mining_level_4_bonus_gold', '2', '等级4金矿加成%', '挖矿游戏'),
('mining_level_5_name', '钻石矿工', '等级5名称', '挖矿游戏'),
('mining_level_5_limit', '50', '等级5每日次数', '挖矿游戏'),
('mining_level_5_threshold', '10000', '等级5升级门槛', '挖矿游戏'),
('mining_level_5_bonus_diamond', '1', '等级5钻石加成%', '挖矿游戏'),
('mining_level_5_bonus_all', '3', '等级5全矿石加成%', '挖矿游戏'),
('farm_wheat_seed_price', '10', '小麦种子价格', '农场游戏'),
('farm_wheat_grow_time', '3600', '小麦生长时间秒', '农场游戏'),
('farm_wheat_harvest_value', '20', '小麦收获价值', '农场游戏'),
('farm_wheat_steal_percent', '40', '小麦被偷比例%', '农场游戏'),
('farm_corn_seed_price', '25', '玉米种子价格', '农场游戏'),
('farm_corn_grow_time', '14400', '玉米生长时间秒', '农场游戏'),
('farm_corn_harvest_value', '60', '玉米收获价值', '农场游戏'),
('farm_corn_steal_percent', '40', '玉米被偷比例%', '农场游戏'),
('farm_tomato_seed_price', '50', '番茄种子价格', '农场游戏'),
('farm_tomato_grow_time', '28800', '番茄生长时间秒', '农场游戏'),
('farm_tomato_harvest_value', '120', '番茄收获价值', '农场游戏'),
('farm_tomato_steal_percent', '35', '番茄被偷比例%', '农场游戏'),
('farm_strawberry_seed_price', '100', '草莓种子价格', '农场游戏'),
('farm_strawberry_grow_time', '43200', '草莓生长时间秒', '农场游戏'),
('farm_strawberry_harvest_value', '250', '草莓收获价值', '农场游戏'),
('farm_strawberry_steal_percent', '30', '草莓被偷比例%', '农场游戏'),
('farm_watermelon_seed_price', '200', '西瓜种子价格', '农场游戏'),
('farm_watermelon_grow_time', '86400', '西瓜生长时间秒', '农场游戏'),
('farm_watermelon_harvest_value', '500', '西瓜收获价值', '农场游戏'),
('farm_watermelon_steal_percent', '25', '西瓜被偷比例%', '农场游戏'),
('farm_ginseng_seed_price', '500', '人参种子价格', '农场游戏'),
('farm_ginseng_grow_time', '259200', '人参生长时间秒', '农场游戏'),
('farm_ginseng_harvest_value', '1500', '人参收获价值', '农场游戏'),
('farm_ginseng_steal_percent', '20', '人参被偷比例%', '农场游戏'),
('farm_dog_price', '100', '看门狗价格', '农场游戏'),
('farm_dog_duration', '86400', '看门狗有效期秒', '农场游戏'),
('farm_dog_success_rate', '50', '看门狗驱赶成功率%', '农场游戏'),
('farm_level_1_name', '小农场', '等级1名称', '农场游戏'),
('farm_level_1_plots', '6', '等级1地块数', '农场游戏'),
('farm_level_1_harvest', '0', '等级1所需收获次数', '农场游戏'),
('farm_level_2_name', '大农场', '等级2名称', '农场游戏'),
('farm_level_2_plots', '9', '等级2地块数', '农场游戏'),
('farm_level_2_harvest', '10', '等级2所需收获次数', '农场游戏'),
('farm_level_3_name', '农场主', '等级3名称', '农场游戏'),
('farm_level_3_plots', '12', '等级3地块数', '农场游戏'),
('farm_level_3_harvest', '50', '等级3所需收获次数', '农场游戏'),
('farm_level_4_name', '农场大亨', '等级4名称', '农场游戏'),
('farm_level_4_plots', '16', '等级4地块数', '农场游戏'),
('farm_level_4_harvest', '200', '等级4所需收获次数', '农场游戏'),
('farm_level_5_name', '农业帝国', '等级5名称', '农场游戏'),
('farm_level_5_plots', '20', '等级5地块数', '农场游戏'),
('farm_level_5_harvest', '500', '等级5所需收获次数', '农场游戏'),
('farm_daily_steal_limit', '50', '每日偷菜上限', '农场游戏'),
('farm_friend_steal_limit', '3', '每个好友每日偷菜上限', '农场游戏'),
('farm_plot_steal_limit', '2', '每块地被偷上限', '农场游戏'),
('farm_wither_hours', '48', '成熟后枯萎小时', '农场游戏');
