# Mystery Box Mall — Complete Figma Design Brief

> **发给 Figma Make AI 直接使用的完整设计文档**
> 一次性包含：品牌定位、Design Tokens、组件库、全部 26 个页面的逐页设计 Prompt、用户流程、动效规范。
> 可以整份丢给 Figma Make，也可以按页面拆开逐个喂。

---

## 📋 Project Overview

| Key | Value |
|-----|-------|
| **Product** | Mystery Box Mall (盲盒商城) — a gacha-style collectible marketplace |
| **Target Market** | Western / Global (English UI) |
| **Platform** | Mobile App (iOS + Android) + Mobile Web (H5) |
| **Base Viewport** | 375px width (iPhone SE standard) |
| **Theme** | Dark-first, neon accents, immersive gaming feel |
| **Style References** | HypeDrop (dark esports aesthetic, neon gradients, real-time unboxing) + Genshin Impact (cinematic gacha animations, particle VFX, pity/guarantee systems) |
| **Design Tone** | Bold, trendy, innovative — lean into gaming culture, loot box excitement, dopamine-driven UX |
| **Total Screens** | 26 pages + modals/sheets |

---

## 1. Design Tokens

### 1.1 Color Palette — Dark Theme

| Token | Hex | Usage |
|-------|-----|-------|
| `bg-primary` | `#0A0A0A` | Page backgrounds |
| `bg-card` | `#1A1A1A` | Card surfaces, list items |
| `bg-elevated` | `#242424` | Modals, sheets, overlays |
| `bg-input` | `#1F1F1F` | Input fields, search bars |
| `border-default` | `#333333` | Card borders, dividers |
| `border-subtle` | `#2A2A2A` | Subtle separators |
| `text-primary` | `#FFFFFF` | Headlines, primary text |
| `text-secondary` | `#9CA3AF` | Descriptions, meta info |
| `text-tertiary` | `#6B7280` | Placeholder, disabled text |
| `accent-gold` | `#FBBF24` | Primary CTA, highlights, points display |
| `accent-glow` | `#FBBF2440` | Glow effects (40% alpha) |
| `gradient-dark-start` | `#18181B` | Header/nav gradient start |
| `gradient-dark-end` | `#27272A` | Header/nav gradient end |
| `success` | `#22C55E` | Success states, completed items |
| `error` | `#EF4444` | Error states, destructive actions |
| `warning` | `#F59E0B` | Warning, countdown urgency |
| `purple-accent` | `#7C3AED` | Limited-time events, premium feel |
| `purple-glow` | `#A78BFA` | Purple gradient endpoint |

### 1.2 Rarity Tier Color System

Every item in the mystery box has a rarity tier. The color system is used across **badges, card borders, glow effects, particles, and backgrounds**.

| Tier | Label | Primary Color | Glow (20%) | Background (10%) | Particle Style |
|------|-------|--------------|------------|-------------------|----------------|
| 1 | Common | `#9CA3AF` | `#9CA3AF33` | `#9CA3AF1A` | Light gray sparks |
| 2 | Uncommon | `#3B82F6` | `#3B82F633` | `#3B82F61A` | Blue sparkles |
| 3 | Rare | `#A855F7` | `#A855F733` | `#A855F71A` | Purple aurora ring |
| 4 | Epic | `#F97316` | `#F9731633` | `#F973161A` | Orange flame burst |
| 5 | Legendary | `#EAB308` | `#EAB30833` | `#EAB3081A` | Gold rain + light beam |
| 6 | Secret | `#EC4899` | `#EC489933` | `#EC48991A` | Rainbow storm + chromatic aberration |

### 1.3 Typography

**Font**: `Inter` (primary), `SF Pro Display` (iOS fallback), system sans-serif.

| Level | Size | Weight | Line Height | Usage |
|-------|------|--------|-------------|-------|
| Hero | 32px | 900 Black | 40px | Hero numbers (pity counter, big stats) |
| H1 | 24px | 800 ExtraBold | 32px | Page titles |
| H2 | 20px | 700 Bold | 28px | Section titles |
| H3 | 18px | 700 Bold | 24px | Card titles, prices |
| Body | 14px | 400 Regular | 20px | Body text, descriptions |
| Body Bold | 14px | 700 Bold | 20px | Emphasized body, item names |
| Caption | 12px | 600 Semibold | 16px | Labels, timestamps, meta |
| Micro | 10px | 700 Bold | 14px | Badges, tags, pill text |

### 1.4 Spacing & Radius

**Spacing scale**: 4 / 8 / 12 / 16 / 20 / 24 / 32 / 48 px

| Element | Radius |
|---------|--------|
| Page-level hero cards | 24px |
| Standard cards | 16px |
| Buttons | 12px |
| Inputs | 12px |
| Tags / Badges | 8px |
| Pill shapes | 9999px (full pill) |
| Avatars | 50% (circle) |

### 1.5 Shadows & Glows

| Effect | CSS |
|--------|-----|
| Card hover | `0 8px 32px rgba(0,0,0,0.4)` |
| Neon glow (gold) | `0 0 20px #FBBF2440, 0 0 60px #FBBF2420` |
| Rarity glow | `0 0 24px {rarity-color}40` |
| Elevated surface | `0 4px 16px rgba(0,0,0,0.3)` |

---

## 2. Component Library

Design these as reusable Figma components with variants:

### 2.1 RarityBadge
- Height 22px, horizontal padding 8px
- Background: `{rarity-color}` at 20% opacity
- Text: `{rarity-color}` full, Micro weight 700
- Border: 1px solid `{rarity-color}` at 30%
- Create 6 variants (Common / Uncommon / Rare / Epic / Legendary / Secret)

### 2.2 ItemCard
- Min-width 45% (for 2-column grid)
- Background: `bg-card`, 1px `border-default`
- Top: image area (128px height, `bg-primary`, centered item image or emoji)
- Bottom: 12px padding. Name (Body Bold white), RarityBadge below, price (H3 accent-gold)
- **Press state**: scale 97%, subtle rarity glow
- **Skeleton state**: shimmer loading animation

### 2.3 ActionButton
- Full-width, 56px height, 12px radius
- **Primary**: `accent-gold` bg, black text, weight 700
- **Secondary**: `bg-card` bg, 1px `border-default`, white text
- **Ghost**: transparent bg, `accent-gold` text
- **Disabled**: `#333333` bg, `text-tertiary` text
- **Loading**: spinner + "Processing..."
- Press: scale(0.95) spring

### 2.4 ProgressBar
- 3 sizes: 4px (compact), 8px (standard), 12px (prominent)
- Track: `bg-elevated`, pill shape
- Fill: gradient `{color}` to `{color}CC`, pill shape
- Mount animation: slide in 600ms ease-out
- Glow variant: `box-shadow: 0 0 8px {color}40`

### 2.5 CountdownTimer
- Layout: `DD : HH : MM : SS` horizontal segments
- Each segment: `bg-elevated`, rounded-lg, monospace, H3 size
- Separator: `:` in `text-secondary`
- **Urgency mode** (< 1 hour): color shifts to `error`, pulse animation
- Label below: Caption (e.g. "Ends in" / "Expires in")

### 2.6 MarqueeBanner
- Full-width strip, 40px height
- Background: `accent-gold` at 10%
- Content: infinite horizontal scroll of pills: "👤 Username won [ItemName] {RarityBadge}"
- Speed: 30s per loop, smooth linear

### 2.7 QuickActionButton
- 44px circle icon area + label below
- Icon area: `accent-gold` at 10% bg, 1px `accent-gold` at 20% border
- Icon: 18px, `accent-gold` color
- Label: Micro, `text-secondary`
- Press: scale 90%, bg brightens

### 2.8 TabBar
- Horizontal scrollable filter tabs
- Active: gradient bg, white text
- Inactive: `bg-primary`, 1px border, `text-primary`
- Animated indicator slides between tabs

### 2.9 EmptyState
- Centered: 48px icon (`text-secondary`) + title (Body Bold) + description (Caption) + optional CTA
- 16px gap between elements

### 2.10 FriendCard
- Horizontal layout: avatar (48px circle) + name/stats + action button
- Stats row: icon + "X opens" + rarity badge of best pull
- Action button: pill shape, accent color

### 2.11 ActivityBanner
- Full-width rounded card with purple gradient (`#4C1D95` → `#7C3AED`)
- "Limited" red badge top-left
- Title (H3 white) + description (Caption white 80%) + countdown + CTA
- Press: navigate to activity detail

### 2.12 GiftRewardCard
- Golden gradient background (`#B45309` → `#F59E0B`)
- Large icon (gift/party) + title + description + claim button
- Used for newbie gifts and event rewards

---

## 3. Information Architecture

### 3.1 Complete Page Map (26 Pages)

```
/box (Mystery Box Mall)
├── index ..................... 🏠 Hall / Lobby (main hub)
├── [id] ..................... 📦 Box Detail
│   └── [id]/opening ........ 🎰 Opening Animation + Result
├── backpack ................. 🎒 My Backpack (inventory)
├── recycle .................. ♻️ Recycle Items for Points
├── shipping ................. 🚚 Request Shipping
├── orders ................... 📋 Order List
├── order-detail ............. 📄 Order Detail
├── history .................. 📜 Opening History
├── draws .................... 🎫 Draw Records
├── brands ................... 🏷️ Brand List
├── brand/[id] ............... 🏷️ Brand Detail
├── collection ............... 📖 Collection Album
├── checkin .................. ✅ Daily Check-in & Tasks
├── leaderboard .............. 🏆 Rankings
├── exchange ................. 🔄 Trading Market
├── synthesis ................ ⚡ Item Fusion
├── wishlist ................. 💫 Wish Pool
├── pity ..................... 🛡️ Pity System / Guarantee
├── probability .............. 📊 Odds Disclosure
├── activity ................. 🔥 Limited-Time Events
├── replay ................... ▶️ Opening Replay
├── friends .................. 👥 Friends & Social
└── newbie ................... 🎁 Newbie Gift Pack
```

### 3.2 Navigation Flow

```
Main Mall Homepage
    └── [Box icon in header bar] → Mystery Box Hall (hub)
        ├── Quick Actions bar (17 entries) → any sub-page
        ├── Activity Banner → Activity page
        ├── Newbie Banner → Newbie Gift page
        ├── Hot Box card → Box Detail
        ├── Series grid → Box Detail
        └── Box Detail → Opening Animation → Result
                                              ├── Share
                                              ├── Backpack → Recycle / Ship
                                              └── Open Another → Box Detail
```

---

## 4. Page-by-Page Design Prompts

> **How to use**: Copy each prompt below and paste it into Figma Make. Each prompt is self-contained with layout, colors, and component specs. Design each as a **375px wide** mobile screen in **dark theme**.

---

### PAGE 1: Hall / Lobby — `index`

```
Design a dark-themed mystery box mall lobby (375px wide, mobile). This is the main hub page.

BACKGROUND: solid #0A0A0A

HEADER (sticky top):
- Linear gradient from #18181B to #27272A
- Left: white back arrow icon
- Center: "Mystery Box" in 24px ExtraBold white, below: sparkle icon + "12,500 pts" in 12px semibold gold (#FBBF24)
- Right: palette icon (theme toggle)

QUICK ACCESS BAR (horizontal scroll, below header):
- Background #1A1A1A, bottom border #333
- 17 circular icon buttons (44px each) in a row, scrollable:
  Backpack | Check-in | Orders | Draws | Rankings | Trade | Fusion | Wishlist | Pity | Odds | Brands | Album | Shipping | Events | Replay | Friends | Gift
- Each: circle (#FBBF24 at 10% bg, 1px gold 20% border), 18px icon in gold, 10px bold gray label below
- Scroll indicator: subtle fade at right edge

MARQUEE STRIP (below quick access):
- Full width, 40px, #FBBF24 at 10% bg
- Infinite scrolling pills: "👤 Alex won AirPods Pro" + Epic rarity badge (orange)
- Smooth linear animation

ACTIVITY BANNER (conditional, if event active):
- Full-width rounded-xl card, gradient #4C1D95 → #7C3AED
- Left: clock icon in gold. Center: event title (14px Bold white) + description (11px white 70%). Right: red "GO" pill badge
- Tap → /activity page

NEWBIE GIFT BANNER (conditional, for new users):
- Full-width rounded-xl card, gradient #B45309 → #F59E0B
- Party icon + "Welcome Gift" + "100 pts + 1 free box" + "Claim" button
- Tap → /newbie page

NOTIFICATION BANNER (conditional):
- Rounded-xl, #FBBF24 at 10% bg, 1px gold 20% border
- Star icon + announcement text in gold

HOT BOX CARD (hero):
- Large rounded-3xl card, #FBBF24 at 30% bg, 1px gold 50% border
- Top-left: red-orange gradient pill "🔥 HOT PICK"
- Left: box image 80px. Right: box name H1, description Body, progress bar (gold fill), price Hero gold + "pts"
- "Open Now" gold button with lightning icon
- Bottom: thin rarity distribution bar (6 colored segments proportional to odds)
- Subtle breathing glow animation on border

ALL SERIES GRID:
- Section header: "All Series" H2 left + "View All >" gold link right
- 2-column grid of cards:
  - Each: rounded-2xl, #1A1A1A bg, 1px #333 border
  - Top: image area (128px, centered emoji/image on #0A0A0A)
  - Bottom: name (14px Bold), description (12px gray), rarity bar, price (18px gold), arrow icon
  - "Opened 1,234 times" micro text

NEW USER GUIDE MODAL (overlay, first visit):
- Dark overlay 70%
- Centered card max 360px, rounded-3xl
- 5-step walkthrough with emoji + title + description per step
- Dot indicators at bottom
- Final step: "Start Exploring" gold CTA
```

---

### PAGE 2: Box Detail — `[id]`

```
Design a dark mystery box detail screen (375px wide).

HEADER: gradient #18181B→#27272A, back arrow, "Box Detail" center, theme toggle right

BOX INFO CARD (hero, full-width):
- Rounded-2xl, gradient bg
- Centered: box image (96px, rounded container, 20% white bg, rarity glow shadow)
- Box name H1 white, description Body white 90%
- Rarity distribution bar (6 colored segments, 8px, rounded-full)
- Stats row: "Opened 5,432" left, "Max ¥2,999" right

OPEN OPTIONS CARD:
- bg-card rounded-2xl, 1px border, 20px padding
- "Open Options" H3 title
- 4 buttons row: "1x" / "3x" / "5x" / "10x"
  - Selected: gradient bg, white text
  - Unselected: bg-primary, 1px border
- Cost display: bg-primary rounded-xl, "Total: 500 pts" H1 gold
- Payment row: "Points (12,500)" and "Balance ($45.00)" cards side by side
  - Selected: gradient bg. Unselected: bg-primary + border

POSSIBLE ITEMS LIST:
- Section header: Package icon + "Possible Items" H2
- Card (bg-card, rounded-2xl, 1px border):
  - Each item: 48px image + name (Body Bold) + RarityBadge + probability % right
  - 1px dividers between items

RECENT OPENINGS:
- Same card style. Each row: 32px avatar circle + "Username opened" + rarity pill + time

STICKY BOTTOM BAR:
- Fixed, bg-card, top border #333, safe-area bottom padding
- Left: "1x Open" Caption + "500 pts" H2 gold
- Right: "Open Now ⚡" gold button 48px height
- Disabled: gray when insufficient funds
```

---

### PAGE 3: Opening Animation — `[id]/opening`

```
Design a full-screen dark opening animation result screen (375px).

Show the RESULT STATE (Stage 4 — after animation completes):

BACKGROUND: #0A0A0A with subtle dark gradient

CENTER — RESULT CARD:
- Card: bg-card rounded-3xl, 1px border, padding 32px, centered
- Item circle: 120px diameter, 4px rarity-colored border, rarity glow shadow
- Item image inside (56px)
- Item name: H1 white bold, centered
- Rarity badge: large pill, rarity-colored, H3 text

ACTION BUTTONS (below card, full width, 12px gap):
1. "Share Result" — rarity-colored 2px border, rarity-colored text, Share2 icon (most prominent)
2. "Go to Backpack" — gold bg, white text, ShoppingBag icon
3. "Open Another" — bg-card, 2px border, white text, Package icon
- All: 52px height, rounded-xl

PARTICLE FX ANNOTATIONS (for developer reference):
- Common: none
- Uncommon: blue sparkle dots floating up
- Rare: purple aurora ring expanding
- Epic: orange flame particles bursting from center
- Legendary: gold rain + top light beam + screen flash
- Secret: rainbow particle storm + chromatic aberration
```

---

### PAGE 4: Backpack — `backpack`

```
Design a dark inventory screen (375px).

HEADER: gradient, "My Backpack"

TAB BAR (horizontal scroll, 4 tabs):
- All | Pending | Shipped | Recyclable
- Each: pill shape, icon + label + count badge (circle, 18px)
- Active: gradient bg, white text. Inactive: bg-primary, border, text-primary

ITEM LIST (vertical scroll):
- Each: rounded-2xl, bg-card, 1px border
- Left: 64px image square. Right: name (H3), RarityBadge, source ("BoxName · 50 pts recycle"), status badge
- Status badges: Shipped (green), Pending (amber), Recyclable (gray)
- Quantity badge: if count > 1, show "×3" pill top-right of image
- Action buttons: "Ship" (outline) and "Recycle" (gold) — contextual
- 12px gap between cards

EMPTY STATE: package icon + "Your backpack is empty" + "Go open some boxes" CTA
```

---

### PAGE 5: Daily Check-in — `checkin`

```
Design a dark check-in & quests screen (375px).

HEADER: gradient, "Check-in & Quests"

STREAK BANNER:
- Rounded-3xl, gold gradient (30%→10%)
- Left: "Streak" label + Hero number (e.g. "7") + "days"
- Right: "Total" label + H2 number + "days"

7-DAY CALENDAR ROW:
- 7 circles (42px each):
  - Past: gold bg, white ✓ icon
  - Today (unchecked): gold 2px border, transparent bg, pulsing glow
  - Today (checked): gold bg, ✓
  - Future: gray bg 60%, gray text "+15" (reward preview)
  - Day 7: gift icon (special reward)
- "Day 1" through "Day 7" labels below each in Micro

CHECK-IN BUTTON:
- Full-width, 48px, rounded-xl
- Unchecked: gold bg, "Check in — Earn 20 pts" white text + Calendar icon
- Checked: gray bg, "Checked in ✓" gray text
- Success animation: confetti burst

DAILY QUESTS SECTION:
- Header: target icon + "Daily Quests" H2 + "3/5 done · 35/85 pts" Caption
- Overall progress bar: gold fill, 8px
- 5 quest cards:
  - Each: rounded-2xl, bg-card, 1px border
  - Left: 40px themed icon square. Middle: title + description + mini progress bar. Right: "+5 pts" gold + status
  - Completed: 70% opacity, gold tinted border
```

---

### PAGE 6: Leaderboard — `leaderboard`

```
Design a dark rankings screen (375px).

HEADER: gradient, "Leaderboard"

TAB BAR (3 equal-width tabs): "🔥 Lucky" | "🏆 Active" | "👑 Rare"
- Active: gradient bg. Inactive: bg-primary + border

TOP 3 (special styling):
- #1 Gold: #FFD700 at 10% bg, gold medal icon, gold border
- #2 Silver: #C0C0C0 at 10% bg, silver medal
- #3 Bronze: #CD7F32 at 10% bg, bronze medal

RANK LIST:
- Each row: rounded-2xl, bg-card, padding 16px
- Rank icon/number + 36px avatar circle + username (Body Bold) + secondary info (RarityBadge + best item) + stat number (gold)
- 8px gap between rows
```

---

### PAGE 7: Trading Market — `exchange`

```
Design a dark trading marketplace (375px).

HEADER: gradient, "Trading Market", "+" button right (create listing)

SEARCH & FILTER:
- Search bar: bg-primary, 1px border, rounded-xl, 40px, search icon + "Search items..."
- Filter pills (horizontal scroll): All + 5 rarity filters
  - Active: rarity-colored bg 30% + rarity border
  - Inactive: bg-primary + border

LISTING COUNT: "42 listings" Caption

TRADE CARDS:
- Each: rounded-2xl, bg-card, 1px border
- Top: avatar + username + date
- Middle 3-col: [Offering item card with rarity border] → [🔄 Trade icon in gold] → [Wanted item card with dashed border + "❓"]
- Bottom: "Request Trade" gold-tinted button
- 12px gap between cards

CREATE LISTING PANEL (expandable):
- Accent 2px border card
- "Post a Trade" H3
- Horizontal scroll of user's items (selectable)
- Text input for want description
- Cancel + Post buttons

EMPTY: Repeat icon + "No listings yet" + CTA
```

---

### PAGE 8: Item Fusion — `synthesis`

```
Design a dark item fusion screen (375px).

HEADER: gradient, "Item Fusion"

RECIPE SELECTOR (horizontal scroll):
- Cards: "3× Common → Uncommon" with colored circles
- Active: target rarity bg 20%, 2px target-color border
- Shows success rate %

FUSION DISPLAY (hero):
- Large rounded-3xl card, target rarity gradient bg
- Center: "×3" from-color square + sparkle icon + "×1" to-color square
- Labels: from-rarity left, to-rarity right
- Stats: "60% Success" + "2/3 Selected" Hero numbers

MATERIAL SELECTION:
- "Select Materials" H2
- Grid (4 per row, square):
  - Selected: rarity border + green ✓ overlay
  - Each: emoji 24px + name Micro
- Empty: "No items" + CTA

RESULT (after fusion):
- Success: target-color card, "✨" + "Fusion Successful!" H1
- Failure: gray card, "💨" + "Fusion Failed" H1

WARNING: "⚠ Failed fusions consume materials" Caption
STICKY BOTTOM: "Fuse (2/3)" ActionButton
```

---

### PAGE 9: Wish Pool — `wishlist`

```
Design a dark wishlist screen (375px).

HEADER: gradient, "Wish Pool"

STATS BANNER: gold gradient card, Star icon + "My Wishes" H2, Hero wish count, rarity mini-pills

ADD WISH: dashed border card, Heart icon + "Add a Wish" gold text → expands selection panel

SELECTION PANEL: list of box series, each with emoji + name + price + "Wish" gold pill button

WISH LIST:
- Each card: rounded-2xl, bg-card, 1px rarity-colored border 30%
- 48px rarity-bg square + name (Body Bold) + rarity badge + "From BoxName" Caption
- Bell icon (gold=on, gray=off) + trash icon (red)

EMPTY: Star icon + "Your wish pool is empty"
```

---

### PAGE 10: Pity System — `pity`

```
Design a dark pity/guarantee screen (375px).

HEADER: gradient, "Pity System"

HERO CARD: rounded-3xl, gold gradient bg
- Shield icon + "My Pity Progress" H2
- Center: HUGE Hero number (gold) = consecutive pulls without rare
- Label: "consecutive non-rare pulls" Caption

4 PROGRESS TIERS:
- Each: colored dot + tier name (Body Bold) + "7 more" / "Triggered!" right
- Progress bar (8px) with tier-color fill
- Thresholds: Rare=10, Epic=30, Legendary=60, Secret=90

RULES: "How it Works" H2 + 4 cards:
1. TrendingUp (blue) — "Cumulative Guarantee"
2. Zap (orange) — "Trigger Points: 10/30/60/90"
3. Gift (green) — "Reset on Hit"
4. Shield (purple) — "Cross-Box Tracking"

FAQ: accordion Q&A pairs
```

---

### PAGE 11: Odds Disclosure — `probability`

```
Design a dark probability disclosure screen (375px).

COMPLIANCE NOTICE: gold-tinted card, ShieldCheck icon, legal statement

GLOBAL RATES TABLE: "Base Odds" H2, bg-card:
- Common 45% | Uncommon 30% | Rare 15% | Epic 7% | Legendary 2.5% | Secret 0.5%
- Each row: rarity dot + name + description + percentage (H2, rarity-colored)

VISUAL BAR: 32px horizontal bar with colored segments proportional to rates + legend below

PER-SERIES RATES: collapsible cards per box series with rarity bars

LEGAL FOOTER: gray card, Info icon, 4 numbered legal notes
```

---

### PAGE 12: Limited-Time Events — `activity` ⭐ NEW

```
Design a dark limited-time events screen (375px).

HEADER: #0F172A bg, back arrow left, "Limited Events" center white 18px Bold

EVENT CARDS (vertical scroll, if multiple events):
- Each card: rounded-2xl, gradient fill #4C1D95 → #7C3AED → #A78BFA (diagonal)
- Top-left: "🔥 LIMITED" red pill badge (rgba(239,68,68,0.8) bg, white text)
- Title: 22px ExtraBold white
- Description: 14px white 80%, line-height 20px
- BOOST ROW: dark overlay rounded box (rgba(0,0,0,0.2)), Zap icon gold + "Rarity Odds ×2" gold Bold 14px
- COUNTDOWN ROW: "Ends in" label + 3 time blocks (HH:MM:SS), each block: rgba(0,0,0,0.3) rounded-md, white Bold 16px monospace, colon separators
- LINKED BOX (if applicable): bottom section with box image (36px rounded), box name white 14px Bold, chevron right

EMPTY STATE (no active events):
- Centered: Clock icon 48px gray + "No Active Events" 16px Semibold gray + "Stay tuned" 13px gray

Overall mood: urgent, exciting, premium purple-gold palette
```

---

### PAGE 13: Opening Replay — `replay` ⭐ NEW

```
Design a dark opening replay list screen (375px).

HEADER: #0F172A bg, back arrow, "Replay" center 18px Bold white

REPLAY LIST (FlatList, vertical scroll):
- Each item: rounded-xl card, bg #1E293B, 1px rarity-colored border
- Left: 60px rounded-xl image area (rarity-tier bg color), item image 48px centered
- Middle: item name (15px Bold white, 1 line), rarity badge pill + date (12px gray) row, box series name (12px gray)
- Right: 40px circle play button (rgba(167,139,250,0.15) bg, purple filled play triangle icon)
- 10px gap between cards

Tapping play → navigates to opening animation page with saved result data (replays the 4-stage animation)

EMPTY STATE: Play icon 48px gray + "No openings yet" + "Go open a box" subtext

Pagination: infinite scroll, load more indicator at bottom
```

---

### PAGE 14: Friends & Social — `friends` ⭐ NEW

```
Design a dark friends & social screen (375px).

HEADER: #0F172A bg, back arrow, "Box Friends" center 18px Bold white

FRIEND CARDS (vertical scroll):
- Each: rounded-2xl, bg #1E293B, 16px padding
- TOP ROW: 48px avatar circle + name (16px Bold white) + stats row below (Box icon + "123 opens" gray, Star icon + rarity badge of best pull)
- RIGHT: "Gift" button (pill shape, rgba(167,139,250,0.15) bg, purple text, Gift icon)
- BOTTOM (if friend has rare items): divider line #334155, "Recent Rare" label 12px gray, horizontal row of rare item thumbnails (32px each in rarity-colored rounded boxes, name below in 11px)

GIFT MODAL (bottom sheet):
- Dark overlay 70%
- Bottom sheet: #1E293B bg, 20px radius top
- "Select Gift Item" title 18px Bold + X close button
- "Sending to: FriendName" 13px gray
- Vertical list of user's backpack items (selectable):
  - Each: rounded-xl, #0F172A bg, 12px padding
  - 40px item image + name (14px Semibold) + Send icon purple right
- Tap item → confirmation alert → gift sent

EMPTY STATE: Users icon 48px gray + "No friends yet" + "Invite friends to play" subtext
```

---

### PAGE 15: Newbie Gift Pack — `newbie` ⭐ NEW

```
Design a dark newbie welcome gift screen (375px).

HEADER: #0F172A bg, back arrow, "Welcome Gift" center 18px Bold white

HERO CARD:
- Rounded-2xl, gradient #7C3AED → #A78BFA → #C4B5FD (diagonal)
- Center: 80px circle (rgba(255,255,255,0.15) bg), Gift icon 48px white inside
- Title: "Welcome to Mystery Box!" 22px ExtraBold white
- Subtitle: "Claim within 7 days of registration" 14px white 80%
- Timer row: Clock icon + "X days remaining" 13px Semibold white 80%

REWARDS SECTION: "Gift Contents" 17px Bold white
- Reward card 1: rounded-xl, bg #1E293B, 16px padding
  - Left: 48px rounded-xl gold-tinted icon area, Coins icon 24px gold
  - Middle: "100 Points" 16px Bold white + "Use for boxes or exchanges" 13px gray
  - (If claimed: green checkmark right)
- Reward card 2: same layout
  - Purple-tinted icon area, Box icon 24px purple
  - "1 Free Opening" + "Experience the thrill"

CLAIM BUTTON (if eligible, not yet claimed):
- Full-width, rounded-xl, gradient #7C3AED → #A78BFA
- Party icon + "Claim Now" 17px ExtraBold white
- Disabled/loading state: 60% opacity + spinner

EXPIRED STATE (if > 7 days since registration):
- Gray card: Clock icon + "Gift expired (registered over 7 days ago)" 14px gray

CLAIMED STATE:
- Hero card changes to gray gradient #334155 → #1E293B
- CheckCircle icon green 48px
- "Gift Claimed" title
- Reward cards show green checkmarks
```

---

### PAGE 16: Orders — `orders`

```
Dark order list (375px). FlatList infinite scroll.
Header gradient "My Orders".
Each card: bg-card rounded-2xl, order ID + date header row,
item preview thumbnails, status badge (Pending=amber countdown, Paid=green, Shipped=blue, Completed=gray),
total in gold. Tap → order detail.
Empty: FileText icon + "No orders yet"
```

---

### PAGE 17: Order Detail — `order-detail`

```
Dark order detail (375px). Header "Order Detail".
Order info card: ID, created time, status colored badge.
Item list with images + rarity badges.
Payment info: method, amount, discount breakdown.
Pending: countdown + "Pay Now" gold CTA.
Shipped: tracking number, address section.
```

---

### PAGE 18: Shipping — `shipping`

```
Dark shipping request (375px). Header "Request Shipping".
Address selector dropdown (saved addresses, default selected) + "Manage Addresses" gold link.
Item selection: checkboxes for eligible items from backpack.
Summary: count + estimated fee.
"Submit Request" gold CTA sticky bottom.
```

---

### PAGE 19: Recycle — `recycle`

```
Dark recycle screen (375px). Header "Recycle".
Rate display card: "Current rate: 80%" gold.
Item grid with multi-select (rarity borders when selected).
Bottom bar: "X items · Y pts return" + "Confirm Recycle" gold button.
Warning: "Recycled items cannot be recovered."
```

---

### PAGE 20: Opening History — `history`

```
Dark history screen (375px). FlatList infinite scroll. Header "Opening History".
Stats card top: total opens, total spent, best rarity badge.
Timeline list: each entry with box name, item won (rarity badge), timestamp.
Tap → replay animation.
```

---

### PAGE 21: Draw Records — `draws`

```
Dark draw records (375px). FlatList infinite scroll. Header "Draw Records".
Each record: draw ID, box name, status badge (pending/revealed/claimed), result preview + rarity badge, timestamp.
```

---

### PAGE 22: Brand List — `brands`

```
Dark brand series list (375px). Header "Brand Series".
Grid/list of brand cards: logo/image, name H3, box count ("12 boxes"), description.
Tap → brand detail.
```

---

### PAGE 23: Brand Detail — `brand/[id]`

```
Dark brand detail (375px). Header with brand name.
Hero: large image, description, stats (total boxes, total items).
Box grid below: same card style as Hall grid.
```

---

### PAGE 24: Collection Album — `collection`

```
Dark collection screen (375px). Header "Collection".
Series cards: name + box image + "5/8 collected" progress bar.
Item grid (4 per row, square): unlocked → image + name + rarity, locked → 🔒 + "???"
Complete reward: "Claim 100 pts" gold CTA when 100%.
```

---

### PAGE 25: Recycle — `recycle`

(See PAGE 19 above — same screen)

---

### PAGE 26: History — `history`

(See PAGE 20 above — same screen)

---

## 5. User Flows

### 5.1 Core: Open a Box

```
Hall → Browse Grid → Tap Box → Box Detail → Choose 1x/3x/5x/10x → Choose Payment (Points/Balance)
→ Tap "Open Now" → [API: create order] → [API: add box] → Opening Animation (shake → crack → reveal → result)
→ Share Result / Go to Backpack / Open Another
```

### 5.2 Daily Engagement Loop

```
Enter Hall → First Visit? → Yes: 5-step Guide Modal → Claim Welcome Bonus
                          → No: Check Activity Banner → Check Newbie Banner → Daily Check-in
→ Earn streak points → View Daily Quests → Complete quests → Earn bonus rewards → Open boxes
```

### 5.3 Item Lifecycle

```
Open Box → Item in Backpack
  → Ship → Pay freight → Delivered (real item)
  → Recycle → Points returned to balance
  → Fuse → Success: higher rarity item / Fail: materials consumed
  → Trade → List on market → Someone requests → Items exchanged
  → Gift → Select friend → Confirm → Item transferred
```

### 5.4 Social Loop

```
Hall → Friends page → View friend stats & rare pulls
  → Gift item to friend (select from backpack)
  → View friend's opening replays
Hall → Leaderboard → See rankings → Compete
```

### 5.5 New User Journey

```
First visit → Guide Modal (5 steps) → Newbie Gift Banner appears
→ Claim Gift (100 pts + 1 free box) → Use points to open first box
→ Opening animation → Get first item → Explore backpack
→ Daily check-in habit formed
```

---

## 6. Motion & VFX Spec

> These annotations are for the **development team** to implement. Figma should show **static keyframes** and annotate the intended animation behavior.

### 6.1 Opening Animation — Rarity-Scaled VFX

| Stage | Duration | Common | Uncommon | Rare | Epic | Legendary | Secret |
|-------|----------|--------|----------|------|------|-----------|--------|
| Shake | 1.2s | Gentle sway | Moderate shake | Strong shake | Violent shake | Intense + screen tremor | Chaotic + chromatic aberration |
| Crack | 0.5s | Simple split | Blue cracks | Purple lightning | Orange fire cracks | Gold shatter | Rainbow explosion |
| Reveal | 0.7s | Fade in | Blue sparkles | Purple aurora | Orange flames | Gold rain + beam | Rainbow storm |
| Result | Hold | Plain card | Blue glow | Purple pulse | Orange fire border | Gold rain continues | Rainbow cycling border |
| Haptic | — | None | Light | Medium | Strong | Heavy repeat | Continuous pattern |
| Sound | — | Click | Chime | Sparkle | Explosion | Fanfare | Epic orchestral |

### 6.2 Micro-interactions

| Element | Trigger | Animation |
|---------|---------|-----------|
| ActionButton | Press | scale(0.95) spring + ripple from touch point |
| ItemCard | Press | scale(0.97) + subtle rarity glow |
| QuickAction | Press | scale(0.9) + bg opacity bump |
| TabBar | Switch | indicator spring slide, content crossfade |
| ProgressBar | Mount | fill slides 0→target, 600ms ease-out |
| MarqueeBanner | Always | translateX loop 30s linear |
| Check-in success | Tap | confetti burst (40 particles, gold+white, 1.5s) |
| Fusion success | Complete | light beam bottom→up (1s) + item bounce-in |
| Fusion fail | Complete | item shatters outward (0.8s) + fade to dust |
| Countdown digit | Each sec | flip animation (rotateX) |
| Hot box card | Idle | breathing glow on border (2s pulse) |
| Activity banner | Idle | subtle shimmer sweep left→right |
| Newbie banner | Appear | slide-down + fade-in |

### 6.3 Ambient / Environmental Effects

- **Hall bg**: slowly drifting golden light particles (10-15 count, 0.3 opacity)
- **Box detail hero**: rarity glow pulse behind box image
- **Leaderboard top 3**: shimmer on medal icons
- **Pity near threshold**: progress bar glows faster as count approaches
- **Activity countdown < 1h**: pulse red urgency effect

### 6.4 Implementation Stack (for dev reference)

| Tech | Purpose |
|------|---------|
| `react-native-reanimated` | 60fps native animations |
| `Rive` (.riv files, @rive-app/canvas) | Complex interactive animations (opening VFX, particle systems) |
| `Lottie` | After Effects exported micro-animations |
| `expo-haptics` | Device vibration feedback on App |
| Canvas / WebGL | H5 particle systems |

---

## 7. Responsive & Platform Notes

- **Base viewport**: 375px (iPhone SE)
- **Max content width**: 420px (center content on larger screens/tablets)
- **Grid**: 2 columns for item grids, 1 column for list views
- **Bottom safe area**: 32px padding (home indicator)
- **Top safe area**: 48px (status bar, handled by SafeAreaView)
- **Platform**: React Native (App) + React Native Web (H5/browser). Both use same component code.

---

## 8. Accessibility

- All touch targets: minimum 44px
- Color contrast: all text meets WCAG AA on dark backgrounds
- Rarity info: conveyed by BOTH color AND text label
- Loading: skeleton shimmer + "Loading..." text
- Errors: clear message + retry action
- Icons: all have aria-labels / accessibilityLabel

---

## 9. Figma File Structure Suggestion

```
📁 Mystery Box Mall
├── 📄 Cover Page (project info, links)
├── 📁 Design Tokens
│   ├── Colors (light + dark palettes)
│   ├── Typography scale
│   ├── Spacing & radius
│   └── Rarity color system (6 tiers)
├── 📁 Components
│   ├── RarityBadge (6 variants)
│   ├── ItemCard (default, pressed, skeleton)
│   ├── ActionButton (primary, secondary, ghost, disabled, loading)
│   ├── ProgressBar (3 sizes × N colors)
│   ├── CountdownTimer (normal, urgent)
│   ├── MarqueeBanner
│   ├── QuickActionButton
│   ├── TabBar
│   ├── EmptyState
│   ├── FriendCard
│   ├── ActivityBanner
│   └── GiftRewardCard
├── 📁 Pages (26 screens)
│   ├── 01-Hall
│   ├── 02-BoxDetail
│   ├── 03-OpeningAnimation
│   ├── ... (one frame per page)
│   └── 26-Collection
├── 📁 User Flows (Figma FigJam or Prototype)
│   ├── Core: Open a Box
│   ├── Daily Engagement
│   ├── Item Lifecycle
│   ├── Social Loop
│   └── New User Journey
└── 📁 Motion Annotations
    ├── Opening Animation Keyframes
    ├── Micro-interaction specs
    └── Ambient effects reference
```

---

*End of design brief. Feed the entire document or individual page prompts to Figma Make AI for generation.*
