-- 积分分类同步映射表（store_integral_category -> store_category）
-- 目的：让积分商城类目变成后台真实类目，并可持续同步图标/状态

CREATE TABLE IF NOT EXISTS `eb_integral_category_sync_map` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `integral_cate_id` INT(11) NOT NULL COMMENT '积分分类ID（store_integral_category.id）',
  `store_cate_id` INT(11) NOT NULL COMMENT '商品分类ID（store_category.id）',
  `add_time` INT(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_integral_cate_id` (`integral_cate_id`),
  UNIQUE KEY `uniq_store_cate_id` (`store_cate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='积分分类与商品分类同步映射';

-- 先同步一级分类（pid=0）
INSERT INTO `eb_store_category` (`pid`, `cate_name`, `sort`, `pic`, `is_show`, `add_time`, `big_pic`)
SELECT
  0 AS pid,
  ic.`cate_name`,
  ic.`sort`,
  ic.`pic`,
  ic.`is_show`,
  ic.`add_time`,
  ic.`big_pic`
FROM `eb_store_integral_category` ic
LEFT JOIN `eb_integral_category_sync_map` m ON m.`integral_cate_id` = ic.`id`
WHERE ic.`pid` = 0
  AND m.`integral_cate_id` IS NULL;

-- 建立一级分类映射
INSERT INTO `eb_integral_category_sync_map` (`integral_cate_id`, `store_cate_id`, `add_time`)
SELECT
  ic.`id`,
  sc.`id`,
  UNIX_TIMESTAMP()
FROM `eb_store_integral_category` ic
JOIN `eb_store_category` sc
  ON sc.`pid` = 0
 AND sc.`cate_name` = ic.`cate_name`
 AND sc.`pic` = ic.`pic`
LEFT JOIN `eb_integral_category_sync_map` m ON m.`integral_cate_id` = ic.`id`
WHERE ic.`pid` = 0
  AND m.`integral_cate_id` IS NULL;

-- 同步二级分类（父级取映射后的商品分类ID）
INSERT INTO `eb_store_category` (`pid`, `cate_name`, `sort`, `pic`, `is_show`, `add_time`, `big_pic`)
SELECT
  pm.`store_cate_id` AS pid,
  ic.`cate_name`,
  ic.`sort`,
  ic.`pic`,
  ic.`is_show`,
  ic.`add_time`,
  ic.`big_pic`
FROM `eb_store_integral_category` ic
JOIN `eb_integral_category_sync_map` pm ON pm.`integral_cate_id` = ic.`pid`
LEFT JOIN `eb_integral_category_sync_map` m ON m.`integral_cate_id` = ic.`id`
WHERE ic.`pid` > 0
  AND m.`integral_cate_id` IS NULL;

-- 建立二级分类映射
INSERT INTO `eb_integral_category_sync_map` (`integral_cate_id`, `store_cate_id`, `add_time`)
SELECT
  ic.`id`,
  sc.`id`,
  UNIX_TIMESTAMP()
FROM `eb_store_integral_category` ic
JOIN `eb_integral_category_sync_map` pm ON pm.`integral_cate_id` = ic.`pid`
JOIN `eb_store_category` sc
  ON sc.`pid` = pm.`store_cate_id`
 AND sc.`cate_name` = ic.`cate_name`
 AND sc.`pic` = ic.`pic`
LEFT JOIN `eb_integral_category_sync_map` m ON m.`integral_cate_id` = ic.`id`
WHERE ic.`pid` > 0
  AND m.`integral_cate_id` IS NULL;

-- 每次执行都刷新映射项字段（保证图标、状态、排序与积分分类一致）
UPDATE `eb_store_category` sc
JOIN `eb_integral_category_sync_map` m ON m.`store_cate_id` = sc.`id`
JOIN `eb_store_integral_category` ic ON ic.`id` = m.`integral_cate_id`
LEFT JOIN `eb_integral_category_sync_map` pm ON pm.`integral_cate_id` = ic.`pid`
SET
  sc.`pid` = IF(ic.`pid` = 0, 0, COALESCE(pm.`store_cate_id`, 0)),
  sc.`cate_name` = ic.`cate_name`,
  sc.`sort` = ic.`sort`,
  sc.`pic` = ic.`pic`,
  sc.`big_pic` = ic.`big_pic`,
  sc.`is_show` = ic.`is_show`;

-- 若 store_category 有 mall_type 字段，则标记为积分商城（2）
SET @has_mall_type := (
  SELECT COUNT(1)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_category'
    AND COLUMN_NAME = 'mall_type'
);
SET @sync_mall_type_sql := IF(
  @has_mall_type > 0,
  'UPDATE eb_store_category sc JOIN eb_integral_category_sync_map m ON m.store_cate_id = sc.id SET sc.mall_type = 2',
  'SELECT 1'
);
PREPARE sync_stmt FROM @sync_mall_type_sql;
EXECUTE sync_stmt;
DEALLOCATE PREPARE sync_stmt;
