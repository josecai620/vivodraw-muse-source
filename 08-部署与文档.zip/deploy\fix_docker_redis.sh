#!/usr/bin/env bash
# 修复 crmeb-app 因 Redis 连接失败导致的崩溃
# 用法：bash deploy/fix_docker_redis.sh 186.241.72.176
set -euo pipefail

SERVER="${1:-186.241.72.176}"
REMOTE_DIR="/opt/crmeb-prod"

echo "==> 修复服务器 .env 中的 Redis/MySQL 主机名（Docker 网络）..."
ssh -p 22 root@${SERVER} bash -s "${REMOTE_DIR}" << 'REMOTE'
REMOTE_DIR="$1"
ENV_FILE="${REMOTE_DIR}/backend_src/.env"

[ -f "$ENV_FILE" ] || { echo "找不到 .env"; exit 1; }

# 将 REDIS_HOSTNAME 改为 redis（Docker 服务名）
sed -i 's/^REDIS_HOSTNAME\s*=\s*.*/REDIS_HOSTNAME = redis/' "$ENV_FILE"
# 将 DATABASE HOSTNAME 改为 mysql
sed -i 's/^HOSTNAME\s*=\s*.*/HOSTNAME = mysql/' "$ENV_FILE" || true
# 若 .env 使用 DATABASE 区块，也处理可能的 DATABASE_HOSTNAME
grep -q "REDIS_HOSTNAME = redis" "$ENV_FILE" && echo "  Redis 主机已改为 redis"
grep -E "HOSTNAME|DATABASE" "$ENV_FILE" | head -5
REMOTE

echo ""
echo "==> 重新创建并启动 crmeb-app 容器（使新环境变量生效）..."
ssh -p 22 root@${SERVER} "cd ${REMOTE_DIR} && (docker compose -f deploy/docker-compose.yml up -d --force-recreate app 2>/dev/null || docker-compose -f deploy/docker-compose.yml up -d --force-recreate app 2>/dev/null || docker restart crmeb-app)"

echo ""
echo "==> 等待 10 秒后检查容器状态..."
sleep 10
ssh -p 22 root@${SERVER} "docker ps -a --filter name=crmeb-app --format '{{.Status}}' && curl -s -o /dev/null -w 'API: %{http_code}\n' http://127.0.0.1:20199/api/ 2>/dev/null || echo 'API 检查略'"

echo ""
echo "✅ 完成。若容器仍 Restarting，请执行: ssh root@${SERVER} 'docker logs crmeb-app --tail 30' 查看日志"
