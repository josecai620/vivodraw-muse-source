# CoreSettlement Phase 11 Target-Env Readonly Readiness 2026-05-18

## Current Task

Phase 11 只做 target-env readonly readiness collection。

本轮未执行写 SQL，未执行 migration，未修改生产 DB，未改结构，未开启任何 switch。

## Target Environment

Confirmed target:

- host: `8.166.115.27`
- app dir: `/opt/crmeb-prod`
- backend dir: `/opt/crmeb-prod/backend_src`
- DB host: `127.0.0.1`
- DB port: `3306`
- DB name: `manghehoutai_qhe`
- DB user: `crmeb`
- MySQL version: `8.0.45-0ubuntu0.24.04.1`
- MySQL hostname: `Eccomall`
- `@@read_only`: `0`
- `@@super_read_only`: `0`

Note:

- Server DB is not globally read-only.
- This phase still used only readonly `SELECT` and `information_schema` checks.

## Backup Path Status

Expected backup path from project workflow:

- `/opt/crmeb-prod/db_backup`

Readonly check result:

- `/opt/crmeb-prod/db_backup` was not confirmed present.

Observed backup-like directories:

- `/opt/crmeb-prod/backend_src/backup`
- `/opt/crmeb-prod/deploy/backup`
- `/opt/crmeb-prod/deploy_backups`

Conclusion:

- DB backup path is not approved for any execution phase.
- Do not execute write SQL until a DB backup path is explicitly confirmed and a fresh backup exists.
- No backup was created in this phase.

## Readonly SQL Checks Run

Only readonly statements were run:

- `SELECT DATABASE(), @@hostname, @@version, @@read_only, @@super_read_only`
- `information_schema.TABLES` table presence check
- `information_schema.COLUMNS` column check
- `information_schema.STATISTICS` index check
- `eb_system_config` switch presence check

No `INSERT`, `UPDATE`, `DELETE`, `TRUNCATE`, `DROP`, `ALTER`, or `CREATE` was executed.

## Table Readiness Result

```text
eb_core_point_ledger       missing
eb_core_settlement_ledger  missing
eb_core_settlement_record  missing
```

Current PHP writer requires:

- `eb_core_settlement_ledger`

Result:

- Not ready.
- Current writer table is missing in target DB.
- Do not open any CoreSettlement switch.

## Ledger Column And Index Result

Because `eb_core_settlement_ledger` is missing:

- no ledger columns were returned
- no ledger indexes were returned
- unique key `scene + request_id` is not present

Readiness:

- failed

## Config Switch Readiness Result

```text
core_settlement_checkin_shadow     missing
core_settlement_daily_task_shadow  missing
core_settlement_game_farm_shadow   missing
core_settlement_game_mine_shadow   missing
core_settlement_pet_feed_shadow    missing
```

Result:

- All required switch rows are missing.
- No switch is currently present with value `1`.
- Missing switch rows are safe by code default because `sys_config(..., 0)` returns `0`.
- Do not insert or enable switch rows in this phase.

## Append-Only And Mutation Scan

Local docs and SQL draft scan checked for planned ledger mutation statements in:

- `docs/backend-master`
- `backend_src/deploy/sql`
- `deploy`

Result:

- No executable CoreSettlement ledger mutation SQL was found.
- Only documented forbidden examples were found in Phase 10 docs:
  - `UPDATE eb_core_settlement_ledger ...`
  - `DELETE FROM eb_core_settlement_ledger ...`
  - `TRUNCATE TABLE eb_core_settlement_ledger`
  - `DROP TABLE eb_core_settlement_ledger`

Hard rule remains:

- `eb_core_settlement_ledger` must be append-only.
- rollback may only set config switches back to `0`.
- rollback must not alter or delete ledger history.

## Phase 11 Decision

Phase 11 readiness failed by design:

1. DB backup path is not confirmed.
2. `eb_core_settlement_ledger` is missing.
3. ledger unique key `scene + request_id` is missing because the table is missing.
4. all five config switch rows are missing.
5. DB server itself is writable, so operator discipline matters.

Required state before any later execution:

- confirmed fresh DB backup
- `eb_core_settlement_ledger` table draft approved
- switch seed draft approved with default `0`
- cache clear path confirmed
- readonly re-check result captured
- one switch opened at a time only after explicit approval

## Forbidden Areas

Do not touch without explicit approval:

- `backend_src/app/controller/api/v1/manghe/MangheController.php`
- payment
- order
- real inventory deduction
- write SQL
- structure changes
- migration execution
- production DB mutation
- server `.env`
- `game/*`
- `mobile-app/*`
- `mobile-app-v3/*`
- unrelated dirty worktree changes

## Next Task

Phase 12 should be backup-and-execution approval planning only.

Recommended next step:

1. Confirm exact DB backup path and retention rule.
2. Decide whether to create a fresh DB backup in a separately approved phase.
3. Keep all CoreSettlement switches off.
4. Do not execute table creation or switch seed SQL until explicit approval.

## NEXT WINDOW HANDOFF PACKAGE

- Role: Backend Master Controller
- Phase: Phase 12 backup-and-execution approval planning
- Completed: Phase 11 target-env readonly readiness collection
- Key Findings: target DB reachable; writer table missing; all switches missing/default off; backup path not confirmed
- Key Files: this report, `docs/backend-master/CoreSettlement_Phase10_NoExecution_Migration_Readiness_2026-05-18.md`
- Dirty Worktree Notes: unrelated game/mobile/v3/docs deletions remain; do not stage broad changes
- Forbidden Areas: payment/order/Manghe/write SQL/migration/prod DB mutation/game/mobile/v3
- Next Step: confirm backup path and get explicit approval before any DB-changing phase
- Validation: readonly SQL only; docs diff check required
- Risks: target DB is writable; running old broad SQL would still create wrong tables; opening switches before table creation would be unsafe
