/* 仅在 /tmp 的独立副本构建；不安装依赖、不发布、不改生产源文件。 */
'use strict';
const fs = require('fs');
const path = require('path');
const root = fs.realpathSync(process.argv[2] || '');
const output = path.resolve(process.argv[3] || '');
if (!/^\/tmp\/support-admin-build\.[A-Za-z0-9]+\/(base|candidate)$/.test(root)
  || path.dirname(output) !== path.dirname(root)
  || !['base-dist', 'candidate-dist'].includes(path.basename(output))) throw new Error('Isolated build paths required');
process.chdir(root);
process.env.VUE_APP_LEGACY = '1';
process.env.NODE_ENV = 'production';
// 与线上当前前端构建环境一致，仅接收这五个公开构建参数，不搬运后端 .env。
const dotenv = require(path.join(root, 'node_modules/dotenv'));
const production = '/opt/crmeb-prod/backend_src/view/admin/.env.production';
if (fs.existsSync(production)) {
  const values = dotenv.parse(fs.readFileSync(production));
  const allowed = new Set(['NODE_ENV', 'VUE_APP_ENV', 'VUE_APP_TITLE', 'VUE_APP_WS_ADMIN_URL', 'VUE_APP_API_URL']);
  for (const [key, value] of Object.entries(values)) {
    if (!allowed.has(key) || value.length > 200 || /[\r\n]/.test(value)) throw new Error('Unexpected build environment');
    if (key === 'NODE_ENV' && value !== 'production') throw new Error('Production mode required');
    if (key.endsWith('_URL') && value && !/^(?:\/(?:adminapi|admin-shop|admin)(?:\/.*)?|(?:https?|wss?):\/\/vivodraw\.com(?:\/[^\s]*)?)$/.test(value)) throw new Error('Unexpected public endpoint');
    process.env[key] = value;
  }
}
const Service = require(path.join(root, 'node_modules/@vue/cli-service/lib/Service'));
const service = new Service(root);
const loadOptions = service.loadUserOptions.bind(service);
service.loadUserOptions = () => {
  const options = loadOptions();
  // Vue CLI 3 的 Babel 与 Terser 都读取同一个 parallel 选项。
  options.parallel = false;
  return options;
};
service.run('build', { mode: 'production', dest: output }).catch((error) => {
  console.error('Isolated admin build failed; production unchanged.');
  console.error(String(error && error.message).replace(/(['"])[^'"\r\n]*\1/g, '[value]').slice(0, 600));
  process.exitCode = 1;
});
