# KeyAPI Hot Products Watchlist - 2026-07-01

Scope: US-market product discovery signals for VivoDraw. This is a watchlist, not an import batch.

## API Samples

| Source | Endpoint | Params | Result |
| --- | --- | --- | --- |
| TikTok Shop | `GET /v1/tiktok/product/list/analytics` | `region=US`, `sales_trend_flag=1`, `min_spu_avg_price=8`, `max_spu_avg_price=80`, `min_product_rating=4`, `min_review_count=20`, sorted by 7-day sales desc | 10 products returned |
| TikTok Shop | `GET /v1/tiktok/product/ranking/analytics` | `date=2026-06-30`, `region=US`, weekly sales ranking | success, 0 products returned |
| Google Shopping | `GET /v1/google/shopping` | `q=portable handheld fan`, `gl=us`, `hl=en`, `page=1` | 40 shopping results returned |
| Amazon | `GET /v1/amazon/best-sellers` | `category=beauty`, `type=MOVERS_AND_SHAKERS`, `country=US` | success, 0 products returned |

Approximate trial spend: 8 KeyAPI credits. Verify final credit usage in KeyAPI dashboard.

## Candidate Signals

| Priority | Candidate | Signal | VivoDraw Fit | Gate |
| --- | --- | --- | --- | --- |
| P1 | Portable handheld fan / power-bank fan | Google Shopping shows $4.88-$19.90 mass-market offers plus premium anchors; seasonal summer demand | Outdoor / Travel, Cute Desk | Need CJ or supplier source, real photos, landed cost |
| P1 | Korean skincare stick / serum | TikTok Shop shows very high 7-day sales for medicube items; beauty category already fits first-six category plan | Beauty & Self-care | Brand/trademark risk; do not clone brand listing; source generic alternative only |
| P1 | Electrolyte / hydration sticks | TikTok Shop shows strong 7-day sales and low ticket price | Outdoor / Travel, Beauty & Self-care | Consumable compliance risk; avoid unless supplier certificates clear |
| P2 | Mini massage / fascia recovery device | TikTok Shop shows high 7-day sales and $74.99 ASP | Outdoor / Travel, Premium Tech | Need safety/compliance and warranty clarity |
| P2 | Compact screwdriver / repair tool kit | TikTok Shop shows strong sales, $20.70 ASP, high rating | Game Gear, Premium Tech | Good non-consumable candidate if sourcing/image rights pass |
| P2 | LED vanity mirror | Prior workflow candidate; aligns with beauty demand, giftable visual fit | Beauty & Self-care, Cute Desk | Need CJ listing, images, cost confirmation |
| Reject now | Branded Dyson/Shark fans | Google Shopping validates demand, but brand/IP and margin risk high | Premium Tech | Do not upload unless authorized reseller path exists |

## Upload Gate

- Do not import these rows directly into product drafts.
- Amazon, TikTok, and Google images are `needs_rights_check`; not front-end upload material.
- Import-ready path remains: find CJ/supplier/manual source, confirm cost and shipping buffer, use authorized images, set `image_status=pass`, then create a normal CSV import batch.
- Current product import command supports safe draft creation, but upload must stay `is_show=0` until manual review.

## Raw Local Evidence

Raw responses are stored locally under `/tmp/keyapi-vivodraw-20260701180205/`.

