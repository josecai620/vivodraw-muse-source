-- ============================================================
-- 拼团抽奖 后台菜单 + 权限
-- 挂到 营销(marketing) 下，新增一个父菜单 "拼团抽奖"，下含 5 个子菜单
-- 执行：mysql -u用户 -p 数据库 < 本文件
-- 幂等：使用 NOT EXISTS 判断，可重复执行
-- ============================================================
SET NAMES utf8mb4;

-- 获取 营销 父菜单 id
SET @marketing_pid = (SELECT `id` FROM `eb_system_menus` WHERE (`header` = 'marketing' OR `menu_path` = '/admin/marketing') AND `is_del` = 0 ORDER BY `id` ASC LIMIT 1);
SET @marketing_pid = IFNULL(@marketing_pid, 1);

-- 1. 父菜单：拼团抽奖
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @marketing_pid, 0, 'md-ribbon', '拼团抽奖', 'admin', '', '', '', 'GET', '[]', 60, 1, 0, 1, '/admin/marketing/group_lottery', '1', 1, 'marketing', 0, 'admin-marketing-group_lottery', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/marketing/group_lottery' AND `unique_auth` = 'admin-marketing-group_lottery' AND `is_del` = 0);

SET @group_pid = (SELECT `id` FROM `eb_system_menus` WHERE `menu_path` = '/admin/marketing/group_lottery' AND `unique_auth` = 'admin-marketing-group_lottery' AND `is_del` = 0 LIMIT 1);

-- 2. 子菜单：抽奖商品
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @group_pid, 1, 'md-albums', '抽奖商品', 'admin', 'marketing.group_lottery.GroupLotteryAdmin', 'index', 'marketing/group_lottery', 'GET', '[]', 10, 1, 1, 1, '/admin/marketing/group_lottery/index', '1', 1, 'marketing', 0, 'marketing-group_lottery', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/marketing/group_lottery/index' AND `is_del` = 0);

-- 2a. 权限：添加商品（按钮/页面级）
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @group_pid, 1, '', '添加抽奖商品', 'admin', 'marketing.group_lottery.GroupLotteryAdmin', 'save', 'marketing/group_lottery/:id', 'POST', '[]', 11, 0, 0, 2, '', '1', 1, 'marketing', 0, 'marketing-group_lottery-create', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `unique_auth` = 'marketing-group_lottery-create' AND `is_del` = 0);

-- 3. 子菜单：拼团列表
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @group_pid, 1, 'md-people', '拼团列表', 'admin', 'marketing.group_lottery.GroupLotteryAdmin', 'pinkList', 'marketing/group_lottery_pink/list', 'GET', '[]', 20, 1, 1, 1, '/admin/marketing/group_lottery/pink_list', '1', 1, 'marketing', 0, 'marketing-group_lottery-pink_list', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/marketing/group_lottery/pink_list' AND `is_del` = 0);

-- 4. 子菜单：取消审核
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @group_pid, 1, 'md-checkbox-outline', '取消审核', 'admin', 'marketing.group_lottery.GroupLotteryAdmin', 'cancelList', 'marketing/group_lottery_pink/cancel_list', 'GET', '[]', 30, 1, 1, 1, '/admin/marketing/group_lottery/cancel_review', '1', 1, 'marketing', 0, 'marketing-group_lottery-cancel_review', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/marketing/group_lottery/cancel_review' AND `is_del` = 0);

-- 5. 子菜单：机器人管理
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @group_pid, 1, 'logo-octocat', '机器人管理', 'admin', 'marketing.group_lottery.GroupLotteryAdmin', 'robotList', 'marketing/group_lottery_robot/list', 'GET', '[]', 40, 1, 1, 1, '/admin/marketing/group_lottery/robot_list', '1', 1, 'marketing', 0, 'marketing-group_lottery-robot_list', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/marketing/group_lottery/robot_list' AND `is_del` = 0);

-- 6. 子菜单：统计报表
INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @group_pid, 1, 'md-stats', '统计报表', 'admin', 'marketing.group_lottery.GroupLotteryAdmin', 'report', 'marketing/group_lottery/report', 'GET', '[]', 50, 1, 1, 1, '/admin/marketing/group_lottery/statistics', '1', 1, 'marketing', 0, 'marketing-group_lottery-statistics', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/marketing/group_lottery/statistics' AND `is_del` = 0);

-- 7. 确保超级管理员权限（admin 账户 & 角色 1 持有所有权限 *）
UPDATE `eb_system_admin` SET `level` = 0, `roles` = '1' WHERE `account` = 'admin' AND `is_del` = 0;
UPDATE `eb_system_role` SET `rules` = '*' WHERE `id` = 1 AND `status` = 1 AND (IFNULL(`rules`,'') = '' OR `rules` IS NULL);

-- 查看插入结果
SELECT `id`, `pid`, `menu_name`, `menu_path`, `unique_auth`, `is_show`, `is_del`
FROM `eb_system_menus`
WHERE `menu_path` LIKE '/admin/marketing/group_lottery%'
  AND `is_del` = 0
ORDER BY `pid`, `sort`, `id`;
