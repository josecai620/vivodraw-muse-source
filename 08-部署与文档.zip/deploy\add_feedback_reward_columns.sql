-- Vivodraw: feedback type/images + admin reward columns
-- Safe to re-run: only adds missing columns.

SET @db := DATABASE();

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_service_feedback' AND COLUMN_NAME='type'),
    'SELECT 1',
    'ALTER TABLE `eb_store_service_feedback` ADD COLUMN `type` varchar(32) NOT NULL DEFAULT \'\' COMMENT \'feedback type code\' AFTER `phone`'
  )
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_service_feedback' AND COLUMN_NAME='images'),
    'SELECT 1',
    'ALTER TABLE `eb_store_service_feedback` ADD COLUMN `images` text NULL COMMENT \'json images\' AFTER `content`'
  )
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_service_feedback' AND COLUMN_NAME='title'),
    'SELECT 1',
    'ALTER TABLE `eb_store_service_feedback` ADD COLUMN `title` varchar(120) NOT NULL DEFAULT \'\' COMMENT \'optional title\' AFTER `type`'
  )
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_service_feedback' AND COLUMN_NAME='reward_status'),
    'SELECT 1',
    'ALTER TABLE `eb_store_service_feedback` ADD COLUMN `reward_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT \'0 none 1 rewarded\' AFTER `status`'
  )
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_service_feedback' AND COLUMN_NAME='reward_points'),
    'SELECT 1',
    'ALTER TABLE `eb_store_service_feedback` ADD COLUMN `reward_points` int NOT NULL DEFAULT 0 COMMENT \'points granted\' AFTER `reward_status`'
  )
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_service_feedback' AND COLUMN_NAME='reward_time'),
    'SELECT 1',
    'ALTER TABLE `eb_store_service_feedback` ADD COLUMN `reward_time` int NOT NULL DEFAULT 0 COMMENT \'unix reward time\' AFTER `reward_points`'
  )
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- widen content if still 500
SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_service_feedback' AND COLUMN_NAME='content' AND CHARACTER_MAXIMUM_LENGTH < 2000),
    'ALTER TABLE `eb_store_service_feedback` MODIFY COLUMN `content` varchar(2000) NOT NULL DEFAULT \'\' COMMENT \'反馈内容\'',
    'SELECT 1'
  )
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- widen make for reward notes
SET @sql := (
  SELECT IF(
    EXISTS(SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='eb_store_service_feedback' AND COLUMN_NAME='make' AND CHARACTER_MAXIMUM_LENGTH < 500),
    'ALTER TABLE `eb_store_service_feedback` MODIFY COLUMN `make` varchar(500) NOT NULL DEFAULT \'\' COMMENT \'备注\'',
    'SELECT 1'
  )
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
