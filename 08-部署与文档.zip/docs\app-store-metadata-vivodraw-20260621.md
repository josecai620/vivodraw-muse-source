# VivoDraw Store Metadata Draft - 2026-06-21

Latest verification: 2026-07-03.

## Store Listing

- App name: VivoDraw
- Subtitle: Rewards, shopping, and member deals
- Short description: Shop useful goods, earn member rewards, track orders, and manage support in one VivoDraw account.
- Category recommendation: Shopping
- Secondary category: Lifestyle
- Age rating working assumption: 17+ until randomized reward wording and prize odds are reviewed in App Store Connect / Play Console questionnaires.

## Long Description

VivoDraw is a rewards-focused shopping app for curated everyday goods, gaming accessories, beauty picks, travel gear, and desk upgrades.

Members can browse product shelves, save favorites, manage cart and orders, collect points, use coupons, join reward activities, and contact support from one account. Reward pages keep prize rules, odds, balances, and order records visible before the user acts.

Account controls include profile editing, mobile binding, privacy policy access, support contact, and authenticated account deletion. Physical goods checkout is prepared for live payment handoff, while high-risk payment, inventory, and reward-settlement switches remain closed until owner approval.

## Keywords

shopping, rewards, coupons, points, orders, customer support, curated products, member deals, mystery rewards

## Review Notes

- Test account: owner must create an App Review / Play review account after email or SMS verification is stable.
- Login methods: password, email code, mobile code, and Google ID token paths exist in the app; provider readiness must be verified before submission.
- Account deletion: open Profile or Support, then `Delete account`; signed-in users must type `DELETE` before the authenticated deletion endpoint is called.
- Support: in-app support chat and email route point to `support@vivodraw.com`; MX/SPF/DMARC were visible on 2026-07-03, but real send/receive still needs owner verification.
- Payments: keep `EXPO_PUBLIC_ENABLE_STRIPE_CHECKOUT=0` until Stripe production readiness is approved. Do not imply live paid checkout before the switch is intentionally enabled.
- Randomized rewards: show prize rules and odds before any paid flow. Avoid cash-out language.

## Required Public URLs

- Privacy policy: `https://vivodraw.com/agreement/privacy`
- Terms: `https://vivodraw.com/agreement/terms`
- Support: `https://vivodraw.com/support`
- Account deletion: `https://vivodraw.com/account/delete`
- Refund / returns: `https://vivodraw.com/agreement/returns`
- Shipping: `https://vivodraw.com/agreement/shipping`

These URLs returned clean `200` on the public domain on 2026-07-03. Recheck before store submission, because stale launch evidence ages like milk.

## Apple App Privacy Draft

- Contact Info: email / phone may be collected for account, support, order, and verification.
- User Content: support messages, screenshots, reviews, and community posts may be collected when the user submits them.
- Purchases: order and transaction metadata may be collected for checkout, fulfillment, refunds, fraud prevention, and accounting.
- Identifiers: user ID and auth token are used for account session and backend requests.
- Usage Data: route and feature usage may be used for app operation and support diagnostics if analytics is enabled.
- Diagnostics: crash and error diagnostics may be collected through platform tooling if enabled.
- Tracking: mark `No` unless third-party cross-app tracking SDKs are added and approved.

## Google Data Safety Draft

- Data collected: personal info, messages, photos/files submitted to support, purchase/order records, app activity, device or other IDs.
- Data sharing: payment processor, shipping/fulfillment partners, authentication providers, and support tooling only when needed to operate the service.
- Data security: data is transmitted over HTTPS after public-domain TLS is fixed; account deletion is available in-app and on web.
- Deletion request: `https://vivodraw.com/account/delete`
- Optional data: screenshots, community posts, reviews, support attachments.

## Screenshot Plan

- iPhone 6.7-inch: Home, Browse, Product detail, Cart/Checkout preview, Rewards hub, Points, Box rules/odds, Profile, Support, Delete account.
- iPhone 6.5-inch or 5.5-inch if App Store Connect asks for fallback sizes.
- iPad screenshots only if keeping `supportsTablet=true`.
- Android phone: same screen set as iPhone.
- Do not include fake paid checkout success, unavailable provider claims, or rewards that hide odds.

## Owner-Only Store Steps

1. Create or link Expo EAS project, then commit the real `extra.eas.projectId`.
2. Create App Store Connect app with `com.vivodraw.app`.
3. Create Google Play app with `com.vivodraw.app`.
4. Configure Apple signing and Google service account credentials for EAS Submit.
5. Verify public domain, HTTPS, support email DNS, privacy URLs, and account deletion URL.
6. Create review test account and verify it can log in without one-time-provider dead ends.
7. Run TestFlight / internal testing, collect screenshots, then submit.
