#!/usr/bin/env bash
# 从线上服务器拉取最新代码到本地（用于多人协作时同步服务器上的变更）
# 用法: bash deploy/从服务器同步到本地.sh [服务器IP]
# 示例: bash deploy/从服务器同步到本地.sh 186.241.72.176
set -euo pipefail

SERVER_IP="${1:-186.241.72.176}"
SSH_USER="${2:-root}"
SSH_PORT="${3:-49375}"
REMOTE_DIR="/opt/crmeb-prod"
LOCAL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "==> 从 ${SERVER_IP} 拉取 backend_src 到本地（排除构建产物与缓存）"
rsync -avz -e "ssh -p ${SSH_PORT}" \
  --exclude='.env' \
  --exclude='public/admin/' \
  --exclude='public/_expo/' \
  --exclude='public/static/' \
  --exclude='public/legacy/' \
  --exclude='public/uploads/' \
  --exclude='public/phpExcel/' \
  --exclude='public/install/install.lock' \
  --exclude='view/admin/node_modules/' \
  --exclude='view/supplier/node_modules/' \
  --exclude='runtime/' \
  --exclude='*.log' \
  --exclude='vendor/xin/container/.git' \
  --exclude='vendor/xin/helper/.git' \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/backend_src/" \
  "${LOCAL_ROOT}/backend_src/"

echo "==> 从 ${SERVER_IP} 拉取 deploy 到本地"
rsync -avz -e "ssh -p ${SSH_PORT}" \
  --exclude='.env' \
  "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/deploy/" \
  "${LOCAL_ROOT}/deploy/"

echo "==> 从 ${SERVER_IP} 拉取根目录文件到本地"
for f in admin.php docker-compose.yml migrations/20260516_consolidated_menu_fixes.sql run_fix_manghe_menus.sh; do
  rsync -avz -e "ssh -p ${SSH_PORT}" \
    "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/${f}" \
    "${LOCAL_ROOT}/" 2>/dev/null || true
done

echo "==> 同步完成"
echo "注意: 服务器上无 mobile-app 源码，前台代码仅存于本仓库。"
echo "建议: 执行 git add . && git status 检查变更后再提交。"
