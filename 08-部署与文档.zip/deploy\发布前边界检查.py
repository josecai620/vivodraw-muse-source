# -*- coding: utf-8 -*-
"""前台发布前的改动归属与边界检查。

默认策略是 fail-closed：只要工作区存在清单外的改动、敏感路径或旧生产地址，
就拒绝继续。清单建议写到仓库外的临时目录，避免把一次发布状态提交进 Git。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path, PureWindowsPath
from typing import NoReturn


REPO_ROOT = Path(__file__).resolve().parents[1]
FORBIDDEN_PREFIXES = (
    ".env",
    ".git/",
    "backend_src/public/",
    "backend_src/runtime/",
    "backend_src/uploads/",
    "game/",
    "mobile-app-v3/",
    "mobile-app/dist-root/",
    "mobile-app/dist-v4/",
    "deploy/",
)
FORBIDDEN_NAMES = {
    "deploy/v4-root-bundle.tar.gz",
    "deploy/v4-slim-overlay.tar.gz",
}
OLD_PRODUCTION_MARKERS = (
    "8.166.115.27",
    "旧广州阿里云服务器",
)


def run_git_bytes(*args: str) -> bytes:
    result = subprocess.run(
        ["git", "--literal-pathspecs", "-C", str(REPO_ROOT), *args],
        check=True,
        capture_output=True,
    )
    return result.stdout


def run_git(*args: str) -> str:
    return run_git_bytes(*args).decode("utf-8", errors="strict")


def normalize_path(value: str) -> str:
    if not value or "\0" in value or PureWindowsPath(value).drive or value.startswith(("/", "\\")):
        fail("清单必须使用仓库内相对文件路径")
    normalized = value.replace("\\", "/")
    while normalized.startswith("./"):
        normalized = normalized[2:]
    parts = normalized.split("/")
    if any(part in ("", ".", "..") or ":" in part for part in parts):
        fail("清单包含空路径、路径遍历或非法文件名")
    return normalized


def status_path(value: bytes) -> str:
    path = value.decode("utf-8", errors="strict")
    # Git 的 -z 输出已经是原始仓库相对路径，不能再把文件名中的反斜杠当分隔符。
    if "\\" in path or normalize_path(path) != path:
        fail("Git 返回了不能安全表示的文件路径")
    return path


def changed_paths() -> set[str]:
    paths: set[str] = set()
    raw = run_git_bytes("status", "--porcelain=v1", "-z", "--untracked-files=all")
    if not raw:
        return paths
    if not raw.endswith(b"\0"):
        fail("Git 状态输出不完整")
    records = iter(raw[:-1].split(b"\0"))
    for record in records:
        if len(record) < 4 or record[2:3] != b" ":
            fail("Git 状态记录不合法")
        state = record[:2]
        if any(chr(char) not in " MADRCU?!T" for char in state) or b"U" in state or state in (b"AA", b"DD", b"!!"):
            fail("工作区有冲突或不能安全发布的 Git 状态")
        paths.add(status_path(record[3:]))
        # porcelain -z 重命名格式：目标路径\0原路径\0；两侧必须分别归属允许清单。
        if b"R" in state or b"C" in state:
            original = next(records, None)
            if original is None:
                fail("Git 重命名记录不完整")
            paths.add(status_path(original))
    return paths


def baseline_changed_paths(base_commit: str) -> set[str]:
    # 自定义基线也必须检查其中的已提交改动，不能把它们藏在干净的 status 后面。
    raw = run_git_bytes("diff", "--no-ext-diff", "--no-textconv", "--name-only", "--no-renames", "-z", base_commit, "--")
    if not raw:
        return set()
    if not raw.endswith(b"\0"):
        fail("Git 基线差异输出不完整")
    return {status_path(path) for path in raw[:-1].split(b"\0")}


def is_forbidden(path: str) -> bool:
    path = path.casefold()
    if any(part == ".git" or part.startswith(".env") for part in path.split("/")):
        return True
    return path in FORBIDDEN_NAMES or any(
        path == prefix.rstrip("/") or path.startswith(prefix)
        for prefix in FORBIDDEN_PREFIXES
    )


def diff_bytes(paths: set[str], base_commit: str) -> bytes:
    if not paths:
        return b""
    # 基线到当前文件的 diff 包含已暂存修改；未跟踪文件由 source_states 完整覆盖。
    return run_git_bytes("diff", "--no-ext-diff", "--no-textconv", "--binary", base_commit, "--", *sorted(paths))


def source_file(path: str) -> Path:
    target = REPO_ROOT.joinpath(*path.split("/"))
    try:
        target.resolve().relative_to(REPO_ROOT)
    except (OSError, ValueError):
        fail("源文件越出仓库边界")
    current = REPO_ROOT
    for part in path.split("/"):
        current = current / part
        try:
            info = current.lstat()
        except FileNotFoundError:
            continue
        # Windows junction/reparse point 也不能作为发布源目录或文件。
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
            fail("清单包含符号链接或重解析路径")
    return target


def source_states(paths: set[str]) -> dict[str, dict]:
    states = {}
    for path in sorted(paths):
        target = source_file(path)
        if not target.exists():
            states[path] = {"deleted": True, "sha256": None, "size": 0}
            continue
        if not target.is_file():
            fail("允许清单只能包含普通源文件，不能包含目录或特殊文件")
        content = target.read_bytes()
        for marker in OLD_PRODUCTION_MARKERS:
            if marker.encode("utf-8") in content:
                fail(f"源文件包含废弃生产地址或标记：{marker}")
        states[path] = {"deleted": False, "sha256": hashlib.sha256(content).hexdigest(), "size": len(content)}
    return states


def manifest_target(path: Path) -> Path:
    # 发布状态不能覆盖仓库文件，也不能通过链接写到未检查的目标。
    absolute = Path(os.path.abspath(path))
    for item in (absolute, *absolute.parents):
        try:
            info = item.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400):
            fail("发布清单目标不能使用链接路径")
    target = absolute.resolve()
    if target == REPO_ROOT or REPO_ROOT in target.parents:
        fail("发布清单必须写在仓库外")
    return target


def fail(message: str) -> "NoReturn":
    print(f"发布边界检查失败：{message}", file=sys.stderr)
    raise SystemExit(2)


def main() -> int:
    global REPO_ROOT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=REPO_ROOT,
        help="要检查的独立 worktree 根目录，默认是本仓库根目录",
    )
    parser.add_argument(
        "--allow",
        nargs="+",
        action="extend",
        required=True,
        help="本次 Agent 明确负责的仓库相对源文件，可重复传入",
    )
    parser.add_argument(
        "--manifest",
        required=True,
        type=Path,
        help="仓库外的发布清单路径；清单会记录基线和改动摘要",
    )
    parser.add_argument(
        "--base-ref",
        default="HEAD",
        help="本次发布核对的 Git 基线，默认 HEAD",
    )
    parser.add_argument(
        "--artifact",
        action="append",
        default=[],
        help="scoped overlay 允许上传的 dist-root 相对产物，可重复传入",
    )
    args = parser.parse_args()
    REPO_ROOT = args.repo_root.resolve()
    if Path(run_git("rev-parse", "--show-toplevel").strip()).resolve() != REPO_ROOT:
        fail("--repo-root 必须是独立 worktree 的仓库根目录")
    head_commit = run_git("rev-parse", "--verify", "HEAD^{commit}").strip()
    base_commit = run_git("rev-parse", "--verify", "--end-of-options", args.base_ref + "^{commit}").strip()
    manifest_path = manifest_target(args.manifest)

    allowed = {normalize_path(item) for item in args.allow}
    if not allowed:
        fail("必须提供至少一个允许发布的源文件")
    if any(is_forbidden(path) for path in allowed):
        fail("允许清单包含禁止发布路径")
    for path in allowed:
        target = source_file(path)
        if target.exists() and not target.is_file():
            fail("允许清单只能包含普通源文件")
    artifacts = [normalize_path(item) for item in args.artifact]
    if any(any(part == ".git" or part.startswith(".env") for part in item.casefold().split("/")) for item in artifacts):
        fail("产物清单包含敏感路径")

    status_paths = changed_paths() | baseline_changed_paths(base_commit)
    forbidden = sorted(path for path in status_paths if is_forbidden(path))
    if forbidden:
        fail("工作区包含禁止路径：" + ", ".join(forbidden))

    unexpected = sorted(status_paths - allowed)
    if unexpected:
        fail("发现清单外改动：" + ", ".join(unexpected))

    diff = diff_bytes(status_paths, base_commit)
    for marker in OLD_PRODUCTION_MARKERS:
        if marker.encode("utf-8") in diff:
            fail(f"改动包含废弃生产地址或标记：{marker}")
    states = source_states(status_paths)
    state_json = json.dumps(states, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    if ((changed_paths() | baseline_changed_paths(base_commit)) != status_paths
            or source_states(status_paths) != states
            or run_git("rev-parse", "--verify", "HEAD^{commit}").strip() != head_commit
            or run_git("rev-parse", "--verify", "--end-of-options", args.base_ref + "^{commit}").strip() != base_commit):
        fail("检查期间基线或源文件发生变化，请重新核对")

    manifest = {
        "schema": 1,
        "mode": "scoped-overlay",
        "base_ref": args.base_ref,
        "base_commit": base_commit,
        "allowed_source_paths": sorted(allowed),
        "actual_changed_paths": sorted(status_paths),
        "artifact_paths": artifacts,
        "diff_sha256": hashlib.sha256(diff).hexdigest(),
        "source_states": states,
        "source_state_sha256": hashlib.sha256(state_json.encode("utf-8")).hexdigest(),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    print("发布边界检查通过：仅允许 scoped overlay，禁止整站覆盖。")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, subprocess.CalledProcessError, UnicodeError):
        fail("无法完整读取仓库或发布清单，已拒绝发布")
