# 机器人/测试数据清理方案（2026-05-02）

对象：测试服务器 `8.166.115.27`，数据库 `manghehoutai_qhe`。

本方案当前只提交脚本和执行计划，尚未删除服务器数据。

## 清理范围

只清理以下 5 张表中 `is_jiqiren = 1` 的机器人/测试数据：

- `eb_store_integral_product_huanqu_log_unique`
- `eb_store_integral_product_huanqu_log`
- `eb_store_integral_product_kaijiang_log`
- `eb_user_box`
- `eb_box_order`

不清理：

- `is_jiqiren = 0` 的非机器人数据
- `eb_store_order`
- 用户、商品、菜单、配置、系统日志
- 机器人基础账号表，例如 `eb_user_jiqiren`

## 只读核对结果

当前机器人/非机器人分布：

| 表 | 机器人行 | 非机器人行 |
| --- | ---: | ---: |
| `eb_store_integral_product_huanqu_log_unique` | 12,721,643 | 822 |
| `eb_store_integral_product_huanqu_log` | 609,513 | 228 |
| `eb_store_integral_product_kaijiang_log` | 45,835 | 8 |
| `eb_user_box` | 351,346 | 846 |
| `eb_box_order` | 206,153 | 392 |

关联边界核对：

| 检查项 | 结果 |
| --- | ---: |
| 机器人 `user_box` 找不到机器人 `box_order` | 0 |
| 非机器人 `user_box` 关联到机器人 `box_order` | 0 |
| 机器人 `huanqu_log` 找不到机器人 `box_order` | 0 |
| 非机器人 `huanqu_log` 关联到机器人 `box_order` | 0 |
| 机器人唯一号找不到机器人 `huanqu_log` | 0 |
| 非机器人唯一号关联到机器人 `huanqu_log` | 0 |
| 机器人开奖找不到机器人 `huanqu_log` | 0 |
| 非机器人开奖关联到机器人 `huanqu_log` | 0 |
| `store_order` 引用机器人 `user_box` | 0 |

结论：按 `is_jiqiren = 1` 清理这 5 张表，当前不会穿透到非机器人链路，也不会影响 `store_order`。

## 执行前必须做

1. 确认已有全库备份：
   - `db_backup/db_20260502_182104_host.sql.gz`
2. 再执行机器人行归档：
   - `bash deploy/db_archive_robot_data_phase7.sh 8.166.115.27`
3. 检查归档目录里的 `counts.tsv`，确认行数与本方案一致或能解释差异。
4. 选择低峰期执行清理。

## 执行脚本

归档脚本：

- `deploy/db_archive_robot_data_phase7.sh`

清理脚本：

- `deploy/db_cleanup_phase7_robot_data.sql`

验证脚本：

- `deploy/db_cleanup_phase7_verify.sql`

## 删除策略

清理 SQL 使用主键范围分批删除，避免一次性 `DELETE` 1200 万行导致长事务和过大 undo：

- 唯一号表：每批 50,000 个 id 范围
- 其他表：每批 10,000 到 20,000 个 id 范围
- 每批后短暂 sleep
- 删除顺序按子表到父表执行：
  1. `eb_store_integral_product_huanqu_log_unique`
  2. `eb_store_integral_product_kaijiang_log`
  3. `eb_user_box`
  4. `eb_store_integral_product_huanqu_log`
  5. `eb_box_order`

删除后会执行 `ANALYZE TABLE`。

## 重要说明

删除大量 InnoDB 数据后，表文件通常不会立刻缩小，空间会变成表内可复用空间。真正释放磁盘空间需要后续 `OPTIMIZE TABLE` 或重建表，这一步风险更高，建议在业务稳定后单独做。

## 回滚

优先回滚方式：

1. 如果刚删除后马上发现问题，使用 `db_archive_robot_data_phase7.sh` 生成的单表归档 SQL 重新导入。
2. 如果问题范围不清，使用全库备份恢复到临时库，对比后再恢复目标数据。

归档文件使用 `INSERT IGNORE`，用于恢复到已有表时不会重建表结构。
