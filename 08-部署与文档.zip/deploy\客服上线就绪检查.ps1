﻿<#
客服上线就绪检查（只读）

作用：一条命令看清「AI 客服现在能不能开」，只读不写。
- 不读取密钥内容、不修改任何配置、不重启服务、不发起模型请求。

用法
  ./deploy/客服上线就绪检查.ps1

它检查 6 件事
  1. 本机正式 Key（DPAPI 凭据）是否还在
  2. 线上 .env 指纹（用于后续写入的前置比对）
  3. 线上客服开关当前生效值
  4. 5 张客服专用表是否存在
  5. 前台 current release 与客服 chunk 是否为新版
  6. 客服接口是否已注册并正确鉴权

真正写入正式配置请用仓库内已验证的官方脚本（默认 dry-run，-Apply 才写）：
  ./yunmall-hybrid/scripts/安全配置正式客服.ps1 -Apply -EnableAI -AllowedUid 1
#>
[CmdletBinding()]
param(
    [string]$SshHost = 'root@186.241.72.176',
    [int]$SshPort = 49375,
    [string]$IdentityPath = 'C:\Users\cai\.ssh\vivodraw_windows_ed25519',
    [string]$CredentialPath = "$env:LOCALAPPDATA\VivoDraw\客服凭据\正式模型密钥.dpapi",
    [string]$ExpectedEnvSha = '7b226765686916ab26c82b88a5a0686467c38ee98b13f67e5d937dfa9c06e4c3',
    [string]$ExpectedChunkSha = '92679abcdeb6670ad7d6b5334cee12bb7f181efeda33cd1e7008528474117b69'
)

$ErrorActionPreference = 'Stop'
$sshArgs = @('-i', $IdentityPath, '-p', "$SshPort", '-o', 'BatchMode=yes', '-o', 'IdentitiesOnly=yes', '-o', 'StrictHostKeyChecking=accept-new')
$result = [ordered]@{}
$problems = New-Object System.Collections.Generic.List[string]

Write-Host '=== 1) 本机正式 Key（DPAPI 凭据）==='
if (Test-Path -LiteralPath $CredentialPath -PathType Leaf) {
    $result.credential = 'present'
    Write-Host "  存在：$CredentialPath"
} else {
    $result.credential = 'missing'
    Write-Host "  缺失：$CredentialPath" -ForegroundColor Yellow
    $problems.Add('本机缺少正式 Key（DPAPI 凭据），无法开启 AI；代码与数据表本身已就绪')
}

if (-not (Test-Path -LiteralPath $IdentityPath)) { throw "SSH 身份文件不存在：$IdentityPath" }

Write-Host '=== 2) 线上 .env 指纹 ==='
$shaCmd = 'sha256sum /opt/crmeb-prod/backend_src/.env | awk ''{print $1}'''
$envSha = (& ssh @sshArgs $SshHost $shaCmd 2>&1 | Out-String).Trim()
if ($envSha -notmatch '^[0-9a-f]{64}$') { throw "无法读取线上 .env 指纹：$envSha" }
$result.env_sha256 = $envSha
if ($envSha -eq $ExpectedEnvSha) {
    Write-Host "  $envSha（与发布时一致，未被改动）"
} else {
    Write-Host "  $envSha（注意：与发布时 $ExpectedEnvSha 不同，可能被其他窗口修改）" -ForegroundColor Yellow
    $problems.Add('线上 .env 与发布基线不同：写入前必须重新采样指纹并人工确认')
}

Write-Host '=== 3) 线上客服开关当前生效值 ==='
$probeLocal = Join-Path $env:TEMP '客服-就绪探针.php'
$probeBody = @(
    '<?php',
    "require '/var/www/backend/vendor/autoload.php';",
    "require '/var/www/backend/vendor/topthink/framework/src/helper.php';",
    "`$app = new think\App('/var/www/backend');",
    "`$app->env->load('/var/www/backend/.env');",
    "`$c = require '/var/www/backend/config/support.php';",
    "echo 'state=' . `$c['enabled'] . '|' . `$c['ai_enabled'] . '|' . `$c['daily_calls'] . '|' . `$c['allowed_uids'] . '|' . ((`$c['api_key'] !== '') ? 'key_set' : 'key_missing') . PHP_EOL;",
    "`$e = parse_ini_file('/var/www/backend/.env', true);",
    "`$d = `$e['DATABASE'];",
    "`$p = mysqli_connect(`$d['HOSTNAME'], `$d['USERNAME'], `$d['PASSWORD'], `$d['DATABASE'], (int)`$d['HOSTPORT']);",
    "if (!`$p) { echo 'tables=DB_FAIL' . PHP_EOL; exit; }",
    "`$present = [];",
    "`$all = mysqli_query(`$p, 'SHOW TABLES');",
    "while (`$row = mysqli_fetch_array(`$all)) { `$present[`$row[0]] = true; }",
    "`$names = ['eb_support_conversation','eb_support_message','eb_support_alert','eb_support_image','eb_support_budget'];",
    "`$parts = [];",
    "foreach (`$names as `$n) {",
    "    `$has = isset(`$present[`$n]);",
    "    `$cnt = '-';",
    "    if (`$has) { `$q = mysqli_query(`$p, 'SELECT COUNT(*) AS c FROM ' . `$n); `$cnt = `$q ? mysqli_fetch_assoc(`$q)['c'] : '?'; }",
    "    `$parts[] = `$n . '=' . (`$has ? 'EXISTS' : 'ABSENT') . ':' . `$cnt;",
    "}",
    "echo 'tables=' . implode(',', `$parts) . PHP_EOL;",
    "echo 'table_count=' . count(`$present) . PHP_EOL;"
) -join "`n"
[System.IO.File]::WriteAllText($probeLocal, $probeBody, [System.Text.UTF8Encoding]::new($false))
& scp -i $IdentityPath -P $SshPort -o BatchMode=yes -o IdentitiesOnly=yes -o StrictHostKeyChecking=accept-new $probeLocal "${SshHost}:/opt/crmeb-prod/backend_src/.support-ready-probe.php" | Out-Null
$probeOut = (& ssh @sshArgs $SshHost 'docker exec crmeb-php-fpm php /var/www/backend/.support-ready-probe.php' 2>&1 | Out-String).Trim()
$null = & ssh @sshArgs $SshHost 'rm -f /opt/crmeb-prod/backend_src/.support-ready-probe.php' 2>&1
$state = (($probeOut -split "`n" | Where-Object { $_ -match '^state=' }) -replace '^state=', '').Trim()
$result.support_state = $state
Write-Host "  enabled|ai_enabled|daily_calls|allowed_uids|key = $state"
if ($state -eq '0|0|0||key_missing') {
    Write-Host '  → 当前为设计上的安全默认：接口在线但一律不调用模型、不写入客服记录' -ForegroundColor Cyan
} elseif ($state -match '^\d+\|\d+\|\d+\|.*\|key_set$') {
    Write-Host '  → 已开启（会消耗模型额度），确认这是你预期的状态' -ForegroundColor Yellow
}

Write-Host '=== 4) 5 张客服专用表 ==='
$tables = (($probeOut -split "`n" | Where-Object { $_ -match '^tables=' }) -replace '^tables=', '').Trim()
$result.tables = $tables
Write-Host ("  " + ($tables -replace ',', '  '))
$missing = ([regex]::Matches($tables, 'ABSENT')).Count
if ($missing -gt 0) { $problems.Add("有 $missing 张客服表不存在") }
# 会话/消息/告警/图片是用户数据，应为 0 行；budget 是当日额度计数行，有 1 行属正常。
$userDataDirty = @()
foreach ($name in @('eb_support_conversation', 'eb_support_message', 'eb_support_alert', 'eb_support_image')) {
    if ($tables -match [regex]::Escape($name) + '=EXISTS:(\d+)') {
        if ([int]$Matches[1] -ne 0) { $userDataDirty += "$name=$($Matches[1])" }
    }
}
if ($userDataDirty.Count -gt 0) {
    Write-Host "  → 注意：用户数据表非空（$($userDataDirty -join ', ')）" -ForegroundColor Yellow
} else {
    Write-Host '  → 用户数据表均为 0 行；budget 为当日额度计数行（1 行属正常）' -ForegroundColor Cyan
}

Write-Host '=== 5) 前台 release 与客服 chunk ==='
$chunkCmd = 'sha256sum /opt/crmeb-prod/frontend-root/current/_expo/static/js/web/service-*.js'
$chunk = (& ssh @sshArgs $SshHost $chunkCmd 2>&1 | Out-String).Trim()
$relCmd = 'readlink /opt/crmeb-prod/frontend-root/current'
$rel = (& ssh @sshArgs $SshHost $relCmd 2>&1 | Out-String).Trim()
$result.frontend_release = $rel
Write-Host "  current -> $rel"
Write-Host "  $chunk"
$chunkSha = ($chunk -split '\s+')[0]
if ($chunkSha -eq $ExpectedChunkSha) {
    Write-Host '  → 客服 chunk 为新版（含 AI 入口/双语/导航/记忆/图片）' -ForegroundColor Cyan
} else {
    Write-Host "  → 客服 chunk 不是预期新版（期望 $ExpectedChunkSha）" -ForegroundColor Yellow
    $problems.Add('前台客服 chunk 不是预期版本，用户可能看不到新版客服界面')
}

Write-Host '=== 6) 客服接口注册与鉴权 ==='
$user = (curl.exe -s -H 'X-Client: mobile-app' 'https://vivodraw.com/api/support/session' | Out-String).Trim()
$admin = (curl.exe -s 'https://vivodraw.com/adminapi/support/users' | Out-String).Trim()
try {
    $req = [System.Net.HttpWebRequest]::Create('https://vivodraw.com/')
    $req.Method = 'GET'
    $req.Timeout = 20000
    $req.AllowAutoRedirect = $true
    $resp = $req.GetResponse()
    $homeCode = [int]$resp.StatusCode
    $resp.Close()
} catch [System.Net.WebException] {
    $homeCode = 'ERR'
}
Write-Host "  首页 HTTP $homeCode"
Write-Host "  /api/support/session -> $user"
Write-Host "  /adminapi/support/users -> $admin"
if ($user -notmatch '410000') { $problems.Add('用户端客服接口未按预期要求登录，请检查路由与鉴权') }
if ($admin -notmatch 'login') { $problems.Add('后台客服接口未按预期要求登录，请检查路由与鉴权') }

Write-Host ''
Write-Host '=== 结论 ==='
if ($problems.Count -eq 0) {
    Write-Host '全部就绪。如尚未写入正式配置，运行：' -ForegroundColor Green
    Write-Host '  ./yunmall-hybrid/scripts/安全配置正式客服.ps1 -Apply -EnableAI -AllowedUid 1' -ForegroundColor Green
} else {
    Write-Host "发现 $($problems.Count) 项待处理：" -ForegroundColor Yellow
    $problems | ForEach-Object { Write-Host "  - $_" -ForegroundColor Yellow }
    Write-Host ''
    if ($result.credential -eq 'missing') {
        Write-Host '关键阻塞：本机正式 Key（DPAPI）不存在，因此无法开启 AI。' -ForegroundColor Yellow
        Write-Host '把正式 Key 安全存回本机（隐藏输入，不要发到聊天里）：' -ForegroundColor Yellow
        Write-Host '  ./yunmall-hybrid/scripts/安全保存正式客服密钥.ps1' -ForegroundColor Yellow
        Write-Host '存回后再运行：' -ForegroundColor Yellow
        Write-Host '  ./yunmall-hybrid/scripts/安全配置正式客服.ps1 -Apply -EnableAI -AllowedUid 1' -ForegroundColor Yellow
    }
}
$result | ConvertTo-Json -Compress
