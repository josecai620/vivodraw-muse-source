# Eccomall — Claude 项目指引

## 共享记忆（跨机器同步）

项目记忆统一存放在 `.claude/memory/`，已纳入 git，Mac 和 Windows 两台机器共用同一份。

**每次开始工作前必读**：[.claude/memory/MEMORY.md](.claude/memory/MEMORY.md)

### 写记忆的规则

在这个项目里新增或更新记忆时，**同时写两个地方**：

1. 本机用户级路径（Claude Code 自动管理的那个）
2. **`.claude/memory/`**（仓库内，这样另一台机器 git pull 后也能读到）

写完后执行 `git add .claude/memory/ && git commit -m "memory: 更新xxx"` 推到 GitHub `main`，保持两边同步。

---

## 项目基本信息

- **名称**：Eccomall 电商商城
- **目标市场**：美国，货币 USD
- **后端**：PHP 8.1 + ThinkPHP 6，Docker 部署
- **前端**：Expo React Native（H5 + App）
- **仓库**：https://github.com/josecai620/eccomall （分支 `main`；Gitee 旧仓仅历史）
- **生产服务器**：`root@186.241.72.176`，SSH 端口 `49375`

## 沟通约定

- 所有回复、思考过程、注释一律用**中文**
- joe 不懂英文，英文输出等于无效输出
