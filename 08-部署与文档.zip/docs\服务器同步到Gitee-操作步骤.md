# 把服务器上的系统同步到 Gitee

目标：**服务器（8.166.115.27）上的代码 → Gitee 仓库**，供 Windows 拉取开发。

仓库地址：`https://gitee.com/caiweizhou/eccomall`

---

## 方式一：一条命令完成（推荐）

在项目根目录执行：

```bash
cd /Users/joe/eccomall
bash deploy/从服务器同步到Gitee.sh 8.166.115.27
```

脚本会自动完成：
1. 从服务器拉取 backend_src、deploy、根目录文件
2. 提交变更
3. 推送到 Gitee

**若推送时报错**（如 Repository not found）：需先按下面「推送前的认证」处理。

---

## 方式二：分步执行

```bash
# 1. 进入项目目录
cd /Users/joe/eccomall

# 2. 从服务器拉取
bash deploy/从服务器同步到本地.sh 8.166.115.27

# 3. 提交
git add backend_src/ deploy/ admin.php docker-compose.yml fix_manghe_menus.sql run_fix_manghe_menus.sh
git commit -m "同步服务器最新代码"

# 4. 推送
git push origin assist/mobile-batch-01
```

---

## 推送前的认证（首次或报错时）

若 `git push` 报错，在终端执行：

```bash
git credential-osxkeychain erase
host=gitee.com
protocol=https
```
（第三行后多按一次回车）

再执行 `git push`，按提示输入：
- Username：Gitee 用户名
- Password：**私人令牌**（Gitee → 设置 → 私人令牌，生成时勾选 `projects` 权限）

---

## 说明

- **服务器有**：backend_src、deploy、admin.php 等
- **服务器无**：mobile-app 源码（只有构建后的 public/_expo），docs、.cursorrules 等
- 仓库中会同时保留：服务器代码 + mobile-app + 文档，供 Windows 完整开发
