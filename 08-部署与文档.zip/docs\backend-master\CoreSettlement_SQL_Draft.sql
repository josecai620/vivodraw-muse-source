-- CoreSettlement_SQL_Draft.sql
-- 草案，不执行。
-- Phase 10 status: legacy broad draft only.
-- 当前 PHP real-write writer 不写本文件里的 eb_core_settlement_record / eb_core_point_ledger。
-- 当前 writer 只写 eb_core_settlement_ledger，见 backend_src/deploy/sql/checkin_core_settlement_ledger.sql。
-- 禁止把本文件作为 Phase 10 执行计划直接运行。
-- 禁止在 CoreSettlement ledger 上使用 UPDATE / DELETE / TRUNCATE / DROP 修改或删除历史账本。
-- 目标：新增旁路规范层表，不替代 CRMEB 旧表，不接真实业务链路。
-- 物理表使用 eb_ 前缀，符合当前 CRMEB 表前缀习惯。

CREATE TABLE IF NOT EXISTS `eb_core_settlement_record` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `scene` VARCHAR(64) NOT NULL,
  `action` VARCHAR(64) NOT NULL,
  `biz_type` VARCHAR(64) NOT NULL DEFAULT '',
  `biz_id` VARCHAR(128) NOT NULL DEFAULT '',
  `request_id` VARCHAR(128) NOT NULL,
  `status` VARCHAR(24) NOT NULL DEFAULT 'pending',
  `result_json` JSON NULL,
  `error_msg` VARCHAR(500) NOT NULL DEFAULT '',
  `created_at` INT UNSIGNED NOT NULL,
  `updated_at` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_scene_request` (`scene`, `request_id`),
  KEY `idx_uid_scene` (`uid`, `scene`),
  KEY `idx_status_time` (`status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='CoreSettlement 旁路结算记录';

CREATE TABLE IF NOT EXISTS `eb_core_point_ledger` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL,
  `scene` VARCHAR(64) NOT NULL,
  `action` VARCHAR(64) NOT NULL,
  `biz_type` VARCHAR(64) NOT NULL DEFAULT '',
  `biz_id` VARCHAR(128) NOT NULL DEFAULT '',
  `request_id` VARCHAR(128) NOT NULL,
  `direction` TINYINT NOT NULL COMMENT '1=in,0=out',
  `amount` INT NOT NULL,
  `balance_before` INT NOT NULL DEFAULT 0,
  `balance_after` INT NOT NULL DEFAULT 0,
  `status` VARCHAR(24) NOT NULL DEFAULT 'success',
  `reason` VARCHAR(255) NOT NULL DEFAULT '',
  `meta_json` JSON NULL,
  `created_at` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_point_idem` (`scene`, `request_id`, `uid`, `action`),
  KEY `idx_uid_time` (`uid`, `created_at`),
  KEY `idx_biz` (`biz_type`, `biz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='积分旁路账本';

CREATE TABLE IF NOT EXISTS `eb_core_reward_record` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL,
  `reward_type` VARCHAR(64) NOT NULL,
  `reward_code` VARCHAR(128) NOT NULL DEFAULT '',
  `source_scene` VARCHAR(64) NOT NULL,
  `source_id` VARCHAR(128) NOT NULL DEFAULT '',
  `amount` INT NOT NULL DEFAULT 0,
  `item_id` VARCHAR(128) NOT NULL DEFAULT '',
  `rarity` VARCHAR(32) NOT NULL DEFAULT '',
  `status` VARCHAR(24) NOT NULL DEFAULT 'pending',
  `expire_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `claimed_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `meta_json` JSON NULL,
  `created_at` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uid_status` (`uid`, `status`),
  KEY `idx_source` (`source_scene`, `source_id`),
  KEY `idx_expire` (`status`, `expire_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='奖励记录';

CREATE TABLE IF NOT EXISTS `eb_core_reward_claim_lock` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL,
  `reward_id` BIGINT UNSIGNED NOT NULL,
  `claim_key` VARCHAR(128) NOT NULL,
  `status` VARCHAR(24) NOT NULL DEFAULT 'locked',
  `result_json` JSON NULL,
  `locked_at` INT UNSIGNED NOT NULL,
  `finished_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_claim` (`uid`, `reward_id`, `claim_key`),
  KEY `idx_reward_status` (`reward_id`, `status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='奖励幂等领取锁';

CREATE TABLE IF NOT EXISTS `eb_core_inventory_lock` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `sku_id` VARCHAR(128) NOT NULL DEFAULT '',
  `scene` VARCHAR(64) NOT NULL,
  `biz_id` VARCHAR(128) NOT NULL DEFAULT '',
  `request_id` VARCHAR(128) NOT NULL,
  `lock_qty` INT NOT NULL,
  `status` VARCHAR(24) NOT NULL DEFAULT 'locked',
  `expire_at` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` INT UNSIGNED NOT NULL,
  `released_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_inventory_lock` (`scene`, `request_id`, `sku_id`),
  KEY `idx_sku_status` (`sku_id`, `status`),
  KEY `idx_expire` (`status`, `expire_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='库存锁';

CREATE TABLE IF NOT EXISTS `eb_core_inventory_ledger` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `product_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `sku_id` VARCHAR(128) NOT NULL DEFAULT '',
  `scene` VARCHAR(64) NOT NULL,
  `biz_id` VARCHAR(128) NOT NULL DEFAULT '',
  `request_id` VARCHAR(128) NOT NULL,
  `delta` INT NOT NULL,
  `stock_before` INT NOT NULL DEFAULT 0,
  `stock_after` INT NOT NULL DEFAULT 0,
  `operator_type` VARCHAR(32) NOT NULL DEFAULT 'system',
  `status` VARCHAR(24) NOT NULL DEFAULT 'success',
  `meta_json` JSON NULL,
  `created_at` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sku_time` (`sku_id`, `created_at`),
  KEY `idx_scene_request` (`scene`, `request_id`),
  KEY `idx_biz` (`scene`, `biz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='库存流水';

CREATE TABLE IF NOT EXISTS `eb_core_payment_webhook_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `provider` VARCHAR(32) NOT NULL,
  `event_id` VARCHAR(128) NOT NULL,
  `payment_intent` VARCHAR(128) NOT NULL DEFAULT '',
  `order_no` VARCHAR(128) NOT NULL DEFAULT '',
  `signature_hash` VARCHAR(128) NOT NULL DEFAULT '',
  `verify_status` VARCHAR(24) NOT NULL DEFAULT 'pending',
  `process_status` VARCHAR(24) NOT NULL DEFAULT 'pending',
  `raw_json` JSON NULL,
  `error_msg` VARCHAR(500) NOT NULL DEFAULT '',
  `created_at` INT UNSIGNED NOT NULL,
  `processed_at` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_provider_event` (`provider`, `event_id`),
  KEY `idx_order_no` (`order_no`),
  KEY `idx_process_status` (`process_status`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='支付回调日志';

CREATE TABLE IF NOT EXISTS `eb_core_risk_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `scene` VARCHAR(64) NOT NULL,
  `action` VARCHAR(64) NOT NULL,
  `request_id` VARCHAR(128) NOT NULL DEFAULT '',
  `risk_code` VARCHAR(64) NOT NULL,
  `risk_level` VARCHAR(24) NOT NULL DEFAULT 'low',
  `decision` VARCHAR(24) NOT NULL DEFAULT 'allow',
  `reason` VARCHAR(255) NOT NULL DEFAULT '',
  `ip` VARCHAR(64) NOT NULL DEFAULT '',
  `user_agent` VARCHAR(255) NOT NULL DEFAULT '',
  `device_id` VARCHAR(128) NOT NULL DEFAULT '',
  `payload_hash` VARCHAR(128) NOT NULL DEFAULT '',
  `created_at` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uid_time` (`uid`, `created_at`),
  KEY `idx_scene_decision` (`scene`, `decision`),
  KEY `idx_request` (`scene`, `request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='风控日志';

CREATE TABLE IF NOT EXISTS `eb_core_analytics_event` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `uid` INT UNSIGNED NOT NULL DEFAULT 0,
  `session_id` VARCHAR(128) NOT NULL DEFAULT '',
  `scene` VARCHAR(64) NOT NULL,
  `event_name` VARCHAR(128) NOT NULL,
  `biz_id` VARCHAR(128) NOT NULL DEFAULT '',
  `device` VARCHAR(64) NOT NULL DEFAULT '',
  `source` VARCHAR(64) NOT NULL DEFAULT '',
  `payload_json` JSON NULL,
  `created_at` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_scene_event_time` (`scene`, `event_name`, `created_at`),
  KEY `idx_uid_time` (`uid`, `created_at`),
  KEY `idx_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='行为埋点事件';
