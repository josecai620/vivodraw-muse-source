# -*- coding: utf-8 -*-
import json, os, collections
L = r'D:\eccomall\mobile-app\lib\i18n\locales'
add = {'en.json': {"tabMarket": "Market", "tabMy": "My", "tabOffers": "Offers"},
       'zh-TW.json': {"tabMarket": "市集", "tabMy": "我的掛單", "tabOffers": "交換申請"}}
for f, kv in add.items():
    p = os.path.join(L, f)
    d = json.load(open(p, encoding='utf-8'), object_pairs_hook=collections.OrderedDict)
    for k, v in kv.items(): d['exchange'][k] = v
    json.dump(d, open(p, 'w', encoding='utf-8', newline='\n'), ensure_ascii=False, indent=2)
    open(p, 'a', encoding='utf-8', newline='\n').write('\n')
    json.load(open(p, encoding='utf-8'))
    print(f, 'ok')
