#!/usr/bin/env bash
# 将本机 backend_src（含 uniapp 双语源码）同步到服务器，不覆盖 public（H5 需在 HBuilderX 发行后单独上传）
# 用法: ./deploy/sync_frontend_to_server.sh [服务器IP]
# 示例: ./deploy/sync_frontend_to_server.sh 186.241.72.176
set -euo pipefail

SERVER_IP="${1:-186.241.72.176}"
SSH_USER="${2:-root}"
REMOTE_DIR="/opt/crmeb-prod"
LOCAL_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOCAL_SRC="${LOCAL_ROOT}/backend_src"

echo "==> 同步 backend_src 到 ${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/backend_src"
echo "    排除: node_modules, .git, public, *.log 等"
rsync -avz --progress \
  --exclude='node_modules' \
  --exclude='.git' \
  --exclude='public' \
  --exclude='*.log' \
  --exclude='.DS_Store' \
  --exclude='runtime/log' \
  --exclude='vendor/phpunit' \
  "${LOCAL_SRC}/" "${SSH_USER}@${SERVER_IP}:${REMOTE_DIR}/backend_src/"

echo "==> 完成"
echo "服务器已更新源码（含 uniapp 双语）。"
echo "H5 前端需在 HBuilderX 中发行一次后，将 unpackage/dist/build/h5 内容上传到服务器 public 目录才会生效，详见 deploy/前端H5发行说明.md"
