#!/usr/bin/env bash
# Cutover nginx: root -> V4 build, legacy V3 -> /v3/, /v4 -> redirect to root.
# Usage: bash nginx-switch-root-v4.sh /tmp/vivodraw-rootv4.conf
set -euo pipefail

NEW_CONF="${1:?path to new conf required}"
CONF=/etc/nginx/sites-enabled/vivodraw.com.conf
TS=$(date +%Y%m%d_%H%M%S)
BACKUP=/etc/nginx/vivodraw.com.conf.bak-$TS

test -f "$NEW_CONF" || { echo "FATAL: $NEW_CONF missing"; exit 1; }

# Resolve real file if sites-enabled is a symlink
REAL_CONF=$(readlink -f "$CONF")
cp -a "$REAL_CONF" "$BACKUP"
echo "backup: $BACKUP"

cp "$NEW_CONF" "$REAL_CONF"
nginx -t
systemctl reload nginx
echo "nginx reloaded at $TS"
echo "rollback: cp $BACKUP $REAL_CONF && nginx -t && systemctl reload nginx"
