-- Rollback for agent promo purchase requests.
-- Approval required before running in any shared or production database.
-- This removes purchase request records only; it does not reverse wallet credits.

DROP TABLE IF EXISTS `eb_agent_promo_purchase_request`;
