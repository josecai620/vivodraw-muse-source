# VivoDraw Entry And Agent Demo Audit - 2026-06-21

## Scope

Read-only operating audit for the autonomous platform ops goal.

Checked:

- Public storefront entry by IP and domain.
- Production Nginx virtual host state.
- `/agent-admin/` growth surface.
- Untracked `mobile-app-v3/public/agent-recruit-demo/` material.

Not changed:

- No production SQL.
- No DNS change.
- No Nginx/server config change.
- No payment, inventory, ledger, or wallet write.
- No deploy.

## Entry Status

### What Works

- `http://8.166.115.27/` returns storefront `200`.
- `http://8.166.115.27/api/category` with `X-Client: mobile-app` returns `status=200`.
- Production server local vhost test:
  - `Host: vivodraw.com` on local HTTP returns `301` to HTTPS.
  - Local HTTPS with SNI `vivodraw.com` returns `200`.
  - `/agent-admin/` route exists in live Nginx and returns static console.
- Production Nginx listens on `80`, `443`, and `20199`.

### What Blocks Growth

- External direct request with `Host: vivodraw.com` to `8.166.115.27:80` returns `403` with `Server: Beaver`.
- External TLS to `8.166.115.27:443` with SNI `vivodraw.com` fails before a certificate is returned.
- Production-side DNS check resolves:
  - `vivodraw.com -> 8.166.115.27`
  - `eccobuy.com -> deprecated server IP`
- Production-side `MX` / `TXT` checks for `vivodraw.com` returned no records.

## Operating Conclusion

The application and local Nginx vhost are alive. The public domain path is not safe for acquisition traffic yet. The evidence points to an external edge/domain/ICP/cloud-gateway block, not an Expo or PHP application outage.

Do not send paid ads, partner links, or recruitment traffic to `vivodraw.com` until external access is verified from a clean network. Advertising into a `403` page is performance art, not growth.

## Agent Recruit Demo Audit

Files found:

- `mobile-app-v3/public/agent-recruit-demo/index.html`
- `mobile-app-v3/public/agent-recruit-demo/styles.css`
- `mobile-app-v3/public/agent-recruit-demo/demo.js`

Content strengths:

- Correctly says `40% of platform net profit`.
- Correctly limits scope to first-level qualified orders.
- Correctly separates `Marketing Credits` from cash/stored value.
- Shows a calculator, agent-admin preview, and plain rule section.

Current risks:

- CTA is `mailto:agents@vivodraw.com`, but `vivodraw.com` has no visible `MX` records from production DNS checks. That can silently lose leads.
- Public domain is externally blocked, so any public demo link using `vivodraw.com` is not ready.
- `impeccable` scan found:
  - Low contrast green text around `4.0:1`, below WCAG AA body target.
  - Hero eyebrow chip pattern, a known AI/SaaS landing page tell.
  - Calculator area flagged for cramped padding.
- Current local worktree includes unrelated deletions in:
  - `backend_src/view/admin/src/api/agent.js`
  - `deploy/nginx/eccomall.conf`

Those deletions touch agent promo admin APIs and `/agent-admin/` Nginx route. Do not commit or deploy them blindly.

## Recommended Next Actions

1. Fix or confirm the external domain edge first.
   - Owner approval needed before DNS, ICP, cloud gateway, or Nginx production changes.
   - Read-only proof to collect next: test from a US VPS or third-party checker, plus cloud provider domain/备案/WAF status.
2. Keep `8.166.115.27` as the internal verification baseline while public domain is blocked.
3. Do not use `mailto:agents@vivodraw.com` as the only lead capture path until mail records are configured and tested.
4. Convert the agent demo from untracked asset to a reviewed growth artifact only after:
   - domain entry works,
   - lead capture works,
   - contrast and AI-template issues are polished,
   - the dirty agent-admin deletions are resolved.
5. For the first public recruitment asset, use:
   - landing page CTA: application form or working email,
   - short video CTA: same landing path,
   - copy: `Bring first-level buyers. Earn 40% of platform net profit from qualified orders.`

## Verification Commands Used

```bash
curl --noproxy '*' -I -H 'Host: vivodraw.com' http://8.166.115.27/
curl --noproxy '*' -I --connect-to vivodraw.com:443:8.166.115.27:443 https://vivodraw.com/
ssh root@8.166.115.27 "curl -I -H 'Host: vivodraw.com' http://127.0.0.1/"
ssh root@8.166.115.27 "curl -k -I --resolve vivodraw.com:443:127.0.0.1 https://vivodraw.com/"
ssh root@8.166.115.27 "nginx -T 2>/dev/null | grep -nE 'server_name|listen 443|ssl_certificate|agent-admin|vivodraw|eccobuy'"
npx impeccable --json mobile-app-v3/public/agent-recruit-demo/index.html
```
