# -*- coding: utf-8 -*-
import os
import subprocess

key = os.path.expanduser(r"~\.ssh\vivodraw_windows_ed25519")
host = "root@186.241.72.176"
ssh = [
    "ssh", "-i", key, "-p", "49375",
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
    "-o", "ServerAliveInterval=15",
    host,
]
scp = [
    "scp", "-O", "-i", key, "-P", "49375",
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
]
root = r"D:\eccomall"
files = [
    "backend_src/app/services/yunmall/PointsTaskService.php",
    "backend_src/app/services/yunmall/LuckyValueService.php",
    "backend_src/app/services/user/UserSignServices.php",
    "backend_src/app/controller/api/v1/user/UserSignController.php",
    "backend_src/app/controller/api/v1/manghe/MangheController.php",
    "backend_src/route/api.php",
    "backend_src/app/services/core/PointRewardBalanceService.php",
]
staging = r"D:\eccomall\deploy\_t26-php-lf"
for rel in files:
    src = os.path.join(root, rel.replace("/", os.sep))
    dest = os.path.join(staging, rel.replace("/", os.sep))
    if not os.path.isfile(src):
        raise SystemExit("missing " + src)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    open(dest, "wb").write(open(src, "rb").read().replace(b"\r\n", b"\n"))
for rel in files:
    local = os.path.join(staging, rel.replace("/", os.sep))
    dest = "%s:/opt/crmeb-prod/%s" % (host, rel)
    print("scp", rel, flush=True)
    rc = subprocess.call(scp + [local, dest])
    if rc != 0:
        raise SystemExit("scp failed " + rel)
print("UPLOAD_OK", flush=True)
lint = [
    "/var/www/backend/app/services/yunmall/PointsTaskService.php",
    "/var/www/backend/app/services/yunmall/LuckyValueService.php",
    "/var/www/backend/app/services/user/UserSignServices.php",
    "/var/www/backend/app/controller/api/v1/user/UserSignController.php",
    "/var/www/backend/app/controller/api/v1/manghe/MangheController.php",
    "/var/www/backend/route/api.php",
    "/var/www/backend/app/services/core/PointRewardBalanceService.php",
]
check = " && ".join("docker exec crmeb-php-fpm php -l " + p for p in lint)
check += (
    " && grep -n 'points_task_claim\\|claim_sign_prize\\|checkin_task_event' /opt/crmeb-prod/backend_src/route/api.php"
    " && rm -f /opt/crmeb-prod/backend_src/runtime/route_list.php"
    " && docker exec crmeb-php-fpm sh -c 'cd /var/www/backend && php think clear' || true"
    " && docker restart crmeb-php-fpm && echo RESTART_OK"
)
print(subprocess.check_output(ssh + [check], timeout=180).decode(errors="replace"), flush=True)
