# 运行基线与发布边界

本文档记录当前测试开发服务器的真实运行基线。后续正式服务器迁移，以这套基线为准，不以服务器 `.git status` 的历史噪声为准。

## 当前服务器

- 测试服务器：`8.166.115.27`
- 项目目录：`/opt/crmeb-prod`
- 后端运行目录：`/opt/crmeb-prod/backend_src`
- PHP-FPM 容器挂载：`/opt/crmeb-prod/backend_src -> /var/www/backend`
- 前台静态入口：`/opt/crmeb-prod/backend_src/public/index.html`
- 前台静态包：`/opt/crmeb-prod/backend_src/public/_expo` 和 `/opt/crmeb-prod/backend_src/public/assets`
- 移动端源码副本：`/opt/crmeb-prod/mobile-app`
- 前台备份目录：`/opt/crmeb-prod/deploy_backups`

## 运行版本

- 宿主机 PHP：`8.1.2`
- PHP-FPM 容器 PHP：`8.1.34`
- ThinkPHP 实际版本：`6.0.9`
- Composer 框架依赖：`topthink/framework: 6.0.9`
- 主要容器：`crmeb-nginx`、`crmeb-php-fpm`
- 宿主机服务：`mysql.service`、`redis-server.service`

结论：当前不是 ThinkPHP 8.1 项目，而是 PHP 8.1 运行环境上的 ThinkPHP 6.0.9 项目。后续代码修改必须按 ThinkPHP 6 兼容方式处理。

## 源码边界

这些目录视为源码，应以本地仓库和 Gitee 为准，并同步到测试服务器：

- `backend_src/app`
- `backend_src/config`
- `backend_src/crmeb`
- `backend_src/route`
- `backend_src/view/admin/src`
- `mobile-app`
- `deploy`
- 根部署入口：`deploy.sh`、`deploy-frontend.sh`

这些目录是服务器私有或运行态文件，不应从本地覆盖：

- `backend_src/.env`
- `backend_src/runtime`
- `backend_src/public/uploads`
- `backend_src/public/install/install.lock`
- `deploy/.env`
- `deploy/.deploy.env`
- `db_backup`
- `deploy_backups`
- `mysql_data`
- `redis_data`

这些目录是构建产物，不作为业务源码判断依据：

- `backend_src/public/index.html`
- `backend_src/public/_expo`
- `backend_src/public/assets`
- `backend_src/public/admin-v2`
- `mobile-app/dist`
- `backend_src/view/admin/dist`

## 发布规则

后端/API/后台路由发布：

```bash
bash deploy/update_online.sh 8.166.115.27
```

前台 Expo Web 发布：

```bash
bash deploy-frontend.sh 8.166.115.27
```

前台发布只从 `mobile-app/dist` 上传静态包到服务器，不再复制到本地 `backend_src/public`，避免本地 Git 工作区被构建产物污染。

每次前台发布成功后，脚本会同步 `mobile-app` 源码到服务器 `/opt/crmeb-prod/mobile-app`，排除：

- `node_modules`
- `dist`
- `.expo`
- `.env`

## 固定验活

统一使用：

```bash
bash deploy/verify_online.sh 8.166.115.27
```

验活内容：

- 前台首页返回 `HTTP 200`
- 前台入口 JS 文件存在
- 移动端 API `/api/category` 返回 `HTTP 200`
- 旧中国市场入口 `/api/wechat/config` 返回 `410` 或 `404`
- 后台接口未登录时被登录保护拦住
- Web/PHP 容器可见：`crmeb-nginx`、`crmeb-php-fpm`
- Redis 允许两种运行形态：`crmeb-redis` 容器，或宿主机 `redis-server.service`
- MySQL 当前以宿主机 `mysql.service` 运行，不依赖 `crmeb-mysql` 容器

## 正式服迁移原则

- 以本地仓库/Gitee 的源码为迁移源。
- 以测试服务器当前运行路径和容器结构为正式服模板。
- 不直接复制测试服务器 `.git` 的脏工作区状态。
- 迁移时单独处理 `.env`、数据库、上传文件、备份文件。
- 上线前必须关闭或隔离开发 mock 数据。
