# Single-Level Commission - 2026-06-16

## Decision

VivoDraw keeps only first-level affiliate commission. Second-level commission is disabled.

## Code Guardrails

- New order commission calculation forces `two_brokerage = 0`.
- New orders force `spread_two_uid = 0`.
- Confirm/take-order commission release no longer falls through to second-level commission.
- Agent level second-level uplift is ignored and hidden from the admin form.
- Distribution settings form hides two-level commission settings and direct config saves force `brokerage_level = 1`, `store_brokerage_two = 0`.

## Production Config

Current production before this change was:

- `brokerage_level = "2"`
- `store_brokerage_ratio = "10"`
- `store_brokerage_two = "5"`

Apply:

```bash
mysql manghehoutai_qhe < deploy/disable_second_level_commission_20260616.sql
```

Then clear runtime cache and restart PHP-FPM:

```bash
cd /opt/crmeb-prod/backend_src
docker exec crmeb-php-fpm php think clear:cache
docker exec crmeb-php-fpm php think clear
docker restart crmeb-php-fpm
```

Rollback requires separate approval and uses:

```bash
mysql manghehoutai_qhe < deploy/rollback_second_level_commission_20260616_approval_required.sql
```
