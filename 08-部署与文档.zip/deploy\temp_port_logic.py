# -*- coding: utf-8 -*-
import io, os

SRC3 = r'D:\eccomall\mobile-app-v3'
DST = r'D:\eccomall\mobile-app\lib\game'
os.makedirs(DST, exist_ok=True)

jobs = [
    (r'features\积分购买\请求锁.ts', 'accountRequestLock.ts'),
    (r'features\游戏补给\补币恢复.ts', 'gameWalletRecovery.ts'),
    (r'features\积分购买\购买恢复.ts', 'pointPurchaseRecovery.ts'),
    (r'features\积分购买\充值恢复.ts', 'rechargeRecovery.ts'),
    (r'features\积分购买\登录返回.ts', 'purchaseReturn.ts'),
]

repls = [
    ('@/lib/api/游戏补币', '@/lib/api/gameWallet'),
    ('@/lib/api/积分购买', '@/lib/api/pointPurchase'),
    ('@/lib/api/http', '@/lib/api/legacyHttp'),
    ('@/features/积分购买/请求锁', '@/lib/game/accountRequestLock'),
    ('./请求锁', './accountRequestLock'),
    ('./购买恢复', './pointPurchaseRecovery'),
    ('@/lib/api/account', '@/lib/api/walletRecharge'),
    # 中文 localStorage key 换成 ascii，避免任何编码隐患
    ('vivodraw:游戏补给:待确认:v2:', 'vivodraw:game-wallet:pending:v2:'),
    ('vivodraw:积分购买:待确认:v1:', 'vivodraw:point-purchase:pending:v1:'),
    ('vivodraw:充值:待确认:v1:', 'vivodraw:recharge:pending:v1:'),
    ('vivodraw:充值:返回:v1:', 'vivodraw:recharge:return:v1:'),
    ('vivodraw:充值:无效金额:v1:', 'vivodraw:recharge:invalid:v1:'),
]

for rel, dname in jobs:
    s = io.open(os.path.join(SRC3, rel), encoding='utf-8').read()
    for a, b in repls:
        s = s.replace(a, b)
    io.open(os.path.join(DST, dname), 'w', encoding='utf-8', newline='\n').write(s)
    print('ported', dname, len(s))
