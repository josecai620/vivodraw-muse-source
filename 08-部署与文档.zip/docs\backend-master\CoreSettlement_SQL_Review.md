# CoreSettlement SQL Review

## 结论

`CoreSettlement_SQL_Draft.sql` 只作为 SQL 草案，不执行。建议新表全部作为旁路规范层，不替代 CRMEB 旧表，不接线上真实业务。

## 覆盖表

草案包含 9 张新表：

- `eb_core_settlement_record`
- `eb_core_point_ledger`
- `eb_core_reward_record`
- `eb_core_reward_claim_lock`
- `eb_core_inventory_lock`
- `eb_core_inventory_ledger`
- `eb_core_payment_webhook_log`
- `eb_core_risk_log`
- `eb_core_analytics_event`

## 旧表保留

继续保留并尊重现有 CRMEB 表：

- `eb_user`
- `eb_user_bill`
- `eb_store_order`
- `eb_store_product`
- `eb_store_product_attr_value`
- `eb_store_integral_product*`
- `eb_store_integral_order*`
- `eb_box_order`
- `eb_user_box`
- `eb_group_lottery*`
- `game_farm_*`
- `game_mine_*`

## 审查项

### 表名前缀

通过。草案使用 `eb_core_*`，符合当前 CRMEB `eb_` 表前缀习惯。

### 引擎与字符集

通过。全部使用 `ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`。

### JSON 字段

通过。当前服务器审计记录为 MySQL 8，支持 JSON 字段。若未来兼容 MySQL 5.7 以下，需要改为 `LONGTEXT` 并由应用层校验 JSON。

### 幂等唯一键

通过但后续需按业务复核：

- `eb_core_settlement_record.uk_scene_request`
- `eb_core_point_ledger.uk_point_idem`
- `eb_core_reward_claim_lock.uk_claim`
- `eb_core_inventory_lock.uk_inventory_lock`
- `eb_core_payment_webhook_log.uk_provider_event`

### 查询索引

通过初版：

- 按用户与时间查账本：`idx_uid_time`
- 按业务对象追踪：`idx_biz`
- 按状态补偿：`idx_status_time`、`idx_process_status`
- 按库存锁状态释放：`idx_sku_status`、`idx_expire`

### 风险

- SQL 草案未执行，未验证真实 DB 字段长度与索引名冲突。
- JSON 字段会增加后续导出/兼容要求。
- 账本表不应直接替代 `eb_user_bill`，第一批只能旁路记录或 dry-run。
- 支付 webhook 表不代表支付已接入，第一批禁止接真实支付。

## 禁止接入清单

第一批禁止接：

- `MangheController`
- 支付回调
- 普通商城订单
- 积分开奖
- 拼团退款/开奖
- 真实库存扣减
- `game/` 当前活跃代码

## Phase 6 结论

工作流搭建阶段完成。下一阶段若继续，只能进入业务接入前评审：

1. 选一个低风险试点。
2. 明确是否需要执行 migration。
3. 执行前必须备份 DB。
4. 先在本地或测试环境验证。
5. 线上接入必须单独开 Phase，不和当前工作流搭建混做。
