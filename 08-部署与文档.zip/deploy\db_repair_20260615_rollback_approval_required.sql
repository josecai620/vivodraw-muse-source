-- Rollback helper for deploy/db_repair_20260615_approval_required.sql.
--
-- APPROVAL REQUIRED.
-- Do not run unless the matching repair script causes an operational issue.
-- Warning: dropping kami_account/kami_pass can lose newly-entered card-code data.

SET @schema_name = DATABASE();

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_user_box` DROP INDEX `idx_user_box_uid_product_status_id`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_user_box_uid_product_status_id missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_user_box' AND index_name = 'idx_user_box_uid_product_status_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_user_box` DROP INDEX `idx_user_box_uid_cate_status_product`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_user_box_uid_cate_status_product missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_user_box' AND index_name = 'idx_user_box_uid_cate_status_product'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_user_box` DROP INDEX `idx_user_box_huanqu_id`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_user_box_huanqu_id missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_user_box' AND index_name = 'idx_user_box_huanqu_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_box_order` DROP INDEX `idx_box_order_uid_id`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_box_order_uid_id missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_box_order' AND index_name = 'idx_box_order_uid_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_box_order` DROP INDEX `idx_box_order_order_sn`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_box_order_order_sn missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_box_order' AND index_name = 'idx_box_order_order_sn'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_box_order` DROP INDEX `idx_box_order_pay_status_id`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_box_order_pay_status_id missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_box_order' AND index_name = 'idx_box_order_pay_status_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_store_integral_product_huanqu_log_unique` DROP INDEX `idx_hq_unique_draw_lookup`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_hq_unique_draw_lookup missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_integral_product_huanqu_log_unique' AND index_name = 'idx_hq_unique_draw_lookup'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_store_integral_product_huanqu_log_unique` DROP INDEX `idx_hq_unique_huanqu_isset`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_hq_unique_huanqu_isset missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_integral_product_huanqu_log_unique' AND index_name = 'idx_hq_unique_huanqu_isset'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_store_integral_product_huanqu_log` DROP INDEX `idx_hq_log_product_bianhao_id`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_hq_log_product_bianhao_id missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_integral_product_huanqu_log' AND index_name = 'idx_hq_log_product_bianhao_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_store_integral_product_huanqu_log` DROP INDEX `idx_hq_log_uid_boxcate_id`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_hq_log_uid_boxcate_id missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_integral_product_huanqu_log' AND index_name = 'idx_hq_log_uid_boxcate_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_store_product_kaijiang_log` DROP INDEX `idx_kaijiang_product_bianhao`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_kaijiang_product_bianhao missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_product_kaijiang_log' AND index_name = 'idx_kaijiang_product_bianhao'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 1,
    'ALTER TABLE `eb_store_product_kaijiang_log` DROP INDEX `idx_kaijiang_status_time_id`, ALGORITHM=INPLACE, LOCK=NONE',
    'SELECT ''skip: idx_kaijiang_status_time_id missing''')
  FROM information_schema.statistics
  WHERE table_schema = @schema_name AND table_name = 'eb_store_product_kaijiang_log' AND index_name = 'idx_kaijiang_status_time_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
