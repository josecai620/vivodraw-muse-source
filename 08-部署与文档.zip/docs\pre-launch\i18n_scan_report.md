# i18n 硬编码中文扫描报告

**扫描时间**：2026-04-20
**扫描范围**：`backend_src/app/` + `backend_src/crmeb/` + `backend_src/config/`
**结论**：**4600+ 个硬编码中文字符串跨 500+ 文件**，是上线前最大的阻断项。不可能一次全改，必须分级处理。

---

## 规模盘点

| 类型 | 出现次数 | 受影响文件 | 风险级别 |
|-----|---------|-----------|---------|
| `$this->fail('...中文...')` | 1863 | 198 | 🔴 用户可见 |
| `throw new XxxException('...中文...')` | 1698 | 204 | 🔴 用户可见（冒泡成错误返回） |
| `$this->success('...中文...')` | 501 | 147 | 🟠 用户可见 |
| Validate 规则里的中文（app/validate/） | 477 | 32 | 🟠 管理员 + C 端填错时见 |
| `['msg' => '中文']` 数组返回 | 63 | 16 | 🟠 用户可见 |
| `config/pay.php`、`config/app.php` 中文字面量 | 3 | 2 | 🟡 内部 |
| **合计估算** | **≈ 4600** | **≈ 500** | |

还没包括的：
- 前端 Vue2 后台的硬编码中文（量级类似）
- Expo RN 前台的硬编码中文
- DB 种子数据（`eb_system_config.main_business` 等已在 API Key 审计里列了）
- 邮件模板、短信模板

---

## 为什么一次改不完

平均一个文件 9 处，500 个文件 → 要跑约 **500 次人工审阅** 确认每条消息的语义才能正确翻译（很多消息是模糊的，如"操作失败"、"数据不存在"，需要上下文判断该映射到哪个英文 key）。按 3 min/条算 = **230 小时**纯翻译工作，没算测试。

---

## 分级策略

### Level 1：**上线前必清**（C 端 user-facing，估 1-2 周）

用户第一次访问就会看见的路径：
- `app/controller/api/v1/LoginController.php`（41 处 fail + 12 处 success）
- `app/controller/api/v1/order/StoreOrderController.php`（80 处 fail）
- `app/controller/api/v1/user/UserController.php`（15 处 fail）
- `app/controller/api/v1/integral/OrderController.php`（16 处 fail + 26 throw）
- `app/controller/api/v1/activity/*.php`（拼团/抽奖/秒杀相关）
- `app/controller/api/v1/PublicController.php`（图形验证码、配置、版权）
- `app/controller/api/v1/manghe/MangheController.php`（盲盒，96 处 fail）
- `app/controller/api/pc/OrderController.php`（PC 端订单）
- `app/services/user/LoginServices.php`（33 处 throw）
- `app/services/order/StoreOrderServices.php`（22 处 throw）
- `app/services/pay/*.php`（支付错误消息）
- `app/http/middleware/api/BlockLegacyClientMiddleware.php`（"客户端已升级，请使用最新版本"）

**Level 1 估算**：约 **600 条消息**，15-20 个文件。

### Level 2：**上线后第一次迭代**（admin 后台，估 2-3 周）

管理员后台返回的消息，上线初期管理员都是中文使用者可以接受短期不翻译；但 US 管理员接手时必须改：
- `app/controller/admin/v1/**/*.php`（最大头）
- `app/validate/admin/**/*.php`（最大头，112 条在 SystemConfigValidata 一个文件里）

### Level 3：**持续**

- Service 层的 `throw new Exception('中文')` —— 这些是兜底错误，用户偶然才看到，但仍要清
- Listener / Job / Queue —— 只在日志里，内部看

---

## 实施方案

### 方案 A（推荐）：Lang Key 驱动

现在 `crmeb\utils\Json::make` 里已经会调 `Lang::get($res['msg'])`，所以**框架层已支持**。问题是当前消息都是中文字面量，Lang 按原样返回。改造方式：

1. 建立语言包文件结构：
   ```
   backend_src/app/lang/en-us/
     api.php        # C 端消息
     order.php      # 订单相关
     product.php
     user.php
     admin.php      # 后台消息
     validate.php   # 校验规则
   backend_src/app/lang/zh-cn/   # 对照版，原值不变，做 fallback
   ```

2. 消息 key 用语义化命名（示例）：
   ```php
   // app/lang/en-us/order.php
   return [
     'missing_address' => 'Please set a shipping address before checkout',
     'product_not_found' => 'Product does not exist',
     'stock_not_enough' => 'Insufficient stock for {product}',
     'payment_failed' => 'Payment failed: {reason}',
   ];
   // app/lang/zh-cn/order.php
   return [
     'missing_address' => '请先设置收货地址再下单',
     'product_not_found' => '商品不存在',
     ...
   ];
   ```

3. 代码里用 key：
   ```php
   return $this->fail('order.missing_address');
   // 或带参数：
   throw new ValidateException(Lang::get('order.stock_not_enough', ['product' => $name]));
   ```

4. 前端通过 `?lang=en-us` 或 cookie 触发（现 Json::make 已处理 cookie 读取）。

### 方案 B（不推荐）：脚本批量替换

跑一个翻译脚本把中文字面量 → 英文字面量直接硬编码。快但永远没办法支持双语。

---

## 优先起手点

joe 决策之前我做不下去。给你一个**立刻可开始的最小切片**（如果你点头）：

- [ ] 先做 `LoginController.php`（41 fail + 12 success = 53 条消息），把 `app/lang/en-us/auth.php` 和 `app/lang/zh-cn/auth.php` 立起来
- [ ] 搭一个 `app/lang/` 目录 + 标明 convention + 写一个 `README.md` 说 key 命名规范
- [ ] 后续每做一个 controller 就单独提交一次，便于逐个 review

**如果你愿意**，我下一步就直接搭骨架 + 做 LoginController 一个文件的完整示范，其余文件你让我继续就继续。

---

## 附：扫描命令（可重复跑）

```bash
cd backend_src

# fail() 带中文
rg -c -P "->fail\('[^']*[\x{4e00}-\x{9fa5}]+[^']*'" app crmeb

# throw new Xxx 带中文
rg -c -P "throw new [\w\\\\]+\('[^']*[\x{4e00}-\x{9fa5}]" app crmeb

# 数组返回带中文 msg
rg -c -P "'msg' *=> *'[^']*[\x{4e00}-\x{9fa5}]+[^']*'" app crmeb

# 总 Chinese char count in validate/
rg -c -P '[\x{4e00}-\x{9fa5}]' app/validate
```
