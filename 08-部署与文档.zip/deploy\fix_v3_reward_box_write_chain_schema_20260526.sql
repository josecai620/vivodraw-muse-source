-- v3 reward / box sandbox write-chain schema compatibility patch.
-- Applied on test server during QA on 2026-05-26.
-- Safe to rerun: every column add is guarded by INFORMATION_SCHEMA.

SET @schema_name = DATABASE();

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_user` ADD COLUMN `lucky_num` decimal(12,2) NOT NULL DEFAULT ''0.00'' COMMENT ''Lucky value'' AFTER `integral`',
    'SELECT ''eb_user.lucky_num exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_user' AND COLUMN_NAME = 'lucky_num'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `bianhao` int NOT NULL DEFAULT 1 COMMENT ''Current period'' AFTER `lucky_num`',
    'SELECT ''eb_store_product.bianhao exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'bianhao'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `exchange_num` int NOT NULL DEFAULT 0 COMMENT ''Current period exchange count'' AFTER `bianhao`',
    'SELECT ''eb_store_product.exchange_num exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'exchange_num'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `jindu_bili` decimal(10,2) NOT NULL DEFAULT ''0.00'' COMMENT ''Current period progress percent'' AFTER `exchange_num`',
    'SELECT ''eb_store_product.jindu_bili exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'jindu_bili'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `min_duihuan_num` int NOT NULL DEFAULT 0 COMMENT ''Minimum exchange count for draw'' AFTER `jindu_bili`',
    'SELECT ''eb_store_product.min_duihuan_num exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'min_duihuan_num'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `is_kami` tinyint(1) NOT NULL DEFAULT 0 COMMENT ''Card-code product flag'' AFTER `min_duihuan_num`',
    'SELECT ''eb_store_product.is_kami exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'is_kami'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `xiaci_jiqiren_time` int NOT NULL DEFAULT 0 COMMENT ''Next robot time'' AFTER `is_kami`',
    'SELECT ''eb_store_product.xiaci_jiqiren_time exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'xiaci_jiqiren_time'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `is_recovery` tinyint(1) NOT NULL DEFAULT 0 COMMENT ''Recovery enabled'' AFTER `xiaci_jiqiren_time`',
    'SELECT ''eb_store_product.is_recovery exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'is_recovery'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `recovery_price` decimal(12,2) NOT NULL DEFAULT ''0.00'' COMMENT ''Recovery price'' AFTER `is_recovery`',
    'SELECT ''eb_store_product.recovery_price exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'recovery_price'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `reference_price` decimal(12,2) NOT NULL DEFAULT ''0.00'' COMMENT ''Reference price'' AFTER `recovery_price`',
    'SELECT ''eb_store_product.reference_price exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'reference_price'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_product` ADD COLUMN `recovery_discount` decimal(10,2) NOT NULL DEFAULT ''100.00'' COMMENT ''Recovery discount'' AFTER `reference_price`',
    'SELECT ''eb_store_product.recovery_discount exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_product' AND COLUMN_NAME = 'recovery_discount'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log` ADD COLUMN `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT ''Draw status'' AFTER `setuid`',
    'SELECT ''eb_store_integral_product_huanqu_log.status exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_integral_product_huanqu_log' AND COLUMN_NAME = 'status'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log` ADD COLUMN `is_jiqiren` tinyint(1) NOT NULL DEFAULT 0 COMMENT ''Robot flag'' AFTER `status`',
    'SELECT ''eb_store_integral_product_huanqu_log.is_jiqiren exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_integral_product_huanqu_log' AND COLUMN_NAME = 'is_jiqiren'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log` ADD COLUMN `client_request_id` varchar(64) DEFAULT NULL COMMENT ''Client idempotency key'' AFTER `is_jiqiren`',
    'SELECT ''eb_store_integral_product_huanqu_log.client_request_id exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_integral_product_huanqu_log' AND COLUMN_NAME = 'client_request_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log` ADD UNIQUE KEY `uniq_uid_client_request_id` (`uid`, `client_request_id`)',
    'SELECT ''eb_store_integral_product_huanqu_log.uniq_uid_client_request_id exists''')
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_integral_product_huanqu_log' AND INDEX_NAME = 'uniq_uid_client_request_id'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log_unique` ADD COLUMN `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT ''Draw status'' AFTER `isset`',
    'SELECT ''eb_store_integral_product_huanqu_log_unique.status exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_integral_product_huanqu_log_unique' AND COLUMN_NAME = 'status'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_huanqu_log_unique` ADD COLUMN `is_jiqiren` tinyint(1) NOT NULL DEFAULT 0 COMMENT ''Robot flag'' AFTER `status`',
    'SELECT ''eb_store_integral_product_huanqu_log_unique.is_jiqiren exists''')
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = @schema_name AND TABLE_NAME = 'eb_store_integral_product_huanqu_log_unique' AND COLUMN_NAME = 'is_jiqiren'
);
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

UPDATE `eb_store_product`
SET `ot_price` = `price`
WHERE `cate_id` IN (310, 311, 312)
  AND (COALESCE(`mall_type`, 0) & 6) = 6
  AND (`ot_price` IS NULL OR `ot_price` <= 0);
