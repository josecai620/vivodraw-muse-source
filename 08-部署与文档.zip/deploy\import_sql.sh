#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/opt/crmeb-prod}"
DEPLOY_DIR="${PROJECT_DIR}/deploy"
ENV_FILE="${DEPLOY_DIR}/.deploy.env"
SQL_FILE="${PROJECT_DIR}/sql_www_sawa_com_20250629_010659.sql.gz"

if [[ ! -f "${ENV_FILE}" ]]; then
  echo "未找到 ${ENV_FILE}"
  exit 1
fi

if [[ ! -f "${SQL_FILE}" ]]; then
  echo "未找到 ${SQL_FILE}"
  exit 1
fi

# shellcheck disable=SC1090
source "${ENV_FILE}"

echo "开始导入 SQL 到 ${MYSQL_DATABASE} ..."
gzip -dc "${SQL_FILE}" | docker exec -i crmeb-mysql mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" "${MYSQL_DATABASE}"
echo "导入完成"
