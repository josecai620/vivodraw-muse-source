# Agent Growth Surface Restore Plan - 2026-06-21

## Scope

Safe review package for restoring the current agent growth surface blocker.

This document does not apply the change. It preserves a reviewable patch because the current worktree changes were not made in this window and should not be silently reverted.

## Current Blocker

Command:

```bash
bash deploy/ops/check_agent_growth_surface.sh
```

Current result:

```text
Summary: 10 failure(s)
```

Observed missing surface:

- `/agent-admin` redirect.
- `/agent-admin/` standalone Nginx route.
- `/agent-admin/index.html` fallback.
- Agent-admin frame protection and CSP.
- `agentPromoSummaryApi`.
- `agentPromoWalletsApi`.
- `agentPromoLedgerApi`.
- `agentPromoCreditApi`.
- `agentPromoStatusApi`.

## Restore Patch

Patch file:

```text
docs/ops/agent-growth-surface-restore-20260621.patch
```

Dry-run validation:

```bash
git apply --check docs/ops/agent-growth-surface-restore-20260621.patch
```

Apply only after owner approval or after confirming the dirty deletions were accidental:

```bash
git apply docs/ops/agent-growth-surface-restore-20260621.patch
bash deploy/ops/check_agent_growth_surface.sh
```

Expected local guard result after applying:

```text
Summary: 0 failure(s)
```

## Risk

Applying this patch changes two currently dirty files:

- `backend_src/view/admin/src/api/agent.js`
- `deploy/nginx/eccomall.conf`

It restores previously committed agent promo API helpers and the standalone `/agent-admin/` Nginx route. It does not execute SQL, deploy, reload Nginx, or modify production.

## Recommendation

Apply the patch if first-level agents, promo budget, and `/agent-admin/` remain part of the growth plan.

Do not apply it if the owner intentionally retired agent promo/admin functionality. In that case, rewrite the growth playbook, prototype, and guard scripts instead. Quietly deleting the front door while recruiting agents remains a bold but unserious business strategy.
