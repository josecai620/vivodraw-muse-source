#!/usr/bin/env bash
# V4 root cutover — atomic release for the ROOT site (www.vivodraw.com /).
# Usage on server: bash remote-release-root.sh <YYYYMMDD_HHMMSS> <explicit-auth-token>
# Expects bundle at /tmp/v4-root-bundle.tar.gz (flat: index.html at archive root).
set -euo pipefail

TS="${1:?release timestamp required}"
AUTH="${2:-}"
test "$AUTH" = "I_UNDERSTAND_WHOLE_SITE_REPLACEMENT" || {
  echo "FATAL: whole-root release requires explicit whole-site authorization" >&2
  exit 2
}
APP_ROOT=/opt/crmeb-prod/frontend-root
BUNDLE=/tmp/v4-root-bundle.tar.gz

mkdir -p "$APP_ROOT/releases"
test -f "$BUNDLE"

RELEASE_DIR="$APP_ROOT/releases/$TS"
rm -rf "$RELEASE_DIR"
mkdir -p "$RELEASE_DIR"
tar -xzf "$BUNDLE" -C "$RELEASE_DIR"
test -f "$RELEASE_DIR/index.html" || { echo "FATAL: index.html missing in bundle"; exit 1; }
test -d "$RELEASE_DIR/_expo" || { echo "FATAL: _expo missing in bundle"; exit 1; }

ln -sfn "releases/$TS" "$APP_ROOT/current.new"
mv -Tf "$APP_ROOT/current.new" "$APP_ROOT/current"

# Keep last 5 releases
ls -1t "$APP_ROOT/releases" | tail -n +6 | while read -r old; do
  rm -rf "$APP_ROOT/releases/$old"
done

rm -f "$BUNDLE"
echo "root current -> $(readlink -f "$APP_ROOT/current")"
