-- 各渠道分配库存：积分商城、盲盒商城的可售数量配额
-- 约束：integral_quota ≤ stock, manghe_quota ≤ stock, integral_quota + manghe_quota ≤ stock
-- 表前缀默认 eb_，如不同请自行替换

ALTER TABLE `eb_store_product` 
ADD COLUMN `integral_quota` INT(11) NOT NULL DEFAULT 0 COMMENT '积分商城可售数量上限，0表示不限制' AFTER `mall_type`,
ADD COLUMN `manghe_quota` INT(11) NOT NULL DEFAULT 0 COMMENT '盲盒商城可售数量上限，0表示不限制' AFTER `integral_quota`;
