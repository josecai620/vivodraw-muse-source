#!/usr/bin/env bash
# 用法: bash remote-bump-v4rel.sh <timestamp>
set -euo pipefail
TS="${1:?timestamp required}"
CONF=/etc/nginx/sites-enabled/vivodraw.com.conf
cp -a "$CONF" "$CONF.bak-bump-$TS"
python3 - "$CONF" "$TS" <<'PY'
import io, re, sys
conf, ts = sys.argv[1], sys.argv[2]
s = io.open(conf, encoding='utf-8').read()
new, n = re.subn(r'set \$v4rel "[0-9_]+";', f'set $v4rel "{ts}";', s)
assert n == 1, f'expected 1 v4rel line, replaced {n}'
io.open(conf, 'w', encoding='utf-8').write(new)
print('replaced lines:', n)
PY
grep -n 'set \$v4rel' "$CONF"
nginx -t
systemctl reload nginx
echo RELOADED_OK
