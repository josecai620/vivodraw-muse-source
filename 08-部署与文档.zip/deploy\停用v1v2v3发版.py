# -*- coding: utf-8 -*-
"""只发：旧前台拦截 PHP + 线上 nginx /v1/v2/v3 跳转 + 现役首页包去掉 V3 按钮。不覆盖整份 nginx，不提交 git。"""
import io
import os
import re
import subprocess
import tempfile

key = os.path.expanduser(r"~\.ssh\vivodraw_windows_ed25519")
ssh = [
    "ssh", "-i", key, "-p", "49375",
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
    "-o", "ServerAliveInterval=15",
    "root@186.241.72.176",
]
scp_base = [
    "scp", "-O", "-i", key, "-P", "49375",
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
]

php_rel = "backend_src/app/http/middleware/api/BlockLegacyClientMiddleware.php"
php_src = os.path.join(r"D:\eccomall", php_rel.replace("/", os.sep))
if not os.path.isfile(php_src):
    raise SystemExit("missing " + php_src)

staging = tempfile.mkdtemp(prefix="legacy-cut-")
php_lf = os.path.join(staging, "BlockLegacyClientMiddleware.php")
open(php_lf, "wb").write(open(php_src, "rb").read().replace(b"\r\n", b"\n"))

print(subprocess.check_output(ssh + [
    "mkdir -p /opt/crmeb-prod/deploy_backups && "
    "cd /opt/crmeb-prod && "
    "tar --ignore-failed-read -czf "
    "deploy_backups/legacy-cut-$(date +%Y%m%d-%H%M%S).tar.gz "
    "backend_src/app/http/middleware/api/BlockLegacyClientMiddleware.php && "
    "cp -a /etc/nginx/sites-enabled/vivodraw.com.conf "
    "/opt/crmeb-prod/deploy_backups/vivodraw.com.conf.legacy-cut-$(date +%Y%m%d-%H%M%S) && "
    "echo BACKUP_OK"
], timeout=60).decode(errors="replace"), flush=True)

dest = "root@186.241.72.176:/opt/crmeb-prod/" + php_rel
rc = subprocess.call(scp_base + [php_lf, dest])
if rc != 0:
    raise SystemExit("scp php failed rc=%s" % rc)
print("PHP_UPLOAD_OK", flush=True)

remote_py = r'''
import io, os, re, glob
conf = "/etc/nginx/sites-enabled/vivodraw.com.conf"
s = io.open(conf, encoding="utf-8").read()
block = (
    "    location = /v1 { return 301 /; }\n"
    "    location ^~ /v1/ { return 301 /; }\n"
    "    location = /v2 { return 301 /; }\n"
    "    location ^~ /v2/ { return 301 /; }\n"
    "    location = /v3 { return 301 /; }\n"
    "    location ^~ /v3/ { return 301 /; }\n"
)
if "location ^~ /v3/ { return 301 /; }" in s and "location ^~ /v2/ { return 301 /; }" in s:
    print("NGINX_ALREADY")
else:
    s2, n = re.subn(
        r"    location = /v2 \{ return 301 /v2/; \}.*?try_files \$uri \$uri\.html \$uri/ /v3/index\.html;\n    \}",
        block.rstrip(),
        s,
        count=1,
        flags=re.S,
    )
    if n != 1:
        s2, n = re.subn(
            r"    location = /v2 \{ return 301 /v2/; \}.*?try_files \$uri \$uri\.html \$uri/ /v2/index\.html;\n    \}",
            block.rstrip(),
            s,
            count=1,
            flags=re.S,
        )
        if n != 1:
            raise SystemExit("nginx v2/v3 block not found n=%s" % n)
        if "location ^~ /v3/" in s2 and "frontend-v3" in s2:
            s2, n3 = re.subn(
                r"    location = /v3 \{ return 301 /v3/; \}.*?try_files \$uri \$uri\.html \$uri/ /v3/index\.html;\n    \}\n",
                "",
                s2,
                count=1,
                flags=re.S,
            )
            if n3 != 1:
                raise SystemExit("nginx v3 leftover n=%s" % n3)
    io.open(conf, "w", encoding="utf-8").write(s2)
    print("NGINX_PATCHED")

root = "/opt/crmeb-prod/frontend-root/current/_expo/static/js/web"
old_btn = "children:[(0,A.jsxs)(w.default,{hitSlop:8,style:({pressed:e})=>[E.legacyV3Btn"
new_btn = "children:[false&&(0,A.jsxs)(w.default,{hitSlop:8,style:({pressed:e})=>[E.legacyV3Btn"
fn = 'function I(){"undefined"!=typeof window&&window.location.assign("/v3/")}'
hit = 0
for path in glob.glob(root + "/index-*.js"):
    text = io.open(path, encoding="utf-8").read()
    if "/v3/" not in text and "legacyV3Btn" not in text:
        continue
    new = text.replace(old_btn, new_btn).replace(fn, "function I(){}")
    if new == text:
        print("JS_NO_MATCH", os.path.basename(path))
        continue
    io.open(path, "w", encoding="utf-8").write(new)
    print("JS_PATCHED", os.path.basename(path))
    hit += 1
print("JS_HIT", hit)
'''

py_path = os.path.join(staging, "patch.py")
open(py_path, "w", encoding="utf-8", newline="\n").write(remote_py)
rc = subprocess.call(scp_base + [py_path, "root@186.241.72.176:/tmp/legacy-cut-patch.py"])
if rc != 0:
    raise SystemExit("scp patch.py failed")

print(subprocess.check_output(ssh + [
    "python3 /tmp/legacy-cut-patch.py && nginx -t && systemctl reload nginx && echo NGINX_RELOAD_OK"
], timeout=60).decode(errors="replace"), flush=True)

print(subprocess.check_output(ssh + [
    "docker exec crmeb-php-fpm php -l /var/www/backend/app/http/middleware/api/BlockLegacyClientMiddleware.php && "
    "rm -f /opt/crmeb-prod/backend_src/runtime/route_list.php && "
    "docker exec crmeb-php-fpm sh -c 'cd /var/www/backend && php think clear' || true && "
    "docker restart crmeb-php-fpm && echo PHP_RESTART_OK"
], timeout=120).decode(errors="replace"), flush=True)
print("DONE", flush=True)
