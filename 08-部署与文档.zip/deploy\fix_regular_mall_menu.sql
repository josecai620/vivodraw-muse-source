-- 常规商城只保留「商品」：点击常规商城时跳转到带 mall_type=0 的地址，以便侧边栏仅显示商品
UPDATE `eb_system_menus` SET `menu_path` = '/admin/product/product_list?mall_type=0' WHERE `id` = 2200;
-- 常规商城下子菜单名改为「商品」
UPDATE `eb_system_menus` SET `menu_name` = 0xE59586E59381 WHERE `id` = 2201;
