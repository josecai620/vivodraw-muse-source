# -*- coding: utf-8 -*-
"""扫描新页面里 t("ns.key") 的全部字面量键，按命名空间汇总，与现有 locale 对比。"""
import io, re, json, os

ROOT = r'D:\eccomall\mobile-app'
PAGES = [
    'app/coin-exchange.tsx',
    'app/game-wallet.tsx',
    'app/point-purchase.tsx',
    'app/wallet.tsx',
    'app/profile/delete-account.tsx',
]
pat = re.compile(r't\(\s*"([a-zA-Z0-9_.]+)"')
found = {}
for rel in PAGES:
    s = io.open(os.path.join(ROOT, rel), encoding='utf-8').read()
    for key in pat.findall(s):
        ns, _, leaf = key.partition('.')
        found.setdefault(ns, set()).add(leaf)

for loc in ['en', 'zh-TW']:
    p = os.path.join(ROOT, 'lib', 'i18n', 'locales', f'{loc}.json')
    data = json.load(io.open(p, encoding='utf-8'))
    print(f'===== {loc}.json 缺失 =====')
    for ns, leaves in sorted(found.items()):
        existing = set((data.get(ns) or {}).keys())
        missing = sorted(leaves - existing)
        print(f'-- {ns}: 缺 {len(missing)} / 共 {len(leaves)}')
        for m in missing:
            print('   ', m)
