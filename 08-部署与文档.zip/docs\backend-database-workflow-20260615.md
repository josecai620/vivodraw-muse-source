# Backend Database Workflow - 2026-06-15

## Boundary

This workflow is read-only by default. Production DDL/DML is not executed without explicit approval.

Allowed now:
- Read schema, logs, table sizes, indexes, and runtime status.
- Patch backend code that points at missing tables.
- Add audit and approval-required repair scripts.

Not allowed without separate approval:
- `ALTER TABLE`, `UPDATE`, `DELETE`, `TRUNCATE`, `DROP`, `OPTIMIZE`, production migration execution, payment/inventory/ledger writes.

## Production Read-Only Findings

- MySQL: `8.0.46`, `ONLY_FULL_GROUP_BY` enabled.
- Database: `manghehoutai_qhe`, 216 tables, about 43.47 MB.
- Largest tables: `eb_user_box` about 18.58 MB, `eb_box_order` about 6.77 MB, `eb_city_area` about 7.55 MB.
- Non-InnoDB table: `eb_wechat_key` uses MyISAM.
- Tables without primary key: 17 found; most are empty relation/status tables. `eb_store_product_description` has 342 rows and no duplicate `(product_id, type)` pairs.
- Duplicate index candidates: `eb_system_attachment_category.id` duplicates `PRIMARY`, `eb_user_level.id` duplicates `PRIMARY`.
- Missing production table: code referenced `eb_store_integral_product_kaijiang_log`, but production only has `eb_store_product_kaijiang_log`.
- Historical script risk: `deploy/fix_store_product_kaijiang_log_view.sql` previously dropped the old table name and replaced it with a view. That is unsafe for the current production state.

## Changes Made In Code/Scripts

- Backend code now uses the production reveal table `store_product_kaijiang_log` instead of the missing `store_integral_product_kaijiang_log`.
- `deploy/fix_store_product_kaijiang_log_view.sql` no longer drops existing base tables. It only creates compatibility views when safe.
- Added `deploy/db_audit_20260615_readonly.sql` for repeatable read-only database checks.
- Added `deploy/db_repair_20260615_approval_required.sql` for guarded DDL repair after explicit approval.
- Added `deploy/db_repair_20260615_rollback_approval_required.sql` for rollback of added indexes if needed.
- Deprecated stale phase-6/phase-7 deploy SQL entrypoints that can fail after partial DDL or partial deletes:
  `deploy/db_optimize_phase6_indexes.sql`, `deploy/db_optimize_phase6_drop_indexes.sql`, and `deploy/db_cleanup_phase7_robot_data.sql`.

## Approval-Required Repair Plan

If approved, run only after a verified backup and preferably staging:

```bash
mysql manghehoutai_qhe < deploy/db_audit_20260615_readonly.sql
mysql manghehoutai_qhe < deploy/db_repair_20260615_approval_required.sql
mysql manghehoutai_qhe < deploy/db_audit_20260615_readonly.sql
```

Planned repairs:
- Add missing composite indexes for `eb_user_box`, `eb_box_order`, `eb_store_integral_product_huanqu_log`, `eb_store_integral_product_huanqu_log_unique`, and `eb_store_product_kaijiang_log`.
- Add `kami_account` and `kami_pass` columns to `eb_store_product_kaijiang_log` if missing.
- Drop duplicate `id` indexes where `PRIMARY` already exists.
- Convert `eb_wechat_key` from MyISAM to InnoDB.
- Add composite primary key on `eb_store_product_description(product_id, type)` if no duplicates exist.

## Current Recommendation

Do not run the repair SQL blindly. The database is small; the biggest win is preventing schema drift and strict-mode crashes, not pretending a 43 MB database needs heroic tuning.
