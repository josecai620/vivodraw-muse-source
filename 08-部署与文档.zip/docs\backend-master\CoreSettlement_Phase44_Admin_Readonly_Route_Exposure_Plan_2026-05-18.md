# CoreSettlement Phase 44 Admin Readonly Route Exposure Plan 2026-05-18

## Current Task

Phase 44 defines the admin readonly route exposure plan for Point Gateway.

Plan only.
No `route/admin.php` change was made.
No route was exposed.
No menu SQL was executed.
No deployment was executed.
No database write path was enabled.

## Exposure Preconditions

```text
explicit user approval required: true
route/admin.php edit allowed in Phase44: false
GET only: true
POST allowed: false
PUT allowed: false
PATCH allowed: false
DELETE allowed: false
menu SQL allowed: false
DbPointTransactionStore enabled: false
production switch enabled: false
```

Do not expose routes until ACL rows and hidden menu behavior are approved.

## Planned Route Block

Do not apply this in Phase44.
Use only after explicit user approval in a later phase.

```php
Route::group('core/point_gateway', function () {
    Route::get('overview', 'v1.core.PointGateway/overview')->option(['real_name' => 'Point Gateway overview']);
    Route::get('transactions', 'v1.core.PointGateway/transactions')->option(['real_name' => 'Point Gateway transactions']);
    Route::get('detail', 'v1.core.PointGateway/detail')->option(['real_name' => 'Point Gateway transaction detail']);
    Route::get('rollback_requests', 'v1.core.PointGateway/rollback_requests')->option(['real_name' => 'Point Gateway rollback requests']);
    Route::get('frozen_points', 'v1.core.PointGateway/frozen_points')->option(['real_name' => 'Point Gateway frozen points']);
    Route::get('expiry_batches', 'v1.core.PointGateway/expiry_batches')->option(['real_name' => 'Point Gateway expiry batches']);
    Route::get('ai_operation_logs', 'v1.core.PointGateway/ai_operation_logs')->option(['real_name' => 'Point Gateway AI operation logs']);
});
```

## Route Contract

```text
GET adminapi/core/point_gateway/overview
GET adminapi/core/point_gateway/transactions
GET adminapi/core/point_gateway/detail
GET adminapi/core/point_gateway/rollback_requests
GET adminapi/core/point_gateway/frozen_points
GET adminapi/core/point_gateway/expiry_batches
GET adminapi/core/point_gateway/ai_operation_logs
```

## Permission Contract

```text
root unique_auth: admin-core-point-gateway
core-point-gateway-overview
core-point-gateway-transactions
core-point-gateway-detail
core-point-gateway-rollback-requests
core-point-gateway-frozen-points
core-point-gateway-expiry-batches
core-point-gateway-ai-operation-logs
```

## Forbidden Route Names

```text
point_gateway.rollback.execute
point_gateway.manual_adjust.execute
point_gateway.legacy_bill.update
point_gateway.user_integral.update
point_gateway.store.enable
point_gateway.migration.execute
```

## Future Exposure Checklist

```text
1. Confirm user approval for route/admin.php edit.
2. Confirm all methods are GET.
3. Confirm controller has no Db facade, save, update, delete, rollback_execute, or manual_adjust methods.
4. Confirm route/admin.php has no existing point_gateway block.
5. Confirm permission rows are approved separately.
6. Confirm menu remains hidden by default.
7. Run point_gateway_admin_route_exposure_plan_assert.
8. Run point_gateway_admin_route_contract_assert.
9. Run core_settlement_backend_package_assert.
10. Deploy only after separate approval.
```

## Rollback Plan

```text
remove only the core/point_gateway route group
do not delete controller or services
do not touch database
do not touch menu SQL
re-run route exposure asserts
```

## Validation

```text
point_gateway_admin_route_exposure_plan_assert
point_gateway_admin_route_contract_assert
core_settlement_backend_package_assert
```
