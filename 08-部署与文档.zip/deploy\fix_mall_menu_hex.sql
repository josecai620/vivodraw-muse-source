-- 使用 UTF-8 十六进制写入，确保中文正确
-- 常规商城 积分商城 盲盒商城 商品列表 积分商品 盲盒商品

UPDATE `eb_system_menus` SET `menu_name` = 0xE5B8B8E8A784E59586E59F8E WHERE `id` = 2200;
UPDATE `eb_system_menus` SET `menu_name` = 0xE59586E59381E58897E8A1A8 WHERE `id` = 2201;
UPDATE `eb_system_menus` SET `menu_name` = 0xE7A7AFE58886E59586E59F8E WHERE `id` = 2202;
UPDATE `eb_system_menus` SET `menu_name` = 0xE7A7AFE58886E59586E59381 WHERE `id` = 2203;
UPDATE `eb_system_menus` SET `menu_name` = 0xE79BB2E79B92E59586E59F8E WHERE `id` = 2204;
UPDATE `eb_system_menus` SET `menu_name` = 0xE79BB2E79B92E59586E59381 WHERE `id` = 2205;
