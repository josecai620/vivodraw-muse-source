# US Hot Product Sourcing Directory - 2026-06-26

Status: sourcing plan only. Do not import to production until the formal server move is complete and each SKU is re-checked.

Target market: United States.

Default storefront lane: regular mall products should include normal sale visibility. Use the current upload workflow rules in `docs/product-upload-maintenance-workflow.md`.

## Operating Rules

1. Use Amazon US for demand proof: bestseller rank, review count, rating, price band, and repeat-purchase signal.
2. Use CJ or authorized supplier pages for fulfillment proof: stock, shipping options, gallery, variant data, and supplier cost.
3. Do not copy Amazon images directly unless PA API / Associates Program usage or supplier permission is confirmed.
4. Prefer products that are easy to understand in 3 seconds, visually clean, low return-risk, and naturally fit points rewards.
5. Re-check every product on collection day. Bestseller pages move daily; yesterday's "hot" can become tomorrow's dust.

## Source References

- Amazon Best Sellers: https://www.amazon.com/Best-Sellers/zgbs
- Amazon Best Sellers - Skin Care: https://www.amazon.com/Best-Sellers-Beauty-Personal-Care-Skin-Care-Products/zgbs/beauty/11060451
- Amazon Best Sellers - Earbud & In-Ear Headphones: https://www.amazon.com/Best-Sellers-Earbud-In-Ear-Headphones/zgbs/electronics/12097478011
- Amazon Best Sellers - Portable Bluetooth Speakers: https://www.amazon.com/Best-Sellers-Portable-Bluetooth-Speakers/zgbs/electronics/7073956011
- Amazon Best Sellers - Xbox One Accessories: https://us.amazon.com/Best-Sellers-Xbox-One-Accessories/zgbs/videogames/6469270011
- Amazon Best Sellers - Toys & Games: https://www.amazon.com/Best-Sellers-Toys-Games/zgbs/toys-and-games
- Amazon Best Sellers - Toy Building Sets: https://www.amazon.com/Best-Sellers-Toy-Building-Sets/zgbs/toys-and-games/166099011
- Amazon Best Sellers - Travel Accessories: https://www.amazon.com/Best-Sellers-Travel-Accessories/zgbs/fashion/15743971
- Amazon Best Sellers - Travel Packing Organizers: https://www.amazon.com/Best-Sellers-Travel-Packing-Organizers/zgbs/fashion/15744041
- Amazon Best Sellers - Desk Lamps: https://www.amazon.com/Best-Sellers-Desk-Lamps/zgbs/hi/1063292
- Amazon Best Sellers - Table Fans: https://www.amazon.com/Best-Sellers-Table-Fans/zgbs/home-garden/3737631
- Amazon Best Sellers - Camping Fans: https://www.amazon.com/Best-Sellers-Camping-Fans/zgbs/sporting-goods/118698861011
- Amazon Best Sellers - Camping Lanterns: https://www.amazon.com/Best-Sellers-Camping-Lanterns/zgbs/sporting-goods/3401371
- CJ June 2026 trending products: https://cjdropshipping.com/blogs/winning-products/10-Best-Dropshipping-Products-June-2026
- CJ 2026 top trending products: https://cjdropshipping.com/blogs/winning-products/10-Top-Trending-Dropshipping-Products
- CJ Shopify dropshipping products 2026: https://cjdropshipping.com/blogs/winning-products/Best-Dropshipping-Products-for-Shopify-Stores
- CJ best-selling products online 2026: https://cjdropshipping.com/blogs/winning-products/best-selling-products-E-commerce
- CJ portable blender example: https://cjdropshipping.com/product/portable-blender-with-usb-rechargeable-mini-kitchen-fruit-juice-mixer-home-simple-portable-electric-mini-juicer-p-1543179507669151744.html
- CJ travel organizer example: https://cjdropshipping.com/product/8-piece-set-luggage-divider-bag-travel-storage-clothes-underwear-shoes-organizer-packing-cube-bag-p-1386852733046362112.html

## Priority A: First Collection Batch

These are the first products to collect after the formal server move. They have broad US acceptance, easy product pages, and enough visual/price logic for normal ecommerce.

| Category | Product direction | Why it should sell | Source target | Collection keywords | Risk gate |
|---|---|---|---|---|---|
| Beauty & Self-care | Hydrocolloid pimple patches | Repeat purchase, low price, high social proof | CJ / authorized skincare supplier | `hydrocolloid pimple patches`, `acne patch`, `spot patch` | No medical cure claims |
| Beauty & Self-care | K-beauty / collagen face mask set | Giftable, replenishable, strong skincare habit | CJ / supplier / brand permission | `collagen face mask`, `K beauty mask`, `sheet mask set` | Ingredient and claims review |
| Beauty & Self-care | Exfoliating toner pads | Amazon skincare bestseller signal; small and repeatable | Supplier / brand-approved media | `toner pads`, `exfoliating facial pads`, `AHA BHA pads` | Avoid copying branded formulas |
| Beauty & Self-care | Travel cosmetic bag | Easy photo, low return risk, daily/travel use | CJ / manual supplier | `travel cosmetic bag`, `makeup organizer pouch` | Material quality photos |
| Beauty & Self-care | LED vanity mirror | Visual card, giftable, existing CJ/source fit | CJ / supplier | `LED vanity mirror`, `makeup mirror rechargeable` | Electrical safety and real photos |
| Cute Desk / Home Lifestyle | Desk organizer / drawer organizer | Strong home-office and vanity demand | CJ / manual supplier | `desk organizer`, `makeup storage organizer`, `drawer organizer` | Avoid oversized shipping |
| Cute Desk / Home Lifestyle | Cable management clip set | Cheap add-on, useful, high conversion accessory | CJ | `magnetic cable clip`, `cable organizer desk` | Need clean close-up image |
| Cute Desk / Home Lifestyle | Rechargeable desk lamp | Useful, giftable, good desk-lifestyle visual | CJ / supplier | `rechargeable desk lamp`, `portable desk light` | Battery/electrical claims |
| Cute Desk / Home Lifestyle | Portable blender | CJ trend fit, TikTok-style demo potential | CJ | `portable blender`, `USB rechargeable blender`, `cordless blender` | Battery, food-contact material |
| Cute Desk / Home Lifestyle | Insulated tumbler / travel cup | Frequent purchase, giftable, repeat colors | CJ / supplier | `insulated tumbler`, `40oz tumbler`, `travel cup` | Brand/IP lookalike risk |
| Game Gear | Hall-effect wired controller | Gaming accessory bestseller signal, clear feature value | CJ / brand-authorized supplier | `hall effect controller`, `wired game controller` | Compatibility copy must be exact |
| Game Gear | Gaming headset | Huge review base category, low entry price | CJ / authorized supplier | `gaming headset`, `wired gaming headset`, `noise cancelling mic` | Audio quality and return risk |
| Game Gear | Controller charging dock / battery pack | Repeat accessory need, low-ticket add-on | CJ / supplier | `controller battery pack`, `charging dock Xbox`, `controller charger` | Battery safety and compatibility |
| Game Gear | Headset/controller stand | Desk setup visual, low return risk | CJ / supplier | `headset stand`, `controller holder`, `gaming desk organizer` | Avoid using console trademarks in title |
| Game Gear | RGB gaming speakers | Visual, giftable, desk setup fit | Supplier / CJ | `RGB gaming speakers`, `computer gaming speakers` | Sound quality reviews |
| Premium Tech | Bluetooth earbuds | Large Amazon category, broad daily use | CJ / authorized supplier | `wireless earbuds`, `bluetooth earbuds`, `USB C case` | High return risk; need reviews |
| Premium Tech | Portable Bluetooth speaker | Bestseller signal, giftable, simple value | CJ / supplier | `portable bluetooth speaker`, `waterproof speaker` | Brand lookalike/IP risk |
| Premium Tech | USB-C hub / 3-in-1 adapter | Practical, low-ticket, laptop/tablet demand | Supplier / CJ | `USB C hub`, `3 in 1 USB C adapter`, `SD card reader` | Compatibility copy |
| Premium Tech | Fast charging power bank | Utility, travel fit, good points reward hook | CJ / supplier | `power bank`, `portable charger`, `USB C power bank` | Battery certification |
| Premium Tech | Foldable laptop stand | Home-office evergreen, easy photos | CJ / supplier | `foldable laptop stand`, `aluminum laptop stand` | Weight/capacity proof |
| Toys / Collectibles | Mini building block flower set | Giftable, desk decor, collector-adjacent | CJ / generic supplier | `building block flower`, `mini flower blocks` | Do not use LEGO wording |
| Toys / Collectibles | Capybara / cute plush | 2026 toy trend signal, impulse gift | CJ / supplier | `capybara plush`, `cute plush`, `bag charm plush` | Licensed character risk |
| Toys / Collectibles | Fidget / sensory desk toy | Low-ticket, repeatable, social video friendly | CJ / supplier | `fidget toy`, `sensory toy`, `desk stress toy` | Age/safety warnings |
| Toys / Collectibles | Puzzle / 3D wooden model | Giftable, family/adult hobby fit | CJ / supplier | `3D wooden puzzle`, `mechanical puzzle kit` | Assembly difficulty and missing parts |
| Toys / Collectibles | Display figure stand / collectible case | Fits platform collectibles without IP risk | CJ / supplier | `display case`, `figure display stand`, `collectible organizer` | Dimensions accuracy |
| Outdoor / Travel | Compression packing cubes | Strong travel organizer signal, practical, low return | CJ / supplier | `compression packing cubes`, `travel packing organizers` | Zipper/material quality |
| Outdoor / Travel | Portable handheld fan | Summer bestseller signal, cheap and useful | CJ / supplier | `portable handheld fan`, `USB rechargeable fan` | Battery and real runtime |
| Outdoor / Travel | Neck fan | CJ June 2026 trend fit, summer/travel use | CJ | `portable neck fan`, `bladeless neck fan` | Comfort/noise reviews |
| Outdoor / Travel | Camping fan with LED lantern | Outdoor and emergency utility, high perceived value | CJ / supplier | `camping fan LED lantern`, `rechargeable camping fan` | Battery certification |
| Outdoor / Travel | Toiletry bag / hanging organizer | Frequent travel purchase, easy photo | CJ / supplier | `hanging toiletry bag`, `travel organizer bag` | Material and zipper quality |

## Category Directory

### Beauty & Self-care

| Priority | Product direction | Source plan | Evidence signal | Collection notes |
|---|---|---|---|---|
| A | Hydrocolloid pimple patches | CJ / authorized skincare supplier | Skincare bestseller and CJ Shopify trend mentions pimple patches | Use neutral problem-solving copy, no cure promise |
| A | Collagen / K-beauty face mask set | CJ / supplier | Repeat purchase, giftable, beauty social content | Need ingredient list and skin-sensitivity disclaimer |
| A | Exfoliating toner pads | Supplier / brand permission | Amazon Best Sellers main page surfaced toner pads | Avoid brand-name copycat listing |
| A | Travel cosmetic bag | CJ / manual supplier | CJ product pages and travel organizer demand | Good for beauty + travel cross-sell |
| A | LED vanity mirror | CJ / supplier | Beauty tool, visual card, current platform fit | Need electrical/battery details |
| B | Facial cleansing brush | CJ / supplier | Evergreen beauty device | Watch return risk and waterproof claims |
| B | Electric scalp massager | CJ June 2026 trend mentions scalp massager | Summer/self-care video product | Keep claims to comfort/relaxation |
| B | Hair dryer / cordless styling tool | CJ March 2026 trend mentions cordless hair styling tools | Strong beauty demand | Higher return/safety risk |
| B | Jewelry organizer | Supplier / manual supplier | Giftable, vanity storage | Needs clean dimensions and materials |
| B | Shower steamers / bath gift set | Supplier | Giftable repeat purchase | Ingredient/fragrance claims |
| C | LED face mask / red light device | CJ trend content highlights home beauty tech | High perceived value | High claim and compliance risk |
| C | Red light hair growth brush | CJ January 2026 trend | Hot but medical-adjacent | Do not list until claims/legal checked |

### Cute Desk / Home Lifestyle

| Priority | Product direction | Source plan | Evidence signal | Collection notes |
|---|---|---|---|---|
| A | Desk organizer / drawer organizer | CJ / supplier | Amazon desk/home organizer demand and existing shortlist | Low-risk first SKU |
| A | Cable clip / cable management set | CJ | Desk setup utility | Add-on product, good bundle item |
| A | Rechargeable desk lamp | CJ / supplier | Amazon Desk Lamps best seller category | Need real lamp-on photos |
| A | Portable blender | CJ product pages and June trend | Video-friendly kitchen gadget | Battery + food-contact material |
| A | Insulated tumbler | CJ / supplier | Frequent purchase, giftable | Avoid Stanley-style trademark look |
| B | Digital kitchen scale | CJ | Amazon kitchen utility signal | Low-risk home product |
| B | Mini projector | CJ March 2026 trend mentions mini projectors | High perceived value | Verify resolution/brightness honestly |
| B | Aroma diffuser / humidifier | CJ / supplier | Home comfort product | Electrical and water-leak complaints |
| B | Coffee mug warmer | Supplier | Desk lifestyle gift | Temperature/safety claims |
| B | Cup washer / sink rinser | CJ product page exists | Strong demo video potential | Installation complexity |
| C | Foldable treadmill / walking pad | CJ / supplier | Home fitness trend | Shipping/returns high |
| C | Vanity desk / furniture | CJ / supplier | Beauty/home fit | Bulky freight risk |

### Game Gear

| Priority | Product direction | Source plan | Evidence signal | Collection notes |
|---|---|---|---|---|
| A | Hall-effect wired controller | CJ / authorized supplier | Amazon Xbox accessories shows controller demand | Compatibility must be exact |
| A | Gaming headset | CJ / supplier | Amazon Xbox accessories shows headset demand | Sound/mic quality reviews matter |
| A | Controller charging dock / batteries | CJ / supplier | Amazon accessories shows battery pack demand | Battery safety |
| A | Headset/controller stand | CJ / supplier | Amazon stand/accessory pages show desk storage demand | Good bundle with headset |
| A | RGB computer speakers | Supplier / CJ | Gaming setup visual | Audio return risk |
| B | Thumb grips / joystick caps | Supplier | Low-ticket controller add-on | Avoid console trademark spam |
| B | Gaming mouse pad / desk mat | Supplier | Desk setup evergreen | Need attractive photos |
| B | Mobile game controller | CJ / supplier | Mobile gaming + controller demand | Phone compatibility |
| B | Console cooling fan / dust kit | Supplier | Amazon accessory pages show cooling/dust products | Do not exaggerate cooling |
| B | Switch / handheld carrying case | Supplier | Travel + gaming accessory | Dimensions must match models |
| C | Racing wheel / pedals | Authorized supplier | Amazon Xbox list shows racing wheels | High ticket, return risk |
| C | VR headset accessories | Authorized supplier | Strong but brand-dependent | Brand/IP and compatibility risk |

### Premium Tech

| Priority | Product direction | Source plan | Evidence signal | Collection notes |
|---|---|---|---|---|
| A | Bluetooth earbuds | CJ / authorized supplier | Amazon earbud bestseller category | Need real reviews, high return risk |
| A | Portable Bluetooth speaker | CJ / supplier | Amazon portable speaker bestseller category | Waterproof claims proof |
| A | USB-C hub / adapter | Supplier / CJ | Laptop/tablet everyday need | Compatibility copy |
| A | Power bank / portable charger | CJ / supplier | Amazon tech utility demand and CJ June trend adjacent | Battery certification |
| A | Foldable laptop stand | CJ / supplier | Home office evergreen | Low-risk accessory |
| B | GaN fast charger | Supplier | Frequent tech purchase | Certification required |
| B | 3-in-1 wireless charging station | Supplier | Desk/travel tech demand | Apple/MagSafe wording caution |
| B | Over-ear headphones | Supplier | Amazon headphone categories | Brand transparency/returns |
| B | Bluetooth tracker tag | Supplier / brand | Travel/key loss use case | Ecosystem compatibility |
| B | Portable monitor | Supplier | Remote work / gaming | Higher return risk |
| C | Robot vacuum | Supplier / brand | High perceived value | Returns/warranty expensive |
| C | Premium laptop / MacBook-like items | Brand/authorized only | Strong demand | Do not resell blindly |

### Toys / Collectibles

| Priority | Product direction | Source plan | Evidence signal | Collection notes |
|---|---|---|---|---|
| A | Mini building block flower set | CJ / generic supplier | Amazon toy building sets and existing shortlist | Do not use LEGO wording |
| A | Cute plush / capybara plush | CJ / supplier | 2026 toy trend coverage mentions capybara plush | Avoid licensed character copies |
| A | Fidget / sensory desk toy | CJ / supplier | Low-ticket social toy | Age/safety warnings |
| A | 3D wooden puzzle / model kit | CJ / supplier | Giftable hobby item | Missing parts support |
| A | Figure display case / collectible organizer | CJ / supplier | Collector utility and low IP risk | Dimensions accuracy |
| B | DIY craft kit | Supplier | Family/gift repeat category | Age and choking warnings |
| B | Magnetic building tiles / sticks | Supplier | STEM toy demand | Safety certification |
| B | Mini RC car / stunt toy | Supplier | Video demo potential | Battery/quality risk |
| B | Card binder / trading card sleeves | Supplier | Collector accessory evergreen | Avoid licensed card images |
| B | Blind-box style generic figurines | Supplier | Platform fit | Avoid fake scarcity and IP copies |
| C | Licensed character toys | Authorized only | Strong demand | Do not source without rights |
| C | Drone toys | Supplier | High visual appeal | Compliance and return risk |

### Outdoor / Travel

| Priority | Product direction | Source plan | Evidence signal | Collection notes |
|---|---|---|---|---|
| A | Compression packing cubes | CJ / supplier | Amazon travel packing organizer category and recent travel coverage | Great first travel SKU |
| A | Portable handheld fan | CJ / supplier | Amazon summer fan coverage and CJ June list | Battery/runtime proof |
| A | Neck fan | CJ | CJ June 2026 trending product | Comfort/noise reviews |
| A | Camping fan with LED lantern | CJ / supplier | Amazon camping fan best seller category | Battery certification |
| A | Hanging toiletry organizer | CJ / supplier | Travel organizer demand | Material/zippers |
| B | Travel bottle set | Supplier | Travel staple | Leak-proof proof |
| B | Foldable travel bag / weekender | CJ / supplier | CJ June trend mentions foldable travel bag | Stitching/weight capacity |
| B | Cable organizer pouch | Supplier | Travel tech add-on | Low-risk bundle |
| B | Luggage scale | Supplier | Travel utility | Accuracy/reviews |
| B | Camping lantern | Supplier | Amazon camping lantern category | Battery/lumen honesty |
| C | Portable ice maker | CJ June 2026 list | Summer demand | Bulky return risk |
| C | Portable power station | Authorized supplier | Outdoor/emergency demand | High-ticket battery/warranty risk |

## First 30 SKU Harvest Order

Use this order after the formal server move. Stop after each block of 10 and check storefront quality before continuing. Flooding the store with half-baked SKUs is not "selection"; it is digital hoarding.

1. Hydrocolloid pimple patches
2. K-beauty / collagen face mask set
3. Travel cosmetic bag
4. LED vanity mirror
5. Desk organizer / drawer organizer
6. Cable clip set
7. Rechargeable desk lamp
8. Portable blender
9. Hall-effect wired controller
10. Controller charging dock / battery pack
11. Gaming headset
12. Headset/controller stand
13. Bluetooth earbuds
14. Portable Bluetooth speaker
15. USB-C hub / adapter
16. Power bank / portable charger
17. Foldable laptop stand
18. Mini building block flower set
19. Cute plush / capybara plush
20. Fidget / sensory desk toy
21. 3D wooden puzzle / model kit
22. Figure display case / collectible organizer
23. Compression packing cubes
24. Portable handheld fan
25. Neck fan
26. Camping fan with LED lantern
27. Hanging toiletry organizer
28. Insulated tumbler
29. Digital kitchen scale
30. RGB computer speakers

## Collection Checklist Per SKU

Every collected SKU must have these fields before upload:

| Field | Requirement |
|---|---|
| `category` | One of the six platform categories |
| `source_platform` | `cj`, `amazon_reference`, `brand`, or `manual_supplier` |
| `source_link` | Direct product/source URL |
| `source_product_id` | CJ SKU, ASIN, supplier SKU, or variant ID |
| `trend_evidence` | Amazon bestseller/category evidence plus CJ/supplier availability |
| `acceptance_signal` | At least two of: review count, rating, price band, repeat-purchase, social/demo potential |
| `image_rights_status` | `cj_api`, `supplier_permission`, `pa_api`, `authorized`, or `needs_rights_check` |
| `image_status` | `pass` only after real product photo check |
| `procurement_cost` | Current source cost, not guessed |
| `shipping_buffer` | Based on source region and product weight |
| `risk_buffer` | Higher for batteries, electronics, beauty claims, bulky goods |
| `pricing_note` | Why the markup is acceptable to a US customer |
| `claims_note` | Required for beauty, wellness, battery, waterproof, compatibility, and safety claims |

## Do Not Collect First

| Product type | Reason |
|---|---|
| Amazon-only branded products with no authorized image/source | Image and listing rights are not cleared |
| Medical-treatment beauty devices | Claim risk is too high for first batch |
| Bulky furniture | Freight, return, and damage risk |
| High-ticket laptops / branded electronics | Margin transparency and warranty risk |
| Licensed character toys | IP risk unless supplier authorization exists |
| Battery-heavy outdoor gear without certification | Safety and platform policy risk |
