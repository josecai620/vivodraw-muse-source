-- Database optimization phase 6: candidate indexes from the 2026-05-02 read-only audit.
--
-- DEPRECATED:
-- This historical script references stale reveal-log table names and can fail
-- after partially applying DDL. Use the guarded current plan instead:
--   deploy/db_repair_20260615_approval_required.sql
SIGNAL SQLSTATE '45000'
  SET MESSAGE_TEXT = 'Deprecated script: use deploy/db_repair_20260615_approval_required.sql';
--
-- IMPORTANT:
-- 1. Do not run this during peak traffic.
-- 2. Take a verified database backup first.
-- 3. Run on the test server before using on production.
-- 4. These ALTER statements are intentionally not auto-idempotent; check SHOW INDEX first.
--
-- Test server execution:
-- - Executed on 8.166.115.27 at 2026-05-02 20:13-20:16 Asia/Shanghai.
-- - Rollback script: deploy/db_optimize_phase6_drop_indexes.sql

-- Large draw-number table.
-- Fixes lookups by product period + draw status + manual winner flag.
ALTER TABLE `eb_store_integral_product_huanqu_log_unique`
  ADD INDEX `idx_hq_unique_draw_lookup` (`product_id`, `bianhao`, `status`, `isset`),
  ADD INDEX `idx_hq_unique_huanqu_isset` (`huanqu_id`, `isset`, `is_jiqiren`),
  ALGORITHM=INPLACE,
  LOCK=NONE;

-- Integral exchange log.
-- Fixes product period history and user category draw-list queries.
ALTER TABLE `eb_store_integral_product_huanqu_log`
  ADD INDEX `idx_hq_log_product_bianhao_id` (`product_id`, `bianhao`, `id`),
  ADD INDEX `idx_hq_log_uid_boxcate_id` (`uid`, `box_cate_id`, `id`),
  ALGORITHM=INPLACE,
  LOCK=NONE;

-- Draw result log.
-- Fixes product period detail lookups and pending draw scans.
ALTER TABLE `eb_store_integral_product_kaijiang_log`
  ADD INDEX `idx_kaijiang_product_bianhao` (`product_id`, `bianhao`),
  ADD INDEX `idx_kaijiang_status_time_id` (`status`, `kaijiang_time`, `id`),
  ALGORITHM=INPLACE,
  LOCK=NONE;

-- User box assets.
-- Fixes backpack counts, shipping selection, and order-to-box lookups.
ALTER TABLE `eb_user_box`
  ADD INDEX `idx_user_box_uid_product_status_id` (`uid`, `product_id`, `status`, `id`),
  ADD INDEX `idx_user_box_uid_cate_status_product` (`uid`, `cate_id`, `status`, `product_id`),
  ADD INDEX `idx_user_box_order_id` (`order_id`),
  ADD INDEX `idx_user_box_huanqu_id` (`huanqu_id`),
  ALGORITHM=INPLACE,
  LOCK=NONE;

-- Box orders.
-- Fixes user order lists and payment/order-sn callbacks.
ALTER TABLE `eb_box_order`
  ADD INDEX `idx_box_order_uid_id` (`uid`, `id`),
  ADD INDEX `idx_box_order_order_sn` (`order_sn`),
  ADD INDEX `idx_box_order_pay_status_id` (`pay_status`, `id`),
  ALGORITHM=INPLACE,
  LOCK=NONE;

-- Refresh optimizer statistics after adding indexes.
ANALYZE TABLE
  `eb_store_integral_product_huanqu_log_unique`,
  `eb_store_integral_product_huanqu_log`,
  `eb_store_integral_product_kaijiang_log`,
  `eb_user_box`,
  `eb_box_order`;
