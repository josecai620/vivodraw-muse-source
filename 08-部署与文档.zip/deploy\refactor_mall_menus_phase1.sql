-- ===========================================================
-- 三商城独立栏目重构 · 第一阶段
-- ===========================================================
-- 目标：
--   1) 把被错命名的 id=1 顶栏「盲盒」改回「常规商城」（保持 CRMEB 原版 header='product'）
--   2) 修正 id=2/3/22 三个子菜单名（盲盒商品/盲盒列表/产品添加 → 商品列表/商品分类/添加商品）
--   3) 新增 3 个独立顶栏：积分商城(2300) / 盲盒商城(2310) / 拼团抽奖(2320)，挂上各自子菜单
--   4) 角色权限追加（程程、paipai 角色 rules 列表追加新 id）
--
-- 安全保证：
--   - 所有 INSERT 用 WHERE NOT EXISTS 幂等
--   - 所有 UPDATE 限定具体 id，重复执行无副作用
--   - 不动 mall_type 字段、不动商品数据、不动前端代码
--   - 旧菜单（盲盒中奖设置 id=1509、盲盒赠送抽奖 id=1510、开盒记录 id=1511 等）保留不动，第二阶段再挪窝
--   - 备份已存于服务器：/opt/crmeb-prod/deploy/backup/eb_system_menus_*.sql
--
-- 路径说明：
--   生产实际路径前缀为 /admin-shop/（不是 /admin/）
--   id 从 2300 起编号，避开已用的 2200(幸运值保底)、2201(Hermes 密钥)
-- ===========================================================

SET NAMES utf8mb4;

-- ===== 1. 修复"盲盒-盲盒列表"误命名 =====

-- id=1 顶栏：盲盒 → 常规商城（图标改为方块）
UPDATE `eb_system_menus` SET `menu_name` = '常规商城', `icon` = 'md-cube-outline'
  WHERE `id` = 1 AND `is_del` = 0;

-- id=2 二级：盲盒商品 → 商品列表（path 本来就是 product_list，名字回归）
UPDATE `eb_system_menus` SET `menu_name` = '商品列表'
  WHERE `id` = 2 AND `is_del` = 0;

-- id=3 二级：盲盒列表 → 商品分类（path 是 product_classify，名字早就错位）
UPDATE `eb_system_menus` SET `menu_name` = '商品分类'
  WHERE `id` = 3 AND `is_del` = 0;

-- id=22 二级：产品添加 → 添加商品（命名一致性）
UPDATE `eb_system_menus` SET `menu_name` = '添加商品'
  WHERE `id` = 22 AND `is_del` = 0;


-- ===== 2. 新增「积分商城」顶栏（id=2300）=====

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2300, 0, 1, 'logo-euro', '积分商城', 'admin', 'marketing.store_integral', 'index', '', '', '[]', 125, 1, 0, 1, '/admin-shop/marketing/store_integral/index', '', 1, 'mall_integral', 1, 'admin-mall-integral', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2300 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2301, 2300, 1, 'md-list-box', '积分商品', 'admin', 'marketing.store_integral', 'index', '', '', '[]', 100, 1, 0, 1, '/admin-shop/marketing/store_integral/index', '2300', 1, 'mall_integral', 0, 'admin-mall-integral-product', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2301 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2302, 2300, 1, 'md-add-circle', '添加积分商品', 'admin', 'marketing.store_integral', 'create', '', '', '[]', 90, 1, 0, 1, '/admin-shop/marketing/store_integral/create', '2300', 1, 'mall_integral', 0, 'admin-mall-integral-create', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2302 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2303, 2300, 1, 'md-reorder', '兑换订单', 'admin', 'marketing.store_integral', 'order_list', '', '', '[]', 80, 1, 0, 1, '/admin-shop/marketing/store_integral/order_list', '2300', 1, 'mall_integral', 0, 'admin-mall-integral-order', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2303 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2304, 2300, 1, 'md-settings', '积分配置', 'admin', 'marketing.integral', 'system_config', '', '', '[]', 70, 1, 0, 1, '/admin-shop/marketing/integral/system_config/3/11', '2300', 1, 'mall_integral', 0, 'admin-mall-integral-config', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2304 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2305, 2300, 1, 'md-calendar', '积分签到', 'admin', 'marketing.integral', 'signIn', '', '', '[]', 60, 1, 0, 1, '/admin-shop/marketing/integral/signIn', '2300', 1, 'mall_integral', 0, 'admin-mall-integral-sign', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2305 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2306, 2300, 1, 'ios-paper', '积分日志', 'admin', 'marketing.user_point', 'index', '', '', '[]', 50, 1, 0, 1, '/admin-shop/marketing/user_point/index', '2300', 1, 'mall_integral', 0, 'admin-mall-integral-log', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2306 AND `is_del` = 0);


-- ===== 3. 新增「盲盒商城」顶栏（id=2310）=====

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2310, 0, 1, 'md-cube', '盲盒商城', 'admin', 'product.product', 'index', '', '', '[]', 124, 1, 0, 1, '/admin-shop/product/product_list?mall_type=2', '', 1, 'mall_manghe', 1, 'admin-mall-manghe', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2310 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2311, 2310, 1, 'md-list-box', '盲盒商品', 'admin', 'product.product', 'index', '', '', '[]', 100, 1, 0, 1, '/admin-shop/product/product_list?mall_type=2', '2310', 1, 'mall_manghe', 0, 'admin-mall-manghe-product', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2311 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2312, 2310, 1, 'md-add-circle', '添加盲盒商品', 'admin', 'product.product', 'add', '', '', '[]', 90, 1, 0, 1, '/admin-shop/product/add_product', '2310', 1, 'mall_manghe', 0, 'admin-mall-manghe-create', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2312 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2313, 2310, 1, 'md-archive', '开盒记录', 'admin', 'product.product', 'openbox_list', '', '', '[]', 80, 1, 0, 1, '/admin-shop/product/openbox_list', '2310', 1, 'mall_manghe', 0, 'admin-mall-manghe-openbox', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2313 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2314, 2310, 1, 'md-trophy', '盲盒中奖设置', 'admin', 'product.zhongjiangset', 'index', '', '', '[]', 70, 1, 0, 1, '/admin-shop/product/zhongjiangset', '2310', 1, 'mall_manghe', 0, 'admin-mall-manghe-zhongjiang', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2314 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2315, 2310, 1, 'md-gift', '盲盒赠送抽奖中奖设置', 'admin', 'product.choujiang_list', 'index', '', '', '[]', 60, 1, 0, 1, '/admin-shop/product/choujiang_list', '2310', 1, 'mall_manghe', 0, 'admin-mall-manghe-choujiang', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2315 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2316, 2310, 1, 'md-person', '机器人管理', 'admin', 'user.user', 'jiqiren_list', '', '', '[]', 50, 1, 0, 1, '/admin-shop/user/jiqiren_list', '2310', 1, 'mall_manghe', 0, 'admin-mall-manghe-robot', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2316 AND `is_del` = 0);


-- ===== 4. 新增「拼团抽奖」顶栏（id=2320）=====

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2320, 0, 1, 'md-people', '拼团抽奖', 'admin', 'marketing.group_lottery', 'index', '', '', '[]', 123, 1, 0, 1, '/admin-shop/marketing/group_lottery/index', '', 1, 'mall_lottery', 1, 'admin-mall-lottery', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2320 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2321, 2320, 1, 'md-list-box', '抽奖商品', 'admin', 'marketing.group_lottery', 'index', '', '', '[]', 100, 1, 0, 1, '/admin-shop/marketing/group_lottery/index', '2320', 1, 'mall_lottery', 0, 'admin-mall-lottery-product', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2321 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2322, 2320, 1, 'md-add-circle', '添加抽奖', 'admin', 'marketing.group_lottery', 'create', '', '', '[]', 90, 1, 0, 1, '/admin-shop/marketing/group_lottery/create', '2320', 1, 'mall_lottery', 0, 'admin-mall-lottery-create', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2322 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2323, 2320, 1, 'md-list', '拼团列表', 'admin', 'marketing.group_lottery', 'pink_list', '', '', '[]', 80, 1, 0, 1, '/admin-shop/marketing/group_lottery/pink_list', '2320', 1, 'mall_lottery', 0, 'admin-mall-lottery-pink', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2323 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2324, 2320, 1, 'md-close-circle', '取消审核', 'admin', 'marketing.group_lottery', 'cancel_review', '', '', '[]', 70, 1, 0, 1, '/admin-shop/marketing/group_lottery/cancel_review', '2320', 1, 'mall_lottery', 0, 'admin-mall-lottery-cancel', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2324 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2325, 2320, 1, 'md-person', '机器人管理', 'admin', 'marketing.group_lottery', 'robot_list', '', '', '[]', 60, 1, 0, 1, '/admin-shop/marketing/group_lottery/robot_list', '2320', 1, 'mall_lottery', 0, 'admin-mall-lottery-robot', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2325 AND `is_del` = 0);

INSERT INTO `eb_system_menus`
  (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2326, 2320, 1, 'ios-stats', '统计报表', 'admin', 'marketing.group_lottery', 'statistics', '', '', '[]', 50, 1, 0, 1, '/admin-shop/marketing/group_lottery/statistics', '2320', 1, 'mall_lottery', 0, 'admin-mall-lottery-statistics', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `id` = 2326 AND `is_del` = 0);


-- ===== 5. 角色权限追加 =====
-- 给所有 status=1 的角色追加新菜单 id（avoid duplicate via NOT LIKE）
UPDATE `eb_system_role`
SET `rules` = CONCAT(IFNULL(`rules`, ''), ',2300,2301,2302,2303,2304,2305,2306,2310,2311,2312,2313,2314,2315,2316,2320,2321,2322,2323,2324,2325,2326')
WHERE `status` = 1
  AND `rules` <> '*'
  AND `rules` IS NOT NULL
  AND `rules` NOT LIKE '%2300%';


-- ===== 验收 SQL（执行后用此查询确认）=====
-- SELECT id, pid, menu_name, header, is_header, is_show, menu_path FROM eb_system_menus
--   WHERE id=1 OR id=2 OR id=3 OR id=22 OR (id BETWEEN 2300 AND 2326)
--   ORDER BY id;
