# VivoDraw US Consumer Acceptance Sprint - 2026-06-21

## Purpose

Make VivoDraw easier for US consumers to trust before spending money on ads.

This is not a brand manifesto. It is a two-week operating board for one question:

> Can a US shopper understand what VivoDraw sells, why rewards exist, how support works, and why the offer is not sketchy?

## Current Go/No-Go

No public paid traffic yet.

Blocking evidence:

- Public `vivodraw.com` path is not healthy in the current ops gate.
- Agent growth surface guard is failing because local dirty changes remove `/agent-admin/` route and promo helper APIs.
- `@vivodraw.com` lead email is not proven ready.
- The review demo is not a production landing page.

Blunt version: first fix door, then invite customers. Reverse order is not growth; it is a refund generator.

## Acceptance Principles

US-facing copy should make four things obvious in the first visit:

1. VivoDraw is a product discovery shop first.
2. Rewards and credits stay inside the platform.
3. Blind box mechanics show rules before reveal.
4. Agent recruitment is first-level only and based on platform net profit from qualified orders.

Do not use these claims:

- Guaranteed income.
- Guaranteed prize.
- Cash out points or credits.
- Free money.
- Risk-free.
- Investment.
- Jackpot.
- 40% of revenue.
- Downline or second-level commission.

## Experiment Ledger

Primary tracker:

```bash
docs/growth/us-growth-experiment-ledger-20260621.tsv
```

Distribution and measurement tracker:

```bash
docs/growth/us-growth-distribution-ledger-20260621.tsv
```

Validation:

```bash
bash deploy/ops/check_us_growth_experiments.sh
bash deploy/ops/check_us_growth_distribution.sh
```

Each experiment must define:

- Channel.
- Audience.
- Hypothesis.
- Asset.
- Landing path.
- CTA.
- Status.
- Gate required.
- Success signal.
- Risk.
- Owner next action.

Each distribution row must define:

- Channel and placement.
- Source asset.
- Gate required before public use.
- UTM source and campaign.
- Budget and paid-traffic flag.
- Success metric.
- Review cycle.

If an experiment cannot name a success signal, it is not an experiment. It is content cosplay.
If a distribution row cannot name measurement, it is not growth. It is yelling into fog with a logo.

## Two-Week Sprint

Day 1-2: Trust baseline.

- Run `deploy/ops/vivodraw_daily_ops_report.sh`.
- Do not publish paid CTA until public domain and agent surface gates are green.
- Collect screenshots for homepage, product detail, rewards, blind box rules, support/refund path.

Day 3-4: Copy and page clarity.

- Rewrite first screen around product discovery, not points mechanics.
- Make rewards non-cash language visible.
- Make shipping, refund, support, and business identity easier to find.

Day 5-7: Organic assets.

- Build one product discovery short.
- Build one blind-box transparency short.
- Build one agent recruitment review cut only if agent surface is restored.

Day 8-10: Lead capture and measurement.

- Verify form or inbox before any CTA.
- Add source labels for each organic post.
- Record clicks, leads, comments, and failure questions.

Day 11-14: Decision.

- Keep experiments where users ask product/rules questions.
- Kill experiments where users ask if it is scam, gambling, cashout, or guaranteed income.
- Only consider paid traffic after public gates pass.

## Daily Operating Rule

Every growth idea must pass this order:

1. System gate.
2. Trust gate.
3. Copy compliance gate.
4. Organic test.
5. Paid spend.

Skipping steps is allowed only if the owner explicitly approves the risk. The default answer is no, because ad platforms accept money even when the funnel is broken. Very generous of them.
