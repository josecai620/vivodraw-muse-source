<?php
/**
 * 临时脚本：将「排版管理」移到「首页装修」下
 * 用法：在 backend_src 目录执行 php deploy/run_move_layout.php
 * 或：docker exec -i crmeb-app php /var/www/html/deploy/run_move_layout.php
 */
$root = dirname(__DIR__);
require $root . '/vendor/autoload.php';
$app = new \think\App($root);
$app->initialize();
$sql = "UPDATE eb_system_menus SET pid = 657, path = '12/656/657', is_header = 0 WHERE menu_path = '/admin/setting/pages/layout' AND is_del = 0";
$n = \think\facade\Db::execute($sql);
echo "Updated $n row(s). Done.\n";
