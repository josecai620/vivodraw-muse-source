# 第三方 API Key 审计

**审计时间**：2026-04-20
**目标环境**：生产服 `8.166.115.27` DB `manghehoutai_qhe`
**核心发现**：有一处 **严重误标注**；多处 **中国服务商 key 仍残留**，不适合美国市场。

---

## 🔴 CRITICAL — 必须先改

### 1. `claude_api_key` 实际是 **Kimi** 的 key

存储位置：`eb_pet_config.cfg_key='claude_api_key'`

```
claude_api_key  = <redacted>
api_base_url    = https://api.kimi.com/coding/v1
provider        = openai_compatible
model           = kimi-k2-turbo-preview
```

- 名字是 `claude_api_key` 但 token 前缀 `sk-kimi-...` 是 Moonshot Kimi 的
- `api_base_url` 是 `api.kimi.com`，不是 `api.anthropic.com`
- **误标注**会让接手的人以为配对的是 Anthropic Claude，实际没有 Claude 能力

**修复选项**：
- **方案 A（改名 + 保留 Kimi）**：把 key 改名为 `kimi_api_key`，接受这是 Kimi 供应商
- **方案 B（切 Claude）**：申请真 Anthropic API key，改 `api_base_url` 为 `https://api.anthropic.com/v1`，改 model 为 `claude-sonnet-4-5`（或当前稳定版），改 `provider` 仍为 `anthropic` 并更新 PetAI 调用代码
- **美国上线建议**：方案 B。中国 AI 服务商给 US 用户使用法律/合规不清晰。

---

## 🟠 HIGH — 中国服务商残留（US 市场不用，应清零）

| key | 当前值 | 提供商 | 处理 |
|-----|--------|--------|------|
| `alipay_merchant_private_key` | 2048-bit RSA 私钥明文 | 支付宝 | **清空**，US 用 Stripe |
| `alipay_public_key` | 2048-bit RSA 公钥 | 支付宝 | 清空 |
| `ali_pay_appid` | `<redacted>` | 支付宝 | 清空 |
| `pay_weixin_key` | `<redacted>` | 微信支付 | 清空 |
| `pay_weixin_mchid` | `<redacted>` | 微信支付 | 清空 |
| `pay_weixin_client_key` | `.pem` 证书路径 | 微信支付 | 清空并删文件 |
| `tengxun_map_key` | `<redacted>` | 腾讯地图 | 清空，改 Google Maps 或 Mapbox |
| `wechat_app_*` | 空/未用 | 微信开放平台 | — 已空 ✓ |

**注意**：`alipay_merchant_private_key` 是**真实 RSA 私钥**，已经以明文存在数据库里。即便不用，也要立刻清掉（泄露就能冒签订单）。

---

## 🟡 MEDIUM — 需要确认 or 替换

| key | 当前值 | 提供商 | 处理 |
|-----|--------|--------|------|
| `accessKey` | `<redacted>` | 阿里云 OSS | 图床 US 市场不建议，但真要用需改成 AWS S3 或 Cloudflare R2 |
| `secretKey` | `<redacted>` | 阿里云 OSS 配对 | 同上 |
| `cj_api_key` | `<redacted>` | CJ Dropshipping | **US 市场可能用**，确认后决定 |
| `openapi_key` | `<redacted>` | 未知 | 查代码，标来源 |
| `sms_account` / `sms_token` | `<redacted>` / `<redacted>` | 未知 SMS（看号码是 CN） | 换 Twilio 或 AWS SNS |
| `site_email` | 空 | — | 上线前必配（Sendgrid/SES） |
| `pay_weixin_client_key` 文件路径 | `/uploads/attach/2023/12/...` | 微信支付证书 | 若留着 → 公开目录里放密钥文件 = 泄露风险 |

---

## 🔵 INFO — `.env` 级别配置（服务器当前状态）

```ini
[APP]
DEFAULT_TIMEZONE = Asia/Shanghai    # ⚠️ US 市场应改 America/New_York 或 UTC
APP_KEY = <redacted>   # ⚠️ 与本地 .env 不一致；本地是 <redacted>...

[LANG]
default_lang = zh-cn                # ⚠️ i18n 硬约束说主=英文，应改 en-us
```

**APP_KEY 要不要同步**：本地 .env 已轮换过，服务器还是旧值。轮换服务器 APP_KEY 会**使所有活跃用户 session 失效**（强制重登）。建议在一次计划停机窗口内做。

---

## 🔓 密钥文件系统层检查

```bash
# 已发现微信支付证书放在 public/uploads/ 下 → Web 可访问
/uploads/attach/2023/12/20231215/70e641f386c7292fbfab1d86ffa4e84c.pem
```

**验证**：任何人访问 `https://<domain>/uploads/attach/2023/12/20231215/70e641f386c7292fbfab1d86ffa4e84c.pem` 都能下载这个证书？若能，这是 **立即的商户证书泄露事件**。需要：
1. Nginx 加规则禁止 `.pem` 下载
2. 移到 `public/` 之外的安全目录
3. 若确认过泄露窗口 → 微信商户后台吊销旧证书重发

---

## 推荐清理 SQL（等 joe 确认后执行）

```sql
USE manghehoutai_qhe;

-- 支付宝 / 微信支付全部清零
UPDATE eb_system_config SET value='""' WHERE menu_name IN (
  'alipay_merchant_private_key',
  'alipay_public_key',
  'ali_pay_appid',
  'pay_weixin_key',
  'pay_weixin_mchid',
  'pay_weixin_client_key'
);

-- 腾讯地图 key
UPDATE eb_system_config SET value='""' WHERE menu_name IN (
  'tengxun_map_key', 'tengxun_appid', 'tengxun_accessKey', 'tengxun_secretKey'
);

-- AI 配置：改名 + 占位
UPDATE eb_pet_config
  SET cfg_value = 'REPLACE_WITH_ANTHROPIC_API_KEY'
  WHERE cfg_key = 'claude_api_key';
UPDATE eb_pet_config
  SET cfg_value = 'https://api.anthropic.com/v1'
  WHERE cfg_key = 'api_base_url';
UPDATE eb_pet_config
  SET cfg_value = 'anthropic'
  WHERE cfg_key = 'provider';
UPDATE eb_pet_config
  SET cfg_value = 'claude-sonnet-4-5'
  WHERE cfg_key = 'model';

-- 验证
SELECT menu_name, value FROM eb_system_config WHERE menu_name IN (
  'alipay_merchant_private_key', 'pay_weixin_key', 'tengxun_map_key'
);
SELECT cfg_key, LEFT(cfg_value,60) FROM eb_pet_config WHERE cfg_key IN (
  'claude_api_key', 'api_base_url', 'provider', 'model'
);
```

---

## 上线前 Must-Have 替换清单

对照美国市场：

| 功能 | 供应商替换 | 需要的 key |
|-----|-----------|----------|
| 支付 | Stripe | `STRIPE_SECRET_KEY` (`<redacted>`), `STRIPE_WEBHOOK_SECRET` (`<redacted>`) |
| 邮件 | SendGrid 或 Amazon SES | API key |
| 短信 | Twilio 或 AWS SNS | Account SID + Auth Token |
| 地图 | Google Maps 或 Mapbox | Static API key |
| 对象存储 | AWS S3 或 Cloudflare R2 | Access key + Secret |
| AI 客服 | Anthropic Claude | `sk-ant-api03-...` |
| 错误监控（推荐） | Sentry | DSN |

---

## 待办（上线前闭环）

- [ ] 确认并执行上面 SQL（joe 亲手点）
- [ ] 检查并移出 `.pem` 文件（微信商户证书）
- [ ] 在 .env 加 `STRIPE_SECRET_KEY`、`ANTHROPIC_API_KEY`、`SENDGRID_KEY`、`TWILIO_*` 等环境变量读取
- [ ] 改 `backend_src/.env` 的 `DEFAULT_TIMEZONE` 和 `default_lang`
- [ ] 计划停机窗口轮换服务器 `APP_KEY`（会强制所有用户重登）
