# -*- coding: utf-8 -*-
"""T26 专用：独立目录上传，避免和其他窗抢 /tmp/v4-root-part-*。"""
import os
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

key = os.path.expanduser(r"~\.ssh\vivodraw_windows_ed25519")
host = "root@186.241.72.176"
port = "49375"
ssh = [
    "ssh", "-i", key, "-p", port,
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
    "-o", "ServerAliveInterval=15",
    host,
]
scp = [
    "scp", "-O", "-i", key, "-P", port,
    "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes",
]
bundle = Path(r"D:\eccomall\deploy\v4-root-bundle.tar.gz")
chunks_dir = Path(r"D:\eccomall\deploy\v4-chunks-t26")
ts = datetime.now().strftime("%Y%m%d_%H%M%S")
prefix = "t26" + ts[-6:]
if not bundle.is_file():
    raise SystemExit("missing bundle")
data = bundle.read_bytes()
if chunks_dir.exists():
    shutil.rmtree(chunks_dir)
chunks_dir.mkdir(parents=True)
size = 1_800_000
parts = []
for i in range(0, len(data), size):
    name = "p%03d" % (i // size)
    (chunks_dir / name).write_bytes(data[i:i + size])
    parts.append(name)
print("ts", ts, "prefix", prefix, "bytes", len(data), "parts", len(parts), flush=True)
subprocess.check_call(ssh + ["rm -rf /tmp/%s; mkdir -p /tmp/%s" % (prefix, prefix)])
for name in parts:
    dest = "%s:/tmp/%s/%s" % (host, prefix, name)
    print("scp", name, flush=True)
    rc = subprocess.call(scp + [str(chunks_dir / name), dest])
    if rc != 0:
        raise SystemExit("scp failed " + name)
    st = subprocess.check_output(
        ssh + ["stat -c %%s /tmp/%s/%s" % (prefix, name)], timeout=30
    ).decode().strip()
    local = str((chunks_dir / name).stat().st_size)
    print("remote", st, "local", local, flush=True)
    if st != local:
        raise SystemExit("size mismatch " + name)
cat_list = " ".join("/tmp/%s/%s" % (prefix, n) for n in parts)
cmd = (
    "set -euo pipefail; "
    "cat %s > /tmp/%s.tar.gz; gzip -t /tmp/%s.tar.gz; "
    "cp -f /tmp/%s.tar.gz /tmp/v4-root-bundle.tar.gz; "
    "ls -l /tmp/v4-root-bundle.tar.gz; "
    "bash /root/remote-release-root.sh %s I_UNDERSTAND_WHOLE_SITE_REPLACEMENT; "
    "bash /root/remote-bump-v4rel.sh %s; "
    "rm -rf /tmp/%s /tmp/%s.tar.gz; "
    "echo LIVE %s"
) % (cat_list, prefix, prefix, prefix, ts, ts, prefix, prefix, ts)
print(subprocess.check_output(ssh + [cmd], timeout=180).decode(errors="replace"), flush=True)
Path(r"D:\eccomall\deploy\.last_ts").write_text(ts, encoding="utf-8")
print("DONE", ts, flush=True)
