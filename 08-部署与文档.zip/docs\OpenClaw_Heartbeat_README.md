# OpenClaw Heartbeat 使用说明

## 概述

`scripts/openclaw_codex_heartbeat.sh` 是 Backend Master 项目的半自动心跳脚本。

**职责：** 定期检查 Codex 总控是否完成了当前 Phase，如果完成则自动生成下一条 Codex 提示词。

**安全保证：** 只读检查 + 写日志/提示词文件，不修改业务代码、不操作数据库、不执行 git push。

---

## 运行方式

```bash
cd /path/to/eccomall
bash scripts/openclaw_codex_heartbeat.sh
```

建议通过 cron 定时运行（每 5 分钟）：

```bash
*/5 * * * * cd /Users/joe/eccomall && bash scripts/openclaw_codex_heartbeat.sh >> tmp/heartbeat_cron.log 2>&1
```

---

## 输出文件

所有输出都在 `tmp/` 目录下：

| 文件 | 说明 |
|------|------|
| `tmp/heartbeat.log` | 运行日志，记录每次检查的结果 |
| `tmp/heartbeat_next_prompt.md` | **下一条 Codex 提示词**（Phase 完成时生成） |
| `tmp/heartbeat_blocked.md` | 高风险阻止报告（检测到风险时生成） |

---

## 运行结果解读

### ✅ 正常完成 — "Phase completed!"

脚本检测到 Codex 已完成当前 Phase（通过最新 handoff 文件或 git 提交）。

**下一步操作：** 把 `tmp/heartbeat_next_prompt.md` 的内容发给 Codex，Codex 会继续推进下一阶段。

### ⏳ 等待中 — "Codex not completed yet"

Codex 尚未完成当前 Phase。

**无需操作。** 脚本会在下次运行时重新检查。

### ⛔ 阻止 — "High-risk keyword detected"

脚本在最新代码中检测到高风险关键词。

**必须等待人工审批。** 阅读 `tmp/heartbeat_blocked.md`，确认风险内容，审批通过后才能继续推进。

---

## 高风险关键词列表

以下关键字触发阻止：

| 关键词 | 风险 |
|--------|------|
| `MangheController` | 盲盒控制器 |
| `real stock` / `real reward` | 真实库存/奖励 |
| `webhook` / `refund` | 支付回调/退款 |
| `blind box` / `group buy` | 盲盒/拼购 |
| `truncate` / `drop table` | 数据删除 |
| `real migration` | 真实迁移 |
| `production deploy` | 生产部署 |

> 注：`payment`/`order`/`inventory` 仅扫描 guards 声明以外的代码区域，避免误报。

---

## 注意事项

1. **不要手动执行 git push** — 脚本只生成提示词，不自动执行任何代码更改或推送
2. **只读设计** — 脚本设计为只读 + 写文件，不碰业务逻辑
3. **建议通过 cron 运行** — 每 5 分钟一次足够，不需要更频繁
4. **生成提示词不等于自动执行** — `heartbeat_next_prompt.md` 需要手动或通过 AutoClaw 发给 Codex
