-- 添加「排版管理」菜单到后台（位于 首页装修 下）
-- 执行方式：mysql -u用户 -p 数据库名 < add_layout_menu.sql
-- 或通过 phpmyadmin / 宝塔 等导入

-- 若已存在则跳过（根据 menu_path 判断）
INSERT INTO `eb_system_menus` (`id`, `pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT 2000, 657, 1, 'md-apps', '排版管理', 'admin', '', '', '', '', '[]', 1, 1, 0, 1, '/admin/setting/pages/layout', '12/656/657', 1, 'devise', 0, 'admin-setting-pages-devise', 0
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/setting/pages/layout' AND `is_del` = 0);
