-- Fix product edit unit table dependencies.
-- Safe to rerun.

CREATE TABLE IF NOT EXISTS `eb_store_integral_product_unit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '单位名称',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否上架',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `idx_name_del` (`name`,`is_del`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='积分商品单位表';

SET @add_product_unit_remark = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_store_product_unit` ADD COLUMN `remark` varchar(100) NOT NULL DEFAULT '''' COMMENT ''备注''',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_product_unit'
    AND COLUMN_NAME = 'remark'
);
PREPARE stmt FROM @add_product_unit_remark;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @add_integral_unit_remark = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product_unit` ADD COLUMN `remark` varchar(100) NOT NULL DEFAULT '''' COMMENT ''备注''',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_integral_product_unit'
    AND COLUMN_NAME = 'remark'
);
PREPARE stmt FROM @add_integral_unit_remark;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

INSERT INTO `eb_store_product_unit` (`store_id`,`name`,`sort`,`status`,`is_del`,`add_time`,`remark`)
SELECT 0,'件',100,1,0,UNIX_TIMESTAMP(),'Piece'
WHERE NOT EXISTS (SELECT 1 FROM `eb_store_product_unit` WHERE `name`='件' AND `is_del`=0);

INSERT INTO `eb_store_integral_product_unit` (`store_id`,`name`,`sort`,`status`,`is_del`,`add_time`,`remark`)
SELECT 0,'件',100,1,0,UNIX_TIMESTAMP(),'Piece'
WHERE NOT EXISTS (SELECT 1 FROM `eb_store_integral_product_unit` WHERE `name`='件' AND `is_del`=0);
