-- 从 2025-06-29 旧库备份中抽取的纯表结构（已剔除全部 INSERT 数据行）
-- 源: sql_www_sawa_com_20250629_010659.sql.gz

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- MySQL dump 10.13  Distrib 8.0.24, for Linux (x86_64)
--
-- Host: localhost    Database: sql_www_sawa_com
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `eb_agent_level`
--

DROP TABLE IF EXISTS `eb_agent_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_agent_level` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '等级名称',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '背景图',
  `one_brokerage` smallint NOT NULL DEFAULT '0' COMMENT '一级分拥比例',
  `two_brokerage` smallint NOT NULL DEFAULT '0' COMMENT '二级分拥比例',
  `grade` smallint NOT NULL DEFAULT '0' COMMENT '等级',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`is_del`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='分销员等级表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_agent_level`
--

/*!40000 ALTER TABLE `eb_agent_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_agent_level_task`
--

DROP TABLE IF EXISTS `eb_agent_level_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_agent_level_task` (
  `id` int NOT NULL AUTO_INCREMENT,
  `level_id` int NOT NULL DEFAULT '0' COMMENT '分销等级id',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '任务名称',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '任务类型',
  `number` int NOT NULL DEFAULT '0' COMMENT '任务限定数',
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '任务描述',
  `is_must` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否必须达成0:其一1:所有',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='分销员等级任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_agent_level_task`
--

/*!40000 ALTER TABLE `eb_agent_level_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_agent_level_task_record`
--

DROP TABLE IF EXISTS `eb_agent_level_task_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_agent_level_task_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `level_id` int NOT NULL DEFAULT '0' COMMENT '等级id',
  `task_id` int NOT NULL DEFAULT '0' COMMENT '任务id',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `add_time` int NOT NULL DEFAULT '10' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COMMENT='分销员完成等级任务表记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_agent_level_task_record`
--

/*!40000 ALTER TABLE `eb_agent_level_task_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_agreement`
--

DROP TABLE IF EXISTS `eb_agreement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_agreement` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '协议类型  1：会员协议',
  `title` varchar(200) NOT NULL DEFAULT '' COMMENT '协议名称',
  `content` text COMMENT '协议内容',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序倒序',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '1：显示：0：不显示',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `type` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='会员协议';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_agreement`
--

/*!40000 ALTER TABLE `eb_agreement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_article`
--

DROP TABLE IF EXISTS `eb_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_article` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '文章管理ID',
  `cid` varchar(255) NOT NULL DEFAULT '1' COMMENT '分类id',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '文章标题',
  `author` varchar(255) NOT NULL DEFAULT '' COMMENT '文章作者',
  `image_input` varchar(255) NOT NULL DEFAULT '' COMMENT '文章图片',
  `synopsis` varchar(255) NOT NULL DEFAULT '' COMMENT '文章简介',
  `share_title` varchar(255) NOT NULL DEFAULT '' COMMENT '文章分享标题',
  `share_synopsis` varchar(255) NOT NULL DEFAULT '' COMMENT '文章分享简介',
  `visit` varchar(255) NOT NULL DEFAULT '0' COMMENT '浏览次数',
  `sort` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '原文链接',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` varchar(255) NOT NULL DEFAULT '' COMMENT '添加时间',
  `hide` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `admin_id` int unsigned NOT NULL DEFAULT '0' COMMENT '管理员id',
  `mer_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商户id',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品关联id',
  `is_hot` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否热门(小程序)',
  `is_banner` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否轮播图(小程序)',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='文章管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_article`
--

/*!40000 ALTER TABLE `eb_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_article_category`
--

DROP TABLE IF EXISTS `eb_article_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_article_category` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '文章分类id',
  `pid` int NOT NULL DEFAULT '0' COMMENT '父级ID',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '文章分类标题',
  `intr` varchar(255) NOT NULL DEFAULT '' COMMENT '文章分类简介',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '文章分类图片',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `sort` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '1删除0未删除',
  `add_time` varchar(255) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `hidden` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='文章分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_article_category`
--

/*!40000 ALTER TABLE `eb_article_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_article_content`
--

DROP TABLE IF EXISTS `eb_article_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_article_content` (
  `nid` int unsigned NOT NULL DEFAULT '0' COMMENT '文章id',
  `content` longtext COMMENT '文章内容',
  UNIQUE KEY `nid` (`nid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='文章内容表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_article_content`
--

/*!40000 ALTER TABLE `eb_article_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_box_order`
--

DROP TABLE IF EXISTS `eb_box_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_box_order` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(255) DEFAULT '' COMMENT '订单编号',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '分类ID',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '单价',
  `num` int NOT NULL DEFAULT '0' COMMENT '数量',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `pay_money` decimal(10,2) DEFAULT '0.00' COMMENT '支付金额',
  `pay_status` tinyint(1) DEFAULT '0' COMMENT '支付状态',
  `pay_time` int DEFAULT '0' COMMENT '支付时间',
  `createtime` int NOT NULL COMMENT '创建时间',
  `cate_image` varchar(255) DEFAULT NULL,
  `cate_name` varchar(255) DEFAULT NULL,
  `pay_type` varchar(255) DEFAULT '',
  `is_jiqiren` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是机器人下单',
  `user_coupon_id` int NOT NULL DEFAULT '0' COMMENT '用户优惠券ID',
  `coupon_id` int NOT NULL DEFAULT '0' COMMENT '优惠券ID',
  `discounts_money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '打折金额',
  `point_deduction_num` int NOT NULL DEFAULT '0' COMMENT '积分抵扣数量',
  `point_deduction_money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '积分抵扣金额',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1922856 DEFAULT CHARSET=utf8mb3 COMMENT='盲盒订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_box_order`
--

/*!40000 ALTER TABLE `eb_box_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_cache`
--

DROP TABLE IF EXISTS `eb_cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_cache` (
  `key` varchar(32) NOT NULL DEFAULT '',
  `result` longtext COMMENT '缓存数据',
  `expire_time` int NOT NULL DEFAULT '0' COMMENT '失效时间0=永久',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '缓存时间',
  PRIMARY KEY (`key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='微信缓存表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_cache`
--

/*!40000 ALTER TABLE `eb_cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_capital_flow`
--

DROP TABLE IF EXISTS `eb_capital_flow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_capital_flow` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '编号',
  `flow_id` varchar(32) NOT NULL DEFAULT '' COMMENT '流水id',
  `order_id` varchar(50) NOT NULL DEFAULT '' COMMENT '关联id',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户id',
  `nickname` varchar(255) NOT NULL DEFAULT '' COMMENT '昵称',
  `phone` varchar(20) NOT NULL DEFAULT '' COMMENT '电话',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '交易金额',
  `trading_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '交易类型',
  `pay_type` varchar(32) NOT NULL DEFAULT '' COMMENT '支付类型',
  `mark` varchar(500) NOT NULL DEFAULT '' COMMENT '备注',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '交易时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='资金流水表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_capital_flow`
--

/*!40000 ALTER TABLE `eb_capital_flow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_category`
--

DROP TABLE IF EXISTS `eb_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` int NOT NULL DEFAULT '0' COMMENT '上级id',
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `owner_id` int NOT NULL DEFAULT '0' COMMENT '所属人，为全部',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分类名称',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `group` tinyint(1) NOT NULL DEFAULT '0' COMMENT '分类类型0=标签分类，1=快捷短语分类,2=商品标签分类，3=商品参数模版,4=企业渠道码',
  `other` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '其他参数',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `name` (`name`(191)),
  KEY `is_be` (`owner_id`,`type`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='标签分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_category`
--

/*!40000 ALTER TABLE `eb_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_city_area`
--

DROP TABLE IF EXISTS `eb_city_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_city_area` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(128) NOT NULL DEFAULT '/' COMMENT '省市级别',
  `parent_id` int NOT NULL DEFAULT '0' COMMENT '父级id',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '类型',
  `level` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '级别',
  `snum` int unsigned NOT NULL DEFAULT '0' COMMENT '子级个数',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '名称',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `parent_id` (`parent_id`) USING BTREE,
  KEY `path` (`path`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=59046 DEFAULT CHARSET=utf8mb3 COMMENT='城市数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_city_area`
--

/*!40000 ALTER TABLE `eb_city_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_delivery_service`
--

DROP TABLE IF EXISTS `eb_delivery_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_delivery_service` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `uid` int NOT NULL DEFAULT '0' COMMENT '配送员uid',
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `avatar` varchar(250) NOT NULL DEFAULT '' COMMENT '配送员头像',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '配送员名称',
  `phone` varchar(20) NOT NULL DEFAULT '0' COMMENT '手机号码',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '0隐藏1显示',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`,`is_del`,`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='配送员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_delivery_service`
--

/*!40000 ALTER TABLE `eb_delivery_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_diy`
--

DROP TABLE IF EXISTS `eb_diy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_diy` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL DEFAULT '' COMMENT '版本号',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '页面名称',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '网站标题',
  `cover_image` varchar(255) NOT NULL DEFAULT '' COMMENT '封面图',
  `template_name` varchar(255) NOT NULL DEFAULT '' COMMENT '模板名称',
  `value` longtext COMMENT '页面数据',
  `default_value` longtext COMMENT '默认数据',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否使用',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '页面类型',
  `is_show` tinyint(1) NOT NULL DEFAULT '0' COMMENT '显示首页',
  `is_bg_color` tinyint(1) NOT NULL DEFAULT '0' COMMENT '颜色是否选中',
  `is_bg_pic` tinyint(1) NOT NULL DEFAULT '0' COMMENT '背景图是否选中',
  `is_diy` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是diy数据',
  `color_picker` varchar(50) NOT NULL DEFAULT '' COMMENT '背景颜色',
  `bg_pic` varchar(256) NOT NULL DEFAULT '' COMMENT '背景图',
  `bg_tab_val` tinyint(1) NOT NULL DEFAULT '0' COMMENT '背景图图片样式',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `order_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '个人中心订单样式',
  `my_banner_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '个人中心banner是否显示',
  `menu_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '个人中心菜单样式',
  `service_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '商家样式',
  PRIMARY KEY (`id`),
  KEY `template_name` (`template_name`(191),`type`) USING BTREE,
  KEY `status_type` (`status`,`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='DIY数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_diy`
--

/*!40000 ALTER TABLE `eb_diy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_express`
--

DROP TABLE IF EXISTS `eb_express`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_express` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '快递公司id',
  `code` varchar(50) NOT NULL DEFAULT '' COMMENT '快递公司简称',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '快递公司全称',
  `partner_id` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否需要月结账号',
  `partner_key` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否需要月结密码',
  `net` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否需要取件网店',
  `account` varchar(100) NOT NULL DEFAULT '' COMMENT '账号',
  `key` varchar(100) NOT NULL DEFAULT '' COMMENT '密码',
  `net_name` varchar(100) NOT NULL DEFAULT '' COMMENT '网点名称',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `is_show` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否可用',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `code` (`code`) USING BTREE,
  KEY `is_show` (`is_show`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='快递公司表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_express`
--

/*!40000 ALTER TABLE `eb_express` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_integral_category`
--

DROP TABLE IF EXISTS `eb_integral_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_integral_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` int NOT NULL DEFAULT '0' COMMENT '上级id',
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `owner_id` int NOT NULL DEFAULT '0' COMMENT '所属人，为全部',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '分类名称',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `group` tinyint(1) NOT NULL DEFAULT '0' COMMENT '分类类型0=标签分类，1=快捷短语分类,2=商品标签分类，3=商品参数模版,4=企业渠道码',
  `other` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '其他参数',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `name` (`name`(191)),
  KEY `is_be` (`owner_id`,`type`,`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='标签分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_integral_category`
--

/*!40000 ALTER TABLE `eb_integral_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_live_anchor`
--

DROP TABLE IF EXISTS `eb_live_anchor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_live_anchor` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '主播名称',
  `cover_img` varchar(255) NOT NULL DEFAULT '' COMMENT '主播图像',
  `wechat` varchar(50) NOT NULL DEFAULT '' COMMENT '主播微信号',
  `phone` varchar(32) NOT NULL DEFAULT '' COMMENT '手机号',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='直播主播表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_live_anchor`
--

/*!40000 ALTER TABLE `eb_live_anchor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_live_goods`
--

DROP TABLE IF EXISTS `eb_live_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_live_goods` (
  `id` int NOT NULL AUTO_INCREMENT,
  `goods_id` int NOT NULL DEFAULT '0' COMMENT '微信商品ID',
  `audit_id` int NOT NULL DEFAULT '0' COMMENT '审核ID',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '商品名称',
  `cover_img` varchar(255) NOT NULL DEFAULT '' COMMENT '商品图片链接',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '商品小程序链接',
  `price_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '价格类型（1:一口价，此时读price字段; 2:价格区间，此时price字段为左边界，price2字段为右边界; 3:折扣价，此时price字段为原价，price2字段为现价；）',
  `cost_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `price2` decimal(10,2) NOT NULL DEFAULT '0.00',
  `audit_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '审核状态（0：未审核，1：审核中，2:审核通过，3审核失败）',
  `third_part_tag` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1、2：表示是为 API 添加商品，否则是直播控制台添加的商品',
  `sort` smallint NOT NULL DEFAULT '0',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='直播商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_live_goods`
--

/*!40000 ALTER TABLE `eb_live_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_live_room`
--

DROP TABLE IF EXISTS `eb_live_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_live_room` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `room_id` int unsigned NOT NULL DEFAULT '0' COMMENT '直播间 id',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '直播间名字',
  `cover_img` varchar(255) NOT NULL DEFAULT '' COMMENT '背景图',
  `share_img` varchar(255) NOT NULL DEFAULT '' COMMENT '分享图',
  `start_time` int NOT NULL DEFAULT '0' COMMENT '直播计划开始时间',
  `end_time` int NOT NULL DEFAULT '0' COMMENT '直播计划结束时间',
  `anchor_name` varchar(50) NOT NULL DEFAULT '' COMMENT '主播昵称',
  `anchor_wechat` varchar(50) NOT NULL DEFAULT '' COMMENT '主播微信号',
  `phone` varchar(32) NOT NULL DEFAULT '' COMMENT '主播手机号',
  `type` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '直播间类型 【1: 推流，0：手机直播】',
  `screen_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '横屏、竖屏 【1：横屏，0：竖屏】',
  `close_like` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否关闭点赞',
  `close_goods` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否关闭货架',
  `close_comment` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否关闭评论',
  `error_msg` varchar(255) NOT NULL DEFAULT '' COMMENT '未通过原因',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '审核状态0=未审核1=微信审核2=审核通过-1=审核未通过',
  `live_status` smallint unsigned NOT NULL DEFAULT '102' COMMENT '直播状态101：直播中，102：未开始，103已结束，104禁播，105：暂停，106：异常，107：已过期',
  `mark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `replay_status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '回放状态',
  `sort` smallint NOT NULL DEFAULT '0',
  `is_show` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`,`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='直播间表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_live_room`
--

/*!40000 ALTER TABLE `eb_live_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_live_room_goods`
--

DROP TABLE IF EXISTS `eb_live_room_goods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_live_room_goods` (
  `live_room_id` int unsigned NOT NULL DEFAULT '0',
  `live_goods_id` int unsigned NOT NULL DEFAULT '0',
  KEY `broadcast_room_id` (`live_room_id`,`live_goods_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='直播间导入商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_live_room_goods`
--

/*!40000 ALTER TABLE `eb_live_room_goods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_luck_lottery`
--

DROP TABLE IF EXISTS `eb_luck_lottery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_luck_lottery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '抽奖类型1:九宫格2：大转盘3：九宫格升级版 4：幸运翻牌',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '抽奖活动名称',
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '活动描述',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '活动背景图',
  `factor` tinyint(1) NOT NULL DEFAULT '1' COMMENT '抽奖消耗：1:积分2：余额3：下单支付成功4：订单评价5：关注公众号',
  `factor_num` smallint NOT NULL DEFAULT '10' COMMENT '获取一次抽奖的条件数量',
  `attends_user` tinyint(1) NOT NULL DEFAULT '1' COMMENT '参与用户1：所有2：部分',
  `user_level` text COMMENT '参与用户等级',
  `user_label` text COMMENT '参与用户标签',
  `is_svip` tinyint(1) NOT NULL DEFAULT '1' COMMENT '参与用户是否付费会员',
  `prize_num` smallint NOT NULL DEFAULT '0' COMMENT '奖品数量',
  `start_time` int NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end_time` int NOT NULL DEFAULT '0' COMMENT '结束时间',
  `lottery_num_term` tinyint(1) NOT NULL DEFAULT '1' COMMENT '抽奖次数限制：1：每天2：每人',
  `lottery_num` smallint NOT NULL DEFAULT '1' COMMENT '抽奖次数',
  `spread_num` smallint NOT NULL DEFAULT '1' COMMENT '关注推广获取抽奖次数',
  `is_all_record` tinyint(1) NOT NULL DEFAULT '1' COMMENT '中奖纪录展示',
  `is_personal_record` tinyint(1) NOT NULL DEFAULT '1' COMMENT '个人中奖纪录展示',
  `is_content` tinyint(1) NOT NULL DEFAULT '1' COMMENT '活动规格是否展示',
  `content` longtext COMMENT '活动文案抽奖协议之类',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `type` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='抽奖活动表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_luck_lottery`
--

/*!40000 ALTER TABLE `eb_luck_lottery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_luck_lottery_record`
--

DROP TABLE IF EXISTS `eb_luck_lottery_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_luck_lottery_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `lottery_id` int NOT NULL DEFAULT '0' COMMENT '活动id',
  `prize_id` int NOT NULL DEFAULT '0' COMMENT '奖品id',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '奖品类型1：未中奖2：积分3:余额4：红包5:优惠券6：站内商品7：等级经验8：用户等级 9：svip天数',
  `is_receive` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否领取',
  `receive_time` int NOT NULL DEFAULT '0' COMMENT '领取时间',
  `receive_info` text COMMENT '收获地址、备注等',
  `is_deliver` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否发货',
  `deliver_time` int NOT NULL DEFAULT '0' COMMENT '发货处理时间',
  `deliver_info` text COMMENT '发货单号、备注等',
  `add_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `prize_id` (`prize_id`),
  KEY `lottery_id` (`lottery_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='抽奖记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_luck_lottery_record`
--

/*!40000 ALTER TABLE `eb_luck_lottery_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_luck_prize`
--

DROP TABLE IF EXISTS `eb_luck_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_luck_prize` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '奖品主键id',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '奖品类型1：未中奖2：积分3:余额4：红包5:优惠券6：站内商品7：等级经验8：用户等级 9：svip天数',
  `lottery_id` int NOT NULL DEFAULT '0' COMMENT '抽奖活动id',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '奖品名称',
  `prompt` varchar(255) NOT NULL DEFAULT '' COMMENT '中奖提示语',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '奖品图片',
  `chance` smallint NOT NULL DEFAULT '10' COMMENT '中奖基数',
  `total` smallint NOT NULL DEFAULT '1' COMMENT '奖品数量',
  `coupon_id` int NOT NULL DEFAULT '0' COMMENT '关联优惠券id',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '关联商品id',
  `unique` varchar(20) NOT NULL DEFAULT '' COMMENT '关联商品规格唯一值',
  `num` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '积分 经验 会员天数',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `lottery_id` (`lottery_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='抽奖活动奖品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_luck_prize`
--

/*!40000 ALTER TABLE `eb_luck_prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_member_card`
--

DROP TABLE IF EXISTS `eb_member_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_member_card` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `card_batch_id` int unsigned NOT NULL DEFAULT '0' COMMENT '卡批次id',
  `card_number` varchar(20) NOT NULL DEFAULT '' COMMENT '卡号',
  `card_password` char(12) NOT NULL DEFAULT '' COMMENT '密码',
  `use_uid` int NOT NULL DEFAULT '0' COMMENT '使用用户',
  `use_time` int NOT NULL DEFAULT '0' COMMENT '使用时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '卡状态：0：冻结；1：激活',
  `add_time` int NOT NULL DEFAULT '0',
  `update_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`card_batch_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='会员卡表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_member_card`
--

/*!40000 ALTER TABLE `eb_member_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_member_card_batch`
--

DROP TABLE IF EXISTS `eb_member_card_batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_member_card_batch` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '0' COMMENT '批次名称',
  `total_num` int unsigned NOT NULL DEFAULT '0' COMMENT '生成卡数量',
  `use_start_time` int unsigned NOT NULL DEFAULT '7' COMMENT '体验开始时间',
  `use_end_time` int NOT NULL DEFAULT '0' COMMENT '体验结束时间',
  `use_day` int NOT NULL DEFAULT '0' COMMENT '体验天数',
  `use_num` int unsigned NOT NULL DEFAULT '0' COMMENT '使用',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否生效,控制此批次所有卡0：不生效；1：生效',
  `sort` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `qrcode` varchar(255) NOT NULL DEFAULT '' COMMENT '二维码图路径',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `add_time` int NOT NULL DEFAULT '0',
  `update_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='会员卡批次表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_member_card_batch`
--

/*!40000 ALTER TABLE `eb_member_card_batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_member_right`
--

DROP TABLE IF EXISTS `eb_member_right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_member_right` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `right_type` varchar(100) NOT NULL DEFAULT '' COMMENT '权益类别',
  `title` varchar(200) NOT NULL DEFAULT '' COMMENT ' 权益名称',
  `show_title` varchar(255) NOT NULL DEFAULT '' COMMENT '显示权益名称',
  `image` varchar(200) NOT NULL DEFAULT '' COMMENT '权益图标',
  `explain` varchar(1024) NOT NULL DEFAULT '' COMMENT '权益介绍',
  `number` int NOT NULL DEFAULT '1' COMMENT '规则数字',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序倒序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0:禁用，1：启用',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`,`right_type`) USING BTREE,
  KEY `type` (`right_type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='会员权益';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_member_right`
--

/*!40000 ALTER TABLE `eb_member_right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_member_ship`
--

DROP TABLE IF EXISTS `eb_member_ship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_member_ship` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL DEFAULT 'month' COMMENT '会员类别month:月卡会员；quarter:季卡；year:年卡；ever:永久；free:免费',
  `title` varchar(200) NOT NULL DEFAULT '' COMMENT '会员名称',
  `vip_day` int NOT NULL DEFAULT '0' COMMENT '会员时间(天)',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '原价',
  `pre_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '优惠后价格',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序倒序',
  `is_del` int NOT NULL DEFAULT '0' COMMENT '删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='会员类型';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_member_ship`
--

/*!40000 ALTER TABLE `eb_member_ship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_other_order`
--

DROP TABLE IF EXISTS `eb_other_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_other_order` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `staff_id` int NOT NULL DEFAULT '0' COMMENT '店员ID',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户uid',
  `type` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '区别 \r\n0：免费领取\r\n1：购买会员卡 \r\n2：卡密领取会员卡 \r\n3：收银订单 \r\n4：管理员赠送',
  `order_id` varchar(32) NOT NULL DEFAULT '' COMMENT '订单号',
  `member_type` varchar(10) NOT NULL DEFAULT '' COMMENT '会员类型 \r\n月卡：month\r\n季卡：quarter\r\n年卡：year\r\n永久：ever\r\n免费：free',
  `code` varchar(20) NOT NULL DEFAULT '' COMMENT '卡号',
  `pay_type` varchar(32) NOT NULL DEFAULT '' COMMENT '支付方式',
  `paid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '支付状态 0:  未支付 1：已支付',
  `pay_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '支付金额',
  `member_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '会员卡价格',
  `pay_time` int unsigned NOT NULL DEFAULT '0' COMMENT '会员购买时间',
  `trade_no` varchar(50) NOT NULL DEFAULT '' COMMENT '支付宝支付,支付宝交易订单号',
  `channel_type` varchar(10) NOT NULL DEFAULT '' COMMENT '支付渠道(微信公众号 h5 小程序)',
  `is_free` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否免费',
  `is_permanent` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否永久',
  `overdue_time` bigint unsigned NOT NULL DEFAULT '0' COMMENT '会员过期时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  `vip_day` int NOT NULL DEFAULT '0' COMMENT '会员有效天数',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `money` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '原价格',
  `remarks` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='会员购买记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_other_order`
--

/*!40000 ALTER TABLE `eb_other_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_other_order_status`
--

DROP TABLE IF EXISTS `eb_other_order_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_other_order_status` (
  `oid` int unsigned NOT NULL DEFAULT '0' COMMENT '订单id',
  `change_type` varchar(32) NOT NULL DEFAULT '' COMMENT '操作类型',
  `change_message` varchar(256) NOT NULL DEFAULT '' COMMENT '操作备注',
  `shop_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '订单类型 1：会员卡',
  `change_time` int NOT NULL DEFAULT '0',
  KEY `oid` (`oid`) USING BTREE,
  KEY `change_type` (`change_type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='订单操作记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_other_order_status`
--

/*!40000 ALTER TABLE `eb_other_order_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_out_account`
--

DROP TABLE IF EXISTS `eb_out_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_out_account` (
  `id` int NOT NULL AUTO_INCREMENT,
  `appid` varchar(50) NOT NULL DEFAULT '' COMMENT '账号',
  `appsecret` varchar(100) NOT NULL DEFAULT '' COMMENT '密钥',
  `title` varchar(200) NOT NULL DEFAULT '' COMMENT '描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `last_time` int NOT NULL DEFAULT '0' COMMENT '最后一次登录时间',
  `ip` varchar(30) NOT NULL DEFAULT '' COMMENT 'IP',
  `is_del` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='对外接口账号';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_out_account`
--

/*!40000 ALTER TABLE `eb_out_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_out_interface`
--

DROP TABLE IF EXISTS `eb_out_interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_out_interface` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `pid` int NOT NULL DEFAULT '0' COMMENT '父级pid',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0菜单，1接口',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '接口名称',
  `describe` text COMMENT '功能描述',
  `method` varchar(255) NOT NULL DEFAULT '' COMMENT '接口类型',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '接口地址',
  `request_params` longtext COMMENT '请求参数',
  `return_params` longtext COMMENT '返回参数',
  `request_example` longtext COMMENT '请求示例',
  `return_example` longtext COMMENT '返回示例',
  `error_code` longtext COMMENT '错误返回',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='对外接口';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_out_interface`
--

/*!40000 ALTER TABLE `eb_out_interface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_page_category`
--

DROP TABLE IF EXISTS `eb_page_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_page_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` int NOT NULL DEFAULT '0' COMMENT '父类id',
  `type` varchar(50) NOT NULL DEFAULT 'link' COMMENT '类型:link、special、product、product_category、custom',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '分类名称',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COMMENT='页面链接分类';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_page_category`
--

/*!40000 ALTER TABLE `eb_page_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_page_link`
--

DROP TABLE IF EXISTS `eb_page_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_page_link` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '分类id',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '分组1:基础2:分销3:个人中心',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '页面名称',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '页面链接',
  `param` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `example` varchar(255) NOT NULL DEFAULT '' COMMENT '事例',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3 COMMENT='页面链接';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_page_link`
--

/*!40000 ALTER TABLE `eb_page_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_qrcode`
--

DROP TABLE IF EXISTS `eb_qrcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_qrcode` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '微信二维码ID',
  `third_type` varchar(32) NOT NULL DEFAULT '' COMMENT '二维码类型',
  `third_id` int unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `ticket` varchar(255) NOT NULL DEFAULT '' COMMENT '二维码参数',
  `expire_seconds` int unsigned NOT NULL DEFAULT '0' COMMENT '二维码有效时间',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` varchar(255) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '微信访问url',
  `qrcode_url` varchar(255) NOT NULL DEFAULT '' COMMENT '微信二维码url',
  `scan` int unsigned NOT NULL DEFAULT '0' COMMENT '被扫的次数',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '二维码所属平台1=小程序，2=公众号，3=H5',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `third_type` (`third_type`,`third_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=COMPACT COMMENT='微信二维码管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_qrcode`
--

/*!40000 ALTER TABLE `eb_qrcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_queue_auxiliary`
--

DROP TABLE IF EXISTS `eb_queue_auxiliary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_queue_auxiliary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `binding_id` int NOT NULL DEFAULT '0' COMMENT '绑定id',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联id',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型0=客服转接辅助，1=商品和分类辅助，2=优惠券和商品辅助',
  `other` varchar(2048) NOT NULL DEFAULT '' COMMENT '其他数据为json',
  `status` int unsigned NOT NULL DEFAULT '0' COMMENT '数据状态 0：未执行，1：成功， 2：失败， 3:删除',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_queue_auxiliary`
--

/*!40000 ALTER TABLE `eb_queue_auxiliary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_queue_list`
--

DROP TABLE IF EXISTS `eb_queue_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_queue_list` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '队列类型  1：批量发放用户优惠券 2 : 批量设置用户分组, 3:批量设置用户标签, 4:批量下架商品, 5:批量删除商品规格, 6:批量删除订单, 7:批量手动发货, 8:批量打印电子面单, 9:批量配送, 10:批量虚拟发货',
  `source` varchar(5) NOT NULL DEFAULT 'admin' COMMENT '来源 前端：home ，后端：admin',
  `execute_key` varchar(512) NOT NULL DEFAULT '' COMMENT '队列执行数据缓存key',
  `title` varchar(200) NOT NULL DEFAULT '' COMMENT ' 队列名称',
  `queue_in_value` text COMMENT '队列参数',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序倒序',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 :尚未执行，1：正在执行，2：执行成功, 3:执行失败,4: 删除的异常队列',
  `first_time` int unsigned NOT NULL DEFAULT '0' COMMENT '首次执行时间',
  `again_time` int unsigned NOT NULL DEFAULT '0' COMMENT '再次执行时间',
  `finish_time` int unsigned NOT NULL DEFAULT '0' COMMENT '完成时间',
  `surplus_num` int unsigned NOT NULL DEFAULT '0' COMMENT '剩余未执行数量',
  `total_num` int unsigned NOT NULL DEFAULT '0' COMMENT ' 总数量',
  `is_del` tinyint(1) NOT NULL DEFAULT '0',
  `add_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`type`,`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='任务列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_queue_list`
--

/*!40000 ALTER TABLE `eb_queue_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_shipping_templates`
--

DROP TABLE IF EXISTS `eb_shipping_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_shipping_templates` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '编号',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '模板名称',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '计费方式',
  `appoint` tinyint(1) NOT NULL DEFAULT '0' COMMENT '指定包邮',
  `no_delivery` tinyint(1) NOT NULL DEFAULT '0' COMMENT '指定不送达',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='运费模板表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_shipping_templates`
--

/*!40000 ALTER TABLE `eb_shipping_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_shipping_templates_free`
--

DROP TABLE IF EXISTS `eb_shipping_templates_free`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_shipping_templates_free` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '编号',
  `province_id` int NOT NULL DEFAULT '0' COMMENT '省ID',
  `temp_id` int NOT NULL DEFAULT '0' COMMENT '模板ID',
  `city_id` int NOT NULL DEFAULT '0' COMMENT '城市ID',
  `number` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '包邮件数',
  `price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '包邮金额',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '计费方式',
  `value` varchar(200) NOT NULL DEFAULT '',
  `uniqid` varchar(32) NOT NULL DEFAULT '' COMMENT '分组唯一值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='运费模板指定包邮关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_shipping_templates_free`
--

/*!40000 ALTER TABLE `eb_shipping_templates_free` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_shipping_templates_no_delivery`
--

DROP TABLE IF EXISTS `eb_shipping_templates_no_delivery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_shipping_templates_no_delivery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `province_id` int NOT NULL DEFAULT '0' COMMENT '省ID',
  `temp_id` int NOT NULL DEFAULT '0' COMMENT '模板ID',
  `city_id` int NOT NULL DEFAULT '0' COMMENT '城市ID',
  `value` varchar(200) NOT NULL DEFAULT '',
  `uniqid` varchar(32) NOT NULL DEFAULT '' COMMENT '分组唯一值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='运费模板指定不送达表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_shipping_templates_no_delivery`
--

/*!40000 ALTER TABLE `eb_shipping_templates_no_delivery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_shipping_templates_region`
--

DROP TABLE IF EXISTS `eb_shipping_templates_region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_shipping_templates_region` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '编号',
  `province_id` int NOT NULL DEFAULT '0' COMMENT '省ID',
  `temp_id` int NOT NULL DEFAULT '0' COMMENT '模板ID',
  `city_id` int NOT NULL DEFAULT '0' COMMENT '城市ID',
  `first` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '首件',
  `first_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '首件运费',
  `continue` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '续件',
  `continue_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '续件运费',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '计费方式',
  `value` varchar(200) NOT NULL DEFAULT '',
  `uniqid` varchar(32) NOT NULL DEFAULT '' COMMENT '分组唯一值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='运费模板指定城市运费表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_shipping_templates_region`
--

/*!40000 ALTER TABLE `eb_shipping_templates_region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_sms_record`
--

DROP TABLE IF EXISTS `eb_sms_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_sms_record` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '短信发送记录编号',
  `uid` varchar(255) NOT NULL DEFAULT '' COMMENT '短信平台账号',
  `phone` char(11) NOT NULL DEFAULT '' COMMENT '接受短信的手机号',
  `content` text COMMENT '短信内容',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '发送短信时间',
  `add_ip` varchar(16) NOT NULL DEFAULT '' COMMENT '添加记录ip',
  `template` varchar(255) NOT NULL DEFAULT '' COMMENT '短信模板ID',
  `resultcode` int unsigned NOT NULL DEFAULT '0' COMMENT '状态码 100=成功,130=失败,131=空号,132=停机,133=关机,134=无状态',
  `record_id` int unsigned NOT NULL DEFAULT '0' COMMENT '发送记录id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='短信发送记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_sms_record`
--

/*!40000 ALTER TABLE `eb_sms_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_activity`
--

DROP TABLE IF EXISTS `eb_store_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_activity` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:秒杀',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '活动名称',
  `image` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '氛围图片',
  `start_day` int NOT NULL DEFAULT '0' COMMENT '开始日期',
  `end_day` int NOT NULL DEFAULT '0' COMMENT '结束日期',
  `start_time` int unsigned DEFAULT NULL COMMENT '开始时间',
  `end_time` int unsigned DEFAULT NULL COMMENT '结束时间',
  `time_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '时间段ID多个',
  `once_num` int unsigned DEFAULT '0' COMMENT '活动期间每人每日购买数量，0不限制',
  `num` int unsigned DEFAULT '0' COMMENT '全部活动期间，用户购买总数限制，0不限制',
  `discount` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '优惠方式',
  `status` tinyint unsigned DEFAULT '0' COMMENT '是否显示',
  `is_recommend` tinyint unsigned DEFAULT '0' COMMENT '是否推荐',
  `link_id` int unsigned DEFAULT '0' COMMENT '关联ID',
  `applicable_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '适用门店：0：仅平台1：所有2：部分',
  `applicable_store_id` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '适用门店ids',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `start_day` (`start_day`,`end_day`) USING BTREE,
  KEY `start_time` (`start_time`,`end_time`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='活动表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_activity`
--

/*!40000 ALTER TABLE `eb_store_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_activity_relation`
--

DROP TABLE IF EXISTS `eb_store_activity_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_activity_relation` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `activity_id` int unsigned NOT NULL,
  `product_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`activity_id`,`product_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='活动关联表中间表(多对多)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_activity_relation`
--

/*!40000 ALTER TABLE `eb_store_activity_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_bargain`
--

DROP TABLE IF EXISTS `eb_store_bargain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_bargain` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '砍价商品ID',
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '关联商品ID',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型0:普通商品，1：卡密，2：优惠券，3：虚拟商品',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '砍价活动名称',
  `image` varchar(150) NOT NULL DEFAULT '' COMMENT '砍价活动图片',
  `unit_name` varchar(16) NOT NULL DEFAULT '' COMMENT '单位名称',
  `stock` int unsigned NOT NULL DEFAULT '0' COMMENT '库存',
  `sales` int unsigned NOT NULL DEFAULT '0' COMMENT '销量',
  `images` varchar(2000) NOT NULL DEFAULT '' COMMENT '砍价商品轮播图',
  `start_time` int unsigned NOT NULL DEFAULT '0' COMMENT '砍价开启时间',
  `stop_time` int unsigned NOT NULL DEFAULT '0' COMMENT '砍价结束时间',
  `store_name` varchar(255) NOT NULL DEFAULT '' COMMENT '砍价商品名称',
  `price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '砍价金额',
  `min_price` decimal(12,2) unsigned DEFAULT '0.00' COMMENT '砍价商品最低价',
  `num` int unsigned NOT NULL DEFAULT '1' COMMENT '可购买砍价商品数量',
  `bargain_max_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '用户每次砍价的最大金额',
  `bargain_min_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '用户每次砍价的最小金额',
  `bargain_num` int unsigned NOT NULL DEFAULT '1' COMMENT '用户帮砍的次数',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '砍价状态 0(到砍价时间不自动开启)  1(到砍价时间自动开启时间)',
  `give_integral` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '反多少积分',
  `info` varchar(255) NOT NULL DEFAULT '' COMMENT '砍价活动简介',
  `cost` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '成本价',
  `sort` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `is_hot` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否推荐0不推荐1推荐',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否删除 0未删除 1删除',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_postage` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '是否包邮 0不包邮 1包邮',
  `postage` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '邮费',
  `rule` text COMMENT '砍价规则',
  `look` int unsigned NOT NULL DEFAULT '0' COMMENT '砍价商品浏览量',
  `share` int unsigned NOT NULL DEFAULT '0' COMMENT '砍价商品分享量',
  `temp_id` int NOT NULL DEFAULT '0' COMMENT '运费模板ID',
  `weight` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '重量',
  `volume` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '体积',
  `quota` int NOT NULL DEFAULT '0' COMMENT '限购总数',
  `quota_show` int NOT NULL DEFAULT '0' COMMENT '限量总数显示',
  `people_num` int NOT NULL DEFAULT '1' COMMENT '用户帮砍的次数',
  `is_support_refund` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否支持退款',
  `delivery_type` varchar(10) NOT NULL DEFAULT '' COMMENT '物流类型',
  `freight` tinyint(1) NOT NULL DEFAULT '2' COMMENT '运费设置',
  `custom_form` longtext COMMENT '自定义表单',
  `store_label_id` longtext COMMENT '商品标签iDS',
  `ensure_id` longtext COMMENT '商品保障服务ids',
  `specs` longtext COMMENT '商品参数',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `is_del` (`is_del`,`status`,`product_id`,`start_time`,`stop_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='砍价表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_bargain`
--

/*!40000 ALTER TABLE `eb_store_bargain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_bargain_user`
--

DROP TABLE IF EXISTS `eb_store_bargain_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_bargain_user` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '用户参与砍价表ID',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `bargain_id` int unsigned NOT NULL DEFAULT '0' COMMENT '砍价商品id',
  `bargain_price_min` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '砍价的最低价',
  `bargain_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '砍价金额',
  `price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '砍掉的价格',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '状态 1参与中 2 活动结束参与失败 3活动结束参与成功',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '参与时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否取消',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户参与砍价表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_bargain_user`
--

/*!40000 ALTER TABLE `eb_store_bargain_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_bargain_user_help`
--

DROP TABLE IF EXISTS `eb_store_bargain_user_help`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_bargain_user_help` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '砍价用户帮助表ID',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '帮助的用户id',
  `bargain_id` int unsigned NOT NULL DEFAULT '0' COMMENT '砍价商品ID',
  `bargain_user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '用户参与砍价表id',
  `price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '帮助砍价多少金额',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否自己砍价',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='砍价用户帮助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_bargain_user_help`
--

/*!40000 ALTER TABLE `eb_store_bargain_user_help` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_branch_product`
--

DROP TABLE IF EXISTS `eb_store_branch_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_branch_product` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '商品图片',
  `store_name` varchar(128) NOT NULL DEFAULT '' COMMENT '商品名称',
  `store_info` varchar(255) NOT NULL DEFAULT '' COMMENT '商品简介',
  `keyword` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `bar_code` varchar(15) NOT NULL DEFAULT '' COMMENT '商品条码（一维码)',
  `cate_id` varchar(64) NOT NULL DEFAULT '' COMMENT '分类id',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `sales` int NOT NULL DEFAULT '0' COMMENT '销量',
  `stock` int NOT NULL DEFAULT '0' COMMENT '库存',
  `sort` int NOT NULL DEFAULT '0',
  `label_id` varchar(50) NOT NULL DEFAULT '' COMMENT '标签id',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '上下架',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='门店商品辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_branch_product`
--

/*!40000 ALTER TABLE `eb_store_branch_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_branch_product_attr_value`
--

DROP TABLE IF EXISTS `eb_store_branch_product_attr_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_branch_product_attr_value` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `unique` char(8) NOT NULL DEFAULT '' COMMENT '唯一值',
  `sales` int NOT NULL DEFAULT '0' COMMENT '销量',
  `stock` int NOT NULL DEFAULT '0' COMMENT '库存',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `bar_code` varchar(50) NOT NULL DEFAULT '' COMMENT '条形码',
  `code` varchar(50) NOT NULL DEFAULT '' COMMENT '商品编码',
  PRIMARY KEY (`id`),
  KEY `code` (`code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='门店商品属性值辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_branch_product_attr_value`
--

/*!40000 ALTER TABLE `eb_store_branch_product_attr_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_brand`
--

DROP TABLE IF EXISTS `eb_store_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_brand` (
  `id` int NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(100) NOT NULL DEFAULT '' COMMENT '品牌名称',
  `pid` int NOT NULL DEFAULT '0' COMMENT '父ID',
  `fid` varchar(64) NOT NULL DEFAULT '' COMMENT '父ID集合 ',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示	',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COMMENT='品牌表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_brand`
--

/*!40000 ALTER TABLE `eb_store_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_cart`
--

DROP TABLE IF EXISTS `eb_store_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_cart` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '购物车表ID',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `tourist_uid` varchar(50) NOT NULL DEFAULT '' COMMENT '游客uid',
  `type` smallint NOT NULL DEFAULT '0' COMMENT '类型 0:普通、1：秒杀、2:砍价、3:拼团、4:积分、5:套餐',
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品ID',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型',
  `activity_id` int NOT NULL DEFAULT '0' COMMENT '活动商品ID',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `staff_id` int NOT NULL DEFAULT '0' COMMENT '店员id',
  `product_attr_unique` varchar(16) NOT NULL DEFAULT '' COMMENT '商品属性',
  `cart_num` smallint unsigned NOT NULL DEFAULT '0' COMMENT '商品数量',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_pay` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = 未购买 1 = 已购买',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `is_new` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为立即购买',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '购物车商品状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `goods_id` (`product_id`) USING BTREE,
  KEY `uid` (`uid`,`is_pay`) USING BTREE,
  KEY `uid_2` (`uid`,`is_del`) USING BTREE,
  KEY `uid_3` (`uid`,`is_new`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=COMPACT COMMENT='购物车表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_cart`
--

/*!40000 ALTER TABLE `eb_store_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_category`
--

DROP TABLE IF EXISTS `eb_store_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_category` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '商品分类表ID',
  `pid` int NOT NULL DEFAULT '0' COMMENT '父id',
  `cate_name` varchar(100) NOT NULL DEFAULT '' COMMENT '分类名称',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `pic` varchar(128) NOT NULL DEFAULT '' COMMENT '图标',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否推荐',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `big_pic` varchar(255) NOT NULL DEFAULT '' COMMENT '分类大图',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '价格',
  `product_id` int DEFAULT '0' COMMENT '赠送抽奖ID',
  `price3` decimal(10,2) DEFAULT '0.00' COMMENT '三连价格',
  `price5` decimal(10,2) DEFAULT '0.00' COMMENT '五连价格',
  `price10` decimal(10,2) DEFAULT '0.00' COMMENT '十连价格',
  `tag1` decimal(10,3) NOT NULL DEFAULT '0.000' COMMENT '标签',
  `tag2` decimal(10,3) NOT NULL DEFAULT '0.000',
  `tag3` decimal(10,3) NOT NULL DEFAULT '0.000',
  `tag4` decimal(10,3) NOT NULL DEFAULT '0.000',
  `box_pic` varchar(255) DEFAULT '' COMMENT '盒柜页图片',
  `ot_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '一抽原价',
  `subtitle` varchar(255) DEFAULT '' COMMENT '副标题',
  `sale` int NOT NULL DEFAULT '0' COMMENT '销售',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `is_base` (`is_show`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_category`
--

/*!40000 ALTER TABLE `eb_store_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_combination`
--

DROP TABLE IF EXISTS `eb_store_combination`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_combination` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品id',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型0:普通商品，1：卡密，2：优惠券，3：虚拟商品',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `mer_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商户id',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '推荐图',
  `images` varchar(2000) NOT NULL DEFAULT '' COMMENT '轮播图',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '活动标题',
  `attr` varchar(255) NOT NULL DEFAULT '' COMMENT '活动属性',
  `people` int unsigned NOT NULL DEFAULT '0' COMMENT '参团人数',
  `info` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '价格',
  `sort` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `sales` int unsigned NOT NULL DEFAULT '0' COMMENT '销量',
  `stock` int unsigned NOT NULL DEFAULT '0' COMMENT '库存',
  `add_time` varchar(128) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_host` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '推荐',
  `is_show` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '商品状态',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0',
  `combination` tinyint unsigned NOT NULL DEFAULT '1',
  `mer_use` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '商户是否可用1可用0不可用',
  `is_postage` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否包邮1是0否',
  `postage` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '邮费',
  `start_time` int unsigned NOT NULL DEFAULT '0' COMMENT '拼团开始时间',
  `stop_time` int unsigned NOT NULL DEFAULT '0' COMMENT '拼团结束时间',
  `effective_time` int NOT NULL DEFAULT '0' COMMENT '拼团订单有效时间',
  `cost` int unsigned NOT NULL DEFAULT '0' COMMENT '拼图商品成本',
  `browse` int NOT NULL DEFAULT '0' COMMENT '浏览量',
  `unit_name` varchar(32) NOT NULL DEFAULT '' COMMENT '单位名',
  `temp_id` int NOT NULL DEFAULT '0' COMMENT '运费模板ID',
  `weight` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '重量',
  `volume` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '体积',
  `num` int NOT NULL DEFAULT '0' COMMENT '单次购买数量',
  `once_num` int NOT NULL DEFAULT '0' COMMENT '每个订单可购买数量',
  `quota` int NOT NULL DEFAULT '0' COMMENT '限购总数',
  `quota_show` int NOT NULL DEFAULT '0' COMMENT '限量总数显示',
  `virtual` int NOT NULL DEFAULT '100' COMMENT '虚拟成团百分比',
  `is_support_refund` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否支持退款',
  `delivery_type` varchar(10) NOT NULL DEFAULT '' COMMENT '物流类型',
  `freight` tinyint(1) NOT NULL DEFAULT '2' COMMENT '运费设置',
  `custom_form` longtext COMMENT '自定义表单',
  `store_label_id` longtext COMMENT '商品标签iDS',
  `ensure_id` longtext COMMENT '商品保障服务ids',
  `specs` longtext COMMENT '商品参数',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='拼团商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_combination`
--

/*!40000 ALTER TABLE `eb_store_combination` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_config`
--

DROP TABLE IF EXISTS `eb_store_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '配置key',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `value` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '值',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key_name`,`store_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='门店配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_config`
--

/*!40000 ALTER TABLE `eb_store_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_coupon_issue`
--

DROP TABLE IF EXISTS `eb_store_coupon_issue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_coupon_issue` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `cid` int NOT NULL DEFAULT '0' COMMENT '优惠券ID',
  `type` tinyint NOT NULL DEFAULT '0' COMMENT '优惠券类型 0-通用 1-品类券 2-商品券',
  `receive_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 手动领取，2 新人券，3赠送券，4会员券',
  `coupon_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:满减券2:折扣券',
  `coupon_title` varchar(255) NOT NULL DEFAULT '' COMMENT '优惠券名称',
  `start_time` int NOT NULL DEFAULT '0' COMMENT '优惠券领取开启时间',
  `end_time` int NOT NULL DEFAULT '0' COMMENT '优惠券领取结束时间',
  `total_count` int NOT NULL DEFAULT '0' COMMENT '优惠券领取数量',
  `remain_count` int NOT NULL DEFAULT '0' COMMENT '优惠券剩余领取数量',
  `is_permanent` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否无限张数',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 正常 0 未开启 -1 已无效',
  `is_give_subscribe` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否首次关注赠送 0-否(默认) 1-是',
  `is_full_give` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否满赠0-否(默认) 1-是',
  `full_reduction` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '消费满多少赠送优惠券',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '优惠券添加时间',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '优惠券名称',
  `integral` int unsigned NOT NULL DEFAULT '0' COMMENT '兑换消耗积分值',
  `coupon_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '兑换的优惠券面值',
  `use_min_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '最低消费多少金额可用优惠券',
  `coupon_time` int unsigned NOT NULL DEFAULT '0' COMMENT '优惠券有效期限（单位：天）',
  `product_id` text COMMENT '所属商品id',
  `category_id` int NOT NULL DEFAULT '0' COMMENT '分类id',
  `start_use_time` int NOT NULL DEFAULT '0' COMMENT '优惠券使用开始时间',
  `end_use_time` int NOT NULL DEFAULT '0' COMMENT '优惠券使用结束时间',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `start_time` (`start_time`,`end_time`) USING BTREE,
  KEY `remain_count` (`remain_count`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `is_del` (`is_del`) USING BTREE,
  KEY `receive_type` (`receive_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=COMPACT COMMENT='优惠券前台领取表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_coupon_issue`
--

/*!40000 ALTER TABLE `eb_store_coupon_issue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_coupon_issue_user`
--

DROP TABLE IF EXISTS `eb_store_coupon_issue_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_coupon_issue_user` (
  `uid` int DEFAULT '0' COMMENT '领取优惠券用户ID',
  `issue_coupon_id` int NOT NULL DEFAULT '0' COMMENT '优惠券前台领取ID',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '领取时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='优惠券前台用户领取记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_coupon_issue_user`
--

/*!40000 ALTER TABLE `eb_store_coupon_issue_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_coupon_product`
--

DROP TABLE IF EXISTS `eb_store_coupon_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_coupon_product` (
  `coupon_id` int NOT NULL DEFAULT '0' COMMENT '优惠卷模板id',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  KEY `coupon_id` (`coupon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='优惠卷模板关联列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_coupon_product`
--

/*!40000 ALTER TABLE `eb_store_coupon_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_coupon_user`
--

DROP TABLE IF EXISTS `eb_store_coupon_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_coupon_user` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '优惠券发放记录id',
  `cid` int unsigned NOT NULL DEFAULT '0' COMMENT '兑换的项目id',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '优惠券所属用户',
  `coupon_title` varchar(32) NOT NULL DEFAULT '' COMMENT '优惠券名称',
  `coupon_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '优惠券的面值',
  `use_min_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '最低消费多少金额可用优惠券',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '优惠券创建时间',
  `start_time` int NOT NULL DEFAULT '0',
  `end_time` int unsigned NOT NULL DEFAULT '0' COMMENT '优惠券结束时间',
  `use_time` int unsigned NOT NULL DEFAULT '0' COMMENT '使用时间',
  `type` varchar(32) NOT NULL DEFAULT 'send' COMMENT '获取方式',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态（0：未使用，1：已使用, 2:已过期）',
  `is_fail` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否有效',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cid` (`cid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `end_time` (`end_time`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `is_fail` (`is_fail`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1217 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='优惠券发放记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_coupon_user`
--

/*!40000 ALTER TABLE `eb_store_coupon_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_delivery_order`
--

DROP TABLE IF EXISTS `eb_store_delivery_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_delivery_order` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint NOT NULL DEFAULT '0' COMMENT '商品所属：0：平台1:门店2:供应商',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联门店、供应商ID',
  `oid` int unsigned NOT NULL COMMENT '订单ID',
  `uid` int unsigned NOT NULL DEFAULT '0',
  `station_type` int unsigned NOT NULL COMMENT '平台类型',
  `order_id` varchar(32) NOT NULL DEFAULT '' COMMENT '订单ID',
  `delivery_no` varchar(255) NOT NULL DEFAULT '' COMMENT '配送方订单号',
  `city_code` varchar(20) NOT NULL DEFAULT '' COMMENT '所属城市',
  `cargo_price` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '配送订单价格',
  `finish_code` varchar(255) NOT NULL DEFAULT '' COMMENT '收货码',
  `user_name` varchar(20) NOT NULL DEFAULT '' COMMENT '用户名',
  `receiver_phone` varchar(11) NOT NULL DEFAULT '' COMMENT '收货人电话',
  `from_address` varchar(255) NOT NULL DEFAULT '' COMMENT '起始位置',
  `to_address` varchar(255) NOT NULL DEFAULT '' COMMENT '结束位置',
  `from_lat` varchar(255) NOT NULL DEFAULT '',
  `from_lng` varchar(255) NOT NULL DEFAULT '',
  `to_lat` varchar(255) NOT NULL DEFAULT '',
  `to_lng` varchar(255) NOT NULL DEFAULT '',
  `distance` float NOT NULL DEFAULT '0' COMMENT '配送距离',
  `fee` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '配送费',
  `deduct_fee` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '取消订单违约金',
  `mer_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商户ID',
  `mark` varchar(255) NOT NULL DEFAULT '' COMMENT '订单备注',
  `status` int NOT NULL DEFAULT '0' COMMENT '状态 取消=-1, 待取货＝2,配送中＝3,已完成＝4,物品返回中=9,物品返回完成=10,骑士到店=100',
  `reason` varchar(255) NOT NULL DEFAULT '' COMMENT '取消原因',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='发货配送订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_delivery_order`
--

/*!40000 ALTER TABLE `eb_store_delivery_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_discounts`
--

DROP TABLE IF EXISTS `eb_store_discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_discounts` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '套餐名称',
  `image` varchar(500) NOT NULL DEFAULT '' COMMENT '组合套餐主图',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '套餐类型0固定1搭配',
  `is_limit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否限量0不限量1限量',
  `limit_num` int NOT NULL DEFAULT '0' COMMENT '限量个数',
  `link_ids` varchar(255) NOT NULL DEFAULT '' COMMENT '关联标签',
  `product_ids` varchar(255) NOT NULL DEFAULT '' COMMENT '商品IDS',
  `is_time` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否限时0不限时1限时',
  `start_time` int NOT NULL DEFAULT '0' COMMENT '开始时间',
  `stop_time` int NOT NULL DEFAULT '0' COMMENT '结束时间',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `free_shipping` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否包邮0不包邮1包邮',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否上架0不上架1上架',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除0未删除1已删除',
  `is_support_refund` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否支持退款',
  `delivery_type` varchar(10) NOT NULL DEFAULT '' COMMENT '物流类型',
  `freight` tinyint(1) NOT NULL DEFAULT '2' COMMENT '运费设置',
  `custom_form` longtext COMMENT '自定义表单',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='组合套餐表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_discounts`
--

/*!40000 ALTER TABLE `eb_store_discounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_discounts_products`
--

DROP TABLE IF EXISTS `eb_store_discounts_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_discounts_products` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `discount_id` int NOT NULL DEFAULT '0' COMMENT '优惠套餐ID',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型0:普通商品，1：卡密，2：优惠券，3：虚拟商品',
  `title` varchar(255) NOT NULL DEFAULT '0' COMMENT '商品名称',
  `image` varchar(500) NOT NULL DEFAULT '' COMMENT '商品图',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否搭配0不是1是',
  `temp_id` int NOT NULL DEFAULT '0' COMMENT '运费模版Id',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='组合套餐商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_discounts_products`
--

/*!40000 ALTER TABLE `eb_store_discounts_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_extract`
--

DROP TABLE IF EXISTS `eb_store_extract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_extract` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `store_id` int unsigned NOT NULL DEFAULT '0' COMMENT '门店ID',
  `store_staff_id` int unsigned NOT NULL DEFAULT '0' COMMENT '门店店员ID',
  `extract_type` varchar(32) NOT NULL DEFAULT 'bank' COMMENT 'bank = 银行卡 alipay = 支付宝wx=微信',
  `bank_code` varchar(32) NOT NULL DEFAULT '0' COMMENT '银行卡',
  `bank_address` varchar(256) NOT NULL DEFAULT '' COMMENT '开户地址',
  `alipay_account` varchar(64) NOT NULL DEFAULT '' COMMENT '支付宝账号',
  `wechat` varchar(15) NOT NULL DEFAULT '' COMMENT '微信号',
  `qrcode_url` varchar(255) NOT NULL DEFAULT '' COMMENT '二维码地址',
  `extract_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '提现金额',
  `mark` varchar(512) NOT NULL DEFAULT '',
  `balance` decimal(12,2) unsigned NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-1 未通过 0 审核中 1 已提现',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 未转账 1 已转账',
  `store_mark` varchar(255) NOT NULL DEFAULT '' COMMENT '门店备注',
  `admin_id` int unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `fail_msg` varchar(128) NOT NULL DEFAULT '' COMMENT '无效原因',
  `fail_time` int unsigned NOT NULL DEFAULT '0',
  `voucher_image` varchar(255) NOT NULL DEFAULT '' COMMENT '转账凭证',
  `voucher_title` varchar(255) NOT NULL DEFAULT '' COMMENT '转账说明',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `store_id` (`store_id`) USING BTREE,
  KEY `extract_type` (`extract_type`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='门店提现表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_extract`
--

/*!40000 ALTER TABLE `eb_store_extract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_finance_flow`
--

DROP TABLE IF EXISTS `eb_store_finance_flow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_finance_flow` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户id',
  `staff_id` int NOT NULL DEFAULT '0' COMMENT '店员id',
  `order_id` varchar(20) NOT NULL DEFAULT '' COMMENT '交易单号',
  `link_id` varchar(50) NOT NULL DEFAULT '' COMMENT '关联订单',
  `pm` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = 支出 1 = 获得',
  `number` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '明细',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '交易类型(1:支付订单,2,门店订单,3,订单手续费,4:退款订单,5:充值返点,6:付费会员返点,7:充值订单,8:付费订单,9:收银订单\r\n)',
  `pay_type` varchar(20) NOT NULL DEFAULT '' COMMENT '支付方式',
  `pay_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '实际支付金额',
  `total_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '订单总金额',
  `rate` smallint NOT NULL DEFAULT '0' COMMENT '费率',
  `trade_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:流水，2：交易',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `mark` varchar(255) NOT NULL DEFAULT '' COMMENT '门店备注',
  `trade_time` int NOT NULL DEFAULT '0' COMMENT '交易时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `store_id` (`store_id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `staff_id` (`staff_id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='门店资金流水表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_finance_flow`
--

/*!40000 ALTER TABLE `eb_store_finance_flow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral`
--

DROP TABLE IF EXISTS `eb_store_integral`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '积分商品ID',
  `image` varchar(256) NOT NULL DEFAULT '' COMMENT '商品图片',
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品id',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型0:普通商品，1：卡密，2：优惠券，3：虚拟商品',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `images` varchar(2000) NOT NULL DEFAULT '' COMMENT '轮播图',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '活动标题',
  `price` int NOT NULL DEFAULT '0' COMMENT '兑换积分',
  `sort` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `sales` int unsigned NOT NULL DEFAULT '0' COMMENT '销量',
  `unit_name` varchar(16) NOT NULL DEFAULT '' COMMENT '单位名',
  `stock` int unsigned NOT NULL DEFAULT '0' COMMENT '库存',
  `add_time` varchar(128) NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_host` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '推荐',
  `is_show` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '商品状态',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '删除',
  `num` int NOT NULL DEFAULT '0' COMMENT '最多积分几个',
  `quota` int NOT NULL DEFAULT '0' COMMENT '限购总数',
  `once_num` int NOT NULL DEFAULT '0' COMMENT '单次购买个数',
  `quota_show` int NOT NULL DEFAULT '0',
  `delivery_type` varchar(10) NOT NULL DEFAULT '' COMMENT '物流类型',
  `freight` tinyint(1) NOT NULL DEFAULT '2' COMMENT '运费设置1：包邮，2：固定运费，3：运费模版',
  `custom_form` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '自定义表单',
  `store_label_id` longtext COMMENT '商品标签iDS',
  `ensure_id` longtext COMMENT '商品保障服务ids',
  `specs` longtext COMMENT '商品参数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COMMENT='积分商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral`
--

/*!40000 ALTER TABLE `eb_store_integral` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_brand`
--

DROP TABLE IF EXISTS `eb_store_integral_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_brand` (
  `id` int NOT NULL AUTO_INCREMENT,
  `brand_name` varchar(100) NOT NULL DEFAULT '' COMMENT '品牌名称',
  `pid` int NOT NULL DEFAULT '0' COMMENT '父ID',
  `fid` varchar(64) NOT NULL DEFAULT '' COMMENT '父ID集合 ',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示	',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COMMENT='品牌表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_brand`
--

/*!40000 ALTER TABLE `eb_store_integral_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_cart`
--

DROP TABLE IF EXISTS `eb_store_integral_cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_cart` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '购物车表ID',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `tourist_uid` varchar(50) NOT NULL DEFAULT '' COMMENT '游客uid',
  `type` smallint NOT NULL DEFAULT '0' COMMENT '类型 0:普通、1：秒杀、2:砍价、3:拼团、4:积分、5:套餐',
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品ID',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型',
  `activity_id` int NOT NULL DEFAULT '0' COMMENT '活动商品ID',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `staff_id` int NOT NULL DEFAULT '0' COMMENT '店员id',
  `product_attr_unique` varchar(16) NOT NULL DEFAULT '' COMMENT '商品属性',
  `cart_num` smallint unsigned NOT NULL DEFAULT '0' COMMENT '商品数量',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_pay` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = 未购买 1 = 已购买',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `is_new` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为立即购买',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '购物车商品状态',
  `bianhao` int DEFAULT '1' COMMENT '商品编号',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `goods_id` (`product_id`) USING BTREE,
  KEY `uid` (`uid`,`is_pay`) USING BTREE,
  KEY `uid_2` (`uid`,`is_del`) USING BTREE,
  KEY `uid_3` (`uid`,`is_new`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=235 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=COMPACT COMMENT='购物车表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_cart`
--

/*!40000 ALTER TABLE `eb_store_integral_cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_category`
--

DROP TABLE IF EXISTS `eb_store_integral_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_category` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '商品分类表ID',
  `pid` int NOT NULL DEFAULT '0' COMMENT '父id',
  `cate_name` varchar(100) NOT NULL DEFAULT '' COMMENT '分类名称',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `pic` varchar(128) NOT NULL DEFAULT '' COMMENT '图标',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否推荐',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `big_pic` varchar(255) NOT NULL DEFAULT '' COMMENT '分类大图',
  `type` int NOT NULL DEFAULT '1' COMMENT '是否是积分换购',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `is_base` (`is_show`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_category`
--

/*!40000 ALTER TABLE `eb_store_integral_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_kaijiang_shaidan_comment`
--

DROP TABLE IF EXISTS `eb_store_integral_kaijiang_shaidan_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_kaijiang_shaidan_comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0',
  `praise` int NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `content` varchar(1000) NOT NULL DEFAULT '' COMMENT '回复内容',
  `pid` int NOT NULL DEFAULT '0' COMMENT '上级回复id',
  `reply_id` int NOT NULL DEFAULT '0' COMMENT '评论id',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `product_id` int DEFAULT '0' COMMENT '商品ID',
  PRIMARY KEY (`id`),
  KEY `reply_id` (`reply_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品评价回复表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_kaijiang_shaidan_comment`
--

/*!40000 ALTER TABLE `eb_store_integral_kaijiang_shaidan_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_kaijiang_shaidan_praise`
--

DROP TABLE IF EXISTS `eb_store_integral_kaijiang_shaidan_praise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_kaijiang_shaidan_praise` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0',
  `shaidan_id` int NOT NULL DEFAULT '0' COMMENT '晒单id',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `product_id` int DEFAULT '0' COMMENT '商品ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品评价回复表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_kaijiang_shaidan_praise`
--

/*!40000 ALTER TABLE `eb_store_integral_kaijiang_shaidan_praise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_order`
--

DROP TABLE IF EXISTS `eb_store_integral_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_order` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_id` varchar(32) NOT NULL DEFAULT '0' COMMENT '订单号',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `real_name` varchar(32) NOT NULL DEFAULT '' COMMENT '用户姓名',
  `user_phone` varchar(18) NOT NULL DEFAULT '' COMMENT '用户电话',
  `user_address` varchar(100) NOT NULL DEFAULT '' COMMENT '详细地址',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `image` varchar(256) NOT NULL DEFAULT '' COMMENT '商品图片',
  `store_name` varchar(128) NOT NULL DEFAULT '' COMMENT '商品名称',
  `suk` varchar(128) NOT NULL DEFAULT '' COMMENT '规格',
  `unique` char(100) NOT NULL DEFAULT '' COMMENT '唯一值',
  `cart_info` longtext COMMENT '积分商品信息',
  `total_num` int unsigned NOT NULL DEFAULT '0' COMMENT '订单商品总数',
  `integral` decimal(10,2) DEFAULT NULL COMMENT '积分单价',
  `total_integral` decimal(10,2) DEFAULT NULL COMMENT '总积分',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `total_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '总积分',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1：待发货；2：待收货；3：已完成；',
  `delivery_name` varchar(64) NOT NULL DEFAULT '' COMMENT '快递名称/送货人姓名',
  `delivery_code` varchar(50) NOT NULL DEFAULT '' COMMENT '快递公司编码',
  `delivery_type` varchar(32) NOT NULL DEFAULT '' COMMENT '发货类型',
  `delivery_id` varchar(64) NOT NULL DEFAULT '' COMMENT '快递单号/手机号',
  `fictitious_content` varchar(500) NOT NULL DEFAULT '' COMMENT '虚拟发货内容',
  `delivery_uid` int NOT NULL DEFAULT '0' COMMENT '配送员id',
  `mark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '管理员备注',
  `mer_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商户ID',
  `is_mer_check` tinyint unsigned NOT NULL DEFAULT '0',
  `is_remind` tinyint unsigned DEFAULT '0' COMMENT '消息提醒',
  `is_system_del` tinyint(1) DEFAULT '0' COMMENT '后台是否删除',
  `channel_type` varchar(255) NOT NULL DEFAULT '' COMMENT '用户访问端标识',
  `province` varchar(255) NOT NULL DEFAULT '' COMMENT '用户省份',
  `express_dump` varchar(502) NOT NULL DEFAULT '' COMMENT '订单面单打印信息',
  `verify_code` varchar(125) NOT NULL DEFAULT '' COMMENT '核销码',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型',
  `virtual_info` varchar(255) NOT NULL DEFAULT '' COMMENT '虚拟商品信息',
  `custom_form` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '自定义表单',
  `paid` int NOT NULL DEFAULT '0' COMMENT '支付状态',
  `trade_no` varchar(100) DEFAULT NULL COMMENT '支付宝订单号',
  `pay_time` int DEFAULT NULL,
  `pay_type` varchar(255) DEFAULT NULL,
  `finish_time` int DEFAULT '0' COMMENT '订单完成事件',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `order_id_2` (`order_id`,`uid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `is_del` (`is_del`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='积分订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_order`
--

/*!40000 ALTER TABLE `eb_store_integral_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_order_status`
--

DROP TABLE IF EXISTS `eb_store_integral_order_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_order_status` (
  `oid` int unsigned NOT NULL DEFAULT '0' COMMENT '订单id',
  `change_type` varchar(32) NOT NULL DEFAULT '' COMMENT '操作类型',
  `change_message` varchar(256) NOT NULL DEFAULT '' COMMENT '操作备注',
  `change_time` int unsigned NOT NULL DEFAULT '0' COMMENT '操作时间',
  KEY `oid` (`oid`) USING BTREE,
  KEY `change_type` (`change_type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='积分订单操作记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_order_status`
--

/*!40000 ALTER TABLE `eb_store_integral_order_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_order_status_kaijiang`
--

DROP TABLE IF EXISTS `eb_store_integral_order_status_kaijiang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_order_status_kaijiang` (
  `oid` int unsigned NOT NULL DEFAULT '0' COMMENT '订单id',
  `change_type` varchar(32) NOT NULL DEFAULT '' COMMENT '操作类型',
  `change_message` varchar(256) NOT NULL DEFAULT '' COMMENT '操作备注',
  `change_time` int unsigned NOT NULL DEFAULT '0' COMMENT '操作时间',
  KEY `oid` (`oid`) USING BTREE,
  KEY `change_type` (`change_type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='积分订单操作记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_order_status_kaijiang`
--

/*!40000 ALTER TABLE `eb_store_integral_order_status_kaijiang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product`
--

DROP TABLE IF EXISTS `eb_store_integral_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product` (
  `id` mediumint NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `xiaci_jiqiren_time` int DEFAULT '0' COMMENT '下次机器人购买时间',
  `is_xinping` tinyint(1) DEFAULT '0' COMMENT '是否新品',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型0:普通商品，1：卡密，2：优惠券，3：虚拟商品',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `mer_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商户Id(0为总后台管理员创建,不为0的时候是商户后台创建)',
  `image` varchar(256) NOT NULL DEFAULT '' COMMENT '商品图片',
  `recommend_image` varchar(256) NOT NULL DEFAULT '' COMMENT '推荐图',
  `slider_image` varchar(2000) NOT NULL DEFAULT '' COMMENT '轮播图',
  `store_name` varchar(128) NOT NULL DEFAULT '' COMMENT '商品名称',
  `store_info` varchar(256) NOT NULL DEFAULT '' COMMENT '商品简介',
  `keyword` varchar(256) NOT NULL DEFAULT '' COMMENT '关键字',
  `bar_code` varchar(15) NOT NULL DEFAULT '' COMMENT '商品条码（一维码）',
  `cate_id` varchar(64) NOT NULL DEFAULT '' COMMENT '分类id',
  `price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '商品价格',
  `vip_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '会员价格',
  `ot_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '市场价',
  `postage` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '邮费',
  `delivery_type` varchar(255) NOT NULL DEFAULT '' COMMENT '商品配送方式',
  `freight` tinyint(1) NOT NULL DEFAULT '2' COMMENT '运费设置',
  `unit_name` varchar(32) NOT NULL DEFAULT '' COMMENT '单位名',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `sales` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '销量',
  `stock` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '库存',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态（0：未上架，1：上架）',
  `is_hot` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否热卖',
  `is_benefit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否优惠',
  `is_best` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否精品',
  `is_new` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否新品',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_postage` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否包邮',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `mer_use` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '商户是否代理 0不可代理1可代理',
  `give_integral` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '获得积分',
  `cost` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '成本价',
  `is_seckill` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '秒杀状态 0 未开启 1已开启',
  `is_bargain` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '砍价状态 0未开启 1开启',
  `is_good` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否优品推荐',
  `is_sub` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否单独分佣',
  `is_vip` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开启会员价格',
  `ficti` mediumint DEFAULT '100' COMMENT '虚拟销量',
  `browse` int NOT NULL DEFAULT '0' COMMENT '浏览量',
  `code_path` varchar(64) NOT NULL DEFAULT '' COMMENT '商品二维码地址(用户小程序海报)',
  `soure_link` varchar(255) NOT NULL DEFAULT '' COMMENT '淘宝京东1688类型',
  `video_link` varchar(500) NOT NULL DEFAULT '' COMMENT '主图视频链接',
  `temp_id` int NOT NULL DEFAULT '1' COMMENT '运费模板ID',
  `spec_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '规格 0单 1多',
  `activity` varchar(255) NOT NULL DEFAULT '' COMMENT '活动显示排序1=秒杀，2=砍价，3=拼团',
  `spu` char(13) NOT NULL DEFAULT '' COMMENT '商品SPU',
  `label_id` varchar(64) NOT NULL DEFAULT '' COMMENT '标签ID',
  `command_word` varchar(255) NOT NULL DEFAULT '' COMMENT '复制口令',
  `recommend_list` varchar(256) NOT NULL DEFAULT '' COMMENT '推荐产品',
  `brand_id` int NOT NULL DEFAULT '0' COMMENT '品牌id',
  `brand_com` varchar(64) NOT NULL DEFAULT '' COMMENT '品牌组合',
  `code` varchar(50) NOT NULL DEFAULT '' COMMENT '编码',
  `is_vip_product` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否会员专属商品',
  `is_presale_product` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否预售商品',
  `presale_start_time` int NOT NULL DEFAULT '0' COMMENT '预售开始时间',
  `presale_end_time` int NOT NULL DEFAULT '0' COMMENT '预售结束时间',
  `presale_day` int NOT NULL DEFAULT '0' COMMENT '预售结束后几天内发货',
  `auto_on_time` int NOT NULL DEFAULT '0' COMMENT '自动上架时间',
  `auto_off_time` int NOT NULL DEFAULT '0' COMMENT '自动下架时间',
  `custom_form` longtext COMMENT '自定义表单',
  `is_support_refund` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否支持退款',
  `store_label_id` longtext COMMENT '商品标签iDS',
  `ensure_id` longtext COMMENT '商品保障服务ids',
  `specs` longtext COMMENT '商品参数',
  `specs_id` int NOT NULL DEFAULT '0' COMMENT '参数模版ID',
  `is_limit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开启限购',
  `limit_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '限购类型1单次限购2永久限购',
  `limit_num` int NOT NULL DEFAULT '0' COMMENT '限购数量',
  `bianhao` int DEFAULT '1' COMMENT '编号',
  `exchange_num` int DEFAULT '0' COMMENT '已兑换数量',
  `jindu_bili` decimal(10,2) DEFAULT '0.00',
  `kouchujifen` int DEFAULT '1' COMMENT '每次扣除积分',
  `is_jiqiren` int DEFAULT '0',
  `jiqiren_jiange_min` int DEFAULT '0',
  `jiqiren_jiange_max` int DEFAULT '0',
  `jiqiren_goods_min_1` int DEFAULT '0',
  `jiqiren_goods_max_1` int DEFAULT '0',
  `jiqiren_goods_min_2` int DEFAULT '0',
  `jiqiren_goods_max_2` int DEFAULT '0',
  `jiqiren_goods_min_3` int DEFAULT '0',
  `jiqiren_goods_max_3` int DEFAULT '0',
  `is_recovery` tinyint NOT NULL DEFAULT '0' COMMENT '是否回收',
  `recovery_price` decimal(10,2) DEFAULT '0.00' COMMENT '回收价格',
  `reference_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '参考价',
  `recovery_discount` int NOT NULL DEFAULT '0' COMMENT '回收价格折扣',
  `lucky_num` int NOT NULL DEFAULT '0' COMMENT '幸运值',
  `min_duihuan_num` int DEFAULT '0' COMMENT '开奖批次最低兑换次数',
  `zhongjiang_jiange_num` int NOT NULL DEFAULT '0' COMMENT '隔几次中一次',
  `zhongjiang_jiange_current` int DEFAULT '0' COMMENT '中间间隔当前间隔次数',
  `is_zhongjiang_gailv_open` tinyint(1) DEFAULT '0' COMMENT '中奖概率开关',
  `is_kami` tinyint(1) DEFAULT '0' COMMENT '是否卡密商品',
  `bizhong_num` int DEFAULT '0' COMMENT '必中抽奖次数',
  `jiqiren_goods_start_1` int DEFAULT '-1' COMMENT '下注1开始时间',
  `jiqiren_goods_start_2` int DEFAULT '-1' COMMENT '下注2开始时间',
  `jiqiren_goods_start_3` int DEFAULT '-1' COMMENT '下注3开始时间',
  `jiqiren_goods_end_1` int DEFAULT '-1' COMMENT '下注1结束时间',
  `jiqiren_goods_end_2` int DEFAULT '-1' COMMENT '下注2结束时间',
  `jiqiren_goods_end_3` int DEFAULT '-1' COMMENT '下注3结束时间',
  `is_box` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否盲盒',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cate_id` (`cate_id`) USING BTREE,
  KEY `is_hot` (`is_hot`) USING BTREE,
  KEY `is_benefit` (`is_benefit`) USING BTREE,
  KEY `is_best` (`is_best`) USING BTREE,
  KEY `is_new` (`is_new`) USING BTREE,
  KEY `toggle_on_sale, is_del` (`is_del`) USING BTREE,
  KEY `price` (`price`) USING BTREE,
  KEY `is_show` (`is_show`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `sales` (`sales`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `is_postage` (`is_postage`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=369 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product`
--

/*!40000 ALTER TABLE `eb_store_integral_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_attr`
--

DROP TABLE IF EXISTS `eb_store_integral_product_attr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_attr` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品ID',
  `attr_name` varchar(32) NOT NULL DEFAULT '' COMMENT '属性名',
  `attr_values` longtext COMMENT '属性值',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '活动类型 0=商品，1=秒杀，2=砍价，3=拼团',
  PRIMARY KEY (`id`),
  KEY `store_id` (`product_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=879 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品属性表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_attr`
--

/*!40000 ALTER TABLE `eb_store_integral_product_attr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_attr_result`
--

DROP TABLE IF EXISTS `eb_store_integral_product_attr_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_attr_result` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品ID',
  `result` longtext COMMENT '商品属性参数',
  `change_time` int unsigned NOT NULL DEFAULT '0' COMMENT '上次修改时间',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '活动类型 0=商品，1=秒杀，2=砍价，3=拼团',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=364 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品属性详情表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_attr_result`
--

/*!40000 ALTER TABLE `eb_store_integral_product_attr_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_attr_value`
--

DROP TABLE IF EXISTS `eb_store_integral_product_attr_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_attr_value` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品ID',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型',
  `suk` varchar(128) NOT NULL DEFAULT '' COMMENT '商品属性索引值 (attr_value|attr_value[|....])',
  `stock` int unsigned NOT NULL DEFAULT '0' COMMENT '属性对应的库存',
  `sum_stock` int NOT NULL DEFAULT '0' COMMENT '平台库存+门店库存总和',
  `sales` int unsigned NOT NULL DEFAULT '0' COMMENT '销量',
  `price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '属性金额',
  `image` varchar(128) DEFAULT '' COMMENT '图片',
  `unique` char(8) NOT NULL DEFAULT '' COMMENT '唯一值',
  `cost` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '成本价',
  `bar_code` varchar(50) NOT NULL DEFAULT '' COMMENT '商品条码',
  `ot_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '原价',
  `vip_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '会员专享价',
  `weight` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '重量',
  `volume` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '体积',
  `brokerage` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '一级返佣',
  `brokerage_two` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '二级返佣',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '活动类型 0=商品，1=秒杀，2=砍价，3=拼团',
  `quota` int NOT NULL DEFAULT '0' COMMENT '活动限购数量',
  `quota_show` int NOT NULL DEFAULT '0' COMMENT '活动限购数量显示',
  `code` varchar(50) NOT NULL DEFAULT '' COMMENT '编码',
  `disk_info` longtext COMMENT '虚拟信息内容',
  PRIMARY KEY (`id`),
  KEY `unique` (`unique`,`suk`) USING BTREE,
  KEY `store_id` (`product_id`,`suk`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=364 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品属性值表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_attr_value`
--

/*!40000 ALTER TABLE `eb_store_integral_product_attr_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_cate`
--

DROP TABLE IF EXISTS `eb_store_integral_product_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_cate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '分类id',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `cate_pid` int NOT NULL DEFAULT '0' COMMENT '一级分类id',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品分类辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_cate`
--

/*!40000 ALTER TABLE `eb_store_integral_product_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_coupon`
--

DROP TABLE IF EXISTS `eb_store_integral_product_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_coupon` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `issue_coupon_id` int NOT NULL DEFAULT '0' COMMENT '优惠劵id',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '优惠券名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品关联优惠券表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_coupon`
--

/*!40000 ALTER TABLE `eb_store_integral_product_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_description`
--

DROP TABLE IF EXISTS `eb_store_integral_product_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_description` (
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `description` text COMMENT '商品详情',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型',
  KEY `product_id` (`product_id`,`type`),
  KEY `type` (`type`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品详情表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_description`
--

/*!40000 ALTER TABLE `eb_store_integral_product_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_ensure`
--

DROP TABLE IF EXISTS `eb_store_integral_product_ensure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_ensure` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '标签名称',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '图片',
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品保障服务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_ensure`
--

/*!40000 ALTER TABLE `eb_store_integral_product_ensure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_huanqu_log`
--

DROP TABLE IF EXISTS `eb_store_integral_product_huanqu_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_huanqu_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `uid` int NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 进行中 1 已揭晓',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `bianhao` int DEFAULT '1' COMMENT '商品编号',
  `image` varchar(256) NOT NULL DEFAULT '' COMMENT '商品图片',
  `store_name` varchar(128) NOT NULL DEFAULT '' COMMENT '商品名称',
  `total_num` int unsigned NOT NULL DEFAULT '0' COMMENT '订单商品总数',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '管理员备注',
  `setuid` int NOT NULL DEFAULT '0' COMMENT '是否设置开奖用户',
  `lucky_num` int DEFAULT '0' COMMENT '幸运值',
  `min_duihuan_num` int DEFAULT '0' COMMENT '开奖批次最低兑换次数',
  `is_jiqiren` tinyint(1) DEFAULT '0' COMMENT '判断是否是机器人',
  `total_price` decimal(10,2) DEFAULT '0.00' COMMENT '总消费额',
  `ot_price` decimal(10,2) DEFAULT '0.00' COMMENT '兑换一次扣积分数',
  `is_kami` tinyint(1) DEFAULT '0' COMMENT '是否卡密商品',
  `haomiao` varchar(20) DEFAULT '0',
  `zhaunhuanshuju` int DEFAULT '0',
  `haomiao_num` int DEFAULT '0',
  `box_order_id` int DEFAULT '0' COMMENT '盲盒订单ID',
  `box_cate_id` int DEFAULT '0' COMMENT '盲盒分类ID',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `is_del` (`is_del`) USING BTREE,
  KEY `product_id` (`product_id`),
  KEY `bianhao` (`bianhao`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2565727 DEFAULT CHARSET=utf8mb3 COMMENT='积分订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_huanqu_log`
--

/*!40000 ALTER TABLE `eb_store_integral_product_huanqu_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_huanqu_log_unique`
--

DROP TABLE IF EXISTS `eb_store_integral_product_huanqu_log_unique`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_huanqu_log_unique` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 进行中 1 已揭晓',
  `huanqu_id` int DEFAULT '0' COMMENT '换取记录表ID',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `bianhao` int DEFAULT '1' COMMENT '商品编号',
  `image` varchar(256) NOT NULL DEFAULT '' COMMENT '商品图片',
  `store_name` varchar(128) NOT NULL DEFAULT '' COMMENT '商品名称',
  `unique` char(8) NOT NULL DEFAULT '' COMMENT '唯一值',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `isset` int NOT NULL DEFAULT '0',
  `is_jiqiren` tinyint(1) DEFAULT '0' COMMENT '是否是机器人',
  `haomiao` varchar(20) DEFAULT '0',
  `zhaunhuanshuju` int DEFAULT '0',
  `haomiao_num` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `huanqu_id` (`huanqu_id`),
  KEY `product_id` (`product_id`),
  KEY `bianhao` (`bianhao`)
) ENGINE=InnoDB AUTO_INCREMENT=12736848 DEFAULT CHARSET=utf8mb3 COMMENT='积分商品换取编码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_huanqu_log_unique`
--

/*!40000 ALTER TABLE `eb_store_integral_product_huanqu_log_unique` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_huanqu_set_price`
--

DROP TABLE IF EXISTS `eb_store_integral_product_huanqu_set_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_huanqu_set_price` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int DEFAULT '0',
  `min_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '最新价格',
  `max_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '最大价格',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型 1 随机 2 必中',
  `bili` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品金额占比',
  `zhongjiang_bili` int DEFAULT '0' COMMENT '随机中中奖比例',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3 COMMENT='中奖概率表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_huanqu_set_price`
--

/*!40000 ALTER TABLE `eb_store_integral_product_huanqu_set_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_huanqu_set_zhong`
--

DROP TABLE IF EXISTS `eb_store_integral_product_huanqu_set_zhong`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_huanqu_set_zhong` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `uid` int NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 预设中 1 已设置',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `store_name` varchar(128) NOT NULL DEFAULT '' COMMENT '商品名称',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COMMENT='积分订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_huanqu_set_zhong`
--

/*!40000 ALTER TABLE `eb_store_integral_product_huanqu_set_zhong` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_kaijiang_log`
--

DROP TABLE IF EXISTS `eb_store_integral_product_kaijiang_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_kaijiang_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no` varchar(255) DEFAULT NULL COMMENT '订单编号',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 未开奖1 已开奖 2 待发货 3 待收货 4 已完成 5 已晒单 6 已回收',
  `uid` int NOT NULL DEFAULT '0',
  `real_name` varchar(32) NOT NULL DEFAULT '' COMMENT '用户姓名',
  `user_phone` varchar(18) NOT NULL DEFAULT '' COMMENT '用户电话',
  `user_address` varchar(100) NOT NULL DEFAULT '' COMMENT '详细地址',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `image` varchar(256) NOT NULL DEFAULT '' COMMENT '商品图片',
  `store_name` varchar(128) NOT NULL DEFAULT '' COMMENT '商品名称',
  `unique` char(8) NOT NULL DEFAULT '' COMMENT '唯一值',
  `cart_info` longtext COMMENT '积分商品信息',
  `total_num` int unsigned NOT NULL DEFAULT '0' COMMENT '订单商品总数',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `total_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '总积分',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `mark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '管理员备注',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型',
  `bianhao` int DEFAULT '1' COMMENT '商品编号',
  `kaijiang_time` int NOT NULL DEFAULT '0' COMMENT '开奖时间',
  `huanqu_id` int DEFAULT '0' COMMENT '中奖者换取记录ID',
  `huanqu_num` int DEFAULT '0' COMMENT '中奖者获取数量',
  `zhongjiang_time` int DEFAULT '0' COMMENT '中奖时间',
  `log_unique_id` int DEFAULT '0' COMMENT '中奖编号ID',
  `cate_id` int DEFAULT '0' COMMENT '商品分类',
  `is_recovery` tinyint(1) DEFAULT '0' COMMENT '是否回收',
  `recovery_price` decimal(10,2) DEFAULT '0.00' COMMENT '回收价格',
  `recovery_discount` int DEFAULT '0' COMMENT '回收折扣',
  `is_jiqiren` tinyint(1) DEFAULT '0' COMMENT '是否是机器人中奖',
  `delivery_id` varchar(255) DEFAULT '' COMMENT '快递号',
  `delivery_name` varchar(255) DEFAULT '' COMMENT '快递公司',
  `delivery_type` varchar(255) DEFAULT '',
  `is_kami` tinyint(1) DEFAULT '0' COMMENT '是否是卡密商品',
  `kami_account` varchar(255) DEFAULT '' COMMENT '卡密账号',
  `kami_pass` varchar(255) DEFAULT '' COMMENT '卡密密码',
  `shijian_sum` varchar(255) DEFAULT '' COMMENT '时间和',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `is_del` (`is_del`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=101716 DEFAULT CHARSET=utf8mb3 COMMENT='积分订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_kaijiang_log`
--

/*!40000 ALTER TABLE `eb_store_integral_product_kaijiang_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_kaijiang_shaidan`
--

DROP TABLE IF EXISTS `eb_store_integral_product_kaijiang_shaidan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_kaijiang_shaidan` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_no` varchar(255) DEFAULT NULL COMMENT '订单编号',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 未开奖1 已开奖 2 待发货 3 待收货 4 已完成 5 已晒单',
  `uid` int NOT NULL DEFAULT '0',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `image` varchar(256) NOT NULL DEFAULT '' COMMENT '商品图片',
  `store_name` varchar(128) NOT NULL DEFAULT '' COMMENT '商品名称',
  `unique` char(8) NOT NULL DEFAULT '' COMMENT '唯一值',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '单价',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '管理员备注',
  `bianhao` int DEFAULT '1' COMMENT '商品编号',
  `kaijiang_time` int NOT NULL DEFAULT '0' COMMENT '开奖时间',
  `huanqu_id` int DEFAULT '0' COMMENT '中奖者换取记录ID',
  `huanqu_num` int DEFAULT '0' COMMENT '中奖者获取数量',
  `zhongjiang_time` int DEFAULT '0' COMMENT '中奖时间',
  `log_unique_id` int DEFAULT '0' COMMENT '中奖编号ID',
  `cate_id` int DEFAULT '0' COMMENT '商品分类',
  `shaidan_images` text COMMENT '晒单图片',
  `title` varchar(255) DEFAULT '' COMMENT '标题',
  `is_show` tinyint(1) DEFAULT '0' COMMENT '是否显示',
  `content` text,
  `views_num` int DEFAULT '0' COMMENT '浏览量',
  `praise` int DEFAULT '0' COMMENT '点赞数',
  `kaijiang_id` int DEFAULT '0' COMMENT '开奖记录ID',
  `shaidan_image` varchar(255) DEFAULT NULL COMMENT '晒单首图',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COMMENT='积分订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_kaijiang_shaidan`
--

/*!40000 ALTER TABLE `eb_store_integral_product_kaijiang_shaidan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_label`
--

DROP TABLE IF EXISTS `eb_store_integral_product_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_label` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `label_cate` int NOT NULL DEFAULT '0' COMMENT '标签分类',
  `label_name` varchar(255) NOT NULL DEFAULT '' COMMENT '标签名称',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `label_cate` (`label_cate`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品标签表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_label`
--

/*!40000 ALTER TABLE `eb_store_integral_product_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_label_auxiliary`
--

DROP TABLE IF EXISTS `eb_store_integral_product_label_auxiliary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_label_auxiliary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label_id` int NOT NULL DEFAULT '0',
  `product_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `label_id` (`label_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品标签辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_label_auxiliary`
--

/*!40000 ALTER TABLE `eb_store_integral_product_label_auxiliary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_log`
--

DROP TABLE IF EXISTS `eb_store_integral_product_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` enum('visit','cart','order','pay','collect','refund') NOT NULL DEFAULT 'visit' COMMENT '类型',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `visit_num` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否浏览',
  `cart_num` int NOT NULL DEFAULT '0' COMMENT '加入购物车数量',
  `order_num` int NOT NULL DEFAULT '0' COMMENT '下单数量',
  `pay_num` int NOT NULL DEFAULT '0' COMMENT '支付数量',
  `pay_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '支付金额',
  `cost_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品成本价',
  `pay_uid` int NOT NULL DEFAULT '0' COMMENT '支付用户ID',
  `refund_num` int NOT NULL DEFAULT '0' COMMENT '退款数量',
  `refund_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '退款金额',
  `collect_num` tinyint(1) NOT NULL DEFAULT '0' COMMENT '收藏',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `delete_time` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `type` (`type`) USING BTREE,
  KEY `product_id` (`product_id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `uid_type` (`uid`,`type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_log`
--

/*!40000 ALTER TABLE `eb_store_integral_product_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_recovery_log`
--

DROP TABLE IF EXISTS `eb_store_integral_product_recovery_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_recovery_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int DEFAULT NULL COMMENT '用户ID',
  `order_no` varchar(255) DEFAULT NULL COMMENT '开奖订单号',
  `kaijiang_id` int NOT NULL,
  `store_name` varchar(255) DEFAULT '' COMMENT '商品名称',
  `image` varchar(255) DEFAULT '' COMMENT '图片',
  `unique` varchar(255) DEFAULT NULL COMMENT '中奖编号',
  `kaijiang_time` int DEFAULT NULL COMMENT '开奖时间',
  `recovery_price` decimal(10,2) DEFAULT '0.00' COMMENT '回收价',
  `recovery_discount` decimal(10,2) DEFAULT '0.00' COMMENT '回收折扣',
  `pay_money` decimal(10,2) DEFAULT '0.00' COMMENT '实际支付',
  `real_name` varchar(255) DEFAULT NULL COMMENT '真实姓名',
  `log_time` int NOT NULL DEFAULT '0',
  `product_id` int DEFAULT '0',
  `bianhao` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='积分商品回收记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_recovery_log`
--

/*!40000 ALTER TABLE `eb_store_integral_product_recovery_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_relation`
--

DROP TABLE IF EXISTS `eb_store_integral_product_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_relation` (
  `uid` int DEFAULT NULL,
  `relation_id` int unsigned NOT NULL DEFAULT '0' COMMENT '关联ID',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '类型(收藏(collect）、点赞(like))',
  `category` varchar(32) NOT NULL DEFAULT '' COMMENT '某种类型的商品(普通商品、秒杀商品)',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `bianhao` int DEFAULT '1' COMMENT '商品编号',
  UNIQUE KEY `uid` (`relation_id`,`type`,`category`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `category` (`category`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品点赞和收藏表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_relation`
--

/*!40000 ALTER TABLE `eb_store_integral_product_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_reply`
--

DROP TABLE IF EXISTS `eb_store_integral_product_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_reply` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `oid` int NOT NULL DEFAULT '0' COMMENT '订单ID',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `unique` char(32) NOT NULL DEFAULT '' COMMENT '唯一id',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `reply_type` varchar(32) NOT NULL DEFAULT 'product' COMMENT '某种商品类型(普通商品、秒杀商品）',
  `product_score` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品分数',
  `service_score` tinyint(1) NOT NULL DEFAULT '0' COMMENT '服务分数',
  `comment` varchar(512) NOT NULL DEFAULT '' COMMENT '评论内容',
  `pics` text COMMENT '评论图片',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '评论时间',
  `praise` int NOT NULL DEFAULT '0' COMMENT '点赞',
  `views_num` int NOT NULL DEFAULT '0' COMMENT '浏览量',
  `merchant_reply_content` varchar(300) NOT NULL DEFAULT '' COMMENT '管理员回复内容',
  `merchant_reply_time` int NOT NULL DEFAULT '0' COMMENT '管理员回复时间',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0未删除1已删除',
  `is_reply` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未回复1已回复',
  `nickname` varchar(64) NOT NULL DEFAULT '' COMMENT '用户名称',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '用户头像',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `order_id_2` (`oid`,`unique`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `parent_id` (`reply_type`) USING BTREE,
  KEY `is_del` (`is_del`) USING BTREE,
  KEY `product_score` (`product_score`) USING BTREE,
  KEY `service_score` (`service_score`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='评论表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_reply`
--

/*!40000 ALTER TABLE `eb_store_integral_product_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_reply_comment`
--

DROP TABLE IF EXISTS `eb_store_integral_product_reply_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_reply_comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0',
  `praise` int NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `content` varchar(1000) NOT NULL DEFAULT '' COMMENT '回复内容',
  `pid` int NOT NULL DEFAULT '0' COMMENT '上级回复id',
  `reply_id` int NOT NULL DEFAULT '0' COMMENT '评论id',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `reply_id` (`reply_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品评价回复表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_reply_comment`
--

/*!40000 ALTER TABLE `eb_store_integral_product_reply_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_rule`
--

DROP TABLE IF EXISTS `eb_store_integral_product_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_rule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(32) NOT NULL DEFAULT '' COMMENT '规格名称',
  `rule_value` text COMMENT '规格值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品规则值(规格)表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_rule`
--

/*!40000 ALTER TABLE `eb_store_integral_product_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_specs`
--

DROP TABLE IF EXISTS `eb_store_integral_product_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_specs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `temp_id` int NOT NULL DEFAULT '0' COMMENT '模版ID',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '参数名称',
  `value` varchar(255) NOT NULL DEFAULT '' COMMENT '参数值',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品参数表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_specs`
--

/*!40000 ALTER TABLE `eb_store_integral_product_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_stock_record`
--

DROP TABLE IF EXISTS `eb_store_integral_product_stock_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_stock_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `unique` varchar(32) NOT NULL DEFAULT '' COMMENT '规格唯一值',
  `cost_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '成本价',
  `number` int NOT NULL DEFAULT '0' COMMENT '数量',
  `pm` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:入库0:出库',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品库存记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_stock_record`
--

/*!40000 ALTER TABLE `eb_store_integral_product_stock_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_unit`
--

DROP TABLE IF EXISTS `eb_store_integral_product_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_unit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '单位名称',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否上架',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品单位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_unit`
--

/*!40000 ALTER TABLE `eb_store_integral_product_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_product_virtual`
--

DROP TABLE IF EXISTS `eb_store_integral_product_virtual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_product_virtual` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `attr_unique` varchar(20) NOT NULL DEFAULT '' COMMENT '对应商品规格',
  `card_no` varchar(255) NOT NULL DEFAULT '' COMMENT '卡密卡号',
  `card_pwd` varchar(255) NOT NULL DEFAULT '' COMMENT '卡密密码',
  `card_unique` varchar(32) NOT NULL DEFAULT '' COMMENT '虚拟卡密唯一值',
  `order_id` varchar(255) NOT NULL DEFAULT '' COMMENT '购买订单id',
  `order_type` smallint NOT NULL DEFAULT '1' COMMENT '购买订单类型：1:order 2:积分订单',
  `uid` int NOT NULL DEFAULT '0' COMMENT '购买人id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='虚拟商品卡密表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_product_virtual`
--

/*!40000 ALTER TABLE `eb_store_integral_product_virtual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_integral_visit`
--

DROP TABLE IF EXISTS `eb_store_integral_visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_integral_visit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `product_type` varchar(32) NOT NULL DEFAULT '' COMMENT '商品类型',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '商品分类ID',
  `type` char(50) NOT NULL DEFAULT '' COMMENT '商品类型',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `count` int NOT NULL DEFAULT '0' COMMENT '访问次数',
  `content` varchar(255) NOT NULL DEFAULT '' COMMENT '备注描述',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='商品浏览分析表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_integral_visit`
--

/*!40000 ALTER TABLE `eb_store_integral_visit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_newcomer`
--

DROP TABLE IF EXISTS `eb_store_newcomer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_newcomer` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `type` tinyint NOT NULL DEFAULT '0' COMMENT '商品所属：0：平台1:门店2:供应商',
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品id',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型0:普通商品，1：卡密，2：优惠券，3：虚拟商品,4：次卡商品',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联门店、供应商ID',
  `price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '商品价格',
  `ot_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '市场价',
  `sales` int unsigned NOT NULL DEFAULT '0' COMMENT '销量',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `product_id` (`product_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='新人专享商品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_newcomer`
--

/*!40000 ALTER TABLE `eb_store_newcomer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_order`
--

DROP TABLE IF EXISTS `eb_store_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_order` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `type` smallint NOT NULL DEFAULT '0' COMMENT '类型 0:普通、1：���杀、2:砍价、3:拼团、4:积分、5:套餐、6:预售',
  `pid` int NOT NULL DEFAULT '0' COMMENT '父类订单id',
  `order_id` varchar(32) NOT NULL DEFAULT '0' COMMENT '订单号',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `trade_no` varchar(100) NOT NULL DEFAULT '' COMMENT '支付宝订单号',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `real_name` varchar(32) NOT NULL DEFAULT '' COMMENT '用户姓名',
  `user_phone` varchar(18) NOT NULL DEFAULT '' COMMENT '用户电话',
  `user_address` varchar(100) NOT NULL DEFAULT '' COMMENT '详细地址',
  `user_location` varchar(30) NOT NULL DEFAULT '' COMMENT '用户地址定位',
  `cart_id` text COMMENT '购物车ids',
  `activity_id` int NOT NULL DEFAULT '0' COMMENT '活动商品ID',
  `activity_append` varchar(255) NOT NULL DEFAULT '' COMMENT '活动附加字段',
  `freight_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '运费金额',
  `total_num` int unsigned NOT NULL DEFAULT '0' COMMENT '订单商品总数',
  `total_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '订单总价',
  `total_postage` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '邮费',
  `pay_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '实际支付金额',
  `pay_postage` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '支付邮费',
  `deduction_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '抵扣金额',
  `coupon_id` int unsigned NOT NULL DEFAULT '0' COMMENT '优惠券id',
  `coupon_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '优惠券金额',
  `promotions_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '优惠活动优惠金额',
  `paid` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '支付状态',
  `pay_time` int unsigned NOT NULL DEFAULT '0' COMMENT '支付时间',
  `pay_type` varchar(32) NOT NULL DEFAULT '' COMMENT '支付方式',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单状态（0：待发货；1：待收货；2：已收货；3：待评价；4：部分发货；5：部分核销；）',
  `refund_status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0 未退款 1 申请中 2 已退款 3 部分退款',
  `refund_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '退款申请类型1:仅退款2：退款退款3：拒绝4：同意退货5：已退货6：已退款',
  `refund_express` varchar(255) NOT NULL DEFAULT '' COMMENT '退货快递单号',
  `refund_reason_wap_img` text COMMENT '退款图片',
  `refund_reason_wap_explain` varchar(255) NOT NULL DEFAULT '' COMMENT '退款用户说明',
  `refund_reason_time` int unsigned NOT NULL DEFAULT '0' COMMENT '退款时间',
  `refund_reason_wap` varchar(255) NOT NULL DEFAULT '' COMMENT '前台退款原因',
  `refund_reason` varchar(255) NOT NULL DEFAULT '' COMMENT '不退款的理由',
  `refund_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '退款金额',
  `delivery_name` varchar(64) NOT NULL DEFAULT '' COMMENT '快递名称/送货人姓名',
  `delivery_code` varchar(50) NOT NULL DEFAULT '' COMMENT '快递公司编码',
  `delivery_type` varchar(32) NOT NULL DEFAULT '' COMMENT '发货类型',
  `delivery_id` varchar(64) NOT NULL DEFAULT '' COMMENT '快递单号/手机号',
  `fictitious_content` varchar(500) NOT NULL DEFAULT '' COMMENT '虚拟发货内容',
  `delivery_uid` int NOT NULL DEFAULT '0' COMMENT '配送员id',
  `gain_integral` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '消费赚取积分',
  `use_integral` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '使用积分',
  `back_integral` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '给用户退了多少积分',
  `spread_uid` int NOT NULL DEFAULT '0' COMMENT '上级推广人uid',
  `spread_two_uid` int NOT NULL DEFAULT '0' COMMENT '上上级推广人uid',
  `one_brokerage` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '一级返佣金额',
  `two_brokerage` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '二级返佣金额',
  `mark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `unique` char(32) NOT NULL DEFAULT '' COMMENT '唯一id(md5加密)类似id',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '管理员备注',
  `mer_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商户ID',
  `is_mer_check` tinyint unsigned NOT NULL DEFAULT '0',
  `pink_id` int unsigned NOT NULL DEFAULT '0' COMMENT '拼团id 0没有拼团',
  `cost` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '成本价',
  `verify_code` varchar(12) NOT NULL DEFAULT '' COMMENT '核销码',
  `staff_id` int NOT NULL DEFAULT '0' COMMENT '店员ID',
  `shipping_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '配送方式 1=快递 ，2=门店自提，3=门店配送，4=门店收银',
  `clerk_id` int NOT NULL DEFAULT '0' COMMENT '店员id',
  `is_channel` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '支付渠道(0微信公众号1微信小程序)',
  `is_remind` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '消息提醒',
  `is_system_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '后台是否删除',
  `channel_type` varchar(255) NOT NULL DEFAULT '' COMMENT '用户访问端标识',
  `province` varchar(255) NOT NULL DEFAULT '' COMMENT '用户省份',
  `express_dump` varchar(502) NOT NULL DEFAULT '' COMMENT '订单面单打印信息',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型',
  `virtual_info` varchar(255) NOT NULL DEFAULT '' COMMENT '虚拟商品信息',
  `custom_form` longtext COMMENT '自定义表单',
  `promotions_give` longtext COMMENT '优惠活动赠送',
  `give_integral` int NOT NULL DEFAULT '0' COMMENT '优惠活动赠送积分',
  `give_coupon` longtext COMMENT '优惠活动赠送优惠券',
  `erp_id` int NOT NULL DEFAULT '0' COMMENT 'ERP内部单号',
  `erp_order_id` varchar(32) NOT NULL DEFAULT '' COMMENT 'ERP订单ID',
  `box_ids` varchar(255) NOT NULL DEFAULT '' COMMENT '盲盒ID',
  `product_json` text COMMENT '发货数据',
  `is_box_order` tinyint(1) DEFAULT '0' COMMENT '是否是盲盒订单',
  `cartInfo_json` text,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `order_id_2` (`order_id`,`uid`) USING BTREE,
  UNIQUE KEY `unique` (`unique`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `paid` (`paid`) USING BTREE,
  KEY `pay_time` (`pay_time`) USING BTREE,
  KEY `pay_type` (`pay_type`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `is_del` (`is_del`) USING BTREE,
  KEY `store_id` (`store_id`) USING BTREE,
  KEY `refund_status` (`refund_status`) USING BTREE,
  KEY `is_system_del` (`is_system_del`) USING BTREE,
  KEY `pid_2` (`uid`,`is_del`,`is_system_del`) USING BTREE,
  KEY `uid_2` (`uid`,`paid`,`status`,`refund_status`,`is_del`,`pid`) USING BTREE,
  KEY `erp_order_id` (`erp_order_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_order`
--

/*!40000 ALTER TABLE `eb_store_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_order_cart_info`
--

DROP TABLE IF EXISTS `eb_store_order_cart_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_order_cart_info` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `oid` int unsigned NOT NULL COMMENT '订单id',
  `cart_id` varchar(50) NOT NULL DEFAULT '0' COMMENT '购物车id',
  `staff_id` int NOT NULL DEFAULT '0' COMMENT '店员ID',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `delivery_id` int NOT NULL DEFAULT '0' COMMENT '配送员ID',
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品ID',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型',
  `promotions_id` longtext COMMENT '关联使用优惠活动ID',
  `is_gift` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是赠品1:是0:否',
  `is_support_refund` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否支持退款',
  `old_cart_id` varchar(50) NOT NULL DEFAULT '' COMMENT '拆单前cart_id',
  `cart_num` int NOT NULL DEFAULT '0' COMMENT '数量	',
  `refund_num` int NOT NULL DEFAULT '0' COMMENT '退款数量',
  `surplus_num` int NOT NULL DEFAULT '0' COMMENT '核销剩余数量',
  `split_surplus_num` int NOT NULL DEFAULT '0' COMMENT '拆分剩余数量',
  `split_status` int NOT NULL DEFAULT '0' COMMENT '0:未拆分1:还可以拆分2：拆分完成',
  `is_writeoff` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否核销',
  `writeoff_time` int NOT NULL DEFAULT '0' COMMENT '核销时间',
  `cart_info` text COMMENT '购买东西的详细信息',
  `unique` char(32) NOT NULL DEFAULT '' COMMENT '唯一id',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `oid` (`oid`,`unique`) USING BTREE,
  KEY `cart_id` (`cart_id`) USING BTREE,
  KEY `old_cart_id` (`old_cart_id`) USING BTREE,
  KEY `split_status` (`split_status`) USING BTREE,
  KEY `product_id` (`product_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单购物详情表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_order_cart_info`
--

/*!40000 ALTER TABLE `eb_store_order_cart_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_order_economize`
--

DROP TABLE IF EXISTS `eb_store_order_economize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_order_economize` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '订单ID',
  `order_id` varchar(32) NOT NULL DEFAULT '' COMMENT '订单号',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `order_type` tinyint(1) unsigned zerofill NOT NULL DEFAULT '1' COMMENT '配送方式 1=商品订单 ，2=线下订单',
  `pay_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '实际支付金额',
  `postage_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '邮费优惠金额',
  `member_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '会员优惠金额',
  `offline_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '线下优惠金额',
  `coupon_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '优惠券优惠金额',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`,`order_id`,`uid`) USING BTREE,
  UNIQUE KEY `order_id_2` (`order_id`,`uid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `pay_price` (`pay_price`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户资金节省表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_order_economize`
--

/*!40000 ALTER TABLE `eb_store_order_economize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_order_invoice`
--

DROP TABLE IF EXISTS `eb_store_order_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_order_invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `category` varchar(10) NOT NULL DEFAULT 'order' COMMENT '开票分类 order:订单',
  `order_id` int NOT NULL DEFAULT '0' COMMENT '订单id',
  `invoice_id` int NOT NULL DEFAULT '0' COMMENT '发票id',
  `header_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '抬头类型',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '发票类型',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '名称（发票抬头）',
  `duty_number` varchar(50) NOT NULL DEFAULT '' COMMENT '税号',
  `drawer_phone` varchar(30) NOT NULL DEFAULT '' COMMENT '开票人手机号',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '开票人邮箱',
  `tell` varchar(30) NOT NULL DEFAULT '' COMMENT '注册电话',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '注册地址',
  `bank` varchar(50) NOT NULL DEFAULT '' COMMENT '开户行',
  `card_number` varchar(50) NOT NULL DEFAULT '' COMMENT '银行卡号',
  `is_pay` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否支付',
  `is_refund` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单是否退款',
  `is_invoice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开票',
  `invoice_number` varchar(50) NOT NULL DEFAULT '' COMMENT '开票票号',
  `invoice_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '开票金额',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `invoice_time` int NOT NULL DEFAULT '0' COMMENT '开票时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户开票表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_order_invoice`
--

/*!40000 ALTER TABLE `eb_store_order_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_order_promotions`
--

DROP TABLE IF EXISTS `eb_store_order_promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_order_promotions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `oid` int NOT NULL DEFAULT '0' COMMENT '订单ID',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `promotions_id` int NOT NULL DEFAULT '0' COMMENT '优惠活动ID',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `promotions_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '优惠金额',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='订单优惠活动辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_order_promotions`
--

/*!40000 ALTER TABLE `eb_store_order_promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_order_refund`
--

DROP TABLE IF EXISTS `eb_store_order_refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_order_refund` (
  `id` int NOT NULL AUTO_INCREMENT,
  `store_order_id` int NOT NULL DEFAULT '0' COMMENT '订单表ID',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `order_id` varchar(50) NOT NULL DEFAULT '' COMMENT '订单号',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户UID',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `refund_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '退款申请类型1:仅退款2：退款退款3：拒绝4：同意退货5：已退货6：已退款',
  `refund_num` int NOT NULL DEFAULT '0' COMMENT '退款件数',
  `refund_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '退款金额',
  `refunded_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '已退款金额',
  `refund_reason` varchar(255) NOT NULL DEFAULT '' COMMENT '退款的理由',
  `refund_phone` varchar(32) NOT NULL DEFAULT '' COMMENT '退款电话',
  `refund_express` varchar(100) NOT NULL DEFAULT '' COMMENT '退货快递单号',
  `refund_express_name` varchar(255) NOT NULL DEFAULT '' COMMENT '退货快递名称',
  `refund_explain` varchar(255) NOT NULL DEFAULT '' COMMENT '退款用户说明',
  `refund_img` text COMMENT '退款图片',
  `refund_goods_explain` varchar(255) NOT NULL DEFAULT '' COMMENT '退货用户说明',
  `refund_goods_img` text COMMENT '退货凭证',
  `refuse_reason` varchar(255) NOT NULL DEFAULT '' COMMENT '拒绝原因',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `refunded_time` int NOT NULL DEFAULT '0' COMMENT '处理时间',
  `cart_info` longtext COMMENT '退款商品信息',
  `is_cancel` tinyint(1) NOT NULL DEFAULT '0' COMMENT '用户是否取消',
  `is_del` tinyint(1) DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '申请退款时间',
  PRIMARY KEY (`id`),
  KEY `store_order_id` (`store_order_id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `store_id` (`store_id`) USING BTREE,
  KEY `order_id` (`order_id`) USING BTREE,
  KEY `refund_type` (`is_cancel`,`store_order_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='售后订单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_order_refund`
--

/*!40000 ALTER TABLE `eb_store_order_refund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_order_status`
--

DROP TABLE IF EXISTS `eb_store_order_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_order_status` (
  `oid` int unsigned NOT NULL DEFAULT '0' COMMENT '订单id',
  `change_type` varchar(32) NOT NULL DEFAULT '' COMMENT '操作类型',
  `change_message` varchar(256) NOT NULL DEFAULT '' COMMENT '操作备注',
  `change_time` int unsigned NOT NULL DEFAULT '0' COMMENT '操作时间',
  KEY `oid` (`oid`) USING BTREE,
  KEY `change_type` (`change_type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='订单操作记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_order_status`
--

/*!40000 ALTER TABLE `eb_store_order_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_order_writeoff`
--

DROP TABLE IF EXISTS `eb_store_order_writeoff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_order_writeoff` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户UID',
  `oid` int NOT NULL DEFAULT '0' COMMENT '订单ID',
  `order_cart_id` int NOT NULL DEFAULT '0' COMMENT '订单商品ID',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品所属：0：平台1:门店2:供应商',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联门店、供应商ID',
  `staff_id` int NOT NULL DEFAULT '0' COMMENT '店员ID',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型0:普通商品，1：卡密，2：优惠券，3：虚拟商品,4：次卡商品',
  `writeoff_num` int NOT NULL DEFAULT '1' COMMENT '核销数量',
  `writeoff_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '核销金额',
  `writeoff_code` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '核销码',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '核销时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单核销记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_order_writeoff`
--

/*!40000 ALTER TABLE `eb_store_order_writeoff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_pink`
--

DROP TABLE IF EXISTS `eb_store_pink`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_pink` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `nickname` varchar(64) NOT NULL DEFAULT '' COMMENT '用户昵称',
  `avatar` varchar(256) NOT NULL DEFAULT '' COMMENT '用户头像',
  `order_id` varchar(32) NOT NULL DEFAULT '' COMMENT '订单id 生成',
  `order_id_key` int unsigned NOT NULL DEFAULT '0' COMMENT '订单id  数据库',
  `total_num` int unsigned NOT NULL DEFAULT '0' COMMENT '购买商品个数',
  `total_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '购买总金额',
  `cid` int unsigned NOT NULL DEFAULT '0' COMMENT '拼团商品id',
  `pid` int unsigned NOT NULL DEFAULT '0' COMMENT '商品id',
  `people` int unsigned NOT NULL DEFAULT '0' COMMENT '拼图总人数',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '拼团商品单价',
  `add_time` varchar(24) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `stop_time` varchar(24) NOT NULL DEFAULT '0',
  `k_id` int unsigned NOT NULL DEFAULT '0' COMMENT '团长id 0为团长',
  `is_tpl` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否发送模板消息0未发送1已发送',
  `is_refund` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否退款 0未退款 1已退款',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态1进行中2已完成3未完成',
  `is_virtual` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否虚拟拼团',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='拼团表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_pink`
--

/*!40000 ALTER TABLE `eb_store_pink` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product`
--

DROP TABLE IF EXISTS `eb_store_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product` (
  `id` mediumint NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型0:普通商品，1：卡密，2：优惠券，3：虚拟商品',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `mer_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商户Id(0为总后台管理员创建,不为0的时候是商户后台创建)',
  `image` varchar(256) NOT NULL DEFAULT '' COMMENT '商品图片',
  `recommend_image` varchar(256) NOT NULL DEFAULT '' COMMENT '推荐图',
  `slider_image` varchar(2000) NOT NULL DEFAULT '' COMMENT '轮播图',
  `store_name` varchar(128) NOT NULL DEFAULT '' COMMENT '商品名称',
  `store_info` varchar(256) NOT NULL DEFAULT '' COMMENT '商品简介',
  `keyword` varchar(256) NOT NULL DEFAULT '' COMMENT '关键字',
  `bar_code` varchar(15) NOT NULL DEFAULT '' COMMENT '商品条码（一维码）',
  `cate_id` varchar(64) NOT NULL DEFAULT '' COMMENT '分类id',
  `price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '商品价格',
  `vip_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '会员价格',
  `ot_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '市场价',
  `postage` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '邮费',
  `delivery_type` varchar(255) NOT NULL DEFAULT '' COMMENT '商品配送方式',
  `freight` tinyint(1) NOT NULL DEFAULT '2' COMMENT '运费设置',
  `unit_name` varchar(32) NOT NULL DEFAULT '' COMMENT '单位名',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `sales` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '销量',
  `stock` mediumint unsigned NOT NULL DEFAULT '0' COMMENT '库存',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态（0：未上架，1：上架）',
  `is_hot` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否热卖',
  `is_benefit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否优惠',
  `is_best` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否精品',
  `is_new` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否新品',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_postage` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否包邮',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `mer_use` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '商户是否代理 0不可代理1可代理',
  `give_integral` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '获得积分',
  `cost` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '成本价',
  `is_seckill` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '秒杀状态 0 未开启 1已开启',
  `is_bargain` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '砍价状态 0未开启 1开启',
  `is_good` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否优品推荐',
  `is_sub` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否单独分佣',
  `is_vip` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开启会员价格',
  `ficti` mediumint DEFAULT '100' COMMENT '虚拟销量',
  `browse` int NOT NULL DEFAULT '0' COMMENT '浏览量',
  `code_path` varchar(64) NOT NULL DEFAULT '' COMMENT '商品二维码地址(用户小程序海报)',
  `soure_link` text COMMENT '淘宝京东1688类型',
  `video_link` varchar(500) NOT NULL DEFAULT '' COMMENT '主图视频链接',
  `temp_id` int NOT NULL DEFAULT '1' COMMENT '运费模板ID',
  `spec_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '规格 0单 1多',
  `activity` varchar(255) NOT NULL DEFAULT '' COMMENT '活动显示排序1=秒杀，2=砍价，3=拼团',
  `spu` char(13) NOT NULL DEFAULT '' COMMENT '商品SPU',
  `label_id` varchar(64) NOT NULL DEFAULT '' COMMENT '标签ID',
  `command_word` varchar(255) NOT NULL DEFAULT '' COMMENT '复制口令',
  `recommend_list` varchar(256) NOT NULL DEFAULT '' COMMENT '推荐产品',
  `brand_id` int NOT NULL DEFAULT '0' COMMENT '品牌id',
  `brand_com` varchar(64) NOT NULL DEFAULT '' COMMENT '品牌组合',
  `code` varchar(50) NOT NULL DEFAULT '' COMMENT '编码',
  `is_vip_product` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否会员专属商品',
  `is_presale_product` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否预售商品',
  `presale_start_time` int NOT NULL DEFAULT '0' COMMENT '预售开始时间',
  `presale_end_time` int NOT NULL DEFAULT '0' COMMENT '预售结束时间',
  `presale_day` int NOT NULL DEFAULT '0' COMMENT '预售结束后几天内发货',
  `auto_on_time` int NOT NULL DEFAULT '0' COMMENT '自动上架时间',
  `auto_off_time` int NOT NULL DEFAULT '0' COMMENT '自动下架时间',
  `custom_form` longtext COMMENT '自定义表单',
  `is_support_refund` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否支持退款',
  `store_label_id` longtext COMMENT '商品标签iDS',
  `ensure_id` longtext COMMENT '商品保障服务ids',
  `specs` longtext COMMENT '商品参数',
  `specs_id` int NOT NULL DEFAULT '0' COMMENT '参数模版ID',
  `is_limit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开启限购',
  `limit_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '限购类型1单次限购2永久限购',
  `limit_num` int NOT NULL DEFAULT '0' COMMENT '限购数量',
  `tag` int NOT NULL DEFAULT '0' COMMENT '盲盒标签',
  `lucky_num` int NOT NULL DEFAULT '0' COMMENT '幸运值',
  `tag1_bili` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tag2_bili` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tag3_bili` decimal(10,2) NOT NULL DEFAULT '0.00',
  `tag4_bili` decimal(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cate_id` (`cate_id`) USING BTREE,
  KEY `is_hot` (`is_hot`) USING BTREE,
  KEY `is_benefit` (`is_benefit`) USING BTREE,
  KEY `is_best` (`is_best`) USING BTREE,
  KEY `is_new` (`is_new`) USING BTREE,
  KEY `toggle_on_sale, is_del` (`is_del`) USING BTREE,
  KEY `price` (`price`) USING BTREE,
  KEY `is_show` (`is_show`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `sales` (`sales`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `is_postage` (`is_postage`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=822 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product`
--

/*!40000 ALTER TABLE `eb_store_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_attr`
--

DROP TABLE IF EXISTS `eb_store_product_attr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_attr` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品ID',
  `attr_name` varchar(32) NOT NULL DEFAULT '' COMMENT '属性名',
  `attr_values` longtext COMMENT '属性值',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '活动类型 0=商品，1=秒杀，2=砍价，3=拼团',
  PRIMARY KEY (`id`),
  KEY `store_id` (`product_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品属性表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_attr`
--

/*!40000 ALTER TABLE `eb_store_product_attr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_attr_result`
--

DROP TABLE IF EXISTS `eb_store_product_attr_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_attr_result` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品ID',
  `result` longtext COMMENT '商品属性参数',
  `change_time` int unsigned NOT NULL DEFAULT '0' COMMENT '上次修改时间',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '活动类型 0=商品，1=秒杀，2=砍价，3=拼团',
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=711 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品属性详情表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_attr_result`
--

/*!40000 ALTER TABLE `eb_store_product_attr_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_attr_value`
--

DROP TABLE IF EXISTS `eb_store_product_attr_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_attr_value` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品ID',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型',
  `suk` varchar(128) NOT NULL DEFAULT '' COMMENT '商品属性索引值 (attr_value|attr_value[|....])',
  `stock` int unsigned NOT NULL DEFAULT '0' COMMENT '属性对应的库存',
  `sum_stock` int NOT NULL DEFAULT '0' COMMENT '平台库存+门店库存总和',
  `sales` int unsigned NOT NULL DEFAULT '0' COMMENT '销量',
  `price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '属性金额',
  `image` varchar(128) NOT NULL DEFAULT '' COMMENT '图片',
  `unique` char(8) NOT NULL DEFAULT '' COMMENT '唯一值',
  `cost` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '成本价',
  `bar_code` varchar(50) NOT NULL DEFAULT '' COMMENT '商品条码',
  `ot_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '原价',
  `vip_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '会员专享价',
  `weight` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '重量',
  `volume` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '体积',
  `brokerage` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '一级返佣',
  `brokerage_two` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '二级返佣',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '活动类型 0=商品，1=秒杀，2=砍价，3=拼团',
  `quota` int NOT NULL DEFAULT '0' COMMENT '活动限购数量',
  `quota_show` int NOT NULL DEFAULT '0' COMMENT '活动限购数量显示',
  `code` varchar(50) NOT NULL DEFAULT '' COMMENT '编码',
  `disk_info` longtext COMMENT '虚拟信息内容',
  PRIMARY KEY (`id`),
  KEY `unique` (`unique`,`suk`) USING BTREE,
  KEY `store_id` (`product_id`,`suk`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1261 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品属性值表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_attr_value`
--

/*!40000 ALTER TABLE `eb_store_product_attr_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_cate`
--

DROP TABLE IF EXISTS `eb_store_product_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_cate` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '分类id',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `cate_pid` int NOT NULL DEFAULT '0' COMMENT '一级分类id',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1490 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品分类辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_cate`
--

/*!40000 ALTER TABLE `eb_store_product_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_category`
--

DROP TABLE IF EXISTS `eb_store_product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_category` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '商品分类表ID',
  `pid` int NOT NULL DEFAULT '0' COMMENT '父id',
  `type` tinyint NOT NULL DEFAULT '0' COMMENT '商品所属：0：平台1:门店2:供应商',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联门店、供应商ID',
  `cate_name` varchar(100) NOT NULL DEFAULT '' COMMENT '分类名称',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `level` tinyint(1) NOT NULL DEFAULT '0' COMMENT '等级',
  `pic` varchar(128) NOT NULL DEFAULT '' COMMENT '图标',
  `big_pic` varchar(255) NOT NULL DEFAULT '' COMMENT '分类大图',
  `adv_pic` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '广告图片',
  `adv_link` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '广告链接',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否推荐',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `is_base` (`is_show`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_category`
--

/*!40000 ALTER TABLE `eb_store_product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_category_brand`
--

DROP TABLE IF EXISTS `eb_store_product_category_brand`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_category_brand` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '分类ID',
  `brand_id` int NOT NULL DEFAULT '0' COMMENT '品牌ID',
  `brand_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '品牌名称',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `cate_id` (`cate_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品分类品牌关联';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_category_brand`
--

/*!40000 ALTER TABLE `eb_store_product_category_brand` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_coupon`
--

DROP TABLE IF EXISTS `eb_store_product_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_coupon` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `issue_coupon_id` int NOT NULL DEFAULT '0' COMMENT '优惠劵id',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '优惠券名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品关联优惠券表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_coupon`
--

/*!40000 ALTER TABLE `eb_store_product_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_description`
--

DROP TABLE IF EXISTS `eb_store_product_description`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_description` (
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `description` text COMMENT '商品详情',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型',
  KEY `product_id` (`product_id`,`type`),
  KEY `type` (`type`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品详情表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_description`
--

/*!40000 ALTER TABLE `eb_store_product_description` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_ensure`
--

DROP TABLE IF EXISTS `eb_store_product_ensure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_ensure` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '标签名称',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '图片',
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品保障服务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_ensure`
--

/*!40000 ALTER TABLE `eb_store_product_ensure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_label`
--

DROP TABLE IF EXISTS `eb_store_product_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_label` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `label_cate` int NOT NULL DEFAULT '0' COMMENT '标签分类',
  `label_name` varchar(255) NOT NULL DEFAULT '' COMMENT '标签名称',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `label_cate` (`label_cate`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品标签表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_label`
--

/*!40000 ALTER TABLE `eb_store_product_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_label_auxiliary`
--

DROP TABLE IF EXISTS `eb_store_product_label_auxiliary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_label_auxiliary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label_id` int NOT NULL DEFAULT '0',
  `product_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `label_id` (`label_id`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品标签辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_label_auxiliary`
--

/*!40000 ALTER TABLE `eb_store_product_label_auxiliary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_log`
--

DROP TABLE IF EXISTS `eb_store_product_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` enum('visit','cart','order','pay','collect','refund') NOT NULL DEFAULT 'visit' COMMENT '类型',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `visit_num` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否浏览',
  `cart_num` int NOT NULL DEFAULT '0' COMMENT '加入购物车数量',
  `order_num` int NOT NULL DEFAULT '0' COMMENT '下单数量',
  `pay_num` int NOT NULL DEFAULT '0' COMMENT '支付数量',
  `pay_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '支付金额',
  `cost_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '商品成本价',
  `pay_uid` int NOT NULL DEFAULT '0' COMMENT '支付用户ID',
  `refund_num` int NOT NULL DEFAULT '0' COMMENT '退款数量',
  `refund_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '退款金额',
  `collect_num` tinyint(1) NOT NULL DEFAULT '0' COMMENT '收藏',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `delete_time` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `type` (`type`) USING BTREE,
  KEY `product_id` (`product_id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `uid_type` (`uid`,`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2438 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_log`
--

/*!40000 ALTER TABLE `eb_store_product_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_relation`
--

DROP TABLE IF EXISTS `eb_store_product_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_relation` (
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `relation_id` int unsigned NOT NULL DEFAULT '0' COMMENT '关联ID',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '类型(收藏(collect）、点赞(like))',
  `category` varchar(32) NOT NULL DEFAULT '' COMMENT '某种类型的商品(普通商品、秒杀商品)',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  UNIQUE KEY `uid` (`uid`,`relation_id`,`type`,`category`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `category` (`category`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品点赞和收藏表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_relation`
--

/*!40000 ALTER TABLE `eb_store_product_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_reply`
--

DROP TABLE IF EXISTS `eb_store_product_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_reply` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `oid` int NOT NULL DEFAULT '0' COMMENT '订单ID',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `unique` char(32) NOT NULL DEFAULT '' COMMENT '唯一id',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `reply_type` varchar(32) NOT NULL DEFAULT 'product' COMMENT '某种商品类型(普通商品、秒杀商品）',
  `product_score` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品分数',
  `service_score` tinyint(1) NOT NULL DEFAULT '0' COMMENT '服务分数',
  `comment` varchar(512) NOT NULL DEFAULT '' COMMENT '评论内容',
  `pics` text COMMENT '评论图片',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '评论时间',
  `praise` int NOT NULL DEFAULT '0' COMMENT '点赞',
  `views_num` int NOT NULL DEFAULT '0' COMMENT '浏览量',
  `merchant_reply_content` varchar(300) NOT NULL DEFAULT '' COMMENT '管理员回复内容',
  `merchant_reply_time` int NOT NULL DEFAULT '0' COMMENT '管理员回复时间',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0未删除1已删除',
  `is_reply` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未回复1已回复',
  `nickname` varchar(64) NOT NULL DEFAULT '' COMMENT '用户名称',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '用户头像',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `order_id_2` (`oid`,`unique`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `parent_id` (`reply_type`) USING BTREE,
  KEY `is_del` (`is_del`) USING BTREE,
  KEY `product_score` (`product_score`) USING BTREE,
  KEY `service_score` (`service_score`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='评论表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_reply`
--

/*!40000 ALTER TABLE `eb_store_product_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_reply_comment`
--

DROP TABLE IF EXISTS `eb_store_product_reply_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_reply_comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0',
  `praise` int NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `content` varchar(1000) NOT NULL DEFAULT '' COMMENT '回复内容',
  `pid` int NOT NULL DEFAULT '0' COMMENT '上级回复id',
  `reply_id` int NOT NULL DEFAULT '0' COMMENT '评论id',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `reply_id` (`reply_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品评价回复表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_reply_comment`
--

/*!40000 ALTER TABLE `eb_store_product_reply_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_rule`
--

DROP TABLE IF EXISTS `eb_store_product_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_rule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rule_name` varchar(32) NOT NULL DEFAULT '' COMMENT '规格名称',
  `rule_value` text COMMENT '规格值',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品规则值(规格)表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_rule`
--

/*!40000 ALTER TABLE `eb_store_product_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_specs`
--

DROP TABLE IF EXISTS `eb_store_product_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_specs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `temp_id` int NOT NULL DEFAULT '0' COMMENT '模版ID',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '参数名称',
  `value` varchar(255) NOT NULL DEFAULT '' COMMENT '参数值',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品参数表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_specs`
--

/*!40000 ALTER TABLE `eb_store_product_specs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_stock_record`
--

DROP TABLE IF EXISTS `eb_store_product_stock_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_stock_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `unique` varchar(32) NOT NULL DEFAULT '' COMMENT '规格唯一值',
  `cost_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '成本价',
  `number` int NOT NULL DEFAULT '0' COMMENT '数量',
  `pm` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:入库0:出库',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品库存记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_stock_record`
--

/*!40000 ALTER TABLE `eb_store_product_stock_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_unit`
--

DROP TABLE IF EXISTS `eb_store_product_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_unit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '单位名称',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否上架',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品单位表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_unit`
--

/*!40000 ALTER TABLE `eb_store_product_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_virtual`
--

DROP TABLE IF EXISTS `eb_store_product_virtual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_virtual` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品id',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `attr_unique` varchar(20) NOT NULL DEFAULT '' COMMENT '对应商品规格',
  `card_no` varchar(255) NOT NULL DEFAULT '' COMMENT '卡密卡号',
  `card_pwd` varchar(255) NOT NULL DEFAULT '' COMMENT '卡密密码',
  `card_unique` varchar(32) NOT NULL DEFAULT '' COMMENT '虚拟卡密唯一值',
  `order_id` varchar(255) NOT NULL DEFAULT '' COMMENT '购买订单id',
  `order_type` smallint NOT NULL DEFAULT '1' COMMENT '购买订单类型：1:order 2:积分订单',
  `uid` int NOT NULL DEFAULT '0' COMMENT '购买人id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='虚拟商品卡密表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_virtual`
--

/*!40000 ALTER TABLE `eb_store_product_virtual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_product_words`
--

DROP TABLE IF EXISTS `eb_store_product_words`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_product_words` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型：0平台2:供应商',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '门店、供应商id',
  `name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '词',
  `color` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '颜色',
  `bg_color` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '背景颜色',
  `border_color` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '边框颜色',
  `icon` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '图标',
  `is_show` tinyint(1) DEFAULT '0' COMMENT '是否显示',
  `sort` smallint DEFAULT '0' COMMENT '排序',
  `is_search` tinyint unsigned DEFAULT '0' COMMENT '大家都在搜',
  `is_hot` tinyint(1) DEFAULT '0' COMMENT '热词',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品搜索热词';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_product_words`
--

/*!40000 ALTER TABLE `eb_store_product_words` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_promotions`
--

DROP TABLE IF EXISTS `eb_store_promotions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_promotions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pid` int NOT NULL DEFAULT '0' COMMENT '同一活动ID',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `promotions_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '活动类型：1：限时折扣2:第N件N折3:满减满折4:满送',
  `promotions_cate` tinyint(1) NOT NULL DEFAULT '1' COMMENT '优惠方式1:阶梯2:循环',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '活动名称',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '优惠标题',
  `desc` text COMMENT '优惠内容详情',
  `threshold_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '门槛类型1:满N元2:满N件',
  `threshold` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '优惠门槛',
  `discount_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '优惠类型1:满减2:满折',
  `n_piece_n_discount` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'n件n折类型：1:第二件半件2:买1送1 3:自定义',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '优惠',
  `give_integral` int NOT NULL DEFAULT '0' COMMENT '赠送积分',
  `give_coupon_id` longtext COMMENT '赠送优惠券ID',
  `give_product_id` longtext COMMENT '赠送商品ID',
  `give_product_unique` varchar(20) NOT NULL DEFAULT '' COMMENT '赠送商品规格唯一值',
  `overlay` varchar(255) NOT NULL DEFAULT '' COMMENT '优惠叠加',
  `label_id` longtext COMMENT '关联标签ids',
  `product_partake_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '参与商品类型：1:全部商品2：指定商品参与3：指定商品不参与',
  `product_id` longtext COMMENT '关联商品ids',
  `is_limit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否限量:0不限量1限量',
  `limit_num` int NOT NULL DEFAULT '0' COMMENT '限量个数',
  `start_time` int NOT NULL DEFAULT '0' COMMENT '活动开始时间',
  `stop_time` int NOT NULL DEFAULT '0' COMMENT '活动结束时间',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '最后一次修改时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `type` (`type`,`store_id`),
  KEY `promotions_type` (`promotions_type`),
  KEY `update_time` (`update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='优惠活动表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_promotions`
--

/*!40000 ALTER TABLE `eb_store_promotions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_promotions_auxiliary`
--

DROP TABLE IF EXISTS `eb_store_promotions_auxiliary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_promotions_auxiliary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型1：关联商品2：赠送优惠券3：赠送商品',
  `promotions_id` int NOT NULL DEFAULT '0',
  `product_partake_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '参与商品类型：1:全部商品2：指定商品参与3：指定商品不参与',
  `product_id` int NOT NULL DEFAULT '0',
  `coupon_id` int NOT NULL DEFAULT '0' COMMENT '优惠券id',
  `limit_num` int NOT NULL DEFAULT '0' COMMENT '限量个数',
  `surplus_num` int NOT NULL DEFAULT '0' COMMENT '限量剩余个数',
  `is_all` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否是全部规格：1是0否',
  `unique` longtext COMMENT '商品unique',
  PRIMARY KEY (`id`),
  KEY `promotions_id` (`promotions_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='优惠活动辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_promotions_auxiliary`
--

/*!40000 ALTER TABLE `eb_store_promotions_auxiliary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_seckill`
--

DROP TABLE IF EXISTS `eb_store_seckill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_seckill` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '商品秒杀商品表id',
  `product_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商品id',
  `product_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '商品类型0:普通商品，1：卡密，2：优惠券，3：虚拟商品',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '推荐图',
  `images` varchar(2000) NOT NULL DEFAULT '' COMMENT '轮播图',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '活动标题',
  `info` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '价格',
  `cost` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '成本',
  `ot_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '原价',
  `give_integral` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '返多少积分',
  `sort` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `stock` int unsigned NOT NULL DEFAULT '0' COMMENT '库存',
  `sales` int unsigned NOT NULL DEFAULT '0' COMMENT '销量',
  `unit_name` varchar(16) NOT NULL DEFAULT '' COMMENT '单位名',
  `postage` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '邮费',
  `description` text COMMENT '内容',
  `start_time` varchar(128) NOT NULL DEFAULT '' COMMENT '开始时间',
  `stop_time` varchar(128) NOT NULL DEFAULT '' COMMENT '结束时间',
  `add_time` varchar(128) NOT NULL DEFAULT '' COMMENT '添加时间',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '商品状态',
  `is_postage` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否包邮',
  `is_hot` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '热门推荐',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '删除 0未删除1已删除',
  `num` int unsigned NOT NULL DEFAULT '1' COMMENT '最多秒杀几个',
  `is_show` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '显示',
  `time_id` int NOT NULL DEFAULT '0' COMMENT '时间段ID',
  `temp_id` int NOT NULL DEFAULT '0' COMMENT '运费模板ID',
  `weight` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '商品重量',
  `volume` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '商品体积',
  `quota` int NOT NULL DEFAULT '0' COMMENT '限购总数',
  `quota_show` int NOT NULL DEFAULT '0' COMMENT '限购总数显示',
  `once_num` int NOT NULL DEFAULT '0' COMMENT '单次购买个数',
  `is_support_refund` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否支持退款',
  `delivery_type` varchar(10) NOT NULL DEFAULT '' COMMENT '物流类型',
  `freight` tinyint(1) NOT NULL DEFAULT '2' COMMENT '运费设置',
  `custom_form` longtext COMMENT '自定义表单',
  `store_label_id` longtext COMMENT '商品标签iDS',
  `ensure_id` longtext COMMENT '商品保障服务ids',
  `specs` longtext COMMENT '商品参数',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `product_id` (`product_id`) USING BTREE,
  KEY `start_time` (`start_time`,`stop_time`) USING BTREE,
  KEY `is_del` (`is_del`) USING BTREE,
  KEY `is_hot` (`is_hot`) USING BTREE,
  KEY `is_show` (`status`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `sort` (`sort`) USING BTREE,
  KEY `is_postage` (`is_postage`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品秒杀商品表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_seckill`
--

/*!40000 ALTER TABLE `eb_store_seckill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_seckill_time`
--

DROP TABLE IF EXISTS `eb_store_seckill_time`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_seckill_time` (
  `seckill_id` int NOT NULL DEFAULT '0' COMMENT '秒杀活动ID',
  `time_id` int NOT NULL DEFAULT '0' COMMENT '秒杀时间段ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='秒杀时段表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_seckill_time`
--

/*!40000 ALTER TABLE `eb_store_seckill_time` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_service`
--

DROP TABLE IF EXISTS `eb_store_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_service` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '客服id',
  `mer_id` int NOT NULL DEFAULT '0' COMMENT '商户id',
  `uid` int NOT NULL DEFAULT '0' COMMENT '客服uid',
  `online` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否在线',
  `account` varchar(255) NOT NULL DEFAULT '' COMMENT '账号',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '密码',
  `avatar` varchar(250) NOT NULL DEFAULT '' COMMENT '客服头像',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '代理名称',
  `phone` varchar(20) NOT NULL DEFAULT '' COMMENT '客服电话',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `account_status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '账号状态,0隐藏1显示',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '客服状态，0隐藏1显示',
  `notify` int NOT NULL DEFAULT '0' COMMENT '订单通知1开启0关闭',
  `customer` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否展示统计管理',
  `uniqid` varchar(35) NOT NULL DEFAULT '',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='客服表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_service`
--

/*!40000 ALTER TABLE `eb_store_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_service_feedback`
--

DROP TABLE IF EXISTS `eb_store_service_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_service_feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户UID',
  `rela_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '姓名',
  `phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '电话',
  `content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '反馈内容',
  `make` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '备注',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态0=未查看，1=已查看',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '类型',
  `images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客服反馈表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_service_feedback`
--

/*!40000 ALTER TABLE `eb_store_service_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_service_log`
--

DROP TABLE IF EXISTS `eb_store_service_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_service_log` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '客服用户对话记录表ID',
  `mer_id` int NOT NULL DEFAULT '0' COMMENT '商户id',
  `msn` text COMMENT '消息内容',
  `uid` int NOT NULL DEFAULT '1' COMMENT '发送人uid',
  `to_uid` int NOT NULL DEFAULT '1' COMMENT '接收人uid',
  `is_tourist` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=游客模式，0=非游客',
  `time_node` tinyint(1) NOT NULL DEFAULT '0' COMMENT '时间节点',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '发送时间',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已读（0：否；1：是；）',
  `remind` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否提醒过',
  `msn_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '消息类型 1=文字 2=表情 3=图片 4=语音',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=452 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='客服用户对话记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_service_log`
--

/*!40000 ALTER TABLE `eb_store_service_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_service_record`
--

DROP TABLE IF EXISTS `eb_store_service_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_service_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL DEFAULT '0' COMMENT '发送人的uid',
  `to_uid` int NOT NULL DEFAULT '0' COMMENT '送达人的uid',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户昵称',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '用户头像',
  `is_tourist` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是游客',
  `online` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否在线',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = pc,1=微信，2=小程序，3=H5',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `mssage_num` int NOT NULL DEFAULT '0' COMMENT '消息条数',
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容',
  `message_type` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `to_uid` (`to_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客服聊天用户记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_service_record`
--

/*!40000 ALTER TABLE `eb_store_service_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_service_speechcraft`
--

DROP TABLE IF EXISTS `eb_store_service_speechcraft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_service_speechcraft` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kefu_id` int NOT NULL DEFAULT '0' COMMENT '0为全局话术',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '0为不分类全局话术',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '话术标题',
  `message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '话术内容',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `kefu_id` (`kefu_id`),
  KEY `cate_id` (`cate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='客服话术';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_service_speechcraft`
--

/*!40000 ALTER TABLE `eb_store_service_speechcraft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_user`
--

DROP TABLE IF EXISTS `eb_store_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_user` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `uid` int NOT NULL DEFAULT '0' COMMENT '平台关联用户uid',
  `label_id` text COMMENT '用户标签',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `store_id` (`store_id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='门店用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_user`
--

/*!40000 ALTER TABLE `eb_store_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_store_visit`
--

DROP TABLE IF EXISTS `eb_store_visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_store_visit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL DEFAULT '0' COMMENT '商品ID',
  `product_type` varchar(32) NOT NULL DEFAULT '' COMMENT '商品类型',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '商品分类ID',
  `type` char(50) NOT NULL DEFAULT '' COMMENT '商品类型',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `count` int NOT NULL DEFAULT '0' COMMENT '访问次数',
  `content` varchar(255) NOT NULL DEFAULT '' COMMENT '备注描述',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=838 DEFAULT CHARSET=utf8mb3 COMMENT='商品浏览分析表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_store_visit`
--

/*!40000 ALTER TABLE `eb_store_visit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_supplier_extract`
--

DROP TABLE IF EXISTS `eb_supplier_extract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_supplier_extract` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `extract_type` varchar(32) NOT NULL DEFAULT 'bank' COMMENT 'bank = 银行卡 alipay = 支付宝wx=微信',
  `bank_code` varchar(32) NOT NULL DEFAULT '0' COMMENT '银行卡',
  `bank_address` varchar(256) NOT NULL DEFAULT '' COMMENT '开户地址',
  `alipay_account` varchar(64) NOT NULL DEFAULT '' COMMENT '支付宝账号',
  `wechat` varchar(15) NOT NULL DEFAULT '' COMMENT '微信号',
  `qrcode_url` varchar(255) NOT NULL DEFAULT '' COMMENT '二维码地址',
  `extract_price` decimal(8,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '提现金额',
  `mark` varchar(512) NOT NULL DEFAULT '',
  `balance` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '-1 未通过 0 审核中 1 已提现',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 未转账 1 已转账',
  `supplier_mark` varchar(255) NOT NULL DEFAULT '' COMMENT '供应商备注',
  `admin_id` int unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `fail_msg` varchar(128) NOT NULL DEFAULT '' COMMENT '无效原因',
  `fail_time` int unsigned NOT NULL DEFAULT '0',
  `voucher_image` varchar(256) NOT NULL DEFAULT '' COMMENT '转账凭证',
  `voucher_title` varchar(256) NOT NULL DEFAULT '' COMMENT '转账说明',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `extract_type` (`extract_type`),
  KEY `status` (`status`),
  KEY `add_time` (`add_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='供应商提现表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_supplier_extract`
--

/*!40000 ALTER TABLE `eb_supplier_extract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_supplier_flowing_water`
--

DROP TABLE IF EXISTS `eb_supplier_flowing_water`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_supplier_flowing_water` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户id',
  `order_id` varchar(20) NOT NULL DEFAULT '' COMMENT '交易单号',
  `link_id` varchar(50) NOT NULL DEFAULT '' COMMENT '关联订单',
  `pm` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = 支出 1 = 获得',
  `number` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '明细',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '交易类型(1:支付订单,2:退款订单)',
  `pay_type` varchar(20) NOT NULL DEFAULT '' COMMENT '支付方式',
  `pay_price` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '实际支付金额',
  `total_price` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '订单总金额',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '平台备注',
  `mark` varchar(255) NOT NULL DEFAULT '' COMMENT '供应商备注',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `trade_time` int NOT NULL DEFAULT '0' COMMENT '交易时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='供应商流水表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_supplier_flowing_water`
--

/*!40000 ALTER TABLE `eb_supplier_flowing_water` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_supplier_ticket_print`
--

DROP TABLE IF EXISTS `eb_supplier_ticket_print`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_supplier_ticket_print` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `supplier_id` int NOT NULL COMMENT '供应商ID',
  `develop_id` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `api_key` varchar(100) NOT NULL DEFAULT '' COMMENT '秘钥',
  `client_id` varchar(100) NOT NULL DEFAULT '' COMMENT '应用ID',
  `terminal_number` varchar(100) NOT NULL DEFAULT '' COMMENT '终端号',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '开启状态',
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_supplier_ticket_print`
--

/*!40000 ALTER TABLE `eb_supplier_ticket_print` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_supplier_transactions`
--

DROP TABLE IF EXISTS `eb_supplier_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_supplier_transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `supplier_id` int NOT NULL DEFAULT '0' COMMENT '供应商ID',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户id',
  `order_id` varchar(20) NOT NULL DEFAULT '' COMMENT '交易单号',
  `link_id` varchar(50) NOT NULL DEFAULT '' COMMENT '关联订单',
  `pm` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = 支出 1 = 获得',
  `type` varchar(50) NOT NULL DEFAULT '' COMMENT '交易类型(1:支付订单,2:退款订单)',
  `pay_type` varchar(20) NOT NULL DEFAULT '' COMMENT '支付方式',
  `pay_price` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '实际支付金额',
  `total_price` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '订单总金额',
  `remark` varchar(512) NOT NULL DEFAULT '' COMMENT '平台备注',
  `mark` varchar(255) NOT NULL DEFAULT '' COMMENT '供应商备注',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `trade_time` int NOT NULL DEFAULT '0' COMMENT '交易时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='供应商交易表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_supplier_transactions`
--

/*!40000 ALTER TABLE `eb_supplier_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_admin`
--

DROP TABLE IF EXISTS `eb_system_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_admin` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT COMMENT '后台管理员表ID',
  `account` varchar(32) NOT NULL DEFAULT '' COMMENT '后台管理员账号',
  `admin_type` tinyint NOT NULL DEFAULT '1' COMMENT '管理员类型 1平台 2门店 4供应商',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联ID',
  `head_pic` varchar(255) NOT NULL DEFAULT '',
  `pwd` varchar(100) NOT NULL DEFAULT '' COMMENT '后台管理员密码',
  `real_name` varchar(16) NOT NULL DEFAULT '' COMMENT '后台管理员姓名',
  `phone` varchar(32) NOT NULL DEFAULT '' COMMENT '用户电话',
  `roles` varchar(128) NOT NULL DEFAULT '' COMMENT '后台管理员权限(menus_id)',
  `last_ip` varchar(16) NOT NULL DEFAULT '' COMMENT '后台管理员最后一次登录ip',
  `last_time` int unsigned NOT NULL DEFAULT '0' COMMENT '后台管理员最后一次登录时间',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '后台管理员添加时间',
  `login_count` int unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `level` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '后台管理员级别',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '后台管理员状态 1有效0无效',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `account` (`account`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COMMENT='后台管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_admin`
--

/*!40000 ALTER TABLE `eb_system_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_attachment`
--

DROP TABLE IF EXISTS `eb_system_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_attachment` (
  `att_id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联id',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '附件名称',
  `att_dir` varchar(200) NOT NULL DEFAULT '' COMMENT '附件路径',
  `satt_dir` varchar(200) NOT NULL DEFAULT '' COMMENT '压缩图片路径',
  `att_size` char(30) NOT NULL DEFAULT '' COMMENT '附件大小',
  `att_type` char(30) NOT NULL DEFAULT '' COMMENT '附件类型',
  `pid` int NOT NULL DEFAULT '0' COMMENT '分类ID0编辑器,1商品图片,2拼团图片,3砍价图片,4秒杀图片,5文章图片,6组合数据图',
  `time` int NOT NULL DEFAULT '0' COMMENT '上传时间',
  `image_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '图片上传类型 1本地 2七牛云 3OSS 4COS ',
  `module_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '图片上传模块类型 1 后台上传 2 用户生成',
  `real_name` varchar(255) NOT NULL DEFAULT '' COMMENT '原始文件名',
  PRIMARY KEY (`att_id`) USING BTREE,
  KEY `time` (`time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15226 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='附件管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_attachment`
--

/*!40000 ALTER TABLE `eb_system_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_attachment_category`
--

DROP TABLE IF EXISTS `eb_system_attachment_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_attachment_category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联id',
  `pid` int NOT NULL DEFAULT '0' COMMENT '父级ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '分类名称',
  `enname` varchar(50) NOT NULL DEFAULT '' COMMENT '分类目录',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='附件分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_attachment_category`
--

/*!40000 ALTER TABLE `eb_system_attachment_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_city`
--

DROP TABLE IF EXISTS `eb_system_city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_city` (
  `id` int NOT NULL AUTO_INCREMENT,
  `city_id` int NOT NULL DEFAULT '0' COMMENT '城市id',
  `level` int NOT NULL DEFAULT '0' COMMENT '省市级别',
  `parent_id` int NOT NULL DEFAULT '0' COMMENT '父级id',
  `area_code` varchar(30) NOT NULL DEFAULT '' COMMENT '区号',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '名称',
  `merger_name` varchar(255) NOT NULL DEFAULT '' COMMENT '合并名称',
  `lng` varchar(50) NOT NULL DEFAULT '' COMMENT '经度',
  `lat` varchar(50) NOT NULL DEFAULT '' COMMENT '纬度',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否展示',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3971 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='城市表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_city`
--

/*!40000 ALTER TABLE `eb_system_city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_config`
--

DROP TABLE IF EXISTS `eb_system_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_config` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '配置id',
  `is_store` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=总后台,1=门店',
  `menu_name` varchar(255) NOT NULL DEFAULT '' COMMENT '字段名称',
  `type` varchar(255) NOT NULL DEFAULT '' COMMENT '类型(文本框,单选按钮...)',
  `input_type` varchar(20) NOT NULL DEFAULT 'input' COMMENT '表单类型',
  `config_tab_id` int unsigned NOT NULL DEFAULT '0' COMMENT '配置分类id',
  `parameter` varchar(255) NOT NULL DEFAULT '' COMMENT '规则 单选框和多选框',
  `upload_type` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '上传文件格式1单图2多图3文件',
  `required` varchar(255) NOT NULL DEFAULT '' COMMENT '规则',
  `width` int unsigned NOT NULL DEFAULT '0' COMMENT '多行文本框的宽度',
  `high` int unsigned NOT NULL DEFAULT '0' COMMENT '多行文框的高度',
  `value` varchar(5000) NOT NULL DEFAULT '' COMMENT '默认值',
  `info` varchar(255) NOT NULL DEFAULT '' COMMENT '配置名称',
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '配置简介',
  `sort` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `is_store` (`is_store`) USING BTREE,
  KEY `config_tab_id` (`config_tab_id`) USING BTREE,
  KEY `menu_name` (`menu_name`(191)) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=453 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_config`
--

/*!40000 ALTER TABLE `eb_system_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_config_tab`
--

DROP TABLE IF EXISTS `eb_system_config_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_config_tab` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '配置分类id',
  `is_store` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=总后台,1=门店',
  `pid` int NOT NULL DEFAULT '0' COMMENT '上级分类id',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '配置分类名称',
  `eng_title` varchar(255) NOT NULL DEFAULT '' COMMENT '配置分类英文名称',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '配置分类状态',
  `info` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '配置分类是否显示',
  `icon` varchar(30) DEFAULT '' COMMENT '图标',
  `type` int NOT NULL DEFAULT '0' COMMENT '配置类型',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `is_store` (`is_store`) USING BTREE,
  KEY `eng_title` (`eng_title`(191)) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='配置分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_config_tab`
--

/*!40000 ALTER TABLE `eb_system_config_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_file`
--

DROP TABLE IF EXISTS `eb_system_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_file` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '文件对比ID',
  `cthash` char(32) NOT NULL DEFAULT '' COMMENT '文件内容',
  `filename` varchar(255) NOT NULL DEFAULT '' COMMENT '文价名称',
  `atime` char(12) NOT NULL DEFAULT '' COMMENT '上次访问时间',
  `mtime` char(12) NOT NULL DEFAULT '' COMMENT '上次修改时间',
  `ctime` char(12) NOT NULL DEFAULT '' COMMENT '上次改变时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1371 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='文件对比表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_file`
--

/*!40000 ALTER TABLE `eb_system_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_form`
--

DROP TABLE IF EXISTS `eb_system_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_form` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL DEFAULT '' COMMENT '版本号',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '表单名称',
  `cover_image` varchar(255) NOT NULL DEFAULT '' COMMENT '封面图',
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '表单数据',
  `default_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '默认数据',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否使用',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统表单数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_form`
--

/*!40000 ALTER TABLE `eb_system_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_form_data`
--

DROP TABLE IF EXISTS `eb_system_form_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_form_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户UID',
  `system_form_id` varchar(255) NOT NULL DEFAULT '' COMMENT '表单名称',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '收集数据来源：1订单',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联数据来源ID',
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '收集数据',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='表单收集数据记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_form_data`
--

/*!40000 ALTER TABLE `eb_system_form_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_group`
--

DROP TABLE IF EXISTS `eb_system_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_group` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '组合数据ID',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '分类id',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '数据组名称',
  `info` varchar(256) NOT NULL DEFAULT '' COMMENT '数据提示',
  `config_name` varchar(50) NOT NULL DEFAULT '' COMMENT '数据字段',
  `fields` text COMMENT '数据组字段以及类型（json数据）',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `config_name` (`config_name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='组合数据表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_group`
--

/*!40000 ALTER TABLE `eb_system_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_group_data`
--

DROP TABLE IF EXISTS `eb_system_group_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_group_data` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '组合数据详情ID',
  `gid` int NOT NULL DEFAULT '0' COMMENT '对应的数据组id',
  `value` text COMMENT '数据组对应的数据值（json数据）',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加数据时间',
  `sort` int NOT NULL DEFAULT '0' COMMENT '数据排序',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态（1：开启；2：关闭；）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=671 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='组合数据详情表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_group_data`
--

/*!40000 ALTER TABLE `eb_system_group_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_log`
--

DROP TABLE IF EXISTS `eb_system_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员操作记录ID',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `admin_id` int unsigned NOT NULL DEFAULT '0' COMMENT '管理员id',
  `admin_name` varchar(64) NOT NULL DEFAULT '' COMMENT '管理员姓名',
  `path` varchar(128) NOT NULL DEFAULT '' COMMENT '链接',
  `page` varchar(64) NOT NULL DEFAULT '' COMMENT '行为',
  `method` varchar(12) NOT NULL DEFAULT '' COMMENT '访问类型',
  `ip` varchar(16) NOT NULL DEFAULT '' COMMENT '登录IP',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '类型',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '操作时间',
  `merchant_id` int unsigned NOT NULL DEFAULT '0' COMMENT '商户id',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `admin_id` (`admin_id`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `type` (`type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1240079 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='管理员操作记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_log`
--

/*!40000 ALTER TABLE `eb_system_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_menus`
--

DROP TABLE IF EXISTS `eb_system_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_menus` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT COMMENT '菜单ID',
  `pid` smallint unsigned NOT NULL DEFAULT '0' COMMENT '父级id',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '菜单类型1:平台2:门店',
  `icon` varchar(50) NOT NULL DEFAULT '' COMMENT '图标',
  `menu_name` varchar(32) NOT NULL DEFAULT '' COMMENT '按钮名',
  `module` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '模块名',
  `controller` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '控制器',
  `action` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '方法名',
  `api_url` varchar(100) NOT NULL DEFAULT '' COMMENT 'api接口地址',
  `methods` varchar(10) NOT NULL DEFAULT '' COMMENT '提交方式POST GET PUT DELETE',
  `params` varchar(128) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '[]' COMMENT '参数',
  `sort` tinyint NOT NULL DEFAULT '1' COMMENT '排序',
  `is_show` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '是否为隐藏菜单0=隐藏菜单,1=显示菜单',
  `is_show_path` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为隐藏菜单供前台使用',
  `access` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '子管理员是否可用',
  `menu_path` varchar(128) NOT NULL DEFAULT '' COMMENT '路由名称 前端使用',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `auth_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为菜单 1菜单 2功能',
  `header` varchar(50) NOT NULL DEFAULT '' COMMENT '顶部菜单标示',
  `is_header` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否顶部菜单1是0否',
  `unique_auth` varchar(150) NOT NULL DEFAULT '' COMMENT '前台唯一标识',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `pid` (`pid`) USING BTREE,
  KEY `is_show` (`is_show`) USING BTREE,
  KEY `access` (`access`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1512 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='菜单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_menus`
--

/*!40000 ALTER TABLE `eb_system_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_message`
--

DROP TABLE IF EXISTS `eb_system_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_message` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mark` varchar(50) NOT NULL DEFAULT '' COMMENT '标识',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` varchar(256) NOT NULL DEFAULT '' COMMENT '通知标题',
  `content` varchar(512) NOT NULL DEFAULT '' COMMENT '通知内容',
  `look` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否查看',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1:普通用户，2：管理员',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '通知时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`look`,`is_del`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=266 DEFAULT CHARSET=utf8mb3 COMMENT='系统通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_message`
--

/*!40000 ALTER TABLE `eb_system_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_notice`
--

DROP TABLE IF EXISTS `eb_system_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_notice` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '通知模板id',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '通知标题',
  `type` varchar(64) NOT NULL DEFAULT '' COMMENT '通知类型',
  `icon` varchar(16) NOT NULL DEFAULT '' COMMENT '图标',
  `url` varchar(64) NOT NULL DEFAULT '' COMMENT '链接',
  `table_title` varchar(256) NOT NULL DEFAULT '' COMMENT '通知数据',
  `template` varchar(64) NOT NULL DEFAULT '' COMMENT '通知模板',
  `push_admin` varchar(128) NOT NULL DEFAULT '' COMMENT '通知管理员id',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `type` (`type`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通知模板表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_notice`
--

/*!40000 ALTER TABLE `eb_system_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_notice_admin`
--

DROP TABLE IF EXISTS `eb_system_notice_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_notice_admin` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '通知记录ID',
  `notice_type` varchar(64) NOT NULL DEFAULT '' COMMENT '通知类型',
  `admin_id` smallint unsigned NOT NULL DEFAULT '0' COMMENT '通知的管理员',
  `link_id` int unsigned NOT NULL DEFAULT '0' COMMENT '关联ID',
  `table_data` text COMMENT '通知的数据',
  `is_click` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '点击次数',
  `is_visit` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '访问次数',
  `visit_time` int NOT NULL DEFAULT '0' COMMENT '访问时间',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '通知时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `admin_id` (`admin_id`,`notice_type`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `is_visit` (`is_visit`) USING BTREE,
  KEY `is_click` (`is_click`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='通知记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_notice_admin`
--

/*!40000 ALTER TABLE `eb_system_notice_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_notification`
--

DROP TABLE IF EXISTS `eb_system_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_notification` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mark` varchar(50) NOT NULL DEFAULT '' COMMENT '标识',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '通知类型',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '通知场景说明',
  `is_system` tinyint(1) NOT NULL DEFAULT '0' COMMENT '站内信（0：不存在，1：开启，2：关闭）',
  `is_app` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'APP推送（0：不存在，1：开启，2：关闭）',
  `is_wechat` tinyint(1) NOT NULL DEFAULT '0' COMMENT '公众号模板消息（0：不存在，1：开启，2：关闭）',
  `is_routine` tinyint(1) NOT NULL DEFAULT '0' COMMENT '小程序订阅消息（0：不存在，1：开启，2：关闭）',
  `is_sms` tinyint(1) NOT NULL DEFAULT '0' COMMENT '发送短信（0：不存在，1：开启，2：关闭）',
  `is_ent_wechat` tinyint(1) NOT NULL DEFAULT '0' COMMENT '企业微信群通知（0：不存在，1：开启，2：关闭）',
  `system_title` varchar(256) NOT NULL DEFAULT '' COMMENT '站内信标题',
  `system_text` varchar(512) NOT NULL DEFAULT '' COMMENT '系统消息id',
  `app_id` int NOT NULL DEFAULT '0' COMMENT 'app推送id',
  `wechat_id` varchar(50) NOT NULL DEFAULT '0' COMMENT '模板消息id',
  `routine_id` varchar(50) NOT NULL DEFAULT '0' COMMENT '订阅消息id',
  `sms_id` int NOT NULL DEFAULT '0' COMMENT '短信id',
  `ent_wechat_text` varchar(512) NOT NULL DEFAULT '' COMMENT '企业微信消息',
  `variable` varchar(256) NOT NULL DEFAULT '' COMMENT '变量',
  `url` varchar(512) NOT NULL DEFAULT '' COMMENT '群机器人链接',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '类型（1：用户，2：管理员）',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb3 COMMENT='通知设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_notification`
--

/*!40000 ALTER TABLE `eb_system_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_role`
--

DROP TABLE IF EXISTS `eb_system_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_role` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '身份管理id',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '角色类型1:平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `role_name` varchar(32) NOT NULL DEFAULT '' COMMENT '身份管理名称',
  `rules` text COMMENT '身份管理权限(menus_id)',
  `level` tinyint unsigned NOT NULL DEFAULT '0',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='身份管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_role`
--

/*!40000 ALTER TABLE `eb_system_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_sign_reward`
--

DROP TABLE IF EXISTS `eb_system_sign_reward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_sign_reward` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '编号',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型，0连续签到奖励，1累计签到奖励',
  `days` int NOT NULL DEFAULT '0' COMMENT '天数',
  `point` int NOT NULL DEFAULT '0' COMMENT '赠送积分',
  `exp` int NOT NULL DEFAULT '0' COMMENT '赠送经验',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='系统签到奖励表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_sign_reward`
--

/*!40000 ALTER TABLE `eb_system_sign_reward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_storage`
--

DROP TABLE IF EXISTS `eb_system_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_storage` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `access_key` varchar(100) NOT NULL DEFAULT '' COMMENT 'access_key',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=本地存储,2=七牛,3=oss,4=cos',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '空间名',
  `region` varchar(100) NOT NULL DEFAULT '' COMMENT '地域',
  `acl` enum('private','public-read','public-read-write') NOT NULL DEFAULT 'public-read' COMMENT '权限',
  `domain` varchar(100) NOT NULL DEFAULT '' COMMENT '空间域名',
  `cname` varchar(255) NOT NULL DEFAULT '' COMMENT 'CNAME值',
  `is_ssl` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=http,1=https',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  `is_delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加事件',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新事件',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COMMENT='云储存';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_storage`
--

/*!40000 ALTER TABLE `eb_system_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_store`
--

DROP TABLE IF EXISTS `eb_system_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_store` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `erp_shop_id` int DEFAULT NULL COMMENT 'EPR门店id',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '门店名称',
  `introduction` varchar(1000) NOT NULL DEFAULT '' COMMENT '简介',
  `phone` char(25) NOT NULL DEFAULT '' COMMENT '手机号码',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '省市区',
  `province` int NOT NULL DEFAULT '0' COMMENT '省ID',
  `city` int NOT NULL DEFAULT '0' COMMENT '市ID',
  `area` int NOT NULL DEFAULT '0' COMMENT '区ID',
  `street` int DEFAULT '0' COMMENT '街道ID',
  `detailed_address` varchar(255) NOT NULL DEFAULT '' COMMENT '详细地址',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '门店logo',
  `oblong_image` varchar(255) NOT NULL DEFAULT '' COMMENT '门店推荐图',
  `latitude` char(25) NOT NULL DEFAULT '' COMMENT '纬度',
  `longitude` char(25) NOT NULL DEFAULT '' COMMENT '经度',
  `bank_code` varchar(32) NOT NULL DEFAULT '0' COMMENT '银行卡',
  `bank_address` varchar(256) NOT NULL DEFAULT '' COMMENT '开户地址',
  `alipay_account` varchar(64) NOT NULL DEFAULT '' COMMENT '支付宝账号',
  `alipay_qrcode_url` varchar(255) NOT NULL DEFAULT '' COMMENT '支付宝二维码地址',
  `wechat` varchar(15) NOT NULL DEFAULT '' COMMENT '微信号',
  `wechat_qrcode_url` varchar(255) NOT NULL DEFAULT '' COMMENT '微信二维码地址',
  `valid_time` varchar(100) NOT NULL DEFAULT '' COMMENT '核销有效日期',
  `valid_range` int NOT NULL DEFAULT '0' COMMENT '有效距离',
  `day_time` varchar(100) NOT NULL DEFAULT '' COMMENT '每日营业开关时间',
  `day_start` varchar(20) DEFAULT '' COMMENT '每日营业开始时间',
  `day_end` varchar(20) NOT NULL DEFAULT '' COMMENT '每日营业结束时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_show` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否显示',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `is_store` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否到店自提',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `phone` (`phone`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='门店自提';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_store`
--

/*!40000 ALTER TABLE `eb_system_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_store_staff`
--

DROP TABLE IF EXISTS `eb_system_store_staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_store_staff` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '微信用户id',
  `account` varchar(50) NOT NULL DEFAULT '' COMMENT '账号',
  `pwd` varchar(100) NOT NULL DEFAULT '' COMMENT '密码',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '店员头像',
  `staff_name` varchar(64) NOT NULL DEFAULT '' COMMENT '店员名称',
  `phone` char(15) NOT NULL DEFAULT '' COMMENT '手机号码',
  `roles` varchar(255) DEFAULT '' COMMENT '管理权限',
  `last_ip` varchar(16) NOT NULL DEFAULT '' COMMENT '最后一次登录ip',
  `last_time` int NOT NULL DEFAULT '0' COMMENT '最后一次登录时间',
  `login_count` int NOT NULL DEFAULT '0' COMMENT '登录次数',
  `level` tinyint NOT NULL DEFAULT '1' COMMENT '级别',
  `verify_status` tinyint NOT NULL DEFAULT '0' COMMENT '核销开关',
  `order_status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '订单管理',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是管理员',
  `is_manager` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是店长',
  `is_cashier` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否收银员1=是，0=否',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态',
  `notify` tinyint(1) NOT NULL DEFAULT '0' COMMENT '订单通知1开启0关闭',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_uid_status_isdel_verifystatus` (`uid`,`status`,`is_del`,`verify_status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='门店店员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_store_staff`
--

/*!40000 ALTER TABLE `eb_system_store_staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_supplier`
--

DROP TABLE IF EXISTS `eb_system_supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_supplier` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `supplier_name` varchar(50) NOT NULL DEFAULT '' COMMENT '供应商名称',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '联系人姓名',
  `phone` char(15) NOT NULL DEFAULT '' COMMENT '联系电话',
  `email` varchar(50) NOT NULL DEFAULT '' COMMENT '邮箱',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '省市区',
  `province` int NOT NULL DEFAULT '0' COMMENT '省ID',
  `city` int NOT NULL DEFAULT '0' COMMENT '市ID',
  `area` int NOT NULL DEFAULT '0' COMMENT '区ID',
  `street` int NOT NULL DEFAULT '0' COMMENT '街道ID',
  `detailed_address` varchar(255) NOT NULL DEFAULT '' COMMENT '详细地址',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态 0关闭 1开启',
  `mark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='供应商表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_supplier`
--

/*!40000 ALTER TABLE `eb_system_supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_timer`
--

DROP TABLE IF EXISTS `eb_system_timer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_timer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '定时器名称',
  `mark` varchar(50) NOT NULL COMMENT '标识',
  `type` tinyint(1) NOT NULL COMMENT '周期状态 1=N分钟 2=N小时 3=每小时 4=每天 5=N天 6=每星期 7=每月 8=每年',
  `title` varchar(255) DEFAULT NULL COMMENT '任务说明',
  `is_open` tinyint(1) DEFAULT '0' COMMENT '是否开启',
  `cycle` varchar(255) DEFAULT NULL COMMENT '执行周期',
  `last_execution_time` int DEFAULT '0' COMMENT '上次执行时间',
  `update_execution_time` int DEFAULT '0' COMMENT '修改时间',
  `is_del` tinyint(1) DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COMMENT='定时器';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_timer`
--

/*!40000 ALTER TABLE `eb_system_timer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_user_apply`
--

DROP TABLE IF EXISTS `eb_system_user_apply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_user_apply` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` tinyint NOT NULL DEFAULT '0' COMMENT '申请类型1:门店2:供应商',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联商户',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `phone` varchar(20) NOT NULL DEFAULT '' COMMENT '手机号',
  `system_name` varchar(30) NOT NULL DEFAULT '' COMMENT '商户名称',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '联系人名称',
  `images` varchar(2000) NOT NULL DEFAULT '' COMMENT '多图',
  `mark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '处理状态0未处理，1通过 ，2未通过',
  `fail_msg` varchar(255) NOT NULL DEFAULT '' COMMENT '未通过原因',
  `is_del` tinyint NOT NULL DEFAULT '0' COMMENT '删除状态 1删除 ，0未删除',
  `status_time` int NOT NULL DEFAULT '0' COMMENT '审核时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='用户申请表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_user_apply`
--

/*!40000 ALTER TABLE `eb_system_user_apply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_system_user_level`
--

DROP TABLE IF EXISTS `eb_system_user_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_system_user_level` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mer_id` int NOT NULL DEFAULT '0' COMMENT '商户id',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '会员名称',
  `money` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '购买金额',
  `valid_date` int NOT NULL DEFAULT '0' COMMENT '有效时间',
  `is_forever` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为永久会员',
  `is_pay` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否购买,1=购买,0=不购买',
  `is_show` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否显示 1=显示,0=隐藏',
  `grade` int NOT NULL DEFAULT '0' COMMENT '会员等级',
  `discount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '享受折扣',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '会员卡背景',
  `icon` varchar(255) NOT NULL DEFAULT '' COMMENT '会员图标',
  `explain` text COMMENT '说明',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除.1=删除,0=未删除',
  `exp_num` int NOT NULL DEFAULT '0' COMMENT '升级经验',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='设置用户等级表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_system_user_level`
--

/*!40000 ALTER TABLE `eb_system_user_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_template_message`
--

DROP TABLE IF EXISTS `eb_template_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_template_message` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '模板id',
  `notification_id` varchar(255) NOT NULL DEFAULT '0' COMMENT '模版通知场景ID,多个',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=订阅消息,1=微信模板消息',
  `tempkey` char(50) NOT NULL DEFAULT '' COMMENT '模板编号',
  `name` char(100) NOT NULL DEFAULT '' COMMENT '模板名',
  `kid` varchar(255) NOT NULL DEFAULT '',
  `content` varchar(1000) NOT NULL DEFAULT '' COMMENT '回复内容',
  `example` varchar(300) NOT NULL DEFAULT '' COMMENT '模版示例',
  `tempid` char(100) NOT NULL DEFAULT '' COMMENT '模板ID',
  `add_time` varchar(15) NOT NULL DEFAULT '' COMMENT '添加时间',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=COMPACT COMMENT='微信模板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_template_message`
--

/*!40000 ALTER TABLE `eb_template_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user`
--

DROP TABLE IF EXISTS `eb_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `back_money` decimal(10,2) DEFAULT '0.00' COMMENT '返现金额',
  `account` varchar(32) NOT NULL DEFAULT '' COMMENT '用户账号',
  `pwd` varchar(32) NOT NULL DEFAULT '' COMMENT '用户密码',
  `real_name` varchar(25) NOT NULL DEFAULT '' COMMENT '真实姓名',
  `birthday` int NOT NULL DEFAULT '0' COMMENT '生日',
  `card_id` varchar(20) NOT NULL DEFAULT '' COMMENT '身份证号码',
  `mark` varchar(255) NOT NULL DEFAULT '' COMMENT '用户备注',
  `partner_id` int NOT NULL DEFAULT '0' COMMENT '合伙人id',
  `group_id` int NOT NULL DEFAULT '0' COMMENT '用户分组id',
  `nickname` varchar(60) NOT NULL DEFAULT '' COMMENT '用户昵称',
  `avatar` varchar(256) NOT NULL DEFAULT '' COMMENT '用户头像',
  `phone` char(15) NOT NULL DEFAULT '' COMMENT '手机号码',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `add_ip` varchar(16) NOT NULL DEFAULT '' COMMENT '添加ip',
  `last_time` int unsigned NOT NULL DEFAULT '0' COMMENT '最后一次登录时间',
  `last_ip` varchar(16) NOT NULL DEFAULT '' COMMENT '最后一次登录ip',
  `now_money` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '用户余额',
  `brokerage_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '佣金金额',
  `integral` int unsigned NOT NULL DEFAULT '0' COMMENT '用户剩余积分',
  `back_integral` decimal(10,2) DEFAULT '0.00' COMMENT '返现积分',
  `exp` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '会员经验',
  `sign_num` int NOT NULL DEFAULT '0' COMMENT '连续签到天数',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1为正常，0为禁止',
  `level` int NOT NULL DEFAULT '0' COMMENT '等级',
  `agent_level` int NOT NULL DEFAULT '0' COMMENT '分销等级',
  `spread_open` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有推广资格',
  `spread_uid` int unsigned NOT NULL DEFAULT '0' COMMENT '推广元id',
  `spread_time` int unsigned NOT NULL DEFAULT '0' COMMENT '推广员关联时间',
  `spread_lottery` int NOT NULL DEFAULT '1' COMMENT '推广获取抽奖次数',
  `work_uid` int NOT NULL DEFAULT '0' COMMENT '绑定企业微信成员uid',
  `work_userid` varchar(64) DEFAULT NULL COMMENT '绑定企业微信成员uid',
  `user_type` varchar(32) NOT NULL DEFAULT '' COMMENT '用户类型',
  `is_promoter` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否为推广员',
  `pay_count` int unsigned NOT NULL DEFAULT '0' COMMENT '用户购买次数',
  `spread_count` int NOT NULL DEFAULT '0' COMMENT '下级人数',
  `clean_time` int NOT NULL DEFAULT '0' COMMENT '清理会员时间',
  `addres` varchar(255) NOT NULL DEFAULT '' COMMENT '详细地址',
  `adminid` int unsigned NOT NULL DEFAULT '0' COMMENT '管理员编号 ',
  `login_type` varchar(36) NOT NULL DEFAULT '' COMMENT '用户登陆类型，h5,wechat,routine',
  `login_city` varchar(255) NOT NULL DEFAULT '' COMMENT '登录城市',
  `record_phone` varchar(11) NOT NULL DEFAULT '' COMMENT '记录临时电话',
  `is_money_level` tinyint(1) NOT NULL DEFAULT '0' COMMENT '会员来源  0: 购买商品升级   1：花钱购买的会员2: 会员卡领取',
  `is_ever_level` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否永久性会员  0: 非永久会员  1：永久会员',
  `overdue_time` bigint NOT NULL DEFAULT '0' COMMENT '会员到期时间',
  `uniqid` varchar(32) NOT NULL DEFAULT '',
  `bar_code` varchar(32) NOT NULL DEFAULT '' COMMENT '条形码值',
  `rand_code` int NOT NULL DEFAULT '0' COMMENT '随机code，用于确认余额支付',
  `sex` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0:其他,1:男,2:女',
  `provincials` varchar(255) NOT NULL DEFAULT '' COMMENT '省市区',
  `province` int NOT NULL DEFAULT '0' COMMENT '省ID',
  `city` int NOT NULL DEFAULT '0' COMMENT '市ID',
  `area` int NOT NULL DEFAULT '0' COMMENT '	区ID',
  `street` int NOT NULL DEFAULT '0' COMMENT '街道ID',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `delete_time` timestamp NULL DEFAULT NULL COMMENT '删除时间',
  `bank_card` varchar(255) DEFAULT NULL COMMENT '银行卡号',
  `bank_address` varchar(255) DEFAULT NULL COMMENT '开户行地址',
  `bank_name` varchar(255) DEFAULT NULL COMMENT '开户行',
  `bank_mobile` varchar(255) DEFAULT NULL COMMENT '银行预留手机号',
  `lucky_num` int DEFAULT '0' COMMENT '幸运值',
  `kaijiang_id` int DEFAULT '0' COMMENT '中奖ID',
  `is_tanchuang` tinyint(1) DEFAULT '0' COMMENT '判断是否弹窗',
  `phone_city` varchar(255) DEFAULT '' COMMENT '手机号归属地',
  PRIMARY KEY (`uid`) USING BTREE,
  KEY `account` (`account`) USING BTREE,
  KEY `spreaduid` (`spread_uid`) USING BTREE,
  KEY `level` (`level`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `work_uid` (`work_uid`) USING BTREE,
  KEY `is_promoter` (`is_promoter`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=106363 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user`
--

/*!40000 ALTER TABLE `eb_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_address`
--

DROP TABLE IF EXISTS `eb_user_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_address` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '用户地址id',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `real_name` varchar(32) NOT NULL DEFAULT '' COMMENT '收货人姓名',
  `phone` varchar(16) NOT NULL DEFAULT '' COMMENT '收货人电话',
  `province` varchar(64) NOT NULL DEFAULT '' COMMENT '收货人所在省',
  `city` varchar(64) NOT NULL DEFAULT '' COMMENT '收货人所在市',
  `street` varchar(100) NOT NULL DEFAULT '' COMMENT '所在镇/街道',
  `city_id` int NOT NULL DEFAULT '0' COMMENT '城市id',
  `district` varchar(64) NOT NULL DEFAULT '' COMMENT '收货人所在区',
  `detail` varchar(256) NOT NULL DEFAULT '' COMMENT '收货人详细地址',
  `post_code` int unsigned NOT NULL DEFAULT '0' COMMENT '邮编',
  `longitude` varchar(16) NOT NULL DEFAULT '0' COMMENT '经度',
  `latitude` varchar(16) NOT NULL DEFAULT '0' COMMENT '纬度',
  `is_default` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否默认',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `is_default` (`is_default`) USING BTREE,
  KEY `is_del` (`is_del`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户地址表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_address`
--

/*!40000 ALTER TABLE `eb_user_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_bank`
--

DROP TABLE IF EXISTS `eb_user_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_bank` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0',
  `real_name` varchar(255) NOT NULL DEFAULT '',
  `bank_card` varchar(255) NOT NULL DEFAULT '',
  `bank_address` varchar(255) NOT NULL DEFAULT '',
  `bank_name` varchar(255) NOT NULL DEFAULT '',
  `bank_mobile` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户银行卡表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_bank`
--

/*!40000 ALTER TABLE `eb_user_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_bill`
--

DROP TABLE IF EXISTS `eb_user_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_bill` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '用户账单id',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户uid',
  `link_id` varchar(32) NOT NULL DEFAULT '0' COMMENT '关联id',
  `pm` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0 = 支出 1 = 获得',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '账单标题',
  `category` varchar(64) NOT NULL DEFAULT '' COMMENT '明细种类',
  `type` varchar(64) NOT NULL DEFAULT '' COMMENT '明细类型',
  `number` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '明细数字',
  `balance` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '剩余',
  `mark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 = 带确定 1 = 有效 -1 = 无效',
  `take` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = 未收货 1 = 已收货',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `openid` (`uid`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `pm` (`pm`) USING BTREE,
  KEY `type` (`category`,`type`,`link_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5278 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户账单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_bill`
--

/*!40000 ALTER TABLE `eb_user_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_box`
--

DROP TABLE IF EXISTS `eb_user_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_box` (
  `id` int NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(255) DEFAULT NULL,
  `order_id` int NOT NULL DEFAULT '0' COMMENT '订单表关联ID',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '分类ID',
  `cate_name` varchar(255) DEFAULT '' COMMENT '分类名称',
  `cate_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '盲盒价格',
  `product_id` int DEFAULT '0' COMMENT '商品ID',
  `product_name` varchar(255) DEFAULT '' COMMENT '商品名称',
  `product_image` varchar(255) DEFAULT NULL COMMENT '商品图片',
  `product_price` decimal(10,2) DEFAULT '0.00' COMMENT '商品价格',
  `brand_id` int DEFAULT '0' COMMENT '品牌ID',
  `freight_money` decimal(10,2) DEFAULT '0.00' COMMENT '运费金额',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=待操作,1=已回收,2=待发货,3=已发货',
  `pay_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=待支付,1=已支付',
  `pay_money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '实际支付金额',
  `pay_time` int NOT NULL DEFAULT '0' COMMENT '支付时间',
  `createtime` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int NOT NULL DEFAULT '0' COMMENT '修改时间',
  `huanqu_id` int NOT NULL DEFAULT '0' COMMENT '换取表关联ID',
  `huanqu_unique` varchar(50) DEFAULT '' COMMENT '兑换码',
  `real_name` varchar(255) DEFAULT NULL,
  `user_phone` varchar(50) DEFAULT NULL,
  `user_address` varchar(255) DEFAULT NULL,
  `pay_type` varchar(255) DEFAULT '' COMMENT '支付类型',
  `is_tanchu` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已弹出',
  `is_jiqiren` tinyint(1) NOT NULL DEFAULT '0',
  `tag` int NOT NULL DEFAULT '0' COMMENT '商品标签',
  `rand_num` int NOT NULL DEFAULT '0' COMMENT '随机数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=972839 DEFAULT CHARSET=utf8mb3 COMMENT='用户盲盒表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_box`
--

/*!40000 ALTER TABLE `eb_user_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_brokerage`
--

DROP TABLE IF EXISTS `eb_user_brokerage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_brokerage` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '用户佣金id',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户uid',
  `link_id` varchar(32) NOT NULL DEFAULT '0' COMMENT '关联id',
  `type` varchar(64) NOT NULL DEFAULT '' COMMENT '明细类型',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '账单标题',
  `number` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '明细数字',
  `balance` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '剩余',
  `pm` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0 = 支出 1 = 获得',
  `mark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 = 带确定 1 = 有效 -1 = 无效',
  `take` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = 未收货 1 = 已收货',
  `frozen_time` int unsigned NOT NULL DEFAULT '0' COMMENT '冻结到期时间',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `pm` (`pm`) USING BTREE,
  KEY `type` (`type`,`link_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='用户账单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_brokerage`
--

/*!40000 ALTER TABLE `eb_user_brokerage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_brokerage_frozen`
--

DROP TABLE IF EXISTS `eb_user_brokerage_frozen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_brokerage_frozen` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '金额',
  `uill_id` int NOT NULL DEFAULT '0' COMMENT '关联id',
  `frozen_time` int NOT NULL DEFAULT '0' COMMENT '冻结到期时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否有效',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `order_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '订单id',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户佣金冻结记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_brokerage_frozen`
--

/*!40000 ALTER TABLE `eb_user_brokerage_frozen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_card`
--

DROP TABLE IF EXISTS `eb_user_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_card` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT 'UID',
  `spread_uid` int NOT NULL DEFAULT '0' COMMENT '推广用户uid',
  `wechat_card_id` int NOT NULL DEFAULT '0' COMMENT 'wechat_card表主键',
  `card_id` varchar(50) NOT NULL DEFAULT '' COMMENT 'card_id',
  `code` varchar(50) NOT NULL DEFAULT '' COMMENT '会员卡号',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `staff_id` int NOT NULL DEFAULT '0' COMMENT '店员ID',
  `openid` varchar(100) NOT NULL DEFAULT '' COMMENT '微信openid',
  `is_submit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否激活',
  `submit_time` int NOT NULL DEFAULT '0' COMMENT '激活时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `del_time` int NOT NULL DEFAULT '0' COMMENT '删除时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='用户领取卡券';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_card`
--

/*!40000 ALTER TABLE `eb_user_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_choujiang_set`
--

DROP TABLE IF EXISTS `eb_user_choujiang_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_choujiang_set` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `cate_id` int NOT NULL DEFAULT '0',
  `pid` int NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `createtime` int NOT NULL DEFAULT '0',
  `updatetime` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='盲盒中奖设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_choujiang_set`
--

/*!40000 ALTER TABLE `eb_user_choujiang_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_enter`
--

DROP TABLE IF EXISTS `eb_user_enter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_enter` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '商户申请ID',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `province` varchar(32) NOT NULL DEFAULT '' COMMENT '商户所在省',
  `city` varchar(32) NOT NULL DEFAULT '' COMMENT '商户所在市',
  `district` varchar(32) NOT NULL DEFAULT '' COMMENT '商户所在区',
  `address` varchar(256) NOT NULL DEFAULT '' COMMENT '商户详细地址',
  `merchant_name` varchar(256) NOT NULL DEFAULT '' COMMENT '商户名称',
  `link_user` varchar(32) NOT NULL DEFAULT '',
  `link_tel` varchar(16) NOT NULL DEFAULT '' COMMENT '商户电话',
  `charter` varchar(512) NOT NULL DEFAULT '' COMMENT '商户证书',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `apply_time` int unsigned NOT NULL DEFAULT '0' COMMENT '审核时间',
  `success_time` int NOT NULL DEFAULT '0' COMMENT '通过时间',
  `fail_message` varchar(256) NOT NULL DEFAULT '' COMMENT '未通过原因',
  `fail_time` int unsigned NOT NULL DEFAULT '0' COMMENT '未通过时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '-1 审核未通过 0未审核 1审核通过',
  `is_lock` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0 = 开启 1= 关闭',
  `is_del` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `uid` (`uid`) USING BTREE,
  KEY `province` (`province`,`city`,`district`) USING BTREE,
  KEY `is_lock` (`is_lock`) USING BTREE,
  KEY `is_del` (`is_del`) USING BTREE,
  KEY `status` (`status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商户申请表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_enter`
--

/*!40000 ALTER TABLE `eb_user_enter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_extract`
--

DROP TABLE IF EXISTS `eb_user_extract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_extract` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `uid` int unsigned NOT NULL DEFAULT '0',
  `real_name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `extract_type` varchar(32) NOT NULL DEFAULT 'bank' COMMENT 'bank = 银行卡 alipay = 支付宝wx=微信',
  `bank_code` varchar(32) NOT NULL DEFAULT '0' COMMENT '银行卡',
  `bank_address` varchar(256) NOT NULL DEFAULT '' COMMENT '开户地址',
  `alipay_code` varchar(64) NOT NULL DEFAULT '' COMMENT '支付宝账号',
  `extract_price` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '提现金额',
  `extract_fee` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '手续费金额',
  `mark` varchar(512) NOT NULL DEFAULT '',
  `balance` decimal(12,2) unsigned NOT NULL DEFAULT '0.00',
  `fail_msg` varchar(128) NOT NULL DEFAULT '' COMMENT '无效原因',
  `fail_time` int unsigned NOT NULL DEFAULT '0',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '-1 未通过 0 审核中 1 已提现',
  `wechat` varchar(15) NOT NULL DEFAULT '' COMMENT '微信号',
  `qrcode_url` varchar(255) NOT NULL DEFAULT '' COMMENT '二维码地址',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `extract_type` (`extract_type`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `openid` (`uid`) USING BTREE,
  KEY `fail_time` (`fail_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户提现表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_extract`
--

/*!40000 ALTER TABLE `eb_user_extract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_friends`
--

DROP TABLE IF EXISTS `eb_user_friends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_friends` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `friends_uid` int NOT NULL DEFAULT '0' COMMENT '好友uid',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户好友关系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_friends`
--

/*!40000 ALTER TABLE `eb_user_friends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_group`
--

DROP TABLE IF EXISTS `eb_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_group` (
  `id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `group_name` varchar(64) NOT NULL DEFAULT '' COMMENT '用户分组名称',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户分组表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_group`
--

/*!40000 ALTER TABLE `eb_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_invoice`
--

DROP TABLE IF EXISTS `eb_user_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0',
  `header_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '抬头类型1:个人2：企业',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '发票类型1：普通2：专用',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '名称（发票抬头）',
  `duty_number` varchar(50) NOT NULL DEFAULT '' COMMENT '税号',
  `drawer_phone` varchar(30) NOT NULL DEFAULT '' COMMENT '开票人手机号',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '开票人邮箱',
  `tell` varchar(30) NOT NULL DEFAULT '' COMMENT '注册电话',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '注册地址',
  `bank` varchar(50) NOT NULL DEFAULT '' COMMENT '注册开户银行',
  `card_number` varchar(50) NOT NULL DEFAULT '' COMMENT '银行卡号',
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否默认',
  `is_del` tinyint(1) NOT NULL DEFAULT '0',
  `add_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='用户发票管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_invoice`
--

/*!40000 ALTER TABLE `eb_user_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_jiqiren`
--

DROP TABLE IF EXISTS `eb_user_jiqiren`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_jiqiren` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nickname` varchar(255) DEFAULT NULL,
  `avatars` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `add_time` int DEFAULT NULL,
  `login_city` varchar(255) DEFAULT '' COMMENT '地址',
  `is_moren` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是默认头像',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2208 DEFAULT CHARSET=utf8mb3 COMMENT='机器人用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_jiqiren`
--

/*!40000 ALTER TABLE `eb_user_jiqiren` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_jiqiren_touxiang`
--

DROP TABLE IF EXISTS `eb_user_jiqiren_touxiang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_jiqiren_touxiang` (
  `id` int NOT NULL AUTO_INCREMENT,
  `images` varchar(255) DEFAULT NULL,
  `add_time` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=393 DEFAULT CHARSET=utf8mb3 COMMENT='机器人头像表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_jiqiren_touxiang`
--

/*!40000 ALTER TABLE `eb_user_jiqiren_touxiang` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_label`
--

DROP TABLE IF EXISTS `eb_user_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_label` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) DEFAULT '1' COMMENT '类型：1平台2:门店',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `label_cate` int NOT NULL DEFAULT '0' COMMENT '标签分类',
  `label_name` varchar(255) NOT NULL DEFAULT '' COMMENT '标签名称',
  `tag_id` varchar(64) DEFAULT NULL COMMENT '企业微信同步标签id',
  PRIMARY KEY (`id`),
  KEY `label_cate` (`label_cate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户标签表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_label`
--

/*!40000 ALTER TABLE `eb_user_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_label_relation`
--

DROP TABLE IF EXISTS `eb_user_label_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_label_relation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店ID',
  `label_id` int NOT NULL DEFAULT '0' COMMENT '标签ID',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户标签关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_label_relation`
--

/*!40000 ALTER TABLE `eb_user_label_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_level`
--

DROP TABLE IF EXISTS `eb_user_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_level` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `level_id` int NOT NULL DEFAULT '0' COMMENT '等级vip',
  `grade` int NOT NULL DEFAULT '0' COMMENT '会员等级',
  `valid_time` int NOT NULL DEFAULT '0' COMMENT '过期时间',
  `is_forever` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否永久',
  `mer_id` int NOT NULL DEFAULT '0' COMMENT '商户id',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0:禁止,1:正常',
  `mark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `remind` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已通知',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除,0=未删除,1=删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `discount` int NOT NULL DEFAULT '0' COMMENT '享受折扣',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户等级记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_level`
--

/*!40000 ALTER TABLE `eb_user_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_manghe_set`
--

DROP TABLE IF EXISTS `eb_user_manghe_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_manghe_set` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `cate_id` int NOT NULL DEFAULT '0',
  `pid` int NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `createtime` int NOT NULL DEFAULT '0',
  `updatetime` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='盲盒中奖设置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_manghe_set`
--

/*!40000 ALTER TABLE `eb_user_manghe_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_money`
--

DROP TABLE IF EXISTS `eb_user_money`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_money` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '用户余额id',
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户uid',
  `link_id` varchar(32) NOT NULL DEFAULT '0' COMMENT '关联id',
  `type` varchar(64) NOT NULL DEFAULT '' COMMENT '明细类型',
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '账单标题',
  `number` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '明细数字',
  `balance` decimal(12,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '剩余',
  `pm` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0 = 支出 1 = 获得',
  `mark` varchar(512) NOT NULL DEFAULT '' COMMENT '备注',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 = 带确定 1 = 有效 -1 = 无效',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `pm` (`pm`) USING BTREE,
  KEY `type` (`type`,`link_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb3 COMMENT='用户账单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_money`
--

/*!40000 ALTER TABLE `eb_user_money` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_notice`
--

DROP TABLE IF EXISTS `eb_user_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_notice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` text COMMENT '接收消息的用户id（类型：json数据）',
  `type` varchar(255) NOT NULL DEFAULT '1' COMMENT '消息通知类型（1：系统消息；2：用户通知）',
  `user` varchar(20) NOT NULL DEFAULT '' COMMENT '发送人',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '通知消息的标题信息',
  `content` varchar(500) NOT NULL DEFAULT '' COMMENT '通知消息的内容',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '通知消息发送的时间',
  `is_send` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否发送（0：未发送；1：已发送）',
  `send_time` int NOT NULL DEFAULT '0' COMMENT '发送时间',
  `image` varchar(255) DEFAULT NULL COMMENT '封面图片',
  `link_url` varchar(255) DEFAULT NULL COMMENT '跳转链接',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1988 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户通知表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_notice`
--

/*!40000 ALTER TABLE `eb_user_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_notice_see`
--

DROP TABLE IF EXISTS `eb_user_notice_see`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_notice_see` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nid` int NOT NULL DEFAULT '0' COMMENT '查看的通知id',
  `uid` int NOT NULL DEFAULT '0' COMMENT '查看通知的用户id',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '查看通知的时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户通知发送记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_notice_see`
--

/*!40000 ALTER TABLE `eb_user_notice_see` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_recharge`
--

DROP TABLE IF EXISTS `eb_user_recharge`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_recharge` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `uid` int NOT NULL DEFAULT '0' COMMENT '充值用户UID',
  `staff_id` int NOT NULL DEFAULT '0' COMMENT '店员ID',
  `order_id` varchar(32) NOT NULL DEFAULT '' COMMENT '订单号',
  `price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '充值金额',
  `give_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '购买赠送金额',
  `recharge_type` varchar(32) NOT NULL DEFAULT '' COMMENT '充值类型',
  `auth_code` varchar(50) NOT NULL DEFAULT '' COMMENT '收款码条码值',
  `paid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否充值',
  `pay_time` int NOT NULL DEFAULT '0' COMMENT '充值支付时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '充值时间',
  `refund_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '退款金额',
  `channel_type` varchar(255) NOT NULL DEFAULT '' COMMENT '用户访问端标识',
  `remarks` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `order_id` (`order_id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE,
  KEY `recharge_type` (`recharge_type`) USING BTREE,
  KEY `paid` (`paid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户充值表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_recharge`
--

/*!40000 ALTER TABLE `eb_user_recharge` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_relation`
--

DROP TABLE IF EXISTS `eb_user_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_relation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `relation_id` int unsigned NOT NULL DEFAULT '0' COMMENT '关联ID',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '类型(收藏(collect）、点赞(like))',
  `category` varchar(32) NOT NULL DEFAULT '' COMMENT '某种类型的商品(普通商品、秒杀商品、文章)',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `type` (`type`) USING BTREE,
  KEY `category` (`category`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=900 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='商品点赞和收藏表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_relation`
--

/*!40000 ALTER TABLE `eb_user_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_search`
--

DROP TABLE IF EXISTS `eb_user_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_search` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `keyword` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '搜索关键词',
  `vicword` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '关键词分词',
  `num` int NOT NULL DEFAULT '1' COMMENT '搜索次数',
  `result` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '搜索结果',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户搜索记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_search`
--

/*!40000 ALTER TABLE `eb_user_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_sign`
--

DROP TABLE IF EXISTS `eb_user_sign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_sign` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '签到说明',
  `number` int NOT NULL DEFAULT '0' COMMENT '获得积分',
  `balance` int NOT NULL DEFAULT '0' COMMENT '剩余积分',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=815 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='签到记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_sign`
--

/*!40000 ALTER TABLE `eb_user_sign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_spread`
--

DROP TABLE IF EXISTS `eb_user_spread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_spread` (
  `id` int NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL DEFAULT '0' COMMENT '门店id',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `staff_id` int NOT NULL DEFAULT '0' COMMENT '店员ID',
  `spread_uid` int NOT NULL DEFAULT '0' COMMENT '推广人uid',
  `spread_time` int NOT NULL DEFAULT '0' COMMENT '推广时间',
  `admin_id` int NOT NULL DEFAULT '0' COMMENT '管理员id',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`) USING BTREE,
  KEY `spread_uid` (`spread_uid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户推广关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_spread`
--

/*!40000 ALTER TABLE `eb_user_spread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_user_visit`
--

DROP TABLE IF EXISTS `eb_user_visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_user_visit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户uid',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '访问路径',
  `ip` varchar(255) NOT NULL DEFAULT '' COMMENT '用户ip',
  `stay_time` int NOT NULL DEFAULT '0' COMMENT '页面停留时间(秒)',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '访问时间',
  `channel_type` varchar(255) NOT NULL DEFAULT '' COMMENT '用户访问端标识',
  `province` varchar(255) NOT NULL DEFAULT '' COMMENT '用户省份',
  PRIMARY KEY (`id`),
  KEY `time` (`channel_type`(191),`add_time`)
) ENGINE=InnoDB AUTO_INCREMENT=8648 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户访问表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_user_visit`
--

/*!40000 ALTER TABLE `eb_user_visit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_video`
--

DROP TABLE IF EXISTS `eb_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_video` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型：0:平台1:门店2:用户',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '关联平台管理门店ID、用户UID',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '封面图',
  `desc` varchar(255) NOT NULL DEFAULT '' COMMENT '简介',
  `video_url` varchar(255) NOT NULL DEFAULT '' COMMENT '视频地址',
  `product_id` longtext COMMENT '关联商品ids',
  `like_num` int NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `collect_num` int NOT NULL DEFAULT '0' COMMENT '收藏数量',
  `play_num` int NOT NULL DEFAULT '0' COMMENT '浏览播放数量',
  `comment_num` int NOT NULL DEFAULT '0' COMMENT '评论数量',
  `share_num` int NOT NULL DEFAULT '0' COMMENT '分享数量',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `is_recommend` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否推荐',
  `is_verify` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否审核：-2强制下架-1未通过0未审核1:通过',
  `sort` smallint NOT NULL DEFAULT '0' COMMENT '排序',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='短视频表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_video`
--

/*!40000 ALTER TABLE `eb_video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_video_comment`
--

DROP TABLE IF EXISTS `eb_video_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_video_comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型：0:平台1:门店2:用户',
  `relation_id` int NOT NULL DEFAULT '0' COMMENT '发布视频门店ID、用户UID',
  `pid` int NOT NULL DEFAULT '0' COMMENT '上级回复id',
  `video_id` int NOT NULL DEFAULT '0' COMMENT '视频id',
  `uid` int NOT NULL DEFAULT '0',
  `nickname` varchar(64) NOT NULL DEFAULT '' COMMENT '用户名称',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '用户头像',
  `like_num` int NOT NULL DEFAULT '0' COMMENT '点赞数量',
  `content` varchar(1000) NOT NULL DEFAULT '' COMMENT '评论内容',
  `ip` varchar(32) NOT NULL DEFAULT '' COMMENT '评论ip',
  `city` varchar(255) NOT NULL DEFAULT '' COMMENT '城市',
  `is_reply` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否回复',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `video_id` (`video_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='短视频评价回复表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_video_comment`
--

/*!40000 ALTER TABLE `eb_video_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_wechat_card`
--

DROP TABLE IF EXISTS `eb_wechat_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_wechat_card` (
  `id` int NOT NULL AUTO_INCREMENT,
  `card_id` varchar(50) NOT NULL DEFAULT '' COMMENT '卡券ID（微信返回）',
  `card_type` varchar(20) NOT NULL DEFAULT 'member_card' COMMENT '卡券类型：默认会员卡',
  `code_type` varchar(20) NOT NULL DEFAULT '' COMMENT '码类型',
  `brand_name` varchar(50) NOT NULL DEFAULT '' COMMENT '商户名称',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '卡券名称',
  `color` varchar(15) NOT NULL DEFAULT '' COMMENT '颜色',
  `notice` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '卡券使用提醒',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '描述',
  `center_title` varchar(255) NOT NULL DEFAULT '' COMMENT '卡券中部居中的按钮，仅在卡券激活后且可用状态 时显示',
  `center_sub_title` varchar(255) NOT NULL DEFAULT '' COMMENT '显示在入口下方的提示语 ， 仅在卡券激活后且可用状态时显示',
  `center_url` varchar(255) NOT NULL DEFAULT '' COMMENT '顶部居中的url ，仅在卡券激活后且可用状态时显示',
  `service_phone` varchar(30) NOT NULL DEFAULT '' COMMENT '联系方式',
  `logo_url` varchar(255) NOT NULL DEFAULT '' COMMENT 'logo URL',
  `background_pic_url` varchar(255) NOT NULL DEFAULT '' COMMENT '背景图',
  `prerogative` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '特权说明',
  `especial` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '特别追加参数',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='微信卡券表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_wechat_card`
--

/*!40000 ALTER TABLE `eb_wechat_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_wechat_key`
--

DROP TABLE IF EXISTS `eb_wechat_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_wechat_key` (
  `id` mediumint NOT NULL AUTO_INCREMENT,
  `reply_id` mediumint NOT NULL DEFAULT '0' COMMENT '回复内容id',
  `keys` varchar(64) NOT NULL DEFAULT '' COMMENT '关键词',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='微信回复关键词辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_wechat_key`
--

/*!40000 ALTER TABLE `eb_wechat_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_wechat_media`
--

DROP TABLE IF EXISTS `eb_wechat_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_wechat_media` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '微信视频音频id',
  `type` varchar(16) NOT NULL DEFAULT '' COMMENT '回复类型',
  `path` varchar(128) NOT NULL DEFAULT '' COMMENT '文件路径',
  `media_id` varchar(64) NOT NULL DEFAULT '' COMMENT '微信服务器返回的id',
  `url` varchar(256) NOT NULL DEFAULT '' COMMENT '地址',
  `temporary` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否永久或者临时 0永久1临时',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `type` (`type`,`media_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='微信回复表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_wechat_media`
--

/*!40000 ALTER TABLE `eb_wechat_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_wechat_message`
--

DROP TABLE IF EXISTS `eb_wechat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_wechat_message` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '用户行为记录id',
  `openid` varchar(32) NOT NULL DEFAULT '' COMMENT '用户openid',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '操作类型',
  `result` varchar(512) NOT NULL DEFAULT '' COMMENT '操作详细记录',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '操作时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `openid` (`openid`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户行为记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_wechat_message`
--

/*!40000 ALTER TABLE `eb_wechat_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_wechat_news_category`
--

DROP TABLE IF EXISTS `eb_wechat_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_wechat_news_category` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '图文消息管理ID',
  `cate_name` varchar(255) NOT NULL DEFAULT '' COMMENT '图文名称',
  `sort` int unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '状态',
  `new_id` varchar(255) NOT NULL DEFAULT '' COMMENT '文章id',
  `add_time` varchar(255) NOT NULL DEFAULT '' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='图文消息管理表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_wechat_news_category`
--

/*!40000 ALTER TABLE `eb_wechat_news_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_wechat_qrcode`
--

DROP TABLE IF EXISTS `eb_wechat_qrcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_wechat_qrcode` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '编号',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户id',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '二维码名称',
  `image` varchar(500) NOT NULL DEFAULT '' COMMENT '二维码图片',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '分类id',
  `label_id` varchar(32) NOT NULL DEFAULT '' COMMENT '标签id',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '回复类型',
  `content` text COMMENT '回复内容',
  `data` text COMMENT '发送数据',
  `follow` int NOT NULL DEFAULT '0' COMMENT '关注人数',
  `scan` int NOT NULL DEFAULT '0' COMMENT '扫码人数',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `continue_time` int NOT NULL DEFAULT '0' COMMENT '有效期',
  `end_time` int NOT NULL DEFAULT '0' COMMENT '到期时间',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='二维码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_wechat_qrcode`
--

/*!40000 ALTER TABLE `eb_wechat_qrcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_wechat_qrcode_cate`
--

DROP TABLE IF EXISTS `eb_wechat_qrcode_cate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_wechat_qrcode_cate` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `cate_name` varchar(255) NOT NULL DEFAULT '' COMMENT '渠道码分类名称',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COMMENT='二维码类型表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_wechat_qrcode_cate`
--

/*!40000 ALTER TABLE `eb_wechat_qrcode_cate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_wechat_qrcode_record`
--

DROP TABLE IF EXISTS `eb_wechat_qrcode_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_wechat_qrcode_record` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `qid` int NOT NULL DEFAULT '0' COMMENT '渠道码id',
  `uid` int NOT NULL DEFAULT '0' COMMENT '用户id',
  `is_follow` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否关注',
  `add_time` int NOT NULL DEFAULT '0' COMMENT '扫码时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COMMENT='渠道码扫码记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_wechat_qrcode_record`
--

/*!40000 ALTER TABLE `eb_wechat_qrcode_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_wechat_reply`
--

DROP TABLE IF EXISTS `eb_wechat_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_wechat_reply` (
  `id` mediumint unsigned NOT NULL AUTO_INCREMENT COMMENT '微信关键字回复id',
  `type` varchar(32) NOT NULL DEFAULT '' COMMENT '回复类型',
  `data` text COMMENT '回复数据',
  `status` tinyint unsigned NOT NULL DEFAULT '1' COMMENT '0=不可用  1 =可用',
  `hide` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `type` (`type`) USING BTREE,
  KEY `status` (`status`) USING BTREE,
  KEY `hide` (`hide`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='微信关键字回复表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_wechat_reply`
--

/*!40000 ALTER TABLE `eb_wechat_reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_wechat_user`
--

DROP TABLE IF EXISTS `eb_wechat_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_wechat_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uid` int unsigned NOT NULL DEFAULT '0' COMMENT '微信用户id',
  `unionid` varchar(30) NOT NULL DEFAULT '' COMMENT '只有在用户将公众号绑定到微信开放平台帐号后，才会出现该字段',
  `openid` varchar(100) NOT NULL DEFAULT '' COMMENT '用户的标识，对当前公众号唯一',
  `nickname` varchar(64) NOT NULL DEFAULT '' COMMENT '用户的昵称',
  `headimgurl` varchar(256) NOT NULL DEFAULT '' COMMENT '用户头像',
  `sex` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '用户的性别，值为1时是男性，值为2时是女性，值为0时是未知',
  `city` varchar(64) NOT NULL DEFAULT '' COMMENT '用户所在城市',
  `language` varchar(64) NOT NULL DEFAULT '' COMMENT '用户的语言，简体中文为zh_CN',
  `province` varchar(64) NOT NULL DEFAULT '' COMMENT '用户所在省份',
  `country` varchar(64) NOT NULL DEFAULT '' COMMENT '用户所在国家',
  `remark` varchar(256) NOT NULL DEFAULT '' COMMENT '公众号运营者对粉丝的备注，公众号运营者可在微信公众平台用户管理界面对粉丝添加备注',
  `groupid` smallint unsigned DEFAULT '0' COMMENT '用户所在的分组ID（兼容旧的用户分组接口）',
  `tagid_list` varchar(256) NOT NULL DEFAULT '' COMMENT '用户被打上的标签ID列表',
  `subscribe` tinyint unsigned DEFAULT '1' COMMENT '用户是否订阅该公众号标识',
  `subscribe_time` int unsigned NOT NULL DEFAULT '0' COMMENT '关注公众号时间',
  `add_time` int unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `second` int unsigned NOT NULL DEFAULT '0' COMMENT '二级推荐人',
  `user_type` varchar(32) NOT NULL DEFAULT 'wechat' COMMENT '用户类型',
  `is_complete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '授权信息是否完整',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `openid` (`openid`) USING BTREE,
  KEY `groupid` (`groupid`) USING BTREE,
  KEY `subscribe_time` (`subscribe_time`) USING BTREE,
  KEY `add_time` (`add_time`) USING BTREE,
  KEY `subscribe` (`subscribe`) USING BTREE,
  KEY `unionid` (`unionid`) USING BTREE,
  KEY `uid` (`uid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='微信用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_wechat_user`
--

/*!40000 ALTER TABLE `eb_wechat_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_channel_code`
--

DROP TABLE IF EXISTS `eb_work_channel_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_channel_code` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型：0=全天在线；1=自动上下线',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '二维码名称',
  `cate_id` int NOT NULL DEFAULT '0' COMMENT '分类',
  `label_id` varchar(1000) NOT NULL DEFAULT '' COMMENT '客户标签',
  `reserve_userid` varchar(64) NOT NULL DEFAULT '' COMMENT '备用成员',
  `userids` varchar(1000) NOT NULL DEFAULT '' COMMENT '全天在线成员',
  `skip_verify` tinyint(1) NOT NULL DEFAULT '0' COMMENT '自动加好友：0=关闭，1=开启',
  `add_upper_limit` tinyint(1) NOT NULL DEFAULT '0' COMMENT '员工添加上限0=关闭,1=开启',
  `welcome_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=使用渠道欢迎，1=默认欢迎语',
  `welcome_words` varchar(1000) NOT NULL DEFAULT '' COMMENT '欢迎语',
  `qrcode_url` varchar(255) NOT NULL DEFAULT '' COMMENT '联系我二维码链接',
  `config_id` varchar(64) NOT NULL DEFAULT '' COMMENT '新增联系方式的配置id',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态：1=开启，0=关闭',
  `client_num` int NOT NULL DEFAULT '0' COMMENT '扫码添加客户人数',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `delete_time` int DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  KEY `cate_id` (`cate_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业渠道码（联系我）';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_channel_code`
--

/*!40000 ALTER TABLE `eb_work_channel_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_channel_cycle`
--

DROP TABLE IF EXISTS `eb_work_channel_cycle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_channel_cycle` (
  `channel_id` int NOT NULL DEFAULT '0' COMMENT '渠道码',
  `userids` varchar(1000) NOT NULL DEFAULT '' COMMENT '成员userid',
  `start_time` varchar(5) NOT NULL DEFAULT '' COMMENT '上班开始',
  `end_time` varchar(5) NOT NULL DEFAULT '' COMMENT '上班结束',
  `wokr_time` varchar(50) NOT NULL DEFAULT '' COMMENT '工作周期，json转换',
  KEY `channel_id` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='渠道码周期规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_channel_cycle`
--

/*!40000 ALTER TABLE `eb_work_channel_cycle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_channel_limit`
--

DROP TABLE IF EXISTS `eb_work_channel_limit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_channel_limit` (
  `channel_id` int NOT NULL DEFAULT '0' COMMENT '渠道码id',
  `userid` varchar(64) NOT NULL DEFAULT '' COMMENT '成员userid',
  `max` int NOT NULL DEFAULT '0' COMMENT '限制个数',
  KEY `channel_id` (`channel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='渠道码添加成员限制器';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_channel_limit`
--

/*!40000 ALTER TABLE `eb_work_channel_limit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_client`
--

DROP TABLE IF EXISTS `eb_work_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_client` (
  `id` int NOT NULL AUTO_INCREMENT,
  `corp_id` varchar(18) NOT NULL DEFAULT '' COMMENT '企业微信id',
  `external_userid` varchar(64) NOT NULL DEFAULT '' COMMENT '外部联系人的userid',
  `uid` int NOT NULL DEFAULT '0' COMMENT '商城用户uid',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '外部联系人的名称',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '外部联系人头像',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1表示该外部联系人是微信用户，2表示该外部联系人是企业微信用户',
  `gender` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别 0-未知 1-男性 2-女性',
  `unionid` varchar(64) NOT NULL DEFAULT '' COMMENT '开放平台的唯一身份标识',
  `position` varchar(50) NOT NULL DEFAULT '' COMMENT '外部联系人的职位',
  `corp_name` varchar(50) NOT NULL DEFAULT '' COMMENT '外部联系人所在企业的简称',
  `corp_full_name` varchar(100) DEFAULT NULL COMMENT '外部联系人所在企业的主体名称',
  `external_profile` varchar(1000) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `create_time` int NOT NULL DEFAULT '0',
  `update_time` int NOT NULL DEFAULT '0',
  `delete_time` int DEFAULT NULL COMMENT '删除时间戳',
  PRIMARY KEY (`id`),
  KEY `external_userid` (`external_userid`),
  KEY `corp_id` (`corp_id`,`external_userid`),
  KEY `uid` (`uid`),
  KEY `unionid` (`unionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信客户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_client`
--

/*!40000 ALTER TABLE `eb_work_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_client_follow`
--

DROP TABLE IF EXISTS `eb_work_client_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_client_follow` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_id` int NOT NULL DEFAULT '0' COMMENT '客户id',
  `userid` varchar(64) NOT NULL DEFAULT '' COMMENT '添加了此外部联系人的企业成员userid',
  `remark` varchar(50) NOT NULL DEFAULT '' COMMENT '该成员对此外部联系人的备注',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '该成员对此外部联系人的描述',
  `createtime` int NOT NULL DEFAULT '0' COMMENT '该成员添加此外部联系人的时间',
  `remark_corp_name` varchar(50) DEFAULT NULL COMMENT '该成员对此微信客户备注的企业名称',
  `remark_mobiles` varchar(255) NOT NULL DEFAULT '' COMMENT '该成员对此客户备注的手机号码',
  `add_way` int NOT NULL DEFAULT '0' COMMENT '该成员添加此客户的来源',
  `oper_userid` varchar(64) NOT NULL DEFAULT '' COMMENT '发起添加的userid，如果成员主动添加，为成员的userid；如果是客户主动添加，则为客户的外部联系人userid；如果是内部成员共享/管理员分配，则为对应的成员/管理员userid',
  `state` varchar(30) NOT NULL DEFAULT '' COMMENT '自定义字段返回数据',
  `is_del_user` tinyint(1) NOT NULL DEFAULT '0' COMMENT '客户是否删除跟踪人:0=没有,1=删除',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `state` (`state`),
  KEY `client_id` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信客服跟踪';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_client_follow`
--

/*!40000 ALTER TABLE `eb_work_client_follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_client_follow_tags`
--

DROP TABLE IF EXISTS `eb_work_client_follow_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_client_follow_tags` (
  `follow_id` int NOT NULL DEFAULT '0' COMMENT '跟踪人id',
  `group_name` varchar(255) NOT NULL DEFAULT '' COMMENT '该成员添加此外部联系人所打标签的分组名称',
  `tag_name` varchar(255) NOT NULL DEFAULT '' COMMENT '该成员添加此外部联系人所打标签名称',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1-企业设置，2-用户自定义，3-规则组标签',
  `tag_id` varchar(32) NOT NULL DEFAULT '' COMMENT '该成员添加此外部联系人所打企业标签的id，用户自定义类型标签（type=2）不返回',
  `create_time` int NOT NULL,
  KEY `follow_id` (`follow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信客户跟踪标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_client_follow_tags`
--

/*!40000 ALTER TABLE `eb_work_client_follow_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_department`
--

DROP TABLE IF EXISTS `eb_work_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_department` (
  `id` int NOT NULL AUTO_INCREMENT,
  `corp_id` varchar(18) NOT NULL DEFAULT '' COMMENT '企业id',
  `department_id` int DEFAULT '0' COMMENT '部门id',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '部门名称',
  `name_en` varchar(50) NOT NULL DEFAULT '' COMMENT '部门英文名称',
  `department_leader` varchar(1000) NOT NULL DEFAULT '' COMMENT 'leader',
  `parentid` int NOT NULL DEFAULT '0' COMMENT '上级id',
  `srot` int NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信部门';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_department`
--

/*!40000 ALTER TABLE `eb_work_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_group_chat`
--

DROP TABLE IF EXISTS `eb_work_group_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_group_chat` (
  `id` int NOT NULL AUTO_INCREMENT,
  `corp_id` varchar(18) NOT NULL DEFAULT '' COMMENT '企业ID',
  `chat_id` varchar(40) NOT NULL DEFAULT '' COMMENT '客户群ID',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '群名',
  `owner` varchar(64) NOT NULL DEFAULT '' COMMENT '群主ID',
  `group_create_time` int NOT NULL DEFAULT '0' COMMENT '群的创建时间',
  `notice` varchar(255) NOT NULL DEFAULT '' COMMENT '群公告',
  `admin_list` varchar(1000) NOT NULL DEFAULT '' COMMENT '群管理员userid',
  `member_num` int NOT NULL DEFAULT '0' COMMENT '群人数',
  `retreat_group_num` int NOT NULL DEFAULT '0' COMMENT '退群总数',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '客户群跟进状态。\r\n0 - 跟进人正常\r\n1 - 跟进人离职\r\n2 - 离职继承中\r\n3 - 离职继承完成',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `corp_id` (`corp_id`,`chat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信群';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_group_chat`
--

/*!40000 ALTER TABLE `eb_work_group_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_group_chat_auth`
--

DROP TABLE IF EXISTS `eb_work_group_chat_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_group_chat_auth` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '二维码名称',
  `auth_group_chat` tinyint(1) NOT NULL DEFAULT '0' COMMENT '自动建群0=关闭，1=开启',
  `chat_id` varchar(1000) NOT NULL DEFAULT '' COMMENT '群聊chat_id',
  `group_name` varchar(100) NOT NULL DEFAULT '' COMMENT '群名称',
  `group_num` int NOT NULL DEFAULT '0' COMMENT '群序列号',
  `label` varchar(255) NOT NULL DEFAULT '' COMMENT '客户标签',
  `config_id` varchar(64) DEFAULT NULL COMMENT '配置id',
  `qr_code` varchar(255) DEFAULT NULL COMMENT '联系二维码的UR',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新',
  `delete_time` int DEFAULT NULL COMMENT '删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信自动拉群';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_group_chat_auth`
--

/*!40000 ALTER TABLE `eb_work_group_chat_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_group_chat_member`
--

DROP TABLE IF EXISTS `eb_work_group_chat_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_group_chat_member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL DEFAULT '0' COMMENT '企业群ID',
  `userid` varchar(64) NOT NULL DEFAULT '' COMMENT '群成员id',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '成员类型。\r\n1 - 企业成员\r\n2 - 外部联系人',
  `unionid` varchar(64) NOT NULL DEFAULT '' COMMENT '微信开放平台的唯一身份标识（微信unionid）',
  `join_time` int NOT NULL DEFAULT '0' COMMENT '入群时间',
  `join_scene` tinyint(1) NOT NULL DEFAULT '0' COMMENT '入群方式。\r\n1 - 由群成员邀请入群（直接邀请入群）\r\n2 - 由群成员邀请入群（通过邀请链接入群）\r\n3 - 通过扫描群二维码入群',
  `invitor_userid` varchar(64) NOT NULL DEFAULT '' COMMENT '邀请者。目前仅当是由本企业内部成员邀请入群时会返回该值',
  `group_nickname` varchar(100) NOT NULL DEFAULT '' COMMENT '在群里的昵称',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '名字。仅当 need_name = 1 时返回',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=在群中,0=已退群',
  `chat_sum` int NOT NULL DEFAULT '0' COMMENT '当前群人数',
  `retreat_chat_num` int NOT NULL DEFAULT '0' COMMENT '当前退群人数',
  `state` varchar(100) DEFAULT NULL,
  `create_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`),
  KEY `group_id_2` (`group_id`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信群成员列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_group_chat_member`
--

/*!40000 ALTER TABLE `eb_work_group_chat_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_group_chat_statistic`
--

DROP TABLE IF EXISTS `eb_work_group_chat_statistic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_group_chat_statistic` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL DEFAULT '0' COMMENT '群id',
  `today_sum` int NOT NULL DEFAULT '0' COMMENT '今日新增人员',
  `today_return_sum` int NOT NULL DEFAULT '0' COMMENT '今日退群人员',
  `chat_sum` int NOT NULL DEFAULT '0' COMMENT '当前群人员',
  `chat_return_sum` int NOT NULL DEFAULT '0' COMMENT '当前退群人员',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信群统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_group_chat_statistic`
--

/*!40000 ALTER TABLE `eb_work_group_chat_statistic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_group_msg_relation`
--

DROP TABLE IF EXISTS `eb_work_group_msg_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_group_msg_relation` (
  `template_id` int NOT NULL DEFAULT '0' COMMENT '群发模板id',
  `msg_id` varchar(64) NOT NULL DEFAULT '' COMMENT '群发消息id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业群发消息id关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_group_msg_relation`
--

/*!40000 ALTER TABLE `eb_work_group_msg_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_group_msg_send_result`
--

DROP TABLE IF EXISTS `eb_work_group_msg_send_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_group_msg_send_result` (
  `id` int NOT NULL AUTO_INCREMENT,
  `msg_id` varchar(64) NOT NULL DEFAULT '' COMMENT '消息id',
  `external_userid` varchar(64) DEFAULT NULL COMMENT '外部联系人userid，群发消息到企业的客户群不返回该字段',
  `chat_id` varchar(64) DEFAULT NULL COMMENT '外部客户群id，群发消息到客户不返回该字段',
  `userid` varchar(64) NOT NULL DEFAULT '' COMMENT '企业服务人员的userid',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0-未发送 1-已发送 2-因客户不是好友导致发送失败 3-因客户已经收到其他群发消息导致发送失败',
  `send_time` int NOT NULL DEFAULT '0' COMMENT '发送时间，发送状态为1时返回',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `msg_id` (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业群发记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_group_msg_send_result`
--

/*!40000 ALTER TABLE `eb_work_group_msg_send_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_group_msg_task`
--

DROP TABLE IF EXISTS `eb_work_group_msg_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_group_msg_task` (
  `id` int NOT NULL AUTO_INCREMENT,
  `msg_id` varchar(64) NOT NULL DEFAULT '' COMMENT '消息id',
  `userid` varchar(64) NOT NULL DEFAULT '' COMMENT '成员id',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态0-未发送 2-已发送',
  `send_time` int NOT NULL DEFAULT '0' COMMENT '发送时间',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `msg_id` (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='群发成员发送任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_group_msg_task`
--

/*!40000 ALTER TABLE `eb_work_group_msg_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_group_template`
--

DROP TABLE IF EXISTS `eb_work_group_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_group_template` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=客户群发，1=客户群群发',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '名称',
  `userids` text COMMENT '成员userid',
  `client_type` tinyint(1) DEFAULT '0' COMMENT '0=全部客户，1=筛选客户',
  `where_time` varchar(100) NOT NULL DEFAULT '' COMMENT '筛选时间',
  `where_label` text COMMENT '筛选标签',
  `where_not_label` text COMMENT '筛选排除标签',
  `template_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=立即发送，1=定时发送',
  `send_time` int DEFAULT '0' COMMENT '定时发送时间',
  `send_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否发送1=已发送，2=正在发送中，0=没有发送',
  `welcome_words` text COMMENT '群发内容',
  `fail_external_userid` text COMMENT '发送失败的客户userid',
  `fail_message` varchar(255) DEFAULT NULL COMMENT '发送失败原因',
  `create_time` int NOT NULL DEFAULT '0',
  `update_time` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `template_type` (`template_type`,`send_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信群发';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_group_template`
--

/*!40000 ALTER TABLE `eb_work_group_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_label`
--

DROP TABLE IF EXISTS `eb_work_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_label` (
  `id` int NOT NULL AUTO_INCREMENT,
  `corp_id` varchar(18) NOT NULL DEFAULT '' COMMENT '企业微信id',
  `group_id` int NOT NULL DEFAULT '0' COMMENT '标签组id',
  `group_name` varchar(50) NOT NULL DEFAULT '' COMMENT '标签组名称',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '标签名称',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间 ',
  PRIMARY KEY (`id`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_label`
--

/*!40000 ALTER TABLE `eb_work_label` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_media`
--

DROP TABLE IF EXISTS `eb_work_media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `md5_path` varchar(32) DEFAULT NULL COMMENT '本地路径md5值',
  `type` enum('image','voice','video','file') DEFAULT 'image' COMMENT '素材类型',
  `upload_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=临时素材附件,1=朋友圈附件,2=商品附件',
  `path` varchar(255) DEFAULT NULL COMMENT '本地文件路径',
  `media_id` varchar(255) DEFAULT NULL COMMENT '媒体文件上传后获取的唯一标识',
  `url` varchar(255) DEFAULT NULL COMMENT '永久素材路径',
  `temporary` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=永久，1=非永久',
  `valid_time` int NOT NULL DEFAULT '0' COMMENT '有效期',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`md5_path`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信素材';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_media`
--

/*!40000 ALTER TABLE `eb_work_media` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_member`
--

DROP TABLE IF EXISTS `eb_work_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `corp_id` varchar(18) NOT NULL DEFAULT '' COMMENT '企业微信id',
  `userid` varchar(64) NOT NULL DEFAULT '' COMMENT '成员UserID',
  `uid` int NOT NULL DEFAULT '0' COMMENT '商城uid',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '成员名称',
  `position` varchar(50) NOT NULL DEFAULT '' COMMENT '职务信息',
  `mobile` varchar(11) NOT NULL DEFAULT '' COMMENT '手机号码',
  `gender` tinyint(1) NOT NULL DEFAULT '0' COMMENT '性别。0表示未定义，1表示男性，2表示女性',
  `email` varchar(50) NOT NULL DEFAULT '' COMMENT '邮箱',
  `biz_mail` varchar(50) NOT NULL DEFAULT '' COMMENT '企业邮箱',
  `direct_leader` varchar(500) DEFAULT NULL COMMENT '直属上级UserID',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像url',
  `thumb_avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像缩略图url',
  `telephone` varchar(50) NOT NULL DEFAULT '' COMMENT '座机',
  `alias` varchar(30) NOT NULL DEFAULT '' COMMENT '别名',
  `enable` tinyint(1) NOT NULL DEFAULT '0' COMMENT '启用/禁用成员。1表示启用成员，0表示禁用成员',
  `is_leader` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否是领导',
  `hide_mobile` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否隐藏手机号',
  `address` varchar(255) NOT NULL DEFAULT '' COMMENT '地址',
  `open_userid` varchar(64) NOT NULL DEFAULT '' COMMENT '全局唯一',
  `main_department` tinyint(1) NOT NULL DEFAULT '0' COMMENT '主部门',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '激活状态: 1=已激活，2=已禁用，4=未激活，5=退出企业',
  `qr_code` varchar(255) NOT NULL DEFAULT '' COMMENT '员工个人二维码',
  `external_position` varchar(100) NOT NULL DEFAULT '' COMMENT '对外职务',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `userid` (`userid`) USING BTREE,
  KEY `corp_id` (`corp_id`),
  KEY `corp_id_2` (`corp_id`,`userid`),
  KEY `mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信成员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_member`
--

/*!40000 ALTER TABLE `eb_work_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_member_other`
--

DROP TABLE IF EXISTS `eb_work_member_other`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_member_other` (
  `member_id` int NOT NULL DEFAULT '0' COMMENT '企业成员id',
  `extattr` longtext COMMENT '扩展属性',
  `external_profile` longtext COMMENT '成员对外属性',
  UNIQUE KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信成员其他信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_member_other`
--

/*!40000 ALTER TABLE `eb_work_member_other` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_member_relation`
--

DROP TABLE IF EXISTS `eb_work_member_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_member_relation` (
  `member_id` int NOT NULL DEFAULT '0' COMMENT '员工ID',
  `department` int NOT NULL DEFAULT '0' COMMENT '所属部门',
  `srot` int NOT NULL DEFAULT '0' COMMENT '排序',
  `is_leader_in_dept` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为部门负责人',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业成员关联表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_member_relation`
--

/*!40000 ALTER TABLE `eb_work_member_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_moment`
--

DROP TABLE IF EXISTS `eb_work_moment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_moment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '任务名称',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=全部成员，1=选择成员',
  `user_ids` text COMMENT '成员userid',
  `client_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '客户类型0=全部，1=筛选',
  `client_tag_list` text COMMENT '客户标签',
  `welcome_words` text COMMENT '内容',
  `send_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '发送类型',
  `send_time` int NOT NULL DEFAULT '0' COMMENT '定时发送时间',
  `jobid` varchar(64) DEFAULT NULL COMMENT '任务id',
  `invalid_sender_list` text COMMENT '不合法的执行者列表，包括不存在的id以及不在应用可见范围内的部门或者成员',
  `moment_id` varchar(64) NOT NULL DEFAULT '' COMMENT '朋友圈id',
  `invalid_external_contact_list` text COMMENT '无效客户',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `jobid` (`jobid`),
  KEY `moment_id` (`moment_id`),
  KEY `send_time` (`send_time`,`send_type`,`jobid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信发送朋友圈';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_moment`
--

/*!40000 ALTER TABLE `eb_work_moment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_moment_send_result`
--

DROP TABLE IF EXISTS `eb_work_moment_send_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_moment_send_result` (
  `id` int NOT NULL AUTO_INCREMENT,
  `moment_id` varchar(64) NOT NULL DEFAULT '' COMMENT '朋友圈id',
  `user_id` varchar(64) NOT NULL DEFAULT '' COMMENT '成员id',
  `external_userid` text COMMENT '客户ids',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '发送状态',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `moment_id` (`moment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信朋友圈发送情况';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_moment_send_result`
--

/*!40000 ALTER TABLE `eb_work_moment_send_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_welcome`
--

DROP TABLE IF EXISTS `eb_work_welcome`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_welcome` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=通用,1=指定员工',
  `content` text COMMENT '消息内容',
  `attachments` text COMMENT '欢迎语消息体',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int NOT NULL DEFAULT '0' COMMENT '更新时间',
  `delete_time` int DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='企业微信欢迎语';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_welcome`
--

/*!40000 ALTER TABLE `eb_work_welcome` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eb_work_welcome_relation`
--

DROP TABLE IF EXISTS `eb_work_welcome_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `eb_work_welcome_relation` (
  `welcome_id` int NOT NULL DEFAULT '0' COMMENT '欢迎语id',
  `userid` varchar(64) NOT NULL DEFAULT '' COMMENT '用户userid',
  KEY `welcome_id` (`welcome_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='欢迎语辅助表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eb_work_welcome_relation`
--

/*!40000 ALTER TABLE `eb_work_welcome_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_ac`
--

DROP TABLE IF EXISTS `fa_ac`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_ac` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titile` varchar(299) NOT NULL COMMENT '标题',
  `image` varchar(299) NOT NULL COMMENT '预览图',
  `stub` varchar(299) NOT NULL COMMENT '活动简介',
  `content` text NOT NULL COMMENT '活动内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COMMENT='活动管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_ac`
--

/*!40000 ALTER TABLE `fa_ac` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_admin`
--

DROP TABLE IF EXISTS `fa_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_admin` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '昵称',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '密码',
  `salt` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '密码盐',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '头像',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '电子邮箱',
  `mobile` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '手机号码',
  `loginfailure` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `logintime` bigint DEFAULT NULL COMMENT '登录时间',
  `loginip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '登录IP',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `token` varchar(59) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'Session标识',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_admin`
--

/*!40000 ALTER TABLE `fa_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_admin_log`
--

DROP TABLE IF EXISTS `fa_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_admin_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `username` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '管理员名字',
  `url` varchar(1500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '操作页面',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '日志标题',
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '内容',
  `ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'IP',
  `useragent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'User-Agent',
  `createtime` bigint DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`),
  KEY `name` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='管理员日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_admin_log`
--

/*!40000 ALTER TABLE `fa_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_area`
--

DROP TABLE IF EXISTS `fa_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_area` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int DEFAULT NULL COMMENT '父id',
  `shortname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '简称',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `mergename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '全称',
  `level` tinyint DEFAULT NULL COMMENT '层级:1=省,2=市,3=区/县',
  `pinyin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '拼音',
  `code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '长途区号',
  `zip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '邮编',
  `first` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '首字母',
  `lng` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '经度',
  `lat` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '纬度',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3749 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='地区表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_area`
--

/*!40000 ALTER TABLE `fa_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_attachment`
--

DROP TABLE IF EXISTS `fa_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_attachment` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '类别',
  `admin_id` int unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '物理路径',
  `imagewidth` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '宽度',
  `imageheight` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '高度',
  `imagetype` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '图片类型',
  `imageframes` int unsigned NOT NULL DEFAULT '0' COMMENT '图片帧数',
  `filename` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '文件名称',
  `filesize` int unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `mimetype` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'mime类型',
  `extparam` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '透传数据',
  `createtime` bigint DEFAULT NULL COMMENT '创建日期',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `uploadtime` bigint DEFAULT NULL COMMENT '上传时间',
  `storage` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'local' COMMENT '存储位置',
  `sha1` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '文件 sha1编码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=458 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='附件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_attachment`
--

/*!40000 ALTER TABLE `fa_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_auth_group`
--

DROP TABLE IF EXISTS `fa_auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_auth_group` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0' COMMENT '父组别',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '组名',
  `rules` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '规则ID',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分组表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_auth_group`
--

/*!40000 ALTER TABLE `fa_auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_auth_group_access`
--

DROP TABLE IF EXISTS `fa_auth_group_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_auth_group_access` (
  `uid` int unsigned NOT NULL COMMENT '会员ID',
  `group_id` int unsigned NOT NULL COMMENT '级别ID',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='权限分组表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_auth_group_access`
--

/*!40000 ALTER TABLE `fa_auth_group_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_auth_rule`
--

DROP TABLE IF EXISTS `fa_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_auth_rule` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('menu','file') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'file' COMMENT 'menu为菜单,file为权限节点',
  `pid` int unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '规则名称',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '规则名称',
  `icon` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '图标',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '规则URL',
  `condition` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '条件',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '备注',
  `ismenu` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '是否为菜单',
  `menutype` enum('addtabs','blank','dialog','ajax') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '菜单类型',
  `extend` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '扩展属性',
  `py` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '拼音首字母',
  `pinyin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '拼音',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `weigh` int NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `pid` (`pid`),
  KEY `weigh` (`weigh`)
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='节点表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_auth_rule`
--

/*!40000 ALTER TABLE `fa_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_bank`
--

DROP TABLE IF EXISTS `fa_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_bank` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL COMMENT '用户编号',
  `firstname` varchar(299) NOT NULL COMMENT '姓',
  `lastname` varchar(299) NOT NULL COMMENT '名',
  `email` varchar(299) NOT NULL COMMENT '邮箱',
  `phone` varchar(299) NOT NULL COMMENT '电话',
  `cpf` varchar(299) NOT NULL COMMENT '稅号',
  `pix` varchar(299) NOT NULL COMMENT 'pix账户',
  `pixtype` varchar(299) NOT NULL COMMENT 'pix账户类型',
  `updatetime` varchar(299) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COMMENT='提现信息���定';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_bank`
--

/*!40000 ALTER TABLE `fa_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_category`
--

DROP TABLE IF EXISTS `fa_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_category` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '栏目类型',
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `flag` set('hot','index','recommend') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `image` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '图片',
  `keywords` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '关键字',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '描述',
  `diyname` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '自定义名称',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `weigh` int NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `weigh` (`weigh`,`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_category`
--

/*!40000 ALTER TABLE `fa_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_ce`
--

DROP TABLE IF EXISTS `fa_ce`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_ce` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_ce`
--

/*!40000 ALTER TABLE `fa_ce` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_command`
--

DROP TABLE IF EXISTS `fa_command`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_command` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '类型',
  `params` varchar(1500) NOT NULL DEFAULT '' COMMENT '参数',
  `command` varchar(1500) NOT NULL DEFAULT '' COMMENT '命令',
  `content` text COMMENT '返回结果',
  `executetime` bigint unsigned DEFAULT NULL COMMENT '执行时间',
  `createtime` bigint unsigned DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint unsigned DEFAULT NULL COMMENT '更新时间',
  `status` enum('successed','failured') NOT NULL DEFAULT 'failured' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3 COMMENT='在线命令表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_command`
--

/*!40000 ALTER TABLE `fa_command` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_config`
--

DROP TABLE IF EXISTS `fa_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_config` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '变量名',
  `group` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '分组',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '变量标题',
  `tip` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '变量描述',
  `type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '类型:string,text,int,bool,array,datetime,date,file',
  `visible` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '可见条件',
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '变量值',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '变量字典数据',
  `rule` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '验证规则',
  `extend` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '扩展属性',
  `setting` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '配置',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_config`
--

/*!40000 ALTER TABLE `fa_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_contents`
--

DROP TABLE IF EXISTS `fa_contents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_contents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(299) NOT NULL COMMENT '名称',
  `content` text NOT NULL COMMENT '富文本',
  `type` int NOT NULL COMMENT '类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COMMENT='内容管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_contents`
--

/*!40000 ALTER TABLE `fa_contents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_conts`
--

DROP TABLE IF EXISTS `fa_conts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_conts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stat` int NOT NULL COMMENT '开关',
  `content` text NOT NULL COMMENT '富文本',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COMMENT='首页弹窗管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_conts`
--

/*!40000 ALTER TABLE `fa_conts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_convert`
--

DROP TABLE IF EXISTS `fa_convert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_convert` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `orderId` varchar(555) NOT NULL,
  `type` int NOT NULL,
  `currency` varchar(299) NOT NULL,
  `addtime` varchar(299) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb3 COMMENT='转换记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_convert`
--

/*!40000 ALTER TABLE `fa_convert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_dotop`
--

DROP TABLE IF EXISTS `fa_dotop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_dotop` (
  `id` int NOT NULL AUTO_INCREMENT,
  `info` varchar(299) NOT NULL COMMENT '信息',
  `user_id` int NOT NULL COMMENT '用户id',
  `username` varchar(299) NOT NULL COMMENT '上分对象',
  `me_user` varchar(299) NOT NULL COMMENT '提交方',
  `money` decimal(10,2) NOT NULL COMMENT '上分金额',
  `dai_id` int NOT NULL COMMENT '代理id',
  `addtime` varchar(299) NOT NULL COMMENT '申请时间',
  `type` int NOT NULL COMMENT '0充值1提现',
  `status` int NOT NULL COMMENT '状态',
  `uptime` varchar(299) NOT NULL COMMENT '审核时间',
  `is_get` int NOT NULL COMMENT '是否充值奖励',
  `mobile` varchar(299) DEFAULT NULL,
  `bankCard` varchar(299) DEFAULT NULL,
  `bankName` varchar(299) DEFAULT NULL,
  `moneys` decimal(10,2) NOT NULL COMMENT '真实上分金额',
  `sxf` decimal(10,2) DEFAULT NULL,
  `orderNo` varchar(299) NOT NULL COMMENT '订单号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb3 COMMENT='上分审核管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_dotop`
--

/*!40000 ALTER TABLE `fa_dotop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_dotops`
--

DROP TABLE IF EXISTS `fa_dotops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_dotops` (
  `id` int NOT NULL AUTO_INCREMENT,
  `info` varchar(299) NOT NULL COMMENT '信息',
  `user_id` int NOT NULL COMMENT '用户id',
  `username` varchar(299) NOT NULL COMMENT '上分对象',
  `me_user` varchar(299) NOT NULL COMMENT '提交方',
  `money` decimal(10,2) NOT NULL COMMENT '上分金额',
  `dai_id` int NOT NULL COMMENT '代理id',
  `addtime` varchar(299) NOT NULL COMMENT '申请时间',
  `type` int NOT NULL COMMENT '0充值1提现',
  `status` int NOT NULL COMMENT '状态',
  `uptime` varchar(299) NOT NULL COMMENT '审核时间',
  `is_get` int NOT NULL COMMENT '是否充值奖励',
  `mobile` varchar(299) DEFAULT NULL,
  `bankCard` varchar(299) DEFAULT NULL,
  `bankName` varchar(299) DEFAULT NULL,
  `moneys` decimal(10,2) NOT NULL COMMENT '真实上分金额',
  `sxf` decimal(10,2) DEFAULT NULL,
  `orderNo` varchar(299) NOT NULL COMMENT '订单号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb3 COMMENT='上分审核管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_dotops`
--

/*!40000 ALTER TABLE `fa_dotops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_ems`
--

DROP TABLE IF EXISTS `fa_ems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_ems` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '事件',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '邮箱',
  `code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '验证码',
  `times` int unsigned NOT NULL DEFAULT '0' COMMENT '验证次数',
  `ip` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'IP',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='邮箱验证码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_ems`
--

/*!40000 ALTER TABLE `fa_ems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_game_record`
--

DROP TABLE IF EXISTS `fa_game_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_game_record` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '注单ID',
  `bet_id` varchar(299) NOT NULL,
  `uid` int NOT NULL COMMENT '用户ID',
  `game_type_name` varchar(20) DEFAULT NULL COMMENT '游戏名称',
  `bet_amount` decimal(20,4) DEFAULT NULL COMMENT '投注额',
  `valid_bet_amount` decimal(20,4) DEFAULT NULL COMMENT '有效投注额',
  `net_amount` decimal(20,4) DEFAULT NULL COMMENT '输赢金额',
  `pumping_amount` decimal(20,4) DEFAULT NULL COMMENT '抽水',
  `currency` varchar(10) DEFAULT NULL COMMENT '币种',
  `create_at` datetime DEFAULT NULL COMMENT '开始时间=当前该注单的投注时间 或该注单创建时间',
  `net_at` datetime DEFAULT NULL COMMENT '结束时间=当前注单被结算的时间',
  `is_fl` int NOT NULL DEFAULT '0' COMMENT '是否反水',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1093 DEFAULT CHARSET=utf8mb3 COMMENT='投注记录管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_game_record`
--

/*!40000 ALTER TABLE `fa_game_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_gamelist`
--

DROP TABLE IF EXISTS `fa_gamelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_gamelist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `platType` varchar(299) NOT NULL,
  `gameType` int NOT NULL,
  `gameCode` varchar(299) NOT NULL,
  `gameName` varchar(299) NOT NULL,
  `imageUrl` varchar(299) NOT NULL,
  `is_hot` int NOT NULL DEFAULT '0',
  `is_show` int NOT NULL DEFAULT '1' COMMENT '0关闭1开启',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1277 DEFAULT CHARSET=utf8mb3 COMMENT='三方游戏列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_gamelist`
--

/*!40000 ALTER TABLE `fa_gamelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_kaika`
--

DROP TABLE IF EXISTS `fa_kaika`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_kaika` (
  `id` int NOT NULL AUTO_INCREMENT,
  `phone` varchar(299) NOT NULL COMMENT '手机号',
  `katype` varchar(299) NOT NULL COMMENT '卡类型',
  `kahao` varchar(299) NOT NULL COMMENT '卡号',
  `chika` varchar(299) NOT NULL COMMENT '持卡人',
  `endu` varchar(299) DEFAULT NULL COMMENT '信用额度',
  `endu2` varchar(299) NOT NULL COMMENT '信用额度2',
  `zdr` varchar(299) NOT NULL COMMENT '账单日',
  `yijiao` varchar(299) NOT NULL COMMENT '溢缴款支取账户',
  `banli` varchar(299) NOT NULL COMMENT '办理进度',
  `banli2` varchar(299) NOT NULL COMMENT '办理进度2',
  `image` varchar(299) NOT NULL COMMENT '银行logo',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COMMENT='数据录入管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_kaika`
--

/*!40000 ALTER TABLE `fa_kaika` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_lb`
--

DROP TABLE IF EXISTS `fa_lb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_lb` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(299) NOT NULL COMMENT '标题',
  `image` varchar(999) NOT NULL COMMENT '轮播图',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COMMENT='轮播管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_lb`
--

/*!40000 ALTER TABLE `fa_lb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_msg`
--

DROP TABLE IF EXISTS `fa_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_msg` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(299) NOT NULL COMMENT '标题',
  `subtitle` varchar(299) NOT NULL COMMENT '简介',
  `content` text NOT NULL COMMENT '内容',
  `addtime` varchar(299) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COMMENT='通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_msg`
--

/*!40000 ALTER TABLE `fa_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_mx`
--

DROP TABLE IF EXISTS `fa_mx`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_mx` (
  `id` int NOT NULL AUTO_INCREMENT,
  `info` varchar(999) NOT NULL COMMENT '信息',
  `type` int NOT NULL COMMENT '类型',
  `money` decimal(10,2) NOT NULL COMMENT '金额',
  `addtime` varchar(299) NOT NULL COMMENT '添加时间',
  `uid` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb3 COMMENT='明细管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_mx`
--

/*!40000 ALTER TABLE `fa_mx` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_rechlist`
--

DROP TABLE IF EXISTS `fa_rechlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_rechlist` (
  `id` int NOT NULL AUTO_INCREMENT,
  `money` decimal(10,2) NOT NULL COMMENT '金额',
  `gift` decimal(10,2) NOT NULL COMMENT '赠送金额',
  `true_money` decimal(10,2) NOT NULL COMMENT '充值实际金额',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3 COMMENT='充值列表配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_rechlist`
--

/*!40000 ALTER TABLE `fa_rechlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_slots`
--

DROP TABLE IF EXISTS `fa_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_slots` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'id',
  `platType` varchar(299) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '平台',
  `platCode` int NOT NULL COMMENT '代码',
  `imageUrl` varchar(299) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '大图',
  `smallUrl` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '小图',
  `is_show` int NOT NULL DEFAULT '1' COMMENT '0关闭1开启',
  `weigh` int DEFAULT '0' COMMENT '排序',
  `create_time` int DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 ROW_FORMAT=DYNAMIC COMMENT='插槽';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_slots`
--

/*!40000 ALTER TABLE `fa_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_sms`
--

DROP TABLE IF EXISTS `fa_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_sms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '事件',
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '手机号',
  `code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '验证码',
  `times` int unsigned NOT NULL DEFAULT '0' COMMENT '验证次数',
  `ip` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'IP',
  `createtime` bigint unsigned DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='短信验证码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_sms`
--

/*!40000 ALTER TABLE `fa_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_test`
--

DROP TABLE IF EXISTS `fa_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_test` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int DEFAULT '0' COMMENT '会员ID',
  `admin_id` int DEFAULT '0' COMMENT '管理员ID',
  `category_id` int unsigned DEFAULT '0' COMMENT '分类ID(单选)',
  `category_ids` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '分类ID(多选)',
  `tags` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '标签',
  `week` enum('monday','tuesday','wednesday') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '星期(单选):monday=星期一,tuesday=星期二,wednesday=星期三',
  `flag` set('hot','index','recommend') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '标志(多选):hot=热门,index=首页,recommend=推荐',
  `genderdata` enum('male','female') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'male' COMMENT '性别(单选):male=男,female=女',
  `hobbydata` set('music','reading','swimming') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '爱好(多选):music=音乐,reading=读书,swimming=游泳',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '标题',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '内容',
  `image` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '图片',
  `images` varchar(1500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '图片组',
  `attachfile` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '附件',
  `keywords` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '关键字',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '描述',
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '省市',
  `json` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '配置:key=名称,value=值',
  `multiplejson` varchar(1500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '二维数组:title=标题,intro=介绍,author=作者,age=年龄',
  `price` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '价格',
  `views` int unsigned DEFAULT '0' COMMENT '点击',
  `workrange` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '时间区间',
  `startdate` date DEFAULT NULL COMMENT '开始日期',
  `activitytime` datetime DEFAULT NULL COMMENT '活动时间(datetime)',
  `year` year DEFAULT NULL COMMENT '年',
  `times` time DEFAULT NULL COMMENT '时间',
  `refreshtime` bigint DEFAULT NULL COMMENT '刷新时间',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint DEFAULT NULL COMMENT '删除时间',
  `weigh` int DEFAULT '0' COMMENT '权重',
  `switch` tinyint(1) DEFAULT '0' COMMENT '开关',
  `status` enum('normal','hidden') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'normal' COMMENT '状态',
  `state` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '1' COMMENT '状态值:0=禁用,1=正常,2=推荐',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='测试表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_test`
--

/*!40000 ALTER TABLE `fa_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user`
--

DROP TABLE IF EXISTS `fa_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_user` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int NOT NULL,
  `group_id` int unsigned NOT NULL DEFAULT '0' COMMENT '组别ID',
  `username` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '昵称',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '密码',
  `salt` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '密码盐',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '电子邮箱',
  `mobile` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '手机号',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '头像',
  `level` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `gender` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `bio` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '格言',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `score` int NOT NULL DEFAULT '0' COMMENT '积分',
  `successions` int unsigned NOT NULL DEFAULT '1' COMMENT '连续登录天数',
  `maxsuccessions` int unsigned NOT NULL DEFAULT '1' COMMENT '最大连续登录天数',
  `prevtime` bigint DEFAULT NULL COMMENT '上次登录时间',
  `logintime` bigint DEFAULT NULL COMMENT '登录时间',
  `loginip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '登录IP',
  `loginfailure` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `joinip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '加入IP',
  `jointime` bigint DEFAULT NULL COMMENT '加入时间',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `token` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'Token',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  `verification` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '验证',
  `stat` int NOT NULL,
  `payerFirstName` varchar(299) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '付款人姓',
  `payerLastName` varchar(299) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '付款人名',
  `payerEmail` varchar(299) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '付款人邮箱',
  `payerPhone` varchar(299) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '付款人电话',
  `payerCPF` varchar(299) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '付款人税号',
  `PIX` varchar(299) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'PIX账户',
  `pixtype` varchar(299) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'PIX账户类型',
  `rtp` decimal(2,1) NOT NULL DEFAULT '0.0' COMMENT '奖率',
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `mobile` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user`
--

/*!40000 ALTER TABLE `fa_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user_group`
--

DROP TABLE IF EXISTS `fa_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_user_group` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '组名',
  `rules` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci COMMENT '权限节点',
  `createtime` bigint DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `status` enum('normal','hidden') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员组表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_group`
--

/*!40000 ALTER TABLE `fa_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user_money_log`
--

DROP TABLE IF EXISTS `fa_user_money_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_user_money_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更余额',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更前余额',
  `after` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更后余额',
  `memo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '备注',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `type` int NOT NULL COMMENT '类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员余额变动表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_money_log`
--

/*!40000 ALTER TABLE `fa_user_money_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user_rule`
--

DROP TABLE IF EXISTS `fa_user_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_user_rule` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int DEFAULT NULL COMMENT '父ID',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '名称',
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '标题',
  `remark` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '备注',
  `ismenu` tinyint(1) DEFAULT NULL COMMENT '是否菜单',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `weigh` int DEFAULT '0' COMMENT '权重',
  `status` enum('normal','hidden') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员规则表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_rule`
--

/*!40000 ALTER TABLE `fa_user_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user_score_log`
--

DROP TABLE IF EXISTS `fa_user_score_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_user_score_log` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `score` int NOT NULL DEFAULT '0' COMMENT '变更积分',
  `before` int NOT NULL DEFAULT '0' COMMENT '变更前积分',
  `after` int NOT NULL DEFAULT '0' COMMENT '变更后积分',
  `memo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '备注',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员积分变动表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_score_log`
--

/*!40000 ALTER TABLE `fa_user_score_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user_token`
--

DROP TABLE IF EXISTS `fa_user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_user_token` (
  `token` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Token',
  `user_id` int unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `expiretime` bigint DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员Token表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_token`
--

/*!40000 ALTER TABLE `fa_user_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_users`
--

DROP TABLE IF EXISTS `fa_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int NOT NULL,
  `group_id` int unsigned NOT NULL DEFAULT '0' COMMENT '组别ID',
  `username` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '昵称',
  `password` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '密码',
  `salt` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '密码盐',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '电子邮箱',
  `mobile` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '手机号',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '头像',
  `level` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `gender` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `bio` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '格言',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `score` int NOT NULL DEFAULT '0' COMMENT '积分',
  `successions` int unsigned NOT NULL DEFAULT '1' COMMENT '连续登录天数',
  `maxsuccessions` int unsigned NOT NULL DEFAULT '1' COMMENT '最大连续登录天数',
  `prevtime` bigint DEFAULT NULL COMMENT '上次登录时间',
  `logintime` bigint DEFAULT NULL COMMENT '登录时间',
  `loginip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '登录IP',
  `loginfailure` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `joinip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '加入IP',
  `jointime` bigint DEFAULT NULL COMMENT '加入时间',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `token` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'Token',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  `verification` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '验证',
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `mobile` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='会员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_users`
--

/*!40000 ALTER TABLE `fa_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_version`
--

DROP TABLE IF EXISTS `fa_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_version` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `oldversion` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '旧版本号',
  `newversion` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '新版本号',
  `packagesize` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '包大小',
  `content` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '升级内容',
  `downloadurl` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '下载地址',
  `enforce` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '强制更新',
  `createtime` bigint DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint DEFAULT NULL COMMENT '更新时间',
  `weigh` int NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='版本表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_version`
--

/*!40000 ALTER TABLE `fa_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_vips`
--

DROP TABLE IF EXISTS `fa_vips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fa_vips` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(299) NOT NULL COMMENT '名称',
  `image` varchar(299) NOT NULL COMMENT '图标',
  `running_water` decimal(10,2) NOT NULL COMMENT '需达流水',
  `running_money` decimal(10,2) NOT NULL COMMENT '需达充值金额',
  `withdraw` decimal(10,2) NOT NULL COMMENT '提现手续',
  `day_withdraw` int NOT NULL COMMENT '每日提现次数',
  `withdraw_limt` decimal(10,2) NOT NULL COMMENT '提现每日限额',
  `week` decimal(10,2) NOT NULL COMMENT '周奖励',
  `moon` decimal(10,2) NOT NULL COMMENT '月奖励',
  `vip_up` decimal(10,2) NOT NULL COMMENT '会员升级奖励',
  `single_withdraw` decimal(10,2) NOT NULL COMMENT '提现单笔限额',
  `level` int NOT NULL COMMENT '实际等级',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3 COMMENT='vip管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_vips`
--

/*!40000 ALTER TABLE `fa_vips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sql_www_sawa_com'
--

--
-- Dumping routines for database 'sql_www_sawa_com'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-29  1:08:26
