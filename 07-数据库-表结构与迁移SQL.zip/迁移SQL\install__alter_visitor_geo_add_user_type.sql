-- 为 eb_visitor_geo_log 添加 user_type 字段，区分访客(0)和会员(1)
-- 同时更新唯一索引，使同一 IP 同一天可以分别记录访客和会员

SET @tbl := 'eb_visitor_geo_log';

-- 添加 user_type 列
SET @col_exists := (
  SELECT COUNT(1) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @tbl AND COLUMN_NAME = 'user_type'
);
SET @add_col := IF(@col_exists = 0,
  CONCAT('ALTER TABLE `', @tbl, '` ADD COLUMN `user_type` TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT ''0=访客(未注册) 1=会员(已注册)'' AFTER `uid`'),
  'SELECT 1');
PREPARE stmt FROM @add_col;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 删除旧唯一索引 (ip, visit_date)
SET @old_uk := (
  SELECT COUNT(1) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @tbl AND INDEX_NAME = 'uk_ip_date'
);
SET @drop_uk := IF(@old_uk > 0,
  CONCAT('ALTER TABLE `', @tbl, '` DROP INDEX `uk_ip_date`'),
  'SELECT 1');
PREPARE stmt FROM @drop_uk;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- 创建新唯一索引 (ip, visit_date, user_type)
SET @new_uk := (
  SELECT COUNT(1) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @tbl AND INDEX_NAME = 'uk_ip_date_type'
);
SET @create_uk := IF(@new_uk = 0,
  CONCAT('ALTER TABLE `', @tbl, '` ADD UNIQUE KEY `uk_ip_date_type` (`ip`, `visit_date`, `user_type`)'),
  'SELECT 1');
PREPARE stmt FROM @create_uk;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
