-- 拼团抽奖模块迁移：开奖可验证快照
-- 2026-09-13
-- 执行环境：生产库（表前缀 eb_），仅新增字段，可重复执行前请先确认字段不存在
-- 用途：开奖时固化真实成员 UID 有序列表，用户可凭 draw_seed + 本快照复算中奖下标

ALTER TABLE `eb_group_lottery_pink`
  ADD COLUMN `draw_members` text NULL COMMENT '开奖时真实成员UID有序快照(JSON)' AFTER `draw_hash`;

-- 历史已开奖团无需回填：验证接口在快照为空时会按成员表回退生成
