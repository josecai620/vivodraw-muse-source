-- 盲盒商城 Phase 2 — 限时活动/新人礼包
-- 2026-03-18

-- 1. 限时活动
CREATE TABLE IF NOT EXISTS `eb_box_activity` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '活动标题',
  `description` text COMMENT '活动描述',
  `cate_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '关联盲盒分类ID',
  `boost_type` varchar(50) NOT NULL DEFAULT 'rarity_up' COMMENT '提升类型(rarity_up/discount/bonus)',
  `boost_value` decimal(10,2) NOT NULL DEFAULT 0 COMMENT '提升值(概率倍数/折扣比/赠送积分)',
  `banner_image` varchar(500) NOT NULL DEFAULT '' COMMENT '活动Banner图',
  `start_time` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '开始时间',
  `end_time` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '结束时间',
  `status` tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '0=关闭 1=开启',
  `sort` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '排序',
  `createtime` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_time` (`start_time`, `end_time`),
  KEY `idx_cate_id` (`cate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='盲盒限时活动';

-- 2. 新人礼包领取记录
CREATE TABLE IF NOT EXISTS `eb_user_box_newbie` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '用户ID',
  `reward_type` varchar(50) NOT NULL DEFAULT 'free_box' COMMENT '奖励类型',
  `reward_points` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '赠送积分',
  `reward_box_order_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '赠送盲盒订单ID',
  `createtime` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='盲盒新人礼包领取记录';

-- 插入一条默认限时活动（示例，可通过后台管理修改）
INSERT INTO `eb_box_activity` (`title`, `description`, `boost_type`, `boost_value`, `start_time`, `end_time`, `status`, `sort`, `createtime`)
VALUES ('新用户限时福利', '注册7天内开盒，稀有概率翻倍！', 'rarity_up', 2.00, UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + 604800, 1, 100, UNIX_TIMESTAMP());
