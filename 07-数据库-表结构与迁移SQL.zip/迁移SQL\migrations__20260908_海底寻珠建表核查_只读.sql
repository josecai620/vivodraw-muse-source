-- 只读结构核查，可在批准建表前后运行；不查询账号资料、不修改积分、不自动建表。
SELECT DATABASE() AS database_name, VERSION() AS mysql_version, @@time_zone AS database_timezone;

SELECT required.table_name,
       COALESCE(actual.engine, 'MISSING') AS engine
FROM (
  SELECT 'eb_game_pearl_profile' AS table_name UNION ALL
  SELECT 'eb_game_pearl_round' UNION ALL
  SELECT 'eb_user' UNION ALL
  SELECT 'eb_user_bill'
) required
LEFT JOIN information_schema.tables actual
  ON actual.table_schema = DATABASE() AND actual.table_name = required.table_name;

SELECT table_name, column_name, column_type, is_nullable
FROM information_schema.columns
WHERE table_schema = DATABASE()
  AND table_name IN ('eb_game_pearl_profile', 'eb_game_pearl_round')
ORDER BY table_name, ordinal_position;

SELECT table_name, index_name, non_unique,
       GROUP_CONCAT(column_name ORDER BY seq_in_index SEPARATOR ',') AS indexed_columns
FROM information_schema.statistics
WHERE table_schema = DATABASE()
  AND table_name IN ('eb_game_pearl_profile', 'eb_game_pearl_round')
GROUP BY table_name, index_name, non_unique
ORDER BY table_name, index_name;

-- 验收：四表均为 InnoDB；profile 的 uid 唯一；round 的 uid,request_hash 联合唯一。
-- 应用会额外检查所有必需字段，缺表/缺字段/缺唯一键时保持 unavailable，永不自动迁移。
