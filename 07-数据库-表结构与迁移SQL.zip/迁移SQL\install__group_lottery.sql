-- 拼团抽奖模块建表 SQL
-- 执行环境：manghehoutai_qhe，表前缀 eb_

-- 拼团抽奖商品表
CREATE TABLE IF NOT EXISTS `eb_group_lottery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联原商品ID',
  `title` varchar(200) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '商品标题',
  `image` varchar(255) NOT NULL DEFAULT '' COMMENT '主图',
  `images` text COMMENT '轮播图JSON',
  `info` varchar(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '简介',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '拼团价格',
  `price_type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1=积分 2=美元',
  `cost_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '商品成本价',
  `recycle_price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '回收价格',
  `people_options` varchar(20) NOT NULL DEFAULT '3,5,10' COMMENT '可选成团人数',
  `bonus_rate` int(3) unsigned NOT NULL DEFAULT '5' COMMENT '未中奖奖励比例(%)',
  `robot_wait_minutes` int(5) unsigned NOT NULL DEFAULT '15' COMMENT '机器人等待时间(分)',
  `effective_hours` int(5) unsigned NOT NULL DEFAULT '24' COMMENT '团有效期(时)',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '0=下架 1=上架',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `sales` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '已开奖次数',
  `description` text CHARACTER SET utf8mb4 COMMENT '商品详情HTML',
  `is_del` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '软删除',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_status` (`status`,`is_del`),
  KEY `idx_product` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='拼团抽奖商品表';

-- 拼团抽奖团记录表
CREATE TABLE IF NOT EXISTS `eb_group_lottery_pink` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lottery_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联商品ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '团长UID',
  `is_admin` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '后台开团0=否1=是',
  `people_count` int(3) unsigned NOT NULL DEFAULT '3' COMMENT '成团人数',
  `current_count` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '当前人数',
  `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '拼团价格',
  `price_type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1=积分 2=美元',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1=进行中 2=已开奖 3=超时 4=已取消',
  `winner_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '中奖者UID',
  `winner_choice` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0=未选 1=发货 2=回收',
  `draw_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '开奖时间戳',
  `draw_seed` varchar(64) NOT NULL DEFAULT '' COMMENT '随机种子',
  `draw_hash` varchar(64) NOT NULL DEFAULT '' COMMENT '开奖哈希',
  `stop_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '截止时间戳',
  `robot_trigger_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '机器人触发时间',
  `cancel_apply_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '团长申请取消时间',
  `cancel_status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0=无 1=待审核 2=已通过 3=已拒绝',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_lottery` (`lottery_id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_status` (`status`),
  KEY `idx_stop_time` (`stop_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='拼团抽奖团记录表';

-- 拼团抽奖参团成员表
CREATE TABLE IF NOT EXISTS `eb_group_lottery_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pink_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联团ID',
  `lottery_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联商品ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户UID',
  `nickname` varchar(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '用户昵称',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '用户头像',
  `is_leader` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否团长',
  `is_robot` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否机器人',
  `paid_amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '实付金额',
  `price_type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1=积分 2=美元',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1=已参团 2=中奖 3=未中奖已退款 4=超时/取消退款 5=申请取消待审 6=已取消已退款 7=已发货 8=已回收',
  `refund_amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '退款金额',
  `cancel_apply_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '申请取消时间',
  `cancel_reason` varchar(200) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '取消原因',
  `shipping_name` varchar(50) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '收货人',
  `shipping_phone` varchar(20) NOT NULL DEFAULT '' COMMENT '收货电话',
  `shipping_address` varchar(300) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '收货地址',
  `join_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '参团时间',
  `refund_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '退款时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `idx_pink` (`pink_id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_lottery` (`lottery_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='拼团抽奖参团成员表';

-- 拼团抽奖机器人池
CREATE TABLE IF NOT EXISTS `eb_group_lottery_robot` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nickname` varchar(50) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '昵称',
  `avatar` varchar(255) NOT NULL DEFAULT '' COMMENT '头像URL',
  `is_active` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否启用',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='拼团抽奖机器人池';

-- 预置一批机器人
INSERT INTO `eb_group_lottery_robot` (`nickname`, `avatar`, `is_active`, `add_time`) VALUES
('小明', 'https://api.dicebear.com/7.x/avataaars/png?seed=xiaoming', 1, UNIX_TIMESTAMP()),
('阿花', 'https://api.dicebear.com/7.x/avataaars/png?seed=ahua', 1, UNIX_TIMESTAMP()),
('大壮', 'https://api.dicebear.com/7.x/avataaars/png?seed=dazhuang', 1, UNIX_TIMESTAMP()),
('甜甜', 'https://api.dicebear.com/7.x/avataaars/png?seed=tiantian', 1, UNIX_TIMESTAMP()),
('阿杰', 'https://api.dicebear.com/7.x/avataaars/png?seed=ajie', 1, UNIX_TIMESTAMP()),
('小美', 'https://api.dicebear.com/7.x/avataaars/png?seed=xiaomei', 1, UNIX_TIMESTAMP()),
('老王', 'https://api.dicebear.com/7.x/avataaars/png?seed=laowang', 1, UNIX_TIMESTAMP()),
('思思', 'https://api.dicebear.com/7.x/avataaars/png?seed=sisi', 1, UNIX_TIMESTAMP()),
('阿强', 'https://api.dicebear.com/7.x/avataaars/png?seed=aqiang', 1, UNIX_TIMESTAMP()),
('小雨', 'https://api.dicebear.com/7.x/avataaars/png?seed=xiaoyu', 1, UNIX_TIMESTAMP()),
('丽丽', 'https://api.dicebear.com/7.x/avataaars/png?seed=lili', 1, UNIX_TIMESTAMP()),
('阿龙', 'https://api.dicebear.com/7.x/avataaars/png?seed=along', 1, UNIX_TIMESTAMP()),
('Jenny', 'https://api.dicebear.com/7.x/avataaars/png?seed=jenny', 1, UNIX_TIMESTAMP()),
('Mike', 'https://api.dicebear.com/7.x/avataaars/png?seed=mike', 1, UNIX_TIMESTAMP()),
('Lucy', 'https://api.dicebear.com/7.x/avataaars/png?seed=lucy', 1, UNIX_TIMESTAMP()),
('Tom', 'https://api.dicebear.com/7.x/avataaars/png?seed=tom', 1, UNIX_TIMESTAMP()),
('Emma', 'https://api.dicebear.com/7.x/avataaars/png?seed=emma', 1, UNIX_TIMESTAMP()),
('Alex', 'https://api.dicebear.com/7.x/avataaars/png?seed=alex', 1, UNIX_TIMESTAMP()),
('Sophie', 'https://api.dicebear.com/7.x/avataaars/png?seed=sophie', 1, UNIX_TIMESTAMP()),
('David', 'https://api.dicebear.com/7.x/avataaars/png?seed=david', 1, UNIX_TIMESTAMP());
