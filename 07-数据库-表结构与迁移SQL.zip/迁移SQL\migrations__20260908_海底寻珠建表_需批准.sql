-- 海底寻珠首版迁移：只新增两张专属表，不改现有账号、账单、农场或矿洞表。
-- 必须取得负责人明确批准后才能在生产执行；部署脚本不得自动调用本文件。
-- 执行前确认数据库备份，并先在隔离测试库验证。表前缀沿用项目 eb_。
-- 停用回滚通过回退本次应用发布处理；保留这两张表及已产生的积分账单，不删记录。

CREATE TABLE IF NOT EXISTS `eb_game_pearl_profile` (
  `uid` int unsigned NOT NULL COMMENT '账号编号，与平台账号一致',
  `play_day` date NOT NULL COMMENT '按平台服务器时区计算的最近游玩日期',
  `plays_today` tinyint unsigned NOT NULL DEFAULT 0 COMMENT '当日已结算免费局数',
  `plays_total` int unsigned NOT NULL DEFAULT 0 COMMENT '累计已结算局数',
  `fragments_total` int unsigned NOT NULL DEFAULT 0 COMMENT '累计装饰碎片，仅供寻珠使用',
  `pearls_json` text NOT NULL COMMENT '固定珍珠品种数量，服务端维护',
  `created_at` int unsigned NOT NULL,
  `updated_at` int unsigned NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='海底寻珠账号收藏与次数';

CREATE TABLE IF NOT EXISTS `eb_game_pearl_round` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '本轮编号及积分账单关联号',
  `uid` int unsigned NOT NULL,
  `request_id` varchar(128) NOT NULL COMMENT '客户端持久重试标识',
  `request_hash` char(64) NOT NULL COMMENT '账号与请求标识哈希',
  `payload_hash` char(64) NOT NULL COMMENT '选择位置指纹，禁止同键改选',
  `selected_shell` tinyint unsigned NOT NULL COMMENT '选中位置，零至五',
  `rule_version` varchar(40) NOT NULL COMMENT '服务端规则版本',
  `play_day` date NOT NULL,
  `shells_json` text NOT NULL COMMENT '本轮完整六蚌结果，结算后保持不变',
  `pearl_key` varchar(16) NOT NULL DEFAULT '' COMMENT '选中珍珠品种，空字符串表示空蚌',
  `fragments_delta` int unsigned NOT NULL DEFAULT 0 COMMENT '本次全部装饰碎片，含每日目标',
  `requested_points` int unsigned NOT NULL DEFAULT 0 COMMENT '本次珍珠的规则积分',
  `awarded_points` int unsigned NOT NULL DEFAULT 0 COMMENT '受平台共享上限约束后的实际积分',
  `balance_after` bigint unsigned NOT NULL DEFAULT 0 COMMENT '本次结算后的平台积分余额',
  `bill_id` bigint unsigned NOT NULL DEFAULT 0 COMMENT '真实积分账单编号，零积分则为零',
  `response_json` mediumtext NOT NULL COMMENT '本次结算固定响应，用于幂等重放',
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_request_hash` (`uid`, `request_hash`),
  KEY `uid_play_day` (`uid`, `play_day`),
  KEY `uid_created_at` (`uid`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='海底寻珠完整结果与结算审计';
