-- ============================================================
-- Migration: 付费会员 USD 重新定价 + 永久卡下架 + 双语文案
-- Date: 2026-04-21
-- Context: eccomall 定位美国市场，货币从 ¥ 切到 $，
--          重新定价以匹配平台积分返利/签到/月度券的价值上限。
-- Safe to re-run: 全部为 UPDATE，使用主键定位，幂等。
-- ============================================================

-- 1) 会员套餐 eb_member_ship —— 重定价 + 下架永久卡
UPDATE `eb_member_ship` SET `title` = 'Monthly / 月卡',           `price` = '4.99',  `pre_price` = '4.99',  `is_del` = 0 WHERE `id` = 1;
UPDATE `eb_member_ship` SET `title` = 'Quarterly / 季卡',         `price` = '14.99', `pre_price` = '12.99', `is_del` = 0 WHERE `id` = 2;
UPDATE `eb_member_ship` SET `title` = 'Annual / 年卡',            `price` = '59.99', `pre_price` = '39.99', `is_del` = 0 WHERE `id` = 3;
UPDATE `eb_member_ship` SET `title` = 'Lifetime / 永久',          `price` = '999.00',`pre_price` = '899.00',`is_del` = 1 WHERE `id` = 4;
UPDATE `eb_member_ship` SET `title` = '7-Day Free Trial / 7 天试用', `price` = '4.99', `pre_price` = '0.00', `is_del` = 0 WHERE `id` = 5;

-- 2) 会员权益 eb_member_right —— 双语文案 + $3 月度券
UPDATE `eb_member_right` SET `title` = 'Cashback Points / 消费返利',
       `show_title` = 'Cashback Points',
       `explain` = 'Earn 2x points on every order / 下单享 2 倍积分',
       `number` = 2, `status` = 1 WHERE `id` = 1;

UPDATE `eb_member_right` SET `title` = 'Member Price / 会员特价',
       `show_title` = 'Member Price',
       `explain` = 'Exclusive member-only pricing / 会员专属价',
       `number` = 1, `status` = 1 WHERE `id` = 2;

UPDATE `eb_member_right` SET `title` = 'Shipping Discount / 运费折扣',
       `show_title` = 'Shipping Discount',
       `explain` = '10% off shipping / 运费 9 折',
       `number` = 90, `status` = 1 WHERE `id` = 3;

UPDATE `eb_member_right` SET `title` = 'Daily Check-in Bonus / 签到返利',
       `show_title` = 'Check-in Bonus',
       `explain` = 'Earn 3x points on daily check-in / 签到 3 倍积分',
       `number` = 3, `status` = 1 WHERE `id` = 4;

-- 线下折扣对美国市场无意义，关闭展示（保留数据）
UPDATE `eb_member_right` SET `title` = 'In-store Discount / 线下折扣',
       `show_title` = 'In-store Discount',
       `explain` = '10% off in-store / 线下 9 折',
       `number` = 90, `status` = 0 WHERE `id` = 5;

UPDATE `eb_member_right` SET `title` = 'Monthly Coupon / 会员优惠券',
       `show_title` = 'Monthly Coupon',
       `explain` = 'Get $3 coupon every month / 每月领 $3 会员券',
       `number` = 1, `status` = 1 WHERE `id` = 6;

-- 3) 风控配置（SystemConfig —— 新用户 7 天积分抵扣冷却期）
--    由应用代码读取键 `integral_new_user_days`，默认 0 表示不启用。
INSERT INTO `eb_system_config` (`menu_name`, `type`, `input_type`, `config_tab_id`, `parameter`, `upload_type`, `required`, `width`, `high`, `value`, `info`, `desc`, `sort`, `status`)
SELECT 'integral_new_user_days', 'text', 'input', 0, '', 0, '', 0, 0, '7', '新用户积分抵扣冷却期(天)', '注册后多少天内不允许使用积分抵扣订单金额，0 表示不限制', 0, 1
WHERE NOT EXISTS (SELECT 1 FROM `eb_system_config` WHERE `menu_name` = 'integral_new_user_days');

-- 4) 检查结果
SELECT id, type, title, vip_day, price, pre_price, is_del FROM `eb_member_ship` ORDER BY id;
SELECT id, right_type, title, number, status FROM `eb_member_right` ORDER BY id;
