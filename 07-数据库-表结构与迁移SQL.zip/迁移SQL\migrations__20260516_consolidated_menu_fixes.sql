-- ============================================
-- ECCOMALL 菜单修复合并（原 10 个分散 fix SQL）
-- 合并日期：2026-05-16
-- 所有修复均为幂等（可重复执行不报错）
-- ============================================

SET NAMES utf8mb4;

-- 1. 修复常规商城菜单（fix_regular_mall_menu.sql）
UPDATE `eb_system_menus` SET `menu_path` = '/admin/product/product_list?mall_type=0' WHERE `id` = 2200;
UPDATE `eb_system_menus` SET `menu_name` = 0xE59586E59381 WHERE `id` = 2201;

-- 2. 修复商城菜单编码（fix_mall_menu_encoding.sql）
UPDATE `eb_system_menus` SET `menu_name` = '常规商城' WHERE `id` = 2200;
UPDATE `eb_system_menus` SET `menu_name` = '商品列表' WHERE `id` = 2201;

-- 3. 修复菜单 HEX 编码（fix_mall_menu_hex.sql）
UPDATE `eb_system_menus` SET `menu_name` = 0xE5B8B8E8A784E59586E59F8E WHERE `id` = 2200;
UPDATE `eb_system_menus` SET `menu_name` = 0xE59586E59381E58897E8A1A8 WHERE `id` = 2201;

-- 4. 修复排版管理菜单乱码（fix_layout_menu_garbled.sql）
UPDATE `eb_system_menus` SET `menu_name` = '排版管理' WHERE `menu_path` = '/admin/setting/pages/layout' AND `is_del` = 0;

-- 5. 修复开盒记录菜单（fix_openbox_menu.sql + fix_openbox_menu_garbled.sql）
SET @product_pid = (SELECT `id` FROM `eb_system_menus` WHERE (`header` = 'product' OR `menu_path` = '/admin/product') AND `is_del` = 0 LIMIT 1);
SET @product_pid = IFNULL(@product_pid, 1);

UPDATE `eb_system_menus` SET
  `menu_path` = '/admin/product/openbox_list',
  `unique_auth` = 'admin-product-openbox-list',
  `api_url` = 'product/boxlist',
  `menu_name` = '开盒记录',
  `pid` = @product_pid,
  `header` = 'product',
  `is_show_path` = 0,
  `is_header` = 0
WHERE (`menu_name` = '开盒记录' OR `menu_path` = '/admin/product/openbox_list') AND `is_del` = 0;

INSERT INTO `eb_system_menus` (`pid`, `type`, `icon`, `menu_name`, `module`, `controller`, `action`, `api_url`, `methods`, `params`, `sort`, `is_show`, `is_show_path`, `access`, `menu_path`, `path`, `auth_type`, `header`, `is_header`, `unique_auth`, `is_del`)
SELECT @product_pid, 1, 'md-cube-outline', '开盒记录', 'admin', 'product.BoxLog', 'index', 'product/boxlist', 'GET', '[]', 5, 1, 0, 1, '/admin/product/openbox_list', '1', 1, 'product', 0, 'admin-product-openbox-list', 0
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `eb_system_menus` WHERE `menu_path` = '/admin/product/openbox_list' AND `is_del` = 0);

-- 6. 修复管理员开盒权限（fix_admin_openbox_permission.sql）
-- 注：level=0 的超级管理员不受 role rules 限制，无需额外 SQL

-- 7. 修复营销权限（fix_marketing_permission.sql）
UPDATE `eb_system_menus` SET `access` = 1 WHERE `header` = 'marketing' AND `is_del` = 0;

-- 8. 修复盲盒菜单（fix_manghe_menus.sql）
UPDATE `eb_system_menus` SET
  `menu_name` = '盲盒管理',
  `menu_path` = '/admin/product/manghe',
  `unique_auth` = 'admin-product-manghe',
  `api_url` = 'product/manghe',
  `header` = 'product'
WHERE `menu_name` IN ('盲盒', '盲盒管理', 'manghe') AND `is_del` = 0;

-- 9. 修复开奖日志视图（fix_store_product_kaijiang_log_view.sql）
ALTER TABLE `eb_store_product_kaijiang_log`
  MODIFY COLUMN `kaijiang_time` int(10) unsigned DEFAULT NULL COMMENT '开奖时间';

-- 10. 统一菜单编码
UPDATE `eb_system_menus` SET `menu_name` = CONVERT(BINARY CONVERT(`menu_name` USING latin1) USING utf8mb4)
WHERE `menu_name` REGEXP '^[[:print:]]+$' AND LENGTH(`menu_name`) != CHAR_LENGTH(`menu_name`) LIMIT 100;
