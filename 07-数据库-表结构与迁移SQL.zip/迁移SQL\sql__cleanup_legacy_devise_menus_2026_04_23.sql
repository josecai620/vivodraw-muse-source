-- 清理 CRMEB 老装修菜单 — 把"装修"tab 下除【素材中心】外的全部子菜单软删除
-- 保留入口：首页装修（/admin/setting/pages/devise → 新装修器）+ 素材中心（/admin/system/file）
--
-- 执行：mysql -u<user> -p<pwd> <db> < cleanup_legacy_devise_menus_2026_04_23.sql
-- 说明：使用 is_del=1 软删除，不物理 DELETE；便于回滚（UPDATE … is_del=0 即可恢复）
-- 2026-04-23

-- 1. 软删除旧菜单项：排版管理 / 主题风格 / 页面数据 / PC 商城
UPDATE `eb_system_menus`
SET `is_del` = 1
WHERE `menu_path` IN (
  '/admin/setting/pages/layout',
  '/admin/setting/theme_style',
  '/admin/setting/system_visualization_data',
  '/admin/setting/pc_group_data'
)
AND `is_del` = 0;

-- 2. 确保"首页装修"菜单项存在且标题/路径正确
UPDATE `eb_system_menus`
SET `menu_name` = '首页装修',
    `is_del` = 0,
    `is_show` = 1,
    `menu_path` = '/admin/setting/pages/devise'
WHERE `unique_auth` = 'admin-setting-pages-devise'
  AND (`menu_name` <> '首页装修' OR `is_del` = 1 OR `is_show` = 0 OR `menu_path` <> '/admin/setting/pages/devise');

-- 3. 清理老装修的子菜单项（"商城首页" / "商品分类" / "个人中心" 这些老 DIY 内嵌 tab
--    在数据库里如果以独立菜单存在，一起软删）
UPDATE `eb_system_menus`
SET `is_del` = 1
WHERE `menu_name` IN ('店铺装修', '店铺装修(旧)', '排版管理', '主题风格', '页面数据', 'PC商城', 'PC 商城')
  AND `menu_path` <> '/admin/setting/pages/devise'
  AND `is_del` = 0;

-- 4. 清理权限 key 含旧装修的记录（排除"首页装修"和"素材中心"）
UPDATE `eb_system_menus`
SET `is_del` = 1
WHERE `unique_auth` IN (
  'admin-setting-pages-layout',
  'admin-setting-theme_style',
  'admin-setting-system_visualization_data',
  'setting-system-pc_data'
)
AND `is_del` = 0;

-- ---- 如需回滚，执行以下语句即可恢复（请自行取消注释）----
-- UPDATE `eb_system_menus` SET `is_del` = 0
-- WHERE `menu_path` IN (
--   '/admin/setting/pages/layout',
--   '/admin/setting/theme_style',
--   '/admin/setting/system_visualization_data',
--   '/admin/setting/pc_group_data'
-- );
