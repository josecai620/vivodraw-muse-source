-- 自研首页装修系统 — 不依赖 CRMEB DIY
-- 后台管理 UI：/home-layout/  （backend_src/public/home-layout/index.html）
-- 前台接口：GET /api/home_layout
-- 2026-04-22

-- 首页布局配置表：只保留最新启用的一条（status=1）
CREATE TABLE IF NOT EXISTS `eb_home_layout` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '默认首页' COMMENT '布局名称（仅后台展示）',
  `status` tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT '是否启用 0=否 1=是',
  `blocks` longtext COMMENT '组件块 JSON 数组',
  `theme` text COMMENT '全局主题 JSON: bg_color / bg_image / header_text_color 等',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `create_time` int(11) unsigned NOT NULL DEFAULT 0,
  `update_time` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='自研首页装修布局';

-- 种子一条默认启用布局，后台首次打开不为空
INSERT INTO `eb_home_layout` (`name`, `status`, `blocks`, `theme`, `create_time`, `update_time`)
SELECT * FROM (SELECT
  '默认首页' AS name,
  1 AS status,
  '[
    {"id":"blk_banner","type":"banner","visible":true,"props":{"height":200,"autoplay":true,"interval":3500,"items":[]}},
    {"id":"blk_quick","type":"quick_grid","visible":true,"props":{"columns":3,"items":[
      {"icon":"🎁","label":{"en":"Mystery Box","zh":"盲盒"},"link":"/box"},
      {"icon":"🏆","label":{"en":"Points","zh":"積分"},"link":"/(tabs)/points"},
      {"icon":"🛒","label":{"en":"Group Buy","zh":"拼團"},"link":"/group-lottery"}
    ]}},
    {"id":"blk_notice","type":"notice","visible":true,"props":{"icon":"📣","text":{"en":"Welcome to eccomall","zh":"歡迎光臨 eccomall"},"link":""}},
    {"id":"blk_group_lottery","type":"group_lottery","visible":true,"props":{"title":{"en":"","zh":""},"desc":{"en":"","zh":""},"cta":{"en":"","zh":""},"link":"/group-lottery"}},
    {"id":"blk_points_balance","type":"points_balance","visible":true,"props":{"balance_title":{"en":"","zh":""},"earn":{"en":"","zh":""},"redeem":{"en":"","zh":""},"points_link":"/(tabs)/points","tasks_link":"/points/tasks"}},
    {"id":"blk_category","type":"category_nav","visible":true,"props":{"source":"auto","limit":8,"columns":4}},
    {"id":"blk_hot","type":"product_list","visible":true,"props":{"title":{"en":"Hot Products","zh":"熱門商品"},"source":"hot","layout":"horizontal","limit":10}},
    {"id":"blk_new","type":"product_list","visible":true,"props":{"title":{"en":"New Arrivals","zh":"新品上架"},"source":"new","layout":"grid","limit":6}}
  ]' AS blocks,
  '{"bg_color":"#F9FAFB","bg_image":"","header_text_color":"#111827"}' AS theme,
  UNIX_TIMESTAMP() AS create_time,
  UNIX_TIMESTAMP() AS update_time
) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM `eb_home_layout` LIMIT 1);
