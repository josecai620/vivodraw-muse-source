-- Add missing integral product flags used by mobile integral APIs.
-- Safe to rerun.

SET @add_integral_product_type = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product` ADD COLUMN `product_type` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''Product type flag'' AFTER `is_kami`',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_integral_product'
    AND COLUMN_NAME = 'product_type'
);
PREPARE stmt FROM @add_integral_product_type;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @add_integral_is_xinping = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product` ADD COLUMN `is_xinping` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''New arrival flag'' AFTER `product_type`',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_integral_product'
    AND COLUMN_NAME = 'is_xinping'
);
PREPARE stmt FROM @add_integral_is_xinping;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @add_integral_is_limit = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product` ADD COLUMN `is_limit` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''Limit purchase flag'' AFTER `is_xinping`',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_integral_product'
    AND COLUMN_NAME = 'is_limit'
);
PREPARE stmt FROM @add_integral_is_limit;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @add_integral_limit_num = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product` ADD COLUMN `limit_num` int NOT NULL DEFAULT ''0'' COMMENT ''Limit purchase quantity'' AFTER `is_limit`',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_integral_product'
    AND COLUMN_NAME = 'limit_num'
);
PREPARE stmt FROM @add_integral_limit_num;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @add_integral_is_hot = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product` ADD COLUMN `is_hot` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''Hot flag'' AFTER `limit_num`',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_integral_product'
    AND COLUMN_NAME = 'is_hot'
);
PREPARE stmt FROM @add_integral_is_hot;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @add_integral_is_benefit = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product` ADD COLUMN `is_benefit` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''Benefit flag'' AFTER `is_hot`',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_integral_product'
    AND COLUMN_NAME = 'is_benefit'
);
PREPARE stmt FROM @add_integral_is_benefit;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @add_integral_is_new = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product` ADD COLUMN `is_new` tinyint(1) NOT NULL DEFAULT ''0'' COMMENT ''New product flag'' AFTER `is_benefit`',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_integral_product'
    AND COLUMN_NAME = 'is_new'
);
PREPARE stmt FROM @add_integral_is_new;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @add_integral_product_type_index = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_store_integral_product` ADD INDEX `idx_integral_product_type_show` (`product_type`,`is_show`,`is_del`)',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.STATISTICS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_store_integral_product'
    AND INDEX_NAME = 'idx_integral_product_type_show'
);
PREPARE stmt FROM @add_integral_product_type_index;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
