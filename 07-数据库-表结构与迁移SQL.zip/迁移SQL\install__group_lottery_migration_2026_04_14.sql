-- 拼团抽奖 2026-04-14 迁移：补全中奖发货所需字段
-- 执行前请先确认 group_lottery.sql 已导入

ALTER TABLE `eb_group_lottery_member`
  ADD COLUMN `delivery_type` varchar(32) NOT NULL DEFAULT '' COMMENT '发货方式 send=商家配送 express=快递配送 fictitious=虚拟' AFTER `shipping_address`,
  ADD COLUMN `delivery_name` varchar(64) NOT NULL DEFAULT '' COMMENT '快递公司/配送方姓名' AFTER `delivery_type`,
  ADD COLUMN `delivery_id` varchar(64) NOT NULL DEFAULT '' COMMENT '快递单号/配送方电话' AFTER `delivery_name`,
  ADD COLUMN `delivery_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发货时间' AFTER `delivery_id`,
  ADD COLUMN `admin_note` varchar(300) CHARACTER SET utf8mb4 NOT NULL DEFAULT '' COMMENT '后台备注' AFTER `delivery_time`;

-- 状态语义补充（7=中奖待发货，由管理员发货后 delivery_id 填入；8=已回收）
-- 无需改 status 枚举，前端根据 delivery_id 判断显示「待发货/已发货」
