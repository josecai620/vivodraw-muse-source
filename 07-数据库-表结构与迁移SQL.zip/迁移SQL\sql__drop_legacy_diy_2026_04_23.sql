-- 清理 CRMEB DIY 旧表（不可恢复）
-- 只有在你确认自研 eb_home_layout 已跑通、且没有历史数据需要保留后再执行
-- 2026-04-23

-- 旧版首页 DIY 模板 + 自定义链接
DROP TABLE IF EXISTS `eb_diy`;
DROP TABLE IF EXISTS `eb_page_category`;
DROP TABLE IF EXISTS `eb_page_link`;
