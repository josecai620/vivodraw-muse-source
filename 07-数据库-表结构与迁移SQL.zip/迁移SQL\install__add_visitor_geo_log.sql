-- 访客地理日志表（每 IP 每天一条，去重计数）
-- 用于美国地图仪表盘：访客来源 + 订单地理分布

SET @tbl := 'eb_visitor_geo_log';
SET @exists := (
  SELECT COUNT(1) FROM information_schema.TABLES
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = @tbl
);

SET @create_ddl := IF(@exists = 0, CONCAT(
  'CREATE TABLE `', @tbl, '` (',
  '  `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,',
  '  `ip` VARCHAR(45) NOT NULL DEFAULT '''',',
  '  `uid` INT UNSIGNED NOT NULL DEFAULT 0,',
  '  `country` VARCHAR(64) NOT NULL DEFAULT '''',',
  '  `country_code` VARCHAR(4) NOT NULL DEFAULT '''',',
  '  `state` VARCHAR(64) NOT NULL DEFAULT '''',',
  '  `city` VARCHAR(64) NOT NULL DEFAULT '''',',
  '  `latitude` DECIMAL(10,6) DEFAULT NULL,',
  '  `longitude` DECIMAL(10,6) DEFAULT NULL,',
  '  `visit_date` DATE NOT NULL,',
  '  `visit_count` INT UNSIGNED NOT NULL DEFAULT 1,',
  '  `source` VARCHAR(32) NOT NULL DEFAULT '''',',
  '  `created_at` INT UNSIGNED NOT NULL DEFAULT 0,',
  '  `updated_at` INT UNSIGNED NOT NULL DEFAULT 0,',
  '  UNIQUE KEY `uk_ip_date` (`ip`, `visit_date`),',
  '  KEY `idx_country_date` (`country_code`, `visit_date`),',
  '  KEY `idx_state_date` (`state`, `visit_date`)',
  ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT=''访客地理日志（每IP每天一条）'''
), 'SELECT 1');

PREPARE stmt FROM @create_ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
