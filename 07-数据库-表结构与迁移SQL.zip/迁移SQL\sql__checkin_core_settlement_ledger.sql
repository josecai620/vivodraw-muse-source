-- 签到核心结算审计日志表
-- Execution: CREATE TABLE IF NOT EXISTS ...
-- 2026-05-18

CREATE TABLE IF NOT EXISTS `eb_core_settlement_ledger` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `scene` varchar(64) NOT NULL DEFAULT '' COMMENT '场景：user_checkin / pet_feeding',
  `action` varchar(64) NOT NULL DEFAULT '' COMMENT '操作：daily_checkin / pet_feed',
  `uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '用户ID',
  `request_id` varchar(128) NOT NULL DEFAULT '' COMMENT '幂等请求ID',
  `amount` int(11) NOT NULL DEFAULT 0 COMMENT '积分变动量',
  `direction` tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '方向：1=收入 0=支出',
  `reason` varchar(64) NOT NULL DEFAULT '' COMMENT '原因：checkin_integral / pet_feed_cost 等',
  `meta` text DEFAULT NULL COMMENT '额外元数据(JSON)',
  `add_time` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_request_id` (`scene`, `request_id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_add_time` (`add_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='核心结算审计日志';
