-- 为已有系统添加 CJ Dropshipping API Key 配置（用于商品采集）
-- 如已安装过系统，可执行此 SQL 添加配置项
INSERT INTO `eb_system_config` (`is_store`, `menu_name`, `type`, `input_type`, `config_tab_id`, `parameter`, `upload_type`, `required`, `width`, `high`, `value`, `info`, `desc`, `sort`, `status`)
SELECT 0, 'cj_api_key', 'text', 'input', 41, '', 0, '', 100, 0, '""', 'CJ Dropshipping API Key', '用于采集 cjdropshipping.cn 商品，在 https://www.cjdropshipping.com/myCJ.html#/apikey 生成', 0, 1
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `eb_system_config` WHERE `menu_name` = 'cj_api_key' LIMIT 1);
