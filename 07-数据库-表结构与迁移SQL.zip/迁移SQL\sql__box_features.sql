-- 盲盒商城新功能表 — 签到/心愿池/交换市场/合成
-- 执行前请确认数据库连接正确
-- 2026-03-18

-- 1. 每日签到记录
CREATE TABLE IF NOT EXISTS `eb_user_box_checkin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '用户ID',
  `checkin_date` date NOT NULL COMMENT '签到日期',
  `streak` int(11) unsigned NOT NULL DEFAULT 1 COMMENT '当前连续签到天数',
  `reward_points` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '获得积分',
  `createtime` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_uid_date` (`uid`, `checkin_date`),
  KEY `idx_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='盲盒签到记录';

-- 2. 心愿池
CREATE TABLE IF NOT EXISTS `eb_user_box_wishlist` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '用户ID',
  `box_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '盲盒分类ID(store_category.id)',
  `box_name` varchar(255) NOT NULL DEFAULT '' COMMENT '盲盒名称',
  `item_name` varchar(255) NOT NULL DEFAULT '' COMMENT '心愿物品名称',
  `item_image` varchar(500) NOT NULL DEFAULT '' COMMENT '物品图片',
  `rarity` varchar(50) NOT NULL DEFAULT 'legendary' COMMENT '稀有度(common/uncommon/rare/epic/legendary/secret)',
  `notify` tinyint(1) unsigned NOT NULL DEFAULT 1 COMMENT '是否通知 0=否 1=是',
  `createtime` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_box_id` (`box_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='盲盒心愿池';

-- 3. 交换市场
CREATE TABLE IF NOT EXISTS `eb_user_box_exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '发布人ID',
  `user_box_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '挂出的盲盒物品ID(user_box.id)',
  `product_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '商品ID(store_product.id)',
  `item_name` varchar(255) NOT NULL DEFAULT '' COMMENT '物品名称',
  `item_image` varchar(500) NOT NULL DEFAULT '' COMMENT '物品图片',
  `item_rarity` varchar(50) NOT NULL DEFAULT '' COMMENT '物品稀有度',
  `want_desc` varchar(500) NOT NULL DEFAULT '' COMMENT '想要换取的物品描述',
  `want_rarity` varchar(50) NOT NULL DEFAULT '' COMMENT '想要换取的稀有度',
  `status` tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT '0=上架 1=交换中 2=已完成 3=已取消',
  `applicant_uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '申请人UID',
  `applicant_box_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '申请人提供的物品ID(user_box.id)',
  `createtime` int(11) unsigned NOT NULL DEFAULT 0,
  `updatetime` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`),
  KEY `idx_status` (`status`),
  KEY `idx_user_box_id` (`user_box_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='盲盒交换市场';

-- 4. 合成记录
CREATE TABLE IF NOT EXISTS `eb_user_box_synthesis_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '用户ID',
  `recipe_type` varchar(50) NOT NULL DEFAULT '' COMMENT '配方类型(common_to_uncommon等)',
  `material_ids` text COMMENT '材料盲盒IDs(JSON数组)',
  `result_success` tinyint(1) unsigned NOT NULL DEFAULT 0 COMMENT '0=失败 1=成功',
  `result_product_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '合成结果商品ID',
  `result_item_name` varchar(255) NOT NULL DEFAULT '' COMMENT '合成结果物品名称',
  `result_item_image` varchar(500) NOT NULL DEFAULT '' COMMENT '合成结果物品图片',
  `result_rarity` varchar(50) NOT NULL DEFAULT '' COMMENT '合成结果稀有度',
  `createtime` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='盲盒合成记录';

-- 5. 每日任务领取记录
CREATE TABLE IF NOT EXISTS `eb_user_box_task_claim` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '用户ID',
  `task_id` varchar(50) NOT NULL DEFAULT '' COMMENT '任务ID',
  `claim_date` date NOT NULL COMMENT '领取日期',
  `reward_points` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '获得积分',
  `createtime` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_uid_task_date` (`uid`, `task_id`, `claim_date`),
  KEY `idx_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='盲盒每日任务领取记录';
