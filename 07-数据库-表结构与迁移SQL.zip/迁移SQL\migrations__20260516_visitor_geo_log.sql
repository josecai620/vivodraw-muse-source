-- Visitor geo tracking persistence for the admin US map dashboard.
-- Safe to rerun.

CREATE TABLE IF NOT EXISTS `eb_visitor_geo_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Visitor geo log id',
  `ip` varchar(45) NOT NULL DEFAULT '' COMMENT 'Visitor IP',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'User id, 0 for guest',
  `user_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0 guest, 1 member',
  `country` varchar(64) NOT NULL DEFAULT '' COMMENT 'Country name',
  `country_code` char(2) NOT NULL DEFAULT '' COMMENT 'ISO country code',
  `state` varchar(80) NOT NULL DEFAULT '' COMMENT 'State or province',
  `city` varchar(80) NOT NULL DEFAULT '' COMMENT 'City',
  `latitude` decimal(10,7) DEFAULT NULL COMMENT 'Latitude',
  `longitude` decimal(10,7) DEFAULT NULL COMMENT 'Longitude',
  `visit_date` date NOT NULL COMMENT 'Visit date',
  `visit_count` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'Deduplicated visit count',
  `source` varchar(32) NOT NULL DEFAULT '' COMMENT 'Geo resolution source',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Create time',
  `updated_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Update time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_ip_date_type` (`ip`,`visit_date`,`user_type`),
  KEY `idx_country_date` (`country_code`,`visit_date`),
  KEY `idx_state_date` (`state`,`visit_date`),
  KEY `idx_city_date` (`city`,`visit_date`),
  KEY `idx_uid_date` (`uid`,`visit_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Visitor geo tracking log';

SET @add_user_type = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_visitor_geo_log` ADD COLUMN `user_type` tinyint(1) unsigned NOT NULL DEFAULT ''0'' COMMENT ''0 guest, 1 member'' AFTER `uid`',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_visitor_geo_log'
    AND COLUMN_NAME = 'user_type'
);
PREPARE stmt FROM @add_user_type;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @add_source = (
  SELECT IF(
    COUNT(*) = 0,
    'ALTER TABLE `eb_visitor_geo_log` ADD COLUMN `source` varchar(32) NOT NULL DEFAULT '''' COMMENT ''Geo resolution source'' AFTER `visit_count`',
    'SELECT 1'
  )
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE()
    AND TABLE_NAME = 'eb_visitor_geo_log'
    AND COLUMN_NAME = 'source'
);
PREPARE stmt FROM @add_source;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
