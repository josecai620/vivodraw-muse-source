-- Pet World account ownership and growth profile.
-- Execute manually after code deploy:
-- mysql -u crmeb -p manghehoutai_qhe < deploy/migrations/20260516_pet_world_profile.sql

CREATE TABLE IF NOT EXISTS `eb_user_pet_profile` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL COMMENT 'User uid',
  `starter_pet_code` varchar(32) NOT NULL COMMENT 'Initial assigned pet code',
  `current_pet_code` varchar(32) NOT NULL COMMENT 'Current active pet code',
  `pet_name` varchar(64) NOT NULL DEFAULT '' COMMENT 'Pet nickname',
  `pet_species` varchar(64) NOT NULL DEFAULT '' COMMENT 'Pet species display key',
  `rarity` varchar(16) NOT NULL DEFAULT 'normal' COMMENT 'normal, rare, hidden',
  `intimacy_value` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Total intimacy value',
  `intimacy_level` int(10) unsigned NOT NULL DEFAULT 1 COMMENT 'Derived intimacy level',
  `feed_count_today` int(10) unsigned NOT NULL DEFAULT 0 COMMENT 'Daily interaction count',
  `feed_limit_daily` int(10) unsigned NOT NULL DEFAULT 5 COMMENT 'Daily interaction limit',
  `last_feed_date` date DEFAULT NULL COMMENT 'Last daily reset date',
  `display_mood` varchar(16) NOT NULL DEFAULT 'idle' COMMENT 'idle, happy, sleepy, hint',
  `current_action_hint` varchar(255) DEFAULT NULL COMMENT 'Current pet hint',
  `current_skin_id` varchar(32) DEFAULT NULL COMMENT 'Current skin id',
  `status_flags` json DEFAULT NULL COMMENT 'Server-owned flags',
  `created_at` int(11) unsigned NOT NULL DEFAULT 0,
  `updated_at` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_uid` (`uid`),
  KEY `idx_current_pet_code` (`current_pet_code`),
  KEY `idx_updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Pet World user profile';

CREATE TABLE IF NOT EXISTS `eb_user_pet_owned` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL COMMENT 'User uid',
  `pet_code` varchar(32) NOT NULL COMMENT 'Owned pet code',
  `source` varchar(32) NOT NULL DEFAULT 'starter' COMMENT 'starter, shop, draw, event',
  `is_active` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Current active pet marker',
  `created_at` int(11) unsigned NOT NULL DEFAULT 0,
  `updated_at` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_uid_pet` (`uid`, `pet_code`),
  KEY `idx_pet_code` (`pet_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Pet World owned pets';

CREATE TABLE IF NOT EXISTS `eb_user_pet_event_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL COMMENT 'User uid',
  `request_id` varchar(80) NOT NULL COMMENT 'Idempotency request id',
  `action` varchar(64) NOT NULL COMMENT 'Pet action',
  `delta_integral` int(11) NOT NULL DEFAULT 0 COMMENT 'Point delta',
  `delta_intimacy` int(11) NOT NULL DEFAULT 0 COMMENT 'Intimacy delta',
  `created_at` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_uid_request` (`uid`, `request_id`),
  KEY `idx_uid_created` (`uid`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Pet World account event log';
