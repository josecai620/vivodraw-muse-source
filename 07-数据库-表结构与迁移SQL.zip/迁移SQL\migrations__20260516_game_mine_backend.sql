-- Abyss Mine backend persistence.
-- Execute manually after backup and DB approval:
-- mysql -u crmeb -p manghehoutai_qhe < deploy/migrations/20260516_game_mine_backend.sql

CREATE TABLE IF NOT EXISTS `eb_game_mine_profile` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Mine profile id',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'User uid',
  `mine_level` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT 'Derived mine level',
  `attempt_day` char(10) NOT NULL DEFAULT '' COMMENT 'Attempt reset day YYYY-MM-DD',
  `daily_attempt_used` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Today used mining attempts',
  `wallet_crystals` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Persistent mine crystal balance',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Create time',
  `updated_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Update time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_uid` (`uid`),
  KEY `idx_attempt_day` (`attempt_day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Abyss mine user profile';

CREATE TABLE IF NOT EXISTS `eb_game_mine_node` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Mine node id',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'User uid',
  `plot_no` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Mine plot number',
  `is_unlocked` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Is unlocked',
  `status` varchar(16) NOT NULL DEFAULT 'idle' COMMENT 'idle mining ready depleted locked',
  `ore_tier` varchar(16) NOT NULL DEFAULT 'iron' COMMENT 'Ore tier',
  `ore_id` varchar(32) NOT NULL DEFAULT 'green' COMMENT 'Ore visual id',
  `ore_name` varchar(32) NOT NULL DEFAULT '翠绿晶石' COMMENT 'Ore display name',
  `rarity` varchar(16) NOT NULL DEFAULT 'common' COMMENT 'common rare epic legendary mythic',
  `reward_points` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'Integral reward after collect',
  `duration_seconds` int(10) unsigned NOT NULL DEFAULT '60' COMMENT 'Mining duration',
  `started_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Mining start time',
  `ready_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Ready time',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Create time',
  `updated_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Update time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_uid_plot` (`uid`,`plot_no`),
  KEY `idx_status_ready` (`status`,`ready_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Abyss mine node state';

CREATE TABLE IF NOT EXISTS `eb_game_mine_inventory` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Mine inventory id',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'User uid',
  `item_id` varchar(32) NOT NULL DEFAULT '' COMMENT 'Inventory item id',
  `ore_tier` varchar(16) NOT NULL DEFAULT '' COMMENT 'Ore tier',
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT 'Item name',
  `rarity` varchar(16) NOT NULL DEFAULT 'common' COMMENT 'Rarity',
  `quantity` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Quantity',
  `unit_points` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Point value reference',
  `image_key` varchar(32) NOT NULL DEFAULT '' COMMENT 'Frontend image key',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Create time',
  `updated_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Update time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_uid_item` (`uid`,`item_id`),
  KEY `idx_uid_quantity` (`uid`,`quantity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Abyss mine inventory';

CREATE TABLE IF NOT EXISTS `eb_game_mine_lab_recipe` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Mine lab recipe id',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'User uid',
  `recipe_id` varchar(32) NOT NULL DEFAULT '' COMMENT 'Recipe id',
  `progress` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Progress 0-100',
  `claim_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Claim count in recipe day',
  `max_claims` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'Max claims per day',
  `recipe_day` char(10) NOT NULL DEFAULT '' COMMENT 'Recipe reset day YYYY-MM-DD',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Create time',
  `updated_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Update time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_uid_recipe` (`uid`,`recipe_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Abyss mine lab recipe progress';

CREATE TABLE IF NOT EXISTS `eb_game_mine_worker` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Mine worker id',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'User uid',
  `worker_id` varchar(32) NOT NULL DEFAULT '' COMMENT 'Worker id',
  `is_assigned` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Assigned flag',
  `assigned_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Assigned time',
  `trial_reward_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Daily recall reward count',
  `max_trial_rewards` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'Max recall rewards per day',
  `worker_day` char(10) NOT NULL DEFAULT '' COMMENT 'Worker reset day YYYY-MM-DD',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Create time',
  `updated_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Update time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_uid_worker` (`uid`,`worker_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Abyss mine worker state';

CREATE TABLE IF NOT EXISTS `eb_game_mine_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Mine action log id',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Actor uid',
  `action` varchar(32) NOT NULL DEFAULT '' COMMENT 'Action',
  `target_key` varchar(64) NOT NULL DEFAULT '' COMMENT 'Target key',
  `plot_no` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Plot number',
  `points_delta` int(11) NOT NULL DEFAULT '0' COMMENT 'Signed integral delta',
  `balance_after` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Integral balance after action',
  `item_id` varchar(32) NOT NULL DEFAULT '' COMMENT 'Changed item id',
  `item_delta` int(11) NOT NULL DEFAULT '0' COMMENT 'Signed item quantity delta',
  `risk_flags` varchar(255) NOT NULL DEFAULT '' COMMENT 'Risk flags',
  `request_hash` varchar(64) NOT NULL DEFAULT '' COMMENT 'Idempotency hash',
  `client_now_ms` bigint(20) NOT NULL DEFAULT '0' COMMENT 'Client timestamp audit',
  `server_now` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Server timestamp',
  `payload_json` text NULL COMMENT 'Debug payload',
  `created_at` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Create time',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_request_hash` (`request_hash`),
  KEY `idx_uid_action_time` (`uid`,`action`,`created_at`),
  KEY `idx_uid_target_time` (`uid`,`target_key`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Abyss mine action audit log';
