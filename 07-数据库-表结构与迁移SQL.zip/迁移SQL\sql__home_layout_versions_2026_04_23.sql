-- 首页装修版本历史表 — 每次"发布"写入一条快照，支持回滚
-- 2026-04-23

CREATE TABLE IF NOT EXISTS `eb_home_layout_version` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `layout_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '对应 eb_home_layout.id',
  `version_no` int(11) unsigned NOT NULL DEFAULT 1 COMMENT '版本号（针对同一 layout_id 自增）',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '快照时的布局名',
  `blocks` longtext COMMENT '组件块 JSON 快照',
  `theme` text COMMENT '主题 JSON 快照',
  `note` varchar(255) NOT NULL DEFAULT '' COMMENT '发布备注',
  `author_id` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '发布者 admin_id',
  `published_at` int(11) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_layout` (`layout_id`, `version_no` DESC),
  KEY `idx_pub` (`published_at` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='首页装修版本历史';

-- 为 eb_home_layout 增加"草稿"字段：保存时写 draft_*，发布时才拷贝到 blocks/theme 并写 version 表
ALTER TABLE `eb_home_layout`
  ADD COLUMN `draft_blocks` longtext NULL COMMENT '草稿：未发布的组件 JSON' AFTER `blocks`,
  ADD COLUMN `draft_theme` text NULL COMMENT '草稿：未发布的主题 JSON' AFTER `theme`,
  ADD COLUMN `draft_updated_at` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '草稿最后编辑时间' AFTER `draft_theme`,
  ADD COLUMN `published_version` int(11) unsigned NOT NULL DEFAULT 0 COMMENT '当前已发布版本号（对应 version 表 version_no）' AFTER `draft_updated_at`;
