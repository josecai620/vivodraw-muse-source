import React, { useEffect, useMemo, useRef, useState } from "react";
import { Modal, Pressable, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { Square, CheckSquare } from "lucide-react-native";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { Colors } from "@/constants/theme";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import { useExchangeAll, usePointsBalance, usePointsCart } from "@/hooks/usePoints";
import { newCloudBuyRequestId } from "@/lib/api/points";
import { getMemberCoupons } from "@/lib/api/userLevel";
import { unwrapApiData, unwrapApiListField } from "@/lib/api/response";
import { useQuery } from "@tanstack/react-query";
import { mergePendingCartItem, parseCloudBuyCart, type CloudBuyCartItem } from "@/lib/points/cloudBuyCart";
import { clearPendingCartItem, peekPendingCartItem } from "@/lib/points/openCloudBuyCart";

const TEAL = Colors.primary.DEFAULT;
const UNIT_COST = 1;

function parseIdSet(raw: string | string[] | undefined): Set<number> {
  const text = Array.isArray(raw) ? raw.join(",") : String(raw || "");
  return new Set(
    text
      .split(",")
      .map((x) => Number(x))
      .filter((n) => n > 0),
  );
}

function pickCartIds(list: CloudBuyCartItem[], idSet: Set<number>, pendingPid: number): number[] {
  if (idSet.size) {
    const hit = list.filter((it) => idSet.has(it.id) && it.id > 0).map((it) => it.id);
    if (hit.length) return hit;
  }
  if (pendingPid > 0) {
    const hit = list.find((it) => it.productId === pendingPid && it.id > 0);
    if (hit) return [hit.id];
  }
  return list.map((it) => it.id).filter((id) => id > 0);
}

export default function PointsPayScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ ids?: string }>();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const user = useAuthStore((s) => s.user);
  const showToast = useAppStore((s) => s.showToast);
  const { data, refetch } = usePointsCart();
  const { data: balanceData } = usePointsBalance();
  const { data: couponRaw } = useQuery({
    queryKey: ["memberCoupons"],
    queryFn: getMemberCoupons,
    enabled: isLoggedIn,
  });
  const exchangeAll = useExchangeAll();
  const [usePoints, setUsePoints] = useState(true);
  const [useLucky, setUseLucky] = useState(true);
  const [useCoupon, setUseCoupon] = useState(true);
  const [buyNext, setBuyNext] = useState(false);
  const [askNeedPoints, setAskNeedPoints] = useState(false);
  const payingLock = useRef(false);

  useEffect(() => {
    if (isLoggedIn) void refetch();
  }, [isLoggedIn, refetch]);

  const idSet = useMemo(() => parseIdSet(params.ids), [params.ids]);
  const pending = peekPendingCartItem();

  const items = useMemo(() => {
    const merged = mergePendingCartItem(parseCloudBuyCart(data), pending);
    if (idSet.size === 0) return merged;
    const picked = merged.filter(
      (it) => idSet.has(it.id) || (it.id <= 0 && pending?.productId === it.productId),
    );
    return picked.length ? picked : merged;
  }, [data, idSet, pending]);

  const totalShares = items.reduce((s, it) => s + it.num, 0);
  const totalPoints = totalShares * UNIT_COST;
  const pointsBalance = Number(
    (balanceData as any)?.data?.integral ?? (balanceData as any)?.integral ?? user?.integral ?? 0,
  );
  const luckyBalance = Number(
    (balanceData as any)?.data?.lucky_num ?? (balanceData as any)?.lucky_num ?? user?.lucky_num ?? 0,
  );
  const luckyOffset = useLucky ? Math.min(totalPoints, Math.floor(luckyBalance / 100)) : 0;
  const coupons = unwrapApiListField<{
    id?: number;
    coupon_title?: string;
    title?: string;
    coupon_price?: number | string;
    use_min_price?: number | string;
    status?: number | string;
  }>(couponRaw);
  const bestCoupon = useMemo(() => {
    return coupons
      .filter((row) => {
        const status = row.status;
        if (status === 1 || status === "1" || status === "已使用" || status === "已过期") return false;
        return Number(row.use_min_price ?? 0) <= totalPoints && Number(row.coupon_price ?? 0) > 0;
      })
      .sort((a, b) => Number(b.coupon_price ?? 0) - Number(a.coupon_price ?? 0))[0];
  }, [coupons, totalPoints]);
  const couponOff =
    useCoupon && bestCoupon ? Math.min(totalPoints - luckyOffset, Number(bestCoupon.coupon_price) || 0) : 0;
  const payablePoints = Math.max(0, totalPoints - luckyOffset - couponOff);
  const paying = exchangeAll.isPending;

  const goSuccess = (paid: CloudBuyCartItem[]) => {
    clearPendingCartItem();
    router.replace({
      pathname: "/points/pay-success",
      params: {
        items: encodeURIComponent(
          JSON.stringify(
            paid.map((it) => ({
              productId: it.productId,
              name: it.name,
              image: it.image,
              bianhao: it.bianhao,
              shares: it.num,
              remain: Math.max(0, it.remain),
            })),
          ),
        ),
      },
    } as never);
  };

  const paidFromSettle = (res: unknown, source: CloudBuyCartItem[]): CloudBuyCartItem[] => {
    const nested = unwrapApiData<Record<string, unknown>>(res, {});
    const raw = res && typeof res === "object" ? (res as Record<string, unknown>) : {};
    const outcomes = (
      Array.isArray(nested.items) ? nested.items : Array.isArray(raw.items) ? raw.items : []
    ) as Record<string, unknown>[];
    return outcomes
      .filter((row) => row.status === "accepted" && Number(row.shares) > 0)
      .map((hit) => {
        const it = source.find((row) => row.productId === Number(hit.productId));
        const shares = Math.max(0, Number(hit.shares) || 0);
        const remain =
          hit.remainingShares != null
            ? Math.max(0, Number(hit.remainingShares) || 0)
            : hit.becameFull
              ? 0
              : Math.max(0, (it?.remain ?? 0) - shares);
        return {
          id: it?.id ?? 0,
          productId: Number(hit.productId) || it?.productId || 0,
          name: it?.name ?? "",
          image: it?.image ?? "",
          num: shares,
          bianhao: hit.periodNo != null ? String(hit.periodNo) : it?.bianhao ?? "",
          remain,
          totalNeed: it?.totalNeed ?? 0,
        };
      })
      .filter((it) => it.productId > 0 && it.num > 0);
  };

  const onPay = async () => {
    if (payingLock.current || paying) return;
    if (!isLoggedIn) {
      router.push("/auth");
      return;
    }
    if (!usePoints) {
      setAskNeedPoints(true);
      return;
    }

    payingLock.current = true;
    try {
      const fresh = await refetch();
      const serverList = parseCloudBuyCart(fresh.data).filter((it) => it.id > 0);
      const ids = pickCartIds(serverList, idSet, pending?.productId ?? 0);
      const payItems = serverList.filter((it) => ids.includes(it.id));
      const serverShares = payItems.reduce((s, it) => s + it.num, 0);
      const serverCost = serverShares * UNIT_COST;
      const serverOffset = useLucky ? Math.min(serverCost, Math.floor(luckyBalance / 100)) : 0;
      const serverCoupon = useCoupon && bestCoupon ? Number(bestCoupon.coupon_price) || 0 : 0;
      const serverPayable = Math.max(0, serverCost - serverOffset - serverCoupon);
      if (!ids.length || !payItems.length) {
        showToast(t("pointsMall.payCartNotReady"), "error");
        payingLock.current = false;
        return;
      }
      if (pointsBalance < serverPayable) {
        showToast(t("pointsMall.insufficientPoints"), "error");
        payingLock.current = false;
        return;
      }

      const requestId = newCloudBuyRequestId("cart");
      exchangeAll.mutate(
        { ids: ids.join(","), zidong: buyNext ? 1 : 0, client_request_id: requestId, use_lucky: useLucky ? 1 : 0, coupon_id: useCoupon && bestCoupon?.id ? Number(bestCoupon.id) : 0 },
        {
          onSuccess: (res) => {
            const paid = paidFromSettle(res, payItems);
            if (!paid.length) {
              showToast(t("pointsMall.payNothingSettled"), "error");
              return;
            }
            goSuccess(paid);
          },
          onSettled: () => {
            payingLock.current = false;
          },
        },
      );
    } catch {
      payingLock.current = false;
    }
  };

  return (
    <View className="flex-1 bg-white">
      <PageHeader title={t("pointsMall.payTitle")} />
      <ScrollView contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 80 }}>
        <View className="bg-gray-50 px-4 py-3">
          {items.map((it) => (
            <View key={`${it.id}-${it.productId}`} className="flex-row justify-between py-2">
              <Text className="flex-1 text-[13px] text-gray-800 pr-3" numberOfLines={2}>
                {it.bianhao ? `${t("pointsMall.periodN", { n: it.bianhao })} ` : ""}
                {it.name}
              </Text>
              <Text className="text-[13px] text-gray-500">x{it.num}</Text>
            </View>
          ))}
          {!items.length ? (
            <Text className="text-sm text-gray-400 py-2">{t("pointsMall.cartEmpty")}</Text>
          ) : null}
          <View className="flex-row justify-between pt-2 border-t border-gray-200 mt-1">
            <Text className="text-sm text-gray-600">{t("pointsMall.cartTotal")}</Text>
            <Text className="text-base font-bold" style={{ color: TEAL }}>
              {totalShares}
            </Text>
          </View>
        </View>

        <Pressable className="flex-row items-center px-4 py-4 border-b border-gray-100" onPress={() => setUsePoints((v) => !v)}>
          {usePoints ? <CheckSquare size={20} color={TEAL} /> : <Square size={20} color="#C4C7C7" />}
          <Text className="flex-1 ml-3 text-[13px] text-gray-700">
            {t("pointsMall.pointsPay", { pay: payablePoints, bal: pointsBalance })}
          </Text>
        </Pressable>

        <Pressable className="flex-row items-center px-4 py-4 border-b border-gray-100" onPress={() => setUseLucky((v) => !v)}>
          {useLucky ? <CheckSquare size={20} color={TEAL} /> : <Square size={20} color="#C4C7C7" />}
          <View className="flex-1 ml-3">
            <Text className="text-[13px] text-gray-700">
              {t("pointsMall.luckyPay", { n: luckyBalance, off: luckyOffset })}
            </Text>
            <Text className="text-[11px] text-gray-400 mt-1">{t("pointsMall.luckyPayHint")}</Text>
          </View>
        </Pressable>

        {bestCoupon ? (
          <Pressable className="flex-row items-center px-4 py-4 border-b border-gray-100" onPress={() => setUseCoupon((v) => !v)}>
            {useCoupon ? <CheckSquare size={20} color={TEAL} /> : <Square size={20} color="#C4C7C7" />}
            <View className="flex-1 ml-3">
              <Text className="text-[13px] text-gray-700">
                {t("pointsMall.memberCouponPay", {
                  title: bestCoupon.coupon_title ?? bestCoupon.title ?? "",
                  off: Number(bestCoupon.coupon_price) || 0,
                })}
              </Text>
              <Text className="text-[11px] text-gray-400 mt-1">
                {t("pointsMall.memberCouponPayHint", { min: Number(bestCoupon.use_min_price) || 0 })}
              </Text>
            </View>
          </Pressable>
        ) : (
          <View className="px-4 py-3 border-b border-gray-100">
            <Text className="text-[12px] text-gray-400">{t("pointsMall.memberCouponNone")}</Text>
          </View>
        )}

        <Pressable className="flex-row items-center px-4 py-4 border-b border-gray-100" onPress={() => setBuyNext((v) => !v)}>
          {buyNext ? <CheckSquare size={20} color={TEAL} /> : <Square size={20} color="#C4C7C7" />}
          <Text className="flex-1 ml-3 text-[13px] text-gray-700">{t("pointsMall.buyNextPeriod")}</Text>
        </Pressable>
      </ScrollView>

      <Pressable
        onPress={onPay}
        disabled={paying}
        style={{
          marginHorizontal: 12,
          marginBottom: pointsMallTabPaddingBottom(insets.bottom) + 8,
          height: 46,
          borderRadius: 6,
          backgroundColor: paying ? "#c8c8c8" : TEAL,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Text className="text-white text-base font-bold">
          {paying ? t("common.loading") : t("pointsMall.payNow")}
        </Text>
      </Pressable>
      <Modal transparent visible={askNeedPoints} animationType="fade" onRequestClose={() => setAskNeedPoints(false)}>
        <Pressable
          style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.35)", alignItems: "center", justifyContent: "center" }}
          onPress={() => setAskNeedPoints(false)}
        >
          <Pressable
            onPress={() => {}}
            style={{ width: 280, backgroundColor: "#fff", borderRadius: 8, overflow: "hidden" }}
          >
            <Text className="text-center text-[15px] text-gray-800 px-5 py-6">{t("pointsMall.needPointsPay")}</Text>
            <Pressable
              className="h-11 items-center justify-center border-t border-gray-100"
              style={{ backgroundColor: TEAL }}
              onPress={() => setAskNeedPoints(false)}
            >
              <Text className="text-white font-bold">{t("common.ok")}</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>
      <PointsMallTabBar />
    </View>
  );
}
