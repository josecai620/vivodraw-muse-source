import React from "react";
import { View } from "react-native";

interface HlSpacerProps {
  props: {
    height?: number;
    bg?: string;
  };
}

export default function HlSpacer({ props }: HlSpacerProps) {
  return <View style={{ height: props.height ?? 16, backgroundColor: props.bg || "transparent" }} />;
}
