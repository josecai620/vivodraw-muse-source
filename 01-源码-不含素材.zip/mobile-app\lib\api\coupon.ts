import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

export interface Coupon {
  id: number;
  coupon_title: string;
  coupon_price: string;
  use_min_price: string;
  start_time: string;
  end_time: string;
  type: number;
  status: number;
  is_use: number;
}

export function getCouponList(params?: { page?: number; limit?: number }) {
  return http.get<Coupon[]>(API_ENDPOINTS.coupon.list, { params });
}

/** 我的优惠券：types 0=全部 1=未使用 2=已使用 3=已过期 */
export function getMyCoupons(types = 1) {
  return http.get<Coupon[]>(API_ENDPOINTS.coupon.myCoupons(types));
}

/** 订单可用券：price 为订单金额或 cartId（根据后端要求传入） */
export function getOrderCoupons(price: string | number) {
  return http.get<Coupon[]>(API_ENDPOINTS.coupon.orderCoupons(price));
}

/** 领取优惠券：body 传 couponId */
export async function receiveCoupon(id: number) {
  const res = await http.post(API_ENDPOINTS.coupon.receive, { couponId: id });
  return res;
}
