import React from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { getUserAgreement } from "@/lib/api/agreement";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

const TITLES: Record<string, string> = {
  about: "About VivoDraw / 關於 VivoDraw",
  user_agreement: "User Agreement / 用戶協議",
  privacy_agreement: "Privacy Policy / 隱私政策",
  register_agreement: "Terms of Service / 服務條款",
};

const FALLBACK_DOCUMENTS: Record<string, string> = {
  about: "VivoDraw is a shopping and rewards platform built around product discovery, community sharing, and member benefits.\n\nOur goal is to make every visit clear, enjoyable, and useful—from browsing products to tracking orders and rewards.\n\nNeed help? Visit Help Center from your profile for order, account, and service support.\n\n——\n\nVivoDraw 是結合商品探索、社群分享與會員回饋的購物平台。\n\n我們希望讓每一次使用都清楚、愉快且有收穫：從瀏覽商品、追蹤訂單，到查看會員回饋。\n\n如需協助，請從個人中心前往幫助中心，取得訂單、帳戶與服務支援。",
  privacy_agreement: "VivoDraw uses the information you provide to operate your account, process orders, deliver support, prevent abuse, and improve the service.\n\nWe protect account data with access controls and do not sell personal information. We only share information with service providers when needed to fulfill an order, process a payment, provide support, or meet legal obligations.\n\nYou can review and update your profile details in Account Settings. For privacy questions or requests, contact us through Help Center.\n\n——\n\nVivoDraw 使用您提供的資料來運作帳戶、處理訂單、提供支援、防止濫用並改善服務。\n\n我們以存取控制保護帳戶資料，不會出售個人資訊。僅在完成訂單、處理付款、提供支援或履行法定義務所需時，才會與服務提供者共享必要資料。\n\n您可在帳號設定中檢視或更新個人資料；如有隱私問題或請求，請透過幫助中心聯絡我們。",
  user_agreement: "By using VivoDraw, you agree to use the service lawfully and provide accurate account and order information.\n\nOrders, rewards, promotions, and account features are subject to the information shown in the service at the time of use. We may update features or these terms when necessary.\n\nPlease keep your account credentials secure and contact Help Center promptly if you notice unauthorized activity.\n\n——\n\n使用 VivoDraw 即表示您同意合法使用服務，並提供正確的帳戶與訂單資訊。\n\n訂單、回饋、活動及帳戶功能，以使用當下服務頁面顯示的內容為準；我們可能在必要時更新功能或本協議。\n\n請妥善保管帳戶憑證，如發現未授權活動，請立即透過幫助中心聯絡我們。",
};

function stripHtml(html: string): string {
  return html.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
}

export default function AgreementScreen() {
  const { type } = useLocalSearchParams<{ type: string }>();
  const agreementType = type ?? "user_agreement";
  const fallbackDocument = FALLBACK_DOCUMENTS[agreementType];

  const { data, isLoading } = useQuery({
    queryKey: ["userAgreement", agreementType],
    queryFn: () => getUserAgreement(agreementType),
    enabled: !!agreementType && agreementType !== "about",
  });

  const raw = (data as any)?.data ?? data ?? {};
  const content = raw?.content ?? raw?.value ?? raw ?? "";
  const text = typeof content === "string" ? stripHtml(content) : "";
  const title = TITLES[agreementType] ?? "Agreement / 協議";
  const fallbackContent = fallbackDocument ?? "";

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={title} />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }} showsVerticalScrollIndicator={false}>
          <Text className="text-base leading-6" style={{ color: Colors.neutral[700] }}>
            {text || fallbackContent || "No content available."}
          </Text>
        </ScrollView>
      )}
    </View>
  );
}
