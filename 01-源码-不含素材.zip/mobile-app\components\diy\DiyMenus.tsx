// [已废弃] 改由 @/components/home-layout/HlQuickGrid 替代
export default function DiyMenusDeprecated(): null { return null; }
