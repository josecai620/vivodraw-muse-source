import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { usePathname, useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { PanResponder, Platform, Pressable, StyleSheet, Text, View, useWindowDimensions, type ViewStyle } from "react-native";

import { PixelDeskPetSprite } from "@/components/pets/PixelDeskPetSprite";
import {
  claimPetDailyGift,
  dialogueMatchesLocale,
  fetchPetDailyGiftStatus,
  fetchPetDeskDialogue,
  type PetDeskDialogue,
} from "@/lib/api/petWorld";
import {
  PET_SPRITE_RENDER_SIZE,
  getPetActionDurationMs,
  getPetBehaviorConfig,
  pickRandomPetAction,
  type PetActionName,
} from "@/lib/pet-animations";
import { getPixelDeskPet, type PixelDeskPetId } from "@/lib/pets";
import { useAuthStore } from "@/store/auth";
import { usePetTheme } from "@/store/pet-theme";

const PET_SIZE = PET_SPRITE_RENDER_SIZE;
const PET_VISUAL_SCALE = 0.72;
const PET_HIT_SIZE = Math.round(PET_SIZE * PET_VISUAL_SCALE);
const PET_RIGHT = 4;
const PET_BOTTOM = 92;
const PET_MARGIN = 4;
const BUBBLE_WIDTH = 168;
const PETS_THAT_FACE_WALL_ON_RIGHT: ReadonlySet<PixelDeskPetId> = new Set([
  "octopus_wizard",
  "raccoon_reader",
  "blue_sprout_slime",
]);
const FRONT_FACING_ACTIONS: ReadonlySet<PetActionName> = new Set([
  "standIdleFront",
  "pawGreetFront",
  "headTiltFront",
  "frontBobIdle",
  "frontHappyWave",
  "frontJoyBounce",
  "frontReadIdle",
  "frontPageFlip",
  "frontHappyLookup",
]);

const HIDDEN_ROUTES = [/^\/auth/, /^\/login/, /^\/register/, /^\/checkout/, /^\/pearl/, /^\/farm/, /^\/mine/];

type PetPosition = { x: number; y: number };

type WebPointerLikeEvent = {
  button?: number;
  buttons?: number;
  clientX?: number;
  clientY?: number;
  pageX?: number;
  pageY?: number;
  pointerId?: number;
  nativeEvent?: WebPointerLikeEvent;
  preventDefault?: () => void;
  stopPropagation?: () => void;
};

type WebPointerCaptureTarget = {
  releasePointerCapture?: (pointerId: number) => void;
  setPointerCapture?: (pointerId: number) => void;
};

type WebDragState = {
  origin: PetPosition;
  pointerId: number;
  startX: number;
  startY: number;
};

function randomBetween(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function shouldHideDeskPet(pathname: string) {
  return HIDDEN_ROUTES.some((pattern) => pattern.test(pathname));
}

type SpeechBubble = {
  title: string;
  message: string;
  ctaLabel: string;
  route: string;
};

function isSameRoute(pathname: string, href: string) {
  if (!href) return true;
  if (pathname === href) return true;
  if (href === "/") return pathname === "/" || pathname === "" || pathname === "/index";
  return pathname.startsWith(`${href}/`) || pathname.startsWith(`${href}?`);
}

export function FloatingDeskPet() {
  const router = useRouter();
  const pathname = usePathname();
  const { t, i18n } = useTranslation();
  const lang = i18n.language || "en";
  const token = useAuthStore((s) => s.token);
  const hasApiToken = !!token;
  const { activePetId, previewAction, previewNonce } = usePetTheme();
  const { width: layoutWidth, height: layoutHeight } = useWindowDimensions();
  const width = Platform.OS === "web" && typeof window !== "undefined" && window.innerWidth > 0 ? window.innerWidth : layoutWidth;
  const height = Platform.OS === "web" && typeof window !== "undefined" && window.innerHeight > 0 ? window.innerHeight : layoutHeight;
  const behavior = useMemo(() => getPetBehaviorConfig(activePetId), [activePetId]);
  const dragActionPool = useMemo(() => {
    const actions = [behavior.dragAction, ...behavior.previewActions].filter(
      (action) => action !== behavior.defaultAction && action !== behavior.inactiveAction,
    );
    return [...new Set(actions)];
  }, [behavior.defaultAction, behavior.dragAction, behavior.inactiveAction, behavior.previewActions]);
  const tapActionPool = useMemo(() => {
    const actions = [...behavior.clickPool, ...behavior.previewActions].filter(
      (action) => action !== behavior.defaultAction && action !== behavior.inactiveAction,
    );
    return [...new Set(actions)];
  }, [behavior.clickPool, behavior.defaultAction, behavior.inactiveAction, behavior.previewActions]);
  const idleActionPool = useMemo(() => {
    const actions = [...behavior.randomIdlePool, ...behavior.previewActions].filter(
      (action) => action !== behavior.defaultAction && action !== behavior.inactiveAction && action !== "fail",
    );
    return [...new Set(actions)];
  }, [behavior.defaultAction, behavior.inactiveAction, behavior.previewActions, behavior.randomIdlePool]);
  const defaultPosition = useMemo(() => getDefaultPetPosition(width, height), [height, width]);
  const getViewportDefaultPosition = useCallback(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return defaultPosition;
    const viewportSize = getWebViewportSize(width, height);
    return getDefaultPetPosition(viewportSize.width, viewportSize.height);
  }, [defaultPosition, height, width]);
  const [currentAction, setCurrentAction] = useState<PetActionName>(behavior.defaultAction);
  const shouldFacePage = PETS_THAT_FACE_WALL_ON_RIGHT.has(activePetId) && !FRONT_FACING_ACTIONS.has(currentAction);
  const [position, setPosition] = useState(defaultPosition);
  const [giftCanClaim, setGiftCanClaim] = useState(false);
  const [giftToast, setGiftToast] = useState("");
  const [speech, setSpeech] = useState<SpeechBubble | null>(null);
  const actionTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const dragOriginRef = useRef(defaultPosition);
  const activeDragActionRef = useRef<PetActionName>(behavior.dragAction);
  const positionRef = useRef(defaultPosition);
  const webDragRef = useRef<WebDragState | null>(null);
  const dragMovedRef = useRef(false);
  const hasUserPositionedRef = useRef(false);
  const lastDragAtRef = useRef(0);
  const lastInteractionRef = useRef(Date.now());
  const giftClaimingRef = useRef(false);
  const speechSeqRef = useRef(0);
  const handlePressRef = useRef<() => void>(() => {});
  const dismissedSpeechRef = useRef(false);
  const greetingShownRef = useRef(false);
  const usesAnchoredDefault = !hasUserPositionedRef.current && position.x === defaultPosition.x && position.y === defaultPosition.y;
  const petPositionStyle: ViewStyle = usesAnchoredDefault ? styles.petButtonDefaultAnchor : { left: position.x, top: position.y };

  const updatePosition = useCallback(
    (nextPosition: PetPosition) => {
      const clamped = clampPetPosition(nextPosition, width, height);
      positionRef.current = clamped;
      setPosition((current) => (current.x === clamped.x && current.y === clamped.y ? current : clamped));
    },
    [height, width],
  );

  const getEffectivePosition = useCallback(() => {
    if (hasUserPositionedRef.current) return positionRef.current;
    const viewportPosition = getViewportDefaultPosition();
    positionRef.current = viewportPosition;
    dragOriginRef.current = viewportPosition;
    return viewportPosition;
  }, [getViewportDefaultPosition]);

  function playTemporaryAction(action: PetActionName) {
    if (actionTimerRef.current) {
      clearTimeout(actionTimerRef.current);
      actionTimerRef.current = null;
    }
    lastInteractionRef.current = Date.now();
    if (currentAction === action) {
      setCurrentAction(behavior.defaultAction);
      setTimeout(() => setCurrentAction(action), 0);
    } else {
      setCurrentAction(action);
    }
    if (action === behavior.inactiveAction) return;
    actionTimerRef.current = setTimeout(() => {
      setCurrentAction(behavior.defaultAction);
      actionTimerRef.current = null;
    }, getPetActionDurationMs(activePetId, action));
  }

  const localSpeech = useCallback((): SpeechBubble => {
    const quote = t(`petDeck.pets.${activePetId}.quote`, {
      defaultValue: getPixelDeskPet(activePetId)?.quote || "",
    });
    if (!hasApiToken) {
      return {
        title: t("petDeck.speech.signInTitle"),
        message: t("petDeck.speech.signInMessage"),
        ctaLabel: t("petDeck.speech.signInCta"),
        route: "/auth",
      };
    }
    if (giftCanClaim) {
      return {
        title: t("petDeck.speech.giftTitle"),
        message: t("petDeck.speech.giftMessage"),
        ctaLabel: t("petDeck.speech.giftCta"),
        route: "/pet-deck",
      };
    }
    if (isSameRoute(pathname || "", "/pet-deck")) {
      return {
        title: t("petDeck.speech.bondTitle"),
        message: t("petDeck.speech.bondMessage"),
        ctaLabel: t("petDeck.speech.gotItCta"),
        route: "/pet-deck",
      };
    }
    return {
      title: t("petDeck.speech.sayTitle"),
      message: quote || t("petDeck.speech.sayFallback"),
      ctaLabel: t("petDeck.speech.petDeckCta"),
      route: "/pet-deck",
    };
  }, [activePetId, giftCanClaim, hasApiToken, pathname, t]);

  const openSpeech = useCallback(
    (next?: SpeechBubble | PetDeskDialogue | null) => {
      dismissedSpeechRef.current = false;
      if (next && typeof next === "object" && "message" in next && next.message && dialogueMatchesLocale(next, lang)) {
        setSpeech({
          title: next.title || t("petDeck.speech.petSays"),
          message: next.message,
          ctaLabel: next.ctaLabel || t("petDeck.speech.gotItCta"),
          route: next.route || "/pet-deck",
        });
        return;
      }
      setSpeech(localSpeech());
    },
    [lang, localSpeech, t],
  );

  const closeSpeech = useCallback(() => {
    dismissedSpeechRef.current = true;
    setSpeech(null);
  }, []);

  const goRoute = useCallback(
    (href: string) => {
      if (isSameRoute(pathname || "", href)) return;
      router.push(href as never);
    },
    [pathname, router],
  );

  const handleSpeechCta = useCallback(() => {
    if (!speech) {
      closeSpeech();
      return;
    }
    const href = speech.route;
    const claimCta = speech.ctaLabel === t("petDeck.speech.giftCta");
    closeSpeech();
    if (giftCanClaim && claimCta) {
      void handlePressRef.current();
      return;
    }
    goRoute(href);
  }, [closeSpeech, giftCanClaim, goRoute, speech, t]);

  async function handlePress() {
    if (Date.now() - lastDragAtRef.current < 220) return;
    playTemporaryAction(pickRandomPetAction(tapActionPool, behavior.defaultAction));
    openSpeech();
    if (!hasApiToken) return;
    if (giftClaimingRef.current) return;
    if (giftCanClaim) {
      giftClaimingRef.current = true;
      try {
        const result = await claimPetDailyGift(activePetId);
        if (result.ok && result.gift) {
          setGiftCanClaim(!!result.gift.canClaim);
          if (result.gift.accepted) {
            setGiftToast(`+${result.coins || result.points}`);
            setTimeout(() => setGiftToast(""), 2400);
            openSpeech({
              title: t("petDeck.speech.gotGiftTitle"),
              message: t("petDeck.speech.gotGiftMessage", { amount: result.coins || result.points }),
              ctaLabel: t("petDeck.speech.petDeckCta"),
              route: "/pet-deck",
            });
          }
        }
      } catch {
        // keep the speech bubble; never remount the current page
      } finally {
        giftClaimingRef.current = false;
      }
      return;
    }
    const seq = ++speechSeqRef.current;
    fetchPetDeskDialogue({
      deskPetId: activePetId,
      trigger: "idle",
      route: pathname || "/pet-deck",
      locale: lang,
    })
      .then((tip) => {
        if (seq !== speechSeqRef.current || !tip?.message) return;
        openSpeech(tip);
      })
      .catch(() => {});
  }
  handlePressRef.current = handlePress;

  useEffect(() => {
    activeDragActionRef.current = behavior.dragAction;
    setCurrentAction(behavior.defaultAction);
    lastInteractionRef.current = Date.now();
  }, [activePetId, behavior.defaultAction, behavior.dragAction]);

  useEffect(() => {
    playTemporaryAction(previewAction);
  }, [previewAction, previewNonce]);

  useEffect(() => {
    if (width <= PET_SIZE || height <= PET_SIZE) return;
    updatePosition(hasUserPositionedRef.current ? positionRef.current : getViewportDefaultPosition());
  }, [getViewportDefaultPosition, height, updatePosition, width]);

  useEffect(() => {
    let active = true;
    if (!hasApiToken) {
      setGiftCanClaim(false);
      return () => {
        active = false;
      };
    }
    fetchPetDailyGiftStatus(activePetId)
      .then((status) => {
        if (active) setGiftCanClaim(!!status?.canClaim);
      })
      .catch(() => {
        if (active) setGiftCanClaim(false);
      });
    return () => {
      active = false;
    };
  }, [activePetId, hasApiToken]);

  useEffect(() => {
    if (currentAction !== behavior.defaultAction) return undefined;
    const timer = setTimeout(() => {
      const nextAction = pickRandomPetAction(idleActionPool, behavior.defaultAction);
      if (nextAction !== behavior.defaultAction) playTemporaryAction(nextAction);
    }, randomBetween(behavior.randomIdleAfterMs[0], behavior.randomIdleAfterMs[1]));
    return () => clearTimeout(timer);
  }, [activePetId, behavior, currentAction, idleActionPool]);

  useEffect(() => {
    if (shouldHideDeskPet(pathname || "") || dismissedSpeechRef.current || greetingShownRef.current) return undefined;
    const timer = setTimeout(() => {
      if (dismissedSpeechRef.current || greetingShownRef.current) return;
      greetingShownRef.current = true;
      setSpeech(localSpeech());
    }, 900);
    return () => clearTimeout(timer);
    // 只在进页时打招呼，避免 t() 身份变化把气泡反复拆掉
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname, activePetId, hasApiToken, giftCanClaim, lang]);

  useEffect(() => {
    if (!speech || dismissedSpeechRef.current) return;
    setSpeech(localSpeech());
    // 只在切语言时改正在显示的对白
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lang]);

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onStartShouldSetPanResponderCapture: () => true,
        onPanResponderGrant: () => {
          dragOriginRef.current = getEffectivePosition();
          activeDragActionRef.current = pickRandomPetAction(dragActionPool, behavior.dragAction);
          dragMovedRef.current = false;
          lastInteractionRef.current = Date.now();
        },
        onPanResponderMove: (_, gestureState) => {
          if (Math.abs(gestureState.dx) > 4 || Math.abs(gestureState.dy) > 4) {
            dragMovedRef.current = true;
            hasUserPositionedRef.current = true;
            setCurrentAction(activeDragActionRef.current);
            setSpeech(null);
          }
          updatePosition({
            x: dragOriginRef.current.x + gestureState.dx,
            y: dragOriginRef.current.y + gestureState.dy,
          });
        },
        onPanResponderRelease: (_, gestureState) => {
          if (dragMovedRef.current) {
            lastDragAtRef.current = Date.now();
            updatePosition({
              x: dragOriginRef.current.x + gestureState.dx,
              y: dragOriginRef.current.y + gestureState.dy,
            });
            playTemporaryAction(behavior.dragEndAction);
            return;
          }
          void handlePressRef.current();
        },
        onPanResponderTerminate: () => {
          lastDragAtRef.current = Date.now();
          playTemporaryAction(behavior.dragEndAction);
        },
      }),
    [behavior.dragAction, behavior.dragEndAction, dragActionPool, getEffectivePosition, updatePosition],
  );

  const webPointerHandlers = useMemo(() => {
    if (Platform.OS !== "web") return {};
    const finishPointerDrag = (event: unknown) => {
      const pointerEvent = getWebPointerEvent(event);
      const activeDrag = webDragRef.current;
      if (!activeDrag || activeDrag.pointerId !== pointerEvent.pointerId) return;
      getWebPointerCaptureTarget(event)?.releasePointerCapture?.(activeDrag.pointerId);
      webDragRef.current = null;
      if (dragMovedRef.current) {
        lastDragAtRef.current = Date.now();
        playTemporaryAction(behavior.dragEndAction);
        return;
      }
      void handlePressRef.current();
    };
    return {
      draggable: false,
      onPointerCancel: finishPointerDrag,
      onPointerDown: (event: unknown) => {
        const pointerEvent = getWebPointerEvent(event);
        if (typeof pointerEvent.button === "number" && pointerEvent.button !== 0) return;
        const point = getWebPointerPoint(pointerEvent);
        pointerEvent.preventDefault?.();
        pointerEvent.stopPropagation?.();
        getWebPointerCaptureTarget(event)?.setPointerCapture?.(pointerEvent.pointerId ?? 1);
        webDragRef.current = {
          origin: getEffectivePosition(),
          pointerId: pointerEvent.pointerId ?? 1,
          startX: point.x,
          startY: point.y,
        };
        dragMovedRef.current = false;
        activeDragActionRef.current = pickRandomPetAction(dragActionPool, behavior.dragAction);
        lastInteractionRef.current = Date.now();
      },
      onPointerMove: (event: unknown) => {
        const pointerEvent = getWebPointerEvent(event);
        const activeDrag = webDragRef.current;
        if (!activeDrag || activeDrag.pointerId !== pointerEvent.pointerId) return;
        const point = getWebPointerPoint(pointerEvent);
        const dx = point.x - activeDrag.startX;
        const dy = point.y - activeDrag.startY;
        if (Math.abs(dx) > 4 || Math.abs(dy) > 4) {
          dragMovedRef.current = true;
          hasUserPositionedRef.current = true;
          setCurrentAction(activeDragActionRef.current);
          setSpeech(null);
        }
        pointerEvent.preventDefault?.();
        updatePosition({ x: activeDrag.origin.x + dx, y: activeDrag.origin.y + dy });
      },
      onPointerUp: finishPointerDrag,
    };
  }, [behavior.dragAction, behavior.dragEndAction, dragActionPool, getEffectivePosition, updatePosition]);

  const speechPositionStyle: ViewStyle = usesAnchoredDefault
    ? styles.speechDefaultAnchor
    : {
        left: Math.max(PET_MARGIN, Math.min(width - BUBBLE_WIDTH - PET_MARGIN, position.x + PET_HIT_SIZE - BUBBLE_WIDTH)),
        top: Math.max(PET_MARGIN, position.y - 108),
      };

  if (shouldHideDeskPet(pathname || "")) return null;

  return (
    <View pointerEvents="box-none" style={styles.overlayRoot}>
      {speech ? (
        <View style={[styles.speechBubble, speechPositionStyle]}>
          <View style={styles.speechHeader}>
            <Text numberOfLines={1} style={styles.speechTitle}>
              {speech.title}
            </Text>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={t("petDeck.speech.closeDialogue")}
              hitSlop={6}
              onPress={closeSpeech}
              style={({ pressed }) => [styles.speechClose, pressed && styles.speechClosePressed]}
            >
              <Text style={styles.speechCloseText}>×</Text>
            </Pressable>
          </View>
          <Text numberOfLines={2} style={styles.speechMessage}>
            {speech.message}
          </Text>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={speech.ctaLabel}
            onPress={handleSpeechCta}
            style={({ pressed }) => [styles.speechCta, pressed && styles.speechCtaPressed]}
          >
            <Text style={styles.speechCtaText}>{speech.ctaLabel}</Text>
          </Pressable>
        </View>
      ) : null}
      <View
        {...(Platform.OS === "web" ? {} : panResponder.panHandlers)}
        {...webPointerHandlers}
        accessibilityRole="button"
        accessibilityLabel="Desk pet"
        style={[styles.petButton, petPositionStyle]}
      >
        <View pointerEvents="none" style={styles.petVisual}>
          <PixelDeskPetSprite
            animation={currentAction}
            petId={activePetId}
            size={PET_SIZE}
            style={shouldFacePage ? styles.facePage : null}
          />
          {hasApiToken && giftCanClaim ? <View style={styles.giftBadge} /> : null}
          {giftToast ? (
            <View style={styles.giftToast}>
              <Text style={styles.giftToastText}>{giftToast}</Text>
            </View>
          ) : null}
        </View>
      </View>
    </View>
  );
}

function getDefaultPetPosition(width: number, height: number): PetPosition {
  return clampPetPosition({ x: width - PET_HIT_SIZE - PET_RIGHT, y: height - PET_HIT_SIZE - PET_BOTTOM }, width, height);
}

function clampPetPosition(position: PetPosition, width: number, height: number): PetPosition {
  return {
    x: Math.max(PET_MARGIN, Math.min(width - PET_HIT_SIZE - PET_MARGIN, position.x)),
    y: Math.max(PET_MARGIN, Math.min(height - PET_HIT_SIZE - PET_MARGIN, position.y)),
  };
}

function getWebPointerEvent(event: unknown): WebPointerLikeEvent {
  const eventLike = event as WebPointerLikeEvent;
  return eventLike.nativeEvent ?? eventLike;
}

function getWebPointerCaptureTarget(event: unknown): WebPointerCaptureTarget | undefined {
  const eventLike = event as { currentTarget?: unknown; nativeEvent?: { currentTarget?: unknown; target?: unknown } };
  const target = eventLike.currentTarget ?? eventLike.nativeEvent?.currentTarget ?? eventLike.nativeEvent?.target;
  return target as WebPointerCaptureTarget | undefined;
}

function getWebPointerPoint(event: WebPointerLikeEvent) {
  return { x: event.clientX ?? event.pageX ?? 0, y: event.clientY ?? event.pageY ?? 0 };
}

function getWebViewportSize(fallbackWidth: number, fallbackHeight: number) {
  if (Platform.OS !== "web" || typeof window === "undefined") {
    return { width: fallbackWidth, height: fallbackHeight };
  }
  const documentElement = window.document?.documentElement;
  const visualViewport = window.visualViewport;
  return {
    width: visualViewport?.width || window.innerWidth || documentElement?.clientWidth || fallbackWidth,
    height: visualViewport?.height || window.innerHeight || documentElement?.clientHeight || fallbackHeight,
  };
}

const styles = StyleSheet.create({
  overlayRoot: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 64,
    elevation: 64,
    ...(Platform.OS === "web" ? ({ position: "fixed" } as unknown as ViewStyle) : null),
  },
  giftBadge: {
    position: "absolute",
    top: 2,
    right: 2,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: "#ff4d4f",
    borderWidth: 2,
    borderColor: "#ffffff",
  },
  giftToast: {
    position: "absolute",
    left: -8,
    right: -8,
    bottom: -6,
    alignItems: "center",
  },
  giftToastText: {
    backgroundColor: "rgba(20,20,20,0.88)",
    color: "#fff7e8",
    fontSize: 11,
    fontWeight: "700",
    overflow: "hidden",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
  },
  petButton: {
    position: "absolute",
    width: PET_HIT_SIZE,
    height: PET_HIT_SIZE,
    alignItems: "center",
    justifyContent: "center",
    overflow: "visible",
    backgroundColor: "transparent",
    ...({
      cursor: "pointer",
      touchAction: "none",
      userSelect: "none",
    } as ViewStyle),
  },
  petButtonDefaultAnchor: {
    right: PET_RIGHT,
    bottom: PET_BOTTOM,
  },
  speechBubble: {
    position: "absolute",
    width: BUBBLE_WIDTH,
    gap: 2,
    borderWidth: 1,
    borderColor: "rgba(15, 118, 110, 0.18)",
    borderRadius: 12,
    backgroundColor: "#ffffff",
    paddingHorizontal: 8,
    paddingTop: 6,
    paddingBottom: 7,
    shadowColor: "#0f172a",
    shadowOpacity: 0.1,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  speechDefaultAnchor: {
    right: 8,
    bottom: PET_BOTTOM + PET_HIT_SIZE + 4,
  },
  speechHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 4,
  },
  speechClose: {
    width: 16,
    height: 16,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 999,
    backgroundColor: "#F3F4F6",
  },
  speechClosePressed: {
    opacity: 0.75,
  },
  speechCloseText: {
    color: "#6B7280",
    fontSize: 11,
    fontWeight: "900",
    lineHeight: 12,
  },
  speechTitle: {
    flex: 1,
    color: "#111827",
    fontSize: 12,
    fontWeight: "800",
    lineHeight: 16,
  },
  speechMessage: {
    color: "#4B5563",
    fontSize: 11,
    lineHeight: 15,
  },
  speechCta: {
    alignSelf: "flex-start",
    backgroundColor: "#0F766E",
    borderRadius: 999,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  speechCtaPressed: {
    opacity: 0.85,
  },
  speechCtaText: {
    color: "#ffffff",
    fontSize: 11,
    fontWeight: "800",
  },
  petVisual: {
    alignItems: "center",
    justifyContent: "center",
    transform: [{ scale: PET_VISUAL_SCALE }],
  },
  facePage: {
    transform: [{ scaleX: -1 }],
  },
});
