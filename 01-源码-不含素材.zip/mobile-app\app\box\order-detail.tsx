/**
 * 盲盒订单详情 - Order detail with pay/check + payment countdown
 */
import React, { useEffect, useState } from "react";
import {
  Pressable,
  ScrollView,
  Text,
  View,
  ActivityIndicator,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import {
  MapPin,
  CreditCard,
  Timer,
  Wallet,
  Truck,
  Package,
} from "lucide-react-native";
import {
  BoxHeader,
  RarityBadge,
  BoxActionButton,
  BoxEmptyState,
  BoxProgressBar,
  BoxTabBar,
  CountdownTimer,
} from "@/components/box";
import {
  BoxSurfaces,
  BoxAccent,
  BoxText,
  BoxBorders,
  BoxGradients,
  BoxTypography,
  BoxSpacing,
  BoxRadius,
  BoxShadows,
  getRarityTier,
  bs,
} from "@/lib/boxTheme";
import { useSendOrderDetail, useBoxOrderPay, useSendPay } from "@/hooks";

const ORDER_EXPIRE_SECONDS = 30 * 60;

function parseTimestamp(raw: string | number | undefined): number {
  if (!raw) return 0;
  if (typeof raw === "number") return raw > 1e12 ? raw : raw * 1000;
  const ms = new Date(raw).getTime();
  return isNaN(ms) ? 0 : ms;
}

function mapOrderStatus(status: number) {
  switch (status) {
    case 0:
      return { label: "Pending Payment", color: BoxAccent.gold };
    case 1:
      return { label: "Pending Shipment", color: BoxAccent.blue };
    case 2:
      return { label: "Shipped", color: BoxAccent.purple };
    case 3:
      return { label: "Completed", color: BoxAccent.green };
    case -1:
      return { label: "Cancelled", color: BoxText.tertiary };
    default:
      return { label: "Unknown", color: BoxText.tertiary };
  }
}

function PaymentCountdown({ addTime }: { addTime: string | number }) {
  const [remaining, setRemaining] = useState(0);

  useEffect(() => {
    const createdMs = parseTimestamp(addTime);
    if (!createdMs) return;
    const expireMs = createdMs + ORDER_EXPIRE_SECONDS * 1000;

    const tick = () => Math.max(0, expireMs - Date.now());
    setRemaining(tick());

    const timer = setInterval(() => {
      const left = tick();
      setRemaining(left);
      if (left <= 0) clearInterval(timer);
    }, 1000);
    return () => clearInterval(timer);
  }, [addTime]);

  if (remaining <= 0) return null;

  const mins = Math.floor(remaining / 60000);
  const secs = Math.floor((remaining % 60000) / 1000);

  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center",
        gap: BoxSpacing.sm,
        marginTop: BoxSpacing.sm,
      }}
    >
      <Timer size={bs(16)} color={BoxAccent.gold} />
      <Text style={[BoxTypography.bodyBold, { color: BoxAccent.gold }]}>
        Expires in {mins}:{secs.toString().padStart(2, "0")}
      </Text>
    </View>
  );
}

export default function BoxOrderDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const orderId = Number(id) || 0;

  const { data: order, isLoading } = useSendOrderDetail(orderId);
  const payMutation = useBoxOrderPay();
  const sendPayMutation = useSendPay();

  const status = mapOrderStatus(order?.status ?? order?.pay_status ?? 0);
  const products =
    order?.products ||
    (order?.product_json ? JSON.parse(order.product_json) : []);
  const isPending = (order?.status ?? order?.pay_status) === 0;

  const handlePay = async () => {
    try {
      await payMutation.mutateAsync({ id: orderId, payType: "yue" });
    } catch {}
  };

  const handlePayShipping = async () => {
    try {
      await sendPayMutation.mutateAsync({ id: orderId, payType: "yue" });
    } catch {}
  };

  if (isLoading) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: BoxSurfaces.void,
        }}
      >
        <ActivityIndicator size="large" color={BoxAccent.gold} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title="Order Details" showThemeToggle={false} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View
          style={{
            padding: BoxSpacing.lg,
            paddingBottom: bs(96),
          }}
        >
          {/* Status Card */}
          <LinearGradient
            colors={[`${status.color}18`, `${status.color}08`]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{
              borderRadius: BoxRadius.xl,
              padding: BoxSpacing.xl,
              marginBottom: BoxSpacing.lg,
              alignItems: "center",
              borderWidth: 1,
              borderColor: `${status.color}30`,
            }}
          >
            <Text
              style={[BoxTypography.h1, { color: status.color }]}
            >
              {status.label}
            </Text>
            <Text
              style={[
                BoxTypography.caption,
                { color: BoxText.tertiary, marginTop: BoxSpacing.xs },
              ]}
            >
              Order #: {order?.order_id || order?.unique || orderId}
            </Text>
            {isPending && (
              <PaymentCountdown
                addTime={order?.add_time || order?.createtime || ""}
              />
            )}
          </LinearGradient>

          {/* Address */}
          {order?.real_name && (
            <View
              style={{
                borderRadius: BoxRadius.xl,
                padding: BoxSpacing.lg,
                marginBottom: BoxSpacing.lg,
                flexDirection: "row",
                alignItems: "flex-start",
                gap: BoxSpacing.md,
                backgroundColor: BoxSurfaces.card,
                borderWidth: 1,
                borderColor: BoxBorders.default,
              }}
            >
              <View
                style={{
                  width: bs(36),
                  height: bs(36),
                  borderRadius: BoxRadius.md,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: BoxAccent.goldDim,
                }}
              >
                <MapPin size={bs(18)} color={BoxAccent.gold} />
              </View>
              <View style={{ flex: 1 }}>
                <Text
                  style={[BoxTypography.bodyBold, { color: BoxText.primary }]}
                >
                  {order.real_name} {order.user_phone}
                </Text>
                <Text
                  style={[
                    BoxTypography.caption,
                    { color: BoxText.tertiary, marginTop: BoxSpacing.xs },
                  ]}
                >
                  {order.user_address}
                </Text>
              </View>
            </View>
          )}

          {/* Products */}
          <View
            style={{
              borderRadius: BoxRadius.xl,
              marginBottom: BoxSpacing.lg,
              overflow: "hidden",
              backgroundColor: BoxSurfaces.card,
              borderWidth: 1,
              borderColor: BoxBorders.default,
            }}
          >
            <View
              style={{
                padding: BoxSpacing.lg,
                borderBottomWidth: 1,
                borderBottomColor: BoxBorders.subtle,
              }}
            >
              <Text
                style={[BoxTypography.h3, { color: BoxText.primary }]}
              >
                Products
              </Text>
            </View>
            {Array.isArray(products) &&
              products.map((p: any, idx: number) => (
                <View
                  key={idx}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: BoxSpacing.md,
                    padding: BoxSpacing.lg,
                    borderBottomWidth: 1,
                    borderBottomColor: BoxBorders.subtle,
                  }}
                >
                  <View
                    style={{
                      width: bs(56),
                      height: bs(56),
                      borderRadius: BoxRadius.lg,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: BoxSurfaces.deep,
                    }}
                  >
                    {p.image && /^https?:\/\//.test(p.image) ? (
                      <Image
                        source={{ uri: p.image }}
                        style={{
                          width: bs(48),
                          height: bs(48),
                          borderRadius: BoxRadius.md,
                        }}
                        contentFit="cover"
                      />
                    ) : (
                      <Package size={bs(24)} color={BoxAccent.gold} strokeWidth={1.6} />
                    )}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={[
                        BoxTypography.bodyBold,
                        { color: BoxText.primary },
                      ]}
                    >
                      {p.name || p.store_name || "Mystery Box Item"}
                    </Text>
                    <Text
                      style={[
                        BoxTypography.caption,
                        {
                          color: BoxText.tertiary,
                          marginTop: BoxSpacing.xs,
                        },
                      ]}
                    >
                      x{p.num || 1}
                    </Text>
                  </View>
                  <Text
                    style={[BoxTypography.bodyBold, { color: BoxAccent.gold }]}
                  >
                    ¥{p.freight_price || p.price || 0}
                  </Text>
                </View>
              ))}
          </View>

          {/* Payment Info */}
          <View
            style={{
              borderRadius: BoxRadius.xl,
              padding: BoxSpacing.lg,
              marginBottom: BoxSpacing.lg,
              backgroundColor: BoxSurfaces.card,
              borderWidth: 1,
              borderColor: BoxBorders.default,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: BoxSpacing.sm,
                marginBottom: BoxSpacing.md,
              }}
            >
              <View
                style={{
                  width: bs(32),
                  height: bs(32),
                  borderRadius: BoxRadius.sm,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: BoxAccent.goldDim,
                }}
              >
                <CreditCard size={bs(16)} color={BoxAccent.gold} />
              </View>
              <Text
                style={[BoxTypography.h3, { color: BoxText.primary }]}
              >
                Payment Info
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginBottom: BoxSpacing.sm,
              }}
            >
              <Text
                style={[BoxTypography.body, { color: BoxText.secondary }]}
              >
                Subtotal
              </Text>
              <Text style={[BoxTypography.body, { color: BoxText.primary }]}>
                ¥{order?.total_price || 0}
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                marginBottom: BoxSpacing.sm,
              }}
            >
              <Text
                style={[BoxTypography.body, { color: BoxText.secondary }]}
              >
                Shipping
              </Text>
              <Text style={[BoxTypography.body, { color: BoxText.primary }]}>
                ¥{order?.pay_postage || 0}
              </Text>
            </View>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                paddingTop: BoxSpacing.sm,
                borderTopWidth: 1,
                borderTopColor: BoxBorders.subtle,
              }}
            >
              <Text
                style={[BoxTypography.bodyBold, { color: BoxText.primary }]}
              >
                Total Paid
              </Text>
              <Text style={[BoxTypography.priceHero, { color: BoxAccent.gold }]}>
                ¥{order?.pay_price || 0}
              </Text>
            </View>
          </View>

          {/* Actions */}
          {isPending && (
            <BoxActionButton
              title="Pay Now"
              variant="primary"
              icon={<Wallet size={bs(18)} color={BoxText.onGold} />}
              loading={payMutation.isPending}
              onPress={handlePay}
              style={{ marginBottom: BoxSpacing.md }}
            />
          )}
          {order?.status === 1 && !order?.pay_postage_status && (
            <BoxActionButton
              title="Pay Shipping"
              variant="secondary"
              icon={<Truck size={bs(18)} color={BoxText.primary} />}
              loading={sendPayMutation.isPending}
              onPress={handlePayShipping}
              style={{ marginBottom: BoxSpacing.md }}
            />
          )}
        </View>
      </ScrollView>
    </View>
  );
}
