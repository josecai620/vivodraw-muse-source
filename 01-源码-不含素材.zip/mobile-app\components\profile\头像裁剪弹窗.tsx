import { Colors } from "@/constants/theme";
import {
  AVATAR_CROP_MAX_SCALE,
  AVATAR_CROP_MIN_SCALE,
  clampPan,
  clampScale,
  coverScale,
  cropLayout,
  cropToJpegBlob,
  loadCropSource,
  type CropSource,
} from "@/lib/头像裁剪";
import type React from "react";
import { useEffect, useRef, useState } from "react";
import { ActivityIndicator, Modal, Platform, Pressable, Text, View } from "react-native";

type Props = {
  visible: boolean;
  file?: File | Blob | null;
  uri?: string | null;
  title: string;
  hint: string;
  cancelLabel: string;
  confirmLabel: string;
  onCancel: () => void;
  onConfirm: (blob: Blob) => void;
  onError?: (message: string) => void;
};

export default function 头像裁剪弹窗({
  visible,
  file,
  uri,
  title,
  hint,
  cancelLabel,
  confirmLabel,
  onCancel,
  onConfirm,
  onError,
}: Props) {
  const [crop, setCrop] = useState<CropSource | null>(null);
  const [scale, setScale] = useState(1);
  const [tx, setTx] = useState(0);
  const [ty, setTy] = useState(0);
  const [busy, setBusy] = useState(false);
  const [layout, setLayout] = useState(() => cropLayout());
  const onCancelRef = useRef(onCancel);
  onCancelRef.current = onCancel;
  const drag = useRef<{ x: number; y: number; tx: number; ty: number } | null>(null);
  const pinch = useRef<{ dist: number; scale: number } | null>(null);
  const pointers = useRef<Map<number, { x: number; y: number }>>(new Map());

  useEffect(() => {
    const sync = () => setLayout(cropLayout());
    sync();
    if (typeof window === "undefined") return;
    window.addEventListener("resize", sync);
    return () => window.removeEventListener("resize", sync);
  }, [visible]);

  useEffect(() => {
    if (!visible) {
      setCrop(null);
      setScale(1);
      setTx(0);
      setTy(0);
      setBusy(false);
      return;
    }
    const input = file ?? uri;
    if (!input) return;
    let cancelled = false;
    loadCropSource(input)
      .then((loaded) => {
        if (cancelled) return;
        setCrop(loaded);
        setScale(1);
        setTx(0);
        setTy(0);
      })
      .catch(() => {
        if (!cancelled) {
          onError?.("图片打不开，换一张再试");
          onCancelRef.current();
        }
      });
    return () => {
      cancelled = true;
    };
  }, [visible, file, uri, onError]);

  const applyPan = (nextX: number, nextY: number, nextScale = scale) => {
    if (!crop) return;
    const clamped = clampPan(nextX, nextY, nextScale, crop.width, crop.height, layout.view, layout.hole);
    setTx(clamped.tx);
    setTy(clamped.ty);
  };

  const applyScale = (next: number) => {
    if (!crop) return;
    const s = clampScale(next);
    setScale(s);
    applyPan(tx, ty, s);
  };

  const handleConfirm = async () => {
    if (!crop || busy) return;
    setBusy(true);
    try {
      const blob = await cropToJpegBlob(
        crop.source,
        crop.width,
        crop.height,
        scale,
        tx,
        ty,
        layout.view,
        layout.hole,
      );
      onConfirm(blob);
    } catch {
      setBusy(false);
      onError?.("保存失败，请再试一次");
    }
  };

  if (Platform.OS !== "web") {
    return null;
  }

  const cover = crop ? coverScale(crop.width, crop.height, layout.hole) : 1;
  const drawW = crop ? crop.width * cover * scale : 0;
  const drawH = crop ? crop.height * cover * scale : 0;
  const holePad = (layout.view - layout.hole) / 2;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <View style={{ flex: 1, backgroundColor: "rgba(8,10,12,0.94)", justifyContent: "space-between" }}>
        <Text style={{ color: "#fff", textAlign: "center", fontWeight: "800", fontSize: 16, marginTop: 28 }}>
          {title}
        </Text>
        <View style={{ alignItems: "center" }}>
          <View nativeID="avatar-crop-surface">
            <div
              onWheel={(event: React.WheelEvent<HTMLDivElement>) => {
                event.preventDefault();
                applyScale(scale + (event.deltaY < 0 ? 0.12 : -0.12));
              }}
              onPointerDown={(event: React.PointerEvent<HTMLDivElement>) => {
                event.currentTarget.setPointerCapture?.(event.pointerId);
                pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
                if (pointers.current.size === 2) {
                  const pts = [...pointers.current.values()];
                  const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
                  pinch.current = { dist, scale };
                  drag.current = null;
                } else {
                  drag.current = { x: event.clientX, y: event.clientY, tx, ty };
                }
              }}
              onPointerMove={(event: React.PointerEvent<HTMLDivElement>) => {
                if (!pointers.current.has(event.pointerId)) return;
                pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
                if (pointers.current.size === 2 && pinch.current) {
                  const pts = [...pointers.current.values()];
                  const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
                  applyScale(pinch.current.scale * (dist / Math.max(1, pinch.current.dist)));
                  return;
                }
                if (!drag.current) return;
                applyPan(drag.current.tx + (event.clientX - drag.current.x), drag.current.ty + (event.clientY - drag.current.y));
              }}
              onPointerUp={(event: React.PointerEvent<HTMLDivElement>) => {
                pointers.current.delete(event.pointerId);
                if (pointers.current.size < 2) pinch.current = null;
                if (pointers.current.size === 0) drag.current = null;
              }}
              style={{
                width: layout.view,
                height: layout.view,
                overflow: "hidden",
                backgroundColor: "#111",
                position: "relative",
                touchAction: "none",
                cursor: "grab",
                userSelect: "none",
              }}
            >
            {crop ? (
              <img
                src={crop.displayUrl}
                alt=""
                draggable={false}
                style={{
                  position: "absolute",
                  width: drawW,
                  height: drawH,
                  left: layout.view / 2 + tx - drawW / 2,
                  top: layout.view / 2 + ty - drawH / 2,
                  pointerEvents: "none",
                }}
              />
            ) : (
              <ActivityIndicator color="#fff" style={{ marginTop: layout.view / 2 - 12 }} />
            )}
            <div
              style={{
                position: "absolute",
                left: holePad,
                top: holePad,
                width: layout.hole,
                height: layout.hole,
                borderRadius: layout.hole / 2,
                border: "2px solid rgba(255,255,255,0.92)",
                boxShadow: "0 0 0 9999px rgba(0,0,0,0.55)",
                pointerEvents: "none",
              }}
            />
            </div>
          </View>
          <Text style={{ color: "rgba(255,255,255,0.72)", marginTop: 16, fontSize: 12, textAlign: "center", paddingHorizontal: 24 }}>
            {hint}
          </Text>
          <View style={{ width: layout.view, marginTop: 18, flexDirection: "row", alignItems: "center", gap: 10 }}>
            <Pressable onPress={() => applyScale(scale - 0.2)} hitSlop={12}>
              <Text style={{ color: "#fff", fontSize: 22, fontWeight: "700" }}>−</Text>
            </Pressable>
            <input
              type="range"
              min={AVATAR_CROP_MIN_SCALE}
              max={AVATAR_CROP_MAX_SCALE}
              step={0.01}
              value={scale}
              onChange={(event: React.ChangeEvent<HTMLInputElement>) => applyScale(Number(event.target.value))}
              style={{ flex: 1, accentColor: Colors.brand.red }}
            />
            <Pressable onPress={() => applyScale(scale + 0.2)} hitSlop={12}>
              <Text style={{ color: "#fff", fontSize: 22, fontWeight: "700" }}>＋</Text>
            </Pressable>
          </View>
        </View>
        <View style={{ flexDirection: "row", padding: 16, paddingBottom: 28, gap: 12 }}>
          <Pressable
            onPress={onCancel}
            style={{ flex: 1, height: 46, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.12)" }}
          >
            <Text style={{ color: "#fff", fontWeight: "700" }}>{cancelLabel}</Text>
          </Pressable>
          <Pressable
            onPress={handleConfirm}
            disabled={!crop || busy}
            style={{ flex: 1, height: 46, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: Colors.brand.red, opacity: !crop || busy ? 0.6 : 1 }}
          >
            {busy ? <ActivityIndicator color="#fff" /> : <Text style={{ color: "#fff", fontWeight: "800" }}>{confirmLabel}</Text>}
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}
