declare module "*.svga" {
  const src: number;
  export default src;
}

declare module "svgaplayerweb" {
  export class Parser {
    load(url: string, success: (videoItem: unknown) => void, failure?: (err: Error) => void): void;
  }
  export class Player {
    loops: number;
    clearsAfterStop: boolean;
    setContentMode(mode: "Fill" | "AspectFill" | "AspectFit"): void;
    setClipsToBounds(v: boolean): void;
    setVideoItem(item: unknown): void;
    startAnimation(): void;
    stopAnimation(clear?: boolean): void;
  }
}

declare module "@/lib/vendor/svgaplayerweb" {
  const SVGA: {
    Parser: new () => {
      load(url: string, success: (videoItem: unknown) => void, failure?: (err: Error) => void): void;
    };
    Player: new (el: HTMLDivElement | HTMLCanvasElement | string) => {
      loops: number;
      clearsAfterStop: boolean;
      setContentMode(mode: "Fill" | "AspectFill" | "AspectFit"): void;
      setClipsToBounds(v: boolean): void;
      setVideoItem(item: unknown): void;
      startAnimation(): void;
      stopAnimation(clear?: boolean): void;
    };
  };
  export = SVGA;
}
