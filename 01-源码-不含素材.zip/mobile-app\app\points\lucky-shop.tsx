import React, { useMemo } from "react";
import { Image, Pressable, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { Colors } from "@/constants/theme";
import { useAuthStore } from "@/store/auth";
import { formatNumber, normalizeImageUrl } from "@/lib/utils";
import { unwrapApiData } from "@/lib/api/response";
import { useLuckyRedeem, useLuckyShop } from "@/hooks";

const TEAL = Colors.primary.DEFAULT;

export default function LuckyShopScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const user = useAuthStore((s) => s.user);
  const lucky = Number(user?.lucky_num ?? 0);
  const { data } = useLuckyShop();
  const redeem = useLuckyRedeem();
  const payload = unwrapApiData<Record<string, unknown>>(data, {});
  const list = useMemo(() => {
    const rows = Array.isArray(payload.list) ? payload.list : [];
    return rows.map((row: any) => ({
      id: Number(row.id ?? 0),
      name: String(row.name ?? ""),
      image: normalizeImageUrl(String(row.image ?? "")),
      luckyCost: Number(row.luckyCost ?? 0),
    })).filter((row: { id: number }) => row.id > 0);
  }, [payload]);

  const onRedeem = (productId: number) => {
    if (!isLoggedIn) {
      router.push("/auth" as never);
      return;
    }
    redeem.mutate({ product_id: productId });
  };

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader
        title={t("pointsMall.luckyShop")}
        onBackPress={() => router.replace("/points" as never)}
        style={{ zIndex: 40, elevation: 8 }}
      />
      <ScrollView contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 16 }}>
        <View className="mx-3 mt-3 rounded-2xl p-4 bg-white" style={{ borderWidth: 1, borderColor: Colors.screen.hairline }}>
          <Text className="text-xs text-gray-500">{t("pointsMall.luckyValue")}</Text>
          <Text className="text-[32px] font-black mt-1" style={{ color: TEAL }}>
            {formatNumber(lucky)}
          </Text>
          <Text className="text-xs text-gray-500 mt-2 leading-5">{t("pointsMall.luckyShopHint")}</Text>
          <Pressable className="mt-2 self-start" onPress={() => router.push("/reveal/rules" as never)}>
            <Text className="text-xs font-bold" style={{ color: TEAL }}>{t("pointsMall.rules")}</Text>
          </Pressable>
        </View>
        {list.length === 0 ? (
          <Text className="text-center text-gray-400 py-16">{t("pointsMall.luckyShopEmpty")}</Text>
        ) : (
          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              paddingHorizontal: 4,
              paddingTop: 8,
            }}
          >
            {list.map((item: { id: number; name: string; image: string; luckyCost: number }) => {
              const can = lucky >= item.luckyCost;
              return (
                <View
                  key={item.id}
                  style={{
                    width: "50%",
                    paddingHorizontal: 4,
                    paddingBottom: 8,
                  }}
                >
                <View
                  style={{
                    width: "100%",
                    borderRadius: 8,
                    backgroundColor: "#fff",
                    overflow: "hidden",
                    borderWidth: 1,
                    borderColor: Colors.screen.hairline,
                    paddingBottom: 8,
                  }}
                >
                  <View style={{ width: "100%", aspectRatio: 1, backgroundColor: "#F8FAFA", overflow: "hidden" }}>
                    {item.image ? (
                      <Image
                        source={{ uri: item.image }}
                        style={{ width: "100%", height: "100%" }}
                        resizeMode="contain"
                      />
                    ) : null}
                  </View>
                  <Text className="px-2 mt-1.5 text-[12px] text-gray-900" numberOfLines={2}>
                    {item.name}
                  </Text>
                  <Text className="px-2 mt-1.5 text-[13px] font-black" style={{ color: TEAL }} numberOfLines={1}>
                    {t("pointsMall.luckyCost", { n: item.luckyCost })}
                  </Text>
                  <Pressable
                    className="mx-2 mt-2 h-8 rounded items-center justify-center"
                    style={{ backgroundColor: can ? TEAL : "#C8C8C8" }}
                    disabled={!can || redeem.isPending}
                    onPress={() => onRedeem(item.id)}
                  >
                    <Text className="text-white text-[11px] font-bold">{t("pointsMall.luckyRedeemNow")}</Text>
                  </Pressable>
                </View>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
