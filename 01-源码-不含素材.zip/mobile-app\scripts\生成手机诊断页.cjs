/* 只生成独立诊断页，不改首页或构建入口，不自动发布。 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
function generate(snapshot, output, release) {
  if (!/^\d{8}_\d{6}$/.test(release)) throw new Error('必须指定已核对的生产版本');
  const html = fs.readFileSync(path.join(snapshot, 'index.html'), 'utf8');
  const urls = [...html.matchAll(/<script\b[^>]*\bsrc=["']([^"']+)["'][^>]*>/gi)].map(match => match[1]).filter(url => url.startsWith('/_expo/static/js/web/'));
  if (urls.length !== 6 || new Set(urls).size !== 6) throw new Error('预期恰好6个首页核心脚本');
  const scripts = urls.map((url, index) => {
    if (!/^\/_expo\/static\/js\/web\/[a-zA-Z0-9_.\[\]-]+\.js(?:\?v=[a-f0-9_]+)?$/.test(url)) throw new Error('拒绝不安全的脚本地址');
    const file = url.split('?')[0].slice(1);
    const bytes = fs.readFileSync(path.join(snapshot, file));
    const label = /__common-/.test(file) ? '公共脚本（最大文件）' : /entry-/.test(file) ? '入口脚本' : /__expo-metro-runtime-/.test(file) ? '基础运行库' : /\/index-/.test(file) ? '首页模块' : '布局模块 ' + (index + 1);
    return { label, url, bytes: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex') };
  });
  const template = fs.readFileSync(path.join(__dirname, '../diagnostics/手机访问检测.html'), 'utf8');
  if (template.split('__VIVO_DIAGNOSTIC_MANIFEST__').length !== 2) throw new Error('模板占位符不唯一');
  const rendered = template.replace('__VIVO_DIAGNOSTIC_MANIFEST__', JSON.stringify({ release, scripts }).replace(/</g, '\\u003c'));
  fs.mkdirSync(path.dirname(output), { recursive: true });
  if (fs.existsSync(output)) throw new Error('拒绝覆盖既有产物，请指定新路径');
  fs.writeFileSync(output, rendered);
  return { output, bytes: Buffer.byteLength(rendered), scripts: scripts.length };
}
module.exports = { generate };
if (require.main === module) console.log(JSON.stringify(generate(...process.argv.slice(2))));
