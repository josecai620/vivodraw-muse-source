import React, { useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Check, CheckCircle2, Clock, Gift, Globe, LinkIcon, TrendingUp } from "lucide-react-native";
import { useTranslation } from "react-i18next";
import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import PageHeader from "@/components/shared/PageHeader";

type AgentStatus = "none" | "pending" | "approved";

export default function CommissionApplyScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const showToast = useAppStore((x) => x.showToast);
  const user = useAuthStore((x) => x.user);
  const [agreed, setAgreed] = useState(false);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ["agentInfo"],
    queryFn: () => http.get(API_ENDPOINTS.commission.agentInfo),
  });

  const raw = (data as any)?.data ?? data ?? {};
  const status: AgentStatus =
    raw?.is_agent === 1 || raw?.is_promoter === 1
      ? "approved"
      : raw?.is_agent === 2 || raw?.status === "pending"
        ? "pending"
        : "none";

  const applyMutation = useMutation({
    mutationFn: () => http.post(API_ENDPOINTS.commission.apply, {}),
    onSuccess: (res: any) => {
      const raw = res?.data ?? res;
      const approved = raw?.is_promoter === 1 || raw?.status === "approved";
      showToast(
        approved ? t("commission.apply.alreadyAffiliate") : t("commission.apply.pending"),
        "success",
      );
      refetch();
      if (approved) {
        setTimeout(() => router.replace("/profile/commission/promote"), 800);
      }
    },
    onError: (err: any) => {
      showToast(err?.message || t("common.failed"), "error");
    },
  });

  const handleSubmit = () => {
    if (!agreed) {
      showToast(t("commission.apply.mustAgree"), "error");
      return;
    }
    applyMutation.mutate();
  };

  const benefits = [
    { icon: Gift, text: t("commission.apply.benefit1") },
    { icon: LinkIcon, text: t("commission.apply.benefit2") },
    { icon: TrendingUp, text: t("commission.apply.benefit3") },
    { icon: Globe, text: t("commission.apply.benefit4") },
  ];

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("commission.apply.title")} />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView
          className="flex-1"
          contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
          showsVerticalScrollIndicator={false}
        >
          <View
            className="rounded-2xl p-6 mb-4"
            style={{ }}
          >
            <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 16, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
            <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 16 }} />
            <Text className="text-white text-2xl font-bold mb-2">
              {t("commission.apply.heroTitle")}
            </Text>
            <Text className="text-white/90 text-sm">
              {t("commission.apply.heroSub")}
            </Text>
          </View>

          <View className="bg-white rounded-2xl p-5 mb-4 border border-gray-100">
            <Text
              className="font-semibold mb-4"
              style={{ color: Colors.neutral[800], fontSize: s(16) }}
            >
              {t("commission.apply.benefitsTitle")}
            </Text>
            {benefits.map((b, i) => (
              <View key={i} className="flex-row items-start mb-3">
                <View
                  className="w-8 h-8 rounded-lg items-center justify-center mr-3"
                  style={{ backgroundColor: `${Colors.brand.red}15` }}
                >
                  <b.icon size={s(16)} color={Colors.brand.red} />
                </View>
                <Text
                  className="flex-1 text-sm"
                  style={{ color: Colors.neutral[700], lineHeight: s(20) }}
                >
                  {b.text}
                </Text>
              </View>
            ))}
          </View>

          {status === "approved" ? (
            <View className="bg-white rounded-2xl p-6 items-center border border-gray-100">
              <CheckCircle2 size={s(48)} color="#04A8AE" />
              <Text
                className="font-semibold mt-3 mb-4"
                style={{ color: Colors.neutral[800], fontSize: s(16) }}
              >
                {t("commission.apply.alreadyAffiliate")}
              </Text>
              <Pressable
                onPress={() => router.replace("/profile/commission/promote")}
                style={{
                  paddingVertical: s(12),
                  paddingHorizontal: s(24),
                  borderRadius: s(12),
                  }}
              >
                <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
                <Text className="font-semibold text-white">
                  {t("commission.apply.goPromote")}
                </Text>
              </Pressable>
            </View>
          ) : status === "pending" ? (
            <View className="bg-white rounded-2xl p-6 items-center border border-gray-100">
              <Clock size={s(48)} color={Colors.accent.orange} />
              <Text
                className="font-semibold mt-3"
                style={{ color: Colors.neutral[800], fontSize: s(16) }}
              >
                {t("commission.apply.pending")}
              </Text>
              <Text
                className="text-sm mt-2 text-center"
                style={{ color: Colors.neutral[500] }}
              >
                {t("commission.apply.pendingDesc")}
              </Text>
            </View>
          ) : (
            <>
              <Pressable
                onPress={() => setAgreed((v) => !v)}
                className="flex-row items-center mb-4 px-1"
              >
                <View
                  className="w-5 h-5 rounded mr-2 items-center justify-center"
                  style={{
                    borderWidth: 1.5,
                    borderColor: agreed ? Colors.brand.red : Colors.neutral[400],
                    backgroundColor: agreed ? Colors.brand.red : "transparent",
                  }}
                >
                  {agreed && <Check size={s(14)} color="#fff" />}
                </View>
                <Text
                  className="flex-1 text-sm"
                  style={{ color: Colors.neutral[600] }}
                >
                  {t("commission.apply.agreeTerms")}
                </Text>
                <Pressable
                  onPress={(e) => {
                    e.stopPropagation?.();
                    router.push("/profile/commission/rules");
                  }}
                >
                  <Text
                    className="text-sm font-medium"
                    style={{ color: Colors.brand.red }}
                  >
                    {t("commission.rules")}
                  </Text>
                </Pressable>
              </Pressable>

              <Pressable
                onPress={handleSubmit}
                disabled={applyMutation.isPending}
                style={{
                  paddingVertical: 14,
                  borderRadius: 12,
                  backgroundColor: agreed ? "transparent" : Colors.neutral[300],
                  alignItems: "center",
                  shadowColor: "#04A8AE",
                  shadowOffset: { width: 0, height: 6 },
                  shadowOpacity: agreed ? 0.3 : 0,
                  shadowRadius: 12,
                  elevation: agreed ? 6 : 0,
                }}
              >
                {agreed && (
                  <>
                    <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
                    <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
                  </>
                )}
                {applyMutation.isPending ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text
                    className="font-semibold text-white"
                    style={{ fontSize: s(16) }}
                  >
                    {t("commission.apply.submit")}
                  </Text>
                )}
              </Pressable>
            </>
          )}

          {user?.uid && (
            <Text
              className="text-xs text-center mt-6"
              style={{ color: Colors.neutral[400] }}
            >
              UID: {user.uid}
            </Text>
          )}
        </ScrollView>
      )}
    </View>
  );
}
