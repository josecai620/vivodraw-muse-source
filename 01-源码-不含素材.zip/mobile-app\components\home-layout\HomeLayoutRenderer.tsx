// 自研首页装修渲染器 — 不依赖 CRMEB DIY
// 后端：GET /api/home_layout
// block 类型：banner / quick_grid / notice / group_lottery / points_balance / …

import React, { Fragment } from "react";
import { View } from "react-native";
import { useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import type { HomeLayoutBlock, HomeLayoutData } from "@/lib/api/home";
import HlBanner from "./HlBanner";
import HlQuickGrid from "./HlQuickGrid";
import HlNotice from "./HlNotice";
import HlCategoryNav from "./HlCategoryNav";
import HlProductList from "./HlProductList";
import HlSingleImage from "./HlSingleImage";
import HlRichText from "./HlRichText";
import HlSpacer from "./HlSpacer";
import HlCheckinCard from "./HlCheckinCard";
import HlBoxReveal from "./HlBoxReveal";
import HlCountdown from "./HlCountdown";
import HlLiveEntry from "./HlLiveEntry";
import HlGroupLottery from "./HlGroupLottery";
import HlPointsBalance from "./HlPointsBalance";
import { Colors } from "@/constants/theme";

export interface HomeLayoutRendererProps {
  layout: HomeLayoutData | null | undefined;
}

export default function HomeLayoutRenderer({ layout }: HomeLayoutRendererProps) {
  const router = useRouter();
  const { i18n } = useTranslation();
  const lang = i18n.language === "en" ? "en" : "zh";

  if (!layout || !Array.isArray(layout.blocks) || layout.blocks.length === 0) {
    return null;
  }

  const rawBg = layout.theme?.bg_color || "";
  const bg = !rawBg || rawBg.toUpperCase() === "#F9FAFB" ? Colors.home.background : rawBg;

  return (
    <View style={{ backgroundColor: bg }}>
      {layout.blocks.map((block) => {
        if (block.visible === false) return null;
        return (
          <Fragment key={block.id}>
            <BlockSwitch
              block={block}
              lang={lang}
              onLink={(link) => {
                if (link) router.push(link as any);
              }}
            />
          </Fragment>
        );
      })}
    </View>
  );
}

interface BlockSwitchProps {
  block: HomeLayoutBlock;
  lang: string;
  onLink: (link: string) => void;
}

function BlockSwitch({ block, lang, onLink }: BlockSwitchProps) {
  switch (block.type) {
    case "banner":
      return <HlBanner props={block.props} onLink={onLink} />;
    case "quick_grid":
      return <HlQuickGrid props={block.props} lang={lang} onLink={onLink} />;
    case "notice":
      return <HlNotice props={block.props} lang={lang} onLink={onLink} />;
    case "group_lottery":
      return <HlGroupLottery props={block.props} lang={lang} />;
    case "points_balance":
      return <HlPointsBalance props={block.props} lang={lang} />;
    case "category_nav":
      return <HlCategoryNav props={block.props} lang={lang} onLink={onLink} />;
    case "product_list":
      return <HlProductList props={block.props} lang={lang} />;
    case "single_image":
      return <HlSingleImage props={block.props} onLink={onLink} />;
    case "rich_text":
      return <HlRichText props={block.props} lang={lang} />;
    case "spacer":
      return <HlSpacer props={block.props} />;
    case "checkin_card":
      return <HlCheckinCard props={block.props} lang={lang} />;
    case "box_reveal":
      return <HlBoxReveal props={block.props} lang={lang} />;
    case "countdown":
      return <HlCountdown props={block.props} lang={lang} />;
    case "live_entry":
      return <HlLiveEntry props={block.props} lang={lang} />;
    default:
      return null;
  }
}
