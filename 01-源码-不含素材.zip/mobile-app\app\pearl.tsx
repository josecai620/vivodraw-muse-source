import { useCallback, useEffect, useRef, useState } from "react";
import { Stack, useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
import Head from "expo-router/head";
import { AccessibilityInfo, ActivityIndicator, Animated, AppState, Easing, Image, ImageBackground, Platform, ScrollView, StyleSheet, Text, View } from "react-native";

import { useAuthStore } from "@/store/auth";
import { getPearlRules, getPearlState, newPearlRequestId, openPearlShell, startPearlRound, pickPearlShell, buyPearlCharm, type PearlCharmId, type PearlKey, type PearlRound, type PearlRules, type PearlState } from "@/lib/api/pearl";
import { PearlGem, PearlStage } from "@/components/pearl/海底舞台";
import { OceanEffects } from "@/components/pearl/场景光效";
import { MotionProvider, MotionPressable as Pressable, RevealText } from "@/components/pearl/动效组件";
import { readPendingExploration, savePendingExploration, clearPendingExploration, pendingConfirmedByRound, type PendingExploration } from "@/lib/game/pearlPending";
import { generatePracticeBoard } from "@/components/pearl/试玩随机";
import { PearlLangContext, translatePearl } from "@/components/pearl/文案";
import { LagoonHeader, LagoonNavigation, LagoonQuest, TrimmedArt, ACTION_BOX, ACTION_ASPECT } from "@/components/pearl/寻珠界面";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const pearlNames: Record<PearlKey, string> = {
  sand: "Sand pearl", white: "Moon pearl", pink: "Rose pearl", gold: "Sun pearl",
  black: "Midnight pearl", aurora: "Aurora pearl", living: "Tideheart pearl",
};
const pearlKeys: PearlKey[] = ["sand", "white", "pink", "gold", "black", "aurora", "living"];
const charmNames: Record<PearlCharmId, string> = {
  star: "Dot", kelp: "Kelp", hermit: "Hermit", coral: "Coral", fan: "Sea fan", seahorse: "Seahorse", jelly: "Moonjelly",
};
const paidMessages: Record<string, string> = {
  "This exploration still needs confirmation. Retry the same exploration safely.": "這次探索仍待確認，請重試原探索；不會另扣一局。",
  "The exploration price changed. No coins were spent. Refresh to confirm the new price.": "探索價格已更新，本次未扣金幣。請刷新後確認新價格。",
  "Not enough game coins. Nothing was spent. Add coins before continuing.": "金幣不足，本次未扣款。可先補充金幣再回來。",
};
const background = Platform.OS === "web"
  ? require("../assets/海底寻珠/动态礁石/你的海.jpg")
  : require("../assets/海底寻珠/海底场景.png");
const modalAccentArt = require("../assets/海底寻珠/界面原画/珊瑚任务签-第二版.png");
const actionArt = require("../assets/海底寻珠/界面原画/海底寻珠-再试一次贝壳签.webp");
type Phase = "idle" | "submitting" | "selected" | "all";
type Panel = "play" | "collection" | "reef" | "rules";

function authoritativeComplete(value: PearlRound | null | undefined): value is PearlRound {
  if (!value || value.status !== "complete" || !Number.isSafeInteger(value.id) || value.id <= 0
    || !value.requestId || (value.maxSelections !== 1 && value.maxSelections !== 2)
    || !Array.isArray(value.selectedShells) || value.selectedShells.length !== value.maxSelections
    || value.selectedShells.some((index) => !Number.isInteger(index) || index < 0 || index > 5)
    || new Set(value.selectedShells).size !== value.selectedShells.length
    || value.selectedShell !== value.selectedShells[value.selectedShells.length - 1]) return false;
  return value.playMode !== "paid" || value.currencyCode === (value.pricingVersion === "pearl-paid-20260913-v1" ? "reward_coin" : "pearl_coin");
}

export default function PearlLagoonScreen() {
  const router = useRouter();
  // 各页面使用各自现役资源入口；Web 离开开蚌时重新取目标 HTML，避免旧路由图加载失效分块。
  const navigateOutside = (href: Parameters<typeof router.push>[0], replace = false) => {
    if (Platform.OS === "web" && typeof window !== "undefined" && typeof href === "string") {
      if (replace) window.location.replace(href);
      else window.location.assign(href);
    } else if (replace) router.replace(href);
    else router.push(href);
  };
  const insets = useSafeAreaInsets();
  const { mode } = useLocalSearchParams<{ mode?: string }>();
  const [language, setLanguage] = useState("zh-Hant");
  const t = (key: string) => translatePearl(key, language);
  const text = (zh: string, en: string) => language === "en" ? en : zh;
  const authToken = useAuthStore((s) => s.token);
  const session = authToken ? { token: authToken } : null;
  const tokenPresent = !!authToken;
  const [rules, setRules] = useState<PearlRules>();
  const [rulesLoading, setRulesLoading] = useState(false);
  const [rulesError, setRulesError] = useState(false);
  const [state, setState] = useState<PearlState>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>();
  const [phase, setPhase] = useState<Phase>("idle");
  const [selected, setSelected] = useState<number | null>(null);
  const [aim, setAim] = useState<number | null>(null);
  const [round, setRound] = useState<PearlRound | null>(null);
  const [panel, setPanelState] = useState<Panel>("play");
  const [practice, setPractice] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [curtain, setCurtain] = useState(false);
  const [gentleEffects, setGentleEffects] = useState(false);
  const [screenFocused, setScreenFocused] = useState(false);
  const [appActive, setAppActive] = useState(true);
  const quietMotion = reducedMotion || gentleEffects || !screenFocused || !appActive;
  const panelEntry = useRef(new Animated.Value(1)).current;
  const [clockNow, setClockNow] = useState(Date.now());
  const busy = useRef(false);
  const pending = useRef<PendingExploration | null>(null);
  const pendingStartIndex = useRef<number | null>(null);
  const practiceLayout = useRef<PearlRound["shells"] | null>(null);
  const accountId = useRef<number | null>(null);
  const epoch = useRef(0);
  const rulesEpoch = useRef(0);
  const rulesBusy = useRef(false);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const clockOffset = useRef(0);
  const autoResetRequested = useRef(0);
  const scrollRef = useRef<ScrollView>(null);
  const loadRules = useCallback(async () => {
    if (rulesBusy.current) return;
    const version = ++rulesEpoch.current;
    rulesBusy.current = true; setRulesLoading(true); setRulesError(false);
    const publicRules = await getPearlRules();
    if (version !== rulesEpoch.current) return;
    rulesBusy.current = false; setRulesLoading(false);
    if (publicRules) setRules(publicRules);
    else setRulesError(true);
  }, []);
  const setPanel = (value: Panel) => {
    setPanelState(value);
    scrollRef.current?.scrollTo({ y: 0, animated: false });
    if (value === "rules" && !rules && !state?.rules) void loadRules();
  };

  const stopTimers = useCallback(() => { timers.current.forEach(clearTimeout); timers.current = []; }, []);
  const applyState = useCallback((value: PearlState) => {
    if (value.profile?.accountId && Number.isSafeInteger(value.profile.accountId)) accountId.current = value.profile.accountId;
    setState(value); setRules(value.rules);
    clockOffset.current = value.serverNowMs - Date.now();
    setClockNow(value.serverNowMs);
  }, []);

  const restoreRound = useCallback((value: PearlRound | null) => {
    stopTimers(); busy.current = false;
    // 旧版历史局没有分步字段，兼容为已完成单开，不能重新进入选择。
    const restored = value ? { ...value, status: value.status ?? "complete", maxSelections: value.maxSelections ?? 1,
      selectedShells: value.selectedShells ?? (value.selectedShell >= 0 ? [value.selectedShell] : []) } as PearlRound : null;
    setRound(restored); setSelected(restored && restored.selectedShell >= 0 ? restored.selectedShell : null);
    setPhase(restored?.status === "complete" ? "all" : "idle");
  }, [stopTimers]);

  const load = useCallback(async (previewOnly = false) => {
    const version = ++epoch.current;
    setLoading(!previewOnly && tokenPresent); setError(undefined);
    if (previewOnly || !tokenPresent) {
      // 试玩立即可操作，公开规则在后台补齐，不让接口等待遮住体验。
      accountId.current = null; setState(undefined);
      void loadRules();
      return;
    }
    // 账号响应已包含完整规则，直接读取，避免先等 rules 再请求 state。
    const response = await getPearlState();
    if (version !== epoch.current) return;
    setLoading(false);
    if (!response.ok || !response.data) {
      setError(response.status === 410000 || response.status === 401 ? "Please sign in again to explore." : "The lagoon could not connect. Please try again.");
      return;
    }
    applyState(response.data);
    // 按服务端账号恢复尚未确认的请求；切页、刷新或登录回来都不另开一局。
    const uid = response.data.profile?.accountId;
    let latest = response.data.lastRound;
    if (response.data.available) {
      if (!uid || !Number.isSafeInteger(uid) || uid <= 0) {
        accountId.current = null;
        setError("The lagoon could not connect. Please try again.");
        return;
      }
      try {
        const saved = readPendingExploration(uid);
        pending.current = saved ?? null;
        let confirmed = saved ? pendingConfirmedByRound(saved, latest) : false;
        if (saved && !confirmed && authoritativeComplete(latest)) {
          if (latest.requestId === saved.requestId) confirmed = true;
          else if (saved.action === "start") confirmed = latest.id > saved.expectedPreviousRoundId;
          else if (saved.action === "pick") {
            // 无原局id的pick不能仅凭异号清除：首次GET后另一窗口可能刚写入新pick。
            // 先读到saved，再读一次服务器进度，且动作未变，才采用权威终态。
            setLoading(true);
            const fresh = await getPearlState(true);
            if (version !== epoch.current) return;
            setLoading(false);
            if (!fresh.ok || !fresh.data?.available || fresh.data.profile?.accountId !== uid) {
              restoreRound(latest); setPhase("idle");
              setError(fresh.status === 410000 || fresh.status === 401 ? "Please sign in again to explore." : "The lagoon could not connect. Please try again.");
              return;
            }
            applyState(fresh.data); latest = fresh.data.lastRound;
            const unchanged = readPendingExploration(uid);
            if (JSON.stringify(unchanged) !== JSON.stringify(saved)) {
              pending.current = unchanged ?? null;
              restoreRound(latest);
              if (unchanged) setPhase("idle");
              return;
            }
            confirmed = pendingConfirmedByRound(saved, latest) || authoritativeComplete(latest);
          }
        }
        if (saved && !confirmed) {
          restoreRound(latest);
          // 即使另一窗口已完成，也保留点蚌恢复原动作的入口，等待服务端核对冲突。
          setPhase("idle");
          // 未完成不等于断网：仅恢复画面，下一次点蚌才发送原请求。
          return;
        }
        if (saved) {
          const cleared = clearPendingExploration(uid, saved);
          const newer = cleared ? undefined : readPendingExploration(uid);
          if (newer) { pending.current = newer; throw new Error("A newer action needs confirmation"); }
          pending.current = null;
        }
      } catch {
        setError("This exploration could not be saved on this device. Refresh before trying again.");
        return;
      }
    }
    restoreRound(latest);
  }, [tokenPresent, applyState, loadRules, restoreRound]);

  useEffect(() => {
    let alive = true;
    AccessibilityInfo.isReduceMotionEnabled().then((value) => { if (alive) setReducedMotion(value); });
    const subscription = AccessibilityInfo.addEventListener("reduceMotionChanged", setReducedMotion);
    return () => { alive = false; subscription.remove(); };
  }, []);

  useEffect(() => {
    setAppActive(AppState.currentState === "active");
    const subscription = AppState.addEventListener("change", (value) => setAppActive(value === "active"));
    return () => subscription.remove();
  }, []);

  useEffect(() => {
    panelEntry.stopAnimation();
    if (quietMotion) { panelEntry.setValue(1); return; }
    panelEntry.setValue(0);
    const animation = Animated.timing(panelEntry, { toValue: 1, duration: 260, easing: Easing.bezier(0.16, 1, 0.3, 1), useNativeDriver: Platform.OS !== "web" });
    animation.start();
    return () => animation.stop();
  }, [panel, panelEntry, quietMotion]);

  useFocusEffect(useCallback(() => {
    setScreenFocused(true);
    if (Platform.OS === "web" && typeof document !== "undefined") document.title = "Pearl Lagoon";
    const previewOnly = mode === "practice" || !tokenPresent;
    setPractice(previewOnly); setRound(null); setSelected(null); setAim(null); setPhase("idle"); setCurtain(false);
    setState(undefined); accountId.current = null; pending.current = null; practiceLayout.current = null; busy.current = false;
    void load(previewOnly);
    return () => { setScreenFocused(false); ++epoch.current; ++rulesEpoch.current; rulesBusy.current = false; stopTimers(); busy.current = false; };
  }, [session?.token, mode, load, stopTimers]));

  useEffect(() => {
    const timer = setInterval(() => setClockNow(Date.now() + clockOffset.current), 30000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const resetAt = state?.profile?.resetAtMs;
    if (state?.available && resetAt && clockNow >= resetAt && autoResetRequested.current !== resetAt && !busy.current && !practice && !loading) {
      autoResetRequested.current = resetAt;
      void load();
    }
  }, [clockNow, state?.profile?.resetAtMs, practice, loading, load]);

  // 最终兜底必须让旧响应失效；待确认请求仍保留，恢复时不能另扣新局。
  useEffect(() => {
    if (phase !== "submitting") return;
    const guard = setTimeout(() => {
      ++epoch.current;
      stopTimers();
      busy.current = false;
      setPhase("idle");
      setError("The lagoon is slow to answer. Tap the clam again to continue this round.");
    }, 20000);
    return () => clearTimeout(guard);
  }, [phase, round?.requestId, stopTimers]);

  const finishReveal = (value: PearlRound) => {
    stopTimers(); setPhase(value.status === "choosing" ? "idle" : "all"); busy.current = false;
  };
  const reveal = (value: PearlRound, version: number) => {
    if (version !== epoch.current) return;
    stopTimers(); setRound(value); setSelected(value.selectedShell); setPhase("selected");
    timers.current.push(setTimeout(() => { if (version === epoch.current) finishReveal(value); }, quietMotion ? 0 : 1800));
  };

  const submit = async (intent: PendingExploration) => {
    if (busy.current || !state?.available || !tokenPresent || !accountId.current) return;
    busy.current = true; setError(undefined); setPhase("submitting");
    const version = ++epoch.current;
    const uid = accountId.current;
    let request: PendingExploration;
    try {
      request = savePendingExploration(uid, pending.current ?? intent);
    } catch {
      busy.current = false; setPhase("idle");
      setError("This exploration could not be saved on this device. Refresh before trying again.");
      return;
    }
    pending.current = request;
    if (request.action !== "start") { setSelected(request.selectedShell); setAim(request.selectedShell); }
    const response = request.action === "start" ? await startPearlRound(request.requestId, request.expectedPreviousRoundId, request.mode ?? "free", request.pricingVersion)
      : request.action === "pick" ? await pickPearlShell(request.requestId, request.selectedShell, request.selectionStep)
        : await openPearlShell(request.requestId, request.selectedShell);
    if (version !== epoch.current) return;
    if (!response.ok || !response.data) {
      busy.current = false; setPhase("idle");
      const interrupted = "Connection interrupted. Retry this exploration to continue safely.";
      setError(response.status === 410000 || response.status === 401
        ? "Please sign in again to explore."
        : interrupted);
      return;
    }
    const result = response.data;
    if (result.snapshot?.profile?.accountId !== uid || (result.accepted && !pendingConfirmedByRound(request, result.round))) {
      busy.current = false; setPhase("idle");
      setError("An earlier exploration needs confirmation. Check it before choosing another shell.");
      return;
    }
    // 冲突不是断网：仅在服务端明确返回同账号、同一局的真实进度时，释放旧动作。
    // 不用别的局或空快照清记录，不换局号、报价或选位重发。
    const actualRound = result.snapshot?.lastRound;
    const actualSelections = actualRound?.selectedShells;
    const conflictResolved = !result.accepted && result.reasonCode === "request_conflict"
      && result.requestId === request.requestId && result.snapshot.available
      && actualRound?.requestId === request.requestId && Number.isSafeInteger(actualRound.id) && actualRound.id > 0
      && (actualRound.status === "choosing" || actualRound.status === "complete")
      && (actualRound.maxSelections === 1 || actualRound.maxSelections === 2)
      && Array.isArray(actualSelections) && actualSelections.length <= actualRound.maxSelections
      && actualSelections.every((index) => Number.isInteger(index) && index >= 0 && index <= 5)
      && new Set(actualSelections).size === actualSelections.length
      && (actualRound.status === "complete" ? actualSelections.length === actualRound.maxSelections : actualSelections.length < actualRound.maxSelections)
      && (request.action !== "pick" || actualSelections[request.selectionStep - 1] !== undefined);
    const zeroDebitReasons = ["pricing_changed", "insufficient_coins", "daily_limit", "rate_limited", "stale_start", "active_round", "upgrade_required", "selection_out_of_order", "shell_already_selected", "round_not_found"];
    if (!result.accepted && !conflictResolved && !zeroDebitReasons.includes(result.reasonCode ?? "")) {
      busy.current = false; setPhase("idle");
      setError("This exploration still needs confirmation. Retry the same exploration safely.");
      return;
    }
    try {
      // 精确到动作和选择步数，迟到的第 1 步响应不能删除第 2 步的恢复记录。
      const cleared = clearPendingExploration(uid, request);
      const newer = cleared ? undefined : readPendingExploration(uid);
      if (newer) { pending.current = newer; throw new Error("A newer action needs confirmation"); }
    } catch {
      busy.current = false; setPhase("idle");
      setError("An earlier exploration needs confirmation. Check it before choosing another shell.");
      return;
    }
    pending.current = null;
    if (result.snapshot) applyState(result.snapshot);
    if (conflictResolved) {
      pendingStartIndex.current = null;
      setAim(null);
      restoreRound(actualRound!);
      return;
    }
    if (result.accepted && result.round) {
      const value = { ...result.round, status: result.round.status ?? "complete", maxSelections: result.round.maxSelections ?? 1,
        selectedShells: result.round.selectedShells ?? [result.round.selectedShell] } as PearlRound;
      const continueStartedRound = (confirmed: PearlRound) => {
        restoreRound(confirmed);
        const index = pendingStartIndex.current;
        pendingStartIndex.current = null;
        if (request.action === "start" && index != null && confirmed.status === "choosing") {
          setAim(index);
          // 同一次点击：先确认服务端开局，再选择原来点中的蚌，始终沿用同一局号。
          void submit({ action: "pick", requestId: confirmed.requestId, selectedShell: index,
            selectionStep: (confirmed.selectedShells.length + 1) as 1 | 2 });
        }
      };
      if (result.duplicate) {
        restoreRound(value);
        setLoading(true);
        const current = await getPearlState();
        if (version !== epoch.current) return;
        setLoading(false);
        if (current.ok && current.data?.profile?.accountId === uid) {
          applyState(current.data);
          if (current.data.lastRound?.requestId === request.requestId) continueStartedRound(current.data.lastRound);
          else { pendingStartIndex.current = null; restoreRound(current.data.lastRound); }
        }
        else setError(current.status === 410000 || current.status === 401 ? "Please sign in again to explore." : "The lagoon could not connect. Please try again.");
      } else if (request.action === "start") continueStartedRound(value);
      else reveal(value, version);
      return;
    }
    restoreRound(result.snapshot?.lastRound ?? null);
    // 服务端业务拒绝已确认这个动作未生效；恢复账号的在途局，不能再抽另一份布局。
    if (result.reasonCode === "active_round" && result.snapshot?.lastRound?.status === "choosing") return;
    const reason: Record<string, string> = {
      unavailable: "The lagoon is preparing to open. Try the animation below.",
      daily_limit: "Today's explorations are complete. Your reef will be here tomorrow.",
      rate_limited: "Let the water settle for a moment, then try again.",
      request_conflict: "This exploration changed on another device. Refresh to continue.",
      stale_start: "This exploration changed on another device. Refresh to continue.",
      upgrade_required: "The lagoon has been updated. Refresh to continue with the current version.",
      selection_out_of_order: "This exploration changed on another device. Refresh to continue.",
      shell_already_selected: "This exploration changed on another device. Refresh to continue.",
      round_not_found: "This exploration changed on another device. Refresh to continue.",
      pricing_changed: "The exploration price changed. No coins were spent. Refresh to confirm the new price.",
      insufficient_coins: "Not enough game coins. Nothing was spent. Add coins before continuing.",
    };
    setError(reason[result.reasonCode ?? ""] ?? "The lagoon could not connect. Please try again.");
  };

  const start = () => {
    if (busy.current || loading || error || pending.current || round?.status === "choosing") return;
    if (practice) {
      ++epoch.current; stopTimers(); setError(undefined);
      try {
        const board = generatePracticeBoard();
        practiceLayout.current = board.private;
        const previewRound: PearlRound = { id: 0, requestId: newPearlRequestId(), status: "choosing", maxSelections: 1, selectedShells: [], selectedShell: -1,
          shells: board.public, pearlKey: null, pointsDelta: 0, requestedPoints: 0, rewardCapped: false, fragmentsDelta: 0,
          dailyGoalFragments: 0, newCollectionKeys: [], unlockedDecorationKeys: [], ruleVersion: "practice", createdAtMs: Date.now() };
        setRound(previewRound);
        setSelected(null); setPhase("idle");
        if (pendingStartIndex.current != null) {
          const index = pendingStartIndex.current;
          pendingStartIndex.current = null;
          setAim(index);
          busy.current = true;
          reveal({ ...previewRound, selectedShell: index, selectedShells: [index], status: "complete",
            shells: board.private, pearlKey: board.private.find((shell) => shell.index === index)?.pearlKey ?? null }, epoch.current);
        }
      } catch {
        practiceLayout.current = null;
        setError("This device cannot start a secure practice round. Please open the HTTPS website.");
      }
      return;
    }
    if (!state?.available || !tokenPresent || !state.profile) return;
    const paid = (state.profile.freeRemaining ?? state.profile.remainingPlays) <= 0;
    const price = state.rules.paidCost;
    if (paid && (!Number.isSafeInteger(price) || !price || price < 1 || !state.rules.pricingVersion || state.rules.currencyCode !== "pearl_coin")) return;
    if (paid && (state.profile.coinBalance ?? 0) < price!) { openSupply(); return; }
    try { void submit(paid
      ? { action: "start", requestId: newPearlRequestId(), expectedPreviousRoundId: state.lastRound?.id ?? 0, mode: "paid", pricingVersion: state.rules.pricingVersion! }
      : { action: "start", requestId: newPearlRequestId(), expectedPreviousRoundId: state.lastRound?.id ?? 0, mode: "free" }); }
    catch { setError("This exploration could not be saved on this device. Refresh before trying again."); }
  };

  const play = (index: number) => {
    if (busy.current || loading || phase !== "idle" || round?.status !== "choosing"
      || !Number.isInteger(index) || index < 0 || index > 5 || round.selectedShells.includes(index)) return;
    const selectionStep = (round.selectedShells.length + 1) as 1 | 2;
    if (selectionStep > round.maxSelections) return;
    if (!practice) { void submit({ action: "pick", requestId: round.requestId, selectedShell: index, selectionStep }); return; }
    if (!practiceLayout.current) return;
    busy.current = true; setError(undefined); setSelected(index); setPhase("submitting");
    const version = ++epoch.current;
    const selectedShells = [...round.selectedShells, index];
    const complete = selectedShells.length === round.maxSelections;
    const value: PearlRound = { ...round, selectedShell: index, selectedShells, status: complete ? "complete" : "choosing",
      shells: practiceLayout.current.filter((shell) => complete || selectedShells.includes(shell.index)),
      pearlKey: practiceLayout.current.find((shell) => shell.index === index)?.pearlKey ?? null };
    // 试玩结果已在本机，不经过“等待服务器”或人工延时，开盖节奏交给动画层。
    reveal(value, version);
  };

  const onShellTap = (index: number) => {
    if (busy.current || loading || phase === "selected" || phase === "submitting") return;
    if (!practice && pending.current) {
      if (pending.current.action === "start" && pendingStartIndex.current == null) pendingStartIndex.current = index;
      if (pending.current.action === "start") setAim(pendingStartIndex.current);
      void submit(pending.current);
      return;
    }
    if (error) return;
    if (!round || round.status !== "choosing" || phase === "all") {
      pendingStartIndex.current = index;
      setAim(index);
      start();
      return;
    }
    setAim(index);
    play(index);
  };

  // 集齐即送：给每条挂件显示「还差几颗某档珍珠」。
  const milestoneOf = (charm: PearlCharmId) =>
    (state?.charmMilestones ?? []).find((row) => row.charm === charm) ?? null;
  const milestoneLine = (row: { tier: string; need: number; count: number; granted: boolean }) => {
    const tierName = (pearlNames as Record<string, string>)[row.tier] ?? row.tier;
    if (row.granted) return text(`集齊 ` + row.need + ` 顆` + tierName + ` 已贈送 ✓`, `Collect ` + row.need + ` ` + tierName + ` free ✓`);
    return text(`集齊 ` + row.need + ` 顆` + tierName + `即贈送（` + row.count + `/` + row.need + `）`, `Collect ` + row.count + `/` + row.need + ` ` + tierName + ` to get it free`);
  };
  const mutateCharm = async (charmId: PearlCharmId) => {
    if (practice || !tokenPresent || !state?.available) return;
    const response = await buyPearlCharm(newPearlRequestId(), charmId);
    if (!response.ok || !response.data) {
      setError(response.status === 410000 || response.status === 401 ? "Please sign in again to explore." : "The lagoon could not connect. Please try again.");
      return;
    }
    if (response.data.snapshot) applyState(response.data.snapshot);
    if (!response.data.accepted) {
      const reason: Record<string, string> = {
        charm_owned: "You already own this charm.",
        insufficient_coins: "Not enough game coins. Nothing was spent. Add coins before continuing.",
        charm_soulbound: "Charms stay in your tray and cannot convert to points.",
      };
      setError(reason[response.data.reasonCode ?? ""] ?? "The lagoon could not connect. Please try again.");
    }
  };

  const nextRound = () => {
    if (busy.current || loading || pending.current || (!practice && round?.status === "choosing")) return;
    ++epoch.current; stopTimers(); busy.current = false; practiceLayout.current = null; pendingStartIndex.current = null;
    setLoading(false); setRound(null); setSelected(null); setAim(null); setPhase("idle"); setCurtain(false); setError(undefined);
    scrollRef.current?.scrollTo({ y: 0, animated: false });
  };
  const enterPractice = () => {
    if (busy.current || loading || pending.current || (!practice && round?.status === "choosing")) return;
    setPanel("play");
    router.setParams({ mode: "practice" });
  };
  const enterCollection = () => {
    if (!tokenPresent) { navigateOutside("/auth"); return; }
    setPanel("play");
    router.setParams({ mode: "collect" });
  };
  const openSupply = () => navigateOutside("/game-wallet?game=pearl&returnTo=%2Fpearl");
  const openPointPurchase = () => navigateOutside("/point-purchase?game=pearl");
  const freeRemaining = state?.profile?.freeRemaining ?? state?.profile?.remainingPlays ?? 0;
  const paidCost = state?.rules.paidCost;
  const paidAvailable = Number.isSafeInteger(paidCost) && (paidCost ?? 0) > 0 && Boolean(state?.rules.pricingVersion) && state?.rules.currencyCode === "pearl_coin";
  const coinName = text("貝殼幣", "shell coins");
  const roundCoinName = round?.currencyCode === "reward_coin" || round?.pricingVersion === "pearl-paid-20260913-v1"
    ? text("農場金幣", "farm coins") : coinName;
  const needsCoins = !practice && freeRemaining <= 0 && paidAvailable;
  const paidStartLabel = (state?.profile?.coinBalance ?? 0) >= (paidCost ?? 1)
    ? text(`繼續尋珠 · ${paidCost} ${coinName}`, `Continue exploring · ${paidCost} shell coin${paidCost === 1 ? "" : "s"}`)
    : text(`補充${coinName}繼續尋珠`, "Add shell coins to continue");
  const canStart = !loading && !error && !pending.current && (practice || (tokenPresent && state?.available && accountId.current !== null && (freeRemaining > 0 || paidAvailable)));
  const canPlay = !loading && !error && !pending.current && round?.status === "choosing"
    && (practice || (tokenPresent && state?.available && accountId.current !== null));
  const shownRules = state?.rules ?? rules;
  const profile = state?.profile;
  const minutesLeft = Math.max(0, Math.ceil(((profile?.resetAtMs ?? rules?.resetAtMs ?? clockNow) - clockNow) / 60000));
  const resetLabel = text(`${Math.floor(minutesLeft / 60)}小時 ${minutesLeft % 60}分`, `${Math.floor(minutesLeft / 60)}h ${minutesLeft % 60}m`);
  const dailyGoal = shownRules?.dailyGoal.plays ?? 3;
  const collectedCount = state?.collection.filter((item) => item.collected).length ?? 0;
  const fragmentBank = profile?.fragmentBank ?? 0;
  const reefStones = profile?.reefStones ?? 0;
  // 四只核心伙伴（海仔/章鱼/粉嫩/Pip）常驻海景：不登录、未解锁也要在，解锁与挂件再叠加。
  const lifeIds = [
    "clownfish", "octopus", "axolotl", "pip",
    ...(state?.companions ?? []),
    ...(state?.charms ?? []),
    ...(reefStones >= 1 ? ["kelp"] : []),
    ...(reefStones >= 2 ? ["coral"] : []),
    ...(reefStones >= 3 ? ["fan"] : []),
  ];
  const isDone = (phase === "all" || round?.status === "complete") && round;
  const rateLimited = error === "Let the water settle for a moment, then try again.";
  // 底部「登入後探索 / 再试一次」条按原画真实高度渲染，滚动内容要给它让位，避免压住任务签。
  const busyAnimation = phase === "selected" || phase === "submitting";
  const chosenPearls = round?.shells.filter((shell) => round.selectedShells.includes(shell.index) && shell.pearlKey) ?? [];
  const choosing = round?.status === "choosing";
  const doubleOpen = round?.maxSelections === 2;
  const selectedCount = round?.selectedShells.length ?? 0;
  const resultTitle = chosenPearls.length > 1 ? "Two pearls, one lovely discovery" : chosenPearls[0]?.pearlKey ? pearlNames[chosenPearls[0].pearlKey] : "A little piece of the ocean";
  // 底部手绘签同时承担「状态说明 + 主动作按钮 + 玩法提示开关」。
  const [infoOpen, setInfoOpen] = useState(false);
  const statusTitle = phase === "submitting" ? text("正在開蚌…", "Opening shell…")
    : practice ? text("開蚌體驗", "Shell opening preview") : t("Today's little adventure");
  const hintText = (practice ? text("體驗不消耗次數，不發放積分或收藏。", "Preview uses no attempts and awards no points or collectibles. ") : "") + t(curtain ? "Drag them. Swipe again to hunt" : "Look for bubbles. A true pearl clam breathes.");
  const primaryAction: { label: string; run: () => void } | null =
    practice ? (isDone ? { label: text("再試玩一次", "Try again"), run: nextRound }
      : !round && !loading && !error ? { label: text("免費試玩", "Try for free"), run: start } : null)
    : phase === "selected" && round?.status === "complete" && !quietMotion ? { label: t("Reveal all now"), run: () => { if (round) finishReveal(round); } }
    : isDone && !busyAnimation && !loading && !pending.current ? { label: text("再開一局", "Open another round"), run: nextRound }
    : !busyAnimation && !loading && !pending.current && !choosing ? { label: text("免費試玩", "Try for free"), run: enterPractice }
    : null;

  return (
    <PearlLangContext.Provider value={language}>
    <Head>
      <title>Pearl Lagoon</title>
    </Head>
    <Stack.Screen options={{ title: "Pearl Lagoon" }} />
    <MotionProvider reducedMotion={quietMotion}>
    <View style={styles.page}>
      <View style={styles.background}>
        <View pointerEvents="none" style={styles.backgroundClip}>
          <ImageBackground source={background} defaultSource={background} resizeMode="cover" style={styles.backgroundImage} />
        </View>
        <OceanEffects reducedMotion={quietMotion} phase={phase} pearlKey={round?.pearlKey} />
        <LinearGradient pointerEvents="none" colors={["rgba(239,247,225,0.65)", "rgba(239,247,225,0)"]} style={styles.surfaceLight} />
        <View style={{ paddingTop: insets.top, zIndex: 20 }}>
          <LagoonHeader key={panel} language={language} practice={practice}
            balance={!practice && profile && state?.available && typeof profile.coinBalance === "number" ? profile.coinBalance.toLocaleString() : "—"}
            attempts={practice ? text("體驗", "Preview") : profile && state?.available ? `${freeRemaining} / ${profile.dailyLimit}` : "—"}
            onBack={() => navigateOutside("/", true)} onLanguage={() => setLanguage(language === "en" ? "zh-Hant" : "en")}
            onHelp={() => setPanel(panel === "rules" ? "play" : "rules")} onSupply={openSupply} onBuyPoints={openPointPurchase} />
        </View>
        <ScrollView ref={scrollRef} style={styles.scrollFill} contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
          {panel === "play" ? (
            <View style={styles.playContent}>
              <View style={styles.sceneCaption}>
                <View style={styles.captionRule} /><Text style={styles.sceneCaptionText}>{t(curtain ? "YOUR LITTLE OCEAN" : practice ? "Look for bubbles. A true pearl clam breathes." : "FOLLOW THE PEARL LIGHT")}</Text><View style={styles.captionRule} />
              </View>
              <View style={styles.stageWrap}>
                <PearlStage selectedShell={aim ?? selected} selectedShells={round?.selectedShells ?? []} shells={round?.shells ?? null} phase={phase} disabled={busyAnimation || loading || (!practice && !state?.available)} reducedMotion={quietMotion} curtain={curtain} lifeIds={lifeIds} onSelect={onShellTap} onCurtain={() => setCurtain((open) => !open)} />
              </View>
              <View style={styles.feedback} accessibilityLiveRegion="polite">
                {doubleOpen && choosing ? <RevealText trigger={`${round.requestId}-double`} reducedMotion={quietMotion} style={styles.doubleTitle}>{t("Tidal surprise! Open two shells this round")}</RevealText> : null}
                {choosing && !busyAnimation && !error ? <Text style={styles.choiceProgress}>{selectedCount} / {round.maxSelections} · {t(selectedCount ? "Choose a different shell for your second pick" : "Choose your first shell")}</Text> : null}
                {!practice && choosing && round.playMode === "paid" ? <Text style={styles.smallCopy}>{text(`本局已扣 ${round.coinsSpent ?? 0} ${roundCoinName}${doubleOpen ? "，第二枚不再收費" : ""}`, `${round.coinsSpent ?? 0} ${roundCoinName} spent this round${doubleOpen ? "; the second pick is included" : ""}`)}</Text> : null}
                {loading ? <View style={styles.loading}><ActivityIndicator color="#155e63" /><Text style={styles.feedbackCopy}>{t("Finding your lagoon...")}</Text></View> : null}
                {error ? <View testID="pearl-recovery" style={styles.recovery}>
                  <Text accessibilityLiveRegion="polite" style={styles.smallCopy}>{pending.current && tokenPresent && state?.available && error !== "Please sign in again to explore." ? text("暫時沒打開，點蚌再試。", "It did not open yet. Tap a clam to retry.") : t(error)}</Text>
                  {error === "Please sign in again to explore." ? <Pressable accessibilityRole="button" style={styles.recoveryButton} onPress={() => navigateOutside("/auth")}><Text style={styles.recoveryButtonText}>{text("重新登入", "Sign in again")}</Text></Pressable>
                    : !pending.current || !state?.available ? <Pressable accessibilityRole="button" disabled={loading || busyAnimation} style={styles.recoveryButton} onPress={() => { if (practice || rateLimited) nextRound(); else void load(); }}><Text style={styles.recoveryButtonText}>{practice ? text("重新試玩", "Try preview again") : rateLimited ? text("再試一次", "Try again") : text("重新連線", "Reconnect")}</Text></Pressable> : null}
                </View> : null}
                {isDone ? <>
                  <RevealText trigger={round.requestId} reducedMotion={quietMotion} style={styles.resultTitle}>{t(resultTitle)}</RevealText>
                  <Text testID="pearl-result-reward" style={styles.feedbackCopy}>{practice ? t("Just a preview of the reveal. Your account is unchanged.") : [round.playMode === "paid" ? text(`本局獲得 ${round.coinsDelta ?? 0} ${roundCoinName} · 已消耗 ${round.coinsSpent ?? 0} ${roundCoinName}`, `Received ${round.coinsDelta ?? 0} ${roundCoinName} · Spent ${round.coinsSpent ?? 0} ${roundCoinName}`) : round.pointsDelta > 0 ? `+${round.pointsDelta} ${t("points")}` : "", round.convertedCoins ? `+${round.convertedCoins} ${coinName}` : "", chosenPearls.length ? `${chosenPearls.length} ${t("pearls collected")}` : "", round.fragmentsDelta ? `+${round.fragmentsDelta} ${t("shell fragments")}` : "", !practice && (round.streak ?? 0) >= 2 ? `${t("Streak")} ${round.streak}` : ""].filter(Boolean).join(" · ")}</Text>
                  {!practice && round.playMode !== "paid" && round.rewardCapped ? <Text style={styles.smallCopy}>{t("Your daily free points limit is reached. Your pearl is still collected.")}</Text> : null}
                  {!practice && round.dailyStone ? <Text style={styles.smallCopy}>{t("A reef stone settled into your sea")}</Text> : null}
                  {!practice && round.playMode !== "paid" && freeRemaining <= 0 ? <>
                    <Text style={styles.goalTitle}>{t("Today's five free points are in your points account.")}{profile?.freePointsToday ? ` · ${t("Today's free points")} ${profile.freePointsToday}` : ""}</Text>
                    <Text style={styles.smallCopy}>{t("Use those points to buy shell coins and keep exploring, or check your points wallet.")}</Text>
                    <Pressable accessibilityRole="button" onPress={openSupply}><Text style={styles.inlineLink}>{t("Convert points to keep playing")} ›</Text></Pressable>
                  </> : null}
                </> : !loading && !error ? <>
                  {needsCoins && !choosing && !busyAnimation ? <Pressable accessibilityRole="button" onPress={openSupply}><Text style={styles.inlineLink}>{t("Convert points to keep playing")} ›</Text></Pressable> : null}
                </> : null}
              </View>
              <LagoonQuest title={statusTitle} caption="" done={!practice ? (profile?.divesToday ?? profile?.playsToday ?? 0) : 0} goal={dailyGoal} practice={practice} actionLabel={primaryAction ? primaryAction.label : null} onAction={() => { if (primaryAction) primaryAction.run(); }} hint={hintText} infoOpen={infoOpen} onToggleInfo={() => setInfoOpen((value) => !value)} onPress={() => setPanel("reef")} />
              {practice ? <View style={styles.previewOptions}>
                <Text style={styles.smallCopy}>{text("不扣次數 · 不計積分與收藏", "No attempts used · No points or collectibles")}</Text>
                <Pressable accessibilityRole="button" onPress={enterCollection} style={({ pressed }) => [styles.previewAccountButton, pressed && styles.pressed]}>
                  <TrimmedArt source={actionArt} box={ACTION_BOX} style={styles.previewAccountArt}>
                    <Text numberOfLines={1} adjustsFontSizeToFit style={styles.previewAccountText}>{tokenPresent ? text("回到正式尋珠", "Return to my lagoon") : text("登入並收集", "Sign in to collect")} ›</Text>
                  </TrimmedArt>
                </Pressable>
              </View> : null}
            </View>
          ) : <Animated.View style={[styles.panel, { opacity: panelEntry, transform: [{ translateY: panelEntry.interpolate({ inputRange: [0, 1], outputRange: [14, 0] }) }] }]}>
            <Image source={modalAccentArt} resizeMode="contain" style={styles.panelAccent} />
            <View style={styles.panelInner}>
            <View style={styles.panelHead}><Text accessibilityRole="header" style={styles.panelTitle}>{t(panel === "collection" ? "Your pearl collection" : panel === "reef" ? "Make this ocean yours" : "A small guide to the lagoon")}</Text><Pressable accessibilityRole="button" accessibilityLabel={t("Close")} style={styles.close} onPress={() => setPanel("play")}><Text style={styles.closeText}>×</Text></Pressable></View>
            {panel === "collection" ? <>
              <Text style={styles.panelCopy}>{t("Every new pearl adds a little color to your ocean.")}</Text>
              {pearlKeys.map((key) => { const item = state?.collection.find((entry) => entry.id === key); return <View key={key} style={styles.collectionRow}><View style={[styles.gemSpot, !item?.collected && styles.undiscovered]}><PearlGem pearlKey={key} size={34} /></View><View style={styles.rowCopy}><Text style={styles.rowTitle}>{t(pearlNames[key])}</Text><Text style={styles.smallCopy}>{t(item?.collected ? "Discovered" : "Waiting to be discovered")}</Text></View><Text style={styles.count}>{item?.count ?? 0}</Text></View>; })}
              <Text style={styles.panelFoot}>{t("Only pearls from the shells you choose join your collection.")}</Text>
              {(shownRules?.charms ?? []).length ? <>
                <Text style={styles.rowTitle}>{t("Charms")}</Text>
                <Text style={styles.smallCopy}>{t("Buy with shell coins. Charms stay with your account and cannot convert back to points.")}</Text>
                {(shownRules?.charms ?? []).map((charm) => {
                  const owned = state?.charms?.includes(charm.id);
                  return (
                    <View key={charm.id} style={styles.collectionRow}>
                      <View style={styles.rowCopy}>
                        <Text style={styles.rowTitle}>{t(charmNames[charm.id] ?? charm.name)}</Text>
                        <Text style={styles.smallCopy}>{owned ? t("Owned · stays in your tray") : `${t("Buy")} ${charm.buy}`}</Text>
                        {milestoneOf(charm.id) ? <Text style={styles.smallCopy}>{milestoneLine(milestoneOf(charm.id)!)}</Text> : null}
                      </View>
                      {!practice && tokenPresent && state?.available && !owned ? (
                        <Pressable accessibilityRole="button" onPress={() => void mutateCharm(charm.id)}>
                          <Text style={styles.inlineLink}>{t("Buy")}</Text>
                        </Pressable>
                      ) : null}
                    </View>
                  );
                })}
                {(shownRules?.charms ?? []).every((charm) => state?.charms?.includes(charm.id)) ? (
                  <Text style={styles.panelFoot}>{t("All charms are in your tray. Leftover shell coins stay here for more dives — they cannot convert back to points.")}</Text>
                ) : null}
              </> : null}
              {state?.companions?.length ? <Text style={styles.panelFoot}>{t("Companions")}: {state.companions.join(" · ")}</Text> : null}
            </> : panel === "reef" ? <>
              <Text style={styles.panelCopy}>{t("Swipe aside the clams to see your sea")}</Text>
              <View style={styles.reefTotals}><Text style={styles.rowTitle}>{fragmentBank}/10 {t("shards")}</Text><Text style={styles.smallCopy}>{t("Ten fragments become one shell coin")}</Text></View>
              <View style={styles.decorationRow}><View style={styles.rowCopy}><Text style={styles.rowTitle}>{t("Stones")}</Text><Text style={styles.smallCopy}>{t("Explore three times for reef fragments")}</Text></View><Text style={styles.count}>{reefStones}</Text></View>
              <View style={styles.decorationRow}><View style={styles.rowCopy}><Text style={styles.rowTitle}>{t("Streak")}</Text><Text style={styles.smallCopy}>{t("White pearls and above keep the tide. Sand resets it.")}</Text></View><Text style={styles.count}>{profile?.streak ?? 0}{profile?.bestStreak ? ` / ${profile.bestStreak}` : ""}</Text></View>
              <Text style={styles.panelFoot}>{state?.companions?.length ? `${t("Companions")}: ${state.companions.join(" · ")}` : t("Pip stays with you. Sets unlock more friends.")}</Text>
            </> : <>
              {!practice ? <>
                <Pressable accessibilityRole="button" disabled={busyAnimation || loading || !!pending.current || !!choosing} accessibilityState={{ disabled: busyAnimation || loading || !!pending.current || !!choosing }} onPress={enterPractice} style={styles.motionSetting}><Text style={styles.rowTitle}>{text("先體驗開蚌", "Preview shell opening")} ›</Text></Pressable>
                <Text style={styles.smallCopy}>{text(choosing || pending.current ? "先完成目前這局，再進入體驗。" : "不消耗次數，不發放積分或收藏。", choosing || pending.current ? "Finish your current round before previewing." : "No attempts used. No points or collectibles awarded.")}</Text>
              </> : null}
              <Guide number="01" title={t("Tap a clam to start")} text={t("No start button. Six clams, one true pearl. Watch bubbles, shimmer, a slight opening.")} />
              <Guide number="02" title={t("Tap to open this shell")} text={text("點一下想開的蚌，確認後就會開蓋；連線中請稍候。", "Tap the clam you want to open. It opens once confirmed; please wait while connecting.")} />
              <Guide number="03" title={t("Pity, companions, charms")} text={t("Pink / gold / aurora pity at 6 / 16 / 40. Sets unlock companions. Charms stay in your tray. Leftover shells keep paying for dives.")} />
              <Guide number="04" title={t("Swipe aside the clams to see your sea")} text={t("Drag them. Swipe again to hunt")} />
              <View style={styles.ruleFacts}>
                {shownRules ? <>
                  <Text style={styles.panelCopy}>{shownRules.dailyFreePlays} {t("free explorations each day")}</Text>
                  <Text style={styles.smallCopy}>{t("Free rounds award platform points, capped at 5, with a 3-point floor after five dives.")}</Text>
                  <Text style={styles.smallCopy}>{t("Starting uses one daily exploration, even if you leave before finishing. Return to continue the same round.")}</Text>
                  <Text style={styles.panelCopy}>{t("Shared daily free points limit")}: {shownRules.freePointsDailyCap} {t("points")}</Text>
                  <Text style={styles.smallCopy}>{t("Shared with check-in, sharing and other free point rewards. At the limit, pearls are still collected but no points are saved for later.")}</Text>
                  <Text style={styles.panelCopy}>{t("Ten fragments become one shell coin")}</Text>
                  <Text style={styles.smallCopy}>{t("Fragments convert to shell coins to buy charms. Old coral / jellyfish / turtle unlocks are gone.")}</Text>
                  {shownRules.pity ? <Text style={styles.panelCopy}>{t("Pity")}: {shownRules.pity.pink}/{shownRules.pity.gold}/{shownRules.pity.aurora}</Text> : null}
                  <Text style={styles.panelCopy}>{t("Pearl colors when found")}</Text>
                  {shownRules.pearls.map((item) => <Text key={item.id} style={styles.smallCopy}>{t(pearlNames[item.id] ?? item.name)}: {item.weight} · +{item.points} {t("points")}{item.coins != null ? ` · +${item.coins}` : ""}</Text>)}
                  {shownRules.paidCost && shownRules.paidPearls ? <>
                    <Text style={styles.panelCopy}>{text(`免費次數用完後，每局 ${shownRules.paidCost} ${coinName}`, `After free rounds, each exploration costs ${shownRules.paidCost} shell coin`)}</Text>
                    <Text style={styles.smallCopy}>{text("開局時扣一次貝殼幣，雙開第二枚不收費。貝殼幣局不發放免費積分；退出後仍須完成原局。", "Coins are charged once at the start; a second pick is included. Paid rounds award shell coins instead of free points. Return to finish an unfinished round.")}</Text>
                    {shownRules.paidPearls.map((item) => <Text key={`paid-${item.id}`} style={styles.smallCopy}>{t(pearlNames[item.id])}: +{item.coins} {coinName}</Text>)}
                  </> : null}
                </> : <>
                  <Text accessibilityLiveRegion="polite" style={rulesError ? styles.error : styles.panelCopy}>{t(rulesLoading ? "Loading lagoon rules..." : "The rules could not load. Please try again.")}</Text>
                  {!rulesLoading ? <Action title={t("Retry rules")} onPress={() => void loadRules()} /> : null}
                </>}
                <Text style={styles.smallCopy}>{t("No points are spent to play. Daily limits reset at midnight, China Standard Time (UTC+8).")}</Text>
                <Pressable accessibilityRole="switch" accessibilityLabel={t("Full scene effects")} aria-checked={!gentleEffects && !reducedMotion} accessibilityState={{ checked: !gentleEffects && !reducedMotion, disabled: reducedMotion }} disabled={reducedMotion} onPress={() => setGentleEffects((value) => !value)} style={styles.motionSetting}>
                  <View style={{ flex: 1 }}><Text style={styles.rowTitle}>{t("Scene effects")}</Text><Text style={styles.smallCopy}>{t(reducedMotion ? "Following your device's reduced motion setting" : gentleEffects ? "Gentle" : "Full")}</Text></View>
                  <Text style={styles.rowTitle}>{!gentleEffects && !reducedMotion ? "✦" : "◌"}</Text>
                </Pressable>
              </View>
            </>}
            </View>
          </Animated.View>}
        </ScrollView>
        <View style={[styles.dockWrap, { paddingBottom: insets.bottom }]}>
          <LagoonNavigation panel={panel} count={collectedCount} onChange={setPanel}
            footer={state?.available && !practice ? `${t("Next daily reset")} · ${resetLabel}` : t("A little discovery. A world to keep.")} />
        </View>
      </View>
    </View>
    </MotionProvider>
    </PearlLangContext.Provider>
  );
}

function Action({ title, onPress }: { title: string; onPress: () => void }) { return <Pressable accessibilityRole="button" onPress={onPress} style={({ pressed }) => [styles.primary, pressed && styles.pressed]}><TrimmedArt source={actionArt} box={ACTION_BOX} style={styles.primaryArt}><Text style={styles.primaryText}>{title}</Text><Text style={styles.primaryArrow}>›</Text></TrimmedArt></Pressable>; }
function Guide({ number, title, text }: { number: string; title: string; text: string }) { return <View style={styles.guide}><Text style={styles.guideNumber}>{number}</Text><View style={styles.rowCopy}><Text style={styles.rowTitle}>{title}</Text><Text style={styles.panelCopy}>{text}</Text></View></View>; }

const styles = StyleSheet.create({
  // 舞台与导航共用一张背景；短屏允许内容滚动，导航不覆盖触摸区域。
  page: { ...StyleSheet.absoluteFillObject, overflow: "hidden", backgroundColor: "#0D343A" },
  background: { flex: 1, alignSelf: "center", width: "100%", maxWidth: 560, overflow: "hidden" },
  backgroundClip: { ...StyleSheet.absoluteFillObject, overflow: "hidden" },
  backgroundImage: { position: "absolute", width: "100%", height: "118%", top: 0 },
  surfaceLight: { position: "absolute", top: 0, left: 0, right: 0, height: 210 },
  scrollFill: { flex: 1 },
  scroll: { flexGrow: 1 },
  playContent: { flexGrow: 1, justifyContent: "center", paddingTop: 0 },
  sceneCaption: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 12, marginBottom: 0, paddingHorizontal: 24 },
  captionRule: { width: 28, height: 1, backgroundColor: "#638F82" },
  sceneCaptionText: { color: "#214F4E", fontSize: 10, fontWeight: "700", letterSpacing: 0.8, flexShrink: 1, textAlign: "center" },
  stageWrap: { position: "relative", minHeight: 300, overflow: "visible", justifyContent: "center", marginTop: 0 },
  feedback: { paddingHorizontal: 28, justifyContent: "center", alignItems: "center", gap: 7, paddingBottom: 0 },
  doubleTitle: { fontSize: 18, fontWeight: "700", color: "#654619", textAlign: "center", lineHeight: 25 },
  choiceProgress: { fontSize: 13, fontWeight: "600", color: "#214C45", textAlign: "center", lineHeight: 20 },
  resultTitle: { fontSize: 21, fontWeight: "700", color: "#164546", textAlign: "center", lineHeight: 29, fontFamily: Platform.OS === "web" ? 'Georgia, "Songti SC", "Noto Serif TC", serif' : undefined },
  feedbackCopy: { fontSize: 12, color: "#31574D", lineHeight: 19, textAlign: "center", maxWidth: 380 },
  smallCopy: { fontSize: 12, color: "#56716A", lineHeight: 19 },
  loading: { flexDirection: "row", gap: 10, alignItems: "center", minHeight: 48 },
  recovery: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 4 },
  recoveryButton: { alignSelf: "center", paddingHorizontal: 14, paddingVertical: 7, borderRadius: 999, backgroundColor: "rgba(255,251,240,0.9)", borderWidth: 1, borderColor: "rgba(150,124,72,0.55)" },
  recoveryButtonText: { color: "#5B431E", fontSize: 12, fontWeight: "700" },
  error: { color: "#7F3328", fontSize: 12, lineHeight: 19 },
  dockWrap: { backgroundColor: "transparent" },
  primary: { width: "100%", justifyContent: "center" },
  primaryArt: { width: "100%", aspectRatio: ACTION_ASPECT, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 16, paddingHorizontal: 28 },
  primaryText: { color: "#183F3D", fontSize: 13, fontWeight: "700", flexShrink: 1 },
  primaryArrow: { color: "#35564B", fontSize: 22, lineHeight: 22 },
  previewOptions: { alignItems: "center", marginTop: 4 },
  previewAccountButton: { width: 220, maxWidth: "90%", minHeight: 44, alignSelf: "center", marginTop: 8, justifyContent: "center" },
  previewAccountArt: { width: "100%", aspectRatio: ACTION_ASPECT, alignItems: "center", justifyContent: "center", paddingLeft: 32, paddingRight: 26, paddingTop: 8 },
  previewAccountText: { color: "#183F3D", fontSize: 13, lineHeight: 18, fontWeight: "700", textAlign: "center" },
  inlineLink: { color: "#18554F", textDecorationLine: "underline", fontSize: 12, fontWeight: "600", lineHeight: 20 },
  pressed: { opacity: 0.86 },
  goalTitle: { fontSize: 12, lineHeight: 18, fontWeight: "700", color: "#365744", textAlign: "center" },
  panel: { marginHorizontal: 20, marginTop: 16, marginBottom: 22, minHeight: 430, paddingTop: 12, paddingBottom: 10, paddingHorizontal: 1, borderRadius: 26, borderTopLeftRadius: 38, borderBottomRightRadius: 38, backgroundColor: "rgba(249,245,228,0.96)", borderWidth: 1, borderColor: "#C9AB76" },
  panelAccent: { position: "absolute", zIndex: 0, left: 5, right: 5, top: -28, width: "98%", height: 92 },
  panelInner: { flex: 1, position: "relative", zIndex: 1, paddingHorizontal: 26, paddingTop: 64, paddingBottom: 30 },
  panelHead: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 15 },
  panelTitle: { flex: 1, fontWeight: "700", color: "#183F3F", fontSize: 22, lineHeight: 30, fontFamily: Platform.OS === "web" ? 'Georgia, "Songti SC", "Noto Serif TC", serif' : undefined },
  close: { width: 40, height: 40, alignItems: "center", justifyContent: "center", marginRight: -8 },
  closeText: { color: "#7B573B", fontSize: 25, lineHeight: 28, fontWeight: "500" },
  panelCopy: { fontSize: 13, lineHeight: 21, color: "#496358" },
  collectionRow: { flexDirection: "row", alignItems: "center", gap: 14, paddingVertical: 17, borderBottomWidth: 1, borderBottomColor: "#D9DFCC" },
  gemSpot: { width: 48, height: 48, alignItems: "center", justifyContent: "center" },
  undiscovered: { opacity: 0.35 },
  rowCopy: { flex: 1, gap: 4 },
  rowTitle: { fontSize: 14, lineHeight: 20, fontWeight: "700", color: "#284D43" },
  count: { fontSize: 14, fontWeight: "600", color: "#466B5B", fontVariant: ["tabular-nums"] },
  panelFoot: { fontSize: 12, color: "#56716A", lineHeight: 19, marginTop: 20 },
  reefTotals: { paddingVertical: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  decorationRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 17, borderTopWidth: 1, borderTopColor: "#D9DFCC" },
  guide: { flexDirection: "row", gap: 14, marginVertical: 13 },
  guideNumber: { fontWeight: "600", fontSize: 18, color: "#7B8D60", paddingTop: 2 },
  ruleFacts: { borderTopWidth: 1, borderTopColor: "#D9DFCC", paddingTop: 16, marginTop: 12, gap: 10 },
  motionSetting: { minHeight: 56, marginTop: 8, flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12, borderTopWidth: 1, borderTopColor: "#D9DFCC" },
});
