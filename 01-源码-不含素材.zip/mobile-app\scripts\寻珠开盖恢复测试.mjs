import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { runInNewContext } from "node:vm";
import ts from "typescript";

// 真实现役页面 + API + legacyHttp + 待结算存储；所有 HTTP 仅进入内存队列。
// 不读取真实 token、不打开浏览器、不访问网络、不向生产写入。
const tick = () => new Promise((resolve) => setImmediate(resolve));
const rules = { ruleVersion: "test", dailyGoal: { plays: 3 }, pearls: [], decorations: [] };
const board = () => Array.from({ length: 6 }, (_, index) => ({ index, pearlKey: index === 2 ? "white" : "sand" }));
const round = (requestId, selectedShell = -1) => ({ id: 1, requestId, selectedShell,
  status: selectedShell < 0 ? "choosing" : "complete", maxSelections: 1,
  selectedShells: selectedShell < 0 ? [] : [selectedShell],
  shells: selectedShell < 0 ? board().map((shell) => ({ ...shell, pearlKey: null })) : board(),
  pearlKey: selectedShell < 0 ? null : board()[selectedShell].pearlKey, pointsDelta: 0,
  fragmentsDelta: 0, newCollectionKeys: [], unlockedDecorationKeys: [], ruleVersion: "test" });
const state = (lastRound = null, uid = 1) => ({ mode: "formal", available: true,
  serverNowMs: 100000, rules, collection: [], decorations: [], lastRound,
  profile: { accountId: uid, freeRemaining: 3, remainingPlays: 3, dailyLimit: 3,
    resetAtMs: 10000000, playsToday: 0, coinBalance: 0 } });
const flatten = (value) => Array.isArray(value) ? value.map(flatten).join("")
  : value && typeof value === "object" ? flatten(value.props?.children)
    : value == null || typeof value === "boolean" ? "" : String(value);
function loadModule(path, dependencies, globals) {
  const module = { exports: {} };
  const code = ts.transpileModule(readFileSync(new URL(`../${path}`, import.meta.url), "utf8"), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022, jsx: ts.JsxEmit.ReactJSX },
  }).outputText;
  runInNewContext(code, { ...globals, module, exports: module.exports, require(name) {
    if (/^\.\.\/assets\//.test(name)) return name;
    assert.ok(Object.hasOwn(dependencies, name), `禁止未隔离依赖：${name}`);
    return dependencies[name];
  } }, { filename: path });
  return module.exports;
}
function runtime({ practice = false, signedIn = true, ignoreAbort = false, platform = "web" } = {}) {
  let cursor = 0, dirty = true, alive = true, tree, now = 100000, timerId = 0, requestId = 0;
  const slots = [], effects = [], timers = new Map(), storage = new Map();
  const calls = { state: [], start: [], pick: [], open: [], rules: [], navigation: [], fullNavigation: [] };
  const session = { token: signedIn ? "isolated-test-token" : null };
  const route = { mode: practice ? "practice" : undefined };
  const unchanged = (a, b) => a && b && a.length === b.length && a.every((value, index) => Object.is(value, b[index]));
  const react = {
    useState(initial) { const index = cursor++; slots[index] ??= { value: typeof initial === "function" ? initial() : initial };
      return [slots[index].value, (next) => { assert.ok(alive, "卸载后更新状态");
        const value = typeof next === "function" ? next(slots[index].value) : next;
        if (!Object.is(value, slots[index].value)) { slots[index].value = value; dirty = true; }
      }]; },
    useRef(initial) { return slots[cursor++] ??= { current: initial }; },
    useCallback(callback, dependencies) { const index = cursor++;
      if (!unchanged(slots[index]?.dependencies, dependencies)) slots[index] = { dependencies, callback };
      return slots[index].callback; },
    useEffect(effect, dependencies) { const index = cursor++;
      if (!unchanged(slots[index]?.dependencies, dependencies)) { const cleanup = slots[index]?.cleanup;
        slots[index] = { dependencies }; effects.push(() => { cleanup?.(); slots[index].cleanup = effect(); });
      } },
  };
  const timer = (callback, delay, interval = false) => { const id = ++timerId; timers.set(id, { callback, at: now + delay, delay, interval }); return id; };
  const auth = (selector) => selector(session); auth.getState = () => session;
  const globals = {
    Date: class extends Date { static now() { return now; } }, AbortController, Headers,
    setTimeout: (callback, delay) => timer(callback, delay), clearTimeout: (id) => timers.delete(id),
    setInterval: (callback, delay) => timer(callback, delay, true), clearInterval: (id) => timers.delete(id),
    window: { location: { assign: (path) => calls.fullNavigation.push({ method: "assign", path }),
      replace: (path) => calls.fullNavigation.push({ method: "replace", path }) },
      localStorage: { getItem: (key) => storage.get(key) ?? null,
      setItem: (key, value) => storage.set(key, value), removeItem: (key) => storage.delete(key) } },
    crypto: { randomUUID: () => `isolated-request-${++requestId}` },
    fetch(url, init) { assert.ok(url.startsWith("https://isolated.invalid/api/pearl/"));
      const name = new URL(url).pathname.split("/").at(-1); assert.ok(Object.hasOwn(calls, name));
      return new Promise((resolve, reject) => {
        const call = { url, body: init.body ? JSON.parse(init.body) : null,
          resolve(data, status = 200) { resolve({ ok: status === 200, status,
            json: async () => ({ status, data }) }); } };
        calls[name].push(call);
        if (!ignoreAbort) init.signal.addEventListener("abort", () => reject(new Error("AbortError")), { once: true });
        if (name === "rules") call.resolve(rules);
      }); },
  };
  const http = loadModule("lib/api/legacyHttp.ts", { "@/constants/api": { API_BASE_URL: "https://isolated.invalid" }, "@/store/auth": { useAuthStore: auth } }, globals);
  const api = loadModule("lib/api/pearl.ts", { "@/lib/api/legacyHttp": http }, globals);
  const pending = loadModule("lib/game/pearlPending.ts", {}, globals);
  const element = (type, props, key) => ({ type, props: props ?? {}, key });
  class Value { constructor(value) { this.value = value; } setValue(value) { this.value = value; } stopAnimation() {} interpolate() { return this.value; } }
  const rn = Object.fromEntries(["ActivityIndicator", "Image", "ImageBackground", "ScrollView", "Text", "View"].map((name) => [name, name]));
  Object.assign(rn, { Platform: { OS: platform }, StyleSheet: { create: (styles) => styles, absoluteFillObject: {} },
    Easing: { bezier: () => undefined }, Animated: { Value, View: "AnimatedView", timing: () => ({ start() {}, stop() {} }) },
    AppState: { currentState: "active", addEventListener: () => ({ remove() {} }) },
    AccessibilityInfo: { isReduceMotionEnabled: () => Promise.resolve(false), addEventListener: () => ({ remove() {} }) } });
  const Page = loadModule("app/pearl.tsx", {
    react, "react/jsx-runtime": { jsx: element, jsxs: element, Fragment: "Fragment" }, "react-native": rn,
    "expo-router": { Stack: { Screen: "Screen" }, useRouter: () => ({ push: (path) => calls.navigation.push(path),
      replace: (path) => calls.navigation.push(path), setParams(params) { Object.assign(route, params); dirty = true; } }),
      useLocalSearchParams: () => route, useFocusEffect: (callback) => react.useEffect(callback, [callback]) },
    "expo-router/head": { default: "Head" }, "@/store/auth": { useAuthStore: auth }, "@/lib/api/pearl": api,
    "@/lib/game/pearlPending": pending, "expo-linear-gradient": { LinearGradient: "LinearGradient" },
    "react-native-safe-area-context": { useSafeAreaInsets: () => ({ top: 0, bottom: 0 }) },
    "@/components/pearl/海底舞台": { PearlStage: "PearlStage", PearlGem: "PearlGem" },
    "@/components/pearl/场景光效": { OceanEffects: "OceanEffects" },
    "@/components/pearl/动效组件": { MotionProvider: "MotionProvider", MotionPressable: "Pressable", RevealText: "RevealText" },
    "@/components/pearl/试玩随机": { generatePracticeBoard: () => ({ private: board(), public: board().map((shell) => ({ ...shell, pearlKey: null })) }) },
    "@/components/pearl/文案": { PearlLangContext: { Provider: "Language" }, translatePearl: (value) => value },
    "@/components/pearl/寻珠界面": { LagoonHeader: "LagoonHeader", LagoonNavigation: "LagoonNavigation",
      LagoonQuest: "LagoonQuest", TrimmedArt: "TrimmedArt", ACTION_BOX: {}, ACTION_ASPECT: 4 },
  }, globals).default;
  function render() { cursor = 0; dirty = false; tree = Page(); while (effects.length) effects.shift()(); }
  async function flush() { for (let count = 0; count < 20; count++) { if (dirty && alive) render(); await tick(); if (!dirty) return; } throw new Error("渲染未收敛"); }
  function nodes(value = tree, result = []) { if (Array.isArray(value)) value.forEach((child) => nodes(child, result));
    else if (value && typeof value === "object") { result.push(value); if (value.props?.children !== undefined) nodes(value.props.children, result); } return result; }
  const stage = () => nodes().find((node) => node.type === "PearlStage").props;
  return { calls, pending, session, route, stage, flush, nodes,
    text: () => flatten(tree), update: () => { dirty = true; },
    click(label) { const node = nodes().find((item) => item.type === "Pressable" && flatten(item).includes(label));
      assert.ok(node, `缺少按钮：${label}`); node.props.onPress(); },
    mount: async () => { render(); await flush(); },
    async advance(delay) { const until = now + delay; let count = 0;
      while (true) { const next = [...timers].filter(([, item]) => item.at <= until).sort((a, b) => a[1].at - b[1].at)[0];
        if (!next) break; assert.ok(++count < 1000, "计时器未收敛"); const [id, item] = next; now = item.at; timers.delete(id);
        if (item.interval) timers.set(id, { ...item, at: now + item.delay }); item.callback(); await flush(); }
      now = until; await flush(); },
    unmount() { slots.forEach((slot) => slot?.cleanup?.()); alive = false; },
  };
}
async function ready(options) { const page = runtime(options); await page.mount(); if (page.calls.state.length) {
  page.calls.state[0].resolve(state()); await page.flush(); } return page; }
async function accept(page, call, value, duplicate = false) {
  call.resolve({ accepted: true, duplicate, round: value, snapshot: state(value) }); await page.flush();
}

test("游客和已登录试玩：一次点蚌立即揭晓，不发任何正式请求", async () => {
  for (const signedIn of [false, true]) { const page = await ready({ practice: true, signedIn });
    page.stage().onSelect(2); await page.flush(); assert.equal(page.stage().phase, "selected");
    assert.deepEqual([...page.stage().selectedShells], [2]); assert.equal(page.stage().shells[2].pearlKey, "white");
    assert.equal(page.calls.state.length + page.calls.start.length + page.calls.pick.length, 0);
    await page.advance(1800); assert.equal(page.stage().phase, "all"); page.unmount(); }
});

test("正式一次点击：确认start后自动pick，同一局号且重复点击不加请求", async () => {
  const page = await ready(); page.stage().onSelect(2); page.stage().onSelect(4); await page.flush();
  assert.equal(page.calls.start.length, 1); const start = page.calls.start[0];
  await accept(page, start, round(start.body.requestId)); assert.equal(page.calls.pick.length, 1);
  assert.deepEqual(page.calls.pick[0].body, { requestId: start.body.requestId, selectedShell: 2, selectionStep: 1 });
  await accept(page, page.calls.pick[0], round(start.body.requestId, 2));
  assert.equal(page.stage().phase, "selected"); await page.advance(1800); assert.equal(page.stage().phase, "all");
  assert.equal(page.pending.readPendingExploration(1), undefined); assert.equal(page.calls.start.length, 1); page.unmount();
});

test("慢响应10秒仍接受原start，不被8秒超时丢弃或自动重发", async () => {
  const page = await ready(); page.stage().onSelect(1); await page.flush(); await page.advance(10000);
  assert.equal(page.calls.start.length, 1); const id = page.calls.start[0].body.requestId;
  await accept(page, page.calls.start[0], round(id)); assert.equal(page.calls.pick.length, 1);
  await accept(page, page.calls.pick[0], round(id, 1)); await page.advance(1800);
  assert.equal(page.stage().phase, "all"); page.unmount();
});

test("15秒fetch实际abort：错误可见，不自动多发；手动恢复原pick不另start", async () => {
  const page = await ready(); page.stage().onSelect(3); await page.flush(); const id = page.calls.start[0].body.requestId;
  await accept(page, page.calls.start[0], round(id)); await page.advance(15000);
  assert.equal(page.stage().phase, "idle"); assert.match(page.text(), /暫時沒打開，點蚌再試/);
  assert.doesNotMatch(page.text(), /Continue this exploration/);
  await page.advance(30000); assert.equal(page.calls.start.length, 1); assert.equal(page.calls.pick.length, 1);
  page.stage().onSelect(5); await page.flush(); assert.equal(page.calls.pick.length, 2);
  assert.deepEqual(page.calls.pick[1].body, page.calls.pick[0].body);
  await accept(page, page.calls.pick[1], round(id, 3)); await page.advance(1800);
  assert.equal(page.stage().phase, "all"); assert.equal(page.calls.start.length, 1); page.unmount();
});

test("state401显示重新登录且不会自动重试", async () => {
  const page = runtime(); await page.mount(); page.calls.state[0].resolve(null, 401); await page.flush();
  assert.match(page.text(), /Please sign in again/); page.click("重新登入");
  assert.deepEqual(page.calls.fullNavigation, [{ method: "assign", path: "/auth" }]);
  assert.equal(page.calls.navigation.length, 0);
  await page.advance(30000); assert.equal(page.calls.state.length, 1); page.unmount();
});

test("开蚌跨页使用目标HTML入口，原生端保留router，避免加载历史分块", async () => {
  for (const platform of ["web", "ios"]) {
    const page = await ready({ practice: true, signedIn: false, platform });
    page.nodes().find((node) => node.type === "LagoonHeader").props.onBack();
    if (platform === "web") {
      assert.deepEqual(page.calls.fullNavigation, [{ method: "replace", path: "/" }]);
      assert.equal(page.calls.navigation.length, 0);
    } else {
      assert.deepEqual(page.calls.navigation, ["/"]);
      assert.equal(page.calls.fullNavigation.length, 0);
    }
    page.unmount();
  }
});

test("start超时后同ID恢复：duplicate先查state，再pick原点位，不另开新局", async () => {
  const page = await ready(); page.stage().onSelect(1); await page.flush(); const first = page.calls.start[0];
  await page.advance(15000); page.stage().onSelect(5); await page.flush();
  assert.equal(page.calls.start.length, 2); assert.deepEqual(page.calls.start[1].body, first.body);
  const active = round(first.body.requestId); await accept(page, page.calls.start[1], active, true);
  assert.equal(page.calls.state.length, 2); assert.equal(page.calls.pick.length, 0);
  page.calls.state[1].resolve(state(active)); await page.flush();
  assert.equal(page.calls.pick.length, 1); assert.deepEqual(page.calls.pick[0].body,
    { requestId: first.body.requestId, selectedShell: 1, selectionStep: 1 });
  await accept(page, page.calls.pick[0], round(first.body.requestId, 1)); await page.advance(1800);
  assert.equal(page.stage().phase, "all"); assert.equal(page.calls.start.length, 2); page.unmount();
});

test("20秒最终guard使旧响应失效，恢复后迟到响应不覆盖已完成局", async () => {
  const page = await ready({ ignoreAbort: true }); page.stage().onSelect(4); await page.flush();
  const id = page.calls.start[0].body.requestId; await accept(page, page.calls.start[0], round(id));
  const late = page.calls.pick[0]; await page.advance(20000); assert.equal(page.stage().phase, "idle");
  assert.match(page.text(), /暫時沒打開，點蚌再試/); page.stage().onSelect(5); await page.flush();
  await accept(page, page.calls.pick[1], round(id, 4)); await page.advance(1800);
  late.resolve({ accepted: true, round: round(id), snapshot: state(round(id)) }); await page.flush();
  assert.equal(page.stage().phase, "all"); assert.deepEqual([...page.stage().selectedShells], [4]);
  assert.equal(page.pending.readPendingExploration(1), undefined); page.unmount();
});

test("切到新账号后旧响应不能覆盖新局，旧账号原请求仍可恢复", async () => {
  const page = await ready(); page.stage().onSelect(2); await page.flush(); const old = page.calls.start[0];
  page.session.token = "isolated-account-b"; page.update(); await page.flush();
  const newRound = round("new-account-round", 5); page.calls.state[1].resolve(state(newRound, 2)); await page.flush();
  await accept(page, old, round(old.body.requestId)); assert.equal(page.stage().phase, "all");
  assert.deepEqual([...page.stage().selectedShells], [5]); assert.equal(page.calls.pick.length, 0);
  assert.equal(page.pending.readPendingExploration(1).requestId, old.body.requestId); page.unmount();
});

test("新版双开规则保留：同局分两次选择，不新增开局也不吞掉第一只", async () => {
  const page = await ready(); page.stage().onSelect(2); await page.flush();
  const id = page.calls.start[0].body.requestId;
  await accept(page, page.calls.start[0], { ...round(id), maxSelections: 2 });
  const first = { ...round(id, 2), maxSelections: 2, status: "choosing" };
  await accept(page, page.calls.pick[0], first); await page.advance(1800);
  assert.equal(page.stage().phase, "idle");
  page.stage().onSelect(4); await page.flush();
  assert.deepEqual(page.calls.pick[1].body, { requestId: id, selectedShell: 4, selectionStep: 2 });
  await accept(page, page.calls.pick[1], { ...round(id, 4), maxSelections: 2, selectedShells: [2, 4] });
  await page.advance(1800);
  assert.equal(page.stage().phase, "all");
  assert.deepEqual([...page.stage().selectedShells], [2, 4]);
  assert.equal(page.calls.start.length, 1); assert.equal(page.calls.pick.length, 2);
  page.unmount();
});

test("冲突恢复服务端真正第一选，下一次点蚌只提交同局第二选", async () => {
  const page = runtime();
  page.pending.savePendingExploration(1, { action: "pick", requestId: "conflict-round-1", selectedShell: 1, selectionStep: 1 });
  await page.mount();
  const actual = { ...round("conflict-round-1", 3), status: "choosing", maxSelections: 2 };
  page.calls.state[0].resolve(state(actual)); await page.flush();
  page.stage().onSelect(5); await page.flush();
  assert.deepEqual(page.calls.pick[0].body, { requestId: actual.requestId, selectedShell: 1, selectionStep: 1 });
  page.calls.pick[0].resolve({ accepted: false, requestId: actual.requestId, reasonCode: "request_conflict", snapshot: state(actual) });
  await page.flush();
  assert.equal(page.pending.readPendingExploration(1), undefined);
  assert.deepEqual([...page.stage().selectedShells], [3]);
  assert.equal(page.calls.start.length, 0); assert.equal(page.calls.pick.length, 1);
  assert.doesNotMatch(page.text(), /暫時沒打開/);
  page.stage().onSelect(4); await page.flush();
  assert.deepEqual(page.calls.pick[1].body, { requestId: actual.requestId, selectedShell: 4, selectionStep: 2 });
  await accept(page, page.calls.pick[1], { ...round(actual.requestId, 4), maxSelections: 2, selectedShells: [3, 4] });
  await page.advance(1800); assert.equal(page.stage().phase, "all"); page.unmount();
});

test("冲突快照缺失、账号不符、局号不符或无真实选择，保留原动作且不自动重发", async () => {
  const id = "conflict-unproven";
  for (const snapshot of [undefined, state(round(id, 2), 2), state(round("different-round", 2)), state(round(id))]) {
    const page = runtime();
    const saved = { action: "pick", requestId: id, selectedShell: 1, selectionStep: 1 };
    page.pending.savePendingExploration(1, saved); await page.mount();
    page.calls.state[0].resolve(state(round(id))); await page.flush();
    page.stage().onSelect(5); await page.flush();
    page.calls.pick[0].resolve({ accepted: false, requestId: id, reasonCode: "request_conflict", snapshot }); await page.flush();
    assert.deepEqual(JSON.parse(JSON.stringify(page.pending.readPendingExploration(1))), saved);
    await page.advance(30000); assert.equal(page.calls.pick.length, 1); assert.equal(page.calls.start.length, 0);
    page.stage().onSelect(4); await page.flush();
    assert.deepEqual(page.calls.pick[1].body, page.calls.pick[0].body); page.unmount();
  }
});

test("旧无mode开局记录与已扣币局冲突，恢复服务器原局而非再扣一次", async () => {
  const page = runtime(); const id = "old-start-paid-round";
  page.pending.savePendingExploration(1, { action: "start", requestId: id, expectedPreviousRoundId: 0 });
  const paid = { ...round(id), playMode: "paid", pricingVersion: "pearl-paid-20260913-v2", currencyCode: "pearl_coin", coinsSpent: 1 };
  await page.mount(); page.calls.state[0].resolve(state(paid)); await page.flush();
  page.stage().onSelect(2); await page.flush();
  page.calls.start[0].resolve({ accepted: false, requestId: id, reasonCode: "request_conflict", snapshot: state(paid) }); await page.flush();
  assert.equal(page.pending.readPendingExploration(1), undefined); assert.equal(page.calls.pick.length, 0);
  page.stage().onSelect(4); await page.flush();
  assert.equal(page.calls.start.length, 1);
  assert.deepEqual(page.calls.pick[0].body, { requestId: id, selectedShell: 4, selectionStep: 1 }); page.unmount();
});

test("旧open待确认记录点蚌仍重发原open，已完成响应恢复真实结果", async () => {
  const page = runtime(); const id = "old-open-recovery";
  page.pending.savePendingExploration(1, { requestId: id, selectedShell: 2 });
  await page.mount(); page.calls.state[0].resolve(state()); await page.flush();
  page.stage().onSelect(5); await page.flush();
  assert.deepEqual(page.calls.open[0].body, { requestId: id, selectedShell: 2 });
  await accept(page, page.calls.open[0], round(id, 2), true);
  page.calls.state[1].resolve(state(round(id, 2))); await page.flush();
  assert.equal(page.stage().phase, "all"); assert.deepEqual([...page.stage().selectedShells], [2]);
  assert.equal(page.pending.readPendingExploration(1), undefined);
  assert.equal(page.calls.start.length + page.calls.pick.length, 0); page.unmount();
});

test("登录正式连续两局：再开一局只清场，不扣费、不入试玩；下次点蚌才start并pick", async () => {
  const page = await ready();
  const quest = () => page.nodes().find((node) => node.type === "LagoonQuest").props;
  for (const [position, index] of [2, 4].entries()) {
    page.stage().onSelect(index); await page.flush();
    assert.equal(page.stage().phase, "submitting");
    assert.equal(page.stage().selectedShell, index);
    assert.equal(quest().title, "正在開蚌…");
    const start = page.calls.start[position];
    assert.equal(page.calls.start.length, position + 1);
    assert.equal(start.body.expectedPreviousRoundId, position);
    const current = { ...round(start.body.requestId), id: position + 1 };
    await accept(page, start, current);
    assert.deepEqual(page.calls.pick[position].body, { requestId: start.body.requestId, selectedShell: index, selectionStep: 1 });
    await accept(page, page.calls.pick[position], { ...round(start.body.requestId, index), id: position + 1 });
    await page.advance(1800);
    assert.equal(quest().actionLabel, "再開一局");
    assert.equal(quest().practice, false);
    quest().onAction(); await page.flush();
    assert.equal(page.stage().phase, "idle");
    assert.equal(page.stage().shells, null);
    assert.equal(page.stage().selectedShell, null);
    assert.equal(page.calls.start.length, position + 1);
    assert.equal(page.calls.pick.length, position + 1);
    assert.equal(page.route.mode, undefined);
    assert.equal(page.pending.readPendingExploration(1), undefined);
  }
  assert.notEqual(page.calls.start[0].body.requestId, page.calls.start[1].body.requestId);
  assert.equal(quest().actionLabel, "免費試玩");
  quest().onAction(); await page.flush();
  assert.equal(page.route.mode, "practice");
  assert.equal(quest().practice, true);
  assert.equal(page.calls.start.length, 2);
  page.unmount();
});

test("同局待选刷新只恢复画面不POST，点一次才恢复原请求，双开保留第一选", async () => {
  for (const selectionStep of [1, 2]) {
    const page = runtime(); const id = `silent-pending-${selectionStep}`;
    const saved = { action: "pick", requestId: id, selectedShell: 4, selectionStep };
    page.pending.savePendingExploration(1, saved);
    const active = selectionStep === 1 ? round(id)
      : { ...round(id, 2), status: "choosing", maxSelections: 2 };
    await page.mount(); page.calls.state[0].resolve(state(active)); await page.flush();
    assert.equal(page.calls.pick.length, 0);
    assert.equal(page.calls.start.length, 0);
    assert.equal(page.stage().phase, "idle");
    assert.deepEqual([...page.stage().selectedShells], selectionStep === 1 ? [] : [2]);
    assert.doesNotMatch(page.text(), /暫時沒打開|earlier exploration needs confirmation|Connection interrupted/);
    await page.advance(30000);
    assert.equal(page.calls.pick.length, 0);
    page.stage().onSelect(1); await page.flush();
    assert.equal(page.stage().phase, "submitting");
    assert.equal(page.stage().selectedShell, 4);
    assert.equal(page.calls.pick.length, 1);
    assert.deepEqual(page.calls.pick[0].body, { requestId: id, selectedShell: 4, selectionStep });
    await accept(page, page.calls.pick[0], { ...round(id, 4), maxSelections: selectionStep,
      selectedShells: selectionStep === 1 ? [4] : [2, 4] });
    await page.advance(1800);
    assert.equal(page.stage().phase, "all");
    assert.equal(page.pending.readPendingExploration(1), undefined);
    page.unmount();
  }
});

test("恢复画面后手动请求实际超时才显示错误，保持原pick且不自动重发", async () => {
  const page = runtime(); const id = "silent-timeout-round";
  const saved = { action: "pick", requestId: id, selectedShell: 3, selectionStep: 1 };
  page.pending.savePendingExploration(1, saved);
  await page.mount(); page.calls.state[0].resolve(state(round(id))); await page.flush();
  assert.doesNotMatch(page.text(), /暫時沒打開/);
  assert.equal(page.calls.pick.length, 0);
  page.stage().onSelect(5); await page.flush();
  assert.equal(page.stage().selectedShell, 3);
  await page.advance(15000);
  assert.match(page.text(), /暫時沒打開/);
  assert.deepEqual(JSON.parse(JSON.stringify(page.pending.readPendingExploration(1))), saved);
  await page.advance(30000); assert.equal(page.calls.pick.length, 1);
  page.stage().onSelect(5); await page.flush();
  assert.equal(page.stage().selectedShell, 3);
  assert.deepEqual(page.calls.pick[1].body, page.calls.pick[0].body);
  assert.equal(page.calls.start.length, 0);
  page.unmount();
});

test("首次读取别局待选不自动POST，不伪报断网；点蚌仍恢复原局原选位", async () => {
  const page = runtime();
  const saved = { action: "pick", requestId: "saved-other-round", selectedShell: 1, selectionStep: 1 };
  page.pending.savePendingExploration(1, saved);
  await page.mount(); page.calls.state[0].resolve(state(round("current-other-round"))); await page.flush();
  assert.equal(page.calls.pick.length + page.calls.start.length, 0);
  assert.doesNotMatch(page.text(), /暫時沒打開|earlier exploration needs confirmation/);
  page.stage().onSelect(5); await page.flush();
  assert.deepEqual(page.calls.pick[0].body, { requestId: saved.requestId, selectedShell: 1, selectionStep: 1 });
  assert.equal(page.stage().selectedShell, 1);
  assert.equal(page.calls.start.length, 0);
  page.unmount();
});

test("同局权威完整终态直接恢复真实选位，不POST核对也不再被旧pending锁住", async () => {
  const page = runtime(); const id = "completed-pending-conflict";
  const saved = { action: "pick", requestId: id, selectedShell: 1, selectionStep: 1 };
  page.pending.savePendingExploration(1, saved);
  const actual = round(id, 3);
  await page.mount(); page.calls.state[0].resolve(state(actual)); await page.flush();
  assert.equal(page.stage().phase, "all");
  assert.deepEqual([...page.stage().selectedShells], [3]);
  assert.equal(page.pending.readPendingExploration(1), undefined);
  const quest = page.nodes().find((node) => node.type === "LagoonQuest").props;
  assert.equal(quest.actionLabel, "再開一局");
  quest.onAction(); await page.flush();
  assert.equal(page.stage().phase, "idle");
  assert.equal(page.stage().shells, null);
  assert.equal(page.calls.start.length, 0);
  assert.equal(page.calls.pick.length, 0);
  page.unmount();
});

test("过期开局有前局id证据才释放，缺失、未完成或未推进的快照保留请求", async () => {
  for (const [latest, clears] of [[{ ...round("newer-complete-round", 2), id: 10 }, true],
    [{ ...round("newer-choosing-round"), id: 10 }, false],
    [{ ...round("not-newer-round", 2), id: 8 }, false], [null, false]]) {
    const page = runtime(); const saved = { action: "start", requestId: "superseded-start-request", expectedPreviousRoundId: 8 };
    page.pending.savePendingExploration(1, saved); await page.mount();
    page.calls.state[0].resolve(state(latest)); await page.flush();
    assert.equal(page.pending.readPendingExploration(1) === undefined, clears);
    assert.equal(page.calls.state.length, 1);
    assert.equal(page.calls.start.length + page.calls.pick.length, 0);
    if (clears) assert.equal(page.nodes().find((node) => node.type === "LagoonQuest").props.actionLabel, "再開一局");
    page.unmount();
  }
});

test("异号pick必须读到保存动作之后的新终态才释放，整个恢复过程零POST", async () => {
  const page = runtime(); const saved = { action: "pick", requestId: "superseded-pick-request", selectedShell: 1, selectionStep: 1 };
  page.pending.savePendingExploration(1, saved); await page.mount();
  page.calls.state[0].resolve(state({ ...round("newer-complete-round", 2), id: 10 })); await page.flush();
  assert.equal(page.calls.state.length, 2);
  assert.equal(new URL(page.calls.state[0].url).search, "");
  assert.ok(new URL(page.calls.state[1].url).searchParams.get("_fresh"));
  assert.deepEqual(JSON.parse(JSON.stringify(page.pending.readPendingExploration(1))), saved);
  page.calls.state[1].resolve(state({ ...round("fresh-complete-round", 4), id: 11 })); await page.flush();
  assert.equal(page.pending.readPendingExploration(1), undefined);
  assert.deepEqual([...page.stage().selectedShells], [4]);
  assert.equal(page.stage().phase, "all");
  assert.equal(page.calls.start.length + page.calls.pick.length, 0);
  page.unmount();
});

test("旧GET完成后另一窗口写入新pick，二次GET仍未完成时不能清掉新动作", async () => {
  const page = runtime(); await page.mount();
  const saved = { action: "pick", requestId: "new-window-pick-request", selectedShell: 1, selectionStep: 1 };
  page.pending.savePendingExploration(1, saved);
  page.calls.state[0].resolve(state({ ...round("stale-read-complete", 2), id: 10 })); await page.flush();
  page.calls.state[1].resolve(state({ ...round(saved.requestId), id: 11 })); await page.flush();
  assert.deepEqual(JSON.parse(JSON.stringify(page.pending.readPendingExploration(1))), saved);
  assert.equal(page.stage().phase, "idle");
  assert.equal(page.calls.pick.length + page.calls.start.length, 0);
  page.unmount();
});

test("二次GET期间pending发生变化，旧终态不能清掉另一个窗口的新pick", async () => {
  const page = runtime(); const saved = { action: "pick", requestId: "first-pending-request", selectedShell: 1, selectionStep: 1 };
  page.pending.savePendingExploration(1, saved); await page.mount();
  const snapshot = state({ ...round("complete-before-new-pick", 2), id: 10 });
  page.calls.state[0].resolve(snapshot); await page.flush();
  page.pending.clearPendingExploration(1, saved);
  const newer = { action: "pick", requestId: "later-pending-request", selectedShell: 5, selectionStep: 1 };
  page.pending.savePendingExploration(1, newer);
  page.calls.state[1].resolve(snapshot); await page.flush();
  assert.deepEqual(JSON.parse(JSON.stringify(page.pending.readPendingExploration(1))), newer);
  assert.equal(page.calls.pick.length + page.calls.start.length, 0);
  page.stage().onSelect(4); await page.flush();
  assert.deepEqual(page.calls.pick[0].body, { requestId: newer.requestId, selectedShell: 5, selectionStep: 1 });
  page.unmount();
});

test("二次state缺失、账号不符、不可用、未完成或非法终态均不释放原pick", async () => {
  const saved = { action: "pick", requestId: "unproven-pending-request", selectedShell: 1, selectionStep: 1 };
  for (const fresh of [null, state(round("another-account-round", 2), 2),
    { ...state(round("unavailable-round", 2)), available: false }, state(round("different-choosing-round")),
    state({ ...round("invalid-complete-round", 2), maxSelections: 2, selectedShells: [2, 2] })]) {
    const page = runtime(); page.pending.savePendingExploration(1, saved); await page.mount();
    page.calls.state[0].resolve(state(round("old-complete-round", 2))); await page.flush();
    page.calls.state[1].resolve(fresh); await page.flush();
    assert.deepEqual(JSON.parse(JSON.stringify(page.pending.readPendingExploration(1))), saved);
    assert.equal(page.calls.pick.length + page.calls.start.length, 0);
    page.unmount();
  }
});

test("同局非法终态与异号legacy open不被当作权威完成，保留原恢复动作", async () => {
  const id = "invalid-terminal-request";
  for (const latest of [{ ...round(id, 3), id: 0 }, { ...round(id, 3), selectedShell: 4 },
    { ...round(id, 3), maxSelections: 2, selectedShells: [3, 3] },
    { ...round(id, 3), selectedShells: [6] }, { ...round(id, 3), selectedShells: [] },
    { ...round(id, 3), playMode: "paid", pricingVersion: "pearl-paid-20260913-v2", currencyCode: "reward_coin" }]) {
    const page = runtime(); const saved = { action: "pick", requestId: id, selectedShell: 1, selectionStep: 1 };
    page.pending.savePendingExploration(1, saved); await page.mount();
    page.calls.state[0].resolve(state(latest)); await page.flush();
    assert.deepEqual(JSON.parse(JSON.stringify(page.pending.readPendingExploration(1))), saved);
    assert.equal(page.calls.pick.length + page.calls.start.length, 0); page.unmount();
  }
  const page = runtime(); const legacy = { requestId: "legacy-unproven-request", selectedShell: 1 };
  page.pending.savePendingExploration(1, legacy); await page.mount();
  page.calls.state[0].resolve(state(round("different-complete-round", 2))); await page.flush();
  assert.deepEqual(JSON.parse(JSON.stringify(page.pending.readPendingExploration(1))), legacy);
  assert.equal(page.calls.state.length, 1);
  assert.equal(page.calls.open.length, 0); page.unmount();
});

test("实际rate_limited后有明确手动重试，按钮清场零请求，下次点蚌才再次开局", async () => {
  const page = await ready(); page.stage().onSelect(2); await page.flush();
  const first = page.calls.start[0];
  first.resolve({ accepted: false, requestId: first.body.requestId, reasonCode: "rate_limited", snapshot: state() }); await page.flush();
  assert.match(page.text(), /Let the water settle/);
  assert.equal(page.pending.readPendingExploration(1), undefined);
  page.click("再試一次"); await page.flush();
  assert.doesNotMatch(page.text(), /Let the water settle/);
  assert.equal(page.calls.state.length, 1); assert.equal(page.calls.start.length, 1); assert.equal(page.calls.pick.length, 0);
  page.stage().onSelect(4); await page.flush();
  assert.equal(page.calls.start.length, 2);
  assert.notEqual(page.calls.start[1].body.requestId, first.body.requestId);
  assert.equal(page.stage().selectedShell, 4); page.unmount();
});
