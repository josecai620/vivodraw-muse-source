import PageHeader from "@/components/shared/PageHeader";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import { commentOrder, getOrderDetail } from "@/lib/api/order";
import { type ApiRecord, isApiRecord, unwrapApiRecord } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Star } from "lucide-react-native";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Alert,
  Image,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

type ProductInfo = ApiRecord & {
  id?: number | string;
  image?: string;
  pic?: string;
  store_name?: string;
};

type ReviewCartPayload = ApiRecord & {
  id?: number | string;
  unique?: string;
  is_reply?: boolean | number | string;
  productInfo?: ProductInfo;
};

type ReviewCartItem = ApiRecord & {
  id?: number | string;
  cart_id?: number | string;
  productInfo?: ProductInfo;
  cart_info?: ReviewCartPayload;
};

type ReviewOrder = ApiRecord & {
  cartInfo?: ReviewCartItem[];
};

function getCartPayload(item: ReviewCartItem): ReviewCartPayload {
  return isApiRecord(item.cart_info) ? (item.cart_info as ReviewCartPayload) : item;
}

function getProductInfo(item: ReviewCartItem): ProductInfo {
  const productInfo = item.productInfo ?? item.cart_info?.productInfo;
  return isApiRecord(productInfo) ? (productInfo as ProductInfo) : {};
}

function isReviewed(value: unknown): boolean {
  return value === true || value === 1 || value === "1";
}

function getReviewItemKey(item: ReviewCartItem): string {
  const cartInfo = getCartPayload(item);
  const productInfo = getProductInfo(item);
  return String(
    cartInfo.unique ??
      item.id ??
      item.cart_id ??
      cartInfo.id ??
      productInfo.id ??
      productInfo.store_name ??
      productInfo.image ??
      "review-item",
  );
}

function getErrorMessage(err: unknown, fallback: string): string {
  return err instanceof Error ? err.message : fallback;
}

export default function OrderReviewScreen() {
  const { t } = useTranslation();
  const { orderId } = useLocalSearchParams<{ orderId: string }>();
  const router = useRouter();
  const queryClient = useQueryClient();

  const [scores, setScores] = useState<Record<string, { product: number; service: number }>>({});
  const [comments, setComments] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["orderDetail", orderId],
    queryFn: () => getOrderDetail(orderId ?? ""),
    enabled: !!orderId,
  });

  const commentMutation = useMutation({
    mutationFn: commentOrder,
  });

  const raw = unwrapApiRecord<ApiRecord>(data, {});
  const orderSource = isApiRecord(raw.orderInfo) ? raw.orderInfo : raw;
  const order = orderSource as ReviewOrder;
  const cartInfo = Array.isArray(order.cartInfo) ? order.cartInfo : [];

  const itemsToReview = cartInfo.filter((item) => {
    const info = getCartPayload(item);
    return Boolean(info.unique) && !isReviewed(info.is_reply);
  });

  const handleSetScore = (unique: string, type: "product" | "service", v: number) => {
    setScores((prev) => ({
      ...prev,
      [unique]: {
        ...(prev[unique] ?? { product: 5, service: 5 }),
        [type]: v,
      },
    }));
  };

  const handleSubmit = async () => {
    if (isSubmitting) return;
    for (const item of itemsToReview) {
      const info = getCartPayload(item);
      const unique = info.unique;
      if (!unique) continue;

      const sc = scores[unique] ?? { product: 5, service: 5 };
      if (sc.product < 1 || sc.service < 1) {
        Alert.alert(t("common.notice"), t("shopOrderReview.rateAll"));
        return;
      }
    }

    setIsSubmitting(true);
    try {
      for (const item of itemsToReview) {
        const info = getCartPayload(item);
        const unique = info.unique;
        if (!unique) continue;
        const sc = scores[unique] ?? { product: 5, service: 5 };
        const comment = (comments[unique] ?? "").trim() || t("shopOrderReview.defaultComment");
        await commentMutation.mutateAsync({
          unique,
          comment,
          product_score: sc.product,
          service_score: sc.service,
        });
      }
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["orderDetail", orderId] }),
        queryClient.invalidateQueries({ queryKey: ["orderList"] }),
      ]);
      Alert.alert(t("common.success"), t("shopOrderReview.submitted"), [
        { text: t("common.ok"), onPress: () => router.back() },
      ]);
    } catch (err) {
      Alert.alert(t("common.failed"), getErrorMessage(err, t("shopOrderReview.submitFailed")));
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!orderId) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("shopOrderReview.title")} />
        <View className="flex-1 items-center justify-center">
          <Text style={{ color: Colors.neutral[500] }}>{t("shopOrderReview.missingOrderId")}</Text>
        </View>
      </View>
    );
  }

  if (isLoading) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("shopOrderReview.title")} />
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      </View>
    );
  }

  const list = itemsToReview.length > 0 ? itemsToReview : cartInfo;
  const canSubmit = itemsToReview.length > 0;
  if (list.length === 0) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("shopOrderReview.title")} />
        <View className="flex-1 items-center justify-center px-6">
          <Text style={{ color: Colors.neutral[500] }}>{t("shopOrderReview.empty")}</Text>
        </View>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("shopOrderReview.title")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
        showsVerticalScrollIndicator={false}
      >
        {list.map((item) => {
          const info = getProductInfo(item);
          const cartInfoItem = getCartPayload(item);
          const unique = cartInfoItem.unique ?? getReviewItemKey(item);
          const isReply = isReviewed(cartInfoItem.is_reply);
          const img = info.image ?? info.pic ?? "";
          const name = info.store_name ?? t("shopOrderReview.productFallback");
          const sc = scores[unique] ?? { product: 5, service: 5 };

          return (
            <View
              key={getReviewItemKey(item)}
              className="bg-white rounded-2xl p-4 mb-4 border border-gray-100"
            >
              <View className="flex-row items-center gap-3 mb-3">
                <Image
                  source={{ uri: normalizeImageUrl(img) }}
                  style={{ width: s(56), height: s(56), borderRadius: s(12) }}
                  resizeMode="cover"
                />
                <Text
                  className="flex-1 font-medium"
                  style={{ color: Colors.neutral[800] }}
                  numberOfLines={2}
                >
                  {name}
                </Text>
              </View>

              {!isReply && (
                <>
                  <View className="mb-3">
                    <Text className="text-sm mb-2" style={{ color: Colors.neutral[600] }}>
                      {t("shopOrderReview.productScore")}
                    </Text>
                    <View className="flex-row gap-1">
                      {[1, 2, 3, 4, 5].map((v) => (
                        <Pressable key={v} onPress={() => handleSetScore(unique, "product", v)}>
                          <Star
                            size={s(28)}
                            color={sc.product >= v ? Colors.primary.DEFAULT : Colors.neutral[300]}
                            fill={sc.product >= v ? Colors.primary.DEFAULT : "transparent"}
                          />
                        </Pressable>
                      ))}
                    </View>
                  </View>
                  <View className="mb-3">
                    <Text className="text-sm mb-2" style={{ color: Colors.neutral[600] }}>
                      {t("shopOrderReview.serviceScore")}
                    </Text>
                    <View className="flex-row gap-1">
                      {[1, 2, 3, 4, 5].map((v) => (
                        <Pressable key={v} onPress={() => handleSetScore(unique, "service", v)}>
                          <Star
                            size={s(28)}
                            color={sc.service >= v ? Colors.primary.DEFAULT : Colors.neutral[300]}
                            fill={sc.service >= v ? Colors.primary.DEFAULT : "transparent"}
                          />
                        </Pressable>
                      ))}
                    </View>
                  </View>
                  <TextInput
                    value={comments[unique] ?? ""}
                    onChangeText={(t) => setComments((prev) => ({ ...prev, [unique]: t }))}
                    placeholder={t("shopOrderReview.placeholder")}
                    placeholderTextColor={Colors.neutral[400]}
                    multiline
                    style={{
                      padding: s(12),
                      borderRadius: s(12),
                      backgroundColor: Colors.neutral[50],
                      borderWidth: 1,
                      borderColor: Colors.neutral[200],
                      color: Colors.neutral[800],
                      fontSize: s(14),
                      minHeight: s(80),
                    }}
                  />
                </>
              )}
              {isReply && (
                <Text className="text-sm" style={{ color: Colors.neutral[500] }}>
                  {t("shopOrderReview.reviewed")}
                </Text>
              )}
            </View>
          );
        })}

        {canSubmit && (
          <Pressable
            onPress={handleSubmit}
            disabled={isSubmitting}
            style={{
              paddingVertical: s(14),
              borderRadius: s(12),
              alignItems: "center",
            }}
          >
            <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
            <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
            {isSubmitting ? (
              <ActivityIndicator color="#FFF" />
            ) : (
              <Text className="font-semibold" style={{ color: "#FFF", fontSize: s(16) }}>
                {t("shopOrderReview.submit")}
              </Text>
            )}
          </Pressable>
        )}
      </ScrollView>
    </View>
  );
}
