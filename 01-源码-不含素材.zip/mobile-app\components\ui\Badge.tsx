import React from "react";
import { View, Text } from "react-native";

interface BadgeProps {
  count?: number;
  dot?: boolean;
  color?: string;
  className?: string;
}

export default function Badge({
  count,
  dot = false,
  color = "bg-brand-red",
  className = "",
}: BadgeProps) {
  if (!dot && (!count || count <= 0)) return null;

  if (dot) {
    return (
      <View
        className={`absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full ${color} ${className}`}
      />
    );
  }

  const display = count && count > 99 ? "99+" : String(count);

  return (
    <View
      className={`absolute -top-2 -right-2 min-w-5 h-5 px-1 rounded-full ${color} items-center justify-center ${className}`}
    >
      <Text className="text-white text-xs font-bold">{display}</Text>
    </View>
  );
}
