import React from "react";
import { Dimensions, Pressable, View } from "react-native";
import { normalizeImageUrl } from "@/lib/utils";
import { CachedImage } from "@/components/shared";

interface HlSingleImageProps {
  props: {
    img?: string;
    link?: string;
    aspectRatio?: string; // "2:1" / "1:1" / "16:9"
  };
  onLink: (link: string) => void;
}

function parseRatio(r?: string): number {
  if (!r) return 2;
  const [w, h] = r.split(":").map(Number);
  if (!w || !h) return 2;
  return w / h;
}

export default function HlSingleImage({ props, onLink }: HlSingleImageProps) {
  if (!props.img) return null;
  const width = Dimensions.get("window").width;
  const height = Math.round(width / parseRatio(props.aspectRatio));
  const uri = normalizeImageUrl(props.img) || props.img;

  const Container: any = props.link ? Pressable : View;
  return (
    <Container
      onPress={() => props.link && onLink(props.link)}
      style={{ width, height }}
    >
      <CachedImage uri={uri} style={{ width, height }} />
    </Container>
  );
}
