import React from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { PageHeader } from "@/components/shared";
import { usePointsHelpList } from "@/hooks";

export default function PointsHelpScreen() {
  const router = useRouter();
  const { cid, title } = useLocalSearchParams<{ cid: string; title?: string }>();
  const currentCid = Number(cid ?? 1) || 1;
  const { data } = usePointsHelpList(currentCid);
  const list = (data as any)?.data?.lists ?? (data as any)?.lists ?? [];

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={title || "Points Help"} />
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="p-4 gap-2">
          <Pressable
            className="bg-white border border-gray-100 rounded-xl px-4 py-3 mb-2"
            onPress={() => router.push("/points/help-categories")}
          >
            <Text className="text-sm font-medium text-gray-700">Switch Category</Text>
          </Pressable>
          {(Array.isArray(list) ? list : []).map((item: any) => (
            <Pressable
              key={item?.id}
              className="bg-white border border-gray-100 rounded-xl p-4"
              onPress={() => router.push({ pathname: "/points/help-detail", params: { id: String(item?.id) } } as any)}
            >
              <Text className="text-sm font-semibold text-gray-900">{item?.title ?? "Help Article"}</Text>
              <Text className="text-xs text-gray-500 mt-1">{item?.add_time ?? ""}</Text>
            </Pressable>
          ))}
          {(!Array.isArray(list) || list.length === 0) && (
            <View className="bg-white border border-gray-100 rounded-xl p-6">
              <Text className="text-sm text-gray-500">No help articles yet</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}
