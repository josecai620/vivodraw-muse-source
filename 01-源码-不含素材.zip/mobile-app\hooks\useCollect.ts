import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getCollectList, addCollect, delCollect } from "@/lib/api/collect";
import { useAppStore } from "@/store/app";

export function useCollectList(page = 1) {
  return useQuery({
    queryKey: ["collectList", page],
    queryFn: () => getCollectList({ page, limit: 20 }),
  });
}

export function useAddCollect() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: addCollect,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["collectList"] });
      showToast("Added to wishlist!", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useDelCollect() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: delCollect,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["collectList"] });
      showToast("Removed from wishlist", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}
