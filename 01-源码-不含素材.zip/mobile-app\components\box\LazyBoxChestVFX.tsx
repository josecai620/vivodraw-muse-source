import React, { Suspense } from "react";
import { View, type ImageSourcePropType, type ViewStyle } from "react-native";
import { bs } from "@/lib/boxTheme";

type ChestVFXDensity = "hero" | "compact";

interface BoxChestVFXProps {
  image?: ImageSourcePropType;
  tier?: string;
  size?: number;
  density?: ChestVFXDensity;
  style?: ViewStyle;
}

const LazyVFX = React.lazy(async () => {
  const module = await import("./BoxChestVFX");
  return { default: module.BoxChestVFX };
});

function BoxChestFallback({ size = 132, style }: Pick<BoxChestVFXProps, "size" | "style">) {
  const stageSize = bs(size);
  return (
    <View
      pointerEvents="none"
      style={[
        {
          width: stageSize,
          height: stageSize,
          alignItems: "center",
          justifyContent: "center",
        },
        style,
      ]}
    />
  );
}

export function BoxChestVFX(props: BoxChestVFXProps) {
  return (
    <Suspense fallback={<BoxChestFallback size={props.size} style={props.style} />}>
      <LazyVFX {...props} />
    </Suspense>
  );
}
