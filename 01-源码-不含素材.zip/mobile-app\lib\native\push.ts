import Constants from "expo-constants";
import * as Device from "expo-device";
import * as Notifications from "expo-notifications";
/**
 * 推送通知 — 权限、token、本地通知
 *
 * 测试阶段：
 *   - registerForPush() 申请权限并拿 Expo push token，拿到后本地保存 + 控制台打印
 *   - 将来后端就绪，在 TODO(send-to-backend) 处把 token 上报 /api/user/device 注册
 *
 * 远程推送真正下发需要 dev build（Expo Go 无法收到远程推送，只能本地通知）。
 */
import { Platform } from "react-native";

import { getItem, setItem } from "@/lib/secure-storage";

const PUSH_TOKEN_KEY = "expo_push_token";

// 前台收到推送时也弹横幅 + 响声（不然默认只在后台才展示）
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export type PushRegisterResult =
  | { ok: true; token: string; isDevice: boolean }
  | { ok: false; reason: "not-device" | "denied" | "no-project-id" | string };

/**
 * 申请通知权限并获取 Expo push token。
 * 幂等：可多次调用。
 */
export async function registerForPush(): Promise<PushRegisterResult> {
  if (!Device.isDevice) {
    return { ok: false, reason: "not-device" };
  }

  // 安卓需要先建一个 channel 才能显示通知
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("default", {
      name: "default",
      importance: Notifications.AndroidImportance.DEFAULT,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#EF4444",
    });
  }

  const settings = await Notifications.getPermissionsAsync();
  let finalStatus = settings.status;
  if (finalStatus !== "granted") {
    const req = await Notifications.requestPermissionsAsync();
    finalStatus = req.status;
  }
  if (finalStatus !== "granted") {
    return { ok: false, reason: "denied" };
  }

  // Expo push token 需要 projectId（EAS 项目）
  const projectId =
    Constants.expoConfig?.extra?.eas?.projectId ??
    (Constants as unknown as { easConfig?: { projectId?: string } }).easConfig?.projectId;

  try {
    const tokenResp = await Notifications.getExpoPushTokenAsync(
      projectId ? { projectId } : undefined,
    );
    const token = tokenResp.data;
    await setItem(PUSH_TOKEN_KEY, token).catch(() => void 0);
    // TODO(send-to-backend): POST /api/user/device { token, platform: Platform.OS }
    console.log("[push] Expo push token:", token);
    return { ok: true, token, isDevice: true };
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    // 没配 projectId 时的典型错误
    if (msg.includes("projectId") || msg.includes("EAS")) {
      return { ok: false, reason: "no-project-id" };
    }
    return { ok: false, reason: msg };
  }
}

export async function getCachedPushToken(): Promise<string | null> {
  try {
    return await getItem(PUSH_TOKEN_KEY);
  } catch {
    return null;
  }
}

/** 触发一条本地通知（用于测试通知是否正常展示） */
export async function sendLocalNotification(
  title: string,
  body: string,
  data?: Record<string, unknown>,
): Promise<string> {
  return Notifications.scheduleNotificationAsync({
    content: { title, body, data: data ?? {} },
    trigger: null, // 立即
  });
}
