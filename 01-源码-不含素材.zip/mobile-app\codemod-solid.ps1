# codemod-solid.ps1
# Turn a SOLID teal JSX element (<Pressable>/<View> with inline backgroundColor teal or bg-[#04A8AE])
# into a raised surface: remove flat fill, inject an absolutely-positioned 3-stop teal gradient
# plus a top white gloss. Progress bars / selected dots / chips / ternary class / self-closing
# elements are skipped. StyleSheet.create entries are never matched (they have no JSX open tag).
# Usage: powershell -File codemod-solid.ps1 -Path <file> [-WhatIf]
param(
  [Parameter(Mandatory=$true)][string]$Path,
  [switch]$WhatIf
)
$utf8 = New-Object System.Text.UTF8Encoding($false)
$txt = [System.IO.File]::ReadAllText($Path)

function Get-Radius($inner) {
  if ($inner -match 'rounded-full') { return 999 }
  if ($inner -match 'rounded-3xl') { return 24 }
  if ($inner -match 'rounded-2xl') { return 16 }
  if ($inner -match 'rounded-xl') { return 12 }
  if ($inner -match 'rounded-lg') { return 8 }
  if ($inner -match 'rounded-md') { return 6 }
  if ($inner -match 'borderRadius:\s*s\((\d+)\)') { return [int]$Matches[1] }
  if ($inner -match 'borderRadius:\s*(\d+)') { return [int]$Matches[1] }
  return 12
}
$DIRMAP = @{
  'lr' = @('{{ x: 0, y: 0.5 }}','{{ x: 1, y: 0.5 }}');
  'rl' = @('{{ x: 1, y: 0.5 }}','{{ x: 0, y: 0.5 }}');
  'tb' = @('{{ x: 0.5, y: 0 }}','{{ x: 0.5, y: 1 }}');
  'bt' = @('{{ x: 0.5, y: 1 }}','{{ x: 0.5, y: 0 }}');
}

# match a JSX open tag for Pressable/View/TouchableOpacity up to the first '>' that is not part of '=>' or '/>'
$rx = [regex]'(?m)<(Pressable|View|TouchableOpacity)\b[\s\S]*?(?<![=\-/>])>'
$ms = $rx.Matches($txt)
$edits = New-Object System.Collections.ArrayList
$seq = 0
foreach ($m in $ms) {
  $inner = $m.Value
  $tag = $m.Groups[1].Value
  $hasTeal = ($inner -match 'backgroundColor:\s*Colors\.brand\.red' -or $inner -match 'backgroundColor:\s*"#04A8AE"' -or $inner -match 'bg-\[#04A8AE\]')
  if (-not $hasTeal) { continue }
  $reason = ''
  if ($inner -match '/5\b' -and $inner -match 'bg-\[#04A8AE\]/5') { $reason='tint-bg' }
  elseif ($inner -match '\?' -and $inner -match 'bg-\[#04A8AE\]') { $reason='ternary-class' }
  elseif ($inner -match 'width:\s*`') { $reason='progress-bar' }
  elseif ($inner -match 'w-2 h-2|w-5 h-5|h-2\b|height:\s*s\(2\)|height:\s*s\(5\)|height:\s*[28]\b') { $reason='tiny-indicator' }
  elseif ($inner -match 'px-2\.5 py-0\.5|px-2 py-1|px-2 py-0\.5' -or ($tag -eq 'View' -and $inner -match 'paddingVertical:\s*s\(4\)')) { $reason='chip' }
  if ($reason) { Write-Output ("  SKIP[{0}] @{1}: {2}" -f $reason,$m.Index,($inner -replace '\s+',' ').Substring(0,[Math]::Min(70,$inner.Length))); continue }

  $dir = if ($seq % 3 -eq 0) {'lr'} elseif ($seq % 3 -eq 1) {'tb'} else {'rl'}
  $seq++
  $R = Get-Radius $inner
  # indent = whitespace at line start of the match
  $lineStart = $txt.LastIndexOf("`n", $m.Index) + 1
  $indent = ''
  for ($k=$lineStart; $k -lt $m.Index -and $txt[$k] -eq ' '; $k++) { $indent += ' ' }
  $childIndent = $indent + '  '
  $d = $DIRMAP[$dir]
  $grad = '<LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start=' + $d[0] + ' end=' + $d[1] + ' style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: ' + $R + ' }} />'
  $gloss = '<LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: ' + $R + ' }} />'

  $newInner = $inner
  $newInner = [regex]::Replace($newInner, 'backgroundColor:\s*Colors\.brand\.red\s*,?\s*', '')
  $newInner = [regex]::Replace($newInner, 'backgroundColor:\s*"#04A8AE"\s*,?\s*', '')
  $newInner = [regex]::Replace($newInner, 'bg-\[#04A8AE\]\s?', '')
  # collapse a left-behind empty style object
  $newInner = $newInner -replace 'style=\{\{\s*,', 'style={{'
  $inject = "`n" + $childIndent + $grad + "`n" + $childIndent + $gloss
  $newInner = $newInner -replace '(?<![=\-/>])>$', ('>' + $inject)
  [void]$edits.Add([pscustomobject]@{ Start=$m.Index; Len=$m.Length; New=$newInner; Dir=$dir; R=$R })
  Write-Output ("  EDIT[{0} r{1}] @{2}: {3}" -f $dir,$R,$m.Index,($inner -replace '\s+',' ').Substring(0,[Math]::Min(70,$inner.Length)))
}
if ($WhatIf) { Write-Output ("{0}: would edit {1}" -f (Split-Path $Path -Leaf),$edits.Count); return }

# apply from end to start
for ($i=$edits.Count-1; $i -ge 0; $i--) {
  $e = $edits[$i]
  $txt = $txt.Substring(0,$e.Start) + $e.New + $txt.Substring($e.Start+$e.Len)
}
if ($edits.Count -gt 0) {
  # ensure TealGradient is imported from constants/theme (handle single-line import)
  if ($txt -notmatch 'TealGradient[,\s][^;]*from "@/constants/theme"') {
    $txt = [regex]::Replace($txt, 'import \{([^}]*)\} from "@/constants/theme"', 'import { TealGradient, $1 } from "@/constants/theme"', 1)
  }
  # ensure LinearGradient is imported
  if ($txt -notmatch 'from "expo-linear-gradient"') {
    $txt = [regex]::Replace($txt, '(import \{[^}]*\} from "react-native";)', "`$1`nimport { LinearGradient } from `"expo-linear-gradient`";", 1)
  }
  [System.IO.File]::WriteAllText($Path,$txt,$utf8)
}
Write-Output ("{0}: edited {1}" -f (Split-Path $Path -Leaf),$edits.Count)
