import PageHeader from "@/components/shared/PageHeader";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import { saveInvoice } from "@/lib/api/invoice";
import { useAppStore } from "@/store/app";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

export default function AddInvoiceScreen() {
  const router = useRouter();
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);

  const [headerType, setHeaderType] = useState<1 | 2>(1);
  const [drawerPhone, setDrawerPhone] = useState("");
  const [name, setName] = useState("");
  const [dutyNumber, setDutyNumber] = useState("");

  const mutate = useMutation({
    mutationFn: saveInvoice,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invoiceList"] });
      showToast(t("profileInvoice.saved"), "success");
      router.back();
    },
    onError: (error: unknown) =>
      showToast(getErrorMessage(error, t("profileInvoice.saveFailed")), "error"),
  });

  const handleSave = () => {
    if (!drawerPhone.trim()) {
      showToast(t("profileInvoice.phoneRequired"), "error");
      return;
    }
    if (!name.trim()) {
      showToast(t("profileInvoice.titleRequired"), "error");
      return;
    }
    if (headerType === 2 && !dutyNumber.trim()) {
      showToast(t("profileInvoice.taxRequired"), "error");
      return;
    }
    mutate.mutate({
      id: 0,
      header_type: headerType,
      type: 1,
      drawer_phone: drawerPhone.trim(),
      name: name.trim(),
      duty_number: headerType === 2 ? dutyNumber.trim() : "",
      is_default: 0,
    });
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-gray-50"
    >
      <PageHeader title={t("profileInvoice.addInvoice")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View className="mb-4">
          <Text className="text-sm font-medium mb-2" style={{ color: Colors.neutral[700] }}>
            {t("profileInvoice.invoiceType")}
          </Text>
          <View className="flex-row gap-3">
            <Pressable
              onPress={() => setHeaderType(1)}
              className={`flex-1 py-3 rounded-xl border-2 ${headerType === 1 ? "border-[#04A8AE] bg-brand-red-light" : "border-gray-200"}`}
            >
              <Text
                className="text-center font-medium"
                style={{ color: headerType === 1 ? Colors.brand.red : Colors.neutral[600] }}
              >
                {t("profileInvoice.personal")}
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setHeaderType(2)}
              className={`flex-1 py-3 rounded-xl border-2 ${headerType === 2 ? "border-[#04A8AE] bg-brand-red-light" : "border-gray-200"}`}
            >
              <Text
                className="text-center font-medium"
                style={{ color: headerType === 2 ? Colors.brand.red : Colors.neutral[600] }}
              >
                {t("profileInvoice.company")}
              </Text>
            </Pressable>
          </View>
        </View>

        <View className="mb-4">
          <Text className="text-sm font-medium mb-2" style={{ color: Colors.neutral[700] }}>
            {t("profileInvoice.phone")} *
          </Text>
          <TextInput
            className="bg-white border border-gray-200 rounded-xl px-4 py-3 text-base"
            placeholder={t("profileInvoice.phonePlaceholder")}
            placeholderTextColor={Colors.neutral[400]}
            value={drawerPhone}
            onChangeText={setDrawerPhone}
            keyboardType="phone-pad"
          />
        </View>

        <View className="mb-4">
          <Text className="text-sm font-medium mb-2" style={{ color: Colors.neutral[700] }}>
            {t("profileInvoice.titleName")} *
          </Text>
          <TextInput
            className="bg-white border border-gray-200 rounded-xl px-4 py-3 text-base"
            placeholder={
              headerType === 1 ? t("profileInvoice.personalName") : t("profileInvoice.companyName")
            }
            placeholderTextColor={Colors.neutral[400]}
            value={name}
            onChangeText={setName}
          />
        </View>

        {headerType === 2 && (
          <View className="mb-4">
            <Text className="text-sm font-medium mb-2" style={{ color: Colors.neutral[700] }}>
              {t("profileInvoice.taxId")} *
            </Text>
            <TextInput
              className="bg-white border border-gray-200 rounded-xl px-4 py-3 text-base"
              placeholder={t("profileInvoice.taxPlaceholder")}
              placeholderTextColor={Colors.neutral[400]}
              value={dutyNumber}
              onChangeText={setDutyNumber}
            />
          </View>
        )}

        <Pressable
          onPress={handleSave}
          disabled={mutate.isPending}
          className="mt-4 h-12 rounded-xl items-center justify-center"
          style={{ opacity: mutate.isPending ? 0.7 : 1 }}
        >
          <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
          <Text className="text-white font-semibold">
            {mutate.isPending ? t("profileInvoice.saving") : t("profileInvoice.save")}
          </Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
