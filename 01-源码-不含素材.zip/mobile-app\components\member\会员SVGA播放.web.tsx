import React, { useEffect, useRef, useState } from "react";
import { Asset } from "expo-asset";
import { Image as RNImage, type ImageSourcePropType } from "react-native";
import { Image as ExpoImage } from "expo-image";

type VideoItem = {
  videoSize: { width: number; height: number };
  FPS: number;
  frames: number;
};

type SvgaParser = { load: (url: string, ok: (item: VideoItem) => void, fail?: (err: Error) => void) => void };
type SvgaPlayer = {
  loops: number;
  clearsAfterStop: boolean;
  setContentMode: (mode: "Fill" | "AspectFill" | "AspectFit") => void;
  setClipsToBounds: (v: boolean) => void;
  setVideoItem: (item: VideoItem) => void;
  startAnimation: () => void;
  stopAnimation: (clear?: boolean) => void;
};

type SvgaApi = {
  Parser: new () => SvgaParser;
  Player: new (el: HTMLDivElement | HTMLCanvasElement | string) => SvgaPlayer;
};

const videoCache = new Map<string, Promise<VideoItem>>();
let apiPromise: Promise<SvgaApi | null> | null = null;

function pickApi(mod: unknown): SvgaApi | null {
  const rec = mod as Record<string, unknown> | null;
  const globalSvga = typeof window !== "undefined" ? (window as unknown as { SVGA?: unknown }).SVGA : undefined;
  const candidates = [rec, rec?.default, rec?.SVGA, globalSvga];
  for (const item of candidates) {
    const row = item as SvgaApi | undefined;
    if (row && typeof row.Parser === "function" && typeof row.Player === "function") return row;
  }
  return null;
}

function loadApi(): Promise<SvgaApi | null> {
  if (!apiPromise) {
    apiPromise = Promise.all([
      import("svgaplayerweb").catch(() => null),
      import("@/lib/vendor/svgaplayerweb").catch(() => null),
    ]).then(([a, b]) => pickApi(a) ?? pickApi(b));
  }
  return apiPromise;
}

function assetToUrl(mod: unknown): string {
  if (!mod && mod !== 0) return "";
  if (typeof mod === "string") return mod;
  try {
    const resolved = RNImage.resolveAssetSource(mod as number);
    if (resolved?.uri) return resolved.uri;
  } catch {
    /* ignore */
  }
  if (typeof mod === "number") {
    try {
      const asset = Asset.fromModule(mod);
      return asset.uri || asset.localUri || "";
    } catch {
      return "";
    }
  }
  if (typeof mod === "object") {
    const rec = mod as { uri?: string; default?: unknown };
    if (typeof rec.uri === "string") return rec.uri;
    if (rec.default) return assetToUrl(rec.default);
  }
  return "";
}

function loadVideo(url: string, api: SvgaApi): Promise<VideoItem> {
  const hit = videoCache.get(url);
  if (hit) return hit;
  const next = new Promise<VideoItem>((resolve, reject) => {
    const parser = new api.Parser();
    parser.load(url, resolve, (err) => reject(err || new Error("svga load fail")));
  });
  videoCache.set(url, next);
  return next;
}

async function ensureAssetUrl(mod: unknown): Promise<string> {
  if (typeof mod === "number") {
    try {
      const asset = Asset.fromModule(mod);
      if (!asset.downloaded) await asset.downloadAsync();
      return asset.localUri || asset.uri || assetToUrl(mod);
    } catch {
      return assetToUrl(mod);
    }
  }
  return assetToUrl(mod);
}

function prefetchBrowserImage(url: string) {
  if (!url || typeof window === "undefined") return;
  const img = new window.Image();
  img.decoding = "async";
  img.src = url;
  void ExpoImage.prefetch(url).catch(() => undefined);
}

async function mapPool<T>(items: T[], limit: number, work: (item: T) => Promise<void>) {
  let cursor = 0;
  const workers = Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
    while (cursor < items.length) {
      const item = items[cursor++];
      try {
        await work(item);
      } catch {
        /* 单个失败不影响其余预加载 */
      }
    }
  });
  await Promise.all(workers);
}

/** 进图库就拉静帧和动效，不要等用户点了才发加载。 */
export function preloadAvatarFrameAssets(
  items: { png?: ImageSourcePropType; svga?: number; bytes?: number }[] = [],
) {
  if (typeof window === "undefined" || !items.length) return;
  const stills = items.map((row) => row.png).filter(Boolean);
  const motions = [...items]
    .filter((row) => row.svga)
    .sort((a, b) => (a.bytes ?? 0) - (b.bytes ?? 0));
  void (async () => {
    await Promise.all(
      stills.map(async (png) => {
        const url = await ensureAssetUrl(png);
        prefetchBrowserImage(url);
      }),
    );
    const api = await loadApi();
    if (!api) return;
    await mapPool(motions, 3, async (row) => {
      const url = await ensureAssetUrl(row.svga);
      if (!url) return;
      prefetchBrowserImage(url);
      await loadVideo(url, api);
    });
  })();
}

/** 正方形铺满可见，只抠圆心。farthest-corner 才能保住四角神兽。 */
function holeMask(radius: number) {
  const r = Math.max(8, radius);
  return `radial-gradient(circle farthest-corner at 50% 50%, transparent ${r}px, #000 ${r + 1}px)`;
}

function holeMaskStyle(radius: number | null): React.CSSProperties {
  if (radius == null) {
    return {
      WebkitMaskImage: "none",
      maskImage: "none",
    };
  }
  const image = holeMask(radius);
  return {
    WebkitMaskImage: image,
    maskImage: image,
    WebkitMaskSize: "100% 100%",
    maskSize: "100% 100%",
    WebkitMaskRepeat: "no-repeat",
    maskRepeat: "no-repeat",
    WebkitMaskPosition: "center",
    maskPosition: "center",
  };
}

function clearHoleMask(el: HTMLElement) {
  el.style.webkitMaskImage = "none";
  el.style.maskImage = "none";
}

function applyHoleMask(el: HTMLElement, radius: number) {
  const image = holeMask(radius);
  el.style.webkitMaskImage = image;
  el.style.maskImage = image;
  el.style.webkitMaskSize = "100% 100%";
  el.style.maskSize = "100% 100%";
  el.style.webkitMaskRepeat = "no-repeat";
  el.style.maskRepeat = "no-repeat";
  el.style.webkitMaskPosition = "center";
  el.style.maskPosition = "center";
}

export function 会员SVGA播放({
  source,
  still,
  size,
  playing = true,
  cutout = 0.7,
}: {
  source?: number;
  still: ImageSourcePropType;
  size: number;
  scale?: number;
  playing?: boolean;
  cutout?: number;
}) {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const playerRef = useRef<SvgaPlayer | null>(null);
  const [live, setLive] = useState(false);
  const useHole = cutout > 0.02;
  const cut = useHole ? Math.max(0.34, Math.min(0.86, cutout)) : 0;
  const stillMask = holeMaskStyle(useHole ? (size * cut) / 2 : null);

  useEffect(() => {
    const hostNode = hostRef.current;
    setLive(false);
    if (!source || !playing) return undefined;
    let cancelled = false;
    let player: SvgaPlayer | null = null;
    const url = assetToUrl(source);
    loadApi()
      .then((api) => {
        if (!api || cancelled || !url) throw new Error("svga api/url missing");
        return loadVideo(url, api).then((video) => ({ api, video }));
      })
      .then(({ api, video }) => {
        const host = hostRef.current;
        const stage = stageRef.current;
        if (cancelled || !host || !stage) return;
        const vw = Math.max(1, video.videoSize?.width || size);
        const vh = Math.max(1, video.videoSize?.height || size);
        const fit = Math.min(size / vw, size / vh);
        stage.style.width = `${vw}px`;
        stage.style.height = `${vh}px`;
        stage.style.left = "50%";
        stage.style.top = "50%";
        stage.style.transform = `translate(-50%, -50%) scale(${fit})`;
        stage.style.transformOrigin = "center center";
        if (useHole) applyHoleMask(stage, (size * cut) / 2 / fit);
        else clearHoleMask(stage);
        host.style.width = `${vw}px`;
        host.style.height = `${vh}px`;
        player = new api.Player(host);
        player.loops = 0;
        player.clearsAfterStop = false;
        player.setContentMode("AspectFit");
        player.setClipsToBounds(false);
        player.setVideoItem(video);
        playerRef.current = player;
        player.startAnimation();
        if (!cancelled) setLive(true);
      })
      .catch(() => {
        if (!cancelled) setLive(false);
      });
    return () => {
      cancelled = true;
      playerRef.current = null;
      player?.stopAnimation(false);
      hostNode?.querySelectorAll("canvas").forEach((el) => el.parentElement?.removeChild(el));
    };
  }, [source, playing, size, cut, useHole]);

  return (
    <div
      style={{
        width: size,
        height: size,
        position: "relative",
        overflow: "visible",
        pointerEvents: "none",
      }}
    >
      {!live ? (
        <div
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            width: size,
            height: size,
            overflow: "visible",
            pointerEvents: "none",
            ...stillMask,
          }}
        >
          <ExpoImage
            source={still}
            cachePolicy="memory-disk"
            style={{ width: size, height: size }}
            contentFit="contain"
            pointerEvents="none"
          />
        </div>
      ) : null}
      {source && playing ? (
        <div
          ref={stageRef}
          style={{
            position: "absolute",
            overflow: "visible",
            pointerEvents: "none",
          }}
        >
          <div ref={hostRef} style={{ position: "relative", flexShrink: 0, overflow: "visible" }} />
        </div>
      ) : null}
    </div>
  );
}
