import PageHeader from "@/components/shared/PageHeader";
import { Colors, s } from "@/constants/theme";
import { type InvoiceItem, delInvoice, getInvoiceList, setDefaultInvoice } from "@/lib/api/invoice";
import { unwrapApiListField } from "@/lib/api/response";
import { useAppStore } from "@/store/app";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { FileText, Plus, Trash2 } from "lucide-react-native";
import React from "react";
import { useTranslation } from "react-i18next";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

function getInvoiceId(invoice: InvoiceItem) {
  return Number(invoice.id ?? invoice.invoice_id ?? 0) || 0;
}

function isDefaultInvoice(invoice: InvoiceItem) {
  return invoice.is_default === true || invoice.is_default === 1 || invoice.is_default === "1";
}

function getInvoiceName(invoice: InvoiceItem, fallback: string) {
  return invoice.name ?? invoice.header ?? invoice.title ?? fallback;
}

function getInvoiceTaxId(invoice: InvoiceItem) {
  return invoice.duty_number ?? invoice.duty_paragraph ?? "";
}

export default function InvoicesScreen() {
  const router = useRouter();
  const { t } = useTranslation();
  const queryClient = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);

  const { data, isLoading } = useQuery({
    queryKey: ["invoiceList"],
    queryFn: () => getInvoiceList(),
  });

  const delMutation = useMutation({
    mutationFn: delInvoice,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invoiceList"] });
      showToast(t("profileInvoice.deleted"), "success");
    },
    onError: (error: unknown) =>
      showToast(getErrorMessage(error, t("profileInvoice.deleteFailed")), "error"),
  });

  const setDefaultMutation = useMutation({
    mutationFn: setDefaultInvoice,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["invoiceList"] });
      showToast(t("profileInvoice.setDefaultDone"), "success");
    },
    onError: (error: unknown) =>
      showToast(getErrorMessage(error, t("profileInvoice.setDefaultFailed")), "error"),
  });

  const list = unwrapApiListField<InvoiceItem>(data, ["list", "data"]).filter(
    (invoice) => getInvoiceId(invoice) > 0,
  );

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("profileInvoice.myInvoices")} />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView
          className="flex-1"
          contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
          showsVerticalScrollIndicator={false}
        >
          {list.length === 0 ? (
            <View className="py-12 items-center">
              <FileText size={s(48)} color={Colors.neutral[300]} />
              <Text className="mt-3 text-center" style={{ color: Colors.neutral[500] }}>
                {t("profileInvoice.empty")}
              </Text>
            </View>
          ) : (
            list.map((inv) => {
              const id = getInvoiceId(inv);
              const name = getInvoiceName(inv, t("profileInvoice.fallback"));
              const phone = inv.drawer_phone ?? "";
              const duty = getInvoiceTaxId(inv);
              const isDefault = isDefaultInvoice(inv);
              const actionDisabled = delMutation.isPending || setDefaultMutation.isPending;

              return (
                <View key={id} className="bg-white rounded-2xl p-4 mb-3 border border-gray-100">
                  <View className="flex-row items-start justify-between">
                    <View className="flex-1">
                      <Text
                        className="font-semibold"
                        style={{ color: Colors.neutral[800] }}
                        numberOfLines={2}
                      >
                        {name}
                      </Text>
                      {phone ? (
                        <Text className="text-sm mt-1" style={{ color: Colors.neutral[500] }}>
                          {phone}
                        </Text>
                      ) : null}
                      {duty ? (
                        <Text className="text-xs mt-1" style={{ color: Colors.neutral[400] }}>
                          {t("profileInvoice.taxLabel", { tax: duty })}
                        </Text>
                      ) : null}
                      {isDefault && (
                        <View
                          className="mt-2 px-2 py-0.5 self-start rounded"
                          style={{ backgroundColor: `${Colors.brand.red}20` }}
                        >
                          <Text
                            className="text-xs font-semibold"
                            style={{ color: Colors.brand.red }}
                          >
                            {t("profileInvoice.default")}
                          </Text>
                        </View>
                      )}
                    </View>
                    <View className="flex-row gap-2">
                      {!isDefault && (
                        <Pressable
                          disabled={actionDisabled}
                          onPress={() => setDefaultMutation.mutate(id)}
                          className="p-2"
                        >
                          <Text className="text-xs font-medium" style={{ color: Colors.brand.red }}>
                            {t("profileInvoice.setDefault")}
                          </Text>
                        </Pressable>
                      )}
                      <Pressable
                        onPress={() => router.push(`/profile/invoices/edit?id=${id}`)}
                        className="p-2"
                      >
                        <Text
                          className="text-xs font-medium"
                          style={{ color: Colors.neutral[600] }}
                        >
                          {t("profileInvoice.edit")}
                        </Text>
                      </Pressable>
                      <Pressable
                        disabled={actionDisabled}
                        onPress={() => delMutation.mutate(id)}
                        className="p-2"
                      >
                        <Trash2 size={s(18)} color={Colors.neutral[400]} />
                      </Pressable>
                    </View>
                  </View>
                </View>
              );
            })
          )}

          <Pressable
            onPress={() => router.push("/profile/invoices/add")}
            className="mt-4 flex-row items-center justify-center gap-2 h-12 rounded-xl border-2 border-dashed"
            style={{ borderColor: Colors.brand.red }}
          >
            <Plus size={s(20)} color={Colors.brand.red} />
            <Text className="font-semibold" style={{ color: Colors.brand.red }}>
              {t("profileInvoice.addInvoice")}
            </Text>
          </Pressable>
        </ScrollView>
      )}
    </View>
  );
}
