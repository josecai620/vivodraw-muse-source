
// components/home/FeaturedDeal.tsx
// 特色优惠大卡片

import React from 'react';
import { View, Text, Pressable, Image } from 'react-native';
import { ArrowRight, Star, Clock } from 'lucide-react-native';
import TealSurface from '@/components/ui/TealSurface';

export default function FeaturedDeal() {
  return (
    <View className="px-6 py-16">
      {/* 标题区域 */}
      <View className="items-center mb-10">
        <Text className="text-4xl font-bold text-gray-700 mb-2">
          Featured Deal
        </Text>
        <Text className="text-lg text-gray-500">
          Don't miss out on today's special offer
        </Text>
      </View>
      
      {/* 特色卡片 */}
      <View className="bg-white rounded-3xl border border-gray-100 p-12 flex-row gap-12">
        {/* 左侧图片 */}
        <View className="flex-1">
          <View className="rounded-2xl overflow-hidden">
            <Image
              source={{ uri: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80' }}
              className="w-full h-96"
              resizeMode="cover"
            />
            {/* 折扣标签 */}
            <View className="absolute top-4 right-4 bg-brand-red px-6 py-3 rounded-lg">
              <Text className="text-white text-lg font-bold">-40% OFF</Text>
            </View>
          </View>
        </View>
        
        {/* 右侧信息 */}
        <View className="flex-1 justify-center">
          {/* 分类标签 */}
          <View className="bg-gray-50 px-4 py-2 rounded-md self-start mb-4">
            <Text className="text-gray-500 text-sm font-bold uppercase tracking-wide">
              Accessories
            </Text>
          </View>
          
          {/* 标题 */}
          <Text className="text-3xl font-bold text-gray-700 mb-4">
            Premium Smart Watch
          </Text>
          
          {/* 描述 */}
          <Text className="text-base text-gray-500 leading-6 mb-6">
            Advanced fitness tracking, heart rate monitor, and 7-day battery life. 
            Water-resistant design perfect for any lifestyle.
          </Text>
          
          {/* 评分 */}
          <View className="flex-row items-center gap-2 mb-6">
            <View className="flex-row gap-1">
              {[1, 2, 3, 4, 5].map((i) => (
                <Star key={i} size={18} color="#171A1A" fill="#171A1A" />
              ))}
            </View>
            <Text className="text-sm font-semibold text-gray-500">
              5.0 (1,234 reviews)
            </Text>
          </View>
          
          {/* 价格 */}
          <View className="flex-row items-baseline gap-3 mb-6">
            <Text className="text-5xl font-bold text-brand-red">$179</Text>
            <Text className="text-2xl text-gray-400 line-through">$299</Text>
            <Text className="text-base font-bold text-teal-500">Save $120</Text>
          </View>
          
          {/* 倒计时 */}
          <View className="bg-neutral-50 border border-dashed border-teal-500 rounded-xl p-5 mb-8 flex-row items-center gap-4">
            <Text className="text-base font-bold text-gray-700">Ends in:</Text>
            <View className="flex-row items-center gap-2">
              <View className="items-center">
                <Text className="text-2xl font-bold text-brand-red">12</Text>
                <Text className="text-xs text-gray-500 mt-1">Hours</Text>
              </View>
              <Text className="text-2xl font-bold text-gray-700">:</Text>
              <View className="items-center">
                <Text className="text-2xl font-bold text-brand-red">34</Text>
                <Text className="text-xs text-gray-500 mt-1">Mins</Text>
              </View>
              <Text className="text-2xl font-bold text-gray-700">:</Text>
              <View className="items-center">
                <Text className="text-2xl font-bold text-brand-red">56</Text>
                <Text className="text-xs text-gray-500 mt-1">Secs</Text>
              </View>
            </View>
          </View>
          
          {/* 按钮 */}
          <Pressable className="h-14 flex-row" style={({ pressed }) => ({ transform: [{ scale: pressed ? 0.97 : 1 }] })}>
          <TealSurface direction="rl" radius={12} style={{ height: 56, flex: 1 }} contentStyle={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <Text className="text-white text-lg font-bold">Claim This Deal</Text>
            <ArrowRight size={20} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
          </TealSurface>
        </Pressable>
        </View>
      </View>
    </View>
  );
}
