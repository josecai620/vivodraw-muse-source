/**
 * 积分揭晓色调切换组件（已并入全站方向 C：teal hero 上的白色玻璃钮）
 */
import React from "react";
import { Pressable, View } from "react-native";
import { Moon, Sun } from "lucide-react-native";
import { useRevealColorScheme } from "@/contexts/RevealColorSchemeContext";

export function RevealColorSchemePicker() {
  const { isBlackTheme, toggleTheme } = useRevealColorScheme();

  return (
    <Pressable
      onPress={toggleTheme}
      hitSlop={{ top: 12, right: 16, bottom: 12, left: 12 }}
      className="w-10 h-10 rounded-full items-center justify-center"
      style={{
        backgroundColor: "rgba(255, 255, 255, 0.18)",
        borderWidth: 1,
        borderColor: "rgba(255, 255, 255, 0.28)",
      }}
    >
      {isBlackTheme ? (
        <Sun size={20} color="#FFFFFF" />
      ) : (
        <Moon size={20} color="#FFFFFF" />
      )}
    </Pressable>
  );
}
