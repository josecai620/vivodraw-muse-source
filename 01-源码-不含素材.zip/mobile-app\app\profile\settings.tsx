import PageHeader from "@/components/shared/PageHeader";
import { Colors } from "@/constants/theme";
import { useLanguage } from "@/hooks/useLanguage";
import { logout as apiLogout } from "@/lib/api/user";
import { useAuthStore } from "@/store/auth";
import { useRouter } from "expo-router";
import { Bell, ChevronRight, Globe, LogOut, Shield, UserX } from "lucide-react-native";
import React from "react";
import { useTranslation } from "react-i18next";
import { Alert, Pressable, ScrollView, Text, View } from "react-native";

export default function SettingsScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const storeLogout = useAuthStore((s) => s.logout);
  const { currentLanguage, languages } = useLanguage();

  const currentLangLabel =
    languages.find((l) => l.code === currentLanguage)?.nativeLabel ?? "English";

  const handleSignOut = () => {
    Alert.alert(t("settings.signOutTitle"), t("settings.signOutConfirm"), [
      { text: t("settings.cancel"), style: "cancel" },
      {
        text: t("settings.signOut"),
        style: "destructive",
        onPress: async () => {
          try {
            await apiLogout();
          } catch {}
          storeLogout();
          router.replace("/auth");
        },
      },
    ]);
  };

  const sections = [
    {
      title: t("settings.general"),
      items: [
        {
          icon: Bell,
          label: t("settings.notifications"),
          onPress: () => router.push("/profile/notifications"),
        },
        {
          icon: Globe,
          label: t("settings.language"),
          value: currentLangLabel,
          onPress: () => router.push("/profile/language"),
        },
      ],
    },
    {
      title: t("settings.security"),
      items: [
        {
          icon: Shield,
          label: t("settings.changePassword"),
          onPress: () => router.push("/profile/change-password"),
        },
        {
          icon: UserX,
          label: t("settings.deleteAccount"),
          danger: true,
          onPress: () => router.push("/profile/delete-account"),
        },
      ],
    },
  ];

  return (
    <View className="flex-1 bg-neutral-50">
      <PageHeader title={t("settings.title")} />

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {sections.map((section) => (
          <View key={section.title} className="mt-6">
            <Text className="text-xs font-semibold text-neutral-400 uppercase px-6 mb-2">
              {section.title}
            </Text>
            <View className="mx-4 bg-white rounded-2xl overflow-hidden">
              {section.items.map((item, i) => (
                <Pressable
                  key={item.label}
                  className={`flex-row items-center px-5 py-4 ${i < section.items.length - 1 ? "border-b border-neutral-50" : ""} active:bg-neutral-50`}
                  onPress={item.onPress}
                >
                  <item.icon size={20} color={"danger" in item && item.danger ? Colors.error : Colors.neutral[500]} />
                  <Text className={`flex-1 ml-4 text-base ${"danger" in item && item.danger ? "text-red-500 font-semibold" : "text-neutral-700"}`}>{item.label}</Text>
                  {"value" in item && item.value ? (
                    <Text className="text-sm text-neutral-400 mr-2">{item.value}</Text>
                  ) : null}
                  <ChevronRight size={18} color={Colors.neutral[300]} />
                </Pressable>
              ))}
            </View>
          </View>
        ))}

        <Pressable
          className="mx-4 mt-8 mb-10 bg-white rounded-2xl flex-row items-center justify-center py-4 active:bg-neutral-50"
          onPress={handleSignOut}
        >
          <LogOut size={20} color={Colors.error} />
          <Text className="ml-2 text-base font-semibold" style={{ color: Colors.error }}>
            {t("settings.signOut")}
          </Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}
