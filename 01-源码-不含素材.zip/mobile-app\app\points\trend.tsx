import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from "react-native";
import { Image } from "expo-image";
import Svg, { Circle, Polyline } from "react-native-svg";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { PageHeader } from "@/components/shared";
import { Colors } from "@/constants/theme";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useAddPointsCart, useDetailLshqz, usePointsProductDetail } from "@/hooks";
import { openCloudBuyCartList, rememberPendingCartItem } from "@/lib/points/openCloudBuyCart";
import { useAuthStore } from "@/store/auth";
import {
  cloudBuyShares,
  collectImageUrls,
  luckyPos,
  mapKaijiangRow,
  toNum,
  toRecordList,
  type CloudBuyPeriod,
} from "@/lib/points/cloudBuyParse";

const JOIN_TEAL = Colors.primary.DEFAULT;
const LIMITS = [20, 15, 10, 5] as const;

export default function CloudBuyTrendScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const { id } = useLocalSearchParams<{ id: string }>();
  const productId = toNum(id);
  const isLoggedIn = useAuthStore((st) => st.isLoggedIn);
  const [limit, setLimit] = useState<(typeof LIMITS)[number]>(20);
  const [qty, setQty] = useState("1");

  const { data: detailData, isLoading } = usePointsProductDetail(productId);
  const { data: lshqzData } = useDetailLshqz(productId, 1, 20);
  const addToCart = useAddPointsCart();

  const detail = (detailData as any)?.data?.detail ?? (detailData as any)?.data ?? (detailData as any) ?? {};
  const storeInfo = detail?.storeInfo ?? detail;
  const name = String(storeInfo?.store_name ?? storeInfo?.title ?? "");
  const thumb = collectImageUrls(storeInfo?.image, storeInfo?.slider_image)[0] || "";
  const valueLabel = toNum(storeInfo?.ot_price ?? storeInfo?.cost ?? storeInfo?.price, 0);
  const { total: totalNeed, sold: joined, remain } = cloudBuyShares(storeInfo);
  const barPct = totalNeed > 0 ? Math.max(2, Math.min(100, (joined / totalNeed) * 100)) : 0;

  const rows = useMemo(() => {
    const list = toRecordList(lshqzData)
      .map((row) => mapKaijiangRow(row, productId))
      .filter(Boolean) as CloudBuyPeriod[];
    return list.slice(0, limit);
  }, [lshqzData, productId, limit]);

  const chartValues = useMemo(
    () => [...rows].reverse().map((row) => luckyPos(row.unique)),
    [rows],
  );

  const onOrder = () => {
    if (!isLoggedIn) {
      router.push("/auth");
      return;
    }
    const num = Math.max(1, Math.floor(toNum(qty, 1)));
    rememberPendingCartItem({
      id: 0,
      productId,
      name,
      image: thumb,
      num,
      bianhao: "",
      remain,
      totalNeed,
    });
    addToCart.mutate(
      { productId, cartNum: num },
      { onSettled: () => openCloudBuyCartList(router) },
    );
  };

  const setRate = (rate: number) => {
    const n = Math.max(1, Math.ceil(remain * rate));
    setQty(String(n));
  };

  const chartH = Math.max(180, Math.round(width * 0.48));
  const chartW = Math.max(280, width - 24);

  if (isLoading) {
    return (
      <View className="flex-1 bg-white">
        <PageHeader title={t("pointsMall.trendChart")} />
        <ActivityIndicator style={{ marginTop: 40 }} color={JOIN_TEAL} />
      </View>
    );
  }

  return (
    <View className="flex-1" style={{ backgroundColor: "#f4f4f4" }}>
      <PageHeader title={t("pointsMall.trendChart")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 120 }}
      >
        <Pressable
          className="bg-white flex-row px-3 py-3"
          onPress={() => router.push({ pathname: "/points/product", params: { id: String(productId) } } as never)}
        >
          {thumb ? (
            <Image source={thumb} style={{ width: 86, height: 86, borderRadius: 4 }} contentFit="cover" />
          ) : (
            <View style={{ width: 86, height: 86, backgroundColor: "#eee" }} />
          )}
          <View className="flex-1 ml-3">
            <Text className="text-sm font-semibold text-gray-900" numberOfLines={2}>
              {name}
            </Text>
            <Text className="text-xs text-gray-500 mt-1">
              {t("pointsMall.valueLabel")}：{valueLabel}
            </Text>
            <View className="h-1.5 rounded-full bg-gray-100 overflow-hidden mt-2">
              <View className="h-full" style={{ width: `${barPct}%`, backgroundColor: JOIN_TEAL }} />
            </View>
            <View className="flex-row justify-between mt-1">
              <Text className="text-[10px]" style={{ color: JOIN_TEAL }}>
                {joined} {t("pointsMall.joined")}
              </Text>
              <Text className="text-[10px] text-gray-500">
                {totalNeed} {t("pointsMall.totalNeed")}
              </Text>
              <Text className="text-[10px]" style={{ color: Colors.primary.dark }}>
                {remain} {t("pointsMall.remain")}
              </Text>
            </View>
          </View>
        </Pressable>

        <View className="flex-row flex-wrap px-3 py-3" style={{ gap: 8 }}>
          {LIMITS.map((n) => {
            const on = n === limit;
            return (
              <Pressable
                key={n}
                onPress={() => setLimit(n)}
                style={{
                  width: 72,
                  height: 30,
                  borderRadius: 5,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: on ? JOIN_TEAL : "#fff",
                  borderWidth: 1,
                  borderColor: JOIN_TEAL,
                }}
              >
                <Text style={{ color: on ? "#fff" : "#111", fontSize: 12 }}>
                  {t("pointsMall.recentNPeriods", { n })}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <View className="bg-white mx-2 mb-3 px-2 py-2">
          <Text className="text-sm font-semibold text-gray-800 mb-1 px-1">
            {t("pointsMall.trendHint")}
          </Text>
          {chartValues.length === 0 ? (
            <Text className="text-xs text-gray-400 py-8 text-center">{t("pointsMall.noJoinRecords")}</Text>
          ) : (
            <TrendLine values={chartValues} width={chartW} height={chartH} />
          )}
        </View>

        <View className="bg-white mx-2">
          <View className="flex-row bg-[#eef3f7] py-2">
            {[
              t("pointsMall.colPeriod"),
              t("pointsMall.colWinner"),
              t("pointsMall.luckyCode"),
              t("pointsMall.colPos"),
              t("pointsMall.colBuyCount"),
            ].map((h) => (
              <Text key={h} className="flex-1 text-center text-[11px] text-gray-600">
                {h}
              </Text>
            ))}
          </View>
          {rows.map((row) => (
            <Pressable
              key={`${row.kaijiangId}-${row.bianhao}`}
              className="flex-row py-2 border-b border-gray-100"
              onPress={() =>
                router.push({
                  pathname: "/points/product",
                  params: {
                    id: String(productId),
                    bianhao: row.bianhao,
                    kaijiang: String(row.kaijiangId),
                  },
                } as never)
              }
            >
              <Text className="flex-1 text-center text-[11px] text-gray-700">{row.bianhao}</Text>
              <Text className="flex-1 text-center text-[11px] text-gray-700" numberOfLines={1}>
                {row.nickname || t("pointsMall.anonymous")}
              </Text>
              <Text className="flex-1 text-center text-[11px]" style={{ color: Colors.primary.dark }}>
                {row.unique || "-"}
              </Text>
              <Text className="flex-1 text-center text-[11px] text-gray-700">{luckyPos(row.unique) || "-"}</Text>
              <Text className="flex-1 text-center text-[11px] text-gray-700">{row.shares || "-"}</Text>
            </Pressable>
          ))}
        </View>
      </ScrollView>

      <View
        style={{
          position: "absolute",
          left: 0,
          right: 0,
          bottom: pointsMallTabPaddingBottom(insets.bottom),
          backgroundColor: "#fff",
          borderTopWidth: 1,
          borderTopColor: "#eee",
        }}
      >
        <View className="flex-row justify-around py-2">
          {[
            { label: "1/2", rate: 0.5 },
            { label: "1/3", rate: 1 / 3 },
            { label: "1/4", rate: 0.25 },
            { label: "1/5", rate: 0.2 },
            { label: t("pointsMall.buyAll"), rate: 1 },
          ].map((item) => (
            <Pressable
              key={item.label}
              onPress={() => setRate(item.rate)}
              style={{
                backgroundColor: JOIN_TEAL,
                paddingHorizontal: 10,
                paddingVertical: 4,
                borderRadius: 8,
              }}
            >
              <Text className="text-white text-xs">{item.label}</Text>
            </Pressable>
          ))}
        </View>
        <View className="flex-row" style={{ height: 56, borderTopWidth: 1, borderTopColor: JOIN_TEAL }}>
          <TextInput
            value={qty}
            onChangeText={(v) => setQty(v.replace(/[^\d]/g, "") || "1")}
            keyboardType="number-pad"
            style={{ flex: 1, textAlign: "center", fontSize: 20, color: JOIN_TEAL }}
          />
          <Pressable
            onPress={onOrder}
            style={{ flex: 1, backgroundColor: JOIN_TEAL, alignItems: "center", justifyContent: "center" }}
          >
            <Text className="text-white text-base font-bold">{t("pointsMall.orderNow")}</Text>
          </Pressable>
        </View>
      </View>
      <PointsMallTabBar />
    </View>
  );
}

function TrendLine({
  values,
  width,
  height,
}: {
  values: number[];
  width: number;
  height: number;
}) {
  if (values.length === 0) return null;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const span = Math.max(max - min, 1);
  const pad = 28;
  const innerW = width - pad * 2;
  const innerH = height - pad * 2;
  const pts = values.map((v, i) => {
    const x = pad + (values.length === 1 ? innerW / 2 : (i / (values.length - 1)) * innerW);
    const y = pad + innerH - ((v - min) / span) * innerH;
    return `${x},${y}`;
  });
  return (
    <Svg width={width} height={height}>
      <Polyline points={pts.join(" ")} fill="none" stroke={JOIN_TEAL} strokeWidth={2} />
      {values.map((v, i) => {
        const x = pad + (values.length === 1 ? innerW / 2 : (i / (values.length - 1)) * innerW);
        const y = pad + innerH - ((v - min) / span) * innerH;
        return <Circle key={i} cx={x} cy={y} r={3} fill={JOIN_TEAL} />;
      })}
    </Svg>
  );
}
