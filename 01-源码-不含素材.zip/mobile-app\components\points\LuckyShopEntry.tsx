import React, { useEffect, useRef } from "react";
import { Animated, Easing, Pressable, Text, View } from "react-native";
import { Sparkles } from "lucide-react-native";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";

const TEAL = Colors.primary.DEFAULT;

export default function LuckyShopEntry({ onPress }: { onPress: () => void }) {
  const { t } = useTranslation();
  const pulse = useRef(new Animated.Value(0)).current;
  const pulse2 = useRef(new Animated.Value(0)).current;
  const spin = useRef(new Animated.Value(0)).current;
  const bob = useRef(new Animated.Value(0)).current;
  const twinkle = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const pulseLoop = Animated.loop(
      Animated.timing(pulse, {
        toValue: 1,
        duration: 1700,
        easing: Easing.out(Easing.quad),
        useNativeDriver: true,
      }),
    );
    const pulse2Loop = Animated.loop(
      Animated.sequence([
        Animated.delay(550),
        Animated.timing(pulse2, {
          toValue: 1,
          duration: 1700,
          easing: Easing.out(Easing.quad),
          useNativeDriver: true,
        }),
      ]),
    );
    const spinLoop = Animated.loop(
      Animated.timing(spin, {
        toValue: 1,
        duration: 7200,
        easing: Easing.linear,
        useNativeDriver: true,
      }),
    );
    const bobLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(bob, {
          toValue: 1,
          duration: 900,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(bob, {
          toValue: 0,
          duration: 900,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ]),
    );
    const twinkleLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(twinkle, { toValue: 1, duration: 640, useNativeDriver: true }),
        Animated.timing(twinkle, { toValue: 0, duration: 640, useNativeDriver: true }),
      ]),
    );
    pulseLoop.start();
    pulse2Loop.start();
    spinLoop.start();
    bobLoop.start();
    twinkleLoop.start();
    return () => {
      pulseLoop.stop();
      pulse2Loop.stop();
      spinLoop.stop();
      bobLoop.stop();
      twinkleLoop.stop();
    };
  }, [bob, pulse, pulse2, spin, twinkle]);

  const ring = (value: Animated.Value) => ({
    opacity: value.interpolate({ inputRange: [0, 1], outputRange: [0.5, 0] }),
    transform: [{ scale: value.interpolate({ inputRange: [0, 1], outputRange: [1, 1.58] }) }],
  });

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={t("pointsMall.luckyShopEntry")}
      onPress={onPress}
      style={{
        width: 96,
        alignItems: "center",
        justifyContent: "center",
        paddingVertical: 8,
        paddingRight: 8,
      }}
    >
      <View style={{ width: 68, height: 68, alignItems: "center", justifyContent: "center" }}>
        <Animated.View
          pointerEvents="none"
          style={[
            {
              position: "absolute",
              width: 52,
              height: 52,
              borderRadius: 26,
              borderWidth: 2,
              borderColor: TEAL,
            },
            ring(pulse),
          ]}
        />
        <Animated.View
          pointerEvents="none"
          style={[
            {
              position: "absolute",
              width: 52,
              height: 52,
              borderRadius: 26,
              borderWidth: 1.5,
              borderColor: "#F5C84C",
            },
            ring(pulse2),
          ]}
        />
        <Animated.View style={{ transform: [{ translateY: bob.interpolate({ inputRange: [0, 1], outputRange: [0, -3] }) }] }}>
          <View
            style={{
              width: 52,
              height: 52,
              borderRadius: 26,
              backgroundColor: TEAL,
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 3px 10px rgba(4, 168, 174, 0.42)",
            }}
          >
            <Animated.View
              style={{
                transform: [{ rotate: spin.interpolate({ inputRange: [0, 1], outputRange: ["0deg", "360deg"] }) }],
              }}
            >
              <Sparkles size={24} color="#FFFFFF" strokeWidth={2.2} />
            </Animated.View>
          </View>
        </Animated.View>
        <Animated.View
          pointerEvents="none"
          style={{
            position: "absolute",
            top: 6,
            right: 8,
            width: 7,
            height: 7,
            borderRadius: 4,
            backgroundColor: "#F5C84C",
            opacity: twinkle,
          }}
        />
        <Animated.View
          pointerEvents="none"
          style={{
            position: "absolute",
            bottom: 10,
            left: 6,
            width: 5,
            height: 5,
            borderRadius: 3,
            backgroundColor: "#FFF4B8",
            opacity: twinkle.interpolate({ inputRange: [0, 1], outputRange: [0.95, 0.15] }),
          }}
        />
      </View>
      <Text
        numberOfLines={2}
        style={{
          marginTop: 2,
          width: 84,
          fontSize: 10,
          fontWeight: "800",
          color: TEAL,
          textAlign: "center",
          lineHeight: 13,
        }}
      >
        {t("pointsMall.luckyShopEntry")}
      </Text>
    </Pressable>
  );
}
