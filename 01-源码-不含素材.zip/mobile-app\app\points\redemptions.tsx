import React, { useMemo, useState } from "react";
import { Image, Pressable, RefreshControl, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { useQueryClient } from "@tanstack/react-query";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useRedemptionList, useRevealMyRecords } from "@/hooks";
import { normalizeImageUrl } from "@/lib/utils";

const TEAL = Colors.primary.DEFAULT;
type Tab = "all" | "addr" | "ship" | "done";

function statusOf(item: any): Tab {
  const s = Number(item?.status ?? item?.huande_status ?? -1);
  if (s === 1 || s === 0) return "addr";
  if (s === 2) return "ship";
  if (s >= 3) return "done";
  return "all";
}

function labelOf(tab: Tab, t: (k: string) => string) {
  if (tab === "addr") return t("pointsMall.waitAddress");
  if (tab === "ship") return t("pointsMall.shipping");
  if (tab === "done") return t("pointsMall.completed");
  return t("pointsMall.tabAllPeriods");
}

export default function PointsRedemptionsScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const [tab, setTab] = useState<Tab>("all");
  const [refreshing, setRefreshing] = useState(false);
  const { data } = useRedemptionList();
  const { data: huandeData } = useRevealMyRecords();

  const rows = useMemo(() => {
    const a = (data as any)?.data?.list ?? (data as any)?.data?.lists ?? (data as any)?.list ?? [];
    const b = (huandeData as any)?.data?.lists ?? (huandeData as any)?.lists ?? [];
    const raw = [...(Array.isArray(a) ? a : []), ...(Array.isArray(b) ? b : [])];
    const seen = new Set<string>();
    return raw
      .map((item: any) => ({
        id: Number(item.id ?? item.huande_id ?? 0),
        name: String(item.store_name ?? item.product?.name ?? item.title ?? ""),
        image: normalizeImageUrl(String(item.image ?? item.product?.image ?? "")),
        period: String(item.bianhao ?? ""),
        time: String(item.zhongjiang_time ?? item.add_time ?? ""),
        status: statusOf(item),
        statusNum: Number(item.status ?? 0),
      }))
      .filter((row) => {
        if (!row.id) return false;
        const key = String(row.id);
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
  }, [data, huandeData]);

  const shown = tab === "all" ? rows : rows.filter((r) => r.status === tab);
  const tabs: Tab[] = ["all", "addr", "ship", "done"];

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.wonGoods")} />
      <View className="flex-row bg-white px-2">
        {tabs.map((key) => {
          const on = tab === key;
          return (
            <Pressable key={key} className="px-2 py-2.5" onPress={() => setTab(key)}>
              <Text
                className="text-sm font-bold"
                style={{
                  color: on ? TEAL : "#6B7280",
                  borderBottomWidth: on ? 2 : 0,
                  borderBottomColor: TEAL,
                  paddingBottom: 3,
                }}
              >
                {labelOf(key, t)}
              </Text>
            </Pressable>
          );
        })}
      </View>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={async () => {
              setRefreshing(true);
              await qc.invalidateQueries();
              setRefreshing(false);
            }}
            tintColor={TEAL}
          />
        }
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}
      >
        {shown.length === 0 ? (
          <Text className="text-center text-gray-400 py-16">{t("pointsMall.noWonYet")}</Text>
        ) : (
          shown.map((row) => (
            <Pressable
              key={row.id}
              className="flex-row bg-white px-3 py-3 border-b border-gray-100"
              onPress={() =>
                router.push({ pathname: "/points/redemption-info", params: { id: String(row.id) } })
              }
            >
              <View className="w-16 h-16 bg-gray-50 rounded overflow-hidden mr-3">
                {row.image ? (
                  <Image source={{ uri: row.image }} className="w-full h-full" resizeMode="contain" />
                ) : null}
              </View>
              <View className="flex-1">
                <Text className="text-[11px]" style={{ color: TEAL }}>
                  {t("pointsMall.periodN", { n: row.period || "-" })}
                </Text>
                <Text className="text-sm text-gray-900 mt-0.5" numberOfLines={2}>
                  {row.name}
                </Text>
                <Text className="text-xs mt-1" style={{ color: TEAL }}>
                  {labelOf(row.status === "all" ? "addr" : row.status, t)}
                </Text>
              </View>
            </Pressable>
          ))
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
