import React from "react";
import { View, Text, Pressable, ScrollView, type ViewStyle } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import {
  BoxSurfaces, BoxBorders, BoxText, BoxAccent,
  BoxTypography, BoxSpacing, BoxRadius, BoxAnimation, bs,
} from "@/lib/boxTheme";

interface Tab {
  key: string;
  label: string;
  count?: number;
  icon?: React.ReactNode;
}

interface BoxTabBarProps {
  tabs: Tab[];
  activeKey: string;
  onSelect: (key: string) => void;
  style?: ViewStyle;
}

export function BoxTabBar({ tabs, activeKey, onSelect, style }: BoxTabBarProps) {
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={[{
        paddingHorizontal: BoxSpacing.lg,
        paddingVertical: BoxSpacing.md,
        gap: BoxSpacing.sm,
      }]}
      style={style}
    >
      {tabs.map((tab) => {
        const isActive = tab.key === activeKey;
        return (
          <Pressable
            key={tab.key}
            onPress={() => onSelect(tab.key)}
            style={({ pressed }) => ({
              transform: [{ scale: pressed ? BoxAnimation.press.scale : 1 }],
            })}
          >
            {isActive ? (
              <LinearGradient
                colors={[BoxAccent.goldLight, BoxAccent.gold, BoxAccent.goldDark]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 6,
                  paddingHorizontal: BoxSpacing.lg,
                  height: bs(34),
                  borderRadius: BoxRadius.full,
                  shadowColor: BoxAccent.gold,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.28,
                  shadowRadius: 10,
                  elevation: 4,
                }}
              >
                {tab.icon}
                <Text style={[BoxTypography.caption, { color: "#FFFFFF", fontWeight: "700" }]}>
                  {tab.label}
                </Text>
                {tab.count !== undefined && (
                  <View style={{
                    minWidth: bs(18), height: bs(18), borderRadius: bs(9),
                    backgroundColor: "rgba(255,255,255,0.22)",
                    alignItems: "center", justifyContent: "center",
                    paddingHorizontal: 4,
                  }}>
                    <Text style={{ fontSize: bs(10), fontWeight: "700", color: "#fff" }}>
                      {tab.count}
                    </Text>
                  </View>
                )}
              </LinearGradient>
            ) : (
              <View style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 6,
                paddingHorizontal: BoxSpacing.lg,
                height: bs(34),
                borderRadius: BoxRadius.full,
                backgroundColor: BoxSurfaces.card,
                borderWidth: 1,
                borderColor: BoxBorders.default,
              }}>
                {tab.icon}
                <Text style={[BoxTypography.caption, { color: BoxText.secondary }]}>
                  {tab.label}
                </Text>
                {tab.count !== undefined && (
                  <View style={{
                    minWidth: bs(18), height: bs(18), borderRadius: bs(9),
                    backgroundColor: BoxSurfaces.elevated,
                    alignItems: "center", justifyContent: "center",
                    paddingHorizontal: 4,
                  }}>
                    <Text style={{ fontSize: bs(10), fontWeight: "700", color: BoxText.tertiary }}>
                      {tab.count}
                    </Text>
                  </View>
                )}
              </View>
            )}
          </Pressable>
        );
      })}
    </ScrollView>
  );
}
