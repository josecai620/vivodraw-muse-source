import React, { useEffect } from "react";
import { Modal, Pressable, Text, View } from "react-native";
import { Image } from "expo-image";
import Animated, { Easing, useAnimatedStyle, useSharedValue, withSequence, withTiming } from "react-native-reanimated";
import { useTranslation } from "react-i18next";
import { BoxChestVFX } from "@/components/box";
import { Colors } from "@/constants/theme";

type PrizeItem = { name?: string; image?: string };

export function SignPrizeOpenOverlay({
  visible,
  opening,
  item,
  onClose,
}: {
  visible: boolean;
  opening: boolean;
  item: PrizeItem | null;
  onClose: () => void;
}) {
  const { t } = useTranslation();
  const scale = useSharedValue(0.6);
  const opacity = useSharedValue(0);

  useEffect(() => {
    if (!visible) return;
    scale.value = withSequence(
      withTiming(1.08, { duration: 280, easing: Easing.out(Easing.cubic) }),
      withTiming(1, { duration: 180 })
    );
    opacity.value = withTiming(1, { duration: 200 });
  }, [visible, item, opening, opacity, scale]);

  const motion = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ scale: scale.value }],
  }));

  if (!visible) return null;

  return (
    <Modal transparent animationType="fade" visible={visible} onRequestClose={onClose}>
      <View className="flex-1 items-center justify-center px-6" style={{ backgroundColor: "rgba(12,18,18,0.72)" }}>
        <Animated.View style={[{ width: "100%", maxWidth: 340, borderRadius: 24, backgroundColor: "#fff", padding: 24, alignItems: "center" }, motion]}>
          {opening && !item ? (
            <BoxChestVFX
              image={require("../../assets/box-category-chests/signature-chest.png")}
              tier="legendary"
              size={140}
            />
          ) : null}
          {item ? (
            <>
              <Text className="text-lg font-bold text-gray-900 mb-3">{t("pointsCheckin.wonTitle")}</Text>
              {item.image ? (
                <Image source={{ uri: item.image }} style={{ width: 120, height: 120, borderRadius: 16 }} contentFit="cover" />
              ) : (
                <BoxChestVFX image={require("../../assets/box-category-chests/signature-chest.png")} tier="legendary" size={120} />
              )}
              <Text className="text-base font-semibold text-gray-800 mt-3 text-center">{item.name}</Text>
              <Text className="text-xs text-gray-500 mt-2 text-center">{t("pointsCheckin.wonHint", { item: item.name || "" })}</Text>
            </>
          ) : (
            <Text className="text-sm text-gray-500 mt-3">{t("common.loading")}</Text>
          )}
          {item ? (
            <Pressable
              onPress={onClose}
              className="mt-5 w-full h-12 rounded-full items-center justify-center"
              style={{ backgroundColor: Colors.primary.DEFAULT }}
            >
              <Text className="text-white font-bold">{t("pointsCheckin.keepPrize")}</Text>
            </Pressable>
          ) : null}
        </Animated.View>
      </View>
    </Modal>
  );
}
