import type { PearlKey, PearlPose, PearlRound, PearlTell } from "@/lib/api/pearl";

export class PracticeRandomUnavailableError extends Error {
  readonly code = "secure_random_unavailable";

  constructor() {
    super("Secure randomness is unavailable for this practice exploration.");
    this.name = "PracticeRandomUnavailableError";
  }
}

const ORDER: PearlKey[] = ["sand", "white", "pink", "gold", "black", "aurora", "living"];
const WEIGHTS = [190, 135, 90, 50, 22, 9, 4];
const POSES: PearlPose[] = ["round", "tall", "fan", "knobby", "flat", "spiral"];

/** 拒绝采样消除取模偏差，所有玩法抽样都只使用浏览器安全随机源。 */
function uniformBelow(maximum: number): number {
  try {
    const source = globalThis.crypto;
    if (typeof source?.getRandomValues !== "function") throw new PracticeRandomUnavailableError();
    const word = new Uint32Array(1);
    const limit = Math.floor(0x100000000 / maximum) * maximum;
    for (let attempt = 0; attempt < 128; attempt++) {
      source.getRandomValues(word);
      if (word[0] < limit) return word[0] % maximum;
    }
  } catch { throw new PracticeRandomUnavailableError(); }
  throw new PracticeRandomUnavailableError();
}

function inclusive(min: number, max: number): number {
  return min + uniformBelow(max - min + 1);
}

function weightedFrom(minIdx: number, maxIdx: number): PearlKey {
  let sum = 0;
  for (let i = minIdx; i <= maxIdx; i++) sum += WEIGHTS[i];
  let ticket = inclusive(1, sum);
  for (let i = minIdx; i <= maxIdx; i++) {
    ticket -= WEIGHTS[i];
    if (ticket <= 0) return ORDER[i];
  }
  return ORDER[maxIdx];
}

function rarityIndex(id: PearlKey): number {
  return ORDER.indexOf(id);
}

function tellsForCatch(rarity: PearlKey): PearlTell[] {
  const idx = rarityIndex(rarity);
  if (idx <= 0) return inclusive(1, 100) <= 35 ? ["bubbles"] : [];
  const tells: PearlTell[] = ["bubbles", "shimmer"];
  if (idx >= 2) tells.push("ajar");
  if (idx >= 3) tells.push("heartbeat");
  if (inclusive(1, 100) <= 35) tells.push("visitor");
  return [...new Set(tells)];
}

function decoyTells(): PearlTell[] {
  const roll = inclusive(1, 100);
  if (roll <= 22) return ["bubbles"];
  if (roll <= 30) return ["visitor"];
  return [];
}

/** v3 一局一只真蚌；试玩也不走双开。 */
export function generatePracticeSelections(): 1 | 2 {
  return 1;
}

/** 诱饵珠档：真珠之下各档均匀随机（真珠是沙珠时只有沙珠）。 */
function decoyRarity(catchKey: PearlKey): PearlKey {
  const idx = rarityIndex(catchKey) - 1;
  if (idx < 0) return catchKey;
  return ORDER[uniformBelow(idx + 1)];
}

function publicFace(shell: PearlRound["shells"][number]): PearlRound["shells"][number] {
  return { index: shell.index, pearlKey: null, tells: shell.tells, pose: shell.pose };
}

/** 私有布局含珠档；舞台开局只应拿到公开面。 */
export function generatePracticeBoard(): { private: PearlRound["shells"]; public: PearlRound["shells"] } {
  const catchRarity = weightedFrom(0, ORDER.length - 1);
  const catchSlot = uniformBelow(6);
  const privateShells: PearlRound["shells"] = Array.from({ length: 6 }, (_, slot) => {
    const isCatch = slot === catchSlot;
    // 诱饵从「真珠之下的各档」均匀取，和服务端一致：视觉上明显不是真珠
    const rarity = isCatch ? catchRarity : decoyRarity(catchRarity);
    return {
      index: slot,
      pearlKey: rarity,
      tells: isCatch ? tellsForCatch(rarity) : decoyTells(),
      pose: POSES[slot],
    };
  });
  return { private: privateShells, public: privateShells.map(publicFace) };
}

/** 每局重新取安全随机数；不接收选择、账号、时间或上一局状态，也不产生积分。 */
export function generatePracticeShells(): PearlRound["shells"] {
  try {
    return generatePracticeBoard().private;
  } catch {
    throw new PracticeRandomUnavailableError();
  }
}
