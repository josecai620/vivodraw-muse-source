import PageHeader from "@/components/shared/PageHeader";
import { Colors, s } from "@/constants/theme";
import { getOrderExpress } from "@/lib/api/order";
import { type ApiRecord, isApiRecord, unwrapApiRecord } from "@/lib/api/response";
import { useQuery } from "@tanstack/react-query";
import { useLocalSearchParams } from "expo-router";
import React from "react";
import { useTranslation } from "react-i18next";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";

type TrackingItem = ApiRecord & {
  context?: string;
  status?: string;
  location?: string;
  time?: string;
  ftime?: string;
};

type ExpressPayload = ApiRecord & {
  express?: ApiRecord | TrackingItem[];
  list?: TrackingItem[];
  result?: ApiRecord;
};

function getTrackingList(payload: ExpressPayload | TrackingItem[]): TrackingItem[] {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload.list)) return payload.list;
  if (Array.isArray(payload.express)) return payload.express;
  if (isApiRecord(payload.express) && Array.isArray(payload.express.list)) {
    return payload.express.list as TrackingItem[];
  }
  if (
    isApiRecord(payload.express) &&
    isApiRecord(payload.express.result) &&
    Array.isArray(payload.express.result.list)
  ) {
    return payload.express.result.list as TrackingItem[];
  }
  if (isApiRecord(payload.result) && Array.isArray(payload.result.list)) {
    return payload.result.list as TrackingItem[];
  }
  return [];
}

function getTrackingItemKey(item: TrackingItem): string {
  const key = item.time ?? item.ftime ?? item.context ?? item.status ?? item.location;
  return key ? String(key) : JSON.stringify(item);
}

export default function OrderExpressScreen() {
  const { t } = useTranslation();
  const { orderId } = useLocalSearchParams<{ orderId: string }>();

  const { data, isLoading } = useQuery({
    queryKey: ["orderExpress", orderId],
    queryFn: () => getOrderExpress(orderId ?? ""),
    enabled: !!orderId,
  });

  if (!orderId) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("shopOrderExpress.title")} />
        <View className="flex-1 items-center justify-center">
          <Text style={{ color: Colors.neutral[500] }}>{t("shopOrderExpress.missingOrderId")}</Text>
        </View>
      </View>
    );
  }

  if (isLoading) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("shopOrderExpress.title")} />
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      </View>
    );
  }

  const raw = unwrapApiRecord<ExpressPayload>(data, {});
  const list = getTrackingList(raw);

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("shopOrderExpress.title")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
        showsVerticalScrollIndicator={false}
      >
        {list.length > 0 ? (
          <View className="bg-white rounded-2xl p-4 border border-gray-100">
            {list.map((item, idx) => (
              <View
                key={`${getTrackingItemKey(item)}-${idx}`}
                className="py-3 border-b border-gray-50"
                style={{ borderBottomWidth: idx < list.length - 1 ? 1 : 0 }}
              >
                <Text
                  className="font-medium"
                  style={{ color: idx === 0 ? Colors.brand.red : Colors.neutral[800] }}
                >
                  {item.context ?? item.status ?? t("common.unknown")}
                </Text>
                {item.location ? (
                  <Text className="text-xs mt-1" style={{ color: Colors.neutral[600] }}>
                    {item.location}
                  </Text>
                ) : null}
                <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }}>
                  {item.time ?? item.ftime ?? ""}
                </Text>
              </View>
            ))}
          </View>
        ) : (
          <View className="bg-white rounded-2xl p-6 items-center">
            <Text style={{ color: Colors.neutral[500] }}>{t("shopOrderExpress.empty")}</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
