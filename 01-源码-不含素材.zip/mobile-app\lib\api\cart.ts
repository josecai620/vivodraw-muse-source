import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

export interface CartItem {
  id: number;
  product_id: number;
  product_attr_unique: string;
  cart_num: number;
  productInfo: {
    id: number;
    image: string;
    store_name: string;
    price: string;
    ot_price: string;
    attrInfo?: {
      suk: string;
      image: string;
      price: string;
    };
  };
  is_pay: number;
  is_del: number;
  is_new: number;
  status: number;
}

/** 后端 /api/cart/list 按促销活动分组返回：{ promotions, pids, cart: [购物车项] } */
export interface CartGroup {
  promotions?: unknown[];
  pids?: number[];
  cart?: CartItem[];
}

/**
 * 把 /api/cart/list 的 valid/invalid 拍平成购物车项数组。
 * 后端是分组结构（[{ promotions, pids, cart: [...] }]），前端按扁平项渲染；
 * 这里同时兼容已经是扁平数组的返回。
 */
export function flattenCartList(raw: unknown): CartItem[] {
  if (!Array.isArray(raw)) return [];
  const items: CartItem[] = [];
  for (const entry of raw) {
    if (!entry || typeof entry !== "object") continue;
    const record = entry as Record<string, unknown>;
    if (Array.isArray(record.cart)) {
      for (const child of record.cart) {
        if (child && typeof child === "object") items.push(child as CartItem);
      }
      continue;
    }
    if ("productInfo" in record || "cart_num" in record) {
      items.push(record as unknown as CartItem);
    }
  }
  return items;
}

export function getCartList() {
  return http.get<{ valid: CartGroup[]; invalid: CartGroup[] }>(
    API_ENDPOINTS.cart.list,
  );
}

export function addToCart(data: {
  productId: number;
  cartNum: number;
  uniqueId?: string;
  new?: number;
  /** 1=直接购买，加入后跳结算 */
  is_new?: number;
  secKillId?: number;
  combinationId?: number;
  bargainId?: number | string;
}) {
  return http.post(API_ENDPOINTS.cart.add, data);
}

export function removeFromCart(ids: number[]) {
  return http.post(API_ENDPOINTS.cart.delete, { ids });
}

export function updateCartNum(id: number, number: number) {
  return http.post(API_ENDPOINTS.cart.update, { id, number });
}

export function getCartCount() {
  return http.get<{ count: number }>(API_ENDPOINTS.cart.count);
}
