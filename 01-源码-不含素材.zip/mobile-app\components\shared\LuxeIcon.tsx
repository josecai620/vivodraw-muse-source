import React from "react";
import { View, type ViewStyle } from "react-native";
import Svg, {
  Circle,
  G,
  Line,
  Path,
  Polyline,
  Rect,
} from "react-native-svg";
import { s } from "@/constants/theme";

type IconComponent = React.ComponentType<{
  size?: number;
  color?: string;
  strokeWidth?: number;
  fill?: string;
}>;

export type LuxeIconTone =
  | "brand"
  | "gold"
  | "orange"
  | "rose"
  | "mint"
  | "blue"
  | "violet"
  | "neutral";

export type SketchGlyphName =
  | "new"
  | "hot"
  | "points"
  | "coupons"
  | "grid"
  | "home"
  | "cart"
  | "user"
  | "search"
  | "bell"
  | "menu"
  | "back"
  | "heart"
  | "plus"
  | "package"
  | "car"
  | "fashion"
  | "electronics"
  | "beauty"
  | "outdoor"
  | "living"
  | "jewelry"
  | "apple"
  | "gift"
  | "ticket"
  | "box";

type LuxeIconVariant = "badge" | "soft" | "solid" | "plain";

interface LuxeIconProps {
  Icon?: IconComponent;
  glyph?: SketchGlyphName;
  children?: React.ReactNode;
  tone?: LuxeIconTone;
  variant?: LuxeIconVariant;
  active?: boolean;
  size?: number;
  iconSize?: number;
  color?: string;
  accentColor?: string;
  fill?: string;
  strokeWidth?: number;
  roundness?: number;
  style?: ViewStyle;
  contentStyle?: ViewStyle;
}

const toneOrder: LuxeIconTone[] = ["brand", "gold", "orange", "rose", "mint", "blue", "violet", "neutral"];
const SKETCH_VIEWBOX = "6 6 52 52";
const SKETCH_ICON_RATIO = 0.82;
const FALLBACK_ICON_RATIO = 0.62;

// 方向C：所有彩色 tone 收敛为唯一 teal 系；neutral 为中性浅灰。干净圆角浅底，无拟物洗色
interface IconPalette {
  paper: string;
  paperActive: string;
  ink: string;
  accent: string;
}
const TEAL_PAPER = "#ECFBFB";
const TEAL_PAPER_ACTIVE = "#D6F4F5";
const GRAY_PAPER = "#F1F3F3";
const GRAY_PAPER_ACTIVE = "#E4E8E8";
const palettes: Record<LuxeIconTone, IconPalette> = {
  brand: { paper: TEAL_PAPER, paperActive: TEAL_PAPER_ACTIVE, ink: "#04A8AE", accent: "#078E93" },
  gold: { paper: TEAL_PAPER, paperActive: TEAL_PAPER_ACTIVE, ink: "#04A8AE", accent: "#078E93" },
  orange: { paper: TEAL_PAPER, paperActive: TEAL_PAPER_ACTIVE, ink: "#04A8AE", accent: "#078E93" },
  rose: { paper: TEAL_PAPER, paperActive: TEAL_PAPER_ACTIVE, ink: "#04A8AE", accent: "#078E93" },
  mint: { paper: TEAL_PAPER, paperActive: TEAL_PAPER_ACTIVE, ink: "#04A8AE", accent: "#078E93" },
  blue: { paper: TEAL_PAPER, paperActive: TEAL_PAPER_ACTIVE, ink: "#04A8AE", accent: "#078E93" },
  violet: { paper: TEAL_PAPER, paperActive: TEAL_PAPER_ACTIVE, ink: "#04A8AE", accent: "#078E93" },
  neutral: { paper: GRAY_PAPER, paperActive: GRAY_PAPER_ACTIVE, ink: "#5E5F5E", accent: "#9AA09F" },
};

export function luxeIconTone(index: number): LuxeIconTone {
  return toneOrder[index % toneOrder.length];
}

export function categorySketchGlyph(label: string, index = 0): SketchGlyphName {
  const text = label.toLowerCase();
  // 独立单词判断：避免 self-care 含 "car"、accessory 含 "access" 这类子串误匹配
  const isWord = (w: string) => new RegExp(`(^|[^a-z])${w}([^a-z]|$)`).test(text);
  // 美妆 / 个护（self-care、personal care）优先，避免被子串规则抢先
  if (
    text.includes("beauty") ||
    text.includes("skin") ||
    text.includes("makeup") ||
    text.includes("self-care") ||
    text.includes("self care") ||
    text.includes("personal care") ||
    isWord("care") ||
    label.includes("美妆") ||
    label.includes("护肤") ||
    label.includes("个护")
  )
    return "beauty";
  if (text.includes("auto") || isWord("car") || text.includes("accessor") || label.includes("车") || label.includes("汽车")) return "car";
  if (text.includes("fashion") || text.includes("shoe") || text.includes("clothing") || text.includes("apparel") || label.includes("鞋") || label.includes("服")) return "fashion";
  if (text.includes("electronic") || text.includes("digital") || text.includes("phone") || text.includes("tech") || label.includes("电子") || label.includes("数码")) return "electronics";
  if (text.includes("outdoor") || text.includes("sport") || text.includes("travel") || label.includes("户外") || label.includes("运动")) return "outdoor";
  if (text.includes("home") || text.includes("living") || text.includes("house") || text.includes("desk") || label.includes("家居") || label.includes("生活")) return "living";
  if (text.includes("jewel") || label.includes("珠宝") || label.includes("首饰")) return "jewelry";
  if (text.includes("apple") || label.includes("苹果")) return "apple";
  if (text.includes("toy") || text.includes("game") || text.includes("collect")) return "outdoor";
  return (["car", "fashion", "electronics", "beauty", "outdoor", "living", "jewelry", "apple"] as SketchGlyphName[])[index % 8];
}

function iconName(Icon?: IconComponent): string {
  if (!Icon) return "";
  const named = Icon as IconComponent & { displayName?: string };
  return named.displayName || Icon.name || "";
}

function glyphForIcon(Icon?: IconComponent): SketchGlyphName | null {
  const name = iconName(Icon).toLowerCase();
  if (!name) return null;
  if (name.includes("arrowleft") || name.includes("chevronleft")) return "back";
  if (name.includes("search")) return "search";
  if (name.includes("bell")) return "bell";
  if (name.includes("menu")) return "menu";
  if (name.includes("heart")) return "heart";
  if (name.includes("plus")) return "plus";
  if (name.includes("home") || name.includes("house")) return "home";
  if (name.includes("grid") || name.includes("layout") || name.includes("settings")) return "grid";
  if (name.includes("cart") || name.includes("shoppingbag") || name.includes("basket")) return "cart";
  if (name.includes("trophy") || name.includes("award") || name.includes("crown")) return "points";
  if (name.includes("gift")) return "gift";
  if (name.includes("ticket") || name.includes("coupon") || name.includes("tag")) return "ticket";
  if (name.includes("user") || name.includes("person") || name.includes("users")) return "user";
  if (name.includes("package") || name.includes("box")) return "package";
  if (name.includes("zap") || name.includes("flame") || name.includes("trending")) return "hot";
  if (name.includes("star") || name.includes("sparkle")) return "jewelry";
  if (name.includes("car") || name.includes("truck")) return "car";
  if (name.includes("shirt") || name.includes("shoe")) return "fashion";
  if (name.includes("monitor") || name.includes("phone") || name.includes("mail")) return "electronics";
  if (name.includes("file") || name.includes("book") || name.includes("calendar") || name.includes("clipboard")) return "ticket";
  if (name.includes("credit") || name.includes("wallet") || name.includes("dollar")) return "ticket";
  if (name.includes("shield") || name.includes("lock")) return "package";
  return null;
}

function Stroke({
  children,
  color,
  width,
}: {
  children: React.ReactNode;
  color: string;
  width: number;
}) {
  return (
    <G stroke={color} strokeWidth={width} strokeLinecap="round" strokeLinejoin="round" fill="none">
      {children}
    </G>
  );
}

export function SketchGlyph({
  name,
  size = 28,
  color = "#171A1A",
  accent = "#04A8AE",
  strokeWidth = 3.9,
}: {
  name: SketchGlyphName;
  size?: number;
  color?: string;
  accent?: string;
  strokeWidth?: number;
}) {
  const w = strokeWidth;

  return (
    <Svg width={size} height={size} viewBox={SKETCH_VIEWBOX}>
      {name === "new" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M13 25c8-9 28-9 38-1l-3 25c-1 7-30 8-34 1Z" />
            <Path d="M20 24c2-12 8-16 12-7M38 22c2-12 9-12 11 0" />
          </Stroke>
          <Stroke color={accent} width={w * 0.9}>
            <Path d="M22 35c1 7 1 10 0 14M32 34c1 8 1 11 0 15M42 35c1 7 1 10 0 14" />
          </Stroke>
        </>
      )}
      {name === "hot" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M33 54c11-2 18-10 18-21 0-8-5-16-12-23 1 9-5 13-9 17-5 5-8 10-7 17" />
            <Path d="M27 53c-9-4-13-11-11-20 2-8 9-13 10-22 5 6 7 12 5 18" />
          </Stroke>
          <Stroke color={accent} width={w * 0.85}>
            <Path d="M34 51c5-3 7-7 6-12-1-4-4-7-7-10-1 6-7 9-7 15 0 4 3 6 8 7Z" />
          </Stroke>
        </>
      )}
      {name === "points" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M21 15h22v12c0 9-5 16-11 16s-11-7-11-16Z" />
            <Path d="M21 21h-8c1 10 6 15 13 14M43 21h8c-1 10-6 15-13 14M32 43v8M22 53h20" />
          </Stroke>
          <Stroke color={accent} width={w * 0.8}>
            <Path d="M27 24h10M25 31h14" />
          </Stroke>
        </>
      )}
      {name === "coupons" || name === "ticket" ? (
        <>
          <Stroke color={color} width={w}>
            <Path d="M13 23c4 0 7-3 7-7h30l2 12c-4 1-6 4-6 8s3 7 7 8l-1 10H20c0-4-3-7-7-7Z" />
            <Path d="M31 20v6M31 33v5M31 45v5" />
          </Stroke>
          <Stroke color={accent} width={w * 0.85}>
            <Path d="M39 27l-9 14M39 41l7-14" />
          </Stroke>
        </>
      ) : null}
      {name === "grid" && (
        <>
          <Stroke color={color} width={w}>
            <Rect x="12" y="12" width="18" height="18" rx="4" />
            <Rect x="35" y="12" width="17" height="18" rx="4" />
            <Rect x="12" y="35" width="18" height="17" rx="4" />
            <Rect x="35" y="35" width="17" height="17" rx="4" />
          </Stroke>
          <Stroke color={accent} width={w * 0.75}>
            <Path d="M18 42h7M41 19h6" />
          </Stroke>
        </>
      )}
      {name === "home" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M12 32 32 15l20 17" />
            <Path d="M18 29v22h28V29" />
            <Path d="M27 51V39h10v12" />
          </Stroke>
          <Stroke color={accent} width={w * 0.8}>
            <Path d="M23 24c7-5 11-6 18-1" />
          </Stroke>
        </>
      )}
      {name === "cart" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M10 16h7l5 27h25l5-19H22" />
            <Circle cx="27" cy="51" r="4" />
            <Circle cx="45" cy="51" r="4" />
          </Stroke>
          <Stroke color={accent} width={w * 0.85}>
            <Path d="M28 31h16M30 37h10" />
          </Stroke>
        </>
      )}
      {name === "user" && (
        <>
          <Stroke color={color} width={w}>
            <Circle cx="32" cy="22" r="10" />
            <Path d="M15 53c3-11 11-17 17-17s15 6 17 17" />
          </Stroke>
          <Stroke color={accent} width={w * 0.8}>
            <Path d="M24 49c4-3 12-3 17 0" />
          </Stroke>
        </>
      )}
      {name === "search" && (
        <>
          <Stroke color={color} width={w}>
            <Circle cx="28" cy="28" r="15" />
            <Path d="m40 40 12 12" />
          </Stroke>
          <Stroke color={accent} width={w * 0.75}>
            <Path d="M20 27c1-5 4-8 9-9" />
          </Stroke>
        </>
      )}
      {name === "bell" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M20 44h25c-4-5-5-10-5-17 0-7-4-12-9-12s-10 5-10 13c0 7-1 11-5 16" />
            <Path d="M28 49c2 4 7 4 9 0" />
          </Stroke>
          <Circle cx="45" cy="15" r="6" fill={accent} />
        </>
      )}
      {name === "menu" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M15 21h34M13 32h36M16 43h29" />
          </Stroke>
          <Stroke color={accent} width={w * 0.7}>
            <Path d="M42 43h6" />
          </Stroke>
        </>
      )}
      {name === "back" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M38 16 21 32l17 16" />
            <Path d="M22 32h30" />
          </Stroke>
          <Stroke color={accent} width={w * 0.75}>
            <Path d="M26 25c-4 4-5 9 0 14" />
          </Stroke>
        </>
      )}
      {name === "heart" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M32 51S14 40 14 25c0-7 5-11 11-11 4 0 7 2 8 6 2-4 5-6 9-6 6 0 10 4 10 11 0 15-20 26-20 26Z" />
          </Stroke>
          <Stroke color={accent} width={w * 0.75}>
            <Path d="M22 22c-2 4-1 8 2 11" />
          </Stroke>
        </>
      )}
      {name === "plus" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M32 15v34M15 32h34" />
          </Stroke>
          <Circle cx="32" cy="32" r="21" stroke={accent} strokeWidth={w * 0.65} fill="none" />
        </>
      )}
      {name === "package" || name === "gift" || name === "box" ? (
        <>
          <Stroke color={color} width={w}>
            <Path d="M17 24 32 15l15 9v22L32 55l-15-9Z" />
            <Path d="M17 24 32 33l15-9M32 33v22" />
          </Stroke>
          <Stroke color={accent} width={w * 0.8}>
            <Path d="M24 20c2-8 10-5 8 4M40 20c-2-8-10-5-8 4" />
            <Path d="M21 35h22" />
          </Stroke>
        </>
      ) : null}
      {name === "car" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M13 38h6l4-11c1-3 3-4 7-4h9c4 0 6 1 8 5l5 10h2" />
            <Path d="M17 38v8h36v-8" />
            <Circle cx="24" cy="48" r="4" />
            <Circle cx="46" cy="48" r="4" />
          </Stroke>
          <Stroke color={accent} width={w * 0.8}>
            <Path d="M28 29h13M20 36h6" />
          </Stroke>
        </>
      )}
      {name === "fashion" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M19 27c6-4 10-8 13-14 3 6 7 10 13 14l-6 24H25Z" />
            <Path d="M25 18c4 4 10 4 14 0" />
          </Stroke>
          <Stroke color={accent} width={w * 0.85}>
            <Path d="M32 32v13M25 51h14" />
          </Stroke>
        </>
      )}
      {name === "electronics" && (
        <>
          <Stroke color={color} width={w}>
            <Rect x="16" y="15" width="32" height="34" rx="5" />
            <Path d="M26 54h12M30 49v5" />
          </Stroke>
          <Stroke color={accent} width={w * 0.8}>
            <Path d="M25 29h14M25 36h9" />
          </Stroke>
        </>
      )}
      {name === "beauty" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M31 15c7 6 11 12 11 22 0 9-5 16-11 16s-11-7-11-16c0-10 4-16 11-22Z" />
            <Path d="M25 23c4 3 9 3 13 0" />
          </Stroke>
          <Stroke color={accent} width={w * 0.8}>
            <Path d="M31 31v12M25 38h12" />
          </Stroke>
        </>
      )}
      {name === "outdoor" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M32 12c8 10 12 19 10 28-2 8-8 13-10 13s-8-5-10-13c-2-9 2-18 10-28Z" />
            <Path d="M21 39c7-3 15-3 22 0" />
          </Stroke>
          <Stroke color={accent} width={w * 0.8}>
            <Path d="M32 19v31M26 29l6 6 7-10" />
          </Stroke>
        </>
      )}
      {name === "living" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M13 33 32 16l19 17" />
            <Path d="M19 31v21h26V31" />
          </Stroke>
          <Stroke color={accent} width={w * 0.8}>
            <Path d="M28 52V40h9v12M24 30h16" />
          </Stroke>
        </>
      )}
      {name === "jewelry" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M32 12 48 28 32 54 16 28Z" />
            <Path d="M16 28h32M24 28l8 26 8-26" />
          </Stroke>
          <Stroke color={accent} width={w * 0.75}>
            <Path d="M25 17h14M20 28l5-11M44 28l-5-11" />
          </Stroke>
        </>
      )}
      {name === "apple" && (
        <>
          <Stroke color={color} width={w}>
            <Path d="M36 20c-6-2-11 1-13 7-4 10 4 25 10 25 3 0 4-2 7-2s4 2 7 1c5-2 9-11 7-19-1-6-5-10-10-11" />
            <Path d="M34 18c1-6 5-9 11-9" />
          </Stroke>
          <Stroke color={accent} width={w * 0.75}>
            <Path d="M25 31c-1 5 0 10 3 14" />
          </Stroke>
        </>
      )}
    </Svg>
  );
}

export default function LuxeIcon({
  Icon,
  glyph,
  children,
  tone = "brand",
  variant = "badge",
  active = false,
  size = 44,
  iconSize,
  color,
  accentColor,
  fill,
  strokeWidth = 3.5,
  roundness = 0.36,
  style,
  contentStyle,
}: LuxeIconProps) {
  const palette = palettes[tone];
  const scaledSize = s(size);
  const resolvedGlyph = glyph ?? glyphForIcon(Icon);
  const baseIconSize = iconSize ?? Math.round(size * 0.64);
  const minIconSize = Math.round(size * (resolvedGlyph ? SKETCH_ICON_RATIO : FALLBACK_ICON_RATIO));
  const scaledIconSize = s(Math.max(baseIconSize, minIconSize));
  const borderRadius = Math.round(scaledSize * roundness);
  const isPressed = active || variant === "solid";
  const ink = color ?? palette.ink;
  const accent = accentColor ?? palette.accent;

  const glyphNode = resolvedGlyph ? (
    <SketchGlyph name={resolvedGlyph} size={scaledIconSize} color={ink} accent={accent} strokeWidth={strokeWidth} />
  ) : Icon ? (
    <Icon size={scaledIconSize} color={ink} strokeWidth={2.2} fill={fill} />
  ) : (
    children
  );

  if (variant === "plain") {
    return <>{glyphNode}</>;
  }

  return (
    <View
      style={[
        {
          width: scaledSize,
          height: scaledSize,
          borderRadius,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: isPressed ? palette.paperActive : palette.paper,
          borderWidth: 1,
          borderColor: "rgba(12,31,31,0.06)",
          // 方向C：冷青墨柔影，轻浮起
          shadowColor: "#0C1F1F",
          shadowOffset: { width: 0, height: isPressed ? 5 : 3 },
          shadowOpacity: isPressed ? 0.1 : 0.05,
          shadowRadius: isPressed ? 10 : 7,
          elevation: isPressed ? 3 : 2,
        },
        variant === "soft" && {
          shadowOpacity: 0.03,
          shadowRadius: 4,
          elevation: 1,
        },
        style,
      ]}
    >
      <View style={[{ alignItems: "center", justifyContent: "center" }, contentStyle]}>
        {glyphNode}
      </View>
    </View>
  );
}
