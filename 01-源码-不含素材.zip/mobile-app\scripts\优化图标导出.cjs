'use strict';
// Fail-closed Metro lucide export optimization. Input is never overwritten.
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),crypto=require('crypto'),zlib=require('zlib');
const parser=require('@babel/parser'),generate=require('@babel/generator').default,traverse=require('@babel/traverse').default,t=require('@babel/types');
const code=n=>generate(n,{compact:true,comments:false,shouldPrintComment:()=>false}).code;
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const flatten=n=>n.type==='SequenceExpression'?n.expressions.flatMap(flatten):[n];
function canonical(node){const ast=parser.parse('('+code(node)+')');let counter=0;traverse(ast,{Scope(p){for(const key of Object.keys(p.scope.bindings))p.scope.rename(key,'local'+counter++);},StringLiteral(p){delete p.node.extra;}});return code(ast.program.body[0].expression);}
const defaultHelper=canonical(parser.parse('(function(x){return x&&x.__esModule?x:{default:x}})').program.body[0].expression);
const namespaceHelper=canonical(parser.parse('(function(x){if(x&&x.__esModule)return x;var result={};return x&&Object.keys(x).forEach(function(name){var descriptor=Object.getOwnPropertyDescriptor(x,name);Object.defineProperty(result,name,descriptor.get?descriptor:{enumerable:!0,get:function(){return x[name]}})}),result.default=x,result})').program.body[0].expression);
const staticIconTemplate=canonical(parser.parse('(function(g,r,i,a,m,exports,d){"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),Object.defineProperty(exports,"default",{enumerable:!0,get:function(){return icon}});var temp,raw=r(d[0]);const icon=(0,((temp=raw)&&temp.__esModule?temp:{default:temp}).default)("ICON",[])})').program.body[0].expression);
function registrations(text){return parser.parse(text).program.body.filter(s=>s.expression?.callee?.name==='__d').map(s=>({stmt:s,call:s.expression,id:s.expression.arguments[1].value,factory:s.expression.arguments[0],deps:s.expression.arguments[2]}));}
function parseBarrel(mod){
 const f=mod.factory;assert(f.type==='FunctionExpression'&&f.params.length===7&&f.params.every(p=>p.type==='Identifier'),'Unknown Metro factory');
 assert(mod.deps.type==='ArrayExpression'&&mod.deps.elements.every(e=>e.type==='NumericLiteral'),'Nonliteral dependencies');
 const params=f.params.map(p=>p.name),vars=new Map(),helpers=new Set(),exports=[],markers=[];
 for(const stmt of f.body.body){
  if(stmt.type==='FunctionDeclaration'){assert(canonical(t.functionExpression(null,stmt.params,stmt.body))===defaultHelper,'Unknown helper');helpers.add(stmt.id.name);continue;}
  if(stmt.type==='VariableDeclaration'){for(const d of stmt.declarations){assert(d.id.type==='Identifier'&&d.init&&!vars.has(d.id.name),'Unsupported declaration');vars.set(d.id.name,d.init);}continue;}
  assert(stmt.type==='ExpressionStatement','Unknown barrel side effect');
  for(const e of flatten(stmt.expression)){
   assert(e.type==='CallExpression'&&code(e.callee)==='Object.defineProperty'&&e.arguments.length===3&&e.arguments[0].name===params[5]&&e.arguments[1].type==='StringLiteral','Unknown export operation');
   const name=e.arguments[1].value,desc=e.arguments[2];assert(desc.type==='ObjectExpression','Unknown descriptor');
   if(name==='__esModule'){assert(desc.properties.length===1&&desc.properties[0].key.name==='value'&&code(desc.properties[0].value)==='!0','Unknown ESM descriptor');markers.push(e);continue;}
   assert(desc.properties.length===2&&desc.properties[0].key.name==='enumerable'&&code(desc.properties[0].value)==='!0'&&desc.properties[1].key.name==='get','Descriptor differs');
   const getter=desc.properties[1].value;assert(getter.type==='FunctionExpression'&&getter.params.length===0&&getter.body.body.length===1&&getter.body.body[0].type==='ReturnStatement','Unknown getter');
   assert(!exports.some(x=>x.name===name),'Duplicate export');exports.push({name,value:getter.body.body[0].argument});
  }
 }
 assert(markers.length===1&&exports.length>100,'Not a recognized icon barrel');
 const requireSlots=new Set();
 function pure(n,seen=new Set()){
  if(n.type==='Identifier'){assert(vars.has(n.name)&&!seen.has(n.name),'Unknown/cyclic import alias');pure(vars.get(n.name),new Set([...seen,n.name]));return;}
  if(n.type==='MemberExpression'){assert(!n.computed&&n.property.name==='default','Only default selection is supported');pure(n.object,seen);return;}
  assert(n.type==='CallExpression'&&n.arguments.length===1,'Unknown initializer effect');
  if(n.callee.name===params[1]){const arg=n.arguments[0];assert(arg.type==='MemberExpression'&&arg.object.name===params[6]&&arg.computed&&arg.property.type==='NumericLiteral'&&mod.deps.elements[arg.property.value],'Unknown require');requireSlots.add(arg.property.value);return;}
  if(n.callee.type==='Identifier'){assert(helpers.has(n.callee.name),'Unknown call');pure(n.arguments[0],seen);return;}
  assert(n.callee.type==='FunctionExpression'&&canonical(n.callee)===namespaceHelper,'Unknown namespace interop');pure(n.arguments[0],seen);
 }
 for(const value of vars.values())pure(value);for(const e of exports)pure(e.value);
 return {params,vars,helpers,exports,markers,requireSlots};
}
function isStaticIcon(mod,creator){
 if(mod.deps.type!=='ArrayExpression'||mod.deps.elements.length!==1||mod.deps.elements[0].value!==creator)return false;
 const f=mod.factory,p=f.params.map(p=>p.name);let creators=0,requires=0,valid=true;
 const ast=parser.parse('('+code(f)+')');
 traverse(ast,{CallExpression(q){const n=q.node;if(code(n.callee)==='Object.defineProperty'){if(n.arguments[0]?.name!==p[5]||!['__esModule','default'].includes(n.arguments[1]?.value))valid=false;return;}
  if(n.callee.name===p[1]){if(code(n.arguments[0])!==p[6]+'[0]')valid=false;requires++;return;}
  // The only remaining call creates a named icon from static SVG node data.
  if(n.arguments.length===2&&n.arguments[0].type==='StringLiteral'&&n.arguments[1].type==='ArrayExpression'){
   try{JSON.parse(code(n.arguments[1]).replace(/([{,])([a-zA-Z_$][\w$]*):/g,'$1"$2":'));}catch{valid=false;}
   const callee=n.callee;if(callee.type!=='SequenceExpression'||callee.expressions.length!==2||callee.expressions[0].value!==0||callee.expressions[1].type!=='MemberExpression'||callee.expressions[1].property.name!=='default')valid=false;
   creators++;n.arguments=[t.stringLiteral('ICON'),t.arrayExpression([])];return;
  }valid=false;
 },AssignmentExpression(q){if(q.node.left.type!=='Identifier')valid=false;},NewExpression(){valid=false;},UpdateExpression(){valid=false;}});
 if(valid&&creators===1&&requires===1)assert.equal(canonical(ast.program.body[0].expression),staticIconTemplate,'Static icon factory structure differs');
 return valid&&creators===1&&requires===1;
}
function optimize(text){
 const mods=registrations(text),byId=new Map(mods.map(m=>[m.id,m]));
 const barrels=mods.filter(m=>{const s=code(m.factory);return s.includes('"AlarmClockCheck"')&&s.includes('"Zap"')&&s.includes('"ZoomIn"');});
 assert.equal(barrels.length,2,'Expected exactly the lucide package and icons barrels');
 const parsed=barrels.map(m=>({m,b:parseBarrel(m)}));
 const outer=parsed.find(x=>x.b.exports.some(e=>e.name==='createLucideIcon')),inner=parsed.find(x=>!x.b.exports.some(e=>e.name==='createLucideIcon'));
 assert(outer&&inner,'Barrel identities not established');
 function depOfExpr(n,b,m){if(n.type==='Identifier')return depOfExpr(b.vars.get(n.name),b,m);if(n.type==='MemberExpression')return depOfExpr(n.object,b,m);if(n.type==='CallExpression'){if(n.callee.name===b.params[1])return m.deps.elements[n.arguments[0].property.value].value;return depOfExpr(n.arguments[0],b,m);}throw Error('Unknown export dependency');}
 const creator=depOfExpr(outer.b.exports.find(e=>e.name==='createLucideIcon').value,outer.b,outer.m);
 const creatorMod=byId.get(creator);
 // Reviewed lucide-react-native 0.460.0 factory: only forwardRef construction + displayName.
 // Canonical hash is independent of module IDs, local variable names and comments.
 assert(creatorMod&&hash(canonical(creatorMod.factory))==='9f0432cd6804f58248ebd26bde76cd68197b0d8beec6c1a1a538a90a477fb93d','Unrecognized createLucideIcon version or side effects');
 const iconIds=new Set(inner.m.deps.elements.map(x=>x.value));
 assert(iconIds.size>1000,'Incomplete icon package');
 for(const id of iconIds)assert(byId.has(id)&&isStaticIcon(byId.get(id),creator),'Unknown icon initialization side effect: '+id);
 const barrelIds=new Set(barrels.map(m=>m.id)),eagerIds=new Set(outer.m.deps.elements.map(n=>n.value).filter(id=>!iconIds.has(id)&&!barrelIds.has(id)));
 // Non-icon framework/helper modules retain eager initialization before any getter can run.
 const patches=[],details=[];
 for(const {m,b}of parsed){
  function spec(n){
   if(n.type==='Identifier')return spec(b.vars.get(n.name));
   if(n.type==='MemberExpression'){const value=spec(n.object);assert(!value[2],'Nested default access');return [value[0],value[1],1];}
   if(n.callee.name===b.params[1])return [n.arguments[0].property.value,0,0];
   const value=spec(n.arguments[0]);assert(value[1]===0&&value[2]===0,'Nested interop operation');return [value[0],n.callee.type==='FunctionExpression'?2:1,0];
  }
  const table=b.exports.map(e=>[e.name,...spec(e.value)]);
  const warm=m.deps.elements.map((id,slot)=>eagerIds.has(id.value)?b.params[1]+'('+b.params[6]+'['+slot+']);':'').join('');
  const body='"use strict";'+code(b.markers[0])+';'+warm+
   'var __lucideCache=[],__lucideReady=[];var __lucideNamespace='+namespaceHelper+';'+
   'function __lucideValue(slot,kind){var key=slot*3+kind;if(!__lucideReady[key]){var v='+b.params[1]+'('+b.params[6]+'[slot]);if(kind===1)v=v&&v.__esModule?v:{default:v};if(kind===2)v=__lucideNamespace(v);__lucideCache[key]=v;__lucideReady[key]=true}return __lucideCache[key]}'+
   JSON.stringify(table)+'.forEach(function(pair){Object.defineProperty('+b.params[5]+',pair[0],{enumerable:true,get:function(){var v=__lucideValue(pair[1],pair[2]);return pair[3]?v.default:v}})});';
  const next=parser.parse('(function('+b.params.join(',')+'){'+body+'})').program.body[0].expression;
  patches.push({start:m.factory.start,end:m.factory.end,replacement:code(next)});
  details.push({moduleId:m.id,exports:b.exports.length,originalBytes:Buffer.byteLength(code(m.factory)),optimizedBytes:Buffer.byteLength(code(next)),dependenciesPreserved:true});
 }
 let output=text;for(const p of patches.sort((a,b)=>b.start-a.start))output=output.slice(0,p.start)+p.replacement+output.slice(p.end);
 const modified=registrations(output);for(const m of mods){const n=modified.find(n=>n.id===m.id);assert(n&&code(n.deps)===code(m.deps),'Dependency list changed');if(!barrelIds.has(m.id))assert.equal(code(n.factory),code(m.factory),'Unrelated factory changed');}
 return {output,report:{inputSha256:hash(text),outputSha256:hash(output),barrels:details,staticIconsVerified:iconIds.size,preservedEagerDependencyIds:[...eagerIds],beforeBytes:Buffer.byteLength(text),afterBytes:Buffer.byteLength(output),beforeGzip:zlib.gzipSync(text).length,afterGzip:zlib.gzipSync(output).length}};
}
module.exports={optimize,registrations,parseBarrel,isStaticIcon,canonical};
if(require.main===module){const[input,out]=process.argv.slice(2);assert(input&&out,'node 优化图标导出.cjs input.js output.js');assert(path.resolve(input)!==path.resolve(out),'Never overwrite input');const result=optimize(fs.readFileSync(input,'utf8'));fs.writeFileSync(out,result.output,{flag:'wx'});console.log(JSON.stringify(result.report,null,2));}
