import React, { useMemo, useState } from "react";
import { Alert, Pressable, ScrollView, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useTranslation } from "react-i18next";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useFocusEffect } from "@react-navigation/native";
import { PageHeader } from "@/components/shared";
import { TealGradient,  Colors  } from "@/constants/theme";
import { getAddressList } from "@/lib/api/address";
import { useCreateIntegralOrder, useIntegralOrderConfirm, usePointsProductDetail } from "@/hooks";
import { getPointsOrderList } from "@/lib/api/points";

export default function PointsConfirmScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const { id, num } = useLocalSearchParams<{ id: string; num: string }>();
  const productId = Number(id ?? 0);
  const initialNum = Math.max(1, Number(num ?? 1) || 1);
  const [buyNum, setBuyNum] = useState(initialNum);

  const { data: detailData } = usePointsProductDetail(productId);
  const detail = (detailData as any)?.data?.detail ?? (detailData as any)?.detail ?? {};
  const unique = String(detail?.unique ?? "");

  const { data: confirmData } = useIntegralOrderConfirm(unique, buyNum);
  const confirm = (confirmData as any)?.data ?? {};
  const productInfo = confirm?.productInfo ?? {};
  const totalPoints = Number(confirm?.total_price ?? Number(productInfo?.attrInfo?.price ?? 0) * buyNum);

  const { data: addressData, refetch: refetchAddress } = useQuery({
    queryKey: ["addressList"],
    queryFn: getAddressList,
  });
  const addresses = useMemo(() => {
    const list = (addressData as any)?.data ?? (addressData as any)?.list ?? addressData ?? [];
    return Array.isArray(list) ? list : [];
  }, [addressData]);

  const [selectedAddressId, setSelectedAddressId] = useState<number>(0);
  const createOrder = useCreateIntegralOrder();

  useFocusEffect(
    React.useCallback(() => {
      refetchAddress();
    }, [refetchAddress]),
  );

  React.useEffect(() => {
    if (selectedAddressId > 0) return;
    const defaultAddr = addresses.find((a: any) => Number(a?.is_default) === 1);
    if (defaultAddr?.id) setSelectedAddressId(Number(defaultAddr.id));
    else if (addresses[0]?.id) setSelectedAddressId(Number(addresses[0].id));
  }, [addresses, selectedAddressId]);

  const submit = async () => {
    if (!unique) {
      Alert.alert(t("pointsConfirm.notice"), t("pointsConfirm.invalidSpec"));
      return;
    }
    if (!selectedAddressId) {
      Alert.alert(t("pointsConfirm.notice"), t("pointsConfirm.selectAddressFirst"));
      return;
    }
    await createOrder.mutateAsync({
      addressId: selectedAddressId,
      unique,
      num: buyNum,
      mark: "",
      custom_form: [],
    });
    let orderUni = "";
    try {
      const listData = await getPointsOrderList({ type: -1, page: 1, limit: 20 });
      const list = (listData as any)?.data?.list ?? (listData as any)?.data?.lists ?? (listData as any)?.list ?? [];
      const first = Array.isArray(list) ? list[0] : null;
      orderUni = String(first?.order_id ?? first?.id ?? "");
    } catch {}

    Alert.alert(t("pointsConfirm.orderPlaced"), t("pointsConfirm.orderCreated"), [
      { text: t("pointsConfirm.backToList"), onPress: () => router.push("/points/orders") },
      ...(orderUni ? [{ text: t("pointsConfirm.viewDetail"), onPress: () => router.push({ pathname: "/points/order-detail", params: { id: orderUni } } as any) }] : []),
    ]);
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("pointsConfirm.title")} />
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 96 }}>
        <View className="p-4 gap-3">
          <View className="bg-white border border-gray-100 rounded-xl p-4">
            <Text className="text-base font-bold text-gray-900">{productInfo?.store_name ?? detail?.store_name ?? t("pointsConfirm.pointsProduct")}</Text>
            <View className="flex-row items-center justify-between mt-3">
              <Text className="text-sm text-gray-600">{t("pointsConfirm.quantity")}</Text>
              <View className="flex-row items-center gap-2">
                <Pressable className="w-8 h-8 rounded-md border border-gray-300 items-center justify-center" onPress={() => setBuyNum((n) => Math.max(1, n - 1))}>
                  <Text className="text-base text-gray-700">-</Text>
                </Pressable>
                <Text className="text-base font-bold text-gray-900 min-w-8 text-center">{buyNum}</Text>
                <Pressable className="w-8 h-8 rounded-md border border-gray-300 items-center justify-center" onPress={() => setBuyNum((n) => n + 1)}>
                  <Text className="text-base text-gray-700">+</Text>
                </Pressable>
              </View>
            </View>
            <Text className="text-sm text-gray-600 mt-1">{t("pointsConfirm.singlePrice", { price: Number(productInfo?.attrInfo?.price ?? detail?.price ?? 0) })}</Text>
            <Text className="text-lg font-bold mt-2" style={{ color: Colors.brand.red }}>
              {t("pointsConfirm.totalPrice", { total: totalPoints })}
            </Text>
          </View>

          <View className="bg-white border border-gray-100 rounded-xl p-4">
            <Text className="text-sm font-bold text-gray-900 mb-2">{t("pointsConfirm.selectAddress")}</Text>
            {addresses.map((item: any) => {
              const isActive = Number(item?.id) === selectedAddressId;
              return (
                <Pressable
                  key={item?.id}
                  className="rounded-lg border p-3 mb-2"
                  style={{ borderColor: isActive ? Colors.brand.red : "#e5e7eb", backgroundColor: isActive ? "#ECFBFB" : "#fff" }}
                  onPress={() => setSelectedAddressId(Number(item?.id))}
                >
                  <Text className="text-sm font-semibold text-gray-900">{item?.real_name} {item?.phone}</Text>
                  <Text className="text-xs text-gray-600 mt-1">
                    {[item?.province, item?.city, item?.district, item?.detail].filter(Boolean).join(" ")}
                  </Text>
                </Pressable>
              );
            })}
            {addresses.length === 0 && (
              <View className="rounded-lg border border-dashed border-gray-300 p-4">
                <Text className="text-sm text-gray-500">{t("pointsConfirm.noAddress")}</Text>
              </View>
            )}
            <Pressable className="mt-2 h-10 rounded-lg border border-gray-300 items-center justify-center" onPress={() => router.push("/profile/address")}>
              <Text className="text-sm font-medium text-gray-700">{t("pointsConfirm.manageAddress")}</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>

      <View className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4">
        <Pressable
          className="h-12 rounded-xl items-center justify-center"
          style={{ }}
          onPress={submit}
          disabled={createOrder.isPending}
        >
          <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
          <Text className="text-white font-bold">{createOrder.isPending ? t("pointsConfirm.submitting") : t("pointsConfirm.submitOrder")}</Text>
        </Pressable>
      </View>
    </View>
  );
}
