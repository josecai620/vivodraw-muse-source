import type { PropsWithChildren } from "react";
import { createContext, useContext, useEffect, useMemo, useReducer, useState } from "react";

import type { PetActionName } from "@/lib/pet-animations";
import { pixelDeskPetIds, type PixelDeskPetId } from "@/lib/pets";

type PetThemeState = {
  activePetId: PixelDeskPetId;
  isFloatingPetEnabled: boolean;
  isMagicThemeEnabled: boolean;
  previewAction: PetActionName;
  previewNonce: number;
};

type PetThemeAction =
  | { type: "hydrate"; state: PetThemeState }
  | { type: "toggle" }
  | { type: "set"; value: boolean }
  | { type: "toggleFloatingPet" }
  | { type: "setFloatingPet"; value: boolean }
  | { type: "setPet"; petId: PixelDeskPetId }
  | { type: "previewAction"; action: PetActionName };

type PetThemeContextValue = {
  activePetId: PixelDeskPetId;
  isFloatingPetEnabled: boolean;
  isMagicThemeEnabled: boolean;
  previewAction: PetActionName;
  previewNonce: number;
  setActivePetId: (petId: PixelDeskPetId) => void;
  setFloatingPetEnabled: (value: boolean) => void;
  setMagicThemeEnabled: (value: boolean) => void;
  setPreviewAction: (action: PetActionName) => void;
  toggleFloatingPet: () => void;
  toggleMagicTheme: () => void;
};

const PetThemeContext = createContext<PetThemeContextValue | null>(null);
const PET_THEME_STORAGE_KEY = "vivodraw:v4:pet-theme:v1";
const DEFAULT_PET_ID: PixelDeskPetId = "cat_programmer";
const DEFAULT_PET_THEME_STATE: PetThemeState = {
  activePetId: DEFAULT_PET_ID,
  isFloatingPetEnabled: true,
  isMagicThemeEnabled: false,
  previewAction: "idle",
  previewNonce: 0,
};

function petThemeReducer(state: PetThemeState, action: PetThemeAction): PetThemeState {
  if (action.type === "hydrate") {
    return action.state;
  }

  if (action.type === "setPet") {
    return {
      ...state,
      activePetId: action.petId,
      isFloatingPetEnabled: true,
      previewAction: "idle",
      previewNonce: state.previewNonce + 1,
    };
  }

  if (action.type === "previewAction") {
    return { ...state, previewAction: action.action, previewNonce: state.previewNonce + 1 };
  }

  if (action.type === "toggle") {
    return { ...state, isMagicThemeEnabled: !state.isMagicThemeEnabled };
  }

  if (action.type === "toggleFloatingPet") {
    return { ...state, isFloatingPetEnabled: !state.isFloatingPetEnabled };
  }

  if (action.type === "setFloatingPet") {
    return { ...state, isFloatingPetEnabled: action.value };
  }

  return { ...state, isMagicThemeEnabled: action.value };
}

export function PetThemeProvider({ children }: PropsWithChildren) {
  const [state, dispatch] = useReducer(petThemeReducer, DEFAULT_PET_THEME_STATE);
  const [hasLoadedStoredPetTheme, setHasLoadedStoredPetTheme] = useState(false);

  useEffect(() => {
    dispatch({ type: "hydrate", state: readStoredPetTheme() });
    setHasLoadedStoredPetTheme(true);
  }, []);

  useEffect(() => {
    if (!hasLoadedStoredPetTheme) {
      return;
    }

    writeStoredPetTheme(state);
  }, [hasLoadedStoredPetTheme, state]);

  const value = useMemo<PetThemeContextValue>(
    () => ({
      activePetId: state.activePetId,
      isFloatingPetEnabled: state.isFloatingPetEnabled,
      isMagicThemeEnabled: state.isMagicThemeEnabled,
      previewAction: state.previewAction,
      previewNonce: state.previewNonce,
      setActivePetId: (petId) => dispatch({ type: "setPet", petId }),
      setFloatingPetEnabled: (value) => dispatch({ type: "setFloatingPet", value }),
      setMagicThemeEnabled: (value) => dispatch({ type: "set", value }),
      setPreviewAction: (action) => dispatch({ type: "previewAction", action }),
      toggleFloatingPet: () => dispatch({ type: "toggleFloatingPet" }),
      toggleMagicTheme: () => dispatch({ type: "toggle" }),
    }),
    [state.activePetId, state.isFloatingPetEnabled, state.isMagicThemeEnabled, state.previewAction, state.previewNonce],
  );

  return <PetThemeContext.Provider value={value}>{children}</PetThemeContext.Provider>;
}

function readStoredPetTheme(): PetThemeState {
  const storage = getStorage();

  if (!storage) {
    return DEFAULT_PET_THEME_STATE;
  }

  try {
    const raw = storage.getItem(PET_THEME_STORAGE_KEY);

    if (!raw) {
      return DEFAULT_PET_THEME_STATE;
    }

    const parsed = JSON.parse(raw) as Partial<PetThemeState>;
    const activePetId = pixelDeskPetIds.includes(parsed.activePetId as PixelDeskPetId) ? (parsed.activePetId as PixelDeskPetId) : DEFAULT_PET_ID;

    return {
      activePetId,
      isFloatingPetEnabled: typeof parsed.isFloatingPetEnabled === "boolean" ? parsed.isFloatingPetEnabled : true,
      isMagicThemeEnabled: Boolean(parsed.isMagicThemeEnabled),
      previewAction: "idle",
      previewNonce: 0,
    };
  } catch {
    return DEFAULT_PET_THEME_STATE;
  }
}

function writeStoredPetTheme(state: PetThemeState) {
  const storage = getStorage();

  if (!storage) {
    return;
  }

  try {
    storage.setItem(PET_THEME_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage failures. Theme still works in memory.
  }
}

function getStorage() {
  if (typeof globalThis === "undefined") {
    return null;
  }

  const storage = (globalThis as { localStorage?: Storage }).localStorage;
  return storage ?? null;
}

export function usePetTheme() {
  const context = useContext(PetThemeContext);

  if (!context) {
    throw new Error("usePetTheme must be used within PetThemeProvider");
  }

  return context;
}
