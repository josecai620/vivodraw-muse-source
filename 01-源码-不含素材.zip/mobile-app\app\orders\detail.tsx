import PageHeader from "@/components/shared/PageHeader";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import { LinearGradient } from "expo-linear-gradient";
import { againOrder, getOrderDetail, takeOrder } from "@/lib/api/order";
import { type ApiRecord, isApiRecord, unwrapApiData, unwrapApiRecord } from "@/lib/api/response";
import { getUserLevelInfo } from "@/lib/api/userLevel";
import {
  MEMBER_SHOP_MULTIPLIER,
  displayMemberTier,
  parseUserLevelPayload,
  resolveMemberFrame,
  shopGiftPoints,
} from "@/lib/会员等级";
import { formatPrice, normalizeImageUrl } from "@/lib/utils";
import { useAuthStore } from "@/store/auth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Coins, MapPin, Package } from "lucide-react-native";
import React from "react";
import { useTranslation } from "react-i18next";
import { ActivityIndicator, Alert, Image, Pressable, ScrollView, Text, View } from "react-native";

type ProductInfo = ApiRecord & {
  id?: number | string;
  image?: string;
  pic?: string;
  store_name?: string;
  price?: string | number;
};

type CartPayload = ApiRecord & {
  unique?: string;
  cart_num?: number | string;
  productInfo?: ProductInfo;
};

type OrderCartItem = ApiRecord & {
  id?: number | string;
  cart_id?: number | string;
  cart_num?: number | string;
  productInfo?: ProductInfo;
  cart_info?: CartPayload;
};

type OrderDetail = ApiRecord & {
  id?: number | string;
  order_id?: string;
  create_time?: string;
  add_time?: string;
  cartInfo?: OrderCartItem[];
  _status?: ApiRecord & { _type?: number | string; _title?: string };
  refund_status?: number | string;
  paid?: number | string;
  status?: number | string;
  shipping_type?: number | string;
  real_name?: string;
  user_phone?: string;
  user_address?: string;
  pay_price?: string | number;
};

function numberValue(value: unknown, fallback = 0): number {
  const next = Number(value);
  return Number.isFinite(next) ? next : fallback;
}

function getOrderCartInfo(order: OrderDetail): OrderCartItem[] {
  return Array.isArray(order.cartInfo) ? order.cartInfo : [];
}

function getProductInfo(item: OrderCartItem): ProductInfo {
  const productInfo = item.productInfo ?? item.cart_info?.productInfo;
  return isApiRecord(productInfo) ? (productInfo as ProductInfo) : {};
}

function getOrderCartKey(item: OrderCartItem): string {
  const productInfo = getProductInfo(item);
  return String(
    item.id ??
      item.cart_id ??
      item.cart_info?.unique ??
      productInfo.id ??
      productInfo.store_name ??
      "order-cart-item",
  );
}

function ActionButton({
  label,
  onPress,
  primary,
}: {
  label: string;
  onPress: () => void;
  primary?: boolean;
}) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        paddingHorizontal: s(16),
        paddingVertical: s(8),
        borderRadius: s(8),
        backgroundColor: primary ? "transparent" : Colors.neutral[100],
        borderWidth: primary ? 0 : 1,
        borderColor: Colors.neutral[300],
        shadowColor: "#04A8AE",
        shadowOffset: { width: 0, height: 5 },
        shadowOpacity: primary ? 0.28 : 0,
        shadowRadius: 10,
        elevation: primary ? 5 : 0,
      }}
    >
      {primary && (
        <>
          <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 8 }} />
          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 8 }} />
        </>
      )}
      <Text
        style={{
          fontSize: s(14),
          fontWeight: "600",
          color: primary ? "#FFF" : Colors.neutral[700],
        }}
      >
        {label}
      </Text>
    </Pressable>
  );
}

export default function OrderDetailScreen() {
  const { t, i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const queryClient = useQueryClient();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const { data: levelRaw } = useQuery({
    queryKey: ["userLevelInfo"],
    queryFn: getUserLevelInfo,
    enabled: isLoggedIn,
  });

  const { data, isLoading } = useQuery({
    queryKey: ["orderDetail", id],
    queryFn: () => getOrderDetail(id ?? ""),
    enabled: !!id,
  });

  const takeMutation = useMutation({
    mutationFn: () => takeOrder(id ?? ""),
    onSuccess: (res) => {
      queryClient.invalidateQueries({ queryKey: ["orderDetail", id] });
      queryClient.invalidateQueries({ queryKey: ["orderList"] });
      queryClient.invalidateQueries({ queryKey: ["messageList"] });
      const gift = Number(unwrapApiData<{ gift_points?: number }>(res, {}).gift_points ?? 0);
      Alert.alert(
        t("shopOrderDetail.giftSuccessTitle"),
        gift > 0
          ? t("shopOrderDetail.giftSuccessBody", { pts: gift })
          : t("shopOrderDetail.giftSuccessZero"),
      );
    },
  });

  const againMutation = useMutation({
    mutationFn: () => againOrder(id ?? ""),
    onSuccess: (res: unknown) => {
      const payload = unwrapApiRecord<ApiRecord>(res, {});
      const cartId = payload.cartId ?? payload.cart_id;
      if (cartId) router.replace(`/checkout?cartId=${String(cartId)}`);
      else router.replace("/(tabs)/cart");
    },
  });

  if (!id) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("shopOrderDetail.title")} />
        <View className="flex-1 items-center justify-center">
          <Text style={{ color: Colors.neutral[500] }}>{t("shopOrderDetail.missingOrderId")}</Text>
        </View>
      </View>
    );
  }

  if (isLoading) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("shopOrderDetail.title")} />
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      </View>
    );
  }

  const raw = unwrapApiRecord<ApiRecord>(data, {});
  const orderSource = isApiRecord(raw.orderInfo) ? raw.orderInfo : raw;
  const order = orderSource as OrderDetail;
  if (!order) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("shopOrderDetail.title")} />
        <View className="flex-1 items-center justify-center px-6">
          <Text style={{ color: Colors.neutral[500] }}>{t("shopOrderDetail.notFound")}</Text>
        </View>
      </View>
    );
  }

  const cartInfo = getOrderCartInfo(order);
  const status = order._status ?? {};
  const statusType = numberValue(status._type);
  const refundStatus = numberValue(order.refund_status);
  const paid = numberValue(order.paid);
  const orderStatus = numberValue(order.status);
  const orderId = String(order.order_id ?? id);
  const shippingType = numberValue(order.shipping_type);

  const canRefund = paid === 1 && [0, 3].includes(refundStatus);
  const canReview = statusType === 3 || statusType === 4;
  const canTake = statusType === 2;
  const canAgain = statusType === 3 || statusType === 4;
  const payUsd = numberValue(order.pay_price);
  const parsed = parseUserLevelPayload(isLoggedIn ? levelRaw : null);
  const frameState = resolveMemberFrame({
    isLoggedIn,
    isMoneyLevel: parsed.user?.is_money_level,
    isEverLevel: parsed.user?.is_ever_level,
    overdueTime: parsed.user?.overdue_time,
    memberType: parsed.user?.member_type,
    spendUsd: parsed.user?.spend_usd ?? parsed.user?.pay_price,
  });
  const frameTier = displayMemberTier(frameState);
  const giftLevel = frameState.trialActive ? 0 : frameState.level;
  const giftPts = shopGiftPoints(payUsd, giftLevel);
  const giftRegular = shopGiftPoints(payUsd, 0);
  const giftGold = shopGiftPoints(payUsd, 2);
  const giftMult = MEMBER_SHOP_MULTIPLIER[giftLevel];
  const giftVars = {
    pay: formatPrice(payUsd),
    tier: zh ? frameTier.nameZh : `${frameTier.nameEn} Member`,
    mult: giftMult.toFixed(1),
    pts: giftPts,
    regular: giftRegular,
    gold: giftGold,
  };

  const handleTake = () => {
    Alert.alert(t("shopOrderDetail.giftConfirmTitle"), t("shopOrderDetail.giftConfirmBody", giftVars), [
      { text: t("common.cancel"), style: "cancel" },
      { text: t("shopOrderDetail.giftConfirmNow"), onPress: () => takeMutation.mutate() },
    ]);
  };

  const handleAgain = () => {
    againMutation.mutate();
  };

  const handleRefund = () => {
    router.push(`/orders/refund?orderId=${orderId}&id=${String(order.id ?? "")}`);
  };

  const handleReview = () => {
    router.push(`/orders/review?orderId=${orderId}&id=${String(order.id ?? "")}`);
  };

  const handleExpress = () => {
    router.push(`/orders/express?orderId=${orderId}`);
  };

  const handleInvoice = () => {
    router.push(`/orders/invoice-apply?orderId=${orderId}`);
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("shopOrderDetail.title")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingBottom: s(100) }}
        showsVerticalScrollIndicator={false}
      >
        {/* Status */}
        <View className="mx-4 mt-4 rounded-2xl p-4" style={{ }}>
          <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 16, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 16 }} />
          <Text className="text-lg font-semibold" style={{ color: "#FFF" }}>
            {status._title ?? t("shopOrderDetail.order")}
          </Text>
          <Text className="text-sm mt-1" style={{ color: "rgba(255,255,255,0.9)" }}>
            {orderId}
          </Text>
          <Text className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.8)" }}>
            {order.create_time ?? order.add_time}
          </Text>
        </View>

        {/* Address */}
        {(shippingType === 1 || shippingType === 3) && (
          <View className="mx-4 mt-4 bg-white rounded-2xl p-4 border border-gray-100">
            <View className="flex-row items-center gap-2 mb-2">
              <MapPin size={s(18)} color={Colors.neutral[600]} />
              <Text className="font-semibold" style={{ color: Colors.neutral[800] }}>
                {t("shopOrderDetail.shippingAddress")}
              </Text>
            </View>
            <Text style={{ color: Colors.neutral[700] }}>
              {order.real_name} {order.user_phone}
            </Text>
            <Text className="mt-1" style={{ color: Colors.neutral[600], fontSize: s(14) }}>
              {order.user_address}
            </Text>
          </View>
        )}

        {/* Goods */}
        <View className="mx-4 mt-4 bg-white rounded-2xl p-4 border border-gray-100">
          <View className="flex-row items-center gap-2 mb-3">
            <Package size={s(18)} color={Colors.neutral[600]} />
            <Text className="font-semibold" style={{ color: Colors.neutral[800] }}>
              {t("shopOrderDetail.products")}
            </Text>
          </View>
          {cartInfo.map((item, idx) => {
            const info = getProductInfo(item);
            const img = info.image ?? info.pic ?? "";
            const name = info.store_name ?? t("shopOrderDetail.productFallback");
            const num = item?.cart_num ?? item?.cart_info?.cart_num ?? 1;
            const price = info.price ?? item?.cart_info?.productInfo?.price ?? "0";
            return (
              <View
                key={getOrderCartKey(item)}
                className="flex-row py-3 border-b border-gray-50"
                style={{ borderBottomWidth: idx < cartInfo.length - 1 ? 1 : 0 }}
              >
                <Image
                  source={{ uri: normalizeImageUrl(img) }}
                  style={{ width: s(72), height: s(72), borderRadius: s(12) }}
                  resizeMode="cover"
                />
                <View className="flex-1 ml-3 justify-center">
                  <Text
                    className="font-medium"
                    style={{ color: Colors.neutral[800] }}
                    numberOfLines={2}
                  >
                    {name}
                  </Text>
                  <Text className="text-sm mt-1" style={{ color: Colors.neutral[500] }}>
                    x{num} · {formatPrice(price)}
                  </Text>
                </View>
              </View>
            );
          })}
        </View>

        {/* Price */}
        <View className="mx-4 mt-4 bg-white rounded-2xl p-4 border border-gray-100">
          <View className="flex-row justify-between py-2">
            <Text style={{ color: Colors.neutral[600] }}>{t("shopOrderDetail.total")}</Text>
            <Text className="font-bold" style={{ color: Colors.brand.red, fontSize: s(18) }}>
              {formatPrice(order.pay_price ?? 0)}
            </Text>
          </View>
        </View>

        {canTake ? (
          <View
            className="mx-4 mt-4 rounded-2xl p-4"
            style={{ backgroundColor: "#ECFBFB", borderWidth: 2, borderColor: "#04A8AE" }}
          >
            <View className="flex-row items-center gap-2">
              <Coins size={s(22)} color="#04A8AE" />
              <Text className="text-base font-extrabold" style={{ color: "#111827" }}>
                {t("shopOrderDetail.giftBannerTitle")}
              </Text>
            </View>
            <Text className="text-3xl font-black mt-2" style={{ color: "#04A8AE" }}>
              +{giftPts} {zh ? "積分" : "pts"}
            </Text>
            <Text className="text-sm leading-5 mt-2" style={{ color: "#374151" }}>
              {t("shopOrderDetail.giftBannerBody", giftVars)}
            </Text>
          </View>
        ) : null}

        {/* Actions */}
        <View className="mx-4 mt-6 flex-row flex-wrap gap-3">
          {canRefund && (
            <ActionButton label={t("shopOrderDetail.applyRefund")} onPress={handleRefund} primary />
          )}
          {canReview && (
            <ActionButton label={t("shopOrderDetail.review")} onPress={handleReview} primary />
          )}
          {canTake && (
            <ActionButton
              label={t("shopOrderDetail.confirmReceipt")}
              onPress={handleTake}
              primary
            />
          )}
          {canAgain && <ActionButton label={t("shopOrderDetail.buyAgain")} onPress={handleAgain} />}
          {(orderStatus >= 1 || statusType >= 2) && (shippingType === 1 || shippingType === 3) && (
            <ActionButton label={t("shopOrderDetail.track")} onPress={handleExpress} />
          )}
          {paid === 1 && (
            <ActionButton label={t("shopOrderDetail.applyInvoice")} onPress={handleInvoice} />
          )}
        </View>
      </ScrollView>
    </View>
  );
}
