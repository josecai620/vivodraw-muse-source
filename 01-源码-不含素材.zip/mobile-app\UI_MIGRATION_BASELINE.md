# mobile-app 新界面嵌入基线（含老界面对照）

## 1. 目标与边界

- 新界面来源：`frontend_src/云小福盲盒`（已复制为 `backend_src/view/uniapp-legacy` 便于对照）
- 线上前台：`mobile-app`（Expo / React Native Web）
- 老界面对照：`backend_src/view/uniapp-legacy`，用 HBuilderX 打开 → 运行到浏览器，不部署

注意：旧 Uniapp H5 已与后端断开，不将 `frontend_src/云小福盲盒` 直接部署到生产。

## 2. 目录约定

- 新实现目录：`mobile-app/app/**`
- 接口封装：`mobile-app/lib/api/**`
- 常量与主题：`mobile-app/lib/**`、`mobile-app/constants/**`
- 对照说明文档：`mobile-app/UI_MIGRATION_BASELINE.md`（本文档）

## 3. 新旧界面对照规则

1. 以 `frontend_src/云小福盲盒/pages/**` 的页面结构为业务输入。
2. 在 `mobile-app/app/**` 中按 Expo 路由重建页面，不直接复制 Vue/Uniapp 代码。
3. 每迁移一个页面，必须同步核对：
   - API 端点是否已有（`mobile-app/constants/api.ts`）
   - API 调用是否复用（`mobile-app/lib/api/*.ts`）
   - 业务状态是否复用现有 hooks/store（`mobile-app/hooks/**`、`mobile-app/stores/**`）
4. 老界面只做逻辑和交互对照，不做样式复刻硬约束。

## 4. 执行节奏（建议按批次）

### P0：盲盒主链路

- 首页入口（盲盒入口区块）
- 盲盒列表
- 盲盒详情
- 开盒流程
- 开盒结果/记录

### P1：积分与兑换链路

- 积分首页
- 积分商品列表/详情
- 地址管理
- 兑换记录

### P2：用户资产链路

- 个人中心关联页
- 订单、支付、退款相关视图
- 余额/账单/优惠券相关视图

## 5. 每页迁移完成定义（DoD）

- 路由可达，页面无白屏
- 核心接口正常返回，错误态可见
- 关键按钮可点击，流程可闭环
- TypeScript 检查通过（至少 `npm run typecheck`）
- 文案走现有国际化方案（如适用）

## 6. 部署与验证

- 改动 `mobile-app` 后：在项目根执行 `bash deploy/构建并上传前台Expo.sh`
- 不执行旧 H5 构建脚本（`deploy/构建并上传H5.sh` / `deploy/上传H5到服务器.sh`）

## 7. 协作说明

- 若需要“保留当前 Expo 老版本”做对照，优先用 Git 分支保存，不在生产路由新增 legacy 入口。
- 本文档是迁移基线，后续页面级映射可在同目录新增专题文档（如 `UI_MIGRATION_BOX.md`）。
