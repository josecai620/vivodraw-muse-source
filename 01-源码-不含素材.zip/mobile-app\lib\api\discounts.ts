import { API_ENDPOINTS } from "@/constants/api";
import { http } from "@/lib/http";

export interface DiscountProduct {
  id?: number;
  product_id?: number;
  image?: string;
  pic?: string;
  store_name?: string;
  title?: string;
  price?: string | number;
  discount_price?: string | number;
}

export function getDiscountsList(productId: number) {
  return http.get<{ list?: DiscountProduct[] } | DiscountProduct[]>(
    API_ENDPOINTS.discounts.list(productId),
  );
}
