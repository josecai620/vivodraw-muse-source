import React from "react";
import { Image, type ImageSourcePropType, type ImageStyle, type StyleProp } from "react-native";

export type ClassicProfileIllustrationTheme = "soft-sorbet" | "airy-linen";
export type ClassicProfileIllustrationName =
  | "wallet"
  | "orders-gift-box"
  | "wishlist-favorites"
  | "points-badge-flower"
  | "coupons-coupon-ticket"
  | "membership-crown"
  | "level-medal"
  | "commission-team-affiliate"
  | "help"
  | "privacy"
  | "share"
  | "language"
  | "logout"
  | "settings"
  | "history-identity-search"
  | "address-home"
  | "payment-wallet-card"
  | "invoices-receipt"
  | "notifications-bell"
  | "profile-account-settings"
  | "messages-pouch"
  | "articles-book";

const illustrationSources: Record<
  ClassicProfileIllustrationName,
  Partial<Record<ClassicProfileIllustrationTheme, ImageSourcePropType>>
> = {
  wallet: {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/wallet.png"),
  },
  "orders-gift-box": {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/orders-gift-box.png"),
  },
  "wishlist-favorites": {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/wishlist-favorites.png"),
  },
  "points-badge-flower": {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/points-badge-flower.png"),
  },
  "coupons-coupon-ticket": {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/coupons-coupon-ticket.png"),
  },
  "membership-crown": {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/membership-crown.png"),
  },
  "level-medal": {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/level-medal.png"),
  },
  "commission-team-affiliate": {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/commission-team-affiliate.png"),
  },
  help: {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/help.png"),
  },
  privacy: {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/privacy.png"),
  },
  share: {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/share.png"),
  },
  language: {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/language.png"),
  },
  logout: {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/logout.png"),
  },
  settings: {
    "soft-sorbet": require("../../assets/classic-profile-icons/soft-sorbet/settings.png"),
  },
  "history-identity-search": {
    "airy-linen": require("../../assets/classic-profile-icons/airy-linen/history-identity-search.png"),
  },
  "address-home": {
    "airy-linen": require("../../assets/classic-profile-icons/airy-linen/address-home.png"),
  },
  "payment-wallet-card": {
    "airy-linen": require("../../assets/classic-profile-icons/airy-linen/payment-wallet-card.png"),
  },
  "invoices-receipt": {
    "airy-linen": require("../../assets/classic-profile-icons/airy-linen/invoices-receipt.png"),
  },
  "notifications-bell": {
    "airy-linen": require("../../assets/classic-profile-icons/airy-linen/notifications-bell.png"),
  },
  "profile-account-settings": {
    "airy-linen": require("../../assets/classic-profile-icons/airy-linen/profile-account-settings.png"),
  },
  "messages-pouch": {
    "airy-linen": require("../../assets/classic-profile-icons/airy-linen/messages-pouch.png"),
  },
  "articles-book": {
    "airy-linen": require("../../assets/classic-profile-icons/airy-linen/articles-book.png"),
  },
};

const defaultThemes: Record<ClassicProfileIllustrationName, ClassicProfileIllustrationTheme> = {
  wallet: "soft-sorbet",
  "orders-gift-box": "soft-sorbet",
  "wishlist-favorites": "soft-sorbet",
  "points-badge-flower": "soft-sorbet",
  "coupons-coupon-ticket": "soft-sorbet",
  "membership-crown": "soft-sorbet",
  "level-medal": "soft-sorbet",
  "commission-team-affiliate": "soft-sorbet",
  help: "soft-sorbet",
  privacy: "soft-sorbet",
  share: "soft-sorbet",
  language: "soft-sorbet",
  logout: "soft-sorbet",
  settings: "soft-sorbet",
  "history-identity-search": "airy-linen",
  "address-home": "airy-linen",
  "payment-wallet-card": "airy-linen",
  "invoices-receipt": "airy-linen",
  "notifications-bell": "airy-linen",
  "profile-account-settings": "airy-linen",
  "messages-pouch": "airy-linen",
  "articles-book": "airy-linen",
};

const opticalAdjustments: Partial<
  Record<
    ClassicProfileIllustrationName,
    { scale?: number; translateX?: number; translateY?: number }
  >
> = {
  "wishlist-favorites": {
    scale: 1.04,
    translateY: 1,
  },
  "points-badge-flower": {
    scale: 1.05,
    translateY: 1.5,
  },
  "coupons-coupon-ticket": {
    scale: 1.06,
    translateX: -1.5,
    translateY: -0.5,
  },
};

type ClassicProfileIllustrationProps = {
  name: ClassicProfileIllustrationName;
  size?: number;
  style?: StyleProp<ImageStyle>;
  theme?: ClassicProfileIllustrationTheme;
  accessibilityLabel?: string;
};

function resolveIllustrationSource(
  name: ClassicProfileIllustrationName,
  theme?: ClassicProfileIllustrationTheme,
): ImageSourcePropType {
  const themedSources = illustrationSources[name];
  const resolvedTheme = theme && theme in themedSources ? theme : defaultThemes[name];
  const source = themedSources[resolvedTheme];
  if (!source) {
    throw new Error(`Missing classic profile illustration: ${name}/${resolvedTheme}`);
  }
  return source;
}

export default function ClassicProfileIllustration({
  name,
  size = 48,
  style,
  theme,
  accessibilityLabel,
}: ClassicProfileIllustrationProps) {
  const adjust = opticalAdjustments[name];

  return (
    <Image
      source={resolveIllustrationSource(name, theme)}
      accessibilityLabel={accessibilityLabel}
      resizeMode="contain"
      style={[
        {
          width: size,
          height: size,
          transform: [
            { translateX: adjust?.translateX ?? 0 },
            { translateY: adjust?.translateY ?? 0 },
            { scale: adjust?.scale ?? 1 },
          ],
        },
        style,
      ]}
    />
  );
}
