import React, { useMemo, useState } from "react";
import { View, StyleSheet, Image as RNImage } from "react-native";
import { Image } from "expo-image";
import { resolveUserAvatarSource } from "@/lib/userAvatar";

const STAMP = require("../../assets/yunmall/reveal-stamp-revealed.png");
const RIBBON = require("../../assets/yunmall/winner-corner-ribbon.png");
const PREV_RIBBON = require("../../assets/yunmall/prev-winner-corner-ribbon.png");

/** 已揭晓印章：盖在商品主图左侧（用户标注的方框），倒计时不显示。 */
export function ProductImageRevealStamp({ imageHeight = 240 }: { imageHeight?: number }) {
  const size = Math.round(Math.min(120, imageHeight * 0.48));
  const top = Math.max(10, Math.round((imageHeight - size) / 2) - 6);
  return (
    <Image
      source={STAMP}
      style={[styles.productStamp, { width: size, height: size, top, left: 14 }]}
      contentFit="contain"
      pointerEvents="none"
    />
  );
}

export function WinnerCornerRibbon({ size = 56 }: { size?: number }) {
  return (
    <Image
      source={RIBBON}
      style={[styles.overlay, { width: size, height: size }]}
      contentFit="cover"
      pointerEvents="none"
    />
  );
}

export function PrevWinnerCornerRibbon({ size = 56 }: { size?: number }) {
  return (
    <Image
      source={PREV_RIBBON}
      style={[styles.overlay, { width: size, height: size }]}
      contentFit="cover"
      pointerEvents="none"
    />
  );
}

export function WinnerAvatar({
  uri,
  uid,
  seed,
  size = 56,
  variant = "winner",
  rounded = "circle",
}: {
  uri?: string;
  uid?: number;
  seed?: string | number;
  size?: number;
  variant?: "winner" | "prev";
  rounded?: "circle" | "square";
}) {
  const radius = rounded === "square" ? 6 : size / 2;
  const fallback = useMemo(() => resolveUserAvatarSource("", uid, seed), [uid, seed]);
  const resolved = useMemo(() => resolveUserAvatarSource(uri, uid, seed), [uri, uid, seed]);
  const [source, setSource] = useState(resolved);
  React.useEffect(() => {
    setSource(resolved);
  }, [resolved]);
  /** 系统头像 PNG 自带白边和蓝圈，放大裁切后脸才铺满头像框。 */
  const fill = size * 1.92;
  const offset = (size - fill) / 2;
  return (
    <View
      style={{
        width: size,
        height: size,
        position: "relative",
        overflow: "hidden",
        borderRadius: radius,
        backgroundColor: "#E5E7EB",
      }}
    >
      <RNImage
        source={source}
        style={{
          position: "absolute",
          width: fill,
          height: fill,
          left: offset,
          top: offset - size * 0.04,
        }}
        resizeMode="cover"
        onError={() => setSource(fallback)}
      />
      {variant === "prev" ? <PrevWinnerCornerRibbon size={size} /> : <WinnerCornerRibbon size={size} />}
    </View>
  );
}

const styles = StyleSheet.create({
  productStamp: {
    position: "absolute",
    zIndex: 8,
    opacity: 0.94,
    transform: [{ rotate: "-12deg" }],
  },
  overlay: {
    position: "absolute",
    top: 0,
    left: 0,
    zIndex: 8,
  },
});
