import { useEffect, useRef } from "react";
import { Animated, Easing, Image, Platform, Pressable, StyleSheet, Text, View } from "react-native";

const nativeDriver = Platform.OS !== "web";
const farmland = require("../../assets/极简农场/耕地空地-轻量.webp");
const wheatM = require("../../assets/极简农场/小麦成熟-轻量.webp");
const cornM = require("../../assets/极简农场/玉米成熟-轻量.webp");
const tomatoM = require("../../assets/极简农场/番茄成熟-轻量.webp");
const berryM = require("../../assets/极简农场/草莓成熟-轻量.webp");
const melonM = require("../../assets/极简农场/西瓜成熟-轻量.webp");
const wheatG = require("../../assets/极简农场/小麦生长-轻量.webp");
const cornG = require("../../assets/极简农场/玉米生长-轻量.webp");

/**
 * Locked stage aspect matches the concept plate.
 * Plot % tuned to the painted 3×3 empty mounds on the exaggerated isometric diamond.
 */
const FIELD_W = 1200;
const FIELD_H = 675;

/** Centers measured from painted 3×3 soil pads (image 1200×675). */
const RAW = [
  { id: 1, left: 600, top: 144, ripe: true, crop: wheatM },
  { id: 2, left: 755, top: 242, ripe: true, crop: cornM },
  { id: 3, left: 906, top: 337, ripe: false, crop: wheatG },
  { id: 4, left: 445, top: 242, ripe: true, crop: tomatoM },
  { id: 5, left: 601, top: 338, ripe: true, crop: berryM },
  { id: 6, left: 755, top: 432, ripe: false, crop: cornG },
  { id: 7, left: 295, top: 338, ripe: true, crop: melonM },
  { id: 8, left: 446, top: 432, ripe: true, crop: wheatM },
  { id: 9, left: 600, top: 529, ripe: false, crop: wheatG },
] as const;

function PlotNode({
  leftPct,
  topPct,
  ripe,
  crop,
  z,
  disabled,
  busy,
  onPress,
}: {
  leftPct: number;
  topPct: number;
  ripe: boolean;
  crop: number;
  z: number;
  disabled?: boolean;
  busy?: boolean;
  onPress: () => void;
}) {
  const pulse = useRef(new Animated.Value(0)).current;
  const squash = useRef(new Animated.Value(1)).current;
  const canTap = ripe && !disabled && !busy;

  useEffect(() => {
    if (!ripe || disabled) {
      pulse.setValue(0);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 750, easing: Easing.inOut(Easing.sin), useNativeDriver: nativeDriver }),
        Animated.timing(pulse, { toValue: 0, duration: 750, easing: Easing.inOut(Easing.sin), useNativeDriver: nativeDriver }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [disabled, pulse, ripe]);

  const handlePress = () => {
    if (!canTap) return;
    Animated.sequence([
      Animated.timing(squash, { toValue: 0.86, duration: 70, useNativeDriver: nativeDriver }),
      Animated.spring(squash, { toValue: 1.06, friction: 4, tension: 220, useNativeDriver: nativeDriver }),
      Animated.timing(squash, { toValue: 1, duration: 80, useNativeDriver: nativeDriver }),
    ]).start();
    onPress();
  };

  return (
    <Animated.View
      style={[
        styles.plotWrap,
        {
          left: `${leftPct}%`,
          top: `${topPct}%`,
          zIndex: z,
          transform: [
            { translateY: pulse.interpolate({ inputRange: [0, 1], outputRange: [0, ripe ? -4 : 0] }) },
            { scale: squash },
          ],
        },
      ]}
    >
      <Pressable disabled={!canTap} onPress={handlePress} style={({ pressed }) => [styles.hit, pressed && canTap && styles.hitPressed]}>
        {ripe ? (
          <>
            <Image source={crop} style={styles.crop} />
            <Animated.View
              style={[styles.glow, { opacity: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.18, 0.55] }) }]}
            />
          </>
        ) : (
          <Text style={styles.growing}>生长中</Text>
        )}
      </Pressable>
    </Animated.View>
  );
}

/** Farmland art + 9 plots share one aspect-ratio box — resize keeps them glued. */
export function IsoFarmStage({
  busy,
  disabled,
  onPlotPress,
}: {
  busy?: boolean;
  disabled?: boolean;
  onPlotPress: () => void;
}) {
  return (
    <View style={styles.slot}>
      <View style={styles.stage}>
        <Image source={farmland} style={styles.farmland} resizeMode="contain" />
        {[...RAW]
          .sort((a, b) => a.top - b.top || a.left - b.left)
          .map((plot, index) => (
          <PlotNode
            key={plot.id}
            leftPct={(plot.left / FIELD_W) * 100}
            topPct={(plot.top / FIELD_H) * 100}
            ripe={plot.ripe}
            crop={plot.crop}
            z={index + 2}
            busy={busy}
            disabled={disabled}
            onPress={onPlotPress}
          />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  slot: {
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    flex: 1,
    minHeight: 280,
    paddingBottom: 100,
    paddingTop: 72,
  },
  stage: {
    width: "100%",
    maxWidth: 640,
    aspectRatio: FIELD_W / FIELD_H,
    position: "relative",
  },
  farmland: {
    ...StyleSheet.absoluteFillObject,
    width: "100%",
    height: "100%",
    zIndex: 1,
  },
  plotWrap: {
    position: "absolute",
    width: "11%",
    aspectRatio: 1,
    marginLeft: "-5.5%",
    marginTop: "-9%",
    alignItems: "center",
  },
  hit: { width: "100%", height: "100%", alignItems: "center", justifyContent: "flex-end" },
  hitPressed: { opacity: 0.92 },
  crop: { width: "100%", height: "100%", resizeMode: "contain" },
  dim: { opacity: 0.55 },
  glow: {
    position: "absolute",
    bottom: "8%",
    width: "58%",
    height: "42%",
    borderRadius: 999,
    backgroundColor: "rgba(255, 210, 90, 0.35)",
  },
  growing: {
    position: "absolute",
    bottom: 0,
    color: "rgba(60, 48, 28, 0.75)",
    fontSize: 10,
    fontWeight: "800",
  },
});
