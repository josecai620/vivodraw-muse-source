import React from "react";
import { ScrollView, Text, View } from "react-native";
import { PageHeader } from "@/components/shared";
import { usePointsFanxianList } from "@/hooks";

export default function PointsCashbackScreen() {
  const { data } = usePointsFanxianList();
  const list = (data as any)?.data?.lists ?? (data as any)?.lists ?? [];

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Cashback Records" />
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="p-4 gap-2">
          {(Array.isArray(list) ? list : []).map((item: any, index: number) => (
            <View key={item?.id ?? index} className="bg-white border border-gray-100 rounded-xl p-4">
              <Text className="text-sm font-semibold text-gray-900">{item?.title ?? "Cashback"}</Text>
              <Text className="text-xs text-gray-500 mt-1">{item?.add_time ?? ""}</Text>
              <Text className="text-sm mt-2">
                Amount: <Text className="font-bold text-brand-red">{Number(item?.number ?? 0)}</Text>
              </Text>
              <Text className="text-xs text-gray-500 mt-1">Balance: {item?.balance ?? "-"}</Text>
            </View>
          ))}
          {(!Array.isArray(list) || list.length === 0) && (
            <View className="bg-white border border-gray-100 rounded-xl p-6">
              <Text className="text-sm text-gray-500">No cashback records yet</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}
