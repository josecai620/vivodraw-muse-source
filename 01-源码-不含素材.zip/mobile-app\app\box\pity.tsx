/**
 * 保底机制说明 + 个人保底进度（真实后端对接版）
 */
import React, { useState } from "react";
import { Pressable, ScrollView, Text, View, ActivityIndicator } from "react-native";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Shield, Zap, Gift, TrendingUp, ChevronDown } from "lucide-react-native";
import { BoxHeader, BoxProgressBar } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, getRarityTier, bs,
} from "@/lib/boxTheme";
import { usePityInfo } from "@/hooks";

export default function PityPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const { data: pityInfo, isLoading } = usePityInfo();
  const [rulesOpen, setRulesOpen] = useState(true);
  const [faqOpen, setFaqOpen] = useState(false);

  const consecutiveNonRare = (pityInfo as any)?.consecutiveNonRare ?? 0;
  const totalOpens = (pityInfo as any)?.totalOpens ?? 0;
  const thresholds: any[] = (pityInfo as any)?.thresholds ?? [
    { rarity: "rare", threshold: 10, color: "#04A8AE" },
    { rarity: "epic", threshold: 30, color: "#04A8AE" },
    { rarity: "legendary", threshold: 60, color: "#04A8AE" },
    { rarity: "secret", threshold: 90, color: "#04A8AE" },
  ];

  if (isLoading) {
    return (
      <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
        <BoxHeader title={t("pity.title")} showThemeToggle={false} />
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator size="large" color={BoxAccent.gold} />
          <Text style={[BoxTypography.body, { color: BoxText.tertiary, marginTop: BoxSpacing.lg }]}>
            {t("common.loading")}
          </Text>
        </View>
      </View>
    );
  }

  const rules = [
    { icon: TrendingUp, titleKey: "pity.rule1Title", descKey: "pity.rule1Desc", color: "#04A8AE" },
    { icon: Zap, titleKey: "pity.rule2Title", descKey: "pity.rule2Desc", color: "#04A8AE" },
    { icon: Gift, titleKey: "pity.rule3Title", descKey: "pity.rule3Desc", color: "#04A8AE" },
    { icon: Shield, titleKey: "pity.rule4Title", descKey: "pity.rule4Desc", color: "#04A8AE" },
  ];

  const faqs = [
    { qKey: "pity.faq1q", aKey: "pity.faq1a" },
    { qKey: "pity.faq2q", aKey: "pity.faq2a" },
    { qKey: "pity.faq3q", aKey: "pity.faq3a" },
    { qKey: "pity.faq4q", aKey: "pity.faq4a" },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("pity.title")} showThemeToggle={false} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(96) }}>
          {/* Hero Card */}
          <View style={{
            borderRadius: BoxRadius["2xl"],
            overflow: "hidden",
            marginBottom: BoxSpacing["2xl"],
            borderWidth: 1,
            borderColor: BoxAccent.goldBorder,
            ...BoxShadows.glow(BoxAccent.gold),
          }}>
            <LinearGradient
              colors={BoxGradients.goldWarm}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{ padding: BoxSpacing.xl }}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm, marginBottom: BoxSpacing.xl }}>
                <Shield size={bs(20)} color={BoxAccent.gold} />
                <Text style={[BoxTypography.h3, { color: BoxText.primary }]}>
                  {t("pity.myProgress")}
                </Text>
                <View style={{ flex: 1 }} />
                <Text style={[BoxTypography.caption, { color: BoxText.tertiary }]}>
                  {t("pity.totalOpens", { count: totalOpens })}
                </Text>
              </View>

              <View style={{ alignItems: "center", marginBottom: BoxSpacing["2xl"] }}>
                <Text style={[BoxTypography.hero, { color: BoxAccent.gold, fontSize: bs(56), lineHeight: bs(64) }]}>
                  {consecutiveNonRare}
                </Text>
                <Text style={[BoxTypography.caption, { color: BoxText.secondary, marginTop: BoxSpacing.xs }]}>
                  {t("pity.consecutiveNonRare")}
                </Text>
              </View>

              {thresholds.map((tier: any, idx: number) => {
                const remaining = Math.max(0, tier.threshold - consecutiveNonRare);
                const progress = Math.min(100, (consecutiveNonRare / tier.threshold) * 100);
                const rarityConfig = getRarityTier(tier.rarity);
                return (
                  <View key={tier.rarity} style={{ marginBottom: idx < thresholds.length - 1 ? BoxSpacing.md : 0 }}>
                    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: BoxSpacing.xs }}>
                      <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm }}>
                        <View style={{
                          width: bs(10),
                          height: bs(10),
                          borderRadius: bs(5),
                          backgroundColor: rarityConfig.color,
                        }} />
                        <Text style={[BoxTypography.caption, { color: BoxText.primary }]}>
                          {t("rarity." + tier.rarity)}
                        </Text>
                      </View>
                      <Text style={[BoxTypography.micro, {
                        color: remaining === 0 ? BoxAccent.gold : BoxText.tertiary,
                      }]}>
                        {remaining === 0 ? t("pity.triggered") : t("pity.remaining", { count: remaining })}
                      </Text>
                    </View>
                    <BoxProgressBar
                      progress={progress}
                      color={rarityConfig.color}
                      size="standard"
                      glow={remaining === 0}
                      delay={idx * 100}
                    />
                  </View>
                );
              })}
            </LinearGradient>
          </View>

          {/* Rules Accordion */}
          <Pressable
            onPress={() => setRulesOpen(!rulesOpen)}
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: BoxSpacing.md,
            }}
          >
            <Text style={[BoxTypography.h2, { color: BoxText.primary }]}>
              {t("pity.ruleTitle")}
            </Text>
            <ChevronDown
              size={bs(20)}
              color={BoxText.tertiary}
              style={{ transform: [{ rotate: rulesOpen ? "180deg" : "0deg" }] } as any}
            />
          </Pressable>
          {rulesOpen && (
            <View style={{
              borderRadius: BoxRadius.xl,
              overflow: "hidden",
              marginBottom: BoxSpacing["2xl"],
              backgroundColor: BoxSurfaces.card,
              borderWidth: 1,
              borderColor: BoxBorders.default,
            }}>
              {rules.map((rule, idx) => {
                const Icon = rule.icon;
                return (
                  <View
                    key={idx}
                    style={{
                      padding: BoxSpacing.lg,
                      flexDirection: "row",
                      alignItems: "flex-start",
                      gap: BoxSpacing.md,
                      borderBottomWidth: idx < rules.length - 1 ? 1 : 0,
                      borderBottomColor: BoxBorders.subtle,
                    }}
                  >
                    <View style={{
                      width: bs(40),
                      height: bs(40),
                      borderRadius: BoxRadius.md,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: `${rule.color}20`,
                    }}>
                      <Icon size={bs(18)} color={rule.color} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[BoxTypography.bodyBold, { color: BoxText.primary, marginBottom: BoxSpacing.xs }]}>
                        {t(rule.titleKey)}
                      </Text>
                      <Text style={[BoxTypography.caption, { color: BoxText.secondary, lineHeight: bs(18) }]}>
                        {t(rule.descKey)}
                      </Text>
                    </View>
                  </View>
                );
              })}
            </View>
          )}

          {/* FAQ Accordion */}
          <Pressable
            onPress={() => setFaqOpen(!faqOpen)}
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: BoxSpacing.md,
            }}
          >
            <Text style={[BoxTypography.h2, { color: BoxText.primary }]}>
              {t("pity.faqTitle")}
            </Text>
            <ChevronDown
              size={bs(20)}
              color={BoxText.tertiary}
              style={{ transform: [{ rotate: faqOpen ? "180deg" : "0deg" }] } as any}
            />
          </Pressable>
          {faqOpen && (
            <View style={{
              borderRadius: BoxRadius.xl,
              padding: BoxSpacing.lg,
              backgroundColor: BoxSurfaces.card,
              borderWidth: 1,
              borderColor: BoxBorders.default,
            }}>
              {faqs.map((faq, idx) => (
                <View
                  key={idx}
                  style={{
                    marginBottom: idx < faqs.length - 1 ? BoxSpacing.lg : 0,
                    paddingBottom: idx < faqs.length - 1 ? BoxSpacing.lg : 0,
                    borderBottomWidth: idx < faqs.length - 1 ? 1 : 0,
                    borderBottomColor: BoxBorders.subtle,
                  }}
                >
                  <Text style={[BoxTypography.bodyBold, { color: BoxText.primary, marginBottom: BoxSpacing.xs }]}>
                    Q: {t(faq.qKey)}
                  </Text>
                  <Text style={[BoxTypography.caption, { color: BoxText.secondary, lineHeight: bs(18) }]}>
                    A: {t(faq.aKey)}
                  </Text>
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}
