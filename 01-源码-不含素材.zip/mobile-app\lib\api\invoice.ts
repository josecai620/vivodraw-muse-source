import { API_ENDPOINTS } from "@/constants/api";
import { http } from "@/lib/http";

export interface InvoiceItem {
  id?: number;
  invoice_id?: number;
  header_type?: number | string;
  headerType?: number | string;
  type?: number | string;
  header?: string;
  title?: string;
  name?: string;
  drawer_phone?: string;
  drawerPhone?: string;
  duty_number?: string;
  dutyNumber?: string;
  duty_paragraph?: string;
  is_default?: boolean | number | string;
}

export interface SaveInvoiceData {
  id?: number;
  header_type: 1 | 2;
  type?: number;
  drawer_phone: string;
  name: string;
  duty_number?: string;
  is_default?: boolean | number | string;
}

export interface InvoiceListData {
  list?: InvoiceItem[];
  data?: InvoiceItem[];
}

export function getInvoiceList() {
  return http.get<InvoiceListData | InvoiceItem[]>(API_ENDPOINTS.invoice.list);
}

export function getInvoiceDetail(id: number) {
  return http.get<InvoiceItem>(API_ENDPOINTS.invoice.detail(id));
}

export function saveInvoice(data: SaveInvoiceData) {
  return http.post(API_ENDPOINTS.invoice.save, data);
}

export function makeUpInvoice(data: { order_id: string | number; invoice_id: number }) {
  return http.post(API_ENDPOINTS.invoice.makeUp, data);
}

export function getOrderInvoiceList() {
  return http.get(API_ENDPOINTS.invoice.orderList);
}

export function setDefaultInvoice(id: number) {
  return http.post(API_ENDPOINTS.invoice.setDefault(id));
}

export function delInvoice(id: number) {
  return http.get(API_ENDPOINTS.invoice.del(id));
}
