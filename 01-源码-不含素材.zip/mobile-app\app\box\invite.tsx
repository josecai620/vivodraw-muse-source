/**
 * Invite Page — 邀请裂变
 * 3-tier rewards: 3 invites → 10pts, 5 paid → 50pts, 10 paid → 100pts + rare guarantee
 */
import React, { useState } from "react";
import { Pressable, ScrollView, Text, View, Share, ActivityIndicator } from "react-native";
import { useTranslation } from "react-i18next";
import { LinearGradient } from "expo-linear-gradient";
import { Users, Gift, Copy, Check, Trophy, ChevronRight } from "lucide-react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { BoxHeader, RarityBadge, BoxActionButton } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, bs,
} from "@/lib/boxTheme";
import { useInviteInfo, useClaimInviteReward } from "@/hooks";
import { useAppStore } from "@/store/app";

export default function InvitePage() {
  const { t } = useTranslation();
  const showToast = useAppStore((s) => s.showToast);
  const [copied, setCopied] = useState(false);
  const { data: inviteData, isLoading } = useInviteInfo();
  const claimMutation = useClaimInviteReward();

  const info = inviteData || {};
  const rewards = info.rewards || [];

  const handleShare = async () => {
    try {
      await Share.share({
        message: `${t("invite.shareMessage")}\n${info.invite_link || ""}`,
        title: t("invite.shareTitle"),
      });
    } catch {}
  };

  const handleCopy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClaim = (level: number) => {
    claimMutation.mutate(level);
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: BoxSurfaces.void }}>
        <ActivityIndicator size="large" color={BoxAccent.gold} />
      </View>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("invite.title")} showThemeToggle={false} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(96) }}>
          {/* Hero */}
          <LinearGradient colors={BoxGradients.goldWarm} style={{ borderRadius: BoxRadius["3xl"],
            padding: BoxSpacing["2xl"], alignItems: "center", marginBottom: BoxSpacing["2xl"],
            ...BoxShadows.glow(BoxAccent.gold) }}>
            <Users size={bs(48)} color={BoxAccent.gold} />
            <Text style={[BoxTypography.h1, { color: BoxText.primary, marginTop: BoxSpacing.lg, textAlign: "center" }]}>{t("invite.heroTitle")}</Text>
            <Text style={[BoxTypography.body, { color: BoxText.secondary, marginTop: BoxSpacing.sm, textAlign: "center" }]}>{t("invite.heroDesc")}</Text>
          </LinearGradient>

          {/* Stats */}
          <View style={{ flexDirection: "row", gap: BoxSpacing.md, marginBottom: BoxSpacing["2xl"] }}>
            <View style={{ flex: 1, borderRadius: BoxRadius.xl, padding: BoxSpacing.lg,
              backgroundColor: BoxSurfaces.card, borderWidth: 1, borderColor: BoxBorders.default, alignItems: "center" }}>
              <Text style={[BoxTypography.hero, { color: BoxAccent.gold }]}>{info.invited_count || 0}</Text>
              <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>{t("invite.invited")}</Text>
            </View>
            <View style={{ flex: 1, borderRadius: BoxRadius.xl, padding: BoxSpacing.lg,
              backgroundColor: BoxSurfaces.card, borderWidth: 1, borderColor: BoxBorders.default, alignItems: "center" }}>
              <Text style={[BoxTypography.hero, { color: "#04A8AE" }]}>{info.invited_paid_count || 0}</Text>
              <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>{t("invite.paidUsers")}</Text>
            </View>
          </View>

          {/* Share Section */}
          <View style={{ borderRadius: BoxRadius.xl, padding: BoxSpacing.lg, marginBottom: BoxSpacing["2xl"],
            backgroundColor: BoxSurfaces.card, borderWidth: 1, borderColor: BoxBorders.default }}>
            <Text style={[BoxTypography.bodyBold, { color: BoxText.primary, marginBottom: BoxSpacing.md }]}>{t("invite.yourCode")}</Text>
            <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm }}>
              <View style={{ flex: 1, borderRadius: BoxRadius.lg, padding: BoxSpacing.md,
                backgroundColor: BoxSurfaces.deep, borderWidth: 1, borderColor: BoxBorders.default }}>
                <Text style={[BoxTypography.h3, { color: BoxAccent.gold, textAlign: "center", letterSpacing: 2 }]}>{info.invite_code || "--------"}</Text>
              </View>
              <Pressable onPress={handleCopy} style={{ padding: BoxSpacing.md, borderRadius: BoxRadius.lg,
                backgroundColor: BoxAccent.goldMuted }}>
                {copied ? <Check size={bs(20)} color={BoxAccent.gold} /> : <Copy size={bs(20)} color={BoxAccent.gold} />}
              </Pressable>
            </View>
            <BoxActionButton title={t("invite.shareNow")} variant="primary"
              onPress={handleShare} style={{ marginTop: BoxSpacing.md }}
              icon={<Gift size={bs(16)} color={BoxText.onGold} />} />
          </View>

          {/* Rewards */}
          <Text style={[BoxTypography.h2, { color: BoxText.primary, marginBottom: BoxSpacing.lg }]}>{t("invite.rewards")}</Text>
          {rewards.map((reward: any, index: number) => {
            const achieved = reward.achieved;
            const isLast = index === rewards.length - 1;
            return (
              <View key={index}>
                <LinearGradient
                  colors={achieved ? BoxGradients.goldWarm : [BoxSurfaces.card, BoxSurfaces.deep]}
                  style={{ borderRadius: BoxRadius.xl, padding: BoxSpacing.lg,
                    borderWidth: 2, borderColor: achieved ? BoxAccent.goldBorder : BoxBorders.default,
                    opacity: achieved ? 1 : 0.7 }}>
                  <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.md }}>
                      <View style={{ width: bs(40), height: bs(40), borderRadius: bs(20),
                        alignItems: "center", justifyContent: "center",
                        backgroundColor: achieved ? BoxAccent.goldMuted : BoxSurfaces.deep }}>
                        <Trophy size={bs(20)} color={achieved ? BoxAccent.gold : BoxText.tertiary} />
                      </View>
                      <View>
                        <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>{t("invite.level" + (index + 1))}</Text>
                        <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>{t("invite.inviteN", { n: reward.invites })}</Text>
                      </View>
                    </View>
                    <View style={{ alignItems: "flex-end" }}>
                      <Text style={[BoxTypography.bodyBold, { color: BoxAccent.gold }]}>{reward.reward}</Text>
                      {achieved ? (
                        <Pressable onPress={() => handleClaim(index + 1)} disabled={claimMutation.isPending}
                          style={{ marginTop: BoxSpacing.xs, paddingHorizontal: BoxSpacing.md, paddingVertical: BoxSpacing.xs,
                            borderRadius: BoxRadius.full, backgroundColor: BoxAccent.gold }}>
                          <Text style={[BoxTypography.micro, { color: BoxText.onGold }]}>{claimMutation.isPending ? "..." : t("invite.claim")}</Text>
                        </Pressable>
                      ) : (
                        <Text style={[BoxTypography.micro, { color: BoxText.tertiary }]}>{t("invite.notYet")}</Text>
                      )}
                    </View>
                  </View>
                </LinearGradient>
                {!isLast && <View style={{ height: bs(20), width: 2, backgroundColor: BoxBorders.default, alignSelf: "center" }} />}
              </View>
            );
          })}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
