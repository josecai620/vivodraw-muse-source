// [已废弃] CRMEB DIY 渲染器 — 改由 @/components/home-layout 替代
// 保留空文件以防残留 import；请运行 scripts/cleanup-legacy-diy.sh 物理删除此目录
export default function DiyRendererDeprecated(): null { return null; }
