# add-shadow.ps1
# Add a soft teal drop shadow to LinearGradient surfaces upgraded by codemod-teal.
# Rules: skip overflow:hidden (self-shadow is clipped), skip absolute badges / selected tabs,
# unify existing black shadows (#000 / Shadows.lg) to teal; inject into an existing inline
# style={{...}} or add a new style prop.
param([Parameter(Mandatory=$true)][string]$Path)
$utf8 = New-Object System.Text.UTF8Encoding($false)
$L = New-Object System.Collections.ArrayList
$L.AddRange([System.IO.File]::ReadAllLines($Path))

$SH = 'shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6, '
$changed = 0
for ($i=$L.Count-1; $i -ge 0; $i--) {
  if ($L[$i] -notmatch 'colors=\{\[TealGradient\.light') { continue }
  # find open-tag end
  $e = $i
  for ($j=$i; $j -lt [Math]::Min($i+16,$L.Count); $j++) { if ($L[$j] -match '\>\s*$' -or $L[$j].Trim() -eq '>') { $e=$j; break } }
  $block = ($L[$i..$e] -join "`n")
  if ($block -match 'overflow:\s*"hidden"') { continue }
  if ($block -match 'absolute top-\d|left-\d.*absolute') { continue }          # badge
  if ($block -match 'position:\s*"absolute"') { continue }                        # injected/fab layer
  if ($block -match 'style=\{styles\.|style=\{StyleSheet|style=\[') { continue }  # external/array style
  $indent = ($L[$i] -replace '^(\s*).*$','$1')

  if ($block -match 'shadowColor:\s*"#000"') {
    for ($k=$i;$k -le $e;$k++){
      if ($L[$k] -match 'shadowColor:\s*"#000"'){ $L[$k] = $L[$k] -replace 'shadowColor:\s*"#000"','shadowColor: "#04A8AE"' }
      if ($L[$k] -match 'shadowOpacity:'){ $L[$k] = [regex]::Replace($L[$k],'shadowOpacity: [\d.]+','shadowOpacity: 0.3') }
    }
    $changed++; continue
  }
  if ($block -match '\.\.\.Shadows\.') {
    for ($k=$i;$k -le $e;$k++){ $L[$k] = $L[$k] -replace '\.\.\.Shadows\.\w+,?', $SH.TrimEnd() }
    $changed++; continue
  }
  if ($block -match 'shadowColor') { continue }   # already teal

  # inject into existing inline style={{
  $styleLine = -1
  for ($k=$i;$k -le $e;$k++){ if ($L[$k] -match 'style=\{\{'){ $styleLine=$k; break } }
  if ($styleLine -ge 0) {
    if ($L[$styleLine] -match 'style=\{\{\s*\}\}') {
      $L[$styleLine] = $L[$styleLine] -replace 'style=\{\{\s*\}\}', ('style={{ '+$SH+'}}')
    } else {
      $L[$styleLine] = $L[$styleLine] -replace 'style=\{\{', ('style={{ '+$SH)
    }
    $changed++
  } else {
    # no inline style -> insert one right before the closing '>'
    $closeLine = $e
    $L.Insert($closeLine, $indent + 'style={{ '+$SH.TrimEnd(', ')+' }}')
    $changed++
  }
}
[System.IO.File]::WriteAllLines($Path,$L,$utf8)
Write-Output ("{0}: shadow {1}" -f (Split-Path $Path -Leaf),$changed)
