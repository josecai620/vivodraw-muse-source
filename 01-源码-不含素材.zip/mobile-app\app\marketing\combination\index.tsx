import React from "react";
import { ActivityIndicator, Image, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";
import { normalizeImageUrl, formatPrice } from "@/lib/utils";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

export default function CombinationScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const { data, isLoading } = useQuery({
    queryKey: ["combinationList"],
    queryFn: () => http.get(API_ENDPOINTS.combination.list),
  });

  const raw = (data as any)?.data ?? data;
  const list = raw?.list ?? raw ?? [];

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Group Buy" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : list.length === 0 ? (
        <View className="flex-1 items-center justify-center px-6">
          <Text style={{ color: Colors.neutral[500] }}>No group buy at the moment</Text>
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }} showsVerticalScrollIndicator={false}>
          {list.map((item: any, i: number) => (
            <Pressable
              key={item.id ?? i}
              onPress={() => router.push(`/marketing/combination/${item.id}`)}
              className="bg-white rounded-2xl flex-row p-4 mb-3 border border-gray-100"
            >
              <Image source={{ uri: normalizeImageUrl(item.image ?? item.pic) }} style={{ width: s(88), height: s(88), borderRadius: s(12), backgroundColor: Colors.neutral[100] }} resizeMode="cover" />
              <View className="flex-1 ml-3 justify-center">
                <Text className="font-semibold" style={{ color: Colors.neutral[800] }} numberOfLines={2}>{item.store_name ?? item.title}</Text>
                <View className="flex-row items-center mt-2">
                  <Text className="font-bold" style={{ color: Colors.brand.red }}>{formatPrice(item.price ?? item.combination_price)}</Text>
                  <Text className="text-xs ml-2 line-through" style={{ color: Colors.neutral[400] }}>{formatPrice(item.ot_price ?? item.product_price)}</Text>
                </View>
                <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }}>{t("groupLottery.nPeopleGroup", { count: item.people ?? 2 })}</Text>
              </View>
            </Pressable>
          ))}
        </ScrollView>
      )}
    </View>
  );
}
