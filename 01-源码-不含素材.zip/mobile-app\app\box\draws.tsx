/**
 * 抽奖记录 - FlatList with infinite scroll, timeline & reveal detail modal
 */
import React, { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Pressable,
  FlatList,
  Text,
  View,
  ActivityIndicator,
  Modal,
} from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { Award, X, Eye, Clock, Gift as GiftIcon, User } from "lucide-react-native";
import {
  BoxHeader,
  RarityBadge,
  BoxActionButton,
  BoxEmptyState,
  BoxProgressBar,
  BoxTabBar,
  CountdownTimer,
} from "@/components/box";
import { NextStepGuide } from "@/components/onboarding/PlayGuides";
import {
  BoxSurfaces,
  BoxAccent,
  BoxText,
  BoxBorders,
  BoxGradients,
  BoxTypography,
  BoxSpacing,
  BoxRadius,
  BoxShadows,
  getRarityTier,
  bs,
} from "@/lib/boxTheme";
import { useBoxChoujiangList, useKaijiangInfo } from "@/hooks";

function normalizeRarity(raw: unknown): string {
  const map: Record<string, string> = {
    "1": "common",
    "2": "uncommon",
    "3": "rare",
    "4": "epic",
    "5": "legendary",
    "6": "secret",
    common: "common",
    uncommon: "uncommon",
    rare: "rare",
    epic: "epic",
    legendary: "legendary",
    secret: "secret",
  };
  return map[String(raw ?? "common")] || "common";
}

export default function BoxDrawsScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const [page, setPage] = useState(1);
  const [allDraws, setAllDraws] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState(0);

  const {
    data: drawData,
    isLoading,
    isFetching,
  } = useBoxChoujiangList(0, {
    page,
  });
  const { data: kaijiangDetail } = useKaijiangInfo(selectedId);

  const total = drawData?.total ?? 0;
  const hasMore = allDraws.length < total;

  useEffect(() => {
    const list = Array.isArray(drawData?.list) ? drawData.list : [];
    if (list.length === 0) return;
    setAllDraws((prev) => (page === 1 ? list : [...prev, ...list]));
  }, [drawData, page]);

  const loadMore = useCallback(() => {
    if (!isFetching && hasMore) setPage((p) => p + 1);
  }, [isFetching, hasMore]);

  const renderDraw = useCallback(
    ({ item: draw, index }: { item: any; index: number }) => {
      const rarity = normalizeRarity(draw.product?.tag || draw.tag);
      const rarityConfig = getRarityTier(rarity);
      const kaijiang = draw.kaijiang;

      return (
        <View style={{ flexDirection: "row", marginBottom: BoxSpacing.lg }}>
          {/* Timeline dot */}
          <View
            style={{
              alignItems: "center",
              marginRight: BoxSpacing.lg,
            }}
          >
            <LinearGradient
              colors={rarityConfig.gradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                width: bs(40),
                height: bs(40),
                borderRadius: bs(20),
                alignItems: "center",
                justifyContent: "center",
                ...BoxShadows.glow(rarityConfig.color),
              }}
            >
              <Award size={bs(18)} color="#fff"  style={{ shadowColor: "rgba(12,31,31,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
            </LinearGradient>
            {index < allDraws.length - 1 && (
              <View
                style={{
                  width: 2,
                  flex: 1,
                  marginTop: BoxSpacing.sm,
                  backgroundColor: BoxBorders.default,
                  minHeight: bs(48),
                }}
              />
            )}
          </View>

          {/* Card */}
          <Pressable
            style={{
              flex: 1,
              borderRadius: BoxRadius.xl,
              overflow: "hidden",
              marginBottom: BoxSpacing.sm,
              backgroundColor: BoxSurfaces.card,
              borderWidth: 1,
              borderColor: BoxBorders.default,
              ...BoxShadows.card,
            }}
            onPress={() => setSelectedId(draw.id)}
          >
            <View style={{ padding: BoxSpacing.lg }}>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginBottom: BoxSpacing.sm,
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: BoxSpacing.md,
                    flex: 1,
                  }}
                >
                  <View
                    style={{
                      width: bs(48),
                      height: bs(48),
                      borderRadius: BoxRadius.lg,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: BoxSurfaces.deep,
                    }}
                  >
                    {draw.product?.image &&
                    /^https?:\/\//.test(draw.product.image) ? (
                      <Image
                        source={{ uri: draw.product.image }}
                        style={{
                          width: bs(40),
                          height: bs(40),
                          borderRadius: BoxRadius.md,
                        }}
                        contentFit="cover"
                      />
                    ) : (
                      <GiftIcon size={bs(20)} color={BoxAccent.gold} strokeWidth={1.6} />
                    )}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={[
                        BoxTypography.bodyBold,
                        { color: BoxText.primary },
                      ]}
                      numberOfLines={1}
                    >
                      {draw.product?.store_name ||
                        draw.store_name ||
                        t("draws.defaultProduct")}
                    </Text>
                    <RarityBadge
                      tier={rarity}
                      size="sm"
                      style={{ marginTop: BoxSpacing.xs }}
                    />
                  </View>
                </View>
                <Pressable
                  onPress={() => setSelectedId(draw.id)}
                  hitSlop={8}
                  style={{
                    padding: BoxSpacing.sm,
                    borderRadius: BoxRadius.sm,
                    backgroundColor: BoxSurfaces.elevated,
                  }}
                >
                  <Eye size={bs(16)} color={BoxText.secondary} />
                </Pressable>
              </View>

              {Array.isArray(draw.unique) && draw.unique.length > 0 && (
                <View
                  style={{
                    flexDirection: "row",
                    flexWrap: "wrap",
                    gap: BoxSpacing.xs,
                    marginTop: BoxSpacing.sm,
                  }}
                >
                  {draw.unique.slice(0, 5).map((u: any, uidx: number) => (
                    <View
                      key={uidx}
                      style={{
                        paddingHorizontal: BoxSpacing.sm,
                        paddingVertical: 2,
                        borderRadius: BoxRadius.sm,
                        backgroundColor: BoxSurfaces.deep,
                        borderWidth: 1,
                        borderColor: BoxBorders.subtle,
                      }}
                    >
                      <Text
                        style={[
                          BoxTypography.micro,
                          { color: BoxText.tertiary },
                        ]}
                      >
                        {u.unique || u}
                      </Text>
                    </View>
                  ))}
                </View>
              )}

              {kaijiang && (
                <View
                  style={{
                    marginTop: BoxSpacing.sm,
                    paddingTop: BoxSpacing.sm,
                    borderTopWidth: 1,
                    borderTopColor: BoxBorders.subtle,
                    flexDirection: "row",
                    alignItems: "center",
                    gap: BoxSpacing.sm,
                  }}
                >
                  <Clock size={bs(12)} color={BoxText.tertiary} />
                  <Text
                    style={[BoxTypography.caption, { color: BoxText.tertiary }]}
                  >
                    {t("draws.winner", {
                      name:
                        kaijiang.nickname || t("draws.notRevealed"),
                    })}
                  </Text>
                </View>
              )}
            </View>
          </Pressable>
        </View>
      );
    },
    [allDraws.length, t]
  );

  const ListFooter = () => {
    if (isFetching && page > 1) {
      return (
        <View
          style={{ alignItems: "center", paddingVertical: BoxSpacing.lg }}
        >
          <ActivityIndicator size="small" color={BoxAccent.gold} />
        </View>
      );
    }
    if (!hasMore && allDraws.length > 0) {
      return (
        <Text
          style={[
            BoxTypography.caption,
            {
              color: BoxText.tertiary,
              textAlign: "center",
              paddingVertical: BoxSpacing.lg,
            },
          ]}
        >
          {t("draws.noMore")}
        </Text>
      );
    }
    return null;
  };

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("draws.title")} showThemeToggle={false} />
      <NextStepGuide kind="boxDraws" />

      {isLoading && page === 1 ? (
        <View
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        >
          <ActivityIndicator size="large" color={BoxAccent.gold} />
          <Text
            style={[
              BoxTypography.body,
              { color: BoxText.secondary, marginTop: BoxSpacing.lg },
            ]}
          >
            {t("common.loading")}
          </Text>
        </View>
      ) : allDraws.length === 0 ? (
        <BoxEmptyState
          icon={<Award size={bs(48)} color={BoxText.tertiary} />}
          title={t("draws.empty")}
          style={{ flex: 1 }}
        />
      ) : (
        <FlatList
          data={allDraws}
          keyExtractor={(item, i) => String(item.id || i)}
          renderItem={renderDraw}
          contentContainerStyle={{
            padding: BoxSpacing.lg,
            paddingBottom: bs(96),
          }}
          onEndReached={loadMore}
          onEndReachedThreshold={0.3}
          ListFooterComponent={ListFooter}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* Kaijiang Detail Modal */}
      <Modal
        visible={selectedId > 0 && !!kaijiangDetail}
        transparent
        animationType="fade"
      >
        <View
          style={{
            flex: 1,
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "rgba(12,31,31,0.45)",
          }}
        >
          <View
            style={{
              width: "85%",
              borderRadius: BoxRadius["2xl"],
              padding: BoxSpacing.xl,
              backgroundColor: BoxSurfaces.card,
              borderWidth: 1,
              borderColor: BoxBorders.default,
              ...BoxShadows.elevated,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: BoxSpacing.lg,
              }}
            >
              <Text
                style={[BoxTypography.h2, { color: BoxText.primary }]}
              >
                {t("draws.detailTitle")}
              </Text>
              <Pressable
                onPress={() => setSelectedId(0)}
                hitSlop={8}
                style={{
                  padding: BoxSpacing.xs,
                  borderRadius: BoxRadius.sm,
                  backgroundColor: BoxSurfaces.elevated,
                }}
              >
                <X size={bs(20)} color={BoxText.secondary} />
              </Pressable>
            </View>

            {kaijiangDetail?.detail && (
              <>
                <Text
                  style={[
                    BoxTypography.body,
                    { color: BoxText.primary, marginBottom: BoxSpacing.sm },
                  ]}
                >
                  {t("draws.product", {
                    name:
                      kaijiangDetail.detail.store_name ||
                      kaijiangDetail.detail.product_name ||
                      t("common.unknown"),
                  })}
                </Text>
                <Text
                  style={[
                    BoxTypography.body,
                    { color: BoxText.primary, marginBottom: BoxSpacing.sm },
                  ]}
                >
                  {t("draws.revealTime", {
                    time:
                      kaijiangDetail.detail.huanqu_time ||
                      t("common.unknown"),
                  })}
                </Text>
                {kaijiangDetail.kaijiang && (
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: BoxSpacing.md,
                      marginTop: BoxSpacing.sm,
                      padding: BoxSpacing.md,
                      borderRadius: BoxRadius.lg,
                      backgroundColor: BoxSurfaces.deep,
                      borderWidth: 1,
                      borderColor: BoxBorders.subtle,
                    }}
                  >
                    {kaijiangDetail.kaijiang.avatar &&
                    /^https?:\/\//.test(
                      kaijiangDetail.kaijiang.avatar
                    ) ? (
                      <Image
                        source={{
                          uri: kaijiangDetail.kaijiang.avatar,
                        }}
                        style={{
                          width: bs(40),
                          height: bs(40),
                          borderRadius: bs(20),
                        }}
                        contentFit="cover"
                      />
                    ) : (
                      <View
                        style={{
                          width: bs(40),
                          height: bs(40),
                          borderRadius: bs(20),
                          alignItems: "center",
                          justifyContent: "center",
                          backgroundColor: BoxSurfaces.elevated,
                        }}
                      >
                        <User size={bs(18)} color={BoxText.tertiary} strokeWidth={1.6} />
                      </View>
                    )}
                    <View>
                      <Text
                        style={[
                          BoxTypography.bodyBold,
                          { color: BoxText.primary },
                        ]}
                      >
                        {kaijiangDetail.kaijiang.nickname ||
                          t("common.anonymous")}
                      </Text>
                      <Text
                        style={[
                          BoxTypography.caption,
                          { color: BoxText.tertiary },
                        ]}
                      >
                        {t("draws.winnerUser")}
                      </Text>
                    </View>
                  </View>
                )}
              </>
            )}

            <BoxActionButton
              title={t("draws.close")}
              variant="secondary"
              onPress={() => setSelectedId(0)}
              style={{ marginTop: BoxSpacing.lg }}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}
