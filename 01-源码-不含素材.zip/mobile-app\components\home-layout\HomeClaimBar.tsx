import { Colors, Shadows, s } from "@/constants/theme";
import { useDoSign, useSignConfig, useSignUser } from "@/hooks";
import { unwrapApiData } from "@/lib/api/response";
import { useAuthStore } from "@/store/auth";
import { useRouter } from "expo-router";
import { Coins } from "lucide-react-native";
import type React from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  AccessibilityInfo,
  ActivityIndicator,
  Animated,
  Easing,
  Pressable,
  Text,
  View,
} from "react-native";

type SignDay = {
  isToday?: boolean;
  sign_num?: number | string;
  integral?: number | string;
  points?: number | string;
};

type SignUser = {
  is_day_sgin?: boolean | number;
  sign_num?: number | string;
  sum_sgin_day?: number | string;
};

function toCount(value: unknown): number {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

function todayRewardPoints(config: unknown): number {
  const days = unwrapApiData<unknown>(config, config);
  const list = Array.isArray(days) ? (days as SignDay[]) : [];
  const today = list.find((day) => day.isToday) ?? list[0];
  return toCount(today?.sign_num ?? today?.integral ?? today?.points);
}

function SubtleJitterText({ children }: { children: React.ReactNode }) {
  const offset = useRef(new Animated.Value(0)).current;
  const [reduceMotion, setReduceMotion] = useState(false);

  useEffect(() => {
    let alive = true;
    AccessibilityInfo.isReduceMotionEnabled().then((value) => {
      if (alive) setReduceMotion(Boolean(value));
    });
    const sub = AccessibilityInfo.addEventListener("reduceMotionChanged", (value) => {
      setReduceMotion(Boolean(value));
    });
    return () => {
      alive = false;
      sub.remove();
    };
  }, []);

  useEffect(() => {
    offset.stopAnimation();
    offset.setValue(0);
    const amount = reduceMotion ? 0.9 : 1.7;

    const loop = Animated.loop(
      Animated.sequence([
        Animated.delay(1900),
        Animated.timing(offset, {
          toValue: 1 * amount,
          duration: 65,
          easing: Easing.linear,
          useNativeDriver: true,
          isInteraction: false,
        }),
        Animated.timing(offset, {
          toValue: -0.8 * amount,
          duration: 75,
          easing: Easing.linear,
          useNativeDriver: true,
          isInteraction: false,
        }),
        Animated.timing(offset, {
          toValue: 0.5 * amount,
          duration: 70,
          easing: Easing.linear,
          useNativeDriver: true,
          isInteraction: false,
        }),
        Animated.timing(offset, {
          toValue: 0,
          duration: 85,
          easing: Easing.out(Easing.quad),
          useNativeDriver: true,
          isInteraction: false,
        }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [offset, reduceMotion]);

  return (
    <Animated.Text style={[styles.copy, { transform: [{ translateX: offset }] }]} numberOfLines={1}>
      {children}
    </Animated.Text>
  );
}

/** Shopee 式领积分条：只显示服务端签到状态，不写死奖励数字 */
export default function HomeClaimBar() {
  const { t } = useTranslation();
  const router = useRouter();
  const isLoggedIn = useAuthStore((st) => st.isLoggedIn);
  const { data: configData } = useSignConfig(isLoggedIn);
  const { data: userData } = useSignUser(isLoggedIn);
  const doSign = useDoSign();

  const user = unwrapApiData<SignUser>(userData, {});
  const signedToday = Boolean(user.is_day_sgin);
  const streak = toCount(user.sign_num);
  const pts = todayRewardPoints(configData);

  const copy = useMemo(() => {
    if (!isLoggedIn) return t("home.claimBar.login");
    if (signedToday) {
      return streak > 0
        ? t("home.claimBar.claimedStreak", { days: streak })
        : t("home.claimBar.claimed");
    }
    if (pts > 0) {
      return streak > 0
        ? t("home.claimBar.claimableStreak", { pts, days: streak })
        : t("home.claimBar.claimable", { pts });
    }
    return t("home.claimBar.claimableNoPts");
  }, [isLoggedIn, pts, signedToday, streak, t]);

  const cta = !isLoggedIn
    ? t("home.claimBar.loginCta")
    : signedToday
      ? t("home.claimBar.claimedCta")
      : doSign.isPending
        ? t("home.claimBar.claiming")
        : t("home.claimBar.claim");

  const openCheckin = () => router.push("/points/checkin");

  const onPressCta = async () => {
    if (!isLoggedIn) {
      router.push("/auth");
      return;
    }
    if (signedToday || doSign.isPending) {
      openCheckin();
      return;
    }
    try {
      await doSign.mutateAsync();
    } catch {
      openCheckin();
    }
  };

  return (
    <View style={styles.wrap}>
      <Pressable
        onPress={isLoggedIn ? openCheckin : () => router.push("/auth")}
        style={({ pressed }) => [styles.bar, { opacity: pressed ? 0.92 : 1 }]}
        accessibilityRole="button"
        accessibilityLabel={copy}
      >
        <View style={styles.iconWrap}>
          <Coins size={s(16)} color={Colors.primary.DEFAULT} strokeWidth={2.2} />
          {isLoggedIn && !signedToday ? <View style={styles.dot} /> : null}
        </View>
        <SubtleJitterText>{copy}</SubtleJitterText>
        <Pressable
          onPress={(event) => {
            event.stopPropagation?.();
            void onPressCta();
          }}
          disabled={doSign.isPending}
          style={({ pressed }) => [
            styles.cta,
            signedToday ? styles.ctaDone : null,
            { opacity: pressed ? 0.85 : 1 },
          ]}
          accessibilityRole="button"
          accessibilityLabel={cta}
        >
          {doSign.isPending ? (
            <ActivityIndicator size="small" color="#FFFFFF" />
          ) : (
            <Text style={[styles.ctaText, signedToday ? styles.ctaTextDone : null]}>{cta}</Text>
          )}
        </Pressable>
      </Pressable>
    </View>
  );
}

const styles = {
  wrap: {
    marginHorizontal: s(16),
    marginTop: s(14),
  },
  bar: {
    minHeight: s(48),
    borderRadius: s(16),
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: Colors.screen.hairline,
    paddingLeft: s(12),
    paddingRight: s(8),
    paddingVertical: s(8),
    flexDirection: "row" as const,
    alignItems: "center" as const,
    gap: s(10),
    ...Shadows.raisedSm,
  },
  iconWrap: {
    position: "relative" as const,
    width: s(32),
    height: s(32),
    borderRadius: s(10),
    backgroundColor: Colors.primary.softer,
    alignItems: "center" as const,
    justifyContent: "center" as const,
  },
  dot: {
    position: "absolute" as const,
    top: s(4),
    right: s(4),
    width: s(7),
    height: s(7),
    borderRadius: s(4),
    backgroundColor: Colors.primary.DEFAULT,
  },
  copy: {
    flex: 1,
    color: "#171A1A",
    fontSize: s(13),
    fontWeight: "700" as const,
  },
  cta: {
    minWidth: s(64),
    height: s(32),
    paddingHorizontal: s(12),
    borderRadius: s(16),
    backgroundColor: Colors.primary.DEFAULT,
    alignItems: "center" as const,
    justifyContent: "center" as const,
  },
  ctaDone: {
    backgroundColor: Colors.primary.softer,
  },
  ctaText: {
    color: "#FFFFFF",
    fontSize: s(12),
    fontWeight: "800" as const,
  },
  ctaTextDone: {
    color: Colors.primary.dark,
  },
};
