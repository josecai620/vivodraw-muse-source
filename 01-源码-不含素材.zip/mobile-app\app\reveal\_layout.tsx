import React from "react";
import { Stack } from "expo-router";
import { RevealColorSchemeProvider } from "@/contexts/RevealColorSchemeContext";

export default function RevealLayout() {
  return (
    <RevealColorSchemeProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="[id]" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="[id]/countdown" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="[id]/result" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="records" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="rules" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="history" options={{ animation: "slide_from_right" }} />
      </Stack>
    </RevealColorSchemeProvider>
  );
}
