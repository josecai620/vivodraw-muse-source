import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getBoxHall,
  getBoxShopwindow,
  getBoxShop,
  getBoxDetail,
  getBoxDetail2,
  getBoxList,
  getBoxLog,
  getBoxLogInfo,
  doRecovery,
  addBox,
  createBoxOrder,
  getBoxBrandList,
  getBoxBrand,
  getLuckyNotices,
  getBoxTuijian,
  getBoxConfig,
  getYuanqiConfig,
  getUserCoupon,
  boxOrderPay,
  getBoxOrderDetail,
  checkBoxOrderPay,
  sendPay,
  sendCreateOrder,
  getSendOrderDetail,
  getSendOrderList,
  getSendAll,
  getBoxChoujiangList,
  getKaijiangInfo,
  getBoxTongzhi,
  getBoxOne,
  getBoxSgetOne,
  getWangqiJixiao,
  getCheckinInfo,
  doCheckin,
  getCheckinTasks,
  claimCheckinTask,
  trackBoxTaskEvent,
  claimSignPrize,
  getPityInfo,
  getWishlistList,
  addWishlistItem,
  removeWishlistItem,
  getExchangeList,
  createExchangeListing,
  applyExchange,
  doSynthesize,
  getLeaderboard,
  getActivityList,
  getActivityDetail,
  getReplayList,
  getFriendBoxList,
  friendGift,
  getNewbieCheck,
  claimNewbieGift,
  // Enhanced exchange
  getExchangeMyList,
  cancelExchangeListing,
  confirmExchange,
  getExchangeOffers,
  // Wishlist notifications
  getWishlistNotifications,
  getWishlistUnreadCount,
  // Quick buy
  getBoxQuickDetail,
  // New features
  getProbability,
  checkFreeDraw,
  doFreeDraw,
  getInviteInfo,
  claimInviteReward,
  mapBoxItem,
  mapBoxCategoryItem,
  mapBoxDetail,
  mapBackpackItem,
  mapOpeningHistoryItem,
  mapLuckyNotice,
} from "@/lib/api/box";
import { useAppStore } from "@/store/app";

// 盲盒大厅
export function useBoxHall() {
  return useQuery({
    queryKey: ["boxHall"],
    queryFn: getBoxHall,
    select: (data) => {
      if (!data?.data) return { recentDrops: [], hotBox: null, boxes: [] };
      return {
        recentDrops: (data.data.recent_drops || []).map(mapBoxItem),
        hotBox: data.data.hot_box ? mapBoxItem(data.data.hot_box) : null,
        boxes: (data.data.boxes || data.data.list || []).map(mapBoxItem),
      };
    },
  });
}

// 橱窗
export function useBoxShopwindow() {
  return useQuery({
    queryKey: ["boxShopwindow"],
    queryFn: getBoxShopwindow,
    select: (data) => (data?.data || []).map(mapBoxItem),
  });
}

// 推荐盲盒列表（盲盒分类，用于大厅）
export function useBoxTuijian() {
  return useQuery({
    queryKey: ["boxTuijian"],
    queryFn: getBoxTuijian,
    select: (data) => {
      const list = data?.data;
      if (!Array.isArray(list)) return [];
      return list.map(mapBoxCategoryItem);
    },
  });
}

// 盲盒商城列表
export function useBoxShop(params?: { id?: number; page?: number; limit?: number; cid?: number }) {
  return useQuery({
    queryKey: ["boxShop", params?.id ?? params?.cid, params?.page],
    queryFn: () => getBoxShop({ 
      page: params?.page ?? 1, 
      limit: params?.limit ?? 20, 
      id: params?.id ?? params?.cid,
      cid: params?.cid 
    }),
    select: (data) => (data?.data?.shop || data?.data?.list || []).map(mapBoxItem),
  });
}

// 盲盒详情
export function useBoxDetail(id: number) {
  return useQuery({
    queryKey: ["boxDetail", id],
    queryFn: () => getBoxDetail({ id }),
    enabled: id > 0,
    select: (data) => mapBoxDetail(data?.data || {}),
  });
}

// 盲盒详情(另一接口)
export function useBoxDetail2(id: number) {
  return useQuery({
    queryKey: ["boxDetail2", id],
    queryFn: () => getBoxDetail2({ id }),
    enabled: id > 0,
    select: (data) => mapBoxDetail(data?.data || {}),
  });
}

// 我的盲盒列表(背包)
export function useBoxList(params?: { page?: number; limit?: number; status?: number }) {
  return useQuery({
    queryKey: ["boxList", params?.status, params?.page],
    queryFn: () => getBoxList({ 
      page: params?.page ?? 1, 
      limit: params?.limit ?? 20, 
      status: params?.status 
    }),
    select: (data) => (data?.data?.list || []).map(mapBackpackItem),
  });
}

// 开盒记录
export function useBoxLog(params?: { page?: number; limit?: number; cid?: number }) {
  return useQuery({
    queryKey: ["boxLog", params?.cid, params?.page],
    queryFn: () => getBoxLog({ 
      cid: params?.cid,
      page: params?.page ?? 1, 
      limit: params?.limit ?? 20 
    }),
    select: (data) => (data?.data?.list || []).map(mapOpeningHistoryItem),
  });
}

// 开盒记录详情
export function useBoxLogInfo(id: number) {
  return useQuery({
    queryKey: ["boxLogInfo", id],
    queryFn: () => getBoxLogInfo({ id }),
    enabled: id > 0,
  });
}

// 回收
export function useDoRecovery() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: doRecovery,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["boxList"] });
      showToast("Recycled successfully!", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

// 添加盲盒(开盒)
export function useAddBox() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: addBox,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["boxList"] });
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      showToast("Box opened successfully!", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

// 创建盲盒订单
export function useCreateBoxOrder() {
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: createBoxOrder,
    onSuccess: () => {
      showToast("Order created successfully!", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

// 品牌列表
export function useBoxBrandList(params?: { page?: number; limit?: number }) {
  return useQuery({
    queryKey: ["boxBrandList", params?.page],
    queryFn: () => getBoxBrandList({ 
      page: params?.page ?? 1, 
      limit: params?.limit ?? 20 
    }),
  });
}

// 品牌详情
export function useBoxBrand(id: number) {
  return useQuery({
    queryKey: ["boxBrand", id],
    queryFn: () => getBoxBrand({ id }),
    enabled: id > 0,
  });
}

// 中奖滚屏列表
export function useLuckyNotices() {
  return useQuery({
    queryKey: ["luckyNotices"],
    queryFn: getLuckyNotices,
    refetchInterval: 3000,
    select: (data) => (data?.data || []).map(mapLuckyNotice),
  });
}

// 盲盒配置
export function useBoxConfig() {
  return useQuery({
    queryKey: ["boxConfig"],
    queryFn: getBoxConfig,
    select: (data) => data?.data || {},
  });
}

// 元气配置
export function useYuanqiConfig() {
  return useQuery({
    queryKey: ["yuanqiConfig"],
    queryFn: getYuanqiConfig,
    select: (data) => data?.data || {},
  });
}

// 用户可用优惠券
export function useUserCoupon(money: number) {
  return useQuery({
    queryKey: ["boxUserCoupon", money],
    queryFn: () => getUserCoupon({ money }),
    enabled: money > 0,
    select: (data) => data?.data || [],
  });
}

// 盲盒订单支付
export function useBoxOrderPay() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: boxOrderPay,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      showToast("Payment successful", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

// 盲盒订单详情
export function useBoxOrderDetail(id: number) {
  return useQuery({
    queryKey: ["boxOrderDetail", id],
    queryFn: () => getBoxOrderDetail({ id }),
    enabled: id > 0,
    select: (data) => data?.data || {},
  });
}

// 检查订单支付状态
export function useCheckOrderPay() {
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: checkBoxOrderPay,
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

// 发货支付运费
export function useSendPay() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: sendPay,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["sendOrderList"] });
      showToast("Shipping fee paid successfully", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

// 创建发货订单
export function useSendCreateOrder() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: sendCreateOrder,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["boxList"] });
      qc.invalidateQueries({ queryKey: ["sendAll"] });
      showToast("Shipping order created successfully", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

// 发货订单详情
export function useSendOrderDetail(id: number) {
  return useQuery({
    queryKey: ["sendOrderDetail", id],
    queryFn: () => getSendOrderDetail({ id }),
    enabled: id > 0,
    select: (data) => data?.data || {},
  });
}

// 发货订单列表
export function useSendOrderList(params?: { page?: number; status?: number }) {
  return useQuery({
    queryKey: ["sendOrderList", params?.status, params?.page],
    queryFn: () => getSendOrderList({ page: params?.page ?? 1, status: params?.status }),
    select: (data) => data?.data || { list: [], total: 0 },
  });
}

// 可发货盲盒列表
export function useGetSendAll() {
  return useQuery({
    queryKey: ["sendAll"],
    queryFn: getSendAll,
    select: (data) => data?.data || [],
  });
}

// 抽奖列表（id=0 表示查询全部盲盒的抽奖记录）
export function useBoxChoujiangList(id: number, params?: { page?: number; status?: number }) {
  return useQuery({
    queryKey: ["boxChoujiangList", id, params?.page, params?.status],
    queryFn: () => getBoxChoujiangList({ id, page: params?.page ?? 1, status: params?.status }),
    select: (data) => data?.data || { list: [], total: 0 },
  });
}

// 开奖详情
export function useKaijiangInfo(id: number) {
  return useQuery({
    queryKey: ["kaijiangInfo", id],
    queryFn: () => getKaijiangInfo({ id }),
    enabled: id > 0,
    select: (data) => data?.data || {},
  });
}

// 盲盒通知弹窗
export function useBoxTongzhi() {
  return useQuery({
    queryKey: ["boxTongzhi"],
    queryFn: getBoxTongzhi,
    select: (data) => data?.data || { content: "" },
  });
}

// 抽奖结果（单次开盒）
export function useBoxGetOne() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: getBoxOne,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["boxList"] });
      qc.invalidateQueries({ queryKey: ["boxLog"] });
    },
  });
}

// 批量开盒结果
export function useBoxSgetOne() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: getBoxSgetOne,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["boxList"] });
      qc.invalidateQueries({ queryKey: ["boxLog"] });
    },
  });
}

// 往期揭晓
export function useWangqiJixiao(id: number, page?: number) {
  return useQuery({
    queryKey: ["wangqiJixiao", id, page],
    queryFn: () => getWangqiJixiao({ id, page: page ?? 1 }),
    enabled: id > 0,
    select: (data) => data?.data || { list: [], total: 0 },
  });
}

// ========== 签到系统 ==========

export function useCheckinInfo() {
  return useQuery({
    queryKey: ["checkinInfo"],
    queryFn: getCheckinInfo,
    select: (data) => data?.data || {},
  });
}

export function useCheckin() {
  const qc = useQueryClient();
  const { showToast } = useAppStore();
  return useMutation({
    mutationFn: doCheckin,
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["checkinInfo"] });
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      const pts = data?.data?.points || 0;
      showToast(`Checked in! Earned ${pts} points`, "success");
    },
  });
}

export function useCheckinTasks() {
  return useQuery({
    queryKey: ["checkinTasks"],
    queryFn: getCheckinTasks,
    select: (data) => data?.data || [],
  });
}

export function useClaimCheckinTask() {
  const qc = useQueryClient();
  const { showToast } = useAppStore();
  return useMutation({
    mutationFn: claimCheckinTask,
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ["checkinTasks"] });
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      const coins = data?.data?.coins || data?.data?.points || 0;
      showToast(`+${coins}`, "success");
    },
  });
}

export function useTrackBoxTaskEvent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: trackBoxTaskEvent,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["checkinTasks"] });
    },
  });
}

export function useClaimSignPrize() {
  const qc = useQueryClient();
  const { showToast } = useAppStore();
  return useMutation({
    mutationFn: claimSignPrize,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["signConfig"] });
      qc.invalidateQueries({ queryKey: ["checkinInfo"] });
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

// ========== 保底系统 ==========

export function usePityInfo() {
  return useQuery({
    queryKey: ["pityInfo"],
    queryFn: getPityInfo,
    select: (data) => data?.data || {},
  });
}

// ========== 心愿池 ==========

export function useWishlistList() {
  return useQuery({
    queryKey: ["wishlistList"],
    queryFn: getWishlistList,
    select: (data) => data?.data || [],
  });
}

export function useAddWishlistItem() {
  const qc = useQueryClient();
  const { showToast } = useAppStore();
  return useMutation({
    mutationFn: addWishlistItem,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wishlistList"] });
      showToast("Added successfully", "success");
    },
  });
}

export function useRemoveWishlistItem() {
  const qc = useQueryClient();
  const { showToast } = useAppStore();
  return useMutation({
    mutationFn: removeWishlistItem,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wishlistList"] });
      showToast("Removed", "success");
    },
  });
}

// ========== 交换市场 ==========

export function useExchangeList(params?: { page?: number; rarity?: string; search?: string }) {
  return useQuery({
    queryKey: ["exchangeList", params],
    queryFn: () => getExchangeList(params),
    select: (data) => data?.data || { list: [], total: 0 },
  });
}

export function useCreateExchangeListing() {
  const qc = useQueryClient();
  const { showToast } = useAppStore();
  return useMutation({
    mutationFn: createExchangeListing,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["exchangeList"] });
      qc.invalidateQueries({ queryKey: ["boxList"] });
      showToast("Published successfully", "success");
    },
  });
}

export function useApplyExchange() {
  const qc = useQueryClient();
  const { showToast } = useAppStore();
  return useMutation({
    mutationFn: applyExchange,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["exchangeList"] });
      showToast("Application submitted", "success");
    },
  });
}

// ========== 合成系统 ==========

export function useSynthesize() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: doSynthesize,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["boxList"] });
    },
  });
}

// ========== 排行榜 ==========

export function useLeaderboard(type: string = "luck") {
  return useQuery({
    queryKey: ["leaderboard", type],
    queryFn: () => getLeaderboard(type),
    select: (data) => data?.data || { list: [], type },
  });
}

// ========== 限时活动 ==========

export function useActivityList() {
  return useQuery({
    queryKey: ["activityList"],
    queryFn: getActivityList,
  });
}

export function useActivityDetail(id: number) {
  return useQuery({
    queryKey: ["activityDetail", id],
    queryFn: () => getActivityDetail(id),
    enabled: id > 0,
  });
}

// ========== 开盒回放 ==========

export function useReplayList(page: number = 1) {
  return useQuery({
    queryKey: ["replayList", page],
    queryFn: () => getReplayList(page),
  });
}

// ========== 好友系统 ==========

export function useFriendBoxList() {
  return useQuery({
    queryKey: ["friendBoxList"],
    queryFn: getFriendBoxList,
  });
}

export function useFriendGift() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ friendUid, userBoxId }: { friendUid: number; userBoxId: number }) =>
      friendGift(friendUid, userBoxId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["friendBoxList"] });
      qc.invalidateQueries({ queryKey: ["boxList"] });
    },
  });
}

// ========== 新人礼包 ==========

export function useNewbieCheck() {
  return useQuery({
    queryKey: ["newbieCheck"],
    queryFn: getNewbieCheck,
  });
}

export function useNewbieClaim() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: claimNewbieGift,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["newbieCheck"] });
    },
  });
}

// ========== Enhanced Exchange Hooks ==========

export function useExchangeMyList(status?: number) {
  return useQuery({
    queryKey: ["exchangeMyList", status],
    queryFn: () => getExchangeMyList(status),
    staleTime: 10000,
  });
}

export function useCancelExchangeListing() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: cancelExchangeListing,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["exchangeMyList"] });
      qc.invalidateQueries({ queryKey: ["boxList"] });
    },
  });
}

export function useConfirmExchange() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (params: { listingId: number; applicantBoxId: number }) =>
      confirmExchange(params.listingId, params.applicantBoxId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["exchangeOffers"] });
      qc.invalidateQueries({ queryKey: ["exchangeMyList"] });
    },
  });
}

export function useExchangeOffers() {
  return useQuery({
    queryKey: ["exchangeOffers"],
    queryFn: getExchangeOffers,
    staleTime: 15000,
  });
}

// ========== Wishlist Notifications Hooks ==========

export function useWishlistNotifications(page: number = 1) {
  return useQuery({
    queryKey: ["wishlistNotifications", page],
    queryFn: () => getWishlistNotifications(page),
    staleTime: 30000,
  });
}

export function useWishlistUnreadCount() {
  return useQuery({
    queryKey: ["wishlistUnreadCount"],
    queryFn: getWishlistUnreadCount,
    refetchInterval: 30000,
    staleTime: 15000,
  });
}

// ========== Quick Buy Hook ==========

export function useBoxQuickDetail(id: number) {
  return useQuery({
    queryKey: ["boxQuickDetail", id],
    queryFn: () => getBoxQuickDetail(id),
    enabled: !!id,
    staleTime: 30000,
  });
}

// ========== New Features Hooks ==========

export function useProbability(cateId: number) {
  return useQuery({
    queryKey: ["probability", cateId],
    queryFn: () => getProbability(cateId),
    enabled: !!cateId,
    staleTime: 60000,
  });
}

export function useFreeDraw() {
  const qc = useQueryClient();
  return {
    check: () => useQuery({
      queryKey: ["freeDraw"],
      queryFn: checkFreeDraw,
      staleTime: 10000,
    }),
    doDraw: useMutation({
      mutationFn: doFreeDraw,
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: ["freeDraw"] });
        qc.invalidateQueries({ queryKey: ["boxList"] });
      },
    }),
  };
}

export function useInviteInfo() {
  return useQuery({
    queryKey: ["inviteInfo"],
    queryFn: getInviteInfo,
    staleTime: 30000,
  });
}

export function useClaimInviteReward() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (level: number) => claimInviteReward(level),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["inviteInfo"] });
    },
  });
}
