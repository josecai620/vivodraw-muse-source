import React from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useQuery } from "@tanstack/react-query";
import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

export default function CommissionPeopleScreen() {
  const { data, isLoading } = useQuery({
    queryKey: ["spreadPeople"],
    queryFn: () => http.post(API_ENDPOINTS.commission.spreadPeople, { page: 1, limit: 20 }),
  });

  const raw = (data as any)?.data ?? data;
  const list = raw?.list ?? raw ?? [];

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="My Team" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16) }} showsVerticalScrollIndicator={false}>
          {Array.isArray(list) && list.length > 0 ? (
            list.map((item: any, i: number) => (
              <View key={i} className="bg-white rounded-2xl p-4 mb-3 border border-gray-100">
                <Text className="font-medium" style={{ color: Colors.neutral[800] }}>{item.nickname ?? "User"}</Text>
                <Text className="text-sm mt-1" style={{ color: Colors.neutral[500] }}>{item.add_time ?? ""}</Text>
              </View>
            ))
          ) : (
            <View className="flex-1 items-center justify-center py-12">
              <Text style={{ color: Colors.neutral[500] }}>No team members yet</Text>
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}
