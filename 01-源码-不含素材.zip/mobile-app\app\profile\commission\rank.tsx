import React from "react";
import { ActivityIndicator, FlatList, Text, View } from "react-native";
import { useQuery } from "@tanstack/react-query";
import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

export default function CommissionRankScreen() {
  const { data, isLoading } = useQuery({
    queryKey: ["brokerageRank"],
    queryFn: () => http.get(API_ENDPOINTS.user.brokerageRank),
  });

  const raw = (data as any)?.data ?? data ?? {};
  const list = raw?.list ?? raw?.rank ?? (Array.isArray(raw) ? raw : []);

  const renderItem = ({ item, index }: { item: any; index: number }) => {
    const rank = index + 1;
    const name = item.nickname ?? item.user_name ?? "User";
    const brokerage = item.brokerage_price ?? item.total ?? "0";

    return (
      <View className="flex-row items-center bg-white mb-2 rounded-xl p-4 border border-gray-100">
        <View
          className="w-10 h-10 rounded-full items-center justify-center mr-3"
          style={{
            backgroundColor: rank <= 3 ? `${Colors.brand.red}20` : Colors.neutral[100],
          }}
        >
          <Text
            className="font-bold"
            style={{ color: rank <= 3 ? Colors.brand.red : Colors.neutral[600], fontSize: s(16) }}
          >
            {rank}
          </Text>
        </View>
        <View className="flex-1">
          <Text className="font-semibold" style={{ color: Colors.neutral[800] }}>
            {name}
          </Text>
          <Text className="text-sm" style={{ color: Colors.neutral[500] }}>
            ${brokerage} commission
          </Text>
        </View>
      </View>
    );
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Commission Rank" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <View className="flex-1 px-4 pt-4">
          <FlatList
            data={Array.isArray(list) ? list : []}
            renderItem={renderItem}
            keyExtractor={(item, i) => String(item.uid ?? item.id ?? i)}
            contentContainerStyle={{ paddingBottom: s(80) }}
            ListEmptyComponent={
              <View className="py-12 items-center">
                <Text style={{ color: Colors.neutral[500] }}>No ranking data</Text>
              </View>
            }
          />
        </View>
      )}
    </View>
  );
}
