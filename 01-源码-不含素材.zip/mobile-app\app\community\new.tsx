import CachedImage from "@/components/shared/CachedImage";
import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import { useCommunityComposer } from "@/hooks/useCommunityComposer";
import { submitCommunityPost, uploadCommunityImage } from "@/lib/api/community";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { Image as RNImage, Platform, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { ActivityIndicator } from "react-native";
import { Camera, Check, X } from "lucide-react-native";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";

const allowedImageTypes = new Set(["image/jpeg", "image/png", "image/webp"]);
const maxImageSize = 2 * 1024 * 1024;
const maxImages = 6;

type AttachedImage = {
  id: string;
  name: string;
  previewUrl: string;
  uploadedUrl?: string;
  isUploading: boolean;
};

export default function NewCommunityPostScreen() {
  const router = useRouter();
  const { i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const text = (z: string, e: string) => (zh ? z : e);
  const composer = useCommunityComposer();
  const [targetId, setTargetId] = useState("");
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [images, setImages] = useState<AttachedImage[]>([]);
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const selectedTarget = composer.targets.find((target) => target.id === targetId);
  const isUploading = images.some((image) => image.isUploading);
  const uploadedImages = images.map((image) => image.uploadedUrl).filter(Boolean) as string[];
  const canSubmit = Boolean(
    targetId && title.trim() && content.trim() && uploadedImages.length > 0 && !isUploading && !isSubmitting,
  );

  const pickImages = () => {
    if (Platform.OS !== "web" || typeof document === "undefined") {
      setMessage(text("圖片上傳僅支持網頁端", "Image upload works on web only."));
      return;
    }
    const input = document.createElement("input");
    input.type = "file";
    input.multiple = true;
    input.accept = "image/png,image/jpeg,image/webp";
    input.onchange = () => {
      const selectedFiles = Array.from(input.files || []);
      selectedFiles
        .slice(0, Math.max(0, maxImages - images.length))
        .forEach((file) => {
          void attachImage(file);
        });
    };
    input.click();
  };

  const attachImage = async (file: File) => {
    if (!allowedImageTypes.has(file.type) || file.size > maxImageSize) {
      setMessage(text("僅支持 2MB 以內的 JPG/PNG/WebP", "Only JPG, PNG, or WebP images under 2 MB."));
      return;
    }
    if (images.length >= maxImages) {
      setMessage(text("最多 6 張圖片", "Maximum 6 images."));
      return;
    }
    const previewUrl = URL.createObjectURL(file);
    const localId = `${file.name}-${Date.now()}`;
    setMessage(text("圖片上傳中…", "Uploading image..."));
    setImages((rows) => [...rows, { id: localId, name: file.name, previewUrl, isUploading: true }]);
    const result = await uploadCommunityImage(file);
    if (!result.ok || !result.data?.url) {
      setMessage(result.message || text("圖片上傳失敗", "Image upload failed."));
      setImages((rows) =>
        rows.map((row) => (row.id === localId ? { ...row, isUploading: false } : row)),
      );
      return;
    }
    setMessage(text("圖片已上傳", "Image uploaded."));
    setImages((rows) =>
      rows.map((row) =>
        row.id === localId ? { ...row, uploadedUrl: result.data?.url, isUploading: false } : row,
      ),
    );
  };

  const removeImage = (id: string) => {
    setImages((rows) => rows.filter((row) => row.id !== id));
  };

  const submitPost = async () => {
    if (!canSubmit) {
      setMessage(text("請選擇中獎記錄、填寫標題與故事並至少上傳一張圖片", "Choose a reward record, write a post, and upload at least one image."));
      return;
    }
    setIsSubmitting(true);
    setMessage("");
    const result = await submitCommunityPost({
      targetId,
      title: title.trim(),
      content: content.trim(),
      images: uploadedImages,
    });
    setIsSubmitting(false);
    if (!result.ok) {
      setMessage(result.message || text("發佈失敗", "Post was not submitted."));
      return;
    }
    setTitle("");
    setContent("");
    setTargetId("");
    setImages([]);
    setMessage(text("已提交，審核通過後會出現在社區", "Submitted. It appears after a quick check."));
    composer.refresh();
  };

  return (
    <View className="flex-1 bg-neutral-50">
      <PageHeader title={text("分享晒單", "Share a win")} />
      <ScrollView
        contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="bg-white rounded-2xl p-5 gap-2">
          <Text className="text-lg font-bold text-neutral-900">
            {text("晒出真實收穫，不做營銷噱頭", "Post real proof, not marketing fog.")}
          </Text>
          <Text className="text-sm text-neutral-500 leading-5">
            {text(
              "選擇一條中獎記錄，上張實物或截圖，寫下你的故事。",
              "Choose a reward record, add screenshots or product photos, then submit your story.",
            )}
          </Text>
        </View>

        {/* 选择中奖记录 */}
        <View className="bg-white rounded-2xl p-4 gap-3">
          <View className="flex-row items-center justify-between">
            <Text className="text-base font-bold text-neutral-900">{text("選擇收穫", "Choose a win")}</Text>
            <Text className="text-xs text-neutral-400">
              {composer.targets.length} {text("條記錄", "records")}
            </Text>
          </View>
          {composer.targets.length > 0 ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View className="flex-row gap-2">
                {composer.targets.map((target) => {
                  const active = target.id === targetId;
                  return (
                    <Pressable
                      key={target.id}
                      onPress={() => setTargetId(target.id)}
                      className="rounded-xl p-2 border"
                      style={{
                        width: 128,
                        borderColor: active ? Colors.brand.red : "rgba(12,31,31,0.08)",
                        backgroundColor: active ? "#ECFBFB" : "#F7F9F9",
                      }}
                    >
                      {target.image ? (
                        <CachedImage uri={target.image} style={{ width: "100%", aspectRatio: 1, borderRadius: 8 }} />
                      ) : null}
                      <Text numberOfLines={2} className="text-xs font-bold text-neutral-900 mt-1.5">
                        {target.productName}
                      </Text>
                      <Text className="text-[10px] text-neutral-400 mt-0.5">{target.openedAt}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </ScrollView>
          ) : (
            <View className="rounded-xl p-5 items-center gap-3" style={{ backgroundColor: "#F7F9F9" }}>
              <Text className="text-sm font-bold text-neutral-900">
                {text("暫無可晒的收穫", "No eligible wins yet")}
              </Text>
              <Text className="text-xs text-neutral-500 text-center leading-4">
                {text(
                  "開出獎品並就緒後，再回來分享結果。",
                  "Open a reward, then come back to share the result after it is ready.",
                )}
              </Text>
              <Pressable
                className="h-10 px-5 rounded-lg border border-neutral-200 items-center justify-center"
                onPress={() => router.push("/points")}
              >
                <Text className="text-sm font-semibold text-neutral-700">{text("去看獎品", "Open rewards")}</Text>
              </Pressable>
            </View>
          )}
          {selectedTarget ? (
            <View className="flex-row items-center rounded-xl px-3 py-2" style={{ backgroundColor: "#ECFBFB" }}>
              <Check size={14} color={Colors.brand.redDark} />
              <Text numberOfLines={2} className="flex-1 ml-2 text-xs font-bold" style={{ color: Colors.brand.redDark }}>
                {text("已選擇", "Selected")}: {selectedTarget.productName}
              </Text>
            </View>
          ) : null}
        </View>

        {/* 标题与故事 */}
        <View className="bg-white rounded-2xl p-5 gap-3">
          <Text className="text-sm font-bold text-neutral-900">{text("標題", "Title")}</Text>
          <TextInput
            placeholder={text("給晒單起個標題", "Give your post a title")}
            placeholderTextColor={Colors.neutral[400]}
            value={title}
            onChangeText={setTitle}
            maxLength={60}
            className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 h-12 text-sm text-neutral-900"
          />
          <Text className="text-sm font-bold text-neutral-900">{text("故事", "Story")}</Text>
          <TextInput
            multiline
            placeholder={text("描述你收到了什麼、對其他買家有什麼參考", "Describe what you received and why it helps other buyers.")}
            placeholderTextColor={Colors.neutral[400]}
            value={content}
            onChangeText={setContent}
            maxLength={1000}
            className="w-full bg-neutral-50 border border-neutral-200 rounded-xl px-3.5 py-3 text-sm text-neutral-900"
            style={{ minHeight: 120 }}
          />

          <View className="flex-row items-center justify-between">
            <Text className="text-sm font-bold text-neutral-900">{text("照片", "Photos")}</Text>
            <Text className="text-xs text-neutral-400">
              {images.length} / {maxImages}
            </Text>
          </View>
          {images.length > 0 ? (
            <View className="flex-row flex-wrap gap-2">
              {images.map((image) => (
                <View key={image.id} className="rounded-xl overflow-hidden border border-neutral-200" style={{ width: 104 }}>
                  <RNImage source={{ uri: image.previewUrl }} style={{ width: 104, height: 104 }} resizeMode="cover" />
                  <View className="p-1.5 gap-0.5">
                    <Text numberOfLines={1} className="text-[10px] text-neutral-700">
                      {image.name}
                    </Text>
                    <Text
                      className="text-[10px] font-bold"
                      style={{ color: image.isUploading ? Colors.neutral[400] : image.uploadedUrl ? Colors.brand.redDark : Colors.error }}
                    >
                      {image.isUploading
                        ? text("上傳中…", "Uploading...")
                        : image.uploadedUrl
                          ? text("就緒", "Ready")
                          : text("失敗", "Upload failed")}
                    </Text>
                    <Pressable className="flex-row items-center" onPress={() => removeImage(image.id)}>
                      <X size={11} color={Colors.neutral[500]} />
                      <Text className="text-[10px] text-neutral-500 ml-0.5">{text("移除", "Remove")}</Text>
                    </Pressable>
                  </View>
                </View>
              ))}
            </View>
          ) : null}
          <Pressable
            disabled={images.length >= maxImages || isUploading}
            onPress={pickImages}
            className="h-12 rounded-xl border border-dashed items-center justify-center flex-row"
            style={{
              borderColor: images.length >= maxImages ? Colors.neutral[300] : Colors.brand.red,
              opacity: images.length >= maxImages || isUploading ? 0.5 : 1,
            }}
          >
            <Camera size={18} color={Colors.brand.red} />
            <Text className="ml-2 font-bold text-sm" style={{ color: Colors.brand.redDark }}>
              {text("上傳照片", "Upload photo")}
            </Text>
          </Pressable>
        </View>

        <Pressable disabled={!canSubmit} onPress={() => void submitPost()}>
          <LinearGradient
            colors={
              canSubmit
                ? [TealGradient.light, TealGradient.base, TealGradient.dark]
                : [Colors.neutral[300], Colors.neutral[300]]
            }
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            className="h-12 rounded-xl items-center justify-center"
          >
            {isSubmitting ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Text className="text-white font-bold">{text("發佈晒單", "Submit post")}</Text>
            )}
          </LinearGradient>
        </Pressable>
        {message ? (
          <Text className="text-sm text-center" style={{ color: Colors.brand.redDark }}>
            {message}
          </Text>
        ) : null}
      </ScrollView>
    </View>
  );
}
