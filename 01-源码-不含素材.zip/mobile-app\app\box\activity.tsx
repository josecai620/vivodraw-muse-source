/**
 * 限时活动（Premium Dark Gaming UI）
 */
import React, { useMemo } from "react";
import { View, Text, ScrollView, Pressable, ActivityIndicator } from "react-native";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { Clock, Zap, ChevronRight, Flame } from "lucide-react-native";
import { BoxHeader, BoxEmptyState, CountdownTimer } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, bs,
} from "@/lib/boxTheme";
import { useActivityList } from "@/hooks";

export default function ActivityPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const { data: activities = [], isLoading } = useActivityList();

  const activitiesWithEndTime = useMemo(
    () => ((activities as any[]) || []).map((act: any) => ({
      ...act,
      _endTime: Date.now() + (act.remainingSeconds || 0) * 1000,
    })),
    [activities],
  );

  const boostLabel = (type: string, value: number) => {
    if (type === "rarity_up") return t("activity.boostRarity", { value });
    if (type === "discount") return t("activity.boostDiscount", { value: Math.round(value * 10) });
    if (type === "bonus") return t("activity.boostBonus", { value });
    return "";
  };

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("activity.title")} />

      <ScrollView
        style={{ flex: 1 }}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ padding: BoxSpacing.lg, paddingBottom: bs(100) }}
      >
        {isLoading ? (
          <ActivityIndicator size="large" color={BoxAccent.purple} style={{ marginTop: BoxSpacing["4xl"] }} />
        ) : activitiesWithEndTime.length === 0 ? (
          <BoxEmptyState
            icon={<Clock size={bs(48)} color={BoxText.tertiary} />}
            title={t("activity.empty")}
            description={t("activity.emptySub")}
          />
        ) : (
          activitiesWithEndTime.map((act: any) => (
            <Pressable
              key={act.id}
              onPress={() => router.push(`/box/${act.cateId || 0}`)}
              style={{
                marginBottom: BoxSpacing.lg,
                borderRadius: BoxRadius.xl,
                overflow: "hidden",
                ...BoxShadows.elevated,
              }}
            >
              <LinearGradient
                colors={[BoxGradients.purpleEvent[0], BoxGradients.purpleEvent[1], BoxAccent.purpleLight]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={{ padding: BoxSpacing.xl, borderRadius: BoxRadius.xl }}
              >
                {/* Limited badge */}
                <View style={{
                  flexDirection: "row",
                  alignItems: "center",
                  alignSelf: "flex-start",
                  backgroundColor: "rgba(255,255,255,0.18)",
                  borderRadius: BoxRadius.full,
                  paddingHorizontal: BoxSpacing.md,
                  paddingVertical: BoxSpacing.xs,
                  gap: BoxSpacing.xs,
                  marginBottom: BoxSpacing.md,
                }}>
                  <Flame size={bs(14)} color="#fff" />
                  <Text style={[BoxTypography.micro, { color: "#fff" }]}>
                    {t("activity.limited")}
                  </Text>
                </View>

                <Text style={[BoxTypography.h1, { color: BoxText.primary, marginBottom: BoxSpacing.xs }]}>
                  {act.title}
                </Text>
                <Text style={[BoxTypography.body, { color: "rgba(255,255,255,0.8)", marginBottom: BoxSpacing.lg }]}>
                  {act.description}
                </Text>

                {/* Boost badge */}
                <View style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: BoxSpacing.sm,
                  backgroundColor: "rgba(255,255,255,0.18)",
                  borderRadius: BoxRadius.md,
                  paddingHorizontal: BoxSpacing.md,
                  paddingVertical: BoxSpacing.sm,
                  marginBottom: BoxSpacing.lg,
                  alignSelf: "flex-start",
                }}>
                  <Zap size={bs(16)} color="#fff" />
                  <Text style={[BoxTypography.bodyBold, { color: "#fff" }]}>
                    {boostLabel(act.boostType, act.boostValue)}
                  </Text>
                </View>

                {/* Countdown */}
                <View style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: BoxSpacing.md,
                  marginBottom: BoxSpacing.lg,
                }}>
                  <Text style={[BoxTypography.caption, { color: "rgba(255,255,255,0.7)" }]}>
                    {t("activity.timeLeft")}
                  </Text>
                  <CountdownTimer endTime={act._endTime} />
                </View>

                {/* Category info */}
                {act.cateInfo && (
                  <View style={{
                    flexDirection: "row",
                    alignItems: "center",
                    backgroundColor: "rgba(255,255,255,0.12)",
                    borderRadius: BoxRadius.md,
                    padding: BoxSpacing.md,
                    gap: BoxSpacing.md,
                  }}>
                    {act.cateInfo.pic ? (
                      <Image
                        source={{ uri: act.cateInfo.pic }}
                        style={{ width: bs(36), height: bs(36), borderRadius: BoxRadius.sm }}
                      />
                    ) : null}
                    <Text style={[BoxTypography.bodyBold, { color: BoxText.primary, flex: 1 }]}>
                      {act.cateInfo.cate_name}
                    </Text>
                    <ChevronRight size={bs(16)} color="rgba(255,255,255,0.6)" />
                  </View>
                )}
              </LinearGradient>
            </Pressable>
          ))
        )}
      </ScrollView>
    </View>
  );
}
