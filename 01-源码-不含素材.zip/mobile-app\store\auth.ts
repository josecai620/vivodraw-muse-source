import { create } from "zustand";
import { deleteItem, getItem, setItem } from "@/lib/secure-storage";

const TOKEN_KEY = "auth_token";
const USER_KEY = "auth_user";

export interface User {
  id?: number;
  uid: number;
  nickname: string;
  avatar: string;
  phone: string;
  integral: number;
  now_money: string;
  lucky_num?: number;
  level: number;
  vip?: boolean;
  sex?: number;
  birthday?: number;
  real_name?: string;
  avatar_frame?: string;
  claimed_free_trial?: number | boolean | string | null;
  spend_usd?: number | string;
  pet?: {
    code?: string;
    name?: string;
    species?: string;
    pet_code?: string;
    pet_name?: string;
    intimacy_level?: number;
  };
}

interface AuthState {
  token: string | null;
  user: User | null;
  isLoggedIn: boolean;
  isHydrated: boolean;

  setToken: (token: string) => void;
  setUser: (user: User) => void;
  logout: () => void;
  hydrate: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  token: null,
  user: null,
  isLoggedIn: false,
  isHydrated: false,

  setToken: (token) => {
    setItem(TOKEN_KEY, token).catch((e) =>
      console.warn("Failed to persist token:", e),
    );
    set({ token, isLoggedIn: true });
  },

  setUser: (user) => {
    setItem(USER_KEY, JSON.stringify(user)).catch((e) =>
      console.warn("Failed to persist user:", e),
    );
    set({ user });
  },

  logout: () => {
    deleteItem(TOKEN_KEY).catch(() => {});
    deleteItem(USER_KEY).catch(() => {});
    set({ token: null, user: null, isLoggedIn: false });
  },

  hydrate: async () => {
    try {
      const token = await getItem(TOKEN_KEY);
      const userStr = await getItem(USER_KEY);
      let user: User | null = null;
      if (userStr) {
        try {
          const parsed = JSON.parse(userStr);
          if (parsed && typeof parsed.uid === "number") {
            user = parsed;
          } else {
            await deleteItem(USER_KEY).catch(() => {});
          }
        } catch {
          await deleteItem(USER_KEY).catch(() => {});
        }
      }
      set({
        token,
        user,
        isLoggedIn: !!token,
        isHydrated: true,
      });
    } catch {
      set({ isHydrated: true });
    }
  },
}));
