import React, { useState } from "react";
import { Pressable, ScrollView, Text, View, ActivityIndicator } from "react-native";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Sparkles, ChevronRight, Zap, Info, Package, Check, XCircle } from "lucide-react-native";
import { Image } from "expo-image";
import { SafeAreaView } from "react-native-safe-area-context";
import { BoxHeader, RarityBadge, BoxActionButton, BoxEmptyState, BoxTabBar } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  getRarityTier, bs, type RarityTier,
} from "@/lib/boxTheme";
import { useBoxList, useSynthesize } from "@/hooks";
import { useAppStore } from "@/store/app";

const SYNTHESIS_RECIPES: {
  key: string;
  from: RarityTier;
  to: RarityTier;
  count: number;
  successRate: number;
}[] = [
  { key: "common_to_uncommon", from: "common", to: "uncommon", count: 3, successRate: 100 },
  { key: "uncommon_to_rare", from: "uncommon", to: "rare", count: 3, successRate: 80 },
  { key: "rare_to_epic", from: "rare", to: "epic", count: 3, successRate: 60 },
  { key: "epic_to_legendary", from: "epic", to: "legendary", count: 3, successRate: 40 },
  { key: "legendary_to_secret", from: "legendary", to: "secret", count: 3, successRate: 20 },
];

export default function SynthesisPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const showToast = useAppStore((s) => s.showToast);
  const { data: backpackItems, isLoading } = useBoxList();
  const synthesizeMutation = useSynthesize();
  const [selectedRecipe, setSelectedRecipe] = useState(0);
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [result, setResult] = useState<{ success: boolean; item?: any } | null>(null);

  const recipe = SYNTHESIS_RECIPES[selectedRecipe];
  const fromRarity = getRarityTier(recipe.from);
  const toRarity = getRarityTier(recipe.to);

  const eligibleItems = (backpackItems || []).filter(
    (item: any) => (item.rarity || "common") === recipe.from
  );

  const toggleItem = (id: number) => {
    if (selectedItems.includes(id)) {
      setSelectedItems(selectedItems.filter((i) => i !== id));
    } else if (selectedItems.length < recipe.count) {
      setSelectedItems([...selectedItems, id]);
    }
  };

  const handleSynthesize = () => {
    if (selectedItems.length < recipe.count || synthesizeMutation.isPending) return;
    synthesizeMutation.mutate(
      { item_ids: selectedItems, recipe: recipe.key },
      {
        onSuccess: (data: any) => {
          const d = data?.data || data;
          const success = !!d?.success;
          setResult({ success, item: d?.item });
          if (success) {
            const itemName = d?.item?.name || `${t("rarity." + recipe.to)} item`;
            showToast(t("synthesis.toastSuccess", { item: itemName }), "success");
          } else {
            showToast(t("synthesis.toastFail"), "error");
          }
          setSelectedItems([]);
        },
      },
    );
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: BoxSurfaces.void }} edges={["top"]}>
      <BoxHeader title={t("synthesis.title")} showThemeToggle={false} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(128) }}>
          {/* Recipe Selector */}
          <Text style={[BoxTypography.h2, { color: BoxText.primary, marginBottom: BoxSpacing.md }]}>
            {t("synthesis.recipes")}
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: BoxSpacing["2xl"] }}>
            {SYNTHESIS_RECIPES.map((r, idx) => {
              const isActive = selectedRecipe === idx;
              const fRarity = getRarityTier(r.from);
              const tRarity = getRarityTier(r.to);
              return (
                <Pressable
                  key={idx}
                  onPress={() => { setSelectedRecipe(idx); setSelectedItems([]); setResult(null); }}
                  style={{
                    borderRadius: BoxRadius.xl,
                    padding: BoxSpacing.md,
                    marginRight: BoxSpacing.md,
                    minWidth: bs(140),
                    backgroundColor: isActive ? tRarity.bgSubtle : BoxSurfaces.card,
                    borderWidth: 2,
                    borderColor: isActive ? tRarity.color : BoxBorders.default,
                  }}
                >
                  <View style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: BoxSpacing.sm,
                    marginBottom: BoxSpacing.sm,
                  }}>
                    <View style={{
                      width: bs(32), height: bs(32), borderRadius: BoxRadius.sm,
                      alignItems: "center", justifyContent: "center",
                      backgroundColor: fRarity.bgSubtle,
                    }}>
                      <View style={{
                        width: bs(12), height: bs(12), borderRadius: bs(6),
                        backgroundColor: fRarity.color,
                      }} />
                    </View>
                    <ChevronRight size={bs(14)} color={BoxText.tertiary} />
                    <View style={{
                      width: bs(32), height: bs(32), borderRadius: BoxRadius.sm,
                      alignItems: "center", justifyContent: "center",
                      backgroundColor: tRarity.bgSubtle,
                    }}>
                      <View style={{
                        width: bs(12), height: bs(12), borderRadius: bs(6),
                        backgroundColor: tRarity.color,
                      }} />
                    </View>
                  </View>
                  <Text style={[BoxTypography.caption, { color: BoxText.primary, textAlign: "center" }]}>
                    {r.count} {t("rarity." + r.from)} → {t("rarity." + r.to)}
                  </Text>
                  <Text style={[BoxTypography.micro, { color: BoxText.secondary, textAlign: "center", marginTop: 2 }]}>
                    {t("synthesis.successRate", { rate: r.successRate })}
                  </Text>
                </Pressable>
              );
            })}
          </ScrollView>

          {/* Hero Fusion Card */}
          <View style={{
            borderRadius: BoxRadius["2xl"],
            overflow: "hidden",
            marginBottom: BoxSpacing["2xl"],
            borderWidth: 1,
            borderColor: toRarity.borderColor,
            ...BoxShadows.glow(toRarity.color),
          }}>
            <LinearGradient
              colors={[toRarity.bgSubtle, "rgba(0,0,0,0)"]}
              style={{ padding: BoxSpacing.xl }}
            >
              <View style={{ alignItems: "center", marginBottom: BoxSpacing.lg }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.lg }}>
                  <View style={{ alignItems: "center" }}>
                    <View style={{
                      width: bs(64), height: bs(64), borderRadius: BoxRadius.xl,
                      alignItems: "center", justifyContent: "center",
                      backgroundColor: fromRarity.bgSubtle,
                      borderWidth: 2, borderColor: fromRarity.color,
                    }}>
                      <Text style={[BoxTypography.h2, { color: fromRarity.color }]}>×{recipe.count}</Text>
                    </View>
                    <Text style={[BoxTypography.caption, { color: fromRarity.color, marginTop: BoxSpacing.xs }]}>
                      {t("rarity." + recipe.from)}
                    </Text>
                  </View>
                  <Sparkles size={bs(24)} color={BoxAccent.gold} />
                  <View style={{ alignItems: "center" }}>
                    <View style={{
                      width: bs(64), height: bs(64), borderRadius: BoxRadius.xl,
                      alignItems: "center", justifyContent: "center",
                      backgroundColor: toRarity.bgSubtle,
                      borderWidth: 2, borderColor: toRarity.color,
                    }}>
                      <Text style={[BoxTypography.h2, { color: toRarity.color }]}>×1</Text>
                    </View>
                    <Text style={[BoxTypography.caption, { color: toRarity.color, marginTop: BoxSpacing.xs }]}>
                      {t("rarity." + recipe.to)}
                    </Text>
                  </View>
                </View>
              </View>
              <View style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: BoxSpacing["2xl"],
              }}>
                <View style={{ alignItems: "center" }}>
                  <Text style={[BoxTypography.priceHero, { color: BoxText.primary }]}>
                    {recipe.successRate}%
                  </Text>
                  <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
                    {t("synthesis.successRateLabel")}
                  </Text>
                </View>
                <View style={{ width: 1, height: bs(32), backgroundColor: BoxBorders.default }} />
                <View style={{ alignItems: "center" }}>
                  <Text style={[BoxTypography.priceHero, { color: BoxText.primary }]}>
                    {selectedItems.length}/{recipe.count}
                  </Text>
                  <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
                    {t("synthesis.materialsSelected")}
                  </Text>
                </View>
              </View>
            </LinearGradient>
          </View>

          {/* Material Selection */}
          <Text style={[BoxTypography.h2, { color: BoxText.primary, marginBottom: BoxSpacing.md }]}>
            {t("synthesis.selectMaterials", { rarity: t("rarity." + recipe.from) })}
          </Text>

          {isLoading ? (
            <View style={{ paddingVertical: BoxSpacing["4xl"], alignItems: "center" }}>
              <ActivityIndicator size="large" color={BoxAccent.gold} />
              <Text style={[BoxTypography.caption, { color: BoxText.secondary, marginTop: BoxSpacing.lg }]}>
                {t("synthesis.loadingBackpack")}
              </Text>
            </View>
          ) : eligibleItems.length === 0 ? (
            <BoxEmptyState
              icon={<Sparkles size={bs(48)} color={BoxText.tertiary} />}
              title={t("synthesis.noItems", { rarity: t("rarity." + recipe.from) })}
              actionLabel={t("synthesis.goDraw")}
              onAction={() => router.push("/box")}
            />
          ) : (
            <View style={{
              flexDirection: "row",
              flexWrap: "wrap",
              gap: BoxSpacing.md,
              marginBottom: BoxSpacing["2xl"],
            }}>
              {eligibleItems.map((item: any) => {
                const isSelected = selectedItems.includes(item.id);
                return (
                  <Pressable
                    key={item.id}
                    onPress={() => toggleItem(item.id)}
                    style={{
                      width: "22%",
                      aspectRatio: 1,
                      borderRadius: BoxRadius.lg,
                      overflow: "hidden",
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: isSelected ? fromRarity.bgSubtle : BoxSurfaces.card,
                      borderWidth: 2,
                      borderColor: isSelected ? fromRarity.color : BoxBorders.default,
                    }}
                  >
                    {item.image && /^https?:\/\//i.test(String(item.image)) ? (
                      <Image source={{ uri: String(item.image) }} style={{ width: "70%", height: "70%" }} contentFit="contain" />
                    ) : (
                      <Package size={bs(20)} color={isSelected ? fromRarity.color : BoxAccent.gold} strokeWidth={1.6} />
                    )}
                    <Text
                      numberOfLines={1}
                      style={[BoxTypography.micro, { color: BoxText.primary, marginTop: 2 }]}
                    >
                      {item.name}
                    </Text>
                    {isSelected && (
                      <View style={{
                        position: "absolute",
                        top: BoxSpacing.xs, right: BoxSpacing.xs,
                        width: bs(16), height: bs(16), borderRadius: bs(8),
                        alignItems: "center", justifyContent: "center",
                        backgroundColor: fromRarity.color,
                      }}>
                        <Check size={bs(10)} color="#fff" strokeWidth={3} />
                      </View>
                    )}
                  </Pressable>
                );
              })}
            </View>
          )}

          {/* Result */}
          {result && (
            <View style={{
              borderRadius: BoxRadius.xl,
              padding: BoxSpacing.xl,
              marginBottom: BoxSpacing["2xl"],
              alignItems: "center",
              backgroundColor: result.success ? toRarity.bgSubtle : BoxSurfaces.elevated,
              borderWidth: 1,
              borderColor: result.success ? toRarity.color : BoxBorders.default,
              ...(result.success ? BoxShadows.glow(toRarity.color) : {}),
            }}>
              <View style={{ marginBottom: BoxSpacing.md }}>
                {result.success
                  ? <Sparkles size={bs(38)} color={toRarity.color} strokeWidth={1.6} />
                  : <XCircle size={bs(38)} color={BoxText.tertiary} strokeWidth={1.6} />}
              </View>
              <Text style={[BoxTypography.h2, {
                color: result.success ? toRarity.color : BoxText.primary,
                marginBottom: BoxSpacing.xs,
              }]}>
                {result.success ? t("synthesis.success") : t("synthesis.fail")}
              </Text>
              <Text style={[BoxTypography.body, { color: BoxText.secondary }]}>
                {result.success
                  ? t("synthesis.gotItem", { item: result.item?.name || t("rarity." + recipe.to) + " item" })
                  : t("synthesis.materialsConsumed")}
              </Text>
            </View>
          )}

          {/* Warning */}
          <View style={{
            flexDirection: "row",
            alignItems: "flex-start",
            gap: BoxSpacing.sm,
            padding: BoxSpacing.md,
            borderRadius: BoxRadius.lg,
            backgroundColor: BoxSurfaces.elevated,
          }}>
            <Info size={bs(14)} color={BoxText.tertiary} />
            <Text style={[BoxTypography.caption, { flex: 1, color: BoxText.tertiary, lineHeight: bs(20) }]}>
              {t("synthesis.warning")}
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Sticky Synthesize Button */}
      <View style={{
        position: "absolute",
        bottom: 0, left: 0, right: 0,
        paddingHorizontal: BoxSpacing.lg,
        paddingTop: BoxSpacing.md,
        paddingBottom: BoxSpacing["3xl"],
        backgroundColor: BoxSurfaces.card,
        borderTopWidth: 1,
        borderTopColor: BoxBorders.default,
      }}>
        <BoxActionButton
          title={
            synthesizeMutation.isPending
              ? t("synthesis.synthesizing")
              : t("synthesis.synthesize", { current: selectedItems.length, required: recipe.count })
          }
          variant="primary"
          icon={<Zap size={bs(20)} color={selectedItems.length >= recipe.count ? BoxText.onGold : BoxText.disabled} />}
          disabled={selectedItems.length < recipe.count || synthesizeMutation.isPending}
          loading={synthesizeMutation.isPending}
          onPress={handleSynthesize}
        />
      </View>
    </SafeAreaView>
  );
}
