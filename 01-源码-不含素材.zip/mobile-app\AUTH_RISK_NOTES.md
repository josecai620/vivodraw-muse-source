# 登录/鉴权风险点记录（AUTH Risk Notes）

> 识别鉴权断联风险，不做跨模块重构。M-B4 批次产出。

---

## 一、Token 存取位置

| 存储 | 位置 | 说明 |
|------|------|------|
| **写入** | `store/auth.ts` → `setToken()` | 登录/注册成功后，`SecureStore.setItemAsync(TOKEN_KEY, token)` |
| **读取** | `store/auth.ts` → `hydrate()` | 启动时 `SecureStore.getItemAsync(TOKEN_KEY)` 恢复 |
| **注入** | `lib/http.ts` → request 拦截器 | `useAuthStore.getState().token` → `Authori-zation: Bearer ${token}` |
| **清除** | `store/auth.ts` → `logout()` | `SecureStore.deleteItemAsync(TOKEN_KEY)` |

- **TOKEN_KEY**：`"auth_token"`
- **USER_KEY**：`"auth_user"`（用户信息缓存，与 token 同生命周期）

---

## 二、401 与登录失效处理

| 触发 | 处理位置 | 行为 |
|------|----------|------|
| **HTTP 401** | `lib/http.ts` response 错误拦截器 | `useAuthStore.getState().logout()` |
| **status 410000/410001/410002** | `lib/http.ts` response 成功拦截器 | 同样调用 `logout()`，视为登录过期 |
| **logout()** | `store/auth.ts` | 清除 SecureStore 中 token/user，set state 为未登录 |

**注意**：logout 后无自动跳转登录页逻辑，需依赖各页面的 `isLoggedIn` 判断或路由守卫。

---

## 三、刷新逻辑

- **当前**：无 Token 刷新机制。Token 过期后直接登出，用户需重新登录。
- **风险**：若后端支持 refresh token，当前未接入，长会话可能频繁掉线。

---

## 四、已知风险

| 风险 | 等级 | 说明 |
|------|------|------|
| 游客模式 guestLogin | 中 | 使用固定 `guest_token`，后端可能不识别，部分接口会 401 |
| 无 refresh token | 中 | 长会话依赖单一 token，过期即登出 |
| Header 拼写 | 低 | `Authori-zation`（少一个 z），与后端约定一致，勿改 |
| hydrate 时机 | 低 | 若在 token 注入前发起请求，可能带空 token |

---

## 五、建议由主机处理的高风险项

1. **游客模式下线**：`store/auth.ts` 内 `guestLogin` 有 `TODO: 上线前删除游客模式`，建议正式环境禁用。
2. **refresh token 接入**：若后端支持，需在主机侧统一设计刷新流程与 401 重试。
3. **登出后跳转**：当前无全局「登出后跳转登录」的逻辑，可考虑在根 layout 或路由 guard 中处理。

---

## 六、不进行跨模块重构的说明

本文档仅记录现状与风险，不修改：
- 鉴权核心流程（login/register/logout）
- Token 存储介质（SecureStore）
- 401 处理策略（直接 logout）

如需调整，应由主机统一决策与实现。
