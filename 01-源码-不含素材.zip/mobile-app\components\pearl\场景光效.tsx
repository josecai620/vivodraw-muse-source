import React, { memo, useEffect, useRef, useState } from "react";
import { Animated, AppState, Easing, Platform, StyleSheet, View } from "react-native";

type PearlKey = "sand" | "white" | "pink" | "gold" | "black" | "aurora" | "living";
type Phase = "idle" | "submitting" | "selected" | "all";

export type OceanEffectsProps = {
  reducedMotion: boolean;
  phase: Phase;
  pearlKey?: PearlKey | null;
};

const COLORS: Record<PearlKey, string> = {
  sand: "232,210,168", white: "196,239,255", pink: "255,175,220", gold: "255,224,139",
  black: "180,175,255", aurora: "127,208,200", living: "224,122,154",
};
const TAU = Math.PI * 2;
const seed = (n: number) => { const v = Math.sin(n * 127.1 + 311.7) * 43758.5453; return v - Math.floor(v); };

/** 一张有预算的透明画布：光束、水底折射、远近气泡共用同一个时钟。 */
export const OceanEffects = memo(function OceanEffects(props: OceanEffectsProps) {
  return Platform.OS === "web" ? <WebOceanEffects {...props} /> : <NativeOceanEffects {...props} />;
});

function WebOceanEffects({ reducedMotion, phase, pearlKey }: OceanEffectsProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cue = useRef({ phase, pearlKey, started: -10000 });
  const sceneTime = useRef(0);

  useEffect(() => {
    if (phase === "selected" && cue.current.phase !== "selected") cue.current.started = sceneTime.current;
    cue.current.phase = phase;
    cue.current.pearlKey = pearlKey;
  }, [phase, pearlKey]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || typeof window === "undefined") return;
    const ctx = canvas.getContext("2d", { alpha: true });
    if (!ctx) return;
    let width = 1, height = 1, scale = 1, frame = 0, stopped = false;
    let intersecting = true, lastFrame = 0, previousTick = 0;
    let elapsed = sceneTime.current;
    let quality = 1, sampleStarted = 0, renderCount = 0, rafCount = 0;
    let costs: number[] = [];
    // 每帧只画一张低分辨率折射层后放大；画布总像素封顶，避免高 DPR 手机浪费填充率。
    const caustic = document.createElement("canvas");
    caustic.width = 420; caustic.height = 360;
    const water = caustic.getContext("2d");
    const particles = Array.from({ length: 35 }, (_, index) => ({
      x: seed(index + 1), y: seed(index + 91), radius: 0.7 + seed(index + 183) * 2.1,
      speed: 0.009 + seed(index + 71) * 0.016, offset: seed(index + 53) * TAU,
    }));

    const drawWater = (time: number) => {
      if (!water) return;
      const cw = caustic.width, ch = caustic.height;
      water.clearRect(0, 0, cw, ch);
      water.lineJoin = "round";
      // 共享顶点的非规则水纹网；控制点随不同频率漂移，边缘持续连贯，不做闪烁贴图。
      const columns = quality === 1 ? 9 : 7, rows = quality === 1 ? 8 : 6;
      const points: { x: number; y: number }[][] = [];
      for (let row = 0; row <= rows; row++) {
        points[row] = [];
        for (let column = 0; column <= columns; column++) {
          const key = row * 41 + column;
          points[row][column] = {
            x: column * (cw / (columns - 1)) - 28 + (row % 2) * 16 + Math.sin(time * 0.44 + key * 0.69) * 12,
            y: row * (ch / (rows - 1)) - 24 + Math.sin(time * 0.31 + key * 1.73) * 13,
          };
        }
      }
      water.beginPath();
      for (let row = 0; row < rows; row++) {
        for (let column = 0; column < columns; column++) {
          const a = points[row][column], b = points[row][column + 1], c = points[row + 1][column];
          const bend = Math.sin(time * 0.4 + row * 1.7 + column * 0.8) * 9;
          water.moveTo(a.x, a.y);
          water.quadraticCurveTo((a.x + b.x) / 2, (a.y + b.y) / 2 + bend, b.x, b.y);
          water.moveTo(a.x, a.y);
          water.quadraticCurveTo((a.x + c.x) / 2 + bend, (a.y + c.y) / 2, c.x, c.y);
        }
      }
      water.lineWidth = 8;
      water.strokeStyle = "rgba(142,242,235,0.045)"; water.stroke();
      water.lineWidth = 3;
      water.strokeStyle = "rgba(204,255,223,0.13)"; water.stroke();
      water.lineWidth = 0.9;
      water.strokeStyle = "rgba(248,255,201,0.29)"; water.stroke();
      water.globalCompositeOperation = "destination-in";
      const fade = water.createLinearGradient(0, 0, 0, ch);
      fade.addColorStop(0, "transparent"); fade.addColorStop(0.26, "rgba(0,0,0,0.22)");
      fade.addColorStop(0.68, "rgba(0,0,0,0.8)"); fade.addColorStop(1, "rgba(0,0,0,0.24)");
      water.fillStyle = fade; water.fillRect(0, 0, cw, ch);
      water.globalCompositeOperation = "source-over";
    };

    const draw = (time: number) => {
      ctx.setTransform(scale, 0, 0, scale, 0, 0);
      ctx.clearRect(0, 0, width, height);
      ctx.globalCompositeOperation = "screen";
      // 太阳在画面上方；光束末端柔和消散，中央文字区域保持安静。
      for (let index = 0; index < 6; index++) {
        const originX = width * (0.15 + index * 0.032);
        const drift = Math.sin(time * 0.13 + index * 1.23) * width * 0.075;
        const reachX = width * (0.16 + index * 0.23) + drift;
        const gradient = ctx.createLinearGradient(originX, 0, reachX, height * 0.82);
        const alpha = 0.085 + Math.sin(time * 0.23 + index) * 0.018;
        gradient.addColorStop(0, `rgba(255,251,202,${alpha})`);
        gradient.addColorStop(0.48, `rgba(204,255,235,${alpha * 0.43})`);
        gradient.addColorStop(1, "rgba(163,235,231,0)");
        ctx.fillStyle = gradient;
        ctx.beginPath(); ctx.moveTo(originX - 9, -20); ctx.lineTo(originX + 11, -20);
        ctx.lineTo(reachX + width * 0.08, height * 0.86); ctx.lineTo(reachX - width * 0.12, height * 0.86);
        ctx.closePath(); ctx.fill();
      }
      drawWater(time);
      ctx.save();
      ctx.globalAlpha = 0.88;
      ctx.translate(-width * 0.08 + Math.sin(time * 0.12) * 12, height * 0.30);
      ctx.transform(1, 0.04, -0.12, 1, 0, 0);
      ctx.drawImage(caustic, 0, 0, width * 1.2, height * 0.72);
      ctx.restore();

      // 漂浮尘点轻小而稀疏；大气泡只出现在屏幕两侧，避免遮挡珍珠。
      for (const p of particles.slice(0, quality === 1 ? 35 : 22)) {
        const py = ((p.y - time * p.speed * 0.42) % 1 + 1) % 1;
        const x = p.x * width + Math.sin(time * 0.32 + p.offset) * 11;
        const y = py * height;
        const quiet = x > width * 0.18 && x < width * 0.82 && y < height * 0.35 ? 0.25 : 1;
        const alpha = (0.12 + (Math.sin(time * 0.57 + p.offset) + 1) * 0.095) * quiet;
        ctx.fillStyle = `rgba(222,255,231,${alpha})`;
        ctx.beginPath(); ctx.arc(x, y, p.radius, 0, TAU); ctx.fill();
        if (p.radius > 2.2) {
          ctx.fillStyle = `rgba(249,255,211,${alpha * 0.65})`;
          ctx.fillRect(x - 3.7, y - 0.5, 7.4, 1); ctx.fillRect(x - 0.5, y - 3.7, 1, 7.4);
        }
      }
      for (let index = 0; index < 9; index++) {
        const py = ((seed(index + 237) - time * (0.012 + seed(index + 713) * 0.009)) % 1 + 1) % 1;
        const edge = index % 2 === 0 ? 0.055 : 0.92;
        const x = width * (edge + Math.sin(time * 0.25 + index) * 0.025);
        const y = height * py, radius = 3 + seed(index + 719) * 8;
        ctx.strokeStyle = "rgba(210,253,252,0.23)"; ctx.lineWidth = 0.85;
        ctx.beginPath(); ctx.arc(x, y, radius, 0, TAU); ctx.stroke();
        ctx.strokeStyle = "rgba(247,255,224,0.5)";
        ctx.beginPath(); ctx.arc(x - radius * 0.08, y - radius * 0.1, radius * 0.69, Math.PI * 1.13, Math.PI * 1.6); ctx.stroke();
      }

      const since = time - cue.current.started;
      if (!reducedMotion && cue.current.pearlKey && since >= 0 && since < 1.8) {
        const progress = Math.min(1, since / 1.8);
        const eased = 1 - Math.pow(1 - progress, 3);
        const radius = Math.max(1, width * (0.12 + eased * 0.92));
        const centerY = height * 0.47;
        const pulse = ctx.createRadialGradient(width / 2, centerY, 0, width / 2, centerY, radius);
        const color = COLORS[cue.current.pearlKey];
        const opacity = Math.sin(progress * Math.PI) * 0.11;
        pulse.addColorStop(0, `rgba(${color},0)`);
        pulse.addColorStop(0.52, `rgba(${color},${opacity * 0.22})`);
        pulse.addColorStop(0.80, `rgba(${color},${opacity})`);
        pulse.addColorStop(1, `rgba(${color},0)`);
        ctx.fillStyle = pulse; ctx.fillRect(0, 0, width, height);
      }
      ctx.globalCompositeOperation = "source-over";
    };

    const shouldAnimate = () => !stopped && !reducedMotion && intersecting && !document.hidden;
    const tick = (now: number) => {
      if (!shouldAnimate()) { frame = 0; previousTick = 0; return; }
      if (!sampleStarted) sampleStarted = now;
      rafCount++;
      if (previousTick) elapsed += Math.min(0.08, (now - previousTick) / 1000);
      previousTick = now;
      // 30 fps 环境层与 60 fps 贝壳/珍珠动效分开预算；缓慢水纹无需占满主线程。
      if (!lastFrame || now - lastFrame >= 1000 / 30 - 1) {
        const drawStarted = performance.now();
        sceneTime.current = elapsed; draw(elapsed); lastFrame = now;
        costs.push(performance.now() - drawStarted); renderCount++;
      }
      if (now - sampleStarted >= 2000) {
        const seconds = (now - sampleStarted) / 1000;
        const meanCost = costs.reduce((sum, cost) => sum + cost, 0) / Math.max(1, costs.length);
        const orderedCosts = costs.slice().sort((a, b) => a - b);
        canvas.dataset.oceanFps = (renderCount / seconds).toFixed(1);
        canvas.dataset.oceanRafFps = (rafCount / seconds).toFixed(1);
        canvas.dataset.oceanFrameMs = meanCost.toFixed(2);
        canvas.dataset.oceanP95FrameMs = (orderedCosts[Math.floor(orderedCosts.length * 0.95)] ?? 0).toFixed(2);
        // 连续两秒的场景绘制偏贵时缩小分辨率与网格；不反复升降档，不影响开蚌时序。
        if (quality === 1 && meanCost > 6) { quality = 0.72; caustic.width = 300; caustic.height = 258; resize(false); }
        canvas.dataset.oceanQuality = quality === 1 ? "high" : "balanced";
        canvas.dataset.oceanParticles = String((quality === 1 ? 35 : 22) + 9);
        sampleStarted = now; renderCount = 0; rafCount = 0; costs = [];
      }
      frame = window.requestAnimationFrame(tick);
    };
    const sync = () => {
      if (frame) { window.cancelAnimationFrame(frame); frame = 0; }
      previousTick = 0; lastFrame = 0;
      sampleStarted = 0; renderCount = 0; rafCount = 0; costs = [];
      canvas.dataset.oceanMotion = reducedMotion ? "reduced" : shouldAnimate() ? "running" : "paused";
      if (!shouldAnimate()) { canvas.dataset.oceanFps = "0"; canvas.dataset.oceanRafFps = "0"; }
      if (shouldAnimate()) frame = window.requestAnimationFrame(tick);
    };
    const resize = (restart = true) => {
      const bounds = canvas.getBoundingClientRect();
      width = Math.max(1, bounds.width); height = Math.max(1, bounds.height);
      scale = Math.min(window.devicePixelRatio || 1, 1.5, Math.sqrt(760000 / (width * height))) * quality;
      canvas.width = Math.max(1, Math.floor(width * scale));
      canvas.height = Math.max(1, Math.floor(height * scale));
      canvas.dataset.oceanPixelCount = String(canvas.width * canvas.height);
      canvas.dataset.oceanDpr = scale.toFixed(2);
      draw(reducedMotion ? 0 : elapsed);
      if (restart) sync();
    };
    const onResize = () => resize();
    const resizeObserver = typeof ResizeObserver === "undefined" ? null : new ResizeObserver(onResize);
    resizeObserver?.observe(canvas);
    const intersectionObserver = typeof IntersectionObserver === "undefined" ? null : new IntersectionObserver((entries) => {
      intersecting = entries[0]?.isIntersecting ?? true; sync();
    });
    intersectionObserver?.observe(canvas);
    document.addEventListener("visibilitychange", sync);
    window.addEventListener("resize", onResize);
    resize();
    return () => {
      stopped = true;
      if (frame) window.cancelAnimationFrame(frame);
      resizeObserver?.disconnect(); intersectionObserver?.disconnect();
      document.removeEventListener("visibilitychange", sync); window.removeEventListener("resize", onResize);
      caustic.width = 0; caustic.height = 0;
    };
  }, [reducedMotion]);

  return <View pointerEvents="none" accessible={false} accessibilityElementsHidden importantForAccessibility="no-hide-descendants" style={styles.layer}>
    <canvas ref={canvasRef} aria-hidden="true" data-ocean-renderer="canvas2d" data-ocean-quality="high" data-ocean-particles="44" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none", contain: "strict" }} />
  </View>;
}

/** 原生端保留同一色彩、层次与节奏，环境变换全部交给 native driver。 */
function NativeOceanEffects({ reducedMotion, phase, pearlKey }: OceanEffectsProps) {
  const drift = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(0)).current;
  const [active, setActive] = useState(AppState.currentState === "active");
  useEffect(() => {
    const subscription = AppState.addEventListener("change", (state) => setActive(state === "active"));
    return () => subscription.remove();
  }, []);
  useEffect(() => {
    if (reducedMotion || !active) { drift.stopAnimation(); return; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(drift, { toValue: 1, duration: 6500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(drift, { toValue: 0, duration: 6500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start(); return () => loop.stop();
  }, [active, reducedMotion, drift]);
  useEffect(() => {
    pulse.stopAnimation(); pulse.setValue(0);
    if (phase !== "selected" || !pearlKey || reducedMotion || !active) return;
    const animation = Animated.timing(pulse, { toValue: 1, duration: 1500, easing: Easing.out(Easing.cubic), useNativeDriver: true });
    animation.start(); return () => animation.stop();
  }, [phase, pearlKey, pulse, reducedMotion, active]);
  return <View pointerEvents="none" accessible={false} accessibilityElementsHidden importantForAccessibility="no-hide-descendants" style={styles.layer}>
    {[0, 1, 2].map((index) => <Animated.View key={index} style={[styles.nativeRay, { left: `${12 + index * 27}%`, opacity: drift.interpolate({ inputRange: [0, 1], outputRange: [0.035, 0.09] }), transform: [{ rotate: `${-24 + index * 13}deg` }, { translateX: drift.interpolate({ inputRange: [0, 1], outputRange: [-9, 12] }) }] }]} />)}
    {[0, 1, 2, 3, 4, 5, 6].map((index) => <Animated.View key={index} style={[styles.nativeBubble, { top: `${20 + index * 11}%`, left: index % 2 ? "93%" : "5%", width: 5 + index, height: 5 + index, transform: [{ translateY: drift.interpolate({ inputRange: [0, 1], outputRange: [7, -16 - index * 2] }) }] }]} />)}
    {pearlKey && <Animated.View style={[styles.nativePulse, { borderColor: `rgba(${COLORS[pearlKey]},0.7)`, opacity: pulse.interpolate({ inputRange: [0, 0.2, 1], outputRange: [0, 0.2, 0] }), transform: [{ scale: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.4, 2.5] }) }] }]} />}
  </View>;
}

const styles = StyleSheet.create({
  layer: { ...StyleSheet.absoluteFillObject, overflow: "hidden" },
  nativeRay: { position: "absolute", top: -150, width: 100, height: "90%", backgroundColor: "#f4ffe1", borderBottomLeftRadius: 90, borderBottomRightRadius: 90 },
  nativeBubble: { position: "absolute", borderWidth: 1, borderColor: "rgba(225,255,240,0.38)", borderRadius: 30, backgroundColor: "rgba(211,255,252,0.025)" },
  nativePulse: { position: "absolute", width: 330, height: 330, borderRadius: 165, borderWidth: 24, top: "28%", left: "10%" },
});
