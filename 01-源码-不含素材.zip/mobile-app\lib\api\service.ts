import { http } from "@/lib/http";
import { API_BASE_URL, API_ENDPOINTS } from "@/constants/api";
import { useAuthStore } from "@/store/auth";

type Env<T> = { status: number; msg: string; data: T };

export type HumanServiceMessage = {
  id: number;
  uid: number;
  to_uid: number;
  msn: string;
  msn_type: number;  // 1=text 2=emoji 3=image
  add_time: number;  // unix timestamp
  _add_time?: string;
};

export type HumanServiceRecord = {
  serviceList: HumanServiceMessage[];
  uid: number;       // assigned CS uid
};

export type SendMessageResult = {
  ok: boolean;
  message_id: number;
  to_uid: number;
  add_time: number;
};

export async function getServiceRecord(params?: { page?: number; limit?: number }): Promise<HumanServiceRecord> {
  const res = await http.get<unknown, Env<HumanServiceRecord>>(
    API_ENDPOINTS.user.service.record,
    { params },
  );
  return res.data;
}

export async function sendServiceMessage(content: string): Promise<SendMessageResult> {
  const res = await http.post<unknown, Env<SendMessageResult>>(
    API_ENDPOINTS.user.service.send,
    { content }
  );
  return res.data;
}

export function getServiceList() {
  return http.get(API_ENDPOINTS.user.service.list);
}

export function submitServiceFeedback(data: { content: string; type?: string; rela_name?: string; phone?: string; images?: string[] }) {
  return http.post(API_ENDPOINTS.user.service.feedback, data);
}

export function getFeedbackInfo() {
  return http.get(API_ENDPOINTS.user.service.getFeedbackInfo);
}

export function getFeedbackType() {
  return http.get(API_ENDPOINTS.user.service.getFeedbackType);
}

export type SupportLanguage = "zh" | "en";
export type SupportMessage = {
  id: number | string;
  role: "user" | "assistant" | "human";
  content: string;
  kind: "text" | "image" | "feedback";
  created_at: number | string;
  attachment_id?: string;
  navigation?: { id: string; path?: string; label?: string }[];
};
export type SupportSession = {
  available: boolean;
  mode: "ai" | "pending" | "human";
  messages: SupportMessage[];
  memory: { enabled: boolean; language: SupportLanguage };
};
export type SupportSend = { content: string; client_request_id: string; language: SupportLanguage; kind: "text" | "image" | "feedback"; attachment_id?: string };

// 该 ID 仅用于幂等，不是鉴权凭据；重试必须复用同一个 ID。
let requestSequence = 0;
export function createSupportRequestId(): string {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  requestSequence += 1;
  return `support-${Date.now().toString(36)}-${requestSequence.toString(36)}-${Math.random().toString(36).slice(2, 14)}`;
}
export async function getSupportSession(): Promise<SupportSession> {
  const res = await http.get<unknown, Env<SupportSession>>("/api/support/session");
  return res.data;
}
export async function sendSupportMessage(data: SupportSend): Promise<SupportSession> {
  const res = await http.post<unknown, Env<SupportSession>>("/api/support/messages", data, { timeout: 45000 });
  return res.data;
}
export async function requestSupportHandoff(data: { client_request_id: string; language: SupportLanguage }): Promise<SupportSession> {
  const res = await http.post<unknown, Env<SupportSession>>("/api/support/handoff", data);
  return res.data;
}
export async function updateSupportMemory(data: { enabled: boolean; language: SupportLanguage; forget?: boolean }): Promise<SupportSession> {
  const res = await http.post<unknown, Env<SupportSession>>("/api/support/memory", data);
  return res.data;
}
export const SUPPORT_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
export const SUPPORT_IMAGE_MAX_BYTES = 5 * 1024 * 1024;
export async function uploadSupportImage(file: Blob | { uri: string; name: string; type: string }, name: string): Promise<string> {
  const data = new FormData();
  if (typeof Blob !== "undefined" && file instanceof Blob) data.append("file", file, name);
  else data.append("file", file as unknown as Blob);
  const res = await http.post<unknown, Env<{ attachment_id: string }>>("/api/support/images", data);
  if (!/^[a-zA-Z0-9_-]{1,128}$/.test(res.data.attachment_id)) throw new Error("Image unavailable");
  return res.data.attachment_id;
}
export function supportImageSource(id: string): { uri: string; headers: Record<string, string> } {
  if (!/^[a-zA-Z0-9_-]{1,128}$/.test(id)) throw new Error("Image unavailable");
  const token = useAuthStore.getState().token;
  if (!token) throw new Error("Authentication required");
  return { uri: `${API_BASE_URL.replace(/\/$/, "")}/api/support/images/${encodeURIComponent(id)}`, headers: { Authorization: `Bearer ${token}`, "X-Client": "mobile-app" } };
}
// 不能使用公开 URL 或把 token 拼进 URL；仅显示鉴权后获得的三种位图。
export async function getSupportImageBlob(id: string, signal: AbortSignal): Promise<Blob> {
  const source = supportImageSource(id);
  const res = await fetch(source.uri, { headers: source.headers, signal, redirect: "error", cache: "no-store" });
  const type = (res.headers.get("content-type") || "").split(";")[0].toLowerCase();
  if (!res.ok || !SUPPORT_IMAGE_TYPES.includes(type)) throw new Error("Image unavailable");
  const blob = await res.blob();
  if (blob.size > SUPPORT_IMAGE_MAX_BYTES) throw new Error("Image unavailable");
  return blob;
}
