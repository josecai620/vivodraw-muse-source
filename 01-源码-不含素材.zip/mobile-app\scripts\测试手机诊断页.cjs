'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const template = fs.readFileSync(path.join(__dirname, '../diagnostics/手机访问检测.html'), 'utf8');
const code = template.match(/<script id="diagnostic-script">([\s\S]*?)<\/script>/)[1];
const body = 'globalThis.mustNeverExecute = true;';
const scripts = Array.from({length: 6}, (_, i) => ({label: '脚本' + i, url: '/_expo/static/js/web/test-' + i + '.js?v=123abc', bytes: Buffer.byteLength(body), sha256: crypto.createHash('sha256').update(body).digest('hex')}));
const home = scripts.map(s => '<script src="' + s.url + '"></script>').join('');
class Element {
  constructor() { this.children = []; this.handlers = {}; this.textContent = ''; this.value = ''; }
  appendChild(child) { this.children.push(child); }
  querySelector() { return this.children[1]; }
  addEventListener(name, fn) { this.handlers[name] = fn; }
  focus() {}
  select() {}
}
function setup(mode) {
  const elements = Object.fromEntries(['start','stop','status','result','resources','copy','hint'].map(id => [id,new Element()]));
  const calls = [];
  const manifest = {release: '20260925_005500', scripts: scripts.map(s => ({...s}))};
  if (mode === 'syntax') {
    manifest.scripts[0].bytes = 6;
    manifest.scripts[0].sha256 = crypto.createHash('sha256').update('var =;').digest('hex');
  }
  const sandbox = {
    document: {getElementById: id => elements[id], createElement: () => new Element()},
    navigator: {userAgent: 'Test iPhone', onLine: true},
    crypto: crypto.webcrypto, Promise, AbortController, TextDecoder, Uint8Array, Date,
    setInterval: () => 1, clearInterval() {},
    setTimeout: mode === 'timeout' ? fn => setTimeout(fn, 4) : setTimeout,
    clearTimeout,
    addEventListener() {},
    fetch: async (url, options) => {
      calls.push({url, options});
      assert.equal(options.credentials, 'omit');
      assert.equal(options.method, 'GET');
      assert.equal(options.redirect, 'error');
      assert.equal(options.cache, 'no-store');
      assert.ok(url === '/' || scripts.some(s => s.url === url));
      if (mode === 'timeout' || mode === 'stop') {
        return new Promise((resolve, reject) => options.signal.addEventListener('abort', () => reject(new Error('aborted')), {once:true}));
      }
      let content = url === '/' ? home : body;
      if (mode === 'version' && url === '/') content = '<script src="/_expo/static/js/web/changed.js"></script>';
      if (mode === 'query-version' && url === '/') content = home.replace('v=123abc', 'v=456def');
      if (mode === 'syntax' && url === scripts[0].url) content = 'var =;';
      if (mode === 'truncated' && url !== '/') content = 'var x';
      if (mode === 'hash' && url !== '/') content = body.replace('true','null');
      if (mode === 'large' && url !== '/') content = 'a'.repeat(8*1024*1024+1);
      const bytes = Buffer.from(content);
      return {
        ok: mode !== 'http', status: mode === 'http' ? 503 : 200,
        headers: {get: () => url === '/' || mode === 'html' ? 'text/html' : 'application/javascript'},
        body: mode === 'stream-error' && url !== '/' ? {getReader: () => ({read: async () => {throw new Error('connection lost');}})} : null,
        arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.length)
      };
    }
  };
  sandbox.window = sandbox;
  // 任何原站存储/账号读取都令测试立即失败。
  for (const name of ['localStorage','sessionStorage','indexedDB']) Object.defineProperty(sandbox, name, {get() {throw new Error('禁止存储访问');}});
  Object.defineProperty(sandbox.document, 'cookie', {get() {throw new Error('禁止cookie读取');}});
  vm.runInNewContext(code.replace('__VIVO_DIAGNOSTIC_MANIFEST__', JSON.stringify(manifest)), sandbox);
  return {elements, calls, sandbox};
}
async function complete(fixture) {
  fixture.elements.start.handlers.click();
  for (let i=0; i<300; i++) {
    if (fixture.elements.start.disabled === false) return fixture.elements.result.value;
    await new Promise(resolve => setTimeout(resolve, 5));
  }
  throw new Error('检测未结束');
}
test('完成六脚本检测；只GET白名单、无凭证、不执行脚本、不读取存储', async () => {
  const fixture = setup();
  assert.match(await complete(fixture), /6\/6项通过/);
  assert.equal(fixture.calls.length,7);
  assert.equal(fixture.sandbox.mustNeverExecute,undefined);
});
for (const [mode, expected] of [['http','HTTP 503'],['html','返回类型不是JavaScript'],['version','首页版本已变化'],['query-version','首页版本已变化'],['syntax','语法检查失败'],['hash','SHA256不符'],['truncated','内容长度不符'],['stream-error','connection lost'],['large','超出8MB上限'],['timeout','60秒超时']]) {
  test(mode + '正确给出失败，而非误报恢复', async () => {assert.ok((await complete(setup(mode))).includes(expected));});
}
test('停止请求，不再调度后续脚本', async () => {
  const fixture = setup('stop');
  const pending = complete(fixture);
  fixture.elements.stop.handlers.click();
  assert.match(await pending, /用户停止/);
  assert.equal(fixture.calls.length,1);
});
test('缺失能力明确显示；复制失败仍可手动复制', () => {
  const fixture = setup();
  fixture.sandbox.crypto = null;
  fixture.elements.start.handlers.click();
  assert.match(fixture.elements.result.value, /缺少浏览器能力/);
  fixture.elements.copy.handlers.click();
  assert.match(fixture.elements.hint.textContent, /长按/);
});
test('重测可用；并发点击不重复启动', async () => {
  const fixture = setup();
  const first = complete(fixture); fixture.elements.start.handlers.click(); await first;
  assert.equal(fixture.calls.length,7);
  await complete(fixture); assert.equal(fixture.calls.length,14);
});
test('页面无外部依赖，CSP禁止图像/表单等，明确说明测量限制', () => {
  assert.ok(!/<script[^>]+src=|<iframe|<img|<link[^>]+href=/.test(template));
  assert.match(template, /default-src 'none'/);
  assert.match(template, /全部通过也不能说明首页故障已解决/);
  assert.match(template, /不运行商城/);
});
