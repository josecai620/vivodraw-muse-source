/**
 * 盲盒发货页 - Select items, pick saved address, create shipping order
 */
import React, { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Pressable,
  ScrollView,
  Text,
  View,
  ActivityIndicator,
  Alert,
} from "react-native";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useFocusEffect } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import {
  Check,
  MapPin,
  Truck,
  Package,
  ChevronRight,
} from "lucide-react-native";
import {
  BoxHeader,
  RarityBadge,
  BoxActionButton,
  BoxEmptyState,
  BoxProgressBar,
  BoxTabBar,
  CountdownTimer,
} from "@/components/box";
import {
  BoxSurfaces,
  BoxAccent,
  BoxText,
  BoxBorders,
  BoxGradients,
  BoxTypography,
  BoxSpacing,
  BoxRadius,
  BoxShadows,
  getRarityTier,
  bs,
} from "@/lib/boxTheme";
import { useGetSendAll, useSendCreateOrder, useSendPay } from "@/hooks";
import { getAddressList, type Address } from "@/lib/api/address";

interface ShipItem {
  id: number;
  name: string;
  image: string;
  num: number;
  freight_price: number;
}

export default function BoxShippingScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<number>(0);

  const { data: sendAllData, isLoading } = useGetSendAll();
  const createOrder = useSendCreateOrder();
  const payShipping = useSendPay();

  const { data: addressData, refetch: refetchAddress } = useQuery({
    queryKey: ["addressList"],
    queryFn: getAddressList,
  });

  const addresses = useMemo(() => {
    const list =
      (addressData as any)?.data ??
      (addressData as any)?.list ??
      addressData ??
      [];
    return Array.isArray(list) ? (list as Address[]) : [];
  }, [addressData]);

  useFocusEffect(
    React.useCallback(() => {
      refetchAddress();
    }, [refetchAddress])
  );

  useEffect(() => {
    if (selectedAddressId > 0) return;
    const defaultAddr = addresses.find((a) => Number(a.is_default) === 1);
    if (defaultAddr?.id) setSelectedAddressId(defaultAddr.id);
    else if (addresses[0]?.id) setSelectedAddressId(addresses[0].id);
  }, [addresses, selectedAddressId]);

  const items: ShipItem[] = Array.isArray(sendAllData)
    ? sendAllData.map((item: any) => ({
        id: item.id || item.product_id,
        name:
          item.name ||
          item.product_name ||
          item.store_name ||
          t("shipping.fallbackItem"),
        image: item.image || item.product_image || "",
        num: item.num || item.count || 1,
        freight_price: item.freight_money || item.postage || 0,
      }))
    : [];

  const toggleItem = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const selectedItems = items.filter((i) => selectedIds.includes(i.id));
  const totalFreight = selectedItems.reduce(
    (sum, i) => sum + i.freight_price * i.num,
    0
  );

  const selectedAddress = addresses.find((a) => a.id === selectedAddressId);

  const handleSubmit = async () => {
    if (selectedIds.length === 0) {
      Alert.alert(t("common.notice"), t("shipping.alertSelectItems"));
      return;
    }
    if (!selectedAddressId) {
      Alert.alert(t("common.notice"), t("shipping.alertSelectAddress"));
      return;
    }

    try {
      const arr = selectedItems.map((item) => ({
        id: item.id,
        name: item.name,
        image: item.image,
        num: item.num,
      }));
      const res = await createOrder.mutateAsync({
        arr,
        address_id: selectedAddressId,
      });
      const orderId =
        (res as any)?.data?.order_id || (res as any)?.data?.id;
      if (orderId && totalFreight > 0) {
        await payShipping.mutateAsync({ id: orderId, payType: "yue" });
      }
      Alert.alert(t("common.success"), t("shipping.alertSuccess"), [
        {
          text: t("shipping.viewOrders"),
          onPress: () => router.push("/box/orders"),
        },
        { text: t("common.back"), onPress: () => router.back() },
      ]);
    } catch (err: any) {
      Alert.alert(
        t("common.failed"),
        err?.message || t("shipping.alertFail")
      );
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("shipping.title")} showThemeToggle={false} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View
          style={{
            padding: BoxSpacing.lg,
            paddingBottom: bs(140),
          }}
        >
          {/* Section: Select Items */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: BoxSpacing.sm,
              marginBottom: BoxSpacing.md,
            }}
          >
            <View
              style={{
                width: bs(32),
                height: bs(32),
                borderRadius: BoxRadius.sm,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: BoxAccent.purpleMuted,
              }}
            >
              <Package size={bs(16)} color={BoxAccent.purple} />
            </View>
            <Text style={[BoxTypography.h3, { color: BoxText.primary }]}>
              {t("shipping.selectItems")}
            </Text>
          </View>

          {isLoading ? (
            <View
              style={{
                alignItems: "center",
                paddingVertical: BoxSpacing["4xl"],
              }}
            >
              <ActivityIndicator size="large" color={BoxAccent.gold} />
            </View>
          ) : items.length === 0 ? (
            <BoxEmptyState
              icon={<Package size={bs(40)} color={BoxText.tertiary} />}
              title={t("shipping.noItems")}
            />
          ) : (
            items.map((item) => {
              const selected = selectedIds.includes(item.id);
              return (
                <Pressable
                  key={item.id}
                  onPress={() => toggleItem(item.id)}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    padding: BoxSpacing.lg,
                    borderRadius: BoxRadius.xl,
                    marginBottom: BoxSpacing.sm,
                    backgroundColor: BoxSurfaces.card,
                    borderWidth: 1.5,
                    borderColor: selected
                      ? BoxAccent.gold
                      : BoxBorders.default,
                    ...(selected ? BoxShadows.glow(BoxAccent.goldDark) : {}),
                  }}
                >
                  <View
                    style={{
                      width: bs(24),
                      height: bs(24),
                      borderRadius: BoxRadius.sm,
                      alignItems: "center",
                      justifyContent: "center",
                      marginRight: BoxSpacing.md,
                      backgroundColor: selected
                        ? BoxAccent.gold
                        : BoxSurfaces.deep,
                      borderWidth: selected ? 0 : 1,
                      borderColor: BoxBorders.default,
                    }}
                  >
                    {selected && (
                      <Check size={bs(14)} color={BoxText.onGold} />
                    )}
                  </View>
                  <View
                    style={{
                      width: bs(48),
                      height: bs(48),
                      borderRadius: BoxRadius.lg,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: BoxSurfaces.deep,
                    }}
                  >
                    {item.image && /^https?:\/\//.test(item.image) ? (
                      <Image
                        source={{ uri: item.image }}
                        style={{
                          width: bs(40),
                          height: bs(40),
                          borderRadius: BoxRadius.md,
                        }}
                        contentFit="cover"
                      />
                    ) : (
                      <Package size={bs(20)} color={BoxAccent.gold} strokeWidth={1.6} />
                    )}
                  </View>
                  <View style={{ flex: 1, marginLeft: BoxSpacing.md }}>
                    <Text
                      style={[
                        BoxTypography.bodyBold,
                        { color: BoxText.primary },
                      ]}
                    >
                      {item.name}
                    </Text>
                    <Text
                      style={[
                        BoxTypography.caption,
                        {
                          color: BoxText.tertiary,
                          marginTop: BoxSpacing.xs,
                        },
                      ]}
                    >
                      {t("shipping.freight", {
                        count: item.num,
                        fee: item.freight_price,
                      })}
                    </Text>
                  </View>
                </Pressable>
              );
            })
          )}

          {/* Section: Address Selection */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: BoxSpacing.sm,
              marginTop: BoxSpacing["2xl"],
              marginBottom: BoxSpacing.md,
            }}
          >
            <View
              style={{
                width: bs(32),
                height: bs(32),
                borderRadius: BoxRadius.sm,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: BoxAccent.goldDim,
              }}
            >
              <MapPin size={bs(16)} color={BoxAccent.gold} />
            </View>
            <Text style={[BoxTypography.h3, { color: BoxText.primary }]}>
              {t("shipping.address")}
            </Text>
          </View>

          {addresses.length > 0 ? (
            <View>
              {addresses.map((addr) => {
                const isActive = addr.id === selectedAddressId;
                return (
                  <Pressable
                    key={addr.id}
                    onPress={() => setSelectedAddressId(addr.id)}
                    style={{
                      borderRadius: BoxRadius.xl,
                      padding: BoxSpacing.lg,
                      marginBottom: BoxSpacing.sm,
                      flexDirection: "row",
                      alignItems: "center",
                      backgroundColor: BoxSurfaces.card,
                      borderWidth: 1.5,
                      borderColor: isActive
                        ? BoxAccent.gold
                        : BoxBorders.default,
                    }}
                  >
                    <View
                      style={{
                        width: bs(24),
                        height: bs(24),
                        borderRadius: BoxRadius.full,
                        alignItems: "center",
                        justifyContent: "center",
                        marginRight: BoxSpacing.md,
                        backgroundColor: isActive
                          ? BoxAccent.gold
                          : BoxSurfaces.deep,
                        borderWidth: isActive ? 0 : 1,
                        borderColor: BoxBorders.default,
                      }}
                    >
                      {isActive && (
                        <Check size={bs(12)} color={BoxText.onGold} />
                      )}
                    </View>
                    <View style={{ flex: 1 }}>
                      <View
                        style={{
                          flexDirection: "row",
                          alignItems: "center",
                          gap: BoxSpacing.sm,
                        }}
                      >
                        <Text
                          style={[
                            BoxTypography.bodyBold,
                            { color: BoxText.primary },
                          ]}
                        >
                          {addr.real_name}
                        </Text>
                        <Text
                          style={[
                            BoxTypography.body,
                            { color: BoxText.secondary },
                          ]}
                        >
                          {addr.phone}
                        </Text>
                        {Number(addr.is_default) === 1 && (
                          <View
                            style={{
                              paddingHorizontal: BoxSpacing.xs,
                              paddingVertical: 2,
                              borderRadius: BoxRadius.sm,
                              backgroundColor: BoxAccent.goldDim,
                              borderWidth: 1,
                              borderColor: BoxAccent.goldBorder,
                            }}
                          >
                            <Text
                              style={[
                                BoxTypography.micro,
                                { color: BoxAccent.gold },
                              ]}
                            >
                              {t("shipping.default")}
                            </Text>
                          </View>
                        )}
                      </View>
                      <Text
                        style={[
                          BoxTypography.caption,
                          {
                            color: BoxText.tertiary,
                            marginTop: BoxSpacing.xs,
                          },
                        ]}
                        numberOfLines={2}
                      >
                        {[
                          addr.province,
                          addr.city,
                          addr.district,
                          addr.detail,
                        ]
                          .filter(Boolean)
                          .join(" ")}
                      </Text>
                    </View>
                  </Pressable>
                );
              })}
              <Pressable
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  height: bs(44),
                  borderRadius: BoxRadius.lg,
                  marginTop: BoxSpacing.xs,
                  borderWidth: 1,
                  borderColor: BoxBorders.default,
                  borderStyle: "dashed",
                }}
                onPress={() => router.push("/profile/address")}
              >
                <Text
                  style={[BoxTypography.body, { color: BoxText.secondary }]}
                >
                  {t("shipping.manageAddress")}
                </Text>
                <ChevronRight size={bs(16)} color={BoxText.secondary} />
              </Pressable>
            </View>
          ) : (
            <Pressable
              style={{
                borderRadius: BoxRadius.xl,
                padding: BoxSpacing["2xl"],
                alignItems: "center",
                backgroundColor: BoxSurfaces.card,
                borderWidth: 1,
                borderColor: BoxBorders.default,
                borderStyle: "dashed",
              }}
              onPress={() => router.push("/profile/address")}
            >
              <MapPin size={bs(32)} color={BoxText.tertiary} />
              <Text
                style={[
                  BoxTypography.body,
                  { color: BoxText.tertiary, marginTop: BoxSpacing.sm },
                ]}
              >
                {t("shipping.noAddress")}
              </Text>
            </Pressable>
          )}

          {/* Summary */}
          {selectedIds.length > 0 && (
            <LinearGradient
              colors={BoxGradients.cardSubtle}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                borderRadius: BoxRadius.xl,
                padding: BoxSpacing.lg,
                marginTop: BoxSpacing.lg,
                borderWidth: 1,
                borderColor: BoxBorders.default,
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  marginBottom: BoxSpacing.sm,
                }}
              >
                <Text
                  style={[BoxTypography.body, { color: BoxText.secondary }]}
                >
                  {t("shipping.selectedCount")}
                </Text>
                <Text
                  style={[BoxTypography.bodyBold, { color: BoxText.primary }]}
                >
                  {selectedItems.length}
                </Text>
              </View>
              {selectedAddress && (
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    marginBottom: BoxSpacing.sm,
                  }}
                >
                  <Text
                    style={[BoxTypography.body, { color: BoxText.secondary }]}
                  >
                    {t("shipping.recipient")}
                  </Text>
                  <Text
                    style={[
                      BoxTypography.bodyBold,
                      { color: BoxText.primary },
                    ]}
                  >
                    {selectedAddress.real_name} {selectedAddress.phone}
                  </Text>
                </View>
              )}
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Text
                  style={[BoxTypography.body, { color: BoxText.secondary }]}
                >
                  {t("shipping.totalFreight")}
                </Text>
                <Text
                  style={[BoxTypography.priceHero, { color: BoxAccent.gold }]}
                >
                  ¥{totalFreight.toFixed(2)}
                </Text>
              </View>
            </LinearGradient>
          )}
        </View>
      </ScrollView>

      {/* Bottom Action Bar */}
      <View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          padding: BoxSpacing.lg,
          paddingBottom: bs(34),
          borderTopWidth: 1,
          borderTopColor: BoxBorders.subtle,
          backgroundColor: BoxSurfaces.deep,
        }}
      >
        <BoxActionButton
          title={t("shipping.confirm", { fee: totalFreight.toFixed(2) })}
          variant="primary"
          icon={
            <Truck
              size={bs(20)}
              color={
                selectedIds.length > 0
                  ? BoxText.onGold
                  : BoxText.disabled
              }
            />
          }
          loading={createOrder.isPending || payShipping.isPending}
          disabled={selectedIds.length === 0}
          onPress={handleSubmit}
        />
      </View>
    </View>
  );
}
