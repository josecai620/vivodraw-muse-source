import { withAccountRequestLock } from "@/lib/game/accountRequestLock";
import { MAX_RECHARGE_MINOR } from "@/lib/api/walletRecharge";
import { isGameWalletGame, type GameWalletGame } from "@/lib/api/gameWallet";
export { MAX_RECHARGE_MINOR } from "@/lib/api/walletRecharge";

/** 仅保存用户发起的充值指令和订单归属；到账状态与余额始终重新向服务器核对。 */
export type PendingRecharge = { account_id: number; request_id: string; amount_minor: number; game: GameWalletGame | null; order_id: string | null };
const key = (uid: number) => `vivodraw:recharge:pending:v1:${uid}`;
const contextKey = (order: string) => `vivodraw:recharge:return:v1:${order}`;
export const validRechargeOrder = (value: unknown): value is string => typeof value === "string" && /^[A-Za-z0-9_-]{1,80}$/.test(value);
export function rechargeMinor(value: string): number | null {
  if (!/^(?:0|[1-9]\d{0,7})(?:\.\d{1,2})?$/.test(value)) return null;
  const [whole, fraction = ""] = value.split(".");
  const minor = Number(whole) * 100 + Number(fraction.padEnd(2, "0"));
  return Number.isSafeInteger(minor) && minor > 0 && minor <= MAX_RECHARGE_MINOR ? minor : null;
}
function validate(value: unknown, allowLegacyAmount = false): PendingRecharge {
  if (!value || typeof value !== "object") throw new Error("Invalid recharge record");
  const r = value as PendingRecharge;
  if (Object.keys(r).length !== 5 || !Number.isSafeInteger(r.account_id) || r.account_id <= 0
    || typeof r.request_id !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(r.request_id)
    || !Number.isSafeInteger(r.amount_minor) || r.amount_minor < 50 || r.amount_minor > (allowLegacyAmount ? 9999999999 : MAX_RECHARGE_MINOR)
    || (r.game !== null && !isGameWalletGame(r.game)) || (r.order_id !== null && !validRechargeOrder(r.order_id))) throw new Error("Invalid recharge record");
  return { account_id: r.account_id, request_id: r.request_id, amount_minor: r.amount_minor, game: r.game, order_id: r.order_id };
}
function read(storageKey: string, allowLegacyAmount = false) {
  const raw = localStorage.getItem(storageKey);
  if (raw === null) return null;
  if (raw.length > 1024) throw new Error("Invalid recharge record");
  return validate(JSON.parse(raw), allowLegacyAmount);
}
function write(storageKey: string, request: PendingRecharge, allowLegacyAmount = false) {
  const raw = JSON.stringify(validate(request, allowLegacyAmount));
  localStorage.setItem(storageKey, raw);
  if (localStorage.getItem(storageKey) !== raw) throw new Error("Recharge record not saved");
}
export function readRechargeContext(order: string) {
  if (!validRechargeOrder(order)) return null;
  const value = read(contextKey(order));
  if (value && value.order_id !== order) throw new Error("Wrong recharge order");
  return value;
}
const sameIntent = (a: PendingRecharge, b: PendingRecharge) => a.account_id === b.account_id && a.request_id === b.request_id
  && a.amount_minor === b.amount_minor && a.game === b.game && (a.order_id === null || b.order_id === null || a.order_id === b.order_id);
export type RechargeRecoveryLock = {
  readPending: () => PendingRecharge | null;
  save: (request: PendingRecharge) => PendingRecharge;
  bindOrder: (request: PendingRecharge, order: string) => PendingRecharge;
  clear: (request: PendingRecharge) => boolean;
  assertCurrent: (request: PendingRecharge) => void;
  readonly discardedInvalidAmount: boolean;
};

/** 所有充值保存、消费、绑定、清理都在同一账号锁内；浏览器不以本地计时锁冒充原子操作。 */
export async function withRechargeLock<T>(uid: number, action: (lock: RechargeRecoveryLock) => Promise<T> | T): Promise<T> {
  if (!Number.isSafeInteger(uid) || uid <= 0) throw new Error("Wrong recharge owner");
  const run = async () => {
    let held = true, discardedInvalidAmount = false;
    const check = () => { if (!held) throw new Error("Recharge lock released"); };
    const readPending = () => {
      check(); const value = read(key(uid), true);
      if (value && value.account_id !== uid) throw new Error("Wrong recharge owner");
      if (value && value.amount_minor > MAX_RECHARGE_MINOR) {
        // 旧前端曾接受服务端必定拒绝的超限金额；保留指令副本后移出活动槽，不再无限重试。
        write(`vivodraw:recharge:invalid:v1:${uid}:${value.request_id}`, value, true);
        localStorage.removeItem(key(uid));
        if (localStorage.getItem(key(uid)) !== null) throw new Error("Recharge record not cleared");
        discardedInvalidAmount = true; return null;
      }
      return value;
    };
    const assertCurrent = (request: PendingRecharge) => {
      check(); const value = validate(request), pending = readPending();
      if (value.account_id !== uid) throw new Error("Wrong recharge owner");
      if (pending ? !sameIntent(pending, value) : !value.order_id || !sameIntent(readRechargeContext(value.order_id) ?? { ...value, request_id: "" }, value)) {
        throw new Error("recharge_request_changed");
      }
    };
    const lock: RechargeRecoveryLock = {
      readPending,
      save(input) {
        check(); const value = validate(input);
        if (value.account_id !== uid) throw new Error("Wrong recharge owner");
        const previous = readPending(); if (previous) return previous;
        write(key(uid), value); return value;
      },
      bindOrder(request, order) {
        assertCurrent(request);
        if (!validRechargeOrder(order) || (request.order_id !== null && request.order_id !== order)) throw new Error("Recharge order changed");
        const value = validate({ ...request, order_id: order }), pending = readPending(), context = readRechargeContext(order);
        if (context && JSON.stringify(context) !== JSON.stringify(value)) throw new Error("Recharge owner changed");
        write(contextKey(order), value);
        if (pending) write(key(uid), value);
        return value;
      },
      clear(request) {
        check(); const pending = readPending();
        if (pending === null) return true;
        if (JSON.stringify(pending) !== JSON.stringify(validate(request))) return false;
        localStorage.removeItem(key(uid));
        if (localStorage.getItem(key(uid)) !== null) throw new Error("Recharge record not cleared");
        return true;
      },
      assertCurrent,
      get discardedInvalidAmount() { return discardedInvalidAmount; },
    };
    try { return await action(lock); } finally { held = false; }
  };
  return withAccountRequestLock(uid, "recharge", run);
}
