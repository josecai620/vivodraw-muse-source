import CachedImage from "@/components/shared/CachedImage";
import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import { useCommunityFeed } from "@/hooks/useCommunityFeed";
import { toggleCommunityLike, type CommunityPost } from "@/lib/api/community";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { Camera, Heart, MessageCircle, Plus, RefreshCw } from "lucide-react-native";
import React from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";

export default function CommunityScreen() {
  const router = useRouter();
  const { i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const text = (z: string, e: string) => (zh ? z : e);
  const community = useCommunityFeed();

  const likePost = async (post: CommunityPost) => {
    await toggleCommunityLike(post.id, post.productId);
    community.refresh();
  };

  return (
    <View className="flex-1 bg-neutral-50">
      <PageHeader title={text("社區廣場", "Community")} />
      <ScrollView
        contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
      >
        {/* 顶部介绍 + 发帖 */}
        <View className="bg-white rounded-2xl p-5 gap-3">
          <Text className="text-xs font-bold" style={{ color: Colors.brand.redDark }}>
            {text("真實會員晒單", "REAL BUYER POSTS")}
          </Text>
          <Text className="text-xl font-bold text-neutral-900">
            {text("會員晒單與中獎故事", "Member photos and reward stories.")}
          </Text>
          <Text className="text-sm text-neutral-500 leading-5">
            {text(
              "看看其他會員收到了什麼，你的獎品晒單也可以在這裡分享。",
              "See what members received, then share your own reward photo when it is ready.",
            )}
          </Text>
          <Pressable onPress={() => router.push("/community/new")}>
            <LinearGradient
              colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              className="h-12 rounded-xl items-center justify-center flex-row"
            >
              <Plus size={18} color="#fff" />
              <Text className="text-white font-bold ml-2">{text("分享我的晒單", "Share a win")}</Text>
            </LinearGradient>
          </Pressable>
        </View>

        <View className="flex-row items-center justify-between">
          <Text className="text-base font-bold text-neutral-900">{text("最新動態", "Latest posts")}</Text>
          <Pressable className="flex-row items-center" onPress={community.refresh}>
            <RefreshCw size={14} color={Colors.brand.redDark} />
            <Text className="text-sm font-bold ml-1.5" style={{ color: Colors.brand.redDark }}>
              {community.isLoading ? text("載入中…", "Loading...") : text("刷新", "Refresh")}
            </Text>
          </Pressable>
        </View>

        {community.isLoading ? (
          <View className="bg-white rounded-2xl p-8 items-center">
            <ActivityIndicator color={Colors.brand.red} />
          </View>
        ) : community.posts.length > 0 ? (
          community.posts.map((post) => (
            <Pressable
              key={post.id}
              onPress={() => router.push(`/community/${post.id}`)}
              className="bg-white rounded-2xl overflow-hidden"
            >
              {post.image ? (
                <CachedImage uri={post.image} style={{ width: "100%", aspectRatio: 1.4 }} />
              ) : null}
              <View className="p-4 gap-2">
                <View className="flex-row items-center justify-between">
                  <Text numberOfLines={1} className="flex-1 text-xs font-bold" style={{ color: Colors.brand.redDark }}>
                    {post.productName}
                  </Text>
                  <Text className="text-xs text-neutral-400 ml-2">{post.createdAt}</Text>
                </View>
                <Text numberOfLines={2} className="text-base font-bold text-neutral-900">
                  {post.title}
                </Text>
                <Text numberOfLines={3} className="text-sm text-neutral-500 leading-5">
                  {post.content || text("會員晒單", "Buyer photo post.")}
                </Text>
                <View className="flex-row items-center gap-2 mt-1">
                  <Text className="flex-1 text-sm font-semibold text-neutral-700">{post.author}</Text>
                  <View className="flex-row items-center rounded-full px-2.5 py-1" style={{ backgroundColor: "#ECFBFB" }}>
                    <Heart size={12} color={Colors.brand.redDark} />
                    <Text className="text-xs font-bold ml-1" style={{ color: Colors.brand.redDark }}>
                      {post.likes}
                    </Text>
                  </View>
                  <View className="flex-row items-center rounded-full px-2.5 py-1 bg-neutral-100">
                    <MessageCircle size={12} color={Colors.neutral[500]} />
                    <Text className="text-xs font-bold ml-1 text-neutral-500">{post.comments}</Text>
                  </View>
                </View>
                <View className="flex-row gap-2 mt-1">
                  <Pressable
                    className="flex-1 h-10 rounded-lg border border-neutral-200 items-center justify-center"
                    onPress={() => router.push(`/community/${post.id}`)}
                  >
                    <Text className="text-sm font-semibold text-neutral-700">{text("查看", "View")}</Text>
                  </Pressable>
                  <Pressable
                    className="flex-1 h-10 rounded-lg items-center justify-center flex-row"
                    style={{ backgroundColor: post.isLiked ? "#ECFBFB" : "#F7F9F9" }}
                    onPress={() => void likePost(post)}
                  >
                    <Heart
                      size={14}
                      color={post.isLiked ? Colors.brand.red : Colors.neutral[500]}
                      fill={post.isLiked ? Colors.brand.red : "transparent"}
                    />
                    <Text
                      className="text-sm font-semibold ml-1.5"
                      style={{ color: post.isLiked ? Colors.brand.redDark : Colors.neutral[600] }}
                    >
                      {post.isLiked ? text("已讚", "Liked") : text("點讚", "Like")}
                    </Text>
                  </Pressable>
                </View>
              </View>
            </Pressable>
          ))
        ) : (
          <View className="bg-white rounded-2xl p-8 items-center gap-3">
            <Camera size={32} color={Colors.neutral[300]} />
            <Text className="text-base font-bold text-neutral-900">
              {text("還沒有會員晒單", "No member photos yet")}
            </Text>
            <Text className="text-sm text-neutral-500 text-center leading-5">
              {text(
                "會員分享獎品晒單後會顯示在這裡，你也可以點上方按鈕第一個分享。",
                "When members share reward photos, they appear here. Use the button above to add yours.",
              )}
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
