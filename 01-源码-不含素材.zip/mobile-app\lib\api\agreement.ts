import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

export function getUserAgreement(type: string) {
  return http.get(API_ENDPOINTS.userAgreement(type));
}
