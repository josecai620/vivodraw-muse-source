'use strict';
// 用于 Expo 静态导出后的局部优化，不触碰 API/账号/支付逻辑。
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

const shellCss = '#vivo-startup{position:fixed;inset:0;z-index:1000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;padding:24px;background:#f5f7f7;color:#243333;font-family:system-ui,-apple-system,sans-serif;text-align:center}#vivo-startup strong{font-size:26px;letter-spacing:-1px}#vivo-startup strong span{color:#04a8ae}#vivo-startup p{font-size:14px;line-height:1.5;max-width:300px;margin:0}#vivo-startup button{min-height:44px;padding:10px 24px;border:0;border-radius:12px;background:#087e83;color:#fff;font:600 15px system-ui;cursor:pointer}#vivo-startup button[hidden]{display:none}#vivo-startup button:focus-visible{outline:3px solid #243333;outline-offset:3px}#vivo-startup i{width:28px;height:28px;border:3px solid #cae8e8;border-top-color:#04a8ae;border-radius:50%;animation:vivo-boot-spin 1s linear infinite}#vivo-startup[data-slow] i{display:none}@keyframes vivo-boot-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){#vivo-startup i{animation:none}}';

function optimizeHtml(html, script = fs.readFileSync(path.join(__dirname, '网页启动保护.js'), 'utf8')) {
  assert(html.includes('<div id="root">'), 'Expected Expo root');
  assert(!html.includes('id="vivo-startup"'), 'Already optimized; use an unmodified input');
  assert(!/<\/script/i.test(script), 'Inline script must not close its tag');
  const scripts = [...html.matchAll(/<script\b[^>]*\bsrc="([^"]+)"[^>]*>/g)]
    .map(m => m[1]).filter(url => url.startsWith('/_expo/') && /\.js(?:\?|$)/.test(url));
  assert(scripts.length >= 3, 'Expected Expo startup scripts');
  // 核心脚本提前发现；字体不再用 preload 抢首屏连接，仍由 expo-font 正常加载。
  let output = html.replace(/<link\b(?=[^>]*\brel="preload")(?=[^>]*\bas="font")[^>]*\/?\s*>/g, '');
  const preloads = scripts.filter(url => !html.includes('rel="preload" href="' + url + '" as="script"'))
    .map(url => '<link rel="preload" href="' + url + '" as="script">').join('');
  output = output.replace('</head>', '<style id="vivo-startup-style">' + shellCss + '</style>' + preloads + '</head>');
  const shell = '<section id="vivo-startup" aria-label="VivoDraw"><strong>Vivo<span>Draw</span></strong><i aria-hidden="true"></i><p data-startup-message role="status" aria-live="polite">Loading your store…</p><button type="button" hidden>Try again</button><noscript>Please enable JavaScript to open the store.</noscript></section>';
  // 放在 #root 外，不改 React 服务端标记，避免 hydration 不匹配。
  output = output.replace(/<body([^>]*)>/, '<body$1>' + shell);
  const firstScript = output.indexOf('<script src=');
  assert(firstScript !== -1, 'Expected deferred scripts after root');
  output = output.slice(0, firstScript) + '<script id="vivo-startup-guard">' + script + '</script>' + output.slice(firstScript);
  return output;
}

function versionChunkUrls(text, digestForFile) {
  const references = new Map();
  const output = text.replace(/\/_expo\/static\/js\/web\/[A-Za-z0-9_.\[\]-]+\.js(?![A-Za-z0-9_?.])/g, url => {
    if (!references.has(url)) {
      const digest = digestForFile(url.slice(1));
      assert(/^[a-f0-9]{64}$/.test(digest), 'Invalid chunk digest: ' + url);
      references.set(url, url + '?v=' + digest.slice(0, 16));
    }
    return references.get(url);
  });
  assert(references.size > 0, 'No unversioned async chunk URLs found');
  return { output, references: Object.fromEntries(references) };
}

function run(dist) {
  const { optimize } = require('./优化图标导出.cjs');
  const jsRoot = path.join(dist, '_expo/static/js/web');
  const commons = fs.readdirSync(jsRoot).filter(f => /^__common-.*\.js$/.test(f));
  assert.equal(commons.length, 1, 'Expected one common bundle');
  const commonPath = path.join(jsRoot, commons[0]);
  const optimized = optimize(fs.readFileSync(commonPath, 'utf8'));
  // 新内容使用新地址；旧地址完整保留，避免 immutable 缓存漂移。
  const nextName = '__common-' + crypto.createHash('sha256').update(optimized.output).digest('hex').slice(0, 32) + '.js';
  const prefix = '/_expo/static/js/web/';
  const digestForExport = relative => crypto.createHash('sha256').update(
    relative === prefix.slice(1) + nextName ? optimized.output : fs.readFileSync(path.join(dist, relative))).digest('hex');
  const entries = fs.readdirSync(jsRoot).filter(f => /^entry-.*\.js$/.test(f));
  assert.equal(entries.length, 1, 'Expected one entry bundle');
  // 页面内跳转也须携带版本，不能继续复用发布前的异步路由缓存。
  const versioned = versionChunkUrls(fs.readFileSync(path.join(jsRoot, entries[0]), 'utf8')
    .replaceAll(prefix + commons[0], prefix + nextName), digestForExport);
  const nextEntry = 'entry-' + crypto.createHash('sha256').update(versioned.output).digest('hex').slice(0, 32) + '.js';
  const htmlOutputs = [];
  for (const relative of ['index.html', '(tabs)/index.html']) {
    const file = path.join(dist, relative);
    if (fs.existsSync(file)) {
      const html = fs.readFileSync(file, 'utf8');
      assert(html.includes(prefix + commons[0]), 'Homepage common reference missing');
      assert(html.includes(prefix + entries[0]), 'Homepage entry reference missing');
      const updated = html.replaceAll(prefix + commons[0], prefix + nextName).replaceAll(prefix + entries[0], prefix + nextEntry);
      const aligned = versionChunkUrls(updated, relative => relative === prefix.slice(1) + nextEntry
        ? crypto.createHash('sha256').update(versioned.output).digest('hex') : digestForExport(relative));
      htmlOutputs.push([file, optimizeHtml(aligned.output)]);
    }
  }
  assert(htmlOutputs.length > 0, 'Homepage export missing');
  fs.writeFileSync(path.join(jsRoot, nextName), optimized.output, { flag: 'wx' });
  fs.writeFileSync(path.join(jsRoot, nextEntry), versioned.output, { flag: 'wx' });
  for (const [file, contents] of htmlOutputs) fs.writeFileSync(file, contents);
  return { ...optimized.report, commonFile: nextName, entryFile: nextEntry };
}
module.exports = { optimizeHtml, versionChunkUrls, run, shellCss };
if (require.main === module) console.log(JSON.stringify(run(path.resolve(process.argv[2] || 'dist-root')), null, 2));
