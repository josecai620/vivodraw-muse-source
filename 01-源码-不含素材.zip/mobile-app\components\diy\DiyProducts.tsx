// [已废弃] 改由 @/components/home-layout/HlProductList 替代
export default function DiyProductsDeprecated(): null { return null; }
