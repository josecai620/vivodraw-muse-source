import { PageHeader } from "@/components/shared";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import {
  type Address,
  type SaveAddressInput,
  deleteAddress,
  getAddressList,
  saveAddress,
  setDefaultAddress,
} from "@/lib/api/address";
import { unwrapApiList } from "@/lib/api/response";
import { useAuthStore } from "@/store/auth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { Check, MapPin, Plus, Star, Trash2, X } from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Pressable,
  RefreshControl,
  ScrollView,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

type AddressForm = {
  id?: number;
  realName: string;
  phone: string;
  line1: string;
  line2: string;
  city: string;
  state: string;
  postalCode: string;
  isDefault: boolean;
};

const EMPTY_FORM: AddressForm = {
  realName: "",
  phone: "",
  line1: "",
  line2: "",
  city: "",
  state: "",
  postalCode: "",
  isDefault: false,
};

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

function detailLines(detail: string) {
  return detail
    .split(/\n|,\s*/)
    .map((line) => line.trim())
    .filter(Boolean);
}

function addressToForm(address: Address): AddressForm {
  const lines = detailLines(address.detail ?? "");
  return {
    id: address.id,
    realName: address.real_name ?? "",
    phone: address.phone ?? "",
    line1: lines[0] ?? "",
    line2: lines.slice(1).join(", "),
    city: address.city ?? "",
    state: address.province ?? "",
    postalCode: address.post_code ?? "",
    isDefault: Number(address.is_default) === 1,
  };
}

function formToPayload(form: AddressForm): SaveAddressInput {
  return {
    id: form.id,
    real_name: form.realName.trim(),
    phone: form.phone.trim(),
    province: form.state.trim(),
    city: form.city.trim(),
    district: "United States",
    detail: [form.line1.trim(), form.line2.trim()].filter(Boolean).join(", "),
    post_code: form.postalCode.trim(),
    is_default: form.isDefault,
  };
}

function formatAddress(address: Address) {
  const street = detailLines(address.detail ?? "").join(", ");
  const cityLine = [address.city, address.province, address.post_code].filter(Boolean).join(", ");
  const country = address.district && address.district !== "United States" ? address.district : "";
  return [street, cityLine, country || "United States"].filter(Boolean).join("\n");
}

export default function AddressScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const queryClient = useQueryClient();
  const isLoggedIn = useAuthStore((state) => state.isLoggedIn);

  const [form, setForm] = useState<AddressForm>(EMPTY_FORM);
  const [modalVisible, setModalVisible] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["addresses"],
    queryFn: getAddressList,
    enabled: isLoggedIn,
  });

  const addresses = useMemo(() => unwrapApiList<Address>(data), [data]);

  const refreshAddressQueries = () => {
    queryClient.invalidateQueries({ queryKey: ["addresses"] });
    queryClient.invalidateQueries({ queryKey: ["defaultAddress"] });
  };

  const saveMutation = useMutation({
    mutationFn: saveAddress,
    onSuccess: () => {
      refreshAddressQueries();
      setModalVisible(false);
      setForm(EMPTY_FORM);
    },
    onError: (error) => {
      Alert.alert(t("common.failed"), getErrorMessage(error, t("addressBook.saveFailed")));
    },
  });

  const deleteMutation = useMutation({
    mutationFn: deleteAddress,
    onSuccess: refreshAddressQueries,
    onError: (error) => {
      Alert.alert(t("common.failed"), getErrorMessage(error, t("addressBook.deleteFailed")));
    },
  });

  const defaultMutation = useMutation({
    mutationFn: setDefaultAddress,
    onSuccess: refreshAddressQueries,
    onError: (error) => {
      Alert.alert(t("common.failed"), getErrorMessage(error, t("addressBook.defaultFailed")));
    },
  });

  const openCreate = () => {
    setForm({ ...EMPTY_FORM, isDefault: addresses.length === 0 });
    setModalVisible(true);
  };

  const openEdit = (address: Address) => {
    setForm(addressToForm(address));
    setModalVisible(true);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ["addresses"] });
    setRefreshing(false);
  };

  const handleSave = () => {
    const payload = formToPayload(form);
    if (
      !payload.real_name ||
      !payload.phone ||
      !payload.detail ||
      !payload.city ||
      !payload.province ||
      !payload.post_code
    ) {
      Alert.alert(t("common.notice"), t("addressBook.required"));
      return;
    }
    saveMutation.mutate(payload);
  };

  const handleDelete = (address: Address) => {
    Alert.alert(t("addressBook.deleteTitle"), t("addressBook.deleteMessage"), [
      { text: t("common.cancel"), style: "cancel" },
      {
        text: t("addressBook.delete"),
        style: "destructive",
        onPress: () => deleteMutation.mutate(address.id),
      },
    ]);
  };

  const renderModal = () => (
    <Modal
      visible={modalVisible}
      animationType="slide"
      transparent
      onRequestClose={() => setModalVisible(false)}
    >
      <View className="flex-1 justify-end bg-black/40">
        <View className="max-h-[88%] rounded-t-3xl bg-white">
          <View className="flex-row items-center justify-between border-b border-gray-100 px-4 py-3">
            <Text className="text-lg font-bold text-gray-900">
              {form.id ? t("addressBook.editTitle") : t("addressBook.addTitle")}
            </Text>
            <Pressable className="p-2" onPress={() => setModalVisible(false)}>
              <X size={s(20)} color={Colors.neutral[600]} />
            </Pressable>
          </View>

          <ScrollView className="px-4 py-4" keyboardShouldPersistTaps="handled">
            {[
              ["realName", t("addressBook.fullName"), "Jane Smith"],
              ["phone", t("addressBook.phone"), "+1 555 123 4567"],
              ["line1", t("addressBook.line1"), "123 Main St"],
              ["line2", t("addressBook.line2"), "Apt, suite, unit"],
              ["city", t("addressBook.city"), "Los Angeles"],
              ["state", t("addressBook.state"), "CA"],
              ["postalCode", t("addressBook.postalCode"), "90001"],
            ].map(([key, label, placeholder]) => (
              <View key={key} className="mb-3">
                <Text className="mb-1.5 text-xs font-semibold text-gray-600">{label}</Text>
                <TextInput
                  value={String(form[key as keyof AddressForm] ?? "")}
                  onChangeText={(value) => setForm((prev) => ({ ...prev, [key]: value }))}
                  placeholder={placeholder}
                  placeholderTextColor={Colors.neutral[400]}
                  autoCapitalize={key === "state" ? "characters" : "words"}
                  keyboardType={key === "phone" ? "phone-pad" : "default"}
                  className="h-11 rounded-xl border border-gray-200 bg-white px-3 text-sm text-gray-900"
                />
              </View>
            ))}

            <View className="mb-5 flex-row items-center justify-between rounded-xl bg-gray-50 px-3 py-3">
              <Text className="text-sm font-semibold text-gray-800">
                {t("addressBook.setDefault")}
              </Text>
              <Switch
                value={form.isDefault}
                onValueChange={(value) => setForm((prev) => ({ ...prev, isDefault: value }))}
                trackColor={{ false: Colors.neutral[300], true: Colors.brand.red }}
              />
            </View>

            <Pressable
              className="h-12 items-center justify-center rounded-xl"
              style={{
                opacity: saveMutation.isPending ? 0.7 : 1,
              }}
              disabled={saveMutation.isPending}
              onPress={handleSave}
            >
              <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
              <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
              <Text className="font-bold text-white">
                {saveMutation.isPending ? t("common.submitting") : t("addressBook.save")}
              </Text>
            </Pressable>
            <View className="h-8" />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  if (!isLoggedIn) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("addressBook.title")} />
        <View className="flex-1 items-center justify-center px-8">
          <MapPin size={s(48)} color={Colors.neutral[300]} />
          <Text className="mt-4 text-xl font-bold text-gray-900">
            {t("addressBook.signInTitle")}
          </Text>
          <Text className="mt-2 text-center text-sm text-gray-500">
            {t("addressBook.signInDesc")}
          </Text>
          <Pressable
            className="mt-6 h-11 items-center justify-center rounded-xl px-6"
            style={{ }}
            onPress={() => router.push("/auth")}
          >
            <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
            <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
            <Text className="font-semibold text-white">{t("common.login")}</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader
        title={t("addressBook.title")}
        rightElement={
          <Pressable className="p-2" onPress={openCreate}>
            <Plus size={s(20)} color={Colors.brand.red} />
          </Pressable>
        }
      />

      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator color={Colors.brand.red} />
        </View>
      ) : addresses.length === 0 ? (
        <View className="flex-1 items-center justify-center px-8">
          <MapPin size={s(48)} color={Colors.neutral[300]} />
          <Text className="mt-4 text-xl font-bold text-gray-900">
            {t("addressBook.emptyTitle")}
          </Text>
          <Text className="mt-2 text-center text-sm text-gray-500">
            {t("addressBook.emptyDesc")}
          </Text>
          <Pressable
            className="mt-6 h-11 items-center justify-center rounded-xl px-6"
            style={{ }}
            onPress={openCreate}
          >
            <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 1, y: 0.5 }} end={{ x: 0, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
            <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
            <Text className="font-semibold text-white">{t("addressBook.addAddress")}</Text>
          </Pressable>
        </View>
      ) : (
        <ScrollView
          className="flex-1 px-4 pt-4"
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#04A8AE" />
          }
        >
          {addresses.map((address) => {
            const isDefault = Number(address.is_default) === 1;
            return (
              <Pressable
                key={address.id}
                className="mb-3 rounded-2xl border bg-white p-4"
                style={{ borderColor: isDefault ? Colors.brand.red : Colors.neutral[100] }}
                onPress={() => openEdit(address)}
              >
                <View className="flex-row items-start gap-3">
                  <View
                    className="h-10 w-10 items-center justify-center rounded-xl"
                    style={{
                      backgroundColor: isDefault ? `${Colors.brand.red}12` : Colors.neutral[100],
                    }}
                  >
                    <MapPin
                      size={s(20)}
                      color={isDefault ? Colors.brand.red : Colors.neutral[500]}
                    />
                  </View>

                  <View className="flex-1">
                    <View className="mb-1 flex-row items-center gap-2">
                      <Text className="text-sm font-semibold text-gray-900">
                        {address.real_name}
                      </Text>
                      {isDefault && (
                        <View
                          className="rounded-full px-2 py-0.5"
                          style={{ backgroundColor: Colors.brand.red }}
                        >
                          <Text className="text-[10px] font-bold text-white">
                            {t("addressBook.default")}
                          </Text>
                        </View>
                      )}
                    </View>
                    <Text className="mb-1 text-xs text-gray-500">{address.phone}</Text>
                    <Text className="text-xs leading-5 text-gray-600">
                      {formatAddress(address)}
                    </Text>

                    <View className="mt-3 flex-row gap-2">
                      {!isDefault && (
                        <Pressable
                          className="h-8 flex-row items-center gap-1 rounded-lg border border-gray-200 px-3"
                          onPress={(event) => {
                            event.stopPropagation();
                            defaultMutation.mutate(address.id);
                          }}
                        >
                          <Star size={s(14)} color={Colors.neutral[600]} />
                          <Text className="text-xs font-semibold text-gray-700">
                            {t("addressBook.makeDefault")}
                          </Text>
                        </Pressable>
                      )}
                      <Pressable
                        className="h-8 flex-row items-center gap-1 rounded-lg border border-gray-200 px-3"
                        onPress={(event) => {
                          event.stopPropagation();
                          handleDelete(address);
                        }}
                      >
                        <Trash2 size={s(14)} color={Colors.neutral[500]} />
                        <Text className="text-xs font-semibold text-gray-700">
                          {t("addressBook.delete")}
                        </Text>
                      </Pressable>
                    </View>
                  </View>

                  {isDefault && <Check size={s(20)} color={Colors.brand.red} />}
                </View>
              </Pressable>
            );
          })}
          <View className="h-8" />
        </ScrollView>
      )}

      {renderModal()}
    </View>
  );
}
