import React, { useState, useEffect } from "react";
import { View, Text, Image, ScrollView, Pressable, ActivityIndicator, Alert, TextInput, Modal } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams, useRouter, Stack } from "expo-router";
import { useTranslation } from "react-i18next";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";
import {
  usePinkDetail,
  useJoinPink,
  useCancelApply,
  useReviewCancel,
  useLeaderCancel,
  useWinnerChoice,
} from "@/hooks/useGroupLottery";
import { useAuthStore } from "@/store/auth";

function useStatusLabels() {
  const { t } = useTranslation();
  const STATUS_LABELS: Record<number, { text: string; color: string }> = {
    1: { text: t("groupLottery.statusActive"),    color: "#04A8AE" },
    2: { text: t("groupLottery.statusDrawn"),     color: "#04A8AE" },
    3: { text: t("groupLottery.statusTimeout"),   color: "#9E9E9E" },
    4: { text: t("groupLottery.statusCancelled"), color: "#9E9E9E" },
  };
  const MEMBER_STATUS: Record<number, { text: string; color: string }> = {
    1: { text: t("groupLottery.memberJoined"),        color: "#04A8AE" },
    2: { text: t("groupLottery.memberWon"),           color: "#04A8AE" },
    3: { text: t("groupLottery.memberRefundedLost"),  color: "#9E9E9E" },
    4: { text: t("groupLottery.memberRefunded"),      color: "#9E9E9E" },
    5: { text: t("groupLottery.memberCancelPending"), color: "#04A8AE" },
    6: { text: t("groupLottery.memberCancelled"),     color: "#9E9E9E" },
    7: { text: t("groupLottery.memberShipped"),       color: "#04A8AE" },
    8: { text: t("groupLottery.memberRecycled"),      color: "#04A8AE" },
  };
  return { STATUS_LABELS, MEMBER_STATUS };
}

function Countdown({ seconds: initial }: { seconds: number }) {
  const [sec, setSec] = useState(initial);
  useEffect(() => {
    if (sec <= 0) return;
    const t = setInterval(() => setSec((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, []);
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const ss = sec % 60;
  return (
    <Text style={{ fontSize: s(20), fontWeight: "bold", color: "#04A8AE" }}>
      {String(h).padStart(2, "0")}:{String(m).padStart(2, "0")}:{String(ss).padStart(2, "0")}
    </Text>
  );
}

export default function PinkDetailScreen() {
  const { t } = useTranslation();
  const { STATUS_LABELS, MEMBER_STATUS } = useStatusLabels();
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const uid = useAuthStore((s) => s.user?.uid);
  const token = useAuthStore((s) => s.token);
  const { data, isLoading } = usePinkDetail(Number(id));
  const joinMut = useJoinPink();
  const cancelMut = useCancelApply();
  const reviewMut = useReviewCancel();
  const leaderCancelMut = useLeaderCancel();
  const winnerMut = useWinnerChoice();

  const [showShipping, setShowShipping] = useState(false);
  const [shipping, setShipping] = useState({ name: "", phone: "", address: "" });
  const [showCancel, setShowCancel] = useState(false);
  const [cancelReason, setCancelReason] = useState("");

  const pink = data?.data;
  if (isLoading || !pink) {
    return (
      <View className="flex-1 bg-gray-50 items-center justify-center">
        <Stack.Screen options={{ headerShown: false }} />
        <ActivityIndicator size="large" color="#04A8AE" />
      </View>
    );
  }

  const lottery = pink.lottery || {};
  const members = pink.members || [];
  const isLeader = pink.uid === uid;
  const isWinner = pink.winner_uid === uid;
  const status = STATUS_LABELS[pink.status] || { text: t("common.unknown"), color: "#999" };
  const priceStr = pink.price_type === 1 ? `${pink.price} ${t("common.pts")}` : `$${pink.price}`;
  const remain = pink.people_count - pink.current_count;

  const handleJoin = () => {
    if (!token) {
      Alert.alert(t("groupLottery.loginRequired"), "", [
        { text: t("common.cancel") },
        { text: t("groupLottery.goLogin"), onPress: () => router.push("/auth") },
      ]);
      return;
    }
    Alert.alert(t("groupLottery.confirmJoin"), t("groupLottery.confirmJoinMsg", { price: priceStr }), [
      { text: t("common.cancel") },
      { text: t("common.confirm"), onPress: () => joinMut.mutate({ pink_id: pink.id }) },
    ]);
  };

  const handleCancel = () => {
    setCancelReason("");
    setShowCancel(true);
  };
  const submitCancel = () => {
    const reason = cancelReason.trim() || t("groupLottery.cancelDefaultReason");
    cancelMut.mutate({ pink_id: pink.id, reason }, { onSuccess: () => setShowCancel(false) });
  };

  const handleLeaderCancel = () => {
    Alert.alert(t("groupLottery.leaderCancelTitle"), t("groupLottery.leaderCancelMsg"), [
      { text: t("groupLottery.giveUp") },
      { text: t("groupLottery.confirmApply"), onPress: () => leaderCancelMut.mutate({ pink_id: pink.id }) },
    ]);
  };

  const handleWinnerShip = () => {
    if (!shipping.name || !shipping.phone || !shipping.address) {
      Alert.alert(t("groupLottery.fillShippingInfo"));
      return;
    }
    winnerMut.mutate({ pink_id: pink.id, choice: 1, ...shipping }, { onSuccess: () => setShowShipping(false) });
  };

  const handleWinnerRecycle = () => {
    const recyclePrice = lottery.recycle_price || 0;
    const priceLabel = pink.price_type === 1 ? `${recyclePrice} ${t("common.pts")}` : `$${recyclePrice}`;
    Alert.alert(t("groupLottery.confirmRecycle"), t("groupLottery.confirmRecycleMsg", { price: priceLabel }), [
      { text: t("common.cancel") },
      { text: t("groupLottery.confirmRecycle"), onPress: () => winnerMut.mutate({ pink_id: pink.id, choice: 2 }) },
    ]);
  };

  return (
    <View className="flex-1 bg-gray-50">
      <Stack.Screen options={{ headerShown: false }} />
      <PageHeader title={t("groupLottery.pinkDetail")} />
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: s(100) }}>
        {/* 状态栏 */}
        <View style={{ backgroundColor: status.color, padding: s(16), alignItems: "center" }}>
          <Text style={{ color: "#fff", fontSize: s(18), fontWeight: "bold" }}>{status.text}</Text>
          {pink.status === 1 && <Countdown seconds={pink.remain_seconds} />}
          {pink.status === 1 && (
            <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: s(12), marginTop: s(4) }}>
              {t("groupLottery.needMoreSimple", { count: remain })}
            </Text>
          )}
          {pink.status === 2 && pink.winner_uid > 0 && (
            <Text style={{ color: "#fff", fontSize: s(13), marginTop: s(4) }}>
              {isWinner ? t("groupLottery.youWon") : t("groupLottery.notWon")}
            </Text>
          )}
        </View>

        {/* 商品信息 */}
        <Pressable
          onPress={() => router.push(`/group-lottery/${pink.lottery_id}`)}
          style={{ backgroundColor: "#fff", flexDirection: "row", padding: s(12), borderBottomWidth: 1, borderBottomColor: "#f5f5f5" }}
        >
          <Image source={{ uri: lottery.image }} style={{ width: s(60), height: s(60), borderRadius: s(8) }} />
          <View style={{ flex: 1, marginLeft: s(10), justifyContent: "center" }}>
            <Text numberOfLines={1} style={{ fontSize: s(14), fontWeight: "600", color: Colors.neutral[800] }}>
              {lottery.title}
            </Text>
            <Text style={{ fontSize: s(15), fontWeight: "bold", color: "#04A8AE", marginTop: s(2) }}>{priceStr}</Text>
          </View>
          <View style={{ justifyContent: "center" }}>
            <Text style={{ fontSize: s(14), color: Colors.neutral[400] }}>{t("groupLottery.nPeopleGroup", { count: pink.people_count })}</Text>
          </View>
        </Pressable>

        {/* 成员 */}
        <View style={{ margin: s(12), backgroundColor: "#fff", borderRadius: s(10), padding: s(14) }}>
          <Text style={{ fontSize: s(13), fontWeight: "600", color: Colors.neutral[700], marginBottom: s(10) }}>
            {t("groupLottery.members", { current: pink.current_count, total: pink.people_count })}
          </Text>
          {members.map((m: any, i: number) => {
            const ms = MEMBER_STATUS[m.status] || { text: t("common.unknown"), color: "#999" };
            const pendingCancel = m.status === 5 && isLeader;
            return (
              <View key={i} style={{ flexDirection: "row", alignItems: "center", paddingVertical: s(8), borderBottomWidth: i < members.length - 1 ? 1 : 0, borderBottomColor: "#f9f9f9" }}>
                <Image
                  source={{ uri: m.avatar || "https://api.dicebear.com/7.x/avataaars/png?seed=default" }}
                  style={{ width: s(36), height: s(36), borderRadius: s(18) }}
                />
                <View style={{ flex: 1, marginLeft: s(8) }}>
                  <View style={{ flexDirection: "row", alignItems: "center" }}>
                    <Text style={{ fontSize: s(13), color: Colors.neutral[700] }}>{m.nickname}</Text>
                    {m.is_leader === 1 && (
                      <View style={{ backgroundColor: "#F7F8F8", paddingHorizontal: s(4), paddingVertical: s(1), borderRadius: s(3), marginLeft: s(4) }}>
                        <Text style={{ fontSize: s(9), color: "#04A8AE" }}>{t("groupLottery.leader")}</Text>
                      </View>
                    )}
                  </View>
                  <Text style={{ fontSize: s(11), color: ms.color }}>{ms.text}</Text>
                </View>
                {pendingCancel && (
                  <View style={{ flexDirection: "row", gap: s(6) }}>
                    <Pressable
                      onPress={() => reviewMut.mutate({ member_id: m.id, approve: 1 })}
                      style={{ paddingHorizontal: s(10), paddingVertical: s(4), borderRadius: s(6) }}
                    >
                      <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 6, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
                      <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 6 }} />
                      <Text style={{ color: "#fff", fontSize: s(11) }}>{t("groupLottery.approve")}</Text>
                    </Pressable>
                    <Pressable
                      onPress={() => reviewMut.mutate({ member_id: m.id, approve: 0 })}
                      style={{ backgroundColor: "#f5f5f5", paddingHorizontal: s(10), paddingVertical: s(4), borderRadius: s(6) }}
                    >
                      <Text style={{ color: Colors.neutral[600], fontSize: s(11) }}>{t("groupLottery.reject")}</Text>
                    </Pressable>
                  </View>
                )}
              </View>
            );
          })}
          {Array.from({ length: remain }).map((_, i) => (
            <View key={`empty-${i}`} style={{ flexDirection: "row", alignItems: "center", paddingVertical: s(8) }}>
              <View style={{ width: s(36), height: s(36), borderRadius: s(18), backgroundColor: "#f0f0f0", alignItems: "center", justifyContent: "center" }}>
                <Text style={{ fontSize: s(16), color: "#ccc" }}>?</Text>
              </View>
              <Text style={{ marginLeft: s(8), color: Colors.neutral[400], fontSize: s(12) }}>{t("groupLottery.waitingJoin")}</Text>
            </View>
          ))}
        </View>

        {/* 开奖验证 */}
        {pink.status === 2 && pink.draw_seed && (
          <View style={{ marginHorizontal: s(12), marginBottom: s(12), backgroundColor: "#fff", borderRadius: s(10), padding: s(14) }}>
            <Text style={{ fontSize: s(13), fontWeight: "600", color: Colors.neutral[700], marginBottom: s(6) }}>
              {t("groupLottery.drawVerification")}
            </Text>
            <Text style={{ fontSize: s(10), color: Colors.neutral[500] }}>Seed: {pink.draw_seed}</Text>
            <Text style={{ fontSize: s(10), color: Colors.neutral[500], marginTop: s(2) }}>Hash: {pink.draw_hash}</Text>
          </View>
        )}
      </ScrollView>

      {/* 底部操作 */}
      <View style={{ position: "absolute", bottom: 0, left: 0, right: 0, backgroundColor: "#fff", borderTopWidth: 1, borderTopColor: "#f0f0f0", padding: s(12), paddingBottom: s(28) }}>
        {pink.status === 1 && !pink.is_joined && (
          <Pressable
            onPress={handleJoin}
            disabled={joinMut.isPending}
            style={{ paddingVertical: s(12), borderRadius: s(10), alignItems: "center" }}
          >
            <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 10, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
            <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 10 }} />
            <Text style={{ color: "#fff", fontSize: s(15), fontWeight: "bold" }}>
              {joinMut.isPending ? t("groupLottery.joining") : t("groupLottery.joinWithPrice", { price: priceStr })}
            </Text>
          </Pressable>
        )}
        {pink.status === 1 && pink.is_joined && !isLeader && (
          <Pressable
            onPress={handleCancel}
            style={{ backgroundColor: "#f5f5f5", paddingVertical: s(12), borderRadius: s(10), alignItems: "center" }}
          >
            <Text style={{ color: Colors.neutral[600], fontSize: s(14) }}>{t("groupLottery.cancelJoin")}</Text>
          </Pressable>
        )}
        {pink.status === 1 && isLeader && (
          <Pressable
            onPress={handleLeaderCancel}
            style={{ backgroundColor: "#F7F8F8", paddingVertical: s(12), borderRadius: s(10), alignItems: "center" }}
          >
            <Text style={{ color: "#04A8AE", fontSize: s(14) }}>{t("groupLottery.leaderCancelBtn")}</Text>
          </Pressable>
        )}
        {pink.status === 2 && isWinner && pink.winner_choice === 0 && (
          <View style={{ flexDirection: "row", gap: s(10) }}>
            <Pressable
              onPress={() => setShowShipping(true)}
              style={{ flex: 1, paddingVertical: s(12), borderRadius: s(10), alignItems: "center" }}
            >
              <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 1, y: 0.5 }} end={{ x: 0, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 10, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
              <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 10 }} />
              <Text style={{ color: "#fff", fontSize: s(14), fontWeight: "bold" }}>{t("groupLottery.ship")}</Text>
            </Pressable>
            <Pressable
              onPress={handleWinnerRecycle}
              style={{ flex: 1, backgroundColor: "#f5f5f5", paddingVertical: s(12), borderRadius: s(10), alignItems: "center" }}
            >
              <Text style={{ color: Colors.neutral[600], fontSize: s(14) }}>{t("groupLottery.recycle")}</Text>
            </Pressable>
          </View>
        )}
        {pink.status === 2 && isWinner && pink.winner_choice === 1 && (() => {
          const me = members.find((m: any) => m.uid === uid);
          const shipped = me && me.delivery_id;
          return (
            <View style={{ backgroundColor: shipped ? "#ECFBFB" : "#F7F8F8", paddingVertical: s(10), paddingHorizontal: s(12), borderRadius: s(10) }}>
              <Text style={{ color: shipped ? "#04A8AE" : "#04A8AE", fontSize: s(13), fontWeight: "600" }}>
                {shipped ? t("groupLottery.shippedStatus") : t("groupLottery.waitingShip")}
              </Text>
              {shipped && (
                <Text style={{ color: Colors.neutral[600], fontSize: s(11), marginTop: s(4) }}>
                  {me.delivery_name} · {me.delivery_id}
                </Text>
              )}
            </View>
          );
        })()}
        {pink.status === 2 && isWinner && pink.winner_choice === 2 && (
          <View style={{ backgroundColor: "#ECFBFB", paddingVertical: s(10), paddingHorizontal: s(12), borderRadius: s(10) }}>
            <Text style={{ color: "#04A8AE", fontSize: s(13), fontWeight: "600" }}>{t("groupLottery.recycledStatus")}</Text>
          </View>
        )}
      </View>

      {/* 发货弹窗 */}
      <Modal visible={showShipping} transparent animationType="slide">
        <Pressable onPress={() => setShowShipping(false)} style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" }}>
          <Pressable onPress={() => {}} style={{ backgroundColor: "#fff", borderTopLeftRadius: s(16), borderTopRightRadius: s(16), padding: s(20) }}>
            <Text style={{ fontSize: s(16), fontWeight: "bold", color: Colors.neutral[800], marginBottom: s(14) }}>
              {t("groupLottery.shippingTitle")}
            </Text>
            {[
              { key: "name" as const, label: t("groupLottery.recipientName"), placeholder: t("groupLottery.enterName") },
              { key: "phone" as const, label: t("groupLottery.recipientPhone"), placeholder: t("groupLottery.enterPhone") },
              { key: "address" as const, label: t("groupLottery.recipientAddress"), placeholder: t("groupLottery.enterAddress") },
            ].map((f) => (
              <View key={f.key} style={{ marginBottom: s(12) }}>
                <Text style={{ fontSize: s(12), color: Colors.neutral[600], marginBottom: s(4) }}>{f.label}</Text>
                <TextInput
                  value={shipping[f.key]}
                  onChangeText={(t) => setShipping((p) => ({ ...p, [f.key]: t }))}
                  placeholder={f.placeholder}
                  style={{ borderWidth: 1, borderColor: "#e0e0e0", borderRadius: s(8), padding: s(10), fontSize: s(14) }}
                />
              </View>
            ))}
            <Pressable
              onPress={handleWinnerShip}
              disabled={winnerMut.isPending}
              style={{ paddingVertical: s(12), borderRadius: s(10), alignItems: "center", marginTop: s(6) }}
            >
              <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 10, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
              <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 10 }} />
              <Text style={{ color: "#fff", fontSize: s(15), fontWeight: "bold" }}>
                {winnerMut.isPending ? t("groupLottery.submitting") : t("groupLottery.submitShipping")}
              </Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>

      {/* 取消原因弹窗 */}
      <Modal visible={showCancel} transparent animationType="slide">
        <Pressable onPress={() => setShowCancel(false)} style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" }}>
          <Pressable onPress={() => {}} style={{ backgroundColor: "#fff", borderTopLeftRadius: s(16), borderTopRightRadius: s(16), padding: s(20) }}>
            <Text style={{ fontSize: s(16), fontWeight: "bold", color: Colors.neutral[800], marginBottom: s(8) }}>
              {t("groupLottery.cancelTitle")}
            </Text>
            <Text style={{ fontSize: s(12), color: Colors.neutral[500], marginBottom: s(12) }}>
              {t("groupLottery.cancelDesc")}
            </Text>
            <TextInput
              value={cancelReason}
              onChangeText={setCancelReason}
              placeholder={t("groupLottery.cancelReasonPlaceholder")}
              multiline
              maxLength={200}
              style={{ borderWidth: 1, borderColor: "#e0e0e0", borderRadius: s(8), padding: s(10), fontSize: s(13), minHeight: s(80), textAlignVertical: "top" }}
            />
            <View style={{ flexDirection: "row", gap: s(10), marginTop: s(14) }}>
              <Pressable
                onPress={() => setShowCancel(false)}
                style={{ flex: 1, paddingVertical: s(12), borderRadius: s(10), backgroundColor: "#f5f5f5", alignItems: "center" }}
              >
                <Text style={{ color: Colors.neutral[600], fontSize: s(14) }}>{t("groupLottery.giveUp")}</Text>
              </Pressable>
              <Pressable
                onPress={submitCancel}
                disabled={cancelMut.isPending}
                style={{ flex: 1, paddingVertical: s(12), borderRadius: s(10), alignItems: "center" }}
              >
                <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 10, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 10 }} />
                <Text style={{ color: "#fff", fontSize: s(14), fontWeight: "bold" }}>
                  {cancelMut.isPending ? t("groupLottery.submitting") : t("groupLottery.confirmApply")}
                </Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}
