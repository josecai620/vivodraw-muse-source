import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import * as Localization from "expo-localization";
import AsyncStorage from "@react-native-async-storage/async-storage";

import en from "./locales/en.json";
import zhTW from "./locales/zh-TW.json";

const LANGUAGE_KEY = "app_language";

export const resources = {
  en: { translation: en },
  "zh-TW": { translation: zhTW },
} as const;

export type SupportedLanguage = keyof typeof resources;

export const LANGUAGE_OPTIONS: { code: SupportedLanguage; label: string; nativeLabel: string }[] = [
  { code: "en", label: "English", nativeLabel: "English" },
  { code: "zh-TW", label: "Traditional Chinese", nativeLabel: "繁體中文" },
];

function getDeviceLanguage(): SupportedLanguage {
  try {
    const locales = Localization.getLocales();
    if (!locales?.length) return "en";
    const tag = locales[0].languageTag;
    if (tag.startsWith("zh-Hant") || tag.startsWith("zh-TW") || tag.startsWith("zh-HK") || tag.startsWith("zh-MO")) {
      return "zh-TW";
    }
  } catch {}
  return "en";
}

export async function initI18n() {
  let lng: SupportedLanguage = "en";
  try {
    const savedLang = await AsyncStorage.getItem(LANGUAGE_KEY);
    lng = (savedLang as SupportedLanguage) || getDeviceLanguage();
  } catch {}

  try {
    await i18n.use(initReactI18next).init({
      resources,
      lng,
      fallbackLng: "en",
      interpolation: { escapeValue: false },
      compatibilityJSON: "v4",
    });
  } catch {
    await i18n.use(initReactI18next).init({
      resources,
      lng: "en",
      fallbackLng: "en",
      interpolation: { escapeValue: false },
    });
  }

  return i18n;
}

export async function changeLanguage(lang: SupportedLanguage) {
  await i18n.changeLanguage(lang);
  try {
    await AsyncStorage.setItem(LANGUAGE_KEY, lang);
  } catch {}
}

export default i18n;
