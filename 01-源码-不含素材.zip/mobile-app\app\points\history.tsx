import React, { useMemo, useState } from "react";
import { Pressable, RefreshControl, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { usePointsBalance, usePointsLog } from "@/hooks";
import { localizeAccountLogTitle } from "@/lib/account-log-title";
import { fetchPetDeskBond } from "@/lib/api/petWorld";
import { unwrapApiData } from "@/lib/api/response";
import { formatNumber } from "@/lib/utils";
import { useAuthStore } from "@/store/auth";

const TEAL = Colors.primary.DEFAULT;
type Filter = "all" | "in" | "out" | "bond";

function unwrapLogList(value: unknown): any[] {
  const data = unwrapApiData<unknown>(value, []);
  if (Array.isArray(data)) return data;
  if (data && typeof data === "object") {
    const rec = data as Record<string, unknown>;
    if (Array.isArray(rec.list)) return rec.list as any[];
    if (Array.isArray(rec.lists)) return rec.lists as any[];
  }
  return [];
}

function formatBillTime(value: unknown): string {
  const n = Number(value);
  if (Number.isFinite(n) && n > 1e12) return new Date(n).toLocaleString();
  if (Number.isFinite(n) && n > 1e9) return new Date(n * 1000).toLocaleString();
  return String(value ?? "");
}

function billSortKey(value: unknown): number {
  const n = Number(value);
  if (Number.isFinite(n) && n > 0) return n > 1e12 ? n : n > 1e9 ? n * 1000 : n;
  return 0;
}

function isBondLedgerRow(item: any): boolean {
  const category = String(item?.category ?? "");
  const type = String(item?.type ?? "");
  const title = String(item?.title ?? item?.mark ?? "");
  return (
    category === "desk_pet_bond" ||
    type === "desk_pet_bond" ||
    type === "desk_pet_unlock" ||
    title.includes("默契") ||
    title.includes("桌宠") ||
    title.includes("桌寵")
  );
}

function isPointsLedgerRow(item: any): boolean {
  return !isBondLedgerRow(item);
}

function mapBill(item: any, index: number, zh: boolean) {
  const pm = Number(item.pm ?? item.change_type ?? 0);
  const raw = Number(item.number ?? item.integral ?? item.points ?? 0);
  const income = pm === 1;
  const amount = Math.abs(raw);
  const money = String(item.category ?? "") === "now_money";
  const bond = isBondLedgerRow(item);
  return {
    id: Number(item.id ?? index),
    title: localizeAccountLogTitle({
      title: item.title ?? item.mark,
      mark: item.mark,
      type: item.type,
      zh,
    }),
    time: formatBillTime(item.add_time ?? item.create_time),
    sortAt: billSortKey(item.add_time ?? item.create_time) || Number(item.id ?? index),
    amount,
    income,
    money,
    bond,
    balance: item.balance != null ? Number(item.balance) : null,
  };
}

export default function PointsHistoryScreen() {
  const { t, i18n } = useTranslation();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const user = useAuthStore((s) => s.user);
  const [filter, setFilter] = useState<Filter>("all");
  const [refreshing, setRefreshing] = useState(false);
  const zh = !String(i18n.language || "").toLowerCase().startsWith("en");
  const bondTab = filter === "bond";
  const { data: pointsData, isLoading: pointsLoading } = usePointsLog(1, "points");
  const { data: bondData, isLoading: bondLoading } = usePointsLog(1, "bond");
  const isLoading = bondTab ? bondLoading : pointsLoading || bondLoading;
  const { data: balanceData } = usePointsBalance();
  const { data: bondStatus } = useQuery({
    queryKey: ["deskBond", "account-log"],
    queryFn: () => fetchPetDeskBond(),
    enabled: bondTab,
  });

  const points = Number(
    (balanceData as any)?.data?.integral ?? (balanceData as any)?.integral ?? user?.integral ?? 0,
  );
  const currentBond = Number(bondStatus?.intimacyValue ?? 0);

  const rows = useMemo(() => {
    const pointsRows = unwrapLogList(pointsData)
      .filter(isPointsLedgerRow)
      .map((item, index) => mapBill(item, index, zh));
    const bondRows = unwrapLogList(bondData)
      .filter(isBondLedgerRow)
      .map((item, index) => mapBill(item, index + 1000, zh));
    if (bondTab) return bondRows;
    if (filter === "all") {
      return [...bondRows, ...pointsRows].sort((a, b) => b.sortAt - a.sortAt || b.id - a.id);
    }
    return pointsRows;
  }, [pointsData, bondData, bondTab, filter, zh]);

  const shown = rows.filter((row) => {
    if (filter === "in") return row.income;
    if (filter === "out") return !row.income;
    return true;
  });

  const moneyTabs: { key: Filter; label: string }[] = [
    { key: "all", label: t("pointsMall.logAll") },
    { key: "in", label: t("pointsMall.logIncome") },
    { key: "out", label: t("pointsMall.logExpense") },
  ];

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.accountLog")} />
      <View className="mx-3 mt-3 mb-2 rounded-xl px-3 py-3 bg-white" style={{ borderWidth: 1, borderColor: Colors.screen.hairline }}>
        <Text className="text-xs text-gray-500">{bondTab ? t("pointsMall.currentBond") : t("pointsMall.currentPoints")}</Text>
        <Text className="text-xl font-black mt-1" style={{ color: TEAL }}>
          {formatNumber(bondTab ? currentBond : points)}
        </Text>
        <Text className="text-[11px] text-gray-400 mt-2 leading-4">
          {bondTab ? t("pointsMall.bondHint") : t("pointsMall.logHint")}
        </Text>
      </View>
      <View className="flex-row items-center justify-between bg-white px-3">
        <View className="flex-row" style={{ gap: 16 }}>
          {moneyTabs.map((tab) => {
            const on = filter === tab.key;
            return (
              <Pressable key={tab.key} className="px-1 py-2.5" onPress={() => setFilter(tab.key)}>
                <Text
                  className="text-sm font-bold"
                  style={{
                    color: on ? TEAL : "#6B7280",
                    borderBottomWidth: on ? 2 : 0,
                    borderBottomColor: TEAL,
                    paddingBottom: 3,
                  }}
                >
                  {tab.label}
                </Text>
              </Pressable>
            );
          })}
        </View>
        <Pressable className="px-1 py-2.5" onPress={() => setFilter("bond")}>
          <Text
            className="text-sm font-bold"
            style={{
              color: TEAL,
              borderBottomWidth: bondTab ? 2 : 0,
              borderBottomColor: TEAL,
              paddingBottom: 3,
            }}
          >
            {t("pointsMall.logBond")}
          </Text>
        </Pressable>
      </View>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={async () => {
              setRefreshing(true);
              await qc.invalidateQueries({ queryKey: ["pointsLog"] });
              await qc.invalidateQueries({ queryKey: ["deskBond", "account-log"] });
              setRefreshing(false);
            }}
            tintColor={TEAL}
          />
        }
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}
      >
        {isLoading ? (
          <Text className="text-center text-gray-400 py-16">{t("common.loading")}</Text>
        ) : shown.length === 0 ? (
          <Text className="text-center text-gray-400 py-16">{t("pointsMall.noAccountLog")}</Text>
        ) : (
          shown.map((row) => (
            <View key={`${row.bond ? "b" : "p"}-${row.id}`} className="flex-row items-center bg-white px-3 py-3 border-b border-gray-100">
              <View className="flex-1 pr-3">
                <Text className="text-sm text-gray-900" numberOfLines={2}>
                  {row.title || t("pointsMall.accountLog")}
                </Text>
                <Text className="text-xs text-gray-400 mt-1">{row.time}</Text>
              </View>
              <View className="items-end">
                <Text className="text-sm font-bold" style={{ color: row.income ? TEAL : "#111827" }}>
                  {row.income ? "+" : "-"}
                  {row.money ? "$" : ""}
                  {row.amount}
                </Text>
                {row.balance != null ? (
                  <Text className="text-[11px] text-gray-400 mt-0.5">
                    {row.bond ? t("pointsMall.bondBalance") : t("pointsMall.balance")} {row.balance}
                  </Text>
                ) : null}
              </View>
            </View>
          ))
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
