/**
 * 可验算揭晓——前端本地复算（T10）。
 *
 * 与 yunmall-hybrid/packages/domain/src/drawMath.ts、backend DrawService::compute 同一公式（huigou-public-v1）：
 *   sum100：全站最近 100 条参与记录的 9 位时间键（HHmmss+毫秒）相加 = S；x100：不足 100 条时只取满员记录的时间键 ×100 = S
 *   M = S mod 总人次；幸运码 = 10000001 + M
 *
 * 这里只做「按页面公示的数字重算一遍」给用户看对不对；权威结果永远来自服务端快照，前端不得伪造。
 */

export const LUCKY_CODE_BASE = 10000001;
export const DRAW_WINDOW_SIZE = 100;

export type DrawMode = "sum100" | "x100";

export interface RevealInput {
  seq: number;
  recordId: number;
  recordProductId: number;
  recordPeriodNo: number;
  atMs: number;
  timeKey: string;
  displayName: string;
}

export interface RevealWinner {
  uid: number;
  displayName: string;
  codeRanges: Array<[number, number]>;
  hitCode: number;
}

export interface RevealView {
  periodId: string;
  productId: number;
  periodNo: number;
  status: "snapshot_frozen" | "revealing" | "resolved" | "error";
  formulaVersion: string;
  formulaSteps: string[];
  tz: string;
  totalShares: number;
  windowCount: number;
  mode: DrawMode;
  inputs: RevealInput[];
  sum: number | null;
  modulo: number | null;
  luckyCode: number | null;
  contentHash: string;
  holdersHash: string;
  frozenAt: number;
  revealAt: number;
  resolvedAt: number | null;
  winner: RevealWinner | null;
  product: { name: string; image: string };
  kaijiangId: number;
  my: { codes: number[]; won: boolean } | null;
}

export interface DrawMath {
  sum: number;
  modulo: number;
  luckyCode: number;
}

export interface LocalVerifyReport {
  ok: boolean;
  recomputed: DrawMath | null;
  mismatches: string[];
}

const TIME_KEY_RE = /^\d{1,9}$/;

export function computeDraw(mode: DrawMode, timeKeys: string[], totalShares: number): DrawMath {
  if (!Number.isInteger(totalShares) || totalShares <= 0) {
    throw new Error("totalShares must be a positive integer");
  }
  for (const k of timeKeys) {
    if (!TIME_KEY_RE.test(k)) throw new Error(`invalid timeKey: ${k}`);
  }
  let sum: number;
  if (mode === "sum100") {
    if (timeKeys.length !== DRAW_WINDOW_SIZE) throw new Error(`sum100 requires exactly ${DRAW_WINDOW_SIZE} inputs`);
    sum = timeKeys.reduce((acc, k) => acc + Number(k), 0);
  } else if (mode === "x100") {
    if (timeKeys.length !== 1) throw new Error("x100 requires exactly one input");
    sum = Number(timeKeys[0]) * 100;
  } else {
    throw new Error(`unknown mode: ${String(mode)}`);
  }
  if (!Number.isSafeInteger(sum)) throw new Error("sum overflow");
  const modulo = sum % totalShares;
  return { sum, modulo, luckyCode: LUCKY_CODE_BASE + modulo };
}

/** 按 RevealView 公示的 inputs 本地重算，与服务端存的 sum/modulo/luckyCode 逐项比对（未开奖时只重算不比对） */
export function verifyRevealView(view: RevealView): LocalVerifyReport {
  let recomputed: DrawMath;
  try {
    recomputed = computeDraw(view.mode, view.inputs.map((i) => i.timeKey), view.totalShares);
  } catch (e) {
    return { ok: false, recomputed: null, mismatches: [(e as Error).message] };
  }
  const mismatches: string[] = [];
  if (view.sum !== null && view.sum !== recomputed.sum) mismatches.push(`sum stored ${view.sum} != recomputed ${recomputed.sum}`);
  if (view.modulo !== null && view.modulo !== recomputed.modulo) mismatches.push(`modulo stored ${view.modulo} != recomputed ${recomputed.modulo}`);
  if (view.luckyCode !== null && view.luckyCode !== recomputed.luckyCode) mismatches.push(`luckyCode stored ${view.luckyCode} != recomputed ${recomputed.luckyCode}`);
  if (view.winner && view.luckyCode !== null) {
    const hit = view.winner.hitCode;
    const held = view.winner.codeRanges.some(([lo, hi]) => hit >= lo && hit <= hi);
    if (!held) mismatches.push(`winner.hitCode ${hit} not within winner.codeRanges`);
    if (hit !== view.luckyCode) mismatches.push(`winner.hitCode ${hit} != luckyCode ${view.luckyCode}`);
  }
  return { ok: mismatches.length === 0, recomputed, mismatches };
}

/** 毫秒时间戳 → 「HH:mm:ss.mmm」，按快照声明的时区展示（与时间键同源） */
export function formatAtMs(atMs: number, tz: string): { date: string; time: string } {
  const d = new Date(atMs);
  try {
    const date = new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
    const time = new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(d);
    return { date, time: `${time}.${String(atMs % 1000).padStart(3, "0")}` };
  } catch {
    return { date: d.toISOString().slice(0, 10), time: d.toISOString().slice(11, 23) };
  }
}

/** 9 位时间键拆成 HH mm ss mmm 便于用户对照 */
export function splitTimeKey(timeKey: string): { hh: string; mm: string; ss: string; ms: string } {
  const k = timeKey.padStart(9, "0");
  return { hh: k.slice(0, 2), mm: k.slice(2, 4), ss: k.slice(4, 6), ms: k.slice(6, 9) };
}

export function formatCodeRanges(ranges: Array<[number, number]>): string {
  return ranges.map(([lo, hi]) => (lo === hi ? String(lo) : `${lo}–${hi}`)).join(", ");
}
