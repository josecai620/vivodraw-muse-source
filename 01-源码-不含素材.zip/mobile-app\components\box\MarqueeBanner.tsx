import React, { useEffect, useRef } from "react";
import { View, Text, Animated as RNAnimated, type ViewStyle } from "react-native";
import { User } from "lucide-react-native";
import { RarityBadge } from "./RarityBadge";
import { BoxAccent, BoxText, BoxBorders, BoxTypography, BoxSpacing, bs } from "@/lib/boxTheme";

interface MarqueeItem {
  username: string;
  itemName: string;
  tier?: string;
}

interface MarqueeBannerProps {
  items: MarqueeItem[];
  speed?: number;
  style?: ViewStyle;
}

export function MarqueeBanner({ items, speed = 40000, style }: MarqueeBannerProps) {
  const translateX = useRef(new RNAnimated.Value(0)).current;

  useEffect(() => {
    if (!items.length) return;
    const loop = RNAnimated.loop(
      RNAnimated.timing(translateX, {
        toValue: -1,
        duration: speed,
        useNativeDriver: true,
      })
    );
    loop.start();
    return () => loop.stop();
  }, [items.length, speed]);

  if (!items.length) return null;

  const doubled = [...items, ...items];

  return (
    <View style={[{
      height: bs(36),
      backgroundColor: BoxAccent.goldDim,
      overflow: "hidden",
      justifyContent: "center",
    }, style]}>
      <RNAnimated.View
        style={{
          flexDirection: "row",
          alignItems: "center",
          transform: [{
            translateX: translateX.interpolate({
              inputRange: [-1, 0],
              outputRange: [-items.length * 220, 0],
            }),
          }],
        }}
      >
        {doubled.map((item, i) => {
          const truncatedUser = item.username.length > 10
            ? item.username.slice(0, 10) + "…"
            : item.username;
          const truncatedItem = item.itemName.length > 18
            ? item.itemName.slice(0, 18) + "…"
            : item.itemName;
          return (
            <View key={i} style={{
              flexDirection: "row", alignItems: "center", gap: 6,
              paddingHorizontal: BoxSpacing.sm, paddingVertical: 4,
              backgroundColor: "#FFFFFF", borderRadius: 20,
              borderWidth: 1, borderColor: BoxBorders.default,
              marginRight: 10,
            }}>
              <User size={bs(11)} color={BoxText.tertiary} style={{ marginRight: 4 }} />
              <Text style={[BoxTypography.micro, { color: BoxText.secondary, marginRight: 6 }]}>
                {truncatedUser}
              </Text>
              <Text style={[BoxTypography.micro, { color: BoxAccent.gold, fontWeight: "700", marginRight: 6 }]} numberOfLines={1}>
                {truncatedItem}
              </Text>
              <RarityBadge tier={item.tier} size="sm" />
            </View>
          );
        })}
      </RNAnimated.View>
    </View>
  );
}
