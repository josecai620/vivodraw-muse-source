import { Redirect } from "expo-router";

export default function PointsRulesRedirect() {
  return <Redirect href="/reveal/rules" />;
}
