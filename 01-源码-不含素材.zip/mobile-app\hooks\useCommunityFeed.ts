import { useEffect, useMemo, useState } from "react";

import { fetchCommunityFeed, type CommunityFeedModel } from "@/lib/api/community";

export function useCommunityFeed() {
  const [model, setModel] = useState<CommunityFeedModel>({ source: "fallback", posts: [] });
  const [isLoading, setIsLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setIsLoading(true);

    fetchCommunityFeed()
      .then((nextModel) => {
        if (!cancelled) {
          setModel(nextModel);
        }
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [refreshKey]);

  return useMemo(
    () => ({
      ...model,
      isLoading,
      isFallback: model.source === "fallback",
      refresh: () => setRefreshKey((key) => key + 1),
    }),
    [isLoading, model],
  );
}
