/**
 * 揭晓 API - 对接 CRMEB integral 揭晓相关接口
 */
import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

const EP = API_ENDPOINTS.points.reveal;

/** 积分揭晓首页：zuixin_list + jijiang_list */
export function getRevealIndex() {
  return http.get(EP.index);
}

/** 最新揭晓列表（历史揭晓） */
export function getRevealLists(params?: { cid?: number; page?: number; limit?: number }) {
  return http.get(EP.jiexiaoLists, { params });
}

/** 揭晓商品详情（kaijiang_log id） */
export function getRevealDetail(id: number, pid?: number) {
  return http.get(EP.jiexiaoDetail, { params: { id, pid } });
}

/** 我的揭晓/换取记录 */
export function getRevealMyRecords(params?: { page?: number; limit?: number; status?: number }) {
  return http.get(EP.huandeLists, { params });
}

/** 换取记录详情 */
export function getRevealRecordDetail(params?: { id?: string; uni?: string }) {
  return http.get(EP.huandeInfo, { params });
}

/** 参与揭晓（立即兑换） */
export function participateReveal(data: { productId: number; num?: number; uniqueId?: string }) {
  return http.post(EP.exchange, data);
}
