import React, { useState } from "react";
import { Alert, Image, Platform, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import * as ImagePicker from "expo-image-picker";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { usePostShaidan } from "@/hooks";
import { uploadImage } from "@/lib/api/user";
import { unwrapApiData } from "@/lib/api/response";
import { useAppStore } from "@/store/app";

const TEAL = Colors.primary.DEFAULT;
const MAX_PHOTOS = 6;

export default function ShaidanPostScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const showToast = useAppStore((s) => s.showToast);
  const { productId, name, id } = useLocalSearchParams<{ productId?: string; name?: string; id?: string }>();
  const [title, setTitle] = useState(String(name ?? ""));
  const [content, setContent] = useState("");
  const [images, setImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const post = usePostShaidan();

  const uploadFile = async (file: File | Blob, filename: string) => {
    const formData = new FormData();
    formData.append("filename", file, filename);
    const uploadRes = await uploadImage(formData);
    const { url } = unwrapApiData<{ url?: string }>(uploadRes, {});
    if (!url) throw new Error("No URL returned");
    setImages((rows) => (rows.includes(url) ? rows : [...rows, url].slice(0, MAX_PHOTOS)));
  };

  const pickWeb = () => {
    if (typeof document === "undefined") return;
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/jpeg,image/png,image/webp";
    input.multiple = true;
    input.onchange = async () => {
      const files = Array.from(input.files || []).slice(0, Math.max(0, MAX_PHOTOS - images.length));
      if (!files.length) return;
      setUploading(true);
      try {
        for (const file of files) {
          await uploadFile(file, file.name);
        }
      } catch (err: unknown) {
        showToast(err instanceof Error ? err.message : t("common.failed"), "error");
      } finally {
        setUploading(false);
      }
    };
    input.click();
  };

  const pickNative = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return;
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      quality: 0.8,
      allowsMultipleSelection: true,
    });
    if (result.canceled) return;
    setUploading(true);
    try {
      for (const asset of result.assets.slice(0, Math.max(0, MAX_PHOTOS - images.length))) {
        const res = await fetch(asset.uri);
        const blob = await res.blob();
        await uploadFile(blob, asset.fileName || `photo-${Date.now()}.jpg`);
      }
    } catch (err: unknown) {
      showToast(err instanceof Error ? err.message : t("common.failed"), "error");
    } finally {
      setUploading(false);
    }
  };

  const submit = async () => {
    if (title.trim().length < 2 || content.trim().length < 4) {
      Alert.alert(t("common.notice"), t("pointsMall.postShowcaseHint"));
      return;
    }
    await post.mutateAsync({
      id: Number(id ?? productId ?? 0) || undefined,
      title: title.trim(),
      content: content.trim(),
      images,
    });
    router.replace("/points/reviews?tab=my" as never);
  };

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.postShowcase")} />
      <ScrollView contentContainerStyle={{ padding: 12, paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 16 }}>
        <Text className="text-xs text-gray-500 mb-2">{t("pointsMall.postShowcaseTitle")}</Text>
        <TextInput
          value={title}
          onChangeText={setTitle}
          className="bg-white rounded px-3 h-11 text-sm text-gray-900"
          placeholder={t("pointsMall.pointsProduct")}
          placeholderTextColor="#9CA3AF"
        />
        <TextInput
          value={content}
          onChangeText={setContent}
          multiline
          className="bg-white rounded px-3 py-3 text-sm text-gray-900 mt-3"
          style={{ minHeight: 140, textAlignVertical: "top" }}
          placeholder={t("pointsMall.postShowcaseHint")}
          placeholderTextColor="#9CA3AF"
        />
        <View className="flex-row flex-wrap mt-3" style={{ gap: 8 }}>
          {images.map((url) => (
            <View key={url} className="w-20 h-20 rounded overflow-hidden bg-gray-100">
              <Image source={{ uri: url }} className="w-full h-full" resizeMode="cover" />
              <Pressable
                className="absolute right-0 top-0 px-1 bg-black/50"
                onPress={() => setImages((rows) => rows.filter((item) => item !== url))}
              >
                <Text className="text-white text-[10px]">{t("pointsMall.removePhoto")}</Text>
              </Pressable>
            </View>
          ))}
        </View>
        {images.length < MAX_PHOTOS ? (
          <Pressable
            className="mt-3 h-10 rounded items-center justify-center bg-white"
            style={{ borderWidth: 1, borderColor: TEAL }}
            onPress={() => (Platform.OS === "web" ? pickWeb() : void pickNative())}
            disabled={uploading}
          >
            <Text className="text-sm font-bold" style={{ color: TEAL }}>
              {uploading ? t("common.submitting") : t("pointsMall.addPhotos")}
            </Text>
          </Pressable>
        ) : null}
        <Text className="text-xs text-gray-400 mt-3 leading-5">{t("pointsMall.showcaseRewardHint")}</Text>
        <Pressable
          className="h-11 rounded items-center justify-center mt-4"
          style={{ backgroundColor: TEAL }}
          onPress={submit}
          disabled={post.isPending || uploading}
        >
          <Text className="text-white font-bold">
            {post.isPending ? t("common.submitting") : t("pointsMall.submitShowcase")}
          </Text>
        </Pressable>
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
