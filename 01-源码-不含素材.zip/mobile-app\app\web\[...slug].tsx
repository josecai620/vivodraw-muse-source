import { Stack, useFocusEffect, useLocalSearchParams, useRouter } from "expo-router";
/**
 * 通用 WebView 容器 — 混合 app 的"网页兜底"
 *
 * 路由示例：
 *   router.push('/web/pages/index/index')           -> WEB_BASE_URL + /pages/index/index
 *   router.push('/web/activity/2025-double11?from=app')
 *   router.push({ pathname: '/web/[...slug]', params: { slug: ['news','123'], title: '资讯详情' } })
 *
 * 功能：
 *   - 自动注入 auth token 到 H5 的 localStorage / window.__APP_TOKEN__，登录态共享
 *   - 自定义 UA 带 EccomallApp 标识，H5 据此隐藏自己的 tab bar / 顶部导航
 *   - 原生 → H5 / H5 → 原生 桥接（postMessage）
 *   - 加载失败 / 断网的友好提示 + 重试
 *   - 安卓物理返回键按 WebView 历史回退
 */
import React, { useCallback, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  BackHandler,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { WebView, type WebViewMessageEvent, type WebViewNavigation } from "react-native-webview";
import { WifiOff } from "lucide-react-native";

import { APP_UA_MARKER, WEB_BASE_URL } from "@/constants/env";
import { BRIDGE_INJECT_SCRIPT, type BridgeMessage, handleBridgeMessage } from "@/lib/native/bridge";
import { useAuthStore } from "@/store/auth";

export default function WebScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{
    slug?: string | string[];
    title?: string;
    q?: string; // 可选 query string，形如 "a=1&b=2"
  }>();
  const token = useAuthStore((s) => s.token);

  const webViewRef = useRef<WebView>(null);
  const canGoBackRef = useRef(false);

  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [title, setTitle] = useState<string>(typeof params.title === "string" ? params.title : "");

  const targetUrl = useMemo(() => {
    const slugs = Array.isArray(params.slug) ? params.slug : params.slug ? [params.slug] : [];
    const path = slugs.map(encodeURIComponent).join("/");
    const base = `${WEB_BASE_URL}/${path}`;
    const query = typeof params.q === "string" && params.q ? params.q : "";
    // 始终带一个 inApp=1 让 H5 识别出运行在 app 内
    const sep = base.includes("?") ? "&" : "?";
    const withFlag = `${base}${sep}inApp=1`;
    return query ? `${withFlag}&${query}` : withFlag;
  }, [params.slug, params.q]);

  /**
   * 页面还没开始加载 JS 前就注入 token，避免 H5 首个请求丢掉认证。
   * CRMEB H5 若读取 localStorage.token 作为 Bearer，可直接用。
   */
  const injectedBeforeLoad = useMemo(() => {
    const safeToken = token ? JSON.stringify(token) : "null";
    return `
      (function () {
        try {
          var t = ${safeToken};
          if (t) {
            window.__APP_TOKEN__ = t;
            window.localStorage.setItem('token', t);
            window.localStorage.setItem('LoginUserInfo_token', t);
          }
          window.__IN_APP__ = true;
        } catch (e) {}
        true;
      })();
      ${BRIDGE_INJECT_SCRIPT}
    `;
  }, [token]);

  /** H5 → 原生 的消息入口，统一走 bridge 模块 */
  const onMessage = useCallback(
    (event: WebViewMessageEvent) => {
      let msg: BridgeMessage | null = null;
      try {
        msg = JSON.parse(event.nativeEvent.data);
      } catch {
        return;
      }
      if (!msg || typeof msg !== "object" || typeof msg.type !== "string") return;

      void handleBridgeMessage(msg, {
        router,
        webViewRef,
        setTitle,
      });
    },
    [router],
  );

  const onNavigationChange = useCallback((nav: WebViewNavigation) => {
    canGoBackRef.current = nav.canGoBack;
  }, []);

  // 安卓物理返回键：优先让 WebView 回退
  useFocusEffect(
    useCallback(() => {
      if (Platform.OS !== "android") return;
      const sub = BackHandler.addEventListener("hardwareBackPress", () => {
        if (canGoBackRef.current && webViewRef.current) {
          webViewRef.current.goBack();
          return true;
        }
        return false;
      });
      return () => sub.remove();
    }, []),
  );

  const handleRetry = useCallback(() => {
    setErrorMsg(null);
    setLoading(true);
    webViewRef.current?.reload();
  }, []);

  return (
    <View style={styles.container}>
      <Stack.Screen options={{ title: title || "加载中", headerBackTitle: "返回" }} />

      <WebView
        ref={webViewRef}
        source={{ uri: targetUrl }}
        // UA 让 H5 识别 app
        applicationNameForUserAgent={APP_UA_MARKER}
        originWhitelist={["http://*", "https://*"]}
        injectedJavaScriptBeforeContentLoaded={injectedBeforeLoad}
        onMessage={onMessage}
        onNavigationStateChange={onNavigationChange}
        onLoadStart={() => setLoading(true)}
        onLoadEnd={() => setLoading(false)}
        onError={(e) => {
          setLoading(false);
          setErrorMsg(e.nativeEvent.description || "加载失败");
        }}
        onHttpError={(e) => {
          // 4xx/5xx 给个提示，但不一定拦截（有些接口 401 是正常业务流）
          const code = e.nativeEvent.statusCode;
          if (code >= 500) {
            setErrorMsg(`服务器错误 (${code})`);
          }
        }}
        javaScriptEnabled
        domStorageEnabled
        startInLoadingState={false}
        sharedCookiesEnabled
        thirdPartyCookiesEnabled
        allowsBackForwardNavigationGestures
        setSupportMultipleWindows={false}
        pullToRefreshEnabled
        decelerationRate="normal"
        style={styles.webview}
      />

      {loading && !errorMsg && (
        <View style={styles.overlay} pointerEvents="none">
          <ActivityIndicator size="large" color="#04A8AE" />
        </View>
      )}

      {errorMsg && (
        <View style={styles.errorOverlay}>
          <WifiOff size={48} color="#919290" strokeWidth={1.6} style={{ marginBottom: 16 }} />
          <Text style={styles.errorTitle}>页面加载失败</Text>
          <Text style={styles.errorDesc}>{errorMsg}</Text>
          <Pressable style={styles.retryBtn} onPress={handleRetry}>
            <Text style={styles.retryText}>重新加载</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  webview: { flex: 1, backgroundColor: "#fff" },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
  },
  errorOverlay: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#fff",
    paddingHorizontal: 32,
  },
  errorEmoji: { fontSize: 48, marginBottom: 16 },
  errorTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#333",
    marginBottom: 8,
  },
  errorDesc: {
    fontSize: 14,
    color: "#666",
    textAlign: "center",
    marginBottom: 24,
  },
  retryBtn: {
    backgroundColor: "#EF4444",
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  retryText: { color: "#fff", fontWeight: "600", fontSize: 16 },
});
