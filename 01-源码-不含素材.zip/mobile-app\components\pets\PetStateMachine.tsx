import type { ReactNode } from "react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { getPetActionDurationMs, getPetBehaviorConfig, pickRandomPetAction, type PetActionName } from "@/lib/pet-animations";
import type { PixelDeskPetId } from "@/lib/pets";

type PetStateMachineOptions = {
  petId: PixelDeskPetId;
  inactiveAfterMs?: number;
};

export type PetStateMachineApi = {
  action: PetActionName;
  isVisible: boolean;
  tap: () => void;
  receiveMessage: () => void;
  startDrag: () => void;
  endDrag: () => void;
  hideLaptop: () => void;
  wake: () => void;
};

export function usePetStateMachine({ petId, inactiveAfterMs }: PetStateMachineOptions): PetStateMachineApi {
  const behavior = useMemo(() => getPetBehaviorConfig(petId), [petId]);
  const sleepAfterMs = inactiveAfterMs ?? behavior.inactiveAfterMs;
  const [action, setActionState] = useState<PetActionName>("idle");
  const actionRef = useRef<PetActionName>("idle");
  const lastInteractionRef = useRef(Date.now());
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const clearTimer = useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
  }, []);

  const setAction = useCallback(
    (nextAction: PetActionName) => {
      actionRef.current = nextAction;
      setActionState(nextAction);
    },
    [],
  );

  const markInteraction = useCallback(() => {
    lastInteractionRef.current = Date.now();
  }, []);

  const setTemporaryAction = useCallback(
    (nextAction: PetActionName, nextAfterComplete: PetActionName = "idle") => {
      clearTimer();
      setAction(nextAction);

      timeoutRef.current = setTimeout(() => {
        setAction(nextAfterComplete);
      }, getPetActionDurationMs(petId, nextAction));
    },
    [clearTimer, petId, setAction],
  );

  const wake = useCallback(() => {
    markInteraction();
    clearTimer();
    setAction(behavior.defaultAction);
  }, [behavior.defaultAction, clearTimer, markInteraction, setAction]);

  const tap = useCallback(() => {
    markInteraction();

    if (actionRef.current === behavior.inactiveAction) {
      clearTimer();
      setAction(behavior.defaultAction);
      return;
    }

    setTemporaryAction(pickRandomPetAction(behavior.clickPool, behavior.defaultAction), behavior.defaultAction);
  }, [behavior, clearTimer, markInteraction, setAction, setTemporaryAction]);

  const receiveMessage = useCallback(() => {
    markInteraction();
    setTemporaryAction(pickRandomPetAction(behavior.messagePool, behavior.defaultAction), behavior.defaultAction);
  }, [behavior, markInteraction, setTemporaryAction]);

  const startDrag = useCallback(() => {
    markInteraction();
    clearTimer();
    setAction(behavior.dragAction);
  }, [behavior.dragAction, clearTimer, markInteraction, setAction]);

  const endDrag = useCallback(() => {
    markInteraction();
    clearTimer();
    setAction(behavior.dragEndAction);
  }, [behavior.dragEndAction, clearTimer, markInteraction, setAction]);

  const hideLaptop = useCallback(() => {
    markInteraction();
    setTemporaryAction("hideLaptop", "disappear");
  }, [markInteraction, setTemporaryAction]);

  useEffect(() => {
    clearTimer();

    if (action !== behavior.defaultAction) {
      return undefined;
    }

    timeoutRef.current = setTimeout(() => {
      if (Date.now() - lastInteractionRef.current >= sleepAfterMs) {
        setAction(behavior.inactiveAction);
      }
    }, sleepAfterMs);

    return clearTimer;
  }, [action, behavior.defaultAction, behavior.inactiveAction, clearTimer, setAction, sleepAfterMs]);

  useEffect(() => {
    wake();
    return clearTimer;
  }, [clearTimer, petId, wake]);

  return useMemo(
    () => ({
      action,
      isVisible: action !== "disappear",
      tap,
      receiveMessage,
      startDrag,
      endDrag,
      hideLaptop,
      wake,
    }),
    [action, endDrag, hideLaptop, receiveMessage, startDrag, tap, wake],
  );
}

export function PetStateMachine({
  children,
  ...options
}: PetStateMachineOptions & {
  children: (api: PetStateMachineApi) => ReactNode;
}) {
  const api = usePetStateMachine(options);
  return <>{children(api)}</>;
}
