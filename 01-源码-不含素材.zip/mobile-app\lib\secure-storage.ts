import { Platform } from "react-native";
import * as SecureStore from "expo-secure-store";

// expo-secure-store 在 Web 平台同步抛异常（不支持 Keychain / KeyStore）。
// 为了让 Expo Web build（https://vivodraw.com）也能登录，在 Web 上 fallback 到 localStorage。
// 注意：localStorage 不加密，仅作为 session 持久化手段；原生平台照旧走 SecureStore。

const isWeb = Platform.OS === "web";

const hasLocalStorage = (): boolean => {
  try {
    return typeof window !== "undefined" && !!window.localStorage;
  } catch {
    return false;
  }
};

export async function setItem(key: string, value: string): Promise<void> {
  if (isWeb) {
    if (hasLocalStorage()) {
      try {
        window.localStorage.setItem(key, value);
      } catch (e) {
        console.warn("[secure-storage] localStorage setItem failed:", e);
      }
    }
    return;
  }
  try {
    await SecureStore.setItemAsync(key, value);
  } catch (e) {
    console.warn("[secure-storage] SecureStore setItemAsync failed:", e);
  }
}

export async function getItem(key: string): Promise<string | null> {
  if (isWeb) {
    if (hasLocalStorage()) {
      try {
        return window.localStorage.getItem(key);
      } catch {
        return null;
      }
    }
    return null;
  }
  try {
    return await SecureStore.getItemAsync(key);
  } catch {
    return null;
  }
}

export async function deleteItem(key: string): Promise<void> {
  if (isWeb) {
    if (hasLocalStorage()) {
      try {
        window.localStorage.removeItem(key);
      } catch {
        /* noop */
      }
    }
    return;
  }
  try {
    await SecureStore.deleteItemAsync(key);
  } catch {
    /* noop */
  }
}
