import type { VFXPresetConfig } from '../core/VFXConfig';

export const oreFirePreset: VFXPresetConfig = { // oreFirePreset：火属性矿石特效
  id: 'fire',
  label: 'fire',
  glow: {
    enabled: true,
    glowColor: 0x07858c,
    glowStrength: 0.92,
    glowSpeed: 1.1,
  },
  flow: {
    enabled: true,
    flowColor: 0x33c6cc,
    flowSpeed: 0.92,
    sweepSpeed: 0.72,
  },
  energy: {
    enabled: true,
    energyColor: 0x08aeb4,
    energyWaveSize: 0.86,
    energyWaveStrength: 0.72,
  },
  explosion: {
    enabled: true,
    explosionStrength: 0.58,
    explosionDuration: 0.72,
  },
  fire: {
    enabled: true,
    fireIntensity: 1,
    fireSpeed: 1.15,
  },
  spark: {
    enabled: true,
    particleColor: 0x9fe4e6,
    particleCount: 42,
    particleSize: 0.96,
  },
};
