/**
 * 新人礼包（Premium Dark Gaming UI）
 */
import React from "react";
import { View, Text, ActivityIndicator } from "react-native";
import { useTranslation } from "react-i18next";
import { LinearGradient } from "expo-linear-gradient";
import {
  Gift, Coins, Box, CheckCircle2, Clock, PartyPopper,
} from "lucide-react-native";
import { BoxHeader, BoxActionButton } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, bs,
} from "@/lib/boxTheme";
import { useNewbieCheck, useNewbieClaim } from "@/hooks";
import { useAppStore } from "@/store/app";

export default function NewbiePage() {
  const { t } = useTranslation();
  const showToast = useAppStore((s) => s.showToast);
  const { data, isLoading, refetch } = useNewbieCheck();
  const claimMutation = useNewbieClaim();

  const handleClaim = () => {
    claimMutation.mutate(undefined, {
      onSuccess: (res: any) => {
        const msg = res?.data?.message || t("newbie.claimSuccess");
        showToast(msg, "success");
        refetch();
      },
      onError: () => showToast(t("newbie.claimFail"), "error"),
    });
  };

  const claimed = data?.claimed;
  const eligible = data?.eligible;
  const daysLeft = Math.max(0, 7 - (data?.daysSinceRegister || 0));
  const preview = data?.rewardPreview || {};

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("newbie.title")} />

      {isLoading ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator size="large" color={BoxAccent.purple} />
        </View>
      ) : (
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(100) }}>
          {/* Hero card */}
          <LinearGradient
            colors={
              claimed
                ? [BoxSurfaces.elevated, BoxSurfaces.deep]
                : [BoxAccent.purpleDark, BoxAccent.purple, BoxAccent.purpleLight]
            }
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{
              borderRadius: BoxRadius["2xl"],
              padding: BoxSpacing["3xl"],
              alignItems: "center",
              gap: BoxSpacing.md,
              marginBottom: BoxSpacing["2xl"],
              ...(claimed ? BoxShadows.subtle : BoxShadows.glow(BoxAccent.purple)),
              borderWidth: 1,
              borderColor: claimed ? BoxBorders.default : BoxAccent.purpleBorder,
            }}
          >
            <View style={{
              width: bs(80),
              height: bs(80),
              borderRadius: BoxRadius.full,
              backgroundColor: "rgba(255,255,255,0.12)",
              alignItems: "center",
              justifyContent: "center",
              marginBottom: BoxSpacing.xs,
            }}>
              {claimed ? (
                <CheckCircle2 size={bs(48)} color={BoxAccent.green} />
              ) : (
                <Gift size={bs(48)} color={BoxText.onGold} />
              )}
            </View>

            <Text style={[BoxTypography.h1, { color: claimed ? BoxText.primary : BoxText.onGold }]}>
              {claimed ? t("newbie.claimed") : t("newbie.welcome")}
            </Text>
            <Text style={[BoxTypography.body, { color: claimed ? BoxText.secondary : "rgba(255,255,255,0.85)", textAlign: "center" }]}>
              {claimed
                ? t("newbie.rewardSent")
                : preview.description || t("newbie.defaultPreview")}
            </Text>

            {!claimed && eligible && (
              <View style={{
                flexDirection: "row",
                alignItems: "center",
                gap: BoxSpacing.sm,
                marginTop: BoxSpacing.xs,
              }}>
                <Clock size={bs(14)} color="rgba(255,255,255,0.8)" />
                <Text style={[BoxTypography.caption, { color: "rgba(255,255,255,0.8)" }]}>
                  {t("newbie.daysLeft", { count: daysLeft })}
                </Text>
              </View>
            )}
          </LinearGradient>

          {/* Rewards section */}
          <Text style={[BoxTypography.h3, { color: BoxText.primary, marginBottom: BoxSpacing.md }]}>
            {t("newbie.sectionTitle")}
          </Text>

          {/* Points reward */}
          <View style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: BoxSurfaces.card,
            borderRadius: BoxRadius.xl,
            padding: BoxSpacing.lg,
            gap: BoxSpacing.lg,
            marginBottom: BoxSpacing.md,
            borderWidth: 1,
            borderColor: BoxBorders.default,
          }}>
            <View style={{
              width: bs(48),
              height: bs(48),
              borderRadius: BoxRadius.lg,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: BoxAccent.goldMuted,
            }}>
              <Coins size={bs(24)} color={BoxAccent.gold} />
            </View>
            <View style={{ flex: 1, gap: 2 }}>
              <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>
                {t("newbie.pointsLabel", { count: preview.points || 100 })}
              </Text>
              <Text style={[BoxTypography.caption, { color: BoxText.tertiary }]}>
                {t("newbie.pointsDesc")}
              </Text>
            </View>
            {claimed && <CheckCircle2 size={bs(20)} color={BoxAccent.green} />}
          </View>

          {/* Free opens reward */}
          <View style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: BoxSurfaces.card,
            borderRadius: BoxRadius.xl,
            padding: BoxSpacing.lg,
            gap: BoxSpacing.lg,
            marginBottom: BoxSpacing.md,
            borderWidth: 1,
            borderColor: BoxBorders.default,
          }}>
            <View style={{
              width: bs(48),
              height: bs(48),
              borderRadius: BoxRadius.lg,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: BoxAccent.purpleMuted,
            }}>
              <Box size={bs(24)} color={BoxAccent.purpleLight} />
            </View>
            <View style={{ flex: 1, gap: 2 }}>
              <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>
                {t("newbie.freeOpensLabel", { count: preview.free_opens || 1 })}
              </Text>
              <Text style={[BoxTypography.caption, { color: BoxText.tertiary }]}>
                {t("newbie.freeOpensDesc")}
              </Text>
            </View>
            {claimed && <CheckCircle2 size={bs(20)} color={BoxAccent.green} />}
          </View>

          {/* Claim button */}
          {!claimed && eligible && (
            <BoxActionButton
              title={t("newbie.claimNow")}
              variant="primary"
              icon={<PartyPopper size={bs(20)} color={BoxText.onGold} />}
              loading={claimMutation.isPending}
              disabled={claimMutation.isPending}
              onPress={handleClaim}
              style={{ marginTop: BoxSpacing["2xl"] }}
            />
          )}

          {/* Expired banner */}
          {!claimed && !eligible && (
            <View style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: BoxSpacing.sm,
              marginTop: BoxSpacing["2xl"],
              backgroundColor: BoxSurfaces.card,
              borderRadius: BoxRadius.lg,
              padding: BoxSpacing.lg,
              borderWidth: 1,
              borderColor: BoxBorders.default,
            }}>
              <Clock size={bs(18)} color={BoxText.tertiary} />
              <Text style={[BoxTypography.body, { color: BoxText.secondary }]}>
                {t("newbie.expired")}
              </Text>
            </View>
          )}
        </View>
      )}
    </View>
  );
}
