import "../global.css";
import React, { Suspense, lazy, useEffect, useState } from "react";
import { Stack, useGlobalSearchParams, usePathname, useRouter } from "expo-router";
import { useFonts } from "expo-font";
import { StatusBar } from "expo-status-bar";
import { Platform, ActivityIndicator, View, Text, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { CloudOff } from "lucide-react-native";
import { Toast } from "@/components/ui";
import CloudBuyLangFab from "@/components/points/CloudBuyLangFab";
import { TealGradient,  Colors  } from "@/constants/theme";
import { getUserProfile } from "@/lib/api/user";
import { initI18n } from "@/lib/i18n";
import { useAuthStore } from "@/store/auth";
import { PetThemeProvider, usePetTheme } from "@/store/pet-theme";
import { captureReferralAttribution } from "@/lib/获客归因";

const FloatingDeskPetLazy = lazy(() =>
  import("@/components/pets/FloatingDeskPet").then((m) => ({ default: m.FloatingDeskPet })),
);

class DeskPetBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean }> {
  state = { hasError: false };
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  render() {
    return this.state.hasError ? null : this.props.children;
  }
}

function FloatingDeskPetHost() {
  const { isFloatingPetEnabled } = usePetTheme();
  const [ready, setReady] = useState(Platform.OS !== "web");
  useEffect(() => {
    if (Platform.OS !== "web") {
      setReady(true);
      return;
    }
    // 首屏先留给商城和商品资源，挂件稍后加载，不与首屏争抢连接。
    const timer = window.setTimeout(() => setReady(true), 2500);
    return () => window.clearTimeout(timer);
  }, []);
  if (!isFloatingPetEnabled || !ready) return null;
  return (
    <DeskPetBoundary>
      <Suspense fallback={null}>
        <FloatingDeskPetLazy />
      </Suspense>
    </DeskPetBoundary>
  );
}

// Web：与 NativeWind / css-interop 约定一致，避免 darkMode=media 时 colorScheme.set 红屏
if (typeof document !== "undefined") {
  document.documentElement.style.setProperty("--css-interop-darkMode", "class dark");
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5,
      gcTime: 1000 * 60 * 30,
      retry: 2,
      refetchOnWindowFocus: false,
    },
  },
});

class AppErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  render() {
    if (this.state.hasError) {
      return (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: Colors.screen.bg }}>
          <CloudOff size={48} color={Colors.neutral[400]} strokeWidth={1.6} style={{ marginBottom: 16 }} />
          <Text style={{ fontSize: 18, fontWeight: "bold", color: Colors.luxe.ink, marginBottom: 8 }}>
            Something went wrong
          </Text>
          <Text style={{ fontSize: 14, color: Colors.luxe.inkMuted, marginBottom: 24, textAlign: "center", paddingHorizontal: 32 }}>
            The app encountered an unexpected error.
          </Text>
          <Pressable
            style={{ paddingHorizontal: 24, paddingVertical: 12, borderRadius: 999 }}
            onPress={() => this.setState({ hasError: false })}
          >
            <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 999, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
            <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 999 }} />
            <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16 }}>Tap to Retry</Text>
          </Pressable>
        </View>
      );
    }
    return this.props.children;
  }
}

function PearlAwareLangFab() {
  const pathname = usePathname();
  if (pathname === "/pearl") return null;
  return <CloudBuyLangFab />;
}

export default function RootLayout() {
  const [i18nReady, setI18nReady] = useState(false);
  const [fontsLoaded] = useFonts({
    "DM Serif Display": require("../assets/fonts/DMSerifDisplay-Regular.ttf"),
    Manrope: require("../assets/fonts/Manrope-Regular.ttf"),
  });
  const appVisualReady = i18nReady && (Platform.OS === "web" || fontsLoaded);
  const router = useRouter();
  const globalParams = useGlobalSearchParams();
  const referralUid = globalParams.spread;
  const hydrateAuth = useAuthStore((state) => state.hydrate);
  const token = useAuthStore((state) => state.token);
  const isAuthHydrated = useAuthStore((state) => state.isHydrated);
  const setUser = useAuthStore((state) => state.setUser);

  useEffect(() => {
    hydrateAuth().catch(() => {});
  }, [hydrateAuth]);

  useEffect(() => {
    captureReferralAttribution(referralUid);
  }, [referralUid]);

  useEffect(() => {
    if (!isAuthHydrated || !token) return;
    let cancelled = false;

    getUserProfile()
      .then((profileRes: any) => {
        if (cancelled) return;
        const profile = profileRes?.data ?? profileRes;
        if (profile?.uid) setUser(profile);
      })
      .catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [isAuthHydrated, setUser, token]);

  useEffect(() => {
    const unsub = useAuthStore.subscribe((state, prevState) => {
      if (prevState.isLoggedIn && !state.isLoggedIn) {
        queryClient.clear();
        try { router.replace("/auth"); } catch {}
      }
    });
    return unsub;
  }, []);

  useEffect(() => {
    initI18n()
      .then(() => setI18nReady(true))
      .catch(() => setI18nReady(true));
  }, []);

  useEffect(() => {
    if (Platform.OS === "web" && typeof window !== "undefined") {
      window.dispatchEvent(new Event("app-ready"));
    }
  }, []);

  if (!appVisualReady) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: Colors.screen.bg }}>
        <ActivityIndicator size="large" color={Colors.brand.red} />
      </View>
    );
  }

  return (
    <AppErrorBoundary>
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: Colors.screen.bg }}>
      <PetThemeProvider>
      <QueryClientProvider client={queryClient}>
        <StatusBar style="dark" />
        <Stack
          screenOptions={{
            headerShown: false,
            // 方向C：全站页面统一极浅冷灰兜底底，白卡片浮在其上产生层次
            contentStyle: { backgroundColor: Colors.screen.bg },
          }}
        >
          <Stack.Screen name="(tabs)" />
          <Stack.Screen name="product/[id]" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="search/index" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="checkout/index" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="orders/index" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="orders/detail" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="orders/refund" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="orders/review" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="orders/express" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/edit" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/settings" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/notifications" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/change-password" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/language" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/wallet" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/wallet/recharge" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/wallet/withdraw" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/commission" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/commission/people" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/commission/orders" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/address" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/coupons" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/wishlist" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/payment" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/help" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="auth/index" options={{ animation: "fade", presentation: "modal" }} />
          <Stack.Screen name="auth/register" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="auth/forgot-password" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/cart" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/product" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/pay" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/pay-success" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/orders" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/history" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/tasks" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/rules" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/checkin" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/lottery" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/wishlist" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/collection" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/reviews" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/redemptions" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/notifications" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/categories" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/order-detail" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="points/tracking" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="reveal" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="box" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="marketing/index" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="marketing/seckill/index" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="marketing/combination/index" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="marketing/bargain/index" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="marketing/live" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="marketing/presale/index" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="marketing/seckill/[id]" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="marketing/combination/[id]" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="marketing/bargain/[id]" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="group-lottery/index" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="group-lottery/[id]" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="group-lottery/pink/[id]" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="group-lottery/my" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/level" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/member-card" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/avatar-frames" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/messages" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/message/[id]" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/service" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="articles" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/visit-history" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/commission/rank" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/commission/apply" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/commission/promote" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/commission/rules" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="agreement/[type]" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="pearl" options={{ title: "Pearl Lagoon" }} />
          <Stack.Screen name="orders/invoice-apply" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/invoices" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/invoices/add" options={{ animation: "slide_from_right" }} />
          <Stack.Screen name="profile/invoices/edit" options={{ animation: "slide_from_right" }} />
        </Stack>
        <Toast />
        <PearlAwareLangFab />
        <FloatingDeskPetHost />
      </QueryClientProvider>
      </PetThemeProvider>
    </GestureHandlerRootView>
    </AppErrorBoundary>
  );
}
