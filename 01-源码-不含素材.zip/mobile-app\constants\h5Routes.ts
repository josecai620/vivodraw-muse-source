/**
 * H5 路由注册表 — 哪些业务页还在走 H5（通过 WebView 打开）
 *
 * 用途：
 *   1. 给 openWeb() 提供集中维护的路径常量（避免魔法字符串散落代码里）
 *   2. 给新同学看一眼就知道：哪些功能是原生、哪些是 H5
 *   3. 上线前做"原生覆盖率"盘点：清单越短说明原生化程度越高
 *
 * 约定：
 *   - path 不要带前导斜杠和协议；openWeb 会自动拼上 WEB_BASE_URL
 *   - nativeRoute 字段：如果将来做了原生版，在这里备注对应原生路由，方便全局替换
 *
 * 使用示例：
 *   openWeb(router, H5Routes.about.path, { title: H5Routes.about.title });
 */
export type H5Entry = {
  /** 相对 WEB_BASE_URL 的路径（不含协议和域名） */
  path: string;
  /** WebView 顶部标题 */
  title: string;
  /** 如果已经有原生版本，填原生路由，便于将来无缝替换 */
  nativeRoute?: string;
  /** 备注：为什么暂时用 H5（开发成本高 / 活动页随时改 / 其他） */
  note?: string;
};

export const H5Routes = {
  /** 关于我们 */
  about: {
    path: "pages/users/about/index",
    title: "About Us",
    note: "静态页，运营偶尔改，放 H5 最省事",
  },
  /** 用户协议 */
  userAgreement: {
    path: "pages/users/user_agreement/index",
    title: "User Agreement",
    query: { type: "user_agreement" },
  },
  /** 隐私政策 */
  privacyPolicy: {
    path: "pages/users/user_agreement/index",
    title: "Privacy Policy",
    query: { type: "privacy_agreement" },
  },
  /** 常见问题 FAQ */
  faq: {
    path: "pages/users/help/index",
    title: "FAQ",
    nativeRoute: "/profile/help",
  },
  /** 积分规则说明 */
  pointsRules: {
    path: "pages/integral/rules/index",
    title: "Points Rules",
    note: "积分规则文案经常调，用 H5 改完即生效",
  },
  /** 直播列表 */
  liveList: {
    path: "pages/plant_server/live_list/index",
    title: "Live",
    note: "直播组件在 H5 已成熟，RN 重写成本高",
  },
  /** 专题活动页（动态营销页） */
  campaignPage: {
    path: "pages/activity/special/index",
    title: "Campaign",
    note: "活动页经常上下架，走 H5 最灵活",
  },
  /** 分销海报生成 */
  sharePoster: {
    path: "pages/users/share/index",
    title: "Invite & Earn",
    nativeRoute: "/profile/commission",
    note: "海报生成涉及 Canvas，H5 版本已经能用",
  },
  /** 新手引导 */
  onboarding: {
    path: "pages/users/onboarding/index",
    title: "Getting Started",
  },
} as const satisfies Record<string, H5Entry & { query?: Record<string, string | number> }>;

export type H5RouteKey = keyof typeof H5Routes;
