import React from "react";
import { Pressable, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useCheckinInfo } from "@/hooks";
import { CalendarCheck } from "lucide-react-native";
import { Colors } from "@/constants/theme";
import { pickLang } from "./utils";

interface HlCheckinCardProps {
  props: {
    title?: { en?: string; zh?: string } | string;
    subtitle?: { en?: string; zh?: string } | string;
    cta?: { en?: string; zh?: string } | string;
    link?: string;
    bg?: string;
  };
  lang: string;
}

/** 签到卡：显示连续签到天数 + 今日是否已签，点击跳签到页 */
export default function HlCheckinCard({ props, lang }: HlCheckinCardProps) {
  const router = useRouter();
  const { data } = useCheckinInfo();
  const info: any = (data as any)?.data ?? data ?? {};
  const streak = Number(info.streak ?? 0);
  const todaySigned = !!info.today_signed;

  const title = pickLang(props.title, lang) || (lang === "en" ? "Daily Check-in" : "每日簽到");
  const subtitle = pickLang(props.subtitle, lang) || (lang === "en" ? `Streak: ${streak} days` : `已連續 ${streak} 天`);
  const cta = pickLang(props.cta, lang) || (todaySigned ? (lang === "en" ? "Signed" : "已簽到") : (lang === "en" ? "Sign in" : "立即簽到"));
  const link = props.link || "/box/checkin";
  const bg = props.bg || "#F7F8F8";

  return (
    <Pressable onPress={() => router.push(link as any)} className="mx-4 mt-3 rounded-2xl p-4" style={{ backgroundColor: bg }}>
      <View className="flex-row items-center justify-between">
        <View className="flex-1">
          <View className="flex-row items-center gap-2">
            <CalendarCheck size={18} color="#04A8AE" strokeWidth={2.1} />
            <Text style={{ color: Colors.neutral[900], fontSize: 15, fontWeight: "700" }}>{title}</Text>
          </View>
          <Text style={{ color: Colors.neutral[600], fontSize: 12, marginTop: 4 }}>{subtitle}</Text>
        </View>
        <View className="rounded-full px-3 py-1.5" style={{ backgroundColor: todaySigned ? "#ECFBFB" : Colors.brand.red }}>
          <Text style={{ color: todaySigned ? "#078E93" : "#fff", fontSize: 12, fontWeight: "600" }}>{cta}</Text>
        </View>
      </View>
    </Pressable>
  );
}
