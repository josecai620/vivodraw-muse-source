import { Container, Graphics, Sprite, Texture } from 'pixi.js';

export interface GlowFilterConfig {
  glowIntensity: number; // glowIntensity：呼吸发光强度
  glowSpeed: number; // glowSpeed：呼吸发光速度
  glowColor: number; // glowColor：发光颜色
}

interface GlowRhythm {
  charge: number; // charge：聚能强度
  burst: number; // burst：爆闪强度
  afterglow: number; // afterglow：余辉强度
  scatter: number; // scatter：粒子散落强度
  brightness: number; // brightness：整体亮度节奏
}

interface SoftEnergyRing {
  sprite: Sprite; // sprite：柔性能量环纹理
  baseAlpha: number; // baseAlpha：基础透明度
  speed: number; // speed：旋转速度
  scale: number; // scale：基础缩放
  seed: number; // seed：随机种子
}

interface EnergyFleck {
  node: Graphics; // node：光屑图形节点
  angle: number; // angle：轨道角度
  radius: number; // radius：轨道半径
  speed: number; // speed：漂移速度
  seed: number; // seed：随机种子
}

export class GlowFilter { // GlowFilter：矿石呼吸发光滤镜
  readonly auraLayer = new Container(); // auraLayer：外圈气场光层
  readonly backGlow: Sprite; // backGlow：背后发光层
  readonly frontGlow: Sprite; // frontGlow：前景发光层
  private readonly energyRings: SoftEnergyRing[] = []; // energyRings：柔性能量环列表
  private readonly energyFlecks: EnergyFleck[] = []; // energyFlecks：空气光屑列表
  private readonly centerX: number; // centerX：矿石中心 X
  private readonly centerY: number; // centerY：矿石中心 Y

  constructor(texture: Texture, centerX: number, centerY: number, size: number) {
    this.centerX = centerX; // centerX：保存中心 X
    this.centerY = centerY; // centerY：保存中心 Y
    this.backGlow = new Sprite(texture); // backGlow：背后发光层
    this.frontGlow = new Sprite(texture); // frontGlow：前景发光层

    [this.backGlow, this.frontGlow].forEach((sprite) => {
      sprite.anchor.set(0.5);
      sprite.x = centerX;
      sprite.y = centerY;
      sprite.width = size;
      sprite.height = size;
      sprite.blendMode = 'add';
    });

    this.backGlow.tint = 0x08aeb4;
    this.frontGlow.tint = 0x7fd8dc;
    this.createEnergyRings();
    this.createEnergyFlecks();
  }

  update(time: number, config: GlowFilterConfig, rhythm: GlowRhythm) {
    const pulse = 0.5 + Math.sin(time * config.glowSpeed * Math.PI * 2) * 0.5; // pulse：呼吸相位
    const power = config.glowIntensity * rhythm.brightness; // power：发光强度
    this.backGlow.tint = config.glowColor;
    this.frontGlow.tint = config.glowColor;
    this.backGlow.alpha = (0.12 + pulse * 0.22 + rhythm.afterglow * 0.1 + rhythm.burst * 0.05) * power;
    this.backGlow.scale.set(1.06 + pulse * 0.055 + rhythm.charge * 0.035);
    this.frontGlow.alpha = (0.025 + pulse * 0.04 + rhythm.burst * 0.018) * power;
    this.frontGlow.scale.set(1);
    this.updateEnergyRings(time, pulse, power, rhythm);
    this.updateEnergyFlecks(time, power, rhythm);
  }

  private createEnergyRings() {
    const ringSpecs = [ // ringSpecs：柔性能量环参数
      { color: 0x9fe4e6, alpha: 0.2, scale: 1.0, speed: 0.10, seed: 2.1 },
      { color: 0x33c6cc, alpha: 0.16, scale: 0.82, speed: -0.14, seed: 5.7 },
      { color: 0xcff3f4, alpha: 0.08, scale: 1.24, speed: 0.06, seed: 9.2 },
    ];

    ringSpecs.forEach((spec) => {
      const sprite = new Sprite(this.createSoftRingTexture(spec.color, spec.seed)); // sprite：柔性能量环
      sprite.anchor.set(0.5);
      sprite.x = this.centerX;
      sprite.y = this.centerY;
      sprite.width = 360 * spec.scale;
      sprite.height = 360 * spec.scale;
      sprite.blendMode = 'add';
      this.energyRings.push({
        sprite,
        baseAlpha: spec.alpha,
        speed: spec.speed,
        scale: spec.scale,
        seed: spec.seed,
      });
      this.auraLayer.addChild(sprite);
    });
  }

  private createEnergyFlecks() {
    for (let index = 0; index < 26; index += 1) { // index：光屑序号
      const node = new Graphics(); // node：单个空气光屑
      node.blendMode = 'add';
      this.energyFlecks.push({
        node,
        angle: index * 2.399 + Math.random() * 0.42,
        radius: 112 + Math.random() * 70,
        speed: 0.12 + Math.random() * 0.18,
        seed: Math.random() * 100,
      });
      this.auraLayer.addChild(node);
    }
  }

  private updateEnergyRings(time: number, pulse: number, power: number, rhythm: GlowRhythm) {
    this.energyRings.forEach((ring, index) => {
      const noise = Math.sin(time * 1.4 + ring.seed) * 0.035; // noise：环体轻微扰动
      const breathe = 0.52 + pulse * 0.22 + rhythm.charge * 0.22 + rhythm.afterglow * 0.14 + Math.sin(time * 1.8 + index) * 0.04; // breathe：透明度呼吸
      ring.sprite.rotation += ring.speed * 0.016;
      ring.sprite.alpha = ring.baseAlpha * breathe * power * (1.45 + rhythm.burst * 0.55);
      ring.sprite.scale.set(1 + noise + rhythm.charge * 0.05 + rhythm.burst * 0.12);
    });
  }

  private updateEnergyFlecks(time: number, power: number, rhythm: GlowRhythm) {
    this.energyFlecks.forEach((fleck, index) => {
      const angle = fleck.angle + time * fleck.speed; // angle：当前漂移角度
      const radius = fleck.radius + Math.sin(time * 1.6 + fleck.seed) * 18; // radius：当前漂移半径
      const breathe = 0.45 + Math.sin(time * (2.2 + fleck.speed) + fleck.seed) * 0.35; // breathe：光屑呼吸
      const x = this.centerX + Math.cos(angle) * radius; // x：光屑 X
      const y = this.centerY + Math.sin(angle) * radius * 0.78; // y：光屑 Y
      const length = 7 + (index % 4) * 3 + breathe * 5; // length：光屑长度
      const tilt = angle + Math.PI * 0.5 + Math.sin(time + fleck.seed) * 0.45; // tilt：光屑旋转
      const color = index % 3 === 0 ? 0xb2ecee : 0x9fe4e6; // color：光屑颜色（teal 系）
      fleck.node.clear();
      this.drawSoftShard(fleck.node, x, y, length, tilt, color, (0.16 + breathe * 0.34 + rhythm.scatter * 0.2) * power);
    });
  }

  private drawSoftShard(node: Graphics, x: number, y: number, length: number, angle: number, color: number, alpha: number) {
    const tailX = x - Math.cos(angle) * length * 0.72; // tailX：光痕尾端 X
    const tailY = y - Math.sin(angle) * length * 0.72; // tailY：光痕尾端 Y
    const tipX = x + Math.cos(angle) * length * 0.5; // tipX：光痕前端 X
    const tipY = y + Math.sin(angle) * length * 0.5; // tipY：光痕前端 Y
    const curveX = x + Math.cos(angle + Math.PI / 2) * length * 0.16; // curveX：曲线控制点 X
    const curveY = y + Math.sin(angle + Math.PI / 2) * length * 0.16; // curveY：曲线控制点 Y
    node.moveTo(tailX, tailY);
    node.bezierCurveTo(curveX, curveY, x, y, tipX, tipY);
    node.stroke({ width: Math.max(1, length * 0.11), color, alpha });
    node.moveTo(x - Math.cos(angle) * length * 0.18, y - Math.sin(angle) * length * 0.18);
    node.bezierCurveTo(curveX, curveY, x, y, tipX, tipY);
    node.stroke({ width: Math.max(1, length * 0.045), color: 0xeafbfb, alpha: alpha * 0.72 });
  }

  private createSoftRingTexture(color: number, seed: number) {
    const size = 256; // size：纹理尺寸
    const canvas = document.createElement('canvas'); // canvas：离屏纹理画布
    canvas.width = size;
    canvas.height = size;
    const context = canvas.getContext('2d'); // context：画布上下文
    if (!context) return Texture.EMPTY;

    const image = context.createImageData(size, size); // image：像素数据
    const data = image.data; // data：RGBA 像素数组
    const red = (color >> 16) & 255; // red：红色通道
    const green = (color >> 8) & 255; // green：绿色通道
    const blue = color & 255; // blue：蓝色通道
    const center = size / 2; // center：纹理中心

    for (let y = 0; y < size; y += 1) { // y：像素 Y
      for (let x = 0; x < size; x += 1) { // x：像素 X
        const dx = x - center; // dx：中心偏移 X
        const dy = y - center; // dy：中心偏移 Y
        const distance = Math.sqrt(dx * dx + dy * dy); // distance：像素到中心距离
        const angle = Math.atan2(dy, dx); // angle：像素角度
        const ring = Math.exp(-Math.pow((distance - 86) / 15, 2)); // ring：径向柔环强度
        const glow = Math.exp(-Math.pow((distance - 86) / 34, 2)) * 0.34; // glow：边缘扩散强度
        const breakNoise = Math.sin(angle * 7 + seed) * Math.sin(angle * 13 - seed * 0.7); // breakNoise：断裂噪声
        const localFlicker = breakNoise > 0.42 ? 0.32 : 1; // localFlicker：局部断裂闪烁基础
        const softNoise = 0.72 + Math.sin(dx * 0.07 + seed) * Math.cos(dy * 0.06 - seed) * 0.28; // softNoise：边缘柔性噪声
        const alpha = Math.max(0, Math.min(1, (ring + glow) * localFlicker * softNoise)); // alpha：最终透明度
        const offset = (y * size + x) * 4; // offset：像素数组偏移
        data[offset] = red;
        data[offset + 1] = green;
        data[offset + 2] = blue;
        data[offset + 3] = Math.floor(alpha * 170);
      }
    }

    context.putImageData(image, 0, 0);
    return Texture.from(canvas);
  }
}
