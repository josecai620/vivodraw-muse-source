import ClassicProfileIllustration, {
  type ClassicProfileIllustrationName,
} from "@/components/shared/ClassicProfileIllustration";
import React from "react";
import type { ImageStyle, StyleProp } from "react-native";

export type ClassicHomeIllustrationName =
  | "theme"
  | "search"
  | "bell"
  | "points"
  | "home"
  | "browse"
  | "cart"
  | "me"
  | "shopping"
  | "mystery-box"
  | "group-buy"
  | "checkin";

const NAME_MAP: Record<ClassicHomeIllustrationName, ClassicProfileIllustrationName> = {
  theme: "settings",
  search: "history-identity-search",
  bell: "notifications-bell",
  points: "points-badge-flower",
  home: "address-home",
  browse: "articles-book",
  cart: "wallet",
  me: "profile-account-settings",
  shopping: "wallet",
  "mystery-box": "orders-gift-box",
  "group-buy": "coupons-coupon-ticket",
  checkin: "invoices-receipt",
};

type ClassicHomeIllustrationProps = {
  name: ClassicHomeIllustrationName;
  size?: number;
  style?: StyleProp<ImageStyle>;
  accessibilityLabel?: string;
};

export default function ClassicHomeIllustration({
  name,
  size = 48,
  style,
  accessibilityLabel,
}: ClassicHomeIllustrationProps) {
  return (
    <ClassicProfileIllustration
      name={NAME_MAP[name]}
      size={size}
      style={style}
      accessibilityLabel={accessibilityLabel}
    />
  );
}
