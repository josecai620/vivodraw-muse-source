import React, { useState } from "react";
import { View, TextInput, Pressable, type TextInputProps } from "react-native";
import { Eye, EyeOff, Search, X } from "lucide-react-native";
import { Colors, Shadows, s } from "@/constants/theme";
import LuxeIcon from "@/components/shared/LuxeIcon";

interface InputProps extends TextInputProps {
  variant?: "default" | "search";
  error?: boolean;
  onClear?: () => void;
}

export default function Input({
  variant = "default",
  error = false,
  onClear,
  secureTextEntry,
  value,
  ...props
}: InputProps) {
  const [showPassword, setShowPassword] = useState(false);
  const isSearch = variant === "search";

  return (
    <View
      className="flex-row items-center h-12 px-4 border"
      style={{
        borderRadius: s(16),
        backgroundColor: "#FFFFFF",
        borderColor: error ? Colors.error : Colors.screen.hairline,
        ...Shadows.raisedSm,
      }}
    >
      {isSearch && (
        <View className="mr-2">
          <LuxeIcon Icon={Search} tone="neutral" variant="soft" size={28} iconSize={14} />
        </View>
      )}

      <TextInput
        value={value}
        secureTextEntry={secureTextEntry && !showPassword}
        placeholderTextColor={Colors.luxe.inkSoft}
        className="flex-1 text-base"
        style={{ color: Colors.luxe.ink, fontWeight: "500" }}
        {...props}
      />

      {secureTextEntry && (
        <Pressable
          onPress={() => setShowPassword(!showPassword)}
          hitSlop={12}
        >
          <LuxeIcon
            Icon={showPassword ? EyeOff : Eye}
            tone="neutral"
            variant="soft"
            size={30}
            iconSize={15}
          />
        </Pressable>
      )}

      {onClear && value ? (
        <Pressable onPress={onClear} hitSlop={12}>
          <LuxeIcon Icon={X} tone="neutral" variant="soft" size={28} iconSize={14} />
        </Pressable>
      ) : null}
    </View>
  );
}
