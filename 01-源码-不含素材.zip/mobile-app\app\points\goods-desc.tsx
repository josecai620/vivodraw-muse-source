import React from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { HtmlContent, PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useDetailDesc, usePointsProductDetail } from "@/hooks";
import { unwrapApiData } from "@/lib/api/response";
import { collectImageUrls, toNum } from "@/lib/points/cloudBuyParse";
import CloudBuyImageSlider from "@/components/points/CloudBuyImageSlider";

export default function CloudBuyGoodsDescScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const productId = toNum(id);
  const { data: descData, isLoading } = useDetailDesc(productId);
  const { data: detailData } = usePointsProductDetail(productId);

  const html = String(
    unwrapApiData<any>(descData, {})?.content ??
      unwrapApiData<any>(descData, {})?.description ??
      "",
  );
  const detail = (detailData as any)?.data?.detail ?? (detailData as any)?.data ?? {};
  const storeInfo = detail?.storeInfo ?? detail;
  const slides = collectImageUrls(storeInfo?.slider_image, storeInfo?.image);

  return (
    <View className="flex-1" style={{ backgroundColor: "#fff" }}>
      <PageHeader title={t("pointsMall.richDetail")} />
      {isLoading ? (
        <ActivityIndicator style={{ marginTop: 40 }} color="#04A8AE" />
      ) : (
        <ScrollView
          className="flex-1"
          contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 16 }}
        >
          {slides.length > 1 ? <CloudBuyImageSlider images={slides} height={220} /> : null}
          {html ? (
            <View style={{ paddingHorizontal: 12, paddingTop: 8 }}>
              <HtmlContent html={html} />
            </View>
          ) : (
            <Text className="text-center text-gray-400 mt-10">{t("pointsMall.noRichDetail")}</Text>
          )}
        </ScrollView>
      )}
      <PointsMallTabBar />
    </View>
  );
}
