import ProfileCloudBuyDock from "@/components/points/ProfileCloudBuyDock";
import { WEB_BASE_URL } from "@/constants/env";
import { Colors, Fonts, Shadows, Typography, s } from "@/constants/theme";
import { type MessageItem, getMessageList } from "@/lib/api/message";
import { unwrapApiPagedList } from "@/lib/api/response";
import { getUserLevelInfo } from "@/lib/api/userLevel";
import { shareText } from "@/lib/native/share";
import { formatNumber } from "@/lib/utils";
import { 会员头像框 } from "@/components/member/会员头像框";
import { 会员卡片框 } from "@/components/member/会员卡片框";
import { 会员入口卡 } from "@/components/member/会员入口卡";
import 头像操作面板 from "@/components/profile/头像操作面板";
import { useAvatarUpload } from "@/hooks/useAvatarUpload";
import {
  displayMemberTier,
  parseUserLevelPayload,
  resolveMemberFrame,
} from "@/lib/会员等级";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import { useQuery } from "@tanstack/react-query";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import {
  Bell,
  BookOpen,
  ChevronRight,
  CreditCard,
  FileText,
  Gamepad2,
  Gift,
  Heart,
  Images,
  HelpCircle,
  History,
  LogOut,
  MapPin,
  Package,
  Receipt,
  Settings,
  Share2,
  ShieldCheck,
  ShoppingBag,
  Star,
  Trophy,
  UserRound,
  Users,
  Wallet,
} from "lucide-react-native";
import type React from "react";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  type ColorValue,
  Image,
  type ImageSourcePropType,
  Linking,
  Pressable,
  ScrollView,
  Text,
  View,
  type ViewStyle,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const ACCOUNT_LOG_ICON = require("../../assets/icons/账户明细图标.png");

type IconComponent = React.ComponentType<{
  color?: string;
  size?: number;
  strokeWidth?: number;
}>;

type ProfileAppRoute =
  | "/(tabs)/points"
  | "/articles"
  | "/play"
  | "/community"
  | "/orders"
  | "/points/tasks"
  | "/profile/address"
  | "/profile/commission"
  | "/profile/coupons"
  | "/profile/help"
  | "/profile/invoices"
  | "/profile/level"
  | "/profile/member-card"
  | "/profile/messages"
  | "/profile/notifications"
  | "/profile/payment"
  | "/profile/settings"
  | "/agreement/about"
  | "/agreement/privacy_agreement"
  | "/agreement/user_agreement"
  | "/points/history"
  | "/profile/visit-history"
  | "/profile/wallet"
  | "/profile/wishlist";
type SpecialMenuRoute = "__rate__" | "__share_app__";

type ProfileMenuItem = {
  icon: IconComponent;
  iconImage?: ImageSourcePropType;
  label: string;
  labelColor?: string;
  route: ProfileAppRoute | SpecialMenuRoute;
  description?: string;
  badge?: string;
  count?: number;
  value?: string;
};

type ProfileMenuSection = {
  title: string;
  subtitle: string;
  items: ProfileMenuItem[];
};

// 方向C：页面浅冷灰底、纯白浮卡、极细冷边、唯一 teal 点缀
const PROFILE_BG = ["#F5F7F7", "#F5F7F7", "#F5F7F7"] as const;
const HERO_BG = ["#FFFFFF", "#FFFFFF"] as const;
const ACCENT_BG = ["#33C6CC", "#08AEB4", "#07858C"] as const;
const FOLIO_BG = ["#F7F9F9", "#F2F4F4"] as const;
const INNER_BG = ["#F7F9F9", "#F2F4F4"] as const;
const WARM_TINT = "rgba(4,168,174, 0.10)";
const GOLD_TINT = "#ECFBFB";
const SURFACE_BORDER = "rgba(12,31,31, 0.055)";
const SOFT_BORDER = "rgba(12,31,31, 0.05)";

function isUnreadMessage(message: MessageItem) {
  const readState = message.is_read ?? message.look ?? message.read;
  return (
    readState === undefined ||
    readState === null ||
    readState === false ||
    readState === 0 ||
    readState === "0"
  );
}

function buildMenuSections(
  t: (key: string) => string,
  zh: boolean,
): ProfileMenuSection[] {
  return [
    {
      title: t("profile.settingsSection"),
      subtitle: "Membership, identity, and account rules",
      items: [
        {
          icon: MapPin,
          label: t("profile.shippingAddress"),
          description: "Default delivery details",
          route: "/profile/address",
        },
        {
          icon: CreditCard,
          label: t("profile.paymentMethods"),
          description: "Payment and checkout methods",
          route: "/profile/payment",
        },
        {
          icon: Receipt,
          label: t("profile.myInvoices"),
          description: "Invoice titles and tax details",
          route: "/profile/invoices",
        },
        {
          icon: Users,
          label: t("profile.commission"),
          description: "Referral income and team",
          route: "/profile/commission",
        },
        {
          icon: Star,
          label: t("profile.memberLevel"),
          description: "Growth value and tier rules",
          route: "/profile/level",
        },
        {
          icon: Settings,
          label: t("profile.accountSettings"),
          description: "Password, privacy, profile",
          route: "/profile/settings",
        },
      ],
    },
    {
      title: t("profile.support"),
      subtitle: zh ? "支援資源與信任文件" : "Support resources and trust documents",
      items: [
        {
          icon: BookOpen,
          label: t("profile.newsArticles"),
          description: zh ? "更新與購買指南" : "Updates and buying guidance",
          route: "/articles",
        },
        {
          icon: HelpCircle,
          label: t("profile.helpCenter"),
          description: zh ? "訂單、獎勵與退貨" : "Orders, rewards, and returns",
          route: "/profile/help",
        },
        {
          icon: ShieldCheck,
          label: t("profile.privacySecurity"),
          description: zh ? "安全與隱私中心" : "Security and privacy center",
          route: "/agreement/privacy_agreement",
        },
        {
          icon: Star,
          label: t("profile.rateUs"),
          description: zh ? "在應用商店留下評價" : "Leave app store feedback",
          route: "__rate__",
        },
        {
          icon: Share2,
          label: t("profile.shareApp"),
          description: zh ? "邀請朋友加入 VivoDraw" : "Invite someone to VivoDraw",
          route: "__share_app__",
        },
        {
          icon: FileText,
          label: t("profile.aboutUs"),
          description: zh ? "公司資訊" : "Company information",
          route: "/agreement/about",
        },
        {
          icon: ShieldCheck,
          label: t("profile.privacyPolicyLink"),
          description: zh ? "隱私與資料條款" : "Privacy and data terms",
          route: "/agreement/privacy_agreement",
        },
        {
          icon: FileText,
          label: t("profile.userAgreement"),
          description: zh ? "使用者協議" : "User agreement",
          route: "/agreement/user_agreement",
        },
      ],
    },
  ];
}

function ShadowPanel({
  children,
  className,
  style,
}: {
  children: React.ReactNode;
  className?: string;
  style?: ViewStyle | ViewStyle[];
}) {
  return (
    <View
      className={className}
      style={[
        {
          borderWidth: 1,
          borderColor: SURFACE_BORDER,
          backgroundColor: "#FFFFFF",
          ...Shadows.raised,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

function IconTile({
  Icon,
  size = 42,
  tint = GOLD_TINT,
  color = Colors.primary.DEFAULT,
  style,
}: {
  Icon: IconComponent;
  size?: number;
  tint?: ColorValue;
  color?: string;
  style?: ViewStyle;
}) {
  return (
    <View
      style={[
        {
          width: size,
          height: size,
          borderRadius: Math.round(size * 0.34),
          alignItems: "center",
          justifyContent: "center",
          borderWidth: 1,
          borderColor: SOFT_BORDER,
          backgroundColor: tint,
          shadowColor: "#0C1F1F",
          shadowOffset: { width: 0, height: 3 },
          shadowOpacity: 0.06,
          shadowRadius: 8,
          elevation: 2,
        },
        style,
      ]}
    >
      <Icon size={Math.round(size * 0.48)} color={color} strokeWidth={2} />
    </View>
  );
}

function SectionTitle({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: string;
}) {
  return (
    <View className="flex-row items-end justify-between mb-3">
      <View className="flex-1 pr-3">
        <Text style={[Typography.h4, { color: Colors.luxe.ink }]}>{title}</Text>
        {subtitle ? (
          <Text className="mt-1 text-xs" style={{ color: Colors.luxe.inkMuted }}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {action ? (
        <Text className="text-xs font-bold" style={{ color: Colors.luxe.inkMuted }}>
          {action}
        </Text>
      ) : null}
    </View>
  );
}

function MetricCard({
  label,
  value,
  helper,
}: {
  label: string;
  value: string;
  helper: string;
}) {
  return (
    <View
      className="flex-1 p-3"
      style={{
        minHeight: s(132),
        borderRadius: s(20),
        borderWidth: 1,
        borderColor: SOFT_BORDER,
        backgroundColor: "#F7F9F9",
      }}
    >
      <Text className="text-[11px] font-bold leading-4" style={{ color: Colors.luxe.inkSoft }}>
        {label}
      </Text>
      <Text
        className="mt-2"
        numberOfLines={1}
        adjustsFontSizeToFit
        style={{
          color: Colors.luxe.ink,
          fontFamily: Fonts.sans,
          fontSize: s(24),
          fontWeight: "800",
        }}
      >
        {value}
      </Text>
      <Text className="mt-1 text-xs leading-4" style={{ color: Colors.luxe.inkMuted }}>
        {helper}
      </Text>
    </View>
  );
}

function OrderStatusCard({
  Icon,
  label,
  value,
  onPress,
}: {
  Icon: IconComponent;
  label: string;
  value: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      onPress={onPress}
      className="flex-1 items-center p-2"
      style={({ pressed }) => ({
        minHeight: s(102),
        borderRadius: s(18),
        borderWidth: 1,
        borderColor: SOFT_BORDER,
        opacity: pressed ? 0.82 : 1,
        transform: [{ translateY: pressed ? 1 : 0 }],
        overflow: "hidden",
      })}
    >
      <LinearGradient colors={FOLIO_BG} className="absolute inset-0" />
      <IconTile Icon={Icon} size={s(38)} tint="#FFFFFF" />
      <Text className="mt-2 text-base font-bold" style={{ color: Colors.primary.DEFAULT }}>
        {value}
      </Text>
      <Text
        className="mt-0.5 text-[10px] font-bold text-center"
        style={{ color: Colors.luxe.inkSoft }}
      >
        {label}
      </Text>
    </Pressable>
  );
}

function QuickCard({
  Icon,
  iconImage,
  label,
  title,
  body,
  value,
  width,
  onPress,
}: {
  Icon: IconComponent;
  iconImage?: ImageSourcePropType;
  label: string;
  title: string;
  body: string;
  tone?: "warm" | "mint" | "plain";
  value?: string;
  width: ViewStyle["width"];
  onPress: () => void;
}) {
  // 内卡统一极浅冷灰，浮在白色 ShadowPanel 之上形成层级
  const bg = INNER_BG;

  return (
    <Pressable
      onPress={onPress}
      className="p-4"
      style={{
        width,
        maxWidth: width,
        minWidth: 0,
        flexShrink: 1,
        minHeight: s(138),
        borderRadius: s(24),
        borderWidth: 1,
        borderColor: SURFACE_BORDER,
        overflow: "hidden",
      }}
    >
      <LinearGradient colors={bg as [string, string]} className="absolute inset-0" />
      <View className="flex-row items-start justify-between gap-2" style={{ minWidth: 0 }}>
        <Text
          className="flex-1 text-[10px] font-bold uppercase leading-4"
          style={{ color: Colors.luxe.inkSoft, minWidth: 0 }}
          numberOfLines={2}
          ellipsizeMode="tail"
        >
          {label}
        </Text>
        {iconImage ? (
          <View
            style={{
              width: s(34),
              height: s(34),
              borderRadius: Math.round(s(34) * 0.34),
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: SOFT_BORDER,
              backgroundColor: "#FFFFFF",
              shadowColor: "#0C1F1F",
              shadowOffset: { width: 0, height: 3 },
              shadowOpacity: 0.06,
              shadowRadius: 8,
              elevation: 2,
            }}
          >
            <Image
              source={iconImage}
              style={{ width: Math.round(s(34) * 0.72), height: Math.round(s(34) * 0.72) }}
              resizeMode="contain"
            />
          </View>
        ) : (
          <IconTile Icon={Icon} size={s(34)} tint="#FFFFFF" />
        )}
      </View>
      <Text
        className="mt-3 text-lg font-bold leading-5"
        style={{ color: Colors.luxe.ink, minWidth: 0 }}
        numberOfLines={2}
        adjustsFontSizeToFit
      >
        {title}
      </Text>
      <Text
        className="mt-2 text-xs leading-5"
        style={{ color: Colors.luxe.inkMuted, minWidth: 0 }}
        numberOfLines={3}
      >
        {body}
      </Text>
      {value ? (
        <Text className="mt-3 text-xl font-extrabold" style={{ color: Colors.luxe.ink }}>
          {value}
        </Text>
      ) : null}
    </Pressable>
  );
}

function ServiceTile({
  item,
  eyebrow,
  width,
  onPress,
}: {
  item: ProfileMenuItem;
  eyebrow: string;
  width: ViewStyle["width"];
  onPress: () => void;
}) {
  const Icon = item.icon;
  const hasMeta = item.count || item.badge || item.value;
  return (
    <Pressable
      onPress={onPress}
      className="p-3"
      style={{
        width,
        minWidth: 0,
        minHeight: s(118),
        borderRadius: s(22),
        borderWidth: 1,
        borderColor: SOFT_BORDER,
        backgroundColor: "#F7F9F9",
        overflow: "hidden",
      }}
    >
      <View className="flex-row items-start justify-between gap-2" style={{ minWidth: 0 }}>
        <Text
          className="flex-1 text-[10px] font-extrabold uppercase leading-4"
          style={{ color: Colors.luxe.inkSoft, minWidth: 0 }}
          numberOfLines={2}
        >
          {eyebrow}
        </Text>
        {item.iconImage ? (
          <View
            style={{
              width: s(34),
              height: s(34),
              borderRadius: Math.round(s(34) * 0.34),
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: SOFT_BORDER,
              backgroundColor: "#FFFFFF",
              shadowColor: "#0C1F1F",
              shadowOffset: { width: 0, height: 3 },
              shadowOpacity: 0.06,
              shadowRadius: 8,
              elevation: 2,
            }}
          >
            <Image
              source={item.iconImage}
              style={{ width: Math.round(s(34) * 0.72), height: Math.round(s(34) * 0.72) }}
              resizeMode="contain"
            />
          </View>
        ) : (
          <IconTile Icon={Icon} size={s(34)} tint="#FFFFFF" />
        )}
      </View>
      <Text
        className="mt-3 text-base font-extrabold leading-5"
        style={{ color: item.labelColor || Colors.luxe.ink, minWidth: 0 }}
        numberOfLines={2}
        adjustsFontSizeToFit
      >
        {item.label}
      </Text>
      {item.description ? (
        <Text
          className="mt-1 text-xs leading-4"
          style={{ color: Colors.luxe.inkMuted, minWidth: 0 }}
          numberOfLines={2}
        >
          {item.description}
        </Text>
      ) : null}
      {item.count ? (
        <Text className="mt-3 text-lg font-extrabold" style={{ color: Colors.brand.red }}>
          {item.count > 99 ? "99+" : item.count}
        </Text>
      ) : item.badge || item.value ? (
        <Text className="mt-3 text-lg font-extrabold" style={{ color: Colors.luxe.inkMuted }}>
          {item.value ?? item.badge}
        </Text>
      ) : hasMeta ? null : (
        <View className="mt-3 self-start">
          <ChevronRight size={18} color={Colors.luxe.inkSoft} strokeWidth={2} />
        </View>
      )}
    </Pressable>
  );
}

function ServiceGrid({
  items,
  eyebrow,
  onPress,
}: {
  items: ProfileMenuItem[];
  eyebrow: string;
  onPress: (item: ProfileMenuItem) => void;
}) {
  const tileWidth: ViewStyle["width"] = "48%";
  const rows: ProfileMenuItem[][] = [];
  for (let index = 0; index < items.length; index += 2) {
    rows.push(items.slice(index, index + 2));
  }

  return (
    <View className="gap-3">
      {rows.map((row) => (
        <View key={row.map((item) => item.label).join("-")} className="flex-row justify-between">
          {row.map((item) => (
            <ServiceTile
              key={item.label}
              item={item}
              eyebrow={eyebrow}
              width={tileWidth}
              onPress={() => onPress(item)}
            />
          ))}
          {row.length === 1 ? <View style={{ width: tileWidth }} /> : null}
        </View>
      ))}
    </View>
  );
}

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { width: viewportWidth } = useWindowDimensions();
  const router = useRouter();
  const { t, i18n } = useTranslation();
  const zhProfile = !!i18n.language?.startsWith("zh");
  const user = useAuthStore((state) => state.user);
  const isLoggedIn = useAuthStore((state) => state.isLoggedIn);
  const logout = useAuthStore((state) => state.logout);
  const showToast = useAppStore((state) => state.showToast);
  const [avatarSheet, setAvatarSheet] = useState(false);
  const { uploading: avatarUploading, startUpload, openCrop, cropModal } = useAvatarUpload();

  const handleAvatarPress = () => {
    if (!isLoggedIn) {
      router.push("/auth");
      return;
    }
    setAvatarSheet(true);
  };

  const { data: msgData } = useQuery({
    queryKey: ["messageList"],
    queryFn: () => getMessageList({ page: 1, limit: 100 }),
    enabled: isLoggedIn,
  });
  const { data: levelRaw } = useQuery({
    queryKey: ["userLevelInfo"],
    queryFn: getUserLevelInfo,
    enabled: isLoggedIn,
  });
  const levelPayload = parseUserLevelPayload(isLoggedIn ? levelRaw : null);
  const frameState = resolveMemberFrame({
    isLoggedIn,
    isMoneyLevel: levelPayload.user?.is_money_level,
    isEverLevel: levelPayload.user?.is_ever_level,
    overdueTime: levelPayload.user?.overdue_time,
    memberType: levelPayload.user?.member_type,
    spendUsd: levelPayload.user?.spend_usd ?? levelPayload.user?.pay_price,
  });
  const frameLevel = frameState.level;
  const frameTier = displayMemberTier(frameState);
  const msgList = unwrapApiPagedList<MessageItem>(msgData);
  const unreadList = msgList.filter(isUnreadMessage);
  const messageUnreadCount = unreadList.length;
  const menuSections = buildMenuSections(t, zhProfile);

  const displayName = user?.nickname || (isLoggedIn ? "User" : "Guest");
  const points = Number(user?.integral ?? 0);
  const balanceValue = Number(user?.now_money ?? 0);
  const balance = Number.isFinite(balanceValue) ? `$${balanceValue.toFixed(2)}` : "$0.00";
  const pageWidth = Math.min(viewportWidth, 520);
  const horizontalPad = Math.max(16, Math.round(pageWidth * 0.045));
  const memberBonus = !isLoggedIn
    ? t("profile.signIn")
    : frameState.trialActive
      ? zhProfile
        ? "試用 7 天動態框"
        : "7-day trial frame"
      : frameLevel === 0
        ? zhProfile
          ? "靜態頭像框"
          : "Static frame"
        : `${frameTier.bonus} Points`;
  const memberLine = isLoggedIn
    ? zhProfile
      ? `${frameTier.nameZh}${frameLevel > 0 ? ` · LV${frameLevel}` : ""}`
      : `${frameTier.nameEn} Member${frameLevel > 0 ? ` · LV${frameLevel}` : ""}`
    : "Guest account / 訪客帳號";
  const quickCardWidth: ViewStyle["width"] = "48%";

  const accountItems: ProfileMenuItem[] = [
    {
      icon: ShoppingBag,
      label: t("profile.myOrders"),
      description: "Order list, shipment, and reviews",
      route: "/orders",
      value: "—",
    },
    {
      icon: History,
      label: t("profile.browseHistory"),
      description: "Recently viewed products",
      route: "/profile/visit-history",
    },
    {
      icon: Heart,
      label: t("profile.wishlist"),
      description: "Saved products and restock alerts",
      route: "/profile/wishlist",
      value: "—",
    },
    {
      icon: Gift,
      label: t("profile.coupons"),
      description: "Available coupons and savings",
      route: "/profile/coupons",
      value: "—",
    },
  ];

  const handleMenuPress = (item: ProfileMenuItem) => {
    if (item.route === "__rate__") {
      Linking.openURL("https://apps.apple.com");
    } else if (item.route === "__share_app__") {
      shareText("VivoDraw - Shop smarter, earn points", WEB_BASE_URL, "VivoDraw");
    } else {
      router.push(item.route);
    }
  };

  const identityAction = isLoggedIn
    ? () => router.push("/profile/edit")
    : () => router.push("/auth");
  const statusLine = isLoggedIn
    ? messageUnreadCount > 0
      ? `${messageUnreadCount} unread messages`
      : "Account ready"
    : "Sign in to sync orders and rewards";

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      {cropModal}
      <头像操作面板
        visible={avatarSheet}
        zh={zhProfile}
        onClose={() => setAvatarSheet(false)}
        onUpload={() => {
          setAvatarSheet(false);
          startUpload();
        }}
        onPickedFile={(file) => {
          setAvatarSheet(false);
          openCrop(file);
        }}
        onFrames={() => {
          setAvatarSheet(false);
          router.push("/profile/avatar-frames");
        }}
      />
      <LinearGradient colors={PROFILE_BG} className="absolute inset-0" />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{
          paddingTop: insets.top + 16,
          paddingBottom: insets.bottom + 104,
          paddingHorizontal: horizontalPad,
          width: pageWidth,
          alignSelf: "center",
        }}
        showsVerticalScrollIndicator={false}
        bounces={false}
        overScrollMode="never"
      >
        <View className="flex-row items-center justify-between">
          <View>
            <Text
              className="text-[11px] font-extrabold uppercase"
              style={{ color: Colors.luxe.inkSoft }}
            >
              Eccomall Circle
            </Text>
            <Text className="mt-1" style={[Typography.h1, { color: Colors.luxe.ink }]}>
              {t("profile.title")}
            </Text>
          </View>
          <Pressable
            onPress={() => router.push("/profile/settings")}
            className="items-center justify-center"
            style={({ pressed }) => ({
              width: s(42),
              height: s(42),
              borderRadius: s(16),
              borderWidth: 1,
              borderColor: SURFACE_BORDER,
              backgroundColor: "#FFFFFF",
              opacity: pressed ? 0.78 : 1,
              ...Shadows.raisedSm,
            })}
            accessibilityRole="button"
            accessibilityLabel={t("profile.accountSettings")}
          >
            <Settings size={20} color={Colors.luxe.ink} strokeWidth={1.9} />
          </Pressable>
        </View>

        <ShadowPanel className="mt-5 p-5" style={{ borderRadius: s(32), overflow: "visible" }}>
          <LinearGradient colors={HERO_BG} className="absolute inset-0" />
          <LinearGradient
            pointerEvents="none"
            colors={["rgba(4,168,174,0.12)", "rgba(255,255,255,0)"]}
            start={{ x: 1, y: 0 }}
            end={{ x: 0.35, y: 0.8 }}
            className="absolute right-0 top-0 h-40 w-56"
          />
          <View className="flex-row items-start justify-between gap-3">
            <View className="flex-1 min-w-0">
              <会员卡片框 level={frameLevel} trial={frameState.trialActive} motion={frameState.motion}>
                <Text
                  className="text-xl font-bold leading-6"
                  numberOfLines={2}
                  adjustsFontSizeToFit
                  style={{ color: Colors.luxe.ink }}
                >
                  {displayName}
                </Text>
                <Text className="mt-1 text-xs leading-5 font-extrabold" style={{ color: frameTier.ring }}>
                  {memberLine}
                </Text>
                <Text className="mt-0.5 text-[10px] font-bold uppercase" style={{ color: Colors.luxe.inkSoft }}>
                  {memberBonus}
                </Text>
                <Pressable
                  onPress={identityAction}
                  className="mt-2 self-start px-3 py-1.5 rounded-full"
                  style={({ pressed }) => ({
                    backgroundColor: WARM_TINT,
                    opacity: pressed ? 0.8 : 1,
                  })}
                >
                  <Text className="text-xs font-extrabold" style={{ color: Colors.brand.red }}>
                    {isLoggedIn ? t("profile.editProfile") : t("profile.signIn")}
                  </Text>
                </Pressable>
              </会员卡片框>
            </View>
            <Pressable
              onPress={handleAvatarPress}
              className="items-center justify-center"
              style={{ marginTop: -8, marginRight: -4 }}
              accessibilityRole="button"
              accessibilityLabel={t("profile.avatar")}
            >
              {avatarUploading ? (
                <ActivityIndicator color={Colors.brand.red} size="small" />
              ) : (
                <会员头像框
                  uri={user?.avatar}
                  uid={user?.uid}
                  level={frameLevel}
                  size={s(92)}
                  zh={zhProfile}
                  trial={frameState.trialActive}
                  motion={frameState.motion}
                  frameId={user?.avatar_frame}
                />
              )}
            </Pressable>
          </View>

          <View className="mt-4 flex-row gap-3">
            <MetricCard
              label="Wallet balance / 錢包餘額"
              value={balance}
              helper="Recharge, withdraw, and checkout balance."
            />
            <MetricCard
              label="Reward points / 積分"
              value={formatNumber(points)}
              helper="Earn tasks and redeem featured goods."
            />
          </View>

          <View className="mt-4 flex-row gap-3">
            <Pressable
              onPress={() => router.push(isLoggedIn ? "/profile/wallet" : "/auth")}
              className="flex-1 h-11 rounded-full items-center justify-center"
              style={({ pressed }) => ({
                opacity: pressed ? 0.84 : 1,
                shadowColor: "#04A8AE",
                shadowOffset: { width: 0, height: 6 },
                shadowOpacity: 0.32,
                shadowRadius: 14,
                elevation: 6,
              })}
            >
              <LinearGradient
                colors={ACCENT_BG}
                start={{ x: 0.5, y: 0 }}
                end={{ x: 0.5, y: 1 }}
                className="absolute inset-0 rounded-full"
              />
              <Text className="text-white text-sm font-extrabold">
                {isLoggedIn ? t("profile.myWallet") : t("profile.signIn")}
              </Text>
            </Pressable>
            <会员入口卡
              label={t("profile.membership")}
              onPress={() => router.push(isLoggedIn ? "/profile/member-card" : "/auth")}
            />
          </View>

          <Text className="mt-3 text-xs" style={{ color: Colors.luxe.inkMuted }}>
            {statusLine}
          </Text>
        </ShadowPanel>

        <ShadowPanel className="mt-4 p-4" style={{ borderRadius: s(28) }}>
          <SectionTitle title={t("profile.ordersInMotion")} subtitle={t("profile.ordersInMotionHint")} />
          <View className="flex-row gap-2">
            <OrderStatusCard
              Icon={Wallet}
              label={t("profile.orderToPay")}
              value="—"
              onPress={() => router.push("/orders")}
            />
            <OrderStatusCard
              Icon={Package}
              label={t("profile.orderProcessing")}
              value="—"
              onPress={() => router.push("/orders")}
            />
            <OrderStatusCard
              Icon={Gift}
              label={t("profile.orderShipping")}
              value="—"
              onPress={() => router.push("/orders")}
            />
            <OrderStatusCard
              Icon={Star}
              label={t("profile.orderReviews")}
              value="—"
              onPress={() => router.push("/orders")}
            />
          </View>
        </ShadowPanel>

        <ShadowPanel className="mt-4 p-4" style={{ borderRadius: s(28) }}>
          <SectionTitle title="Quick desk" subtitle="High-frequency paths" />
          <View className="flex-row justify-between">
            <QuickCard
              Icon={History}
              iconImage={ACCOUNT_LOG_ICON}
              label="ACCOUNT"
              title={t("profile.accountLogEntry")}
              body={t("profile.accountLogDesc")}
              width={quickCardWidth}
              onPress={() => router.push("/points/history")}
            />
            <QuickCard
              Icon={Bell}
              label="ACCOUNT"
              title={t("profile.notifications")}
              body="Order and account alerts."
              width={quickCardWidth}
              onPress={() => router.push("/profile/notifications")}
            />
          </View>
          <View className="mt-3 flex-row justify-between">
            <QuickCard
              Icon={Gamepad2}
              label="PLAY"
              title={zhProfile ? "互動樂園" : "Play & rewards"}
              body={zhProfile ? "遊戲、金幣與積分入口" : "Games, coins and points"}
              width={quickCardWidth}
              onPress={() => router.push("/play")}
            />
            <QuickCard
              Icon={Images}
              label="COMMUNITY"
              title={zhProfile ? "社區廣場" : "Community"}
              body={zhProfile ? "會員晒單與中獎故事" : "Buyer photos and stories"}
              width={quickCardWidth}
              onPress={() => router.push("/community")}
            />
          </View>
        </ShadowPanel>

        <ShadowPanel className="mt-4 p-4" style={{ borderRadius: s(28) }}>
          <SectionTitle title={t("profile.myAccount")} subtitle="Compact shortcuts." />
          <ServiceGrid items={accountItems} eyebrow="Account" onPress={handleMenuPress} />
        </ShadowPanel>

        {menuSections.map((section) => (
          <ShadowPanel key={section.title} className="mt-4 p-4" style={{ borderRadius: s(28) }}>
            <SectionTitle title={section.title} subtitle={section.subtitle} />
            <ServiceGrid items={section.items} eyebrow={section.title} onPress={handleMenuPress} />
          </ShadowPanel>
        ))}

        {isLoggedIn ? (
          <View className="px-1 py-5">
            <Pressable
              className="h-12 flex-row items-center justify-center gap-2 rounded-2xl"
              style={({ pressed }) => ({
                borderWidth: 1,
                borderColor: "rgba(239,68,68,0.18)",
                backgroundColor: "#FFFFFF",
                opacity: pressed ? 0.8 : 1,
              })}
              onPress={() => {
                logout();
                router.replace("/auth");
              }}
            >
              <LogOut size={18} color={Colors.error} strokeWidth={2} />
              <Text className="font-extrabold" style={{ color: Colors.error }}>
                {t("profile.logOut")}
              </Text>
            </Pressable>
          </View>
        ) : null}

        <Text className="text-center text-xs pb-2" style={{ color: Colors.luxe.inkSoft }}>
          {t("profile.version", { version: "2.0.1" })}
        </Text>
      </ScrollView>
      <ProfileCloudBuyDock />
    </View>
  );
}
