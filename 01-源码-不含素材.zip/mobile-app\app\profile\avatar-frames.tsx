import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import PageHeader from "@/components/shared/PageHeader";
import { 会员头像框 } from "@/components/member/会员头像框";
import { preloadAvatarFrameAssets } from "@/components/member/会员SVGA播放";
import { Colors, s } from "@/constants/theme";
import { wearAvatarFrame } from "@/lib/api/user";
import { getUserLevelInfo } from "@/lib/api/userLevel";
import { parseUserLevelPayload, resolveMemberFrame } from "@/lib/会员等级";
import {
  MEMBER_AVATAR_FRAMES,
  frameDisplayName,
  frameHowYouGet,
  isFrameOwned,
  isMembershipDefaultFrame,
  ownsTrialAvatarFrame,
  resolveWornFrameId,
  sortAvatarFrames,
  wearFailToast,
  type AvatarFrameId,
} from "@/lib/会员头像框素材";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";

export default function AvatarFramesPickerScreen() {
  const router = useRouter();
  const { i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const authUser = useAuthStore((s) => s.user);
  const setUser = useAuthStore((s) => s.setUser);
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const showToast = useAppStore((s) => s.showToast);
  const [wearing, setWearing] = useState<string | null>(null);

  const { data: levelRaw } = useQuery({
    queryKey: ["userLevelInfo"],
    queryFn: getUserLevelInfo,
    enabled: isLoggedIn,
  });
  const levelPayload = parseUserLevelPayload(isLoggedIn ? levelRaw : null);
  const frameState = resolveMemberFrame({
    isLoggedIn,
    isMoneyLevel: levelPayload.user?.is_money_level,
    isEverLevel: levelPayload.user?.is_ever_level,
    overdueTime: levelPayload.user?.overdue_time,
    memberType: levelPayload.user?.member_type,
    spendUsd: levelPayload.user?.spend_usd ?? levelPayload.user?.pay_price,
  });
  const spendUsd = Number(levelPayload.user?.spend_usd ?? levelPayload.user?.pay_price ?? 0);
  const trialOwned = ownsTrialAvatarFrame({
    trialActive: frameState.trialActive,
    claimedFreeTrial: levelPayload.user?.claimed_free_trial ?? authUser?.claimed_free_trial,
  });

  const wornId = resolveWornFrameId({
    level: frameState.level,
    trial: trialOwned,
    spendUsd,
    frameId: authUser?.avatar_frame,
  });
  const [previewId, setPreviewId] = useState<AvatarFrameId | null>(null);
  const activeId = previewId ?? wornId;
  const preview = useMemo(
    () => MEMBER_AVATAR_FRAMES.find((row) => row.id === activeId),
    [activeId],
  );
  const owned = sortAvatarFrames(
    MEMBER_AVATAR_FRAMES.filter((row) => isFrameOwned(row.id, frameState.level, trialOwned, spendUsd)),
  );
  const locked = sortAvatarFrames(
    MEMBER_AVATAR_FRAMES.filter((row) => !isFrameOwned(row.id, frameState.level, trialOwned, spendUsd)),
  );

  useEffect(() => {
    preloadAvatarFrameAssets(MEMBER_AVATAR_FRAMES);
  }, []);

  const wear = async (id: AvatarFrameId | "") => {
    if (!isLoggedIn) {
      router.push("/auth");
      return;
    }
    if (id && !isFrameOwned(id, frameState.level, trialOwned, spendUsd)) {
      showToast(wearFailToast(new Error(frameHowYouGet(id, zh) ? `${zh ? "这个头像框你还不能穿。" : ""}${frameHowYouGet(id, zh)}` : ""), zh, id), "error");
      return;
    }
    setWearing(id || "default");
    try {
      await wearAvatarFrame(id);
      if (authUser) setUser({ ...authUser, avatar_frame: id });
      setPreviewId(id || null);
      showToast(zh ? "已穿戴" : "Frame equipped", "success");
    } catch (error: unknown) {
      showToast(wearFailToast(error, zh, id), "error");
    } finally {
      setWearing(null);
    }
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={zh ? "头像框图库" : "Avatar frames"} onBackPress={() => router.replace("/profile")} />
      <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}>
        <View className="bg-white rounded-2xl border border-gray-100 p-4 items-center" style={{ overflow: "visible" }}>
          <Text className="text-sm font-extrabold" style={{ color: "#111827" }}>
            {zh ? "当前穿戴" : "Wearing"} · {frameDisplayName(preview, zh)}
          </Text>
          <Text className="text-[11px] mt-1 text-center" style={{ color: "#6B7280" }}>
            {zh
              ? "累计实付每上一档送一个礼物框。会员专属框要等级够才能穿。点格子可预览动效。"
              : "Each spend milestone gifts one frame. Membership exclusives stay locked until that tier. Tap a card to preview motion."}
          </Text>
          <View style={{ marginTop: 18, overflow: "visible" }}>
            <会员头像框
              uri={authUser?.avatar}
              uid={authUser?.uid}
              frameId={activeId}
              level={frameState.level}
              trial={trialOwned}
              size={92}
              zh={zh}
              motion
              showBadge={false}
            />
          </View>
          {activeId && activeId !== wornId && isFrameOwned(activeId, frameState.level, trialOwned, spendUsd) ? (
            <Pressable
              onPress={() => wear(activeId)}
              disabled={!!wearing}
              className="mt-4 rounded-xl py-3 px-8"
              style={{ backgroundColor: Colors.brand.red }}
            >
              {wearing ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text className="text-sm font-extrabold" style={{ color: "#fff" }}>
                  {zh ? "穿戴这个头像框" : "Wear this frame"}
                </Text>
              )}
            </Pressable>
          ) : null}
          {wornId ? (
            <Pressable onPress={() => wear("")} className="mt-2 py-2">
              <Text className="text-xs font-bold" style={{ color: "#6B7280" }}>
                {zh ? "改回当前会员默认框" : "Use default frame for my tier"}
              </Text>
            </Pressable>
          ) : null}
        </View>

        <FrameSection
          title={zh ? `已获得 ${owned.length}` : `Owned ${owned.length}`}
          empty={zh ? "还没有动态框。领取试用或累计实付满 $30 就会开始解锁。" : "No frames yet. Claim the trial or spend $30."}
          rows={owned}
          activeId={activeId}
          wornId={wornId}
          zh={zh}
          avatar={authUser?.avatar}
          uid={authUser?.uid}
          level={frameState.level}
          trial={trialOwned}
          wearing={wearing}
          onPreview={setPreviewId}
          onWear={wear}
        />
        <FrameSection
          title={zh ? `未获得 ${locked.length}` : `Locked ${locked.length}`}
          empty=""
          rows={locked}
          activeId={activeId}
          wornId={wornId}
          zh={zh}
          avatar={authUser?.avatar}
          uid={authUser?.uid}
          level={frameState.level}
          trial={trialOwned}
          wearing={wearing}
          locked
          onPreview={setPreviewId}
          onWear={(id) => {
            if (isMembershipDefaultFrame(id)) return;
            router.push("/profile/member-card");
          }}
        />
      </ScrollView>
    </View>
  );
}

function FrameSection({
  title,
  empty,
  rows,
  activeId,
  wornId,
  zh,
  avatar,
  uid,
  level,
  trial,
  wearing,
  locked,
  onPreview,
  onWear,
}: {
  title: string;
  empty: string;
  rows: typeof MEMBER_AVATAR_FRAMES;
  activeId: AvatarFrameId | null;
  wornId: AvatarFrameId | null;
  zh: boolean;
  avatar?: string | null;
  uid?: number | null;
  level: 0 | 1 | 2 | 3 | 4 | 5 | 6;
  trial: boolean;
  wearing: string | null;
  locked?: boolean;
  onPreview: (id: AvatarFrameId) => void;
  onWear: (id: AvatarFrameId) => void;
}) {
  return (
    <View className="mt-5">
      <Text className="text-base font-bold mb-3" style={{ color: Colors.neutral[800] }}>
        {title}
      </Text>
      {rows.length === 0 ? (
        empty ? (
          <Text className="text-xs" style={{ color: "#6B7280" }}>
            {empty}
          </Text>
        ) : null
      ) : (
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
          {rows.map((row) => {
            const selected = row.id === activeId;
            const wearingNow = row.id === wornId;
            const tierLocked = locked && isMembershipDefaultFrame(row.id);
            return (
              <Pressable
                key={row.id}
                onPress={() => onPreview(row.id)}
                style={{
                  width: "47%",
                  backgroundColor: "#fff",
                  borderRadius: 16,
                  borderWidth: selected ? 2 : 1,
                  borderColor: selected ? Colors.brand.red : "#E5E7EB",
                  paddingTop: 18,
                  paddingBottom: 12,
                  paddingHorizontal: 8,
                  alignItems: "center",
                  overflow: "visible",
                  opacity: locked ? 0.86 : 1,
                }}
              >
                <会员头像框
                  uri={avatar}
                  uid={uid}
                  frameId={row.id}
                  level={level}
                  trial={trial}
                  size={64}
                  zh={zh}
                  motion={selected}
                  showBadge={false}
                />
                <Text className="text-xs font-extrabold mt-2 text-center" style={{ color: "#111827" }}>
                  {frameDisplayName(row, zh)}
                </Text>
                <Text className="text-[10px] mt-0.5 text-center" style={{ color: locked ? Colors.brand.red : "#6B7280" }}>
                  {locked
                    ? frameHowYouGet(row.id, zh)
                    : wearingNow
                      ? zh
                        ? "穿戴中"
                        : "Wearing"
                      : frameHowYouGet(row.id, zh)}
                </Text>
                <Pressable
                  onPress={() => onWear(row.id)}
                  disabled={!!wearing || (wearingNow && !locked) || tierLocked}
                  className="mt-2 rounded-full px-3 py-1.5"
                  style={{ backgroundColor: locked ? "#111827" : wearingNow ? "#E5E7EB" : Colors.brand.red }}
                >
                  <Text className="text-[11px] font-extrabold" style={{ color: wearingNow && !locked ? "#6B7280" : "#fff" }}>
                    {locked
                      ? tierLocked
                        ? zh
                          ? "已锁定"
                          : "Locked"
                        : zh
                          ? "去开通"
                          : "Unlock"
                      : wearingNow
                        ? zh
                          ? "已穿戴"
                          : "Wearing"
                        : zh
                          ? "穿戴"
                          : "Wear"}
                  </Text>
                </Pressable>
              </Pressable>
            );
          })}
        </View>
      )}
    </View>
  );
}
