import React from "react";
import Svg, { Circle, Path } from "react-native-svg";

type Props = {
  size?: number;
  color?: string;
  strokeWidth?: number;
};

/** 开口蚌 + 中间珍珠，和采矿镐同风格的线宽青绿图标 */
export default function PearlClamIcon({
  size = 22,
  color = "#04A8AE",
  strokeWidth = 1.9,
}: Props) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <Path
        d="M5 13.2C6.4 7.6 9.1 5 12 5s5.6 2.6 7 8.2"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M4.4 14.2C5.8 18.2 8.6 20.2 12 20.2s6.2-2 7.6-6"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M6.2 13.6h11.6"
        stroke={color}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
      />
      <Circle cx="12" cy="12.2" r="2.05" fill={color} />
    </Svg>
  );
}
