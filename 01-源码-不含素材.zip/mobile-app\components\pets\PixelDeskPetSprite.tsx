import { useEffect, useMemo } from "react";
import { Platform, StyleSheet, View, type StyleProp, type ViewStyle } from "react-native";
import { Image as ExpoImage } from "expo-image";

import { SpriteSheetPlayer } from "@/components/pets/SpriteSheetPlayer";
import { PET_SPRITE_RENDER_SIZE, getPetActionDefinition, normalizePetAction, type PetActionName } from "@/lib/pet-animations";
import { getPixelDeskPet, type PixelDeskPetAnimationName, type PixelDeskPetId } from "@/lib/pets";

type PixelDeskPetSpriteProps = {
  petId: PixelDeskPetId;
  animation: PixelDeskPetAnimationName | PetActionName;
  size: number;
  style?: StyleProp<ViewStyle>;
  onReadyChange?: (ready: boolean) => void;
};

export function PixelDeskPetSprite({ petId, animation, size, style, onReadyChange }: PixelDeskPetSpriteProps) {
  const requestedSize = Number.isFinite(size) ? size : PET_SPRITE_RENDER_SIZE;
  const lockedSize = Math.max(PET_SPRITE_RENDER_SIZE, Math.round(requestedSize / PET_SPRITE_RENDER_SIZE) * PET_SPRITE_RENDER_SIZE);
  const pet = useMemo(() => getPixelDeskPet(petId), [petId]);
  const normalizedAction = normalizePetAction(animation);
  const sheetAnimationDef = getPetActionDefinition(petId, normalizedAction);
  const sourceResetKey = `${petId}-static`;

  useEffect(() => {
    if (!sheetAnimationDef) {
      return;
    }

    onReadyChange?.(true);
  }, [onReadyChange, sheetAnimationDef]);

  if (sheetAnimationDef) {
    return (
      <View style={[styles.frame, style, { width: lockedSize, height: lockedSize }]}>
        <SpriteSheetPlayer
          displayScale={lockedSize / sheetAnimationDef.frameWidth}
          fps={sheetAnimationDef.fps}
          frameHeight={sheetAnimationDef.frameHeight}
          frameWidth={sheetAnimationDef.frameWidth}
          frames={sheetAnimationDef.frames}
          loop={sheetAnimationDef.loop}
          source={sheetAnimationDef.source}
          sourceFrames={sheetAnimationDef.sourceFrames}
          startFrame={sheetAnimationDef.startFrame}
        />
      </View>
    );
  }

  return (
    <View style={[styles.frame, style, { width: lockedSize, height: lockedSize }]}>
      <ExpoImage
        accessibilityIgnoresInvertColors
        cachePolicy="memory-disk"
        contentFit="contain"
        key={sourceResetKey}
        pointerEvents="none"
        onDisplay={() => {
          onReadyChange?.(true);
        }}
        onError={() => {
          onReadyChange?.(true);
        }}
        source={pet.source}
        style={[
          styles.image,
          { width: lockedSize, height: lockedSize },
          Platform.OS === "web" ? ({ imageRendering: "pixelated" } as never) : null,
        ]}
        transition={0}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  frame: {
    overflow: "hidden",
  },
  image: {
    maxWidth: "100%",
    maxHeight: "100%",
  },
});
