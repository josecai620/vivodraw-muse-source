import { PageHeader } from "@/components/shared";
import { USE_DEV_MOCK_DATA } from "@/constants/env";
import { TealGradient, Colors, s } from "@/constants/theme";
import { usePointsOrderExpress } from "@/hooks";
import { isApiRecord, unwrapApiData } from "@/lib/api/response";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams } from "expo-router";
import { CheckCircle, Copy, MapPin, Package, Phone, Truck } from "lucide-react-native";
import React from "react";
import { useTranslation } from "react-i18next";
import { Alert, Pressable, ScrollView, Text, View } from "react-native";

type TrackingInfo = {
  courier: string;
  trackingNumber: string;
  currentStatus: string;
  estimatedDelivery: string;
};

type TrackingHistoryItem = {
  status: string;
  location: string;
  time: string;
  description: string;
  isCurrent: boolean;
};

type DeliveryAddress = {
  name: string;
  phone: string;
  lines: string[];
};

type ApiTrackingHistory = {
  status?: unknown;
  title?: unknown;
  location?: unknown;
  address?: unknown;
  time?: unknown;
  add_time?: unknown;
  description?: unknown;
  desc?: unknown;
  isCurrent?: unknown;
  is_current?: unknown;
};

type ApiDeliveryAddress = {
  name?: unknown;
  real_name?: unknown;
  phone?: unknown;
  user_phone?: unknown;
  address?: unknown;
  user_address?: unknown;
  city?: unknown;
  country?: unknown;
};

type ApiTrackingExpress = {
  courier?: unknown;
  express_name?: unknown;
  delivery_name?: unknown;
  trackingNumber?: unknown;
  tracking_number?: unknown;
  delivery_id?: unknown;
  currentStatus?: unknown;
  status?: unknown;
  state?: unknown;
  estimatedDelivery?: unknown;
  estimated_delivery?: unknown;
  delivery_time?: unknown;
  list?: ApiTrackingHistory[];
  timeline?: ApiTrackingHistory[];
  traces?: ApiTrackingHistory[];
  address?: ApiDeliveryAddress;
  real_name?: unknown;
  user_phone?: unknown;
  user_address?: unknown;
  city?: unknown;
  country?: unknown;
};

const MOCK_TRACKING_INFO: TrackingInfo = {
  courier: "FedEx Express",
  trackingNumber: "TRK123456789",
  currentStatus: "Out for Delivery",
  estimatedDelivery: "2026-03-07",
};

const MOCK_TRACKING_HISTORY: TrackingHistoryItem[] = [
  {
    status: "Out for Delivery",
    location: "New York, NY - Local Facility",
    time: "2026-03-06 08:30",
    description: "Package is out for delivery and will arrive today",
    isCurrent: true,
  },
  {
    status: "Arrived at Facility",
    location: "New York, NY - Distribution Center",
    time: "2026-03-06 05:15",
    description: "Package arrived at local distribution center",
    isCurrent: false,
  },
  {
    status: "In Transit",
    location: "Philadelphia, PA - Sorting Center",
    time: "2026-03-05 22:45",
    description: "Package is in transit to destination",
    isCurrent: false,
  },
  {
    status: "Departed Facility",
    location: "Los Angeles, CA - Fulfillment Center",
    time: "2026-03-05 14:30",
    description: "Package departed from fulfillment center",
    isCurrent: false,
  },
  {
    status: "Order Processed",
    location: "Los Angeles, CA - Warehouse",
    time: "2026-03-05 10:00",
    description: "Order has been processed and packed",
    isCurrent: false,
  },
];

const MOCK_DELIVERY_ADDRESS: DeliveryAddress = {
  name: "John Doe",
  phone: "+1 (555) 123-4567",
  lines: ["123 Main Street, Apt 4B", "New York, NY 10001", "United States"],
};

function toText(value: unknown, fallback = "") {
  if (value == null) return fallback;
  return String(value);
}

function firstList(...lists: Array<ApiTrackingHistory[] | undefined>) {
  return lists.find((list) => Array.isArray(list) && list.length > 0) ?? [];
}

function buildTrackingInfo(express: ApiTrackingExpress | null): TrackingInfo | null {
  if (!express) return null;
  const trackingNumber = toText(
    express.trackingNumber ?? express.tracking_number ?? express.delivery_id,
  );
  if (!trackingNumber) return null;

  return {
    courier: toText(express.courier ?? express.express_name ?? express.delivery_name, "-"),
    trackingNumber,
    currentStatus: toText(express.currentStatus ?? express.status ?? express.state, "-"),
    estimatedDelivery: toText(
      express.estimatedDelivery ?? express.estimated_delivery ?? express.delivery_time,
      "-",
    ),
  };
}

function buildTrackingHistory(express: ApiTrackingExpress | null): TrackingHistoryItem[] {
  if (!express) return [];
  return firstList(express.list, express.timeline, express.traces).map((item) => ({
    status: toText(item.status ?? item.title),
    location: toText(item.location ?? item.address),
    time: toText(item.time ?? item.add_time),
    description: toText(item.description ?? item.desc),
    isCurrent: Boolean(item.isCurrent ?? item.is_current),
  }));
}

function buildDeliveryAddress(express: ApiTrackingExpress | null): DeliveryAddress | null {
  if (!express) return null;
  const addressRecord = isApiRecord(express.address) ? express.address : {};
  const name = toText(addressRecord.name ?? addressRecord.real_name ?? express.real_name);
  const phone = toText(addressRecord.phone ?? addressRecord.user_phone ?? express.user_phone);
  const lines = [
    addressRecord.address ?? addressRecord.user_address ?? express.user_address,
    addressRecord.city ?? express.city,
    addressRecord.country ?? express.country,
  ]
    .map((line) => toText(line))
    .filter(Boolean);

  if (!name && !phone && lines.length === 0) return null;
  return { name, phone, lines };
}

export default function PointsTrackingScreen() {
  const { t } = useTranslation();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { data } = usePointsOrderExpress(id ?? "");
  const express = unwrapApiData<ApiTrackingExpress | null>(data, null);

  const realTrackingInfo = buildTrackingInfo(express);
  const trackingInfo = realTrackingInfo ?? (USE_DEV_MOCK_DATA ? MOCK_TRACKING_INFO : null);
  const realTrackingHistory = buildTrackingHistory(express);
  const trackingHistory =
    realTrackingHistory.length > 0
      ? realTrackingHistory
      : USE_DEV_MOCK_DATA
        ? MOCK_TRACKING_HISTORY
        : [];
  const deliveryAddress =
    buildDeliveryAddress(express) ?? (USE_DEV_MOCK_DATA ? MOCK_DELIVERY_ADDRESS : null);

  const copyToClipboard = (text: string) => {
    Alert.alert(t("pointsTracking.copied"), text);
  };

  if (!trackingInfo) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("pointsTracking.title")} />
        <View className="flex-1 items-center justify-center px-8">
          <Package size={s(56)} color={Colors.neutral[300]} />
          <Text className="text-xl font-bold text-gray-900 mt-4 mb-2">
            {t("pointsTracking.noTracking")}
          </Text>
          <Text className="text-sm text-gray-500 text-center">
            {t("pointsTracking.noTrackingDesc")}
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("pointsTracking.title")} />

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 32 }}
      >
        <View className="px-4 pt-4">
          <View className="rounded-3xl overflow-hidden">
            <LinearGradient
              colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
              style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6,  padding: 24, borderRadius: 24 }}
            >
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
              <View className="flex-row items-center gap-3 mb-4">
                <View className="w-14 h-14 rounded-full overflow-hidden items-center justify-center">
                  <LinearGradient
                    colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                    start={{ x: 0.5, y: 0 }}
                    end={{ x: 0.5, y: 1 }}
                    style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6, 
                      width: 56,
                      height: 56,
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Truck size={s(28)} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
                  </LinearGradient>
                </View>
                <View className="flex-1">
                  <Text className="text-sm text-white/80 mb-1">
                    {t("pointsTracking.currentStatus")}
                  </Text>
                  <Text className="text-xl font-bold text-white">{trackingInfo.currentStatus}</Text>
                </View>
              </View>

              <View
                className="pt-4 flex-row gap-3"
                style={{ borderTopWidth: 1, borderTopColor: "rgba(255,255,255,0.1)" }}
              >
                <View className="flex-1">
                  <Text className="text-xs text-white/70 mb-1">{t("pointsTracking.courier")}</Text>
                  <Text className="text-sm font-semibold text-white">{trackingInfo.courier}</Text>
                </View>
                <View className="flex-1">
                  <Text className="text-xs text-white/70 mb-1">
                    {t("pointsTracking.estimatedDelivery")}
                  </Text>
                  <Text className="text-sm font-semibold" style={{ color: Colors.primary.DEFAULT }}>
                    {trackingInfo.estimatedDelivery}
                  </Text>
                </View>
              </View>
            </LinearGradient>
          </View>
        </View>

        <View className="px-4 pt-4">
          <View className="bg-white rounded-2xl p-4">
            <View className="flex-row items-center justify-between">
              <View className="flex-1">
                <Text className="text-xs text-gray-500 mb-1">
                  {t("pointsTracking.trackingNumber")}
                </Text>
                <Text
                  className="text-base font-bold text-gray-900"
                  style={{ fontFamily: "monospace" }}
                >
                  {trackingInfo.trackingNumber}
                </Text>
              </View>
              <Pressable
                className="px-4 py-2 bg-gray-100 rounded-lg flex-row items-center gap-2"
                onPress={() => copyToClipboard(trackingInfo.trackingNumber)}
              >
                <Copy size={s(16)} color={Colors.neutral[600]} />
                <Text className="text-sm font-medium text-gray-700">
                  {t("pointsTracking.copy")}
                </Text>
              </Pressable>
            </View>
          </View>
        </View>

        {trackingHistory.length > 0 && (
          <View className="px-4 pt-5">
            <View className="flex-row items-center gap-2 mb-3">
              <Package size={s(16)} color={Colors.brand.red} />
              <Text className="text-sm font-bold text-gray-900">
                {t("pointsTracking.trackingHistory")}
              </Text>
            </View>
            <View className="bg-white rounded-2xl p-5">
              <View className="gap-5">
                {trackingHistory.map((item, index) => (
                  <View
                    key={`${item.status}-${item.time}-${item.location}`}
                    className="flex-row gap-4"
                  >
                    <View className="items-center">
                      <View
                        className="w-4 h-4 rounded-full items-center justify-center"
                        style={{
                          backgroundColor: item.isCurrent ? Colors.brand.red : "#FFFFFF",
                          borderWidth: 2,
                          borderColor: item.isCurrent ? Colors.brand.red : Colors.neutral[300],
                        }}
                      >
                        {item.isCurrent && <View className="w-2 h-2 bg-white rounded-full" />}
                      </View>
                      {index < trackingHistory.length - 1 && (
                        <View
                          className="w-0.5 flex-1"
                          style={{
                            minHeight: 48,
                            backgroundColor:
                              item.isCurrent || trackingHistory[index + 1]?.isCurrent
                                ? Colors.brand.red
                                : Colors.neutral[200],
                          }}
                        />
                      )}
                    </View>

                    <View
                      className="flex-1 pb-2"
                      style={item.isCurrent ? undefined : { opacity: 0.6 }}
                    >
                      <Text
                        className="text-sm font-bold mb-0.5"
                        style={{
                          color: item.isCurrent ? Colors.brand.red : Colors.neutral[900],
                        }}
                      >
                        {item.status}
                      </Text>
                      <Text className="text-xs text-gray-600 mb-1">{item.location}</Text>
                      <Text className="text-xs text-gray-500 mb-2">{item.time}</Text>
                      <Text className="text-xs text-gray-600 leading-4">{item.description}</Text>
                    </View>
                  </View>
                ))}
              </View>
            </View>
          </View>
        )}

        {deliveryAddress && (
          <View className="px-4 pt-5">
            <View className="flex-row items-center gap-2 mb-3">
              <MapPin size={s(16)} color={Colors.brand.red} />
              <Text className="text-sm font-bold text-gray-900">
                {t("pointsTracking.deliveryAddress")}
              </Text>
            </View>
            <View className="bg-white rounded-2xl p-4">
              <View className="flex-row items-start gap-3">
                <View className="w-10 h-10 bg-brand-red-light rounded-full items-center justify-center">
                  <MapPin size={s(20)} color={Colors.brand.red} />
                </View>
                <View className="flex-1">
                  <View className="flex-row items-center justify-between mb-2">
                    <Text className="text-sm font-bold text-gray-900">
                      {deliveryAddress.name || "-"}
                    </Text>
                    <View className="flex-row items-center gap-1.5">
                      <Phone size={s(12)} color={Colors.neutral[600]} />
                      <Text className="text-xs text-gray-600">{deliveryAddress.phone || "-"}</Text>
                    </View>
                  </View>
                  <Text className="text-sm text-gray-700 leading-5">
                    {deliveryAddress.lines.length > 0 ? deliveryAddress.lines.join("\n") : "-"}
                  </Text>
                </View>
              </View>
            </View>
          </View>
        )}

        <View className="px-4 pt-5">
          <View className="rounded-2xl overflow-hidden">
            <LinearGradient
              colors={[Colors.home.warmSurface, Colors.home.background]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <View className="p-4 border border-brand-red-light rounded-2xl">
                <View className="flex-row items-start gap-3">
                  <View className="w-10 h-10 rounded-full overflow-hidden items-center justify-center">
                    <LinearGradient
                      colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                      start={{ x: 0.5, y: 0 }}
                      end={{ x: 0.5, y: 1 }}
                      style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6, 
                        width: 40,
                        height: 40,
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                        <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                      <CheckCircle size={s(20)} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
                    </LinearGradient>
                  </View>
                  <View className="flex-1">
                    <Text className="text-sm font-bold text-gray-900 mb-1">
                      {t("pointsTracking.deliveryTips")}
                    </Text>
                    <View className="gap-1">
                      <Text className="text-xs text-gray-700 leading-4">
                        • {t("pointsTracking.tipUpdates")}
                      </Text>
                      <Text className="text-xs text-gray-700 leading-4">
                        • {t("pointsTracking.tipReceive")}
                      </Text>
                      <Text className="text-xs text-gray-700 leading-4">
                        • {t("pointsTracking.tipCourier")}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
            </LinearGradient>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
