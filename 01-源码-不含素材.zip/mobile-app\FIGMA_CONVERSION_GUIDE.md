# Figma 转码规范 (Figma → React Native + NativeWind)

本文档定义了将 Figma 交付的 Web React 代码转换为本项目 React Native 代码的标准流程。

---

## 一、元素映射表

| Web (Figma 交付) | React Native | 说明 |
|---|---|---|
| `<div>` | `<View>` | 通用容器 |
| `<span>` | `<Text>` | 行内文本也用 Text |
| `<p>`, `<h1>`~`<h6>` | `<Text>` | 用 className 控制字号字重 |
| `<img>` | `<Image>` | 必须加 `source={{ uri }}` + `resizeMode` |
| `<button>`, `<a>` | `<Pressable>` | 所有可点击元素 |
| `<input>` | `<TextInput>` | 搜索框、表单输入 |
| `<svg>` 图标 | `lucide-react-native` | 优先用 lucide 图标库 |
| `<ul>/<li>` | `<View>` 嵌套 | RN 没有列表语义标签 |
| `<ScrollView>` (web) | `<ScrollView>` | 同名可直接用 |
| CSS `linear-gradient` | `<LinearGradient>` | 从 `expo-linear-gradient` 导入 |

## 二、样式转换规则

### 2.1 className 直接可用（NativeWind 支持）

```
flex-1, flex-row, flex-wrap, items-center, justify-between, justify-center
gap-{n}, p-{n}, px-{n}, py-{n}, m-{n}, mx-{n}, my-{n}, mt-{n}, mb-{n}
bg-white, bg-gray-50, bg-gray-100, bg-black
text-white, text-sm, text-base, text-lg, text-xl, text-2xl, text-3xl
font-medium, font-semibold, font-bold, font-extrabold
rounded-{size}, rounded-full, rounded-xl, rounded-2xl, rounded-3xl
border, border-gray-100, border-gray-200
overflow-hidden, relative, absolute
w-full, h-full
line-through
```

### 2.2 需要转为 style 的属性

| Web CSS / Tailwind | RN style 写法 |
|---|---|
| `width: 48.5%` | `style={{ width: "48.5%" }}` |
| `height: 200px` | `style={{ height: 200 }}` |
| `aspect-ratio: 1` | `className="aspect-square"` 或 `style={{ aspectRatio: 1 }}` |
| `box-shadow` | `style={{ shadowColor, shadowOffset, shadowOpacity, shadowRadius, elevation }}` |
| `background: linear-gradient(...)` | `<LinearGradient colors={[...]} />` |
| `position: fixed` | RN 不支持 fixed，用 `absolute` + 安全区 |
| `cursor: pointer` | 不需要，Pressable 自带 |
| `hover:` 前缀 | 不需要，移动端无 hover |
| `grid` 布局 | 用 `flex-row flex-wrap` 模拟 |
| `gap` (CSS Grid) | `gap-{n}` 在 flex 容器上可用 |
| `backdrop-filter: blur` | RN 不直接支持，用 `bg-white/90` 近似 |
| `text-[#CC0000]` | `style={{ color: Colors.brand.red }}` 用 Token |
| `bg-[#CC0000]` | `style={{ backgroundColor: Colors.brand.red }}` 用 Token |

### 2.3 颜色必须用 Token

**禁止**在页面中硬编码颜色值。所有颜色引用 `constants/theme.ts`：

```tsx
import { Colors } from "@/constants/theme";

// 品牌红
Colors.brand.red       // #CC0000
Colors.brand.redDark   // #990000
Colors.brand.redLight  // #FF3333

// 强调色
Colors.accent.gold     // #FFB800
Colors.accent.orange   // #FF6B00

// 中性色（灰度）
Colors.neutral[0]      // #FFFFFF
Colors.neutral[400]    // #9CA3AF
Colors.neutral[700]    // #374151
Colors.neutral[800]    // #1F2937
Colors.neutral[900]    // #111827

// 功能色
Colors.success         // #10B981
Colors.warning         // #F59E0B
Colors.error           // #EF4444
Colors.info            // #3B82F6
```

### 2.4 尺寸必须用响应式缩放

```tsx
import { s } from "@/constants/theme";

// s() 以 390 宽为基准，在大屏手机上自动放大
style={{ fontSize: s(14), width: s(24), height: s(24) }}
```

## 三、共享组件对照表

转码时优先检查是否能用已有组件，避免重复代码：

| UI 模式 | 用哪个组件 | import |
|---|---|---|
| 页面顶栏（返回+标题+右侧） | `<PageHeader title="xxx" />` | `@/components/shared` |
| 区块标题（标题+See All） | `<SectionHeader title="xxx" onAction={fn} />` | `@/components/shared` |
| 商品卡片（图+名+价+按钮） | `<ProductCard id={} image={} name={} price={} />` | `@/components/shared` |
| 价格展示（现价+原价+折扣） | `<PriceDisplay price={} originalPrice={} size="lg" />` | `@/components/shared` |
| 按钮 | `<Button>` | `@/components/ui` |
| 输入框 | `<Input>` | `@/components/ui` |
| 徽标 | `<Badge>` | `@/components/ui` |
| 骨架屏 | `<Skeleton>` | `@/components/ui` |
| 空状态 | `<EmptyState>` | `@/components/ui` |
| 轻提示 | `<Toast>` (全局已挂载) | `useAppStore().showToast()` |

## 四、转码步骤（每次 Figma 交新页面时执行）

### Step 1: 识别页面类型

- 普通页（有 Header + 内容） → 用 `_template_page.tsx`
- 列表页（Header + 筛选 + 商品列表） → 用 `_template_list.tsx`
- 详情页（Header + 大图 + 内容 + 底部操作栏） → 用 `_template_detail.tsx`
- Tab 页（在 (tabs) 目录下，无返回按钮） → 用 `_template_tab.tsx`

### Step 2: 复制模板 → 重命名

```bash
cp mobile-app/templates/_template_page.tsx mobile-app/app/新路径/index.tsx
```

### Step 3: 替换元素

1. `div` → `View`
2. `span/p/h1~h6` → `Text`
3. `img` → `Image`（加 `source={{ uri: normalizeImageUrl(xxx) }}`）
4. `button/a` → `Pressable`
5. `onClick` → `onPress`
6. `className` 中的 Web-only 类删除（如 `cursor-pointer`, `hover:xxx`）

### Step 4: 替换颜色和尺寸

1. 所有 `#XXXXXX` → `Colors.xxx`
2. 固定像素字号 → `s(N)`
3. 图标统一用 `lucide-react-native`

### Step 5: 接入真实数据

1. 在 `lib/api/` 下找对应接口函数
2. 在 `hooks/` 下找或新建 React Query hook
3. 把硬编码数据替换为 hook 返回值
4. 加 loading / error / empty 状态

### Step 6: 注册路由

在 `app/_layout.tsx` 的 `<Stack>` 中添加：
```tsx
<Stack.Screen name="新路径" options={{ animation: "slide_from_right" }} />
```

如果需要在汉堡菜单中可见，在 `components/shared/FloatingNav.tsx` 的 `pages` 数组中添加条目。

---

## 五、常见陷阱

1. **Text 嵌套规则**：RN 中 `<Text>` 只能嵌套 `<Text>`，不能嵌套 `<View>`
2. **Image 必须有尺寸**：RN 的 Image 不会自动撑开，必须给 width/height 或 className 指定
3. **没有 CSS Grid**：用 `flex-row flex-wrap` + 百分比宽度模拟
4. **没有 z-index 随意用**：RN 中同级后渲染的在上面，少数情况才需 `zIndex`
5. **ScrollView 里不能嵌 FlatList**：如果列表数据多，用 FlatList 替代 ScrollView+map
6. **安全区域**：用 `useSafeAreaInsets()` 处理刘海和 Home Indicator
7. **路由**：用 `router.push("/path")` 而非 `<a href>`
