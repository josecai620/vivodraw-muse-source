import { PageHeader } from "@/components/shared";
import ClassicPointsIllustration from "@/components/shared/ClassicPointsIllustration";
import { Colors, Shadows, s } from "@/constants/theme";
import { usePointsProducts } from "@/hooks";
import type { PointsProduct } from "@/lib/api/points";
import { unwrapApiPagedList } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";
import { useRouter } from "expo-router";
import { Trophy } from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Image, Pressable, ScrollView, Text, View } from "react-native";

type ShopTab = "boost" | "badge" | "physical";

type DisplayProduct = {
  id: number;
  name: string;
  image: string;
  points: number;
  tab: ShopTab;
};

function classifyProduct(name: string): ShopTab {
  const n = name.toLowerCase();
  if (
    /badge|avatar frame|emoji|memorial|profile badge/.test(n)
  ) {
    return "badge";
  }
  if (
    /boost|fertilizer|points pack|points mega|double points|pity|lucky|charm|shield|token|spin|combo|refund|cash back|instant credit/.test(
      n,
    )
  ) {
    return "boost";
  }
  return "physical";
}

export default function PointsShopScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const [tab, setTab] = useState<ShopTab>("boost");
  const { data: productsData } = usePointsProducts();

  const products = useMemo(() => {
    return unwrapApiPagedList<PointsProduct>(productsData)
      .map((item) => {
        const name = String(item.store_name ?? item.name ?? item.title ?? t("pointsMall.pointsProduct"));
        return {
          id: Number(item.id ?? 0),
          name,
          image: normalizeImageUrl(String(item.image ?? item.img ?? "")),
          points: Number(item.price ?? item.integral ?? item.points ?? 0) || 0,
          tab: classifyProduct(name),
        } satisfies DisplayProduct;
      })
      .filter((item) => item.id > 0);
  }, [productsData, t]);

  const filtered = products.filter((item) => item.tab === tab);
  const tabs: Array<{ key: ShopTab; label: string }> = [
    { key: "boost", label: t("pointsMall.tabBoost") },
    { key: "badge", label: t("pointsMall.tabBadge") },
    { key: "physical", label: t("pointsMall.tabPhysical") },
  ];

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("pointsMall.exchangeShop")} showBack />

      <View className="px-4 pt-2 pb-3 flex-row gap-2">
        {tabs.map((item) => {
          const active = tab === item.key;
          return (
            <Pressable
              key={item.key}
              className="flex-1 rounded-2xl py-2.5 items-center"
              style={{
                backgroundColor: active ? "#04A8AE" : "#fff",
                borderWidth: 1,
                borderColor: active ? "#04A8AE" : Colors.screen.hairline,
              }}
              onPress={() => setTab(item.key)}
            >
              <Text className="text-xs font-bold" style={{ color: active ? "#fff" : "#374151" }}>
                {item.label}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <ScrollView contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 28 }} showsVerticalScrollIndicator={false}>
        {filtered.length === 0 ? (
          <View className="items-center py-16">
            <ClassicPointsIllustration name="gifts" size={72} />
            <Text className="mt-3 text-sm text-gray-500">{t("pointsMall.noProductsFound")}</Text>
          </View>
        ) : (
          <View className="flex-row flex-wrap justify-between" style={{ rowGap: 12 }}>
            {filtered.map((product) => (
              <Pressable
                key={product.id}
                className="bg-white rounded-2xl overflow-hidden"
                style={{ width: "48.5%", borderWidth: 1, borderColor: Colors.screen.hairline, ...Shadows.raisedSm }}
                onPress={() => router.push({ pathname: "/points/product", params: { id: String(product.id) } })}
              >
                <View className="aspect-square bg-gray-50 items-center justify-center">
                  {product.image ? (
                    <Image source={{ uri: product.image }} className="w-full h-full" resizeMode="contain" />
                  ) : (
                    <ClassicPointsIllustration name="gifts" size={48} />
                  )}
                </View>
                <View className="p-2.5">
                  <Text className="text-sm font-medium text-gray-900 mb-1.5" numberOfLines={2}>
                    {product.name}
                  </Text>
                  <View className="flex-row items-center gap-1">
                    <Trophy size={s(13)} color={Colors.primary.DEFAULT} />
                    <Text className="font-bold" style={{ fontSize: s(14), color: Colors.brand.red }}>
                      {product.points.toLocaleString()}
                    </Text>
                    <Text className="text-xs text-gray-500">{t("pointsMall.pts")}</Text>
                  </View>
                </View>
              </Pressable>
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}
