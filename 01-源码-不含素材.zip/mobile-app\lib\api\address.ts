import { API_ENDPOINTS } from "@/constants/api";
import { http } from "@/lib/http";

export interface Address {
  id: number;
  real_name: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  detail: string;
  is_default: number;
  post_code: string;
  city_id?: number;
  street?: string;
}

export interface SaveAddressInput {
  id?: number;
  real_name: string;
  phone: string;
  province: string;
  city: string;
  district: string;
  detail: string;
  post_code?: string;
  is_default?: boolean | number;
}

export function getAddressList() {
  return http.get<Address[]>(API_ENDPOINTS.address.list);
}

export function saveAddress(data: SaveAddressInput) {
  return http.post(API_ENDPOINTS.address.create, {
    id: data.id ?? 0,
    type: 1,
    real_name: data.real_name,
    phone: data.phone,
    post_code: data.post_code ?? "",
    detail: data.detail,
    is_default: data.is_default ? 1 : 0,
    address: {
      province: data.province,
      city: data.city,
      district: data.district,
      country: "US",
      city_id: 0,
    },
  });
}

export function deleteAddress(id: number) {
  return http.post(API_ENDPOINTS.address.del, { id });
}

export function getDefaultAddress() {
  return http.get<Address>(API_ENDPOINTS.address.default);
}

export function setDefaultAddress(id: number) {
  return http.post(API_ENDPOINTS.address.setDefault, { id });
}
