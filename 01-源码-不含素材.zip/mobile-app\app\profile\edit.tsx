import PageHeader from "@/components/shared/PageHeader";
import { TealGradient,  Colors  } from "@/constants/theme";
import { 动态系统头像 } from "@/components/profile/动态系统头像";
import { SYSTEM_AVATAR_PICKS, resolveUserAvatarSource } from "@/lib/userAvatar";
import { updateProfileFull } from "@/lib/api/user";
import { normalizeImageUrl } from "@/lib/utils";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import { useAvatarUpload } from "@/hooks/useAvatarUpload";
import { useRouter } from "expo-router";
import { Camera, Check, ChevronRight, Upload } from "lucide-react-native";
import type React from "react";
import { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

const GENDER_OPTIONS = [
  { value: 1, labelKey: "profile.male" },
  { value: 2, labelKey: "profile.female" },
  { value: 0, labelKey: "profile.preferNotToSay" },
] as const;

function formatBirthday(timestamp?: number): string {
  if (!timestamp || timestamp === 0) return "";
  const d = new Date(timestamp * 1000);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

function parseBirthdayToTimestamp(value: string, fallback?: number) {
  if (!value) return fallback;
  const timestamp = Math.floor(new Date(`${value}T00:00:00`).getTime() / 1000);
  return Number.isFinite(timestamp) ? timestamp : fallback;
}

export default function EditProfileScreen() {
  const router = useRouter();
  const { t } = useTranslation();
  const user = useAuthStore((s) => s.user);
  const setUser = useAuthStore((s) => s.setUser);
  const showToast = useAppStore((s) => s.showToast);

  const [nickname, setNickname] = useState(user?.nickname ?? "");
  const [sex, setSex] = useState<number>(user?.sex ?? 0);
  const [birthday, setBirthday] = useState(formatBirthday(user?.birthday));
  const [avatarUrl, setAvatarUrl] = useState(user?.avatar ?? "");
  const [saving, setSaving] = useState(false);
  const { uploading: avatarUploading, startUpload, cropModal } = useAvatarUpload({
    persist: false,
    onPicked: setAvatarUrl,
  });

  const hasChanges = useMemo(() => {
    return (
      nickname !== (user?.nickname ?? "") ||
      sex !== (user?.sex ?? 0) ||
      birthday !== formatBirthday(user?.birthday) ||
      avatarUrl !== (user?.avatar ?? "")
    );
  }, [nickname, sex, birthday, avatarUrl, user]);

  const handleAvatarPress = () => {
    startUpload();
  };

  const handleSave = async () => {
    if (saving) return;

    const trimmed = nickname.trim();
    if (!trimmed) {
      showToast(t("profile.nicknamePlaceholder"), "error");
      return;
    }
    setSaving(true);
    try {
      await updateProfileFull({
        avatar: avatarUrl,
        nickname: trimmed,
        sex,
        birthday: birthday || undefined,
      });
      if (user) {
        const birthdayTs = parseBirthdayToTimestamp(birthday, user.birthday);
        setUser({ ...user, avatar: avatarUrl, nickname: trimmed, sex, birthday: birthdayTs });
      }
      showToast(t("profile.profileUpdated"), "success");
      router.back();
    } catch (err: unknown) {
      showToast(getErrorMessage(err, t("profile.profileUpdateFailed")), "error");
    } finally {
      setSaving(false);
    }
  };

  const showDatePicker = () => {
    if (Platform.OS === "web") {
      return;
    }
    // On native, we use Alert with a hint. A full native date picker would require a library.
    // For now the TextInput with date format works cross-platform.
  };

  return (
    <View className="flex-1 bg-gray-50">
      {cropModal}
      <PageHeader title={t("profile.editProfileTitle")} onBackPress={() => router.replace("/profile")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Avatar Section */}
        <View className="items-center py-8 bg-white mb-3">
          <Pressable onPress={handleAvatarPress} className="relative">
            <View className="w-24 h-24 rounded-full items-center justify-center overflow-hidden bg-gray-200">
              {avatarUploading ? (
                <ActivityIndicator color={Colors.brand.red} size="large" />
              ) : (
                <动态系统头像 source={resolveUserAvatarSource(avatarUrl, user?.uid)} size={96} />
              )}
            </View>
            <View
              className="absolute bottom-0 right-0 w-8 h-8 rounded-full items-center justify-center border-2 border-white"
              style={{ }}
            >
              <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 999, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
              <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 999 }} />
              <Camera size={14} color="#fff" />
            </View>
          </Pressable>
          <Text className="text-sm text-gray-500 mt-3">{t("profile.tapToChangeAvatar")}</Text>

          {/* Upload / Camera button */}
          <Pressable
            onPress={handleAvatarPress}
            className="mt-3 flex-row items-center gap-2 px-4 h-9 rounded-full border border-gray-300"
          >
            <Upload size={14} color="#5E5F5E" />
            <Text className="text-sm text-gray-600">{t("profile.uploadPhoto")}</Text>
          </Pressable>
        </View>

        {/* System Avatars */}
        <View className="bg-white px-4 py-4 mb-3">
          <Text className="text-sm font-medium text-gray-900 mb-3">
            {t("profile.systemAvatars")}
          </Text>

          <Text className="text-xs text-gray-500 mb-2">{t("profile.maleAvatars")}</Text>
          <View className="flex-row gap-3 mb-4">
            {SYSTEM_AVATAR_PICKS.filter((pick) => pick.sex === "male").map((pick) => {
              const url = normalizeImageUrl(pick.path);
              const isSelected = avatarUrl === url || avatarUrl === pick.path || String(avatarUrl).endsWith(pick.path);
              return (
                <Pressable key={pick.path} onPress={() => setAvatarUrl(url)} className="relative">
                  <View
                    className={`w-14 h-14 rounded-full overflow-hidden border-2 ${
                      isSelected ? "border-[#04A8AE]" : "border-transparent"
                    }`}
                  >
                    <动态系统头像 source={pick.source} size={56} />
                  </View>
                  {isSelected && (
                    <View className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full items-center justify-center bg-[#04A8AE]">
                      <Check size={12} color="#fff" />
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>

          <Text className="text-xs text-gray-500 mb-2">{t("profile.femaleAvatars")}</Text>
          <View className="flex-row gap-3">
            {SYSTEM_AVATAR_PICKS.filter((pick) => pick.sex === "female").map((pick) => {
              const url = normalizeImageUrl(pick.path);
              const isSelected = avatarUrl === url || avatarUrl === pick.path || String(avatarUrl).endsWith(pick.path);
              return (
                <Pressable key={pick.path} onPress={() => setAvatarUrl(url)} className="relative">
                  <View
                    className={`w-14 h-14 rounded-full overflow-hidden border-2 ${
                      isSelected ? "border-[#04A8AE]" : "border-transparent"
                    }`}
                  >
                    <动态系统头像 source={pick.source} size={56} />
                  </View>
                  {isSelected && (
                    <View className="absolute -bottom-0.5 -right-0.5 w-5 h-5 rounded-full items-center justify-center bg-[#04A8AE]">
                      <Check size={12} color="#fff" />
                    </View>
                  )}
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* Form Fields */}
        <View className="bg-white px-4 mb-3">
          {/* Nickname */}
          <View className="flex-row items-center py-4 border-b border-gray-100">
            <Text className="text-sm font-medium text-gray-900 w-28">{t("profile.nickname")}</Text>
            <TextInput
              className="flex-1 text-sm text-gray-900 text-right"
              value={nickname}
              onChangeText={setNickname}
              placeholder={t("profile.nicknamePlaceholder")}
              placeholderTextColor="#AAAAA8"
              maxLength={60}
            />
          </View>

          {/* Gender */}
          <View className="py-4 border-b border-gray-100">
            <Text className="text-sm font-medium text-gray-900 mb-3">{t("profile.gender")}</Text>
            <View className="flex-row gap-2">
              {GENDER_OPTIONS.map((opt) => {
                const isActive = sex === opt.value;
                return (
                  <Pressable
                    key={opt.value}
                    onPress={() => setSex(opt.value)}
                    className={`flex-1 flex-row items-center justify-center gap-2 h-10 rounded-xl border ${
                      isActive ? "border-[#04A8AE] bg-brand-red-light" : "border-gray-200 bg-white"
                    }`}
                  >
                    {isActive && <Check size={14} color="#04A8AE" />}
                    <Text
                      className={`text-sm font-medium ${isActive ? "text-[#04A8AE]" : "text-gray-700"}`}
                    >
                      {t(opt.labelKey)}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>

          {/* Birthday */}
          <View className="flex-row items-center py-4 border-b border-gray-100">
            <Text className="text-sm font-medium text-gray-900 w-28">{t("profile.birthday")}</Text>
            {Platform.OS === "web" ? (
              <input
                type="date"
                value={birthday}
                onChange={(event: React.ChangeEvent<HTMLInputElement>) =>
                  setBirthday(event.target.value)
                }
                style={{
                  flex: 1,
                  textAlign: "right",
                  border: "none",
                  outline: "none",
                  fontSize: 14,
                  color: birthday ? "#171A1A" : "#AAAAA8",
                  backgroundColor: "transparent",
                }}
                max={new Date().toISOString().split("T")[0]}
              />
            ) : (
              <Pressable
                className="flex-1 flex-row items-center justify-end"
                onPress={showDatePicker}
              >
                <TextInput
                  className="flex-1 text-sm text-gray-900 text-right"
                  value={birthday}
                  onChangeText={(text) => {
                    const cleaned = text.replace(/[^0-9-]/g, "");
                    setBirthday(cleaned);
                  }}
                  placeholder="YYYY-MM-DD"
                  placeholderTextColor="#AAAAA8"
                  maxLength={10}
                  keyboardType="numbers-and-punctuation"
                />
              </Pressable>
            )}
          </View>

          {/* Phone (read-only) */}
          <View className="flex-row items-center py-4">
            <Text className="text-sm font-medium text-gray-900 w-28">{t("profile.phone")}</Text>
            <Text className="flex-1 text-sm text-gray-400 text-right">{user?.phone || "—"}</Text>
            <ChevronRight size={16} color="#d1d5db" style={{ marginLeft: 4 }} />
          </View>
        </View>

        {/* Save Button */}
        <View className="px-4 mt-6">
          <Pressable
            onPress={handleSave}
            disabled={saving || !hasChanges}
            className="h-12 rounded-xl items-center justify-center"
            style={{ backgroundColor: hasChanges && !saving ? "transparent" : "#D1D5DB" }}
          >
            {hasChanges && !saving && (
              <>
                <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
              </>
            )}
            {saving ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Text className="text-white text-base font-semibold">{t("profile.saveChanges")}</Text>
            )}
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}
