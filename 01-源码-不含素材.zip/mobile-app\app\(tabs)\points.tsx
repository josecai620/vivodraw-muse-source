import React, { useEffect, useMemo, useState } from "react";
import {
  Image,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ChevronLeft, Heart, Search, ShoppingCart, Volume2, Gift, LayoutGrid, Wallet } from "lucide-react-native";
import { Colors, Shadows } from "@/constants/theme";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import LuckyShopEntry from "@/components/points/LuckyShopEntry";
import CloudBuyProgress from "@/components/points/CloudBuyProgress";
import {
  useAddPointsCart,
  useAddPointsCollect,
  useDelPointsCollect,
  useNotice,
  usePointsBalance,
  usePointsCollection,
  usePointsIndex,
  usePointsProducts,
  useRevealIndex,
} from "@/hooks";
import { unwrapApiData, unwrapApiPagedList } from "@/lib/api/response";
import { mapCloudProduct, sortCloudBuyCards } from "@/lib/points/cloudBuyParse";
import { RevealMsClock, RevealSlideIn } from "@/components/points/RevealMotion";
import { openCloudBuyCartList, rememberPendingCartItem } from "@/lib/points/openCloudBuyCart";
import { normalizeImageUrl } from "@/lib/utils";
import { useAuthStore } from "@/store/auth";

const TEAL = Colors.primary.DEFAULT;
type SortKey = "hot" | "new" | "value" | "soon";

function toList(data: unknown): any[] {
  const raw = unwrapApiData<any>(data, data);
  if (Array.isArray(raw)) return raw;
  if (Array.isArray(raw?.list)) return raw.list;
  if (Array.isArray(raw?.data)) return raw.data;
  if (Array.isArray(raw?.goods)) return raw.goods;
  if (Array.isArray(raw?.product)) return raw.product;
  return [];
}

export default function PointsMallHomeScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const [sort, setSort] = useState<SortKey>("hot");
  const [keyword, setKeyword] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [collectOverride, setCollectOverride] = useState<Record<number, boolean>>({});
  const [now, setNow] = useState(() => Date.now());
  const [revealFetchedAt, setRevealFetchedAt] = useState(() => Date.now());

  const { data: productsData, refetch: refetchProducts } = usePointsProducts();
  const { data: indexData, refetch: refetchIndex } = usePointsIndex();
  const { data: revealData, refetch: refetchReveal } = useRevealIndex(8000);
  const { data: noticeData, refetch: refetchNotice } = useNotice();
  const { data: balanceData, refetch: refetchBalance } = usePointsBalance();
  const addCart = useAddPointsCart();
  const addCollect = useAddPointsCollect();
  const delCollect = useDelPointsCollect();
  const { data: collectionData, refetch: refetchCollection } = usePointsCollection();

  const colW = Math.floor((Math.min(width, 480) - 16 - 8) / 2);

  const banners = useMemo(() => {
    const idx = unwrapApiData<any>(indexData, {});
    const list = toList(idx?.banner) || toList(idx?.banners) || toList(idx?.slide);
    return list
      .map((b) => ({
        image: normalizeImageUrl(String(b?.pic ?? b?.image ?? b?.img ?? b?.url ?? "")),
        title: String(b?.title ?? b?.name ?? ""),
      }))
      .filter((b) => b.image)
      .slice(0, 1);
  }, [indexData]);

  const noticeText = useMemo(() => {
    const n = unwrapApiData<any>(noticeData, noticeData);
    if (typeof n === "string") return n;
    return String(n?.content ?? n?.title ?? n?.notice ?? t("pointsMall.noticeFallback"));
  }, [noticeData, t]);

  const revealItems = useMemo(() => {
    const raw = unwrapApiData<any>(revealData, revealData);
    const list = toList(raw?.zuixin_list) || toList(raw?.lottery) || toList(raw?.list) || toList(raw);
    const mapped = list.slice(0, 8).map((item: any, i: number) => ({
      id: Number(item?.id ?? item?.kaijiang_id ?? item?.pid ?? i),
      productId: Number(item?.product_id ?? item?.sid ?? item?.id ?? 0),
      name: String(item?.title ?? item?.store_name ?? item?.goods_name ?? item?.name ?? ""),
      image: normalizeImageUrl(String(item?.image ?? item?.img ?? item?.thumb ?? "")),
      djs: Math.max(0, Number(item?.djs ?? 0) || 0),
      nickname: String(item?.nickname ?? ""),
    }));
    return mapped.sort((a, b) => Number(b.djs > 0) - Number(a.djs > 0));
  }, [revealData]);

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    setRevealFetchedAt(Date.now());
  }, [revealData]);

  useEffect(() => {
    const hadPending = revealItems.some((it) => it.djs > 0);
    const stillPending = revealItems.some((it) => Math.max(0, it.djs - (now - revealFetchedAt)) > 0);
    if (hadPending && !stillPending) void refetchReveal();
  }, [now, revealItems, revealFetchedAt, refetchReveal]);

  const products = useMemo(() => {
    let list = unwrapApiPagedList<any>(productsData).map(mapCloudProduct).filter(Boolean) as NonNullable<
      ReturnType<typeof mapCloudProduct>
    >[];
    if (!list.length) {
      const idx = unwrapApiData<any>(indexData, {});
      list = toList(idx?.product ?? idx?.goods ?? idx?.list)
        .map(mapCloudProduct)
        .filter(Boolean) as typeof list;
    }
    return sortCloudBuyCards(list, sort);
  }, [productsData, indexData, sort]);

  useFocusEffect(
    React.useCallback(() => {
      void refetchProducts();
      void refetchIndex();
      void refetchCollection();
    }, [refetchProducts, refetchIndex, refetchCollection]),
  );

  const balance = isLoggedIn
    ? Number((balanceData as any)?.data?.integral ?? (balanceData as any)?.integral ?? 0)
    : 0;

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      await Promise.all([
        refetchProducts(),
        refetchIndex(),
        refetchReveal(),
        refetchNotice(),
        refetchBalance(),
        refetchCollection(),
      ]);
    } finally {
      setRefreshing(false);
    }
  };

  const goProduct = (id: number) => {
    router.push({ pathname: "/points/product", params: { id: String(id) } });
  };

  const requireLogin = () => {
    if (isLoggedIn) return true;
    router.push("/auth");
    return false;
  };

  const collectedIds = useMemo(() => {
    const ids = new Set<number>();
    for (const row of unwrapApiPagedList<any>(collectionData)) {
      const id = Number(row?.id ?? row?.product_id ?? row?.pid ?? 0);
      if (id > 0) ids.add(id);
    }
    return ids;
  }, [collectionData]);

  const isCollected = (productId: number) => collectOverride[productId] ?? collectedIds.has(productId);

  const onToggleCollect = (productId: number) => {
    if (!requireLogin()) return;
    const next = !isCollected(productId);
    setCollectOverride((prev) => ({ ...prev, [productId]: next }));
    const revert = () =>
      setCollectOverride((prev) => {
        const copy = { ...prev };
        delete copy[productId];
        return copy;
      });
    if (next) addCollect.mutate({ id: productId }, { onError: revert });
    else delCollect.mutate({ id: productId }, { onError: revert });
  };

  const onJoin = (item: { id: number; name: string; image: string; remain: number; total: number }) => {
    if (!requireLogin()) return;
    rememberPendingCartItem({
      id: 0,
      productId: item.id,
      name: item.name,
      image: item.image,
      num: 1,
      bianhao: "",
      remain: Math.max(1, item.remain),
      totalNeed: Math.max(1, item.total),
    });
    addCart.mutate(
      { productId: item.id, cartNum: 1 } as any,
      { onSettled: () => openCloudBuyCartList(router) },
    );
  };

  const onSearch = () => {
    const q = keyword.trim();
    router.push({ pathname: "/points/search", params: q ? { q } : {} } as never);
  };

  const sorts: Array<{ key: SortKey; label: string }> = [
    { key: "hot", label: t("pointsMall.sortHot") },
    { key: "new", label: t("pointsMall.sortNew") },
    { key: "value", label: t("pointsMall.sortValue") },
    { key: "soon", label: t("pointsMall.sortSoon") },
  ];

  const shortcuts = [
    { key: "glist", label: t("pointsMall.tabAllPeriods"), Icon: LayoutGrid, href: "/points/glist" },
    { key: "reveal", label: t("pointsMall.tabReveal"), Icon: Gift, href: "/reveal" },
    { key: "fav", label: t("pointsMall.collect"), Icon: Heart, href: "/points/collection" },
    { key: "earn", label: t("pointsMall.shortcutRecharge"), Icon: Wallet, href: "/points/tasks" },
  ];

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <View
        className="px-3 pb-2 flex-row items-center gap-2"
        style={{ paddingTop: Math.max(insets.top, 8), backgroundColor: "#fff" }}
      >
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={t("common.back")}
          className="items-center justify-center"
          style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: "#FFFFFF", ...Shadows.raisedSm }}
          onPress={() => {
            if (router.canGoBack()) router.back();
            else router.push("/" as never);
          }}
        >
          <ChevronLeft size={22} color="#111111" strokeWidth={2.4} />
        </Pressable>
        <Pressable
          className="flex-1 h-9 flex-row items-center rounded-full px-3"
          style={{ backgroundColor: "#F3F4F6" }}
          onPress={onSearch}
        >
          <Search size={14} color="#9CA3AF" />
          <TextInput
            value={keyword}
            onChangeText={setKeyword}
            placeholder={t("pointsMall.searchPlaceholder")}
            placeholderTextColor="#9CA3AF"
            className="flex-1 ml-2 text-sm text-gray-800"
            returnKeyType="search"
            onSubmitEditing={onSearch}
          />
        </Pressable>
        <Pressable
          className="h-9 px-3 rounded-full items-center justify-center"
          style={{ backgroundColor: TEAL }}
          onPress={onSearch}
        >
          <Text className="text-white text-xs font-bold">{t("pointsMall.search")}</Text>
        </Pressable>
      </View>

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={TEAL} />}
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}
      >
        <View className="mx-3 mt-2 rounded-xl overflow-hidden bg-white flex-row items-center">
          {banners[0]?.image ? (
            <Image source={{ uri: banners[0].image }} style={{ flex: 1, height: 132 }} resizeMode="cover" />
          ) : (
            <View className="flex-1 px-4 py-5">
              <Text className="text-lg font-black" style={{ color: TEAL }}>
                {t("pointsMall.duobaoTitle")}
              </Text>
              <Text className="text-sm text-gray-600 mt-1">{t("pointsMall.homeBannerDesc")}</Text>
              <Text className="text-xs text-gray-500 mt-2">
                {t("pointsMall.balance")}: {balance.toLocaleString()}
              </Text>
            </View>
          )}
          <LuckyShopEntry onPress={() => router.push("/points/lucky-shop" as never)} />
        </View>

        <View className="flex-row justify-between px-6 py-3">
          {shortcuts.map((s) => {
            const Icon = s.Icon;
            return (
              <Pressable key={s.key} className="items-center" onPress={() => router.push(s.href as never)}>
                <View
                  className="w-11 h-11 rounded-full items-center justify-center mb-1"
                  style={{ backgroundColor: Colors.primary.light }}
                >
                  <Icon size={20} color={TEAL} />
                </View>
                <Text className="text-[11px] text-gray-700" numberOfLines={1}>
                  {s.label}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <View
          className="mx-3 mb-3 px-3 py-2 rounded-xl flex-row items-center bg-white"
          style={{ borderWidth: 1, borderColor: Colors.screen.hairline }}
        >
          <Volume2 size={14} color={TEAL} />
          <Text className="ml-2 flex-1 text-xs text-gray-700" numberOfLines={1}>
            {noticeText}
          </Text>
        </View>

        <View className="px-3 mb-2">
          <Pressable className="flex-row items-center justify-between mb-2" onPress={() => router.push("/reveal" as never)}>
            <Text className="text-base font-bold text-gray-900">{t("pointsMall.latestReveal")}</Text>
            <Text className="text-xs" style={{ color: TEAL }}>
              {t("pointsMall.seeAll")}
            </Text>
          </Pressable>
          <View style={{ overflow: "hidden" }}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
              {revealItems.map((item, index) => {
                const deadlineAt = revealFetchedAt + item.djs;
                const revealing = item.djs > 0 && deadlineAt > Date.now();
                return (
                  <RevealSlideIn key={`rv-${item.id}`} index={index} from={-88}>
                    <Pressable
                      className="w-32 bg-white rounded-lg overflow-hidden"
                      style={{ borderWidth: 1, borderColor: Colors.screen.hairline }}
                      onPress={() => {
                        if (Number(item.id) > 0) {
                          router.push(`/reveal/${item.id}` as never);
                          return;
                        }
                        if (item.productId) goProduct(item.productId);
                      }}
                    >
                      <View className="h-20 bg-gray-50 items-center justify-center">
                        {item.image ? (
                          <Image source={{ uri: item.image }} className="w-full h-full" resizeMode="contain" />
                        ) : null}
                      </View>
                      <View className="px-2 py-1.5 items-center">
                        {revealing ? (
                          <>
                            <Text className="text-[10px] text-gray-400">{t("pointsMall.countdown")}</Text>
                            <RevealMsClock
                              deadlineAt={deadlineAt}
                              style={{ color: TEAL, fontSize: 12, fontWeight: "900", marginTop: 2 }}
                            />
                          </>
                        ) : item.nickname ? (
                          <>
                            <Text className="text-[10px] text-gray-400">{t("pointsMall.revealWinnerShort")}</Text>
                            <Text className="text-[11px] font-black mt-0.5" style={{ color: TEAL }} numberOfLines={1}>
                              {item.nickname}
                            </Text>
                          </>
                        ) : (
                          <>
                            <Text className="text-[10px] text-gray-400">{t("pointsMall.revealWinnerShort")}</Text>
                            <Text className="text-[11px] font-black mt-0.5" style={{ color: TEAL }}>
                              {t("pointsMall.calculatingShort")}
                            </Text>
                          </>
                        )}
                      </View>
                    </Pressable>
                  </RevealSlideIn>
                );
              })}
            </ScrollView>
          </View>
          {revealItems.length === 0 ? (
            <Text className="text-xs text-gray-400 px-1">{t("pointsMall.noRevealsYet")}</Text>
          ) : null}
        </View>

        <View className="flex-row items-center px-2 bg-white mt-1">
          {sorts.map((s) => {
            const active = sort === s.key;
            return (
              <Pressable key={s.key} className="px-3 py-2.5" onPress={() => setSort(s.key)}>
                <Text
                  className="text-sm font-bold"
                  style={{
                    color: active ? TEAL : "#6B7280",
                    borderBottomWidth: active ? 2 : 0,
                    borderBottomColor: TEAL,
                    paddingBottom: 3,
                  }}
                >
                  {s.label}
                </Text>
              </Pressable>
            );
          })}
          <View className="flex-1" />
          <Pressable className="px-3 py-2.5" onPress={() => router.push("/points/categories" as never)}>
            <Text className="text-sm font-semibold" style={{ color: TEAL }}>
              {t("pointsMall.categories")}
            </Text>
          </Pressable>
        </View>

        <View className="flex-row flex-wrap px-2 pt-2" style={{ gap: 8 }}>
          {products.map((item) => (
            <View
              key={item.id}
              style={{
                width: colW,
                borderRadius: 8,
                backgroundColor: "#fff",
                paddingBottom: 8,
              }}
            >
              <Pressable onPress={() => goProduct(item.id)}>
                <View className="aspect-square bg-gray-50 items-center justify-center overflow-hidden rounded-t-lg">
                  {item.image ? (
                    <Image source={{ uri: item.image }} className="w-full h-full" resizeMode="contain" />
                  ) : null}
                </View>
                <Text className="px-2 mt-1.5 text-[12px] text-gray-900" numberOfLines={2}>
                  {item.name}
                </Text>
                <View className="px-2 mt-1.5">
                  <CloudBuyProgress
                    joined={item.sold}
                    total={item.total}
                    remain={item.remain}
                    joinedLabel={t("pointsMall.joined")}
                    totalLabel={t("pointsMall.totalNeed")}
                    remainLabel={t("pointsMall.remain")}
                  />
                </View>
              </Pressable>
              <View className="flex-row items-center px-2 mt-2" style={{ gap: 4 }}>
                <Pressable
                  className="p-2"
                  hitSlop={10}
                  onPress={(e) => {
                    (e as { stopPropagation?: () => void })?.stopPropagation?.();
                    onToggleCollect(item.id);
                  }}
                >
                  <Heart
                    size={16}
                    color={TEAL}
                    fill={isCollected(item.id) ? TEAL : "transparent"}
                  />
                </Pressable>
                <Pressable
                  className="flex-1 h-7 rounded items-center justify-center"
                  style={{ backgroundColor: TEAL, zIndex: 2 }}
                  onPress={(e) => {
                    (e as { stopPropagation?: () => void })?.stopPropagation?.();
                    onJoin(item);
                  }}
                >
                  <Text className="text-[10px] font-bold text-white">{t("pointsMall.joinNow")}</Text>
                </Pressable>
                <Pressable
                  className="w-7 h-7 rounded items-center justify-center"
                  style={{ borderWidth: 1, borderColor: TEAL }}
                  onPress={() => {
                    if (!requireLogin()) return;
                    addCart.mutate({ productId: item.id, cartNum: 1 } as any);
                  }}
                >
                  <ShoppingCart size={12} color={TEAL} />
                </Pressable>
              </View>
            </View>
          ))}
        </View>

        {products.length === 0 ? (
          <Text className="text-center text-sm text-gray-400 py-10">{t("pointsMall.noProductsFound")}</Text>
        ) : null}
      </ScrollView>

      <PointsMallTabBar />
    </View>
  );
}
