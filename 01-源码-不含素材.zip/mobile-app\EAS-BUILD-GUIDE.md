# EAS Dev Build 操作手册

测试期内测、真机跑原生能力（推送 / 分享 / WebView）都要用 EAS 打 dev build。
Expo Go 跑不了带原生依赖的 app（我们装了 `react-native-webview` / `expo-notifications` 等）。

---

## 一次性准备（全程大约 15 分钟）

### 1. 注册 Expo 账号

<https://expo.dev/signup> 用邮箱注册，免费。

### 2. 装 EAS CLI

```bash
npm install -g eas-cli
eas login
```

### 3. 初始化 EAS 项目

在 `mobile-app/` 目录下：

```bash
cd mobile-app
eas init
```

这个命令会：
- 在 expo.dev 创建一个项目
- 自动把 `projectId` 写进 `app.json` 的 `extra.eas.projectId`（替换掉 `__FILL_AFTER_eas_init__`）
- 把 `owner` 替换成你的 expo 用户名

执行完后再打开 `app.json`，把 `updates.url` 的 `__FILL_AFTER_eas_init__` 部分也手动改成你刚拿到的 projectId（或者跑 `eas update:configure` 自动配好）。

### 4.（iOS only）Apple Developer 账号

- 有账号：`eas credentials` 按提示登录 Apple，让 EAS 帮你生成证书和 provisioning profile
- 没账号：先跳过 iOS，用 Android build 就行（测试期 Android 足够）

Android 不需要任何账号，EAS 自动签名。

---

## 日常使用

所有命令都在 `mobile-app/` 目录里跑。

### Android 内测 apk（推荐先用这个）

```bash
npm run eas:build:dev:android
```

- 10-15 分钟后，EAS 会给一个下载链接
- apk 直接发给团队，手机打开链接装就行
- 之后启动 `npm run start:dev` 起 Metro，apk 连上就能热更新 JS

### iOS 真机内测

```bash
npm run eas:build:dev:ios
```

- 需要先在 `eas credentials` 里把真机 UDID 加到 provisioning profile
- 构建完会给 `.ipa` 下载链接或 TestFlight 入口

### iOS 模拟器（不用 Apple 账号也能跑）

```bash
npm run eas:build:dev:ios-sim
```

下载下来的 `.tar.gz` 解压得到 `.app`，拖到 Xcode 模拟器即可。

### 团队预览版（distribution: internal）

```bash
npm run eas:build:preview:android   # 或 preview:ios
```

预览版不带 devClient，更接近正式包，适合让 PM / 运营试用。

### 正式版（上线用，暂时别用）

```bash
npm run eas:build:prod
```

这会走 `production` profile，API 指向 `https://api.eccobuy.com` + `https://eccobuy.com`，对应"上线美国服务器后"的配置。目前不要跑，除非你已经完成服务器迁移和域名解析。

---

## profile 说明（`eas.json` 里定义的）

| profile | 环境变量 API_BASE | 用途 |
|---------|-------------------|------|
| `development` | `https://vivodraw.com` | 真机内测，带 devClient 支持热更新 |
| `development-simulator` | 同上 | iOS 模拟器专用（不生成签名） |
| `preview` | 同上 | 准正式版，发给非研发试用 |
| `production` | `https://api.eccobuy.com` / `https://eccobuy.com` | 迁完美国服务器后才启用 |

切换服务器时只改 `eas.json` 里 `production.env` 两行即可，代码零改动。

---

## 常见问题

**Q: 为啥 `npm run ios` 不能直接用？**
A: 可以用，但需要本地装 Xcode 和 cocoapods。用 EAS build 省去这些。

**Q: 每次改代码都要重新 build？**
A: 不要。只有新增/升级原生依赖（比如将来加 `react-native-bluetooth`）才需要重 build。日常改 JS/TS 直接 `npm run start:dev`，dev client 会热更新。

**Q: EAS build 要钱吗？**
A: 免费账号每月有 30 次 build 额度，测试期够用。

**Q: 推送 Token 什么时候能拿到？**
A: 测试期可在 dev build 里临时接入推送调试页，拿到后复制保存。为避免生产包暴露测试能力，调试页不要提交到 `app/` 路由目录；也可以在 expo.dev 的 push notifications 工具里直接发测试推送。

---

## 下一步 TODO（上线前）

- [ ] 替换 `app.json` 的 `bundleIdentifier` / `package` 为正式 id（当前 `com.eccomall.app`，确认无冲突）
- [ ] 申请 Apple Developer 账号 ($99/年) 并在 `eas credentials` 里配证书
- [ ] Firebase 项目（FCM）并配置 `google-services.json` 到 Android
- [ ] 把 `eas.json` 的 `production.env` 改成美国服务器域名
- [ ] 打一次 `production` build 过审 App Store / Google Play
