import React from "react";
import { ActivityIndicator, Image, Pressable, ScrollView, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";
import { normalizeImageUrl, formatPrice } from "@/lib/utils";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";
import { useAuthStore } from "@/store/auth";
import { useAddToCartAndCheckout } from "@/hooks";

export default function CombinationDetailScreen() {
  const { t } = useTranslation();
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const addAndCheckout = useAddToCartAndCheckout();

  const comboId = id ? parseInt(id, 10) : 0;

  const { data, isLoading } = useQuery({
    queryKey: ["combinationDetail", comboId],
    queryFn: () => http.get(API_ENDPOINTS.combination.detail(comboId)),
    enabled: comboId > 0,
  });

  const raw = (data as any)?.data ?? data ?? {};
  const product = raw?.storeInfo ?? raw?.product ?? raw ?? {};
  const productId = product.product_id ?? product.id ?? 0;
  const people = product.people ?? 2;
  const images = product.slider_image ?? product.images ?? [product.image ?? product.pic];
  const mainImg = Array.isArray(images) ? images[0] : images ?? "";

  const handleStart = () => {
    if (!isLoggedIn) {
      router.push("/auth");
      return;
    }
    addAndCheckout.mutate({
      productId,
      cartNum: 1,
      new: 1,
      combinationId: comboId,
    });
  };

  if (isLoading || !product) {
    return (
      <View className="flex-1 bg-gray-50 items-center justify-center">
        <ActivityIndicator size="large" color={Colors.brand.red} />
      </View>
    );
  }

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Group Buy" />
      <ScrollView className="flex-1" contentContainerStyle={{ paddingBottom: s(100) }} showsVerticalScrollIndicator={false}>
        <View className="bg-white rounded-b-3xl overflow-hidden">
          <View className="aspect-square bg-gray-100">
            <Image source={{ uri: normalizeImageUrl(mainImg) }} className="w-full h-full" resizeMode="cover" />
          </View>
          <View className="p-4">
            <View className="px-2 py-1 rounded self-start mb-2" style={{ backgroundColor: "#04A8AE15" }}>
              <Text className="text-xs font-bold" style={{ color: "#04A8AE" }}>{t("groupLottery.nPeopleGroup", { count: people })}</Text>
            </View>
            <Text className="text-lg font-bold" style={{ color: Colors.neutral[900] }}>{product.store_name ?? product.title}</Text>
            <View className="flex-row items-baseline mt-3 gap-2">
              <Text className="text-2xl font-bold" style={{ color: Colors.brand.red }}>{formatPrice(product.price ?? product.combination_price)}</Text>
              <Text className="text-sm line-through" style={{ color: Colors.neutral[400] }}>{formatPrice(product.ot_price ?? product.product_price)}</Text>
            </View>
          </View>
        </View>

        <View className="mx-4 mt-6 px-4 py-2 bg-white rounded-xl border border-gray-100">
          <Text className="text-sm" style={{ color: Colors.neutral[600] }}>{product.store_info ?? product.synopsis ?? `Group buy: ${people} people needed.`}</Text>
        </View>
      </ScrollView>

      <View className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3">
        <Pressable
          onPress={handleStart}
          disabled={addAndCheckout.isPending}
          className="h-12 rounded-xl items-center justify-center"
          style={{ opacity: addAndCheckout.isPending ? 0.7 : 1 }}
        >
          <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
          <Text className="text-white font-semibold">{addAndCheckout.isPending ? "Loading..." : "Start Group"}</Text>
        </Pressable>
      </View>
    </View>
  );
}
