import React from "react";
import { View, Text, Pressable, type ViewStyle } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Gift } from "lucide-react-native";
import {
  BoxAccent, BoxText, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, BoxAnimation, bs,
} from "@/lib/boxTheme";

interface GiftRewardCardProps {
  title: string;
  description?: string;
  buttonLabel?: string;
  onPress?: () => void;
  style?: ViewStyle;
}

export function GiftRewardCard({ title, description, buttonLabel, onPress, style }: GiftRewardCardProps) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        { borderRadius: BoxRadius.xl, overflow: "hidden", transform: [{ scale: pressed ? BoxAnimation.press.scale : 1 }] },
        BoxShadows.glow(BoxAccent.goldDark),
        style,
      ]}
    >
      <LinearGradient
        colors={BoxGradients.newbieGold}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          flexDirection: "row",
          alignItems: "center",
          padding: BoxSpacing.lg,
          gap: BoxSpacing.md,
        }}
      >
        <View style={{
          width: bs(44), height: bs(44), borderRadius: bs(22),
          backgroundColor: "rgba(255,255,255,0.15)",
          alignItems: "center", justifyContent: "center",
        }}>
          <Gift size={bs(24)} color="#fff"  style={{ shadowColor: "rgba(12,31,31,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
        </View>

        <View style={{ flex: 1 }}>
          <Text style={[BoxTypography.bodyBold, { color: "#fff" }]}>{title}</Text>
          {description && (
            <Text style={[BoxTypography.caption, { color: "rgba(255,255,255,0.8)", marginTop: 2 }]}>
              {description}
            </Text>
          )}
        </View>

        {buttonLabel && (
          <View style={{
            paddingHorizontal: BoxSpacing.md,
            paddingVertical: BoxSpacing.sm,
            borderRadius: BoxRadius.full,
            backgroundColor: "rgba(255,255,255,0.2)",
          }}>
            <Text style={[BoxTypography.caption, { color: "#fff", fontWeight: "700" }]}>
              {buttonLabel}
            </Text>
          </View>
        )}
      </LinearGradient>
    </Pressable>
  );
}
