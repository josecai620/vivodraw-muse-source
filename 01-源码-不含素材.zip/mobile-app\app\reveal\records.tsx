import React, { useMemo, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useRevealMyRecords } from "@/hooks/usePoints";
import { normalizeImageUrl } from "@/lib/utils";

const TEAL = Colors.primary.DEFAULT;
type Tab = "all" | "ing" | "won";

function statusOf(item: any): Tab {
  const s = Number(item?.status ?? 0);
  if (s >= 1) return "won";
  return "ing";
}

export default function RevealRecordsScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState<Tab>("all");
  const { data, isLoading } = useRevealMyRecords();

  const rows = useMemo(() => {
    const list = (data as any)?.data?.lists ?? (data as any)?.lists ?? [];
    return (Array.isArray(list) ? list : []).map((item: any) => ({
      id: Number(item.id ?? 0),
      productId: Number(item.product_id ?? 0),
      name: String(item.store_name ?? ""),
      image: normalizeImageUrl(String(item.image ?? "")),
      period: String(item.bianhao ?? ""),
      shares: Number(item.huanqu_num ?? item.exchange_num ?? 0),
      status: statusOf(item),
      code: String(item.zj_unique ?? ""),
    })).filter((row: { id: number }) => row.id > 0);
  }, [data]);

  const shown = tab === "all" ? rows : rows.filter((r) => r.status === tab);
  const tabs: { key: Tab; label: string }[] = [
    { key: "all", label: t("pointsMall.tabAllPeriods") },
    { key: "ing", label: t("pointsMall.inProgressTab") },
    { key: "won", label: t("pointsMall.wonGoods") },
  ];

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.buyRecords")} />
      <View className="flex-row bg-white px-3" style={{ gap: 8 }}>
        {tabs.map((item) => {
          const on = tab === item.key;
          return (
            <Pressable key={item.key} className="px-2 py-2.5" onPress={() => setTab(item.key)}>
              <Text
                className="text-sm font-bold"
                style={{
                  color: on ? TEAL : "#6B7280",
                  borderBottomWidth: on ? 2 : 0,
                  borderBottomColor: TEAL,
                  paddingBottom: 3,
                }}
              >
                {item.label}
              </Text>
            </Pressable>
          );
        })}
      </View>
      <ScrollView contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}>
        {isLoading && rows.length === 0 ? (
          <ActivityIndicator color={TEAL} style={{ marginTop: 40 }} />
        ) : shown.length === 0 ? (
          <Text className="text-center text-gray-400 py-16">{t("pointsMall.noMyRecords")}</Text>
        ) : (
          shown.map((row) => (
            <Pressable
              key={row.id}
              className="flex-row bg-white px-3 py-3 border-b border-gray-100"
              onPress={() =>
                row.status === "won"
                  ? router.push({ pathname: "/points/redemption-info", params: { id: String(row.id) } })
                  : router.push(`/reveal/${row.id}` as never)
              }
            >
              <View className="w-16 h-16 bg-gray-50 rounded overflow-hidden mr-3">
                {row.image ? <Image source={row.image} style={{ width: 64, height: 64 }} contentFit="contain" /> : null}
              </View>
              <View className="flex-1">
                <Text className="text-[11px]" style={{ color: TEAL }}>
                  {t("pointsMall.periodN", { n: row.period || "-" })}
                </Text>
                <Text className="text-sm text-gray-900 mt-0.5" numberOfLines={2}>
                  {row.name}
                </Text>
                <Text className="text-xs text-gray-500 mt-1">
                  {t("pointsMall.joinedShares", { n: row.shares || 0 })}
                </Text>
                {row.status === "won" && row.code ? (
                  <Text className="text-xs font-mono mt-0.5" style={{ color: TEAL }}>
                    {t("pointsMall.luckyCode")} {row.code}
                  </Text>
                ) : null}
              </View>
              <Text className="self-center text-xs font-bold" style={{ color: TEAL }}>
                {row.status === "won" ? t("pointsMall.fillAddress") : t("pointsMall.viewDetail")}
              </Text>
            </Pressable>
          ))
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
