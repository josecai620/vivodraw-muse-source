import { TabBagIcon, TabChestIcon, TabDealIcon, TabPeopleIcon } from "@/components/shared/TabNavIcons";
import { Colors } from "@/constants/theme";
import { useAppStore } from "@/store/app";
import { useCartStore } from "@/store/cart";
import { Tabs } from "expo-router";
import React, { useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import {
  Platform,
  Text,
  View,
  useWindowDimensions,
  type ViewStyle,
  type TextStyle,
} from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSequence,
  withSpring,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const ACTIVE_COLOR = Colors.primary.DEFAULT; // teal #04A8AE
const INACTIVE_ICON = "#5E5F5E"; // 未选中：深灰线性
const INACTIVE_LABEL = "#9AA09F";

type LineIconProps = {
  size?: number;
  color?: string;
  strokeWidth?: number;
};
type LineIcon = React.ComponentType<LineIconProps>;

function TabIcon({
  Icon,
  label,
  focused,
  badge,
}: {
  Icon: LineIcon;
  label: string;
  focused: boolean;
  badge?: number;
}) {
  const scale = useSharedValue(1);
  const prev = useRef(focused);

  useEffect(() => {
    if (focused && !prev.current) {
      scale.value = withSequence(
        withSpring(1.18, { damping: 6, stiffness: 320 }),
        withSpring(1, { damping: 10, stiffness: 200 }),
      );
    }
    prev.current = focused;
  }, [focused, scale]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <Animated.View accessibilityLabel={label} style={[animStyle, tabIconStyles.wrap]}>
      <View>
        <Icon
          size={28}
          color={focused ? ACTIVE_COLOR : INACTIVE_ICON}
          strokeWidth={focused ? 1.9 : 1.65}
        />
        {badge != null && badge > 0 && (
          <View style={tabIconStyles.badge}>
            <Text style={tabIconStyles.badgeText}>{badge > 99 ? "99+" : badge}</Text>
          </View>
        )}
      </View>
      {/* 选中底座：一条短 teal 实心圆角横（参考稿语言）；未选中透明等高占位防跳动 */}
      <View
        style={{
          width: 18,
          height: 3,
          borderRadius: 2,
          marginTop: 3,
          backgroundColor: focused ? ACTIVE_COLOR : "transparent",
        }}
      />
    </Animated.View>
  );
}

const tabIconStyles: Record<string, ViewStyle | TextStyle> = {
  wrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  badge: {
    position: "absolute",
    top: -5,
    right: -9,
    backgroundColor: ACTIVE_COLOR,
    borderRadius: 9,
    minWidth: 16,
    height: 16,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 3,
    borderWidth: 1.5,
    borderColor: "#FFFFFF",
  },
  badgeText: {
    color: "#fff",
    fontSize: 8.5,
    fontWeight: "800",
  },
};

export default function TabLayout() {
  const { width } = useWindowDimensions();
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const cartCount = useCartStore((st) => st.count);
  const uiScale = Math.min(Math.max(width / 390, 1), 1.16);

  // 贴底收敛：白底铺到屏幕最底，不悬空留缝；安全区由底栏自身垫高
  const contentH = Math.round(62 * uiScale);
  const bottomInset = Platform.OS === "web" ? 0 : insets.bottom;

  return (
    <Tabs
      safeAreaInsets={{ top: 0, right: 0, bottom: 0, left: 0 }}
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: true,
        tabBarActiveTintColor: ACTIVE_COLOR,
        tabBarInactiveTintColor: INACTIVE_LABEL,
        tabBarStyle: {
          position: "absolute",
          left: 0,
          right: 0,
          bottom: 0,
          height: contentH + bottomInset,
          borderRadius: 0,
          backgroundColor: "#FFFFFF",
          borderWidth: 0,
          borderTopWidth: 1,
          borderColor: Colors.screen.hairline,
          paddingTop: 0,
          paddingBottom: bottomInset,
          paddingHorizontal: Math.round(6 * uiScale),
          elevation: 8,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.06,
          shadowRadius: 8,
        },
        tabBarItemStyle: {
          marginHorizontal: Math.round(2 * uiScale),
          height: contentH,
          borderRadius: 0,
          paddingTop: 0,
          paddingBottom: 0,
        },
        tabBarIconStyle: {
          marginTop: Math.round(3 * uiScale),
        },
        tabBarLabelStyle: {
          marginTop: Math.round(2 * uiScale),
          marginBottom: Math.round(2 * uiScale),
          fontSize: Math.round(10 * uiScale),
          lineHeight: Math.round(12 * uiScale),
          fontWeight: "700",
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: t("tabs.home"),
          tabBarIcon: ({ focused }) => (
            <TabIcon Icon={TabBagIcon} label={t("tabs.home")} focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="categories"
        options={{
          title: t("tabs.browse"),
          tabBarIcon: ({ focused }) => (
            <TabIcon Icon={TabDealIcon} label={t("tabs.browse")} focused={focused} />
          ),
        }}
        listeners={({ navigation }) => ({
          tabPress: () => {
            if (navigation.isFocused()) {
              useAppStore.getState().cycleCategoryColumns(width);
            }
          },
        })}
      />
      <Tabs.Screen
        name="points"
        options={{
          href: null,
          title: t("tabs.points"),
          tabBarStyle: { display: "none" },
          tabBarIcon: ({ focused }) => (
            <TabIcon Icon={TabDealIcon} label={t("tabs.points")} focused={focused} />
          ),
        }}
      />
      <Tabs.Screen
        name="cart"
        options={{
          title: t("tabs.cart"),
          tabBarIcon: ({ focused }) => (
            <TabIcon Icon={TabChestIcon} label={t("tabs.cart")} focused={focused} badge={cartCount} />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: t("tabs.me"),
          tabBarIcon: ({ focused }) => (
            <TabIcon Icon={TabPeopleIcon} label={t("tabs.me")} focused={focused} />
          ),
        }}
      />
    </Tabs>
  );
}
