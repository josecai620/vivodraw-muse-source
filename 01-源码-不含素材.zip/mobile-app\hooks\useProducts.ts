import {
  type ProductListParams,
  getCategories,
  getHotProducts,
  getProductDetail,
  getProductList,
  searchProducts,
} from "@/lib/api/product";
import { useQuery } from "@tanstack/react-query";

export function useProductList(params: ProductListParams, options?: { enabled?: boolean }) {
  return useQuery({
    queryKey: ["products", params],
    queryFn: () => getProductList(params),
    staleTime: 60_000,
    ...options,
  });
}

export function useProductDetail(id: number) {
  return useQuery({
    queryKey: ["product", id],
    queryFn: () => getProductDetail(id),
    enabled: id > 0,
  });
}

export function useHotProducts() {
  return useQuery({
    queryKey: ["hotProducts"],
    queryFn: () => getHotProducts({ page: 1, limit: 10 }),
  });
}

export function useCategories() {
  return useQuery({
    queryKey: ["categories"],
    queryFn: getCategories,
    staleTime: 5 * 60_000,
  });
}

export function useSearch(keyword: string) {
  return useQuery({
    queryKey: ["search", keyword],
    queryFn: () => searchProducts(keyword),
    enabled: keyword.length > 0,
  });
}
