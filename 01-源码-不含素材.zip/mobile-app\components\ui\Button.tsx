import React from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  ActivityIndicator,
  type ViewStyle,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
} from "react-native-reanimated";
import { Colors, Duration, s } from "@/constants/theme";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

type Variant = "primary" | "secondary" | "outline" | "ghost" | "danger";
type Size = "sm" | "md" | "lg";
// 渐变受光方向：lr 左→右 / rl 右→左 / tb 上→下（默认，最立体）/ bt 下→上
type GradientDirection = "lr" | "rl" | "tb" | "bt";

interface ButtonProps {
  children: string;
  variant?: Variant;
  size?: Size;
  direction?: GradientDirection;
  disabled?: boolean;
  loading?: boolean;
  fullWidth?: boolean;
  onPress?: () => void;
  style?: ViewStyle;
}

const sizeClasses: Record<Size, { container: string; text: string }> = {
  sm: { container: "h-9 px-4", text: "text-sm font-semibold" },
  md: { container: "h-12 px-6", text: "text-base font-bold" },
  lg: { container: "h-14 px-8", text: "text-lg font-bold" },
};

const variantStyles: Record<Variant, { bg: string; border?: string; text: string }> = {
  primary: { bg: Colors.brand.red, text: Colors.white },
  secondary: { bg: Colors.luxe.surfaceTint, border: Colors.luxe.hairline, text: Colors.brand.red },
  outline: { bg: "transparent", border: Colors.brand.red, text: Colors.brand.red },
  ghost: { bg: "transparent", text: Colors.brand.red },
  danger: { bg: Colors.error, text: Colors.white },
};

// 同色系三段：受光面(亮) -> 主色 -> 背光面(暗)，保证白字对比且更立体
type Shade = { light: string; base: string; dark: string };
const SHADE: Partial<Record<Variant, Shade>> = {
  primary: { light: "#33C6CC", base: "#08AEB4", dark: "#07858C" },
  danger: { light: "#F47070", base: "#EF4444", dark: "#C82828" },
};

const DIR: Record<GradientDirection, { start: { x: number; y: number }; end: { x: number; y: number }; order: [number, number, number] }> = {
  lr: { start: { x: 0, y: 0.5 }, end: { x: 1, y: 0.5 }, order: [2, 1, 0] }, // 左暗→右亮
  rl: { start: { x: 1, y: 0.5 }, end: { x: 0, y: 0.5 }, order: [0, 1, 2] }, // 右暗→左亮
  tb: { start: { x: 0.5, y: 0 }, end: { x: 0.5, y: 1 }, order: [0, 1, 2] }, // 上亮→下暗（默认，最立体）
  bt: { start: { x: 0.5, y: 1 }, end: { x: 0.5, y: 0 }, order: [2, 1, 0] }, // 下暗→上亮
};

function buildGradient(shade: Shade, dir: GradientDirection): [string, string, string] {
  const seq: [string, string, string] = [shade.light, shade.base, shade.dark];
  const o = DIR[dir].order;
  return [seq[o[0]], seq[o[1]], seq[o[2]]];
}

export default function Button({
  children,
  variant = "primary",
  size = "md",
  direction = "tb",
  disabled = false,
  loading = false,
  fullWidth = false,
  onPress,
  style,
}: ButtonProps) {
  const scale = useSharedValue(1);
  const pressed = useSharedValue(0);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => {
    scale.value = withTiming(0.97, { duration: Duration.fast });
    pressed.value = withTiming(1, { duration: Duration.fast });
  };

  const handlePressOut = () => {
    scale.value = withTiming(1, { duration: Duration.normal });
    pressed.value = withTiming(0, { duration: Duration.normal });
  };

  const isDisabled = disabled || loading;
  const variantStyle = variantStyles[variant];
  const shade = SHADE[variant];
  const radius = s(16);
  const isSolid = variant === "primary" || variant === "danger";

  return (
    <AnimatedPressable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      disabled={isDisabled}
      style={[
        animatedStyle,
        {
          backgroundColor: shade ? "transparent" : variantStyle.bg,
          borderRadius: radius,
          borderWidth: variant === "ghost" ? 0 : 1,
          borderColor:
            variantStyle.border ??
            (isSolid ? "rgba(255,255,255,0.32)" : Colors.luxe.hairline),
          // 同色柔光投影：按钮底部偏深的同色阴影，营造悬浮凸起
          shadowColor:
            variant === "primary" ? "#04A8AE" : variant === "danger" ? "#EF4444" : "transparent",
          shadowOffset: { width: 0, height: 8 },
          shadowOpacity: isSolid ? 0.32 : 0,
          shadowRadius: 18,
          elevation: isSolid ? 6 : 0,
        },
        isDisabled && { opacity: 0.5 },
        style,
      ]}
      className={`flex-row items-center justify-center ${sizeClasses[size].container} ${fullWidth ? "w-full" : ""}`}
    >
      {shade ? (
        <LinearGradient
          pointerEvents="none"
          colors={buildGradient(shade, direction)}
          start={DIR[direction].start}
          end={DIR[direction].end}
          style={[StyleSheet.absoluteFill, { borderRadius: radius }]}
        >
          <LinearGradient
            pointerEvents="none"
            colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]}
            start={{ x: 0.5, y: 0 }}
            end={{ x: 0.5, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        </LinearGradient>
      ) : null}
      {loading ? (
        <ActivityIndicator
          size="small"
          color={variant === "outline" || variant === "ghost" || variant === "secondary" ? Colors.brand.red : "#fff"}
        />
      ) : (
        <Text
          className={sizeClasses[size].text}
          style={{
            color: variantStyle.text,
            backgroundColor: "transparent",
            // 实心按钮白字加极轻下浮雕，浮在渐变表面上
            ...(isSolid
              ? {
                  textShadowColor: "rgba(0,0,0,0.18)",
                  textShadowOffset: { width: 0, height: 1 },
                  textShadowRadius: 2,
                }
              : null),
          }}
        >
          {children}
        </Text>
      )}
    </AnimatedPressable>
  );
}
