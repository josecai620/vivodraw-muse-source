/**
 * 概率公示 - 各稀有度精确概率展示（合规要求）
 */
import React, { useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Info, ShieldCheck, ChevronDown, ChevronRight } from "lucide-react-native";
import { BoxHeader, RarityBar } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, getRarityTier, bs, RARITY_ORDER,
} from "@/lib/boxTheme";
import { useBoxTuijian } from "@/hooks";

const GLOBAL_RATES = [
  { rarity: "common", rate: "45.00%", descKey: "probability.commonDesc" },
  { rarity: "uncommon", rate: "30.00%", descKey: "probability.uncommonDesc" },
  { rarity: "rare", rate: "15.00%", descKey: "probability.rareDesc" },
  { rarity: "epic", rate: "7.00%", descKey: "probability.epicDesc" },
  { rarity: "legendary", rate: "2.50%", descKey: "probability.legendaryDesc" },
  { rarity: "secret", rate: "0.50%", descKey: "probability.secretDesc" },
] as const;

export default function ProbabilityPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const { data: boxes } = useBoxTuijian();
  const [expandedBox, setExpandedBox] = useState<number | null>(null);

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("probability.title")} showThemeToggle={false} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(96) }}>
          {/* Compliance Notice */}
          <LinearGradient
            colors={[BoxAccent.goldDim, "transparent"]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{
              borderRadius: BoxRadius.xl,
              padding: BoxSpacing.lg,
              marginBottom: BoxSpacing["2xl"],
              flexDirection: "row",
              alignItems: "flex-start",
              gap: BoxSpacing.md,
              borderWidth: 1,
              borderColor: BoxAccent.goldBorder,
            }}
          >
            <ShieldCheck size={bs(20)} color={BoxAccent.gold} />
            <View style={{ flex: 1 }}>
              <Text style={[BoxTypography.bodyBold, { color: BoxAccent.gold, marginBottom: BoxSpacing.xs }]}>
                {t("probability.noticeTitle")}
              </Text>
              <Text style={[BoxTypography.caption, { color: BoxText.secondary, lineHeight: bs(18) }]}>
                {t("probability.noticeDesc")}
              </Text>
            </View>
          </LinearGradient>

          {/* Global Rates Table */}
          <Text style={[BoxTypography.h2, { color: BoxText.primary, marginBottom: BoxSpacing.md }]}>
            {t("probability.globalRates")}
          </Text>
          <View style={{
            borderRadius: BoxRadius.xl,
            overflow: "hidden",
            marginBottom: BoxSpacing["2xl"],
            backgroundColor: BoxSurfaces.card,
            borderWidth: 1,
            borderColor: BoxBorders.default,
          }}>
            {GLOBAL_RATES.map((item, index) => {
              const rarityConfig = getRarityTier(item.rarity);
              return (
                <View
                  key={item.rarity}
                  style={{
                    padding: BoxSpacing.lg,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    borderBottomWidth: index < GLOBAL_RATES.length - 1 ? 1 : 0,
                    borderBottomColor: BoxBorders.subtle,
                  }}
                >
                  <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.md, flex: 1 }}>
                    <View style={{
                      width: bs(40),
                      height: bs(40),
                      borderRadius: BoxRadius.md,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: rarityConfig.bgSubtle,
                    }}>
                      <View style={{
                        width: bs(14),
                        height: bs(14),
                        borderRadius: bs(7),
                        backgroundColor: rarityConfig.color,
                      }} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>
                        {t("rarity." + item.rarity)}
                      </Text>
                      <Text style={[BoxTypography.micro, { color: BoxText.tertiary, marginTop: 2 }]}>
                        {t(item.descKey)}
                      </Text>
                    </View>
                  </View>
                  <Text style={[BoxTypography.price, { color: rarityConfig.color }]}>
                    {item.rate}
                  </Text>
                </View>
              );
            })}
          </View>

          {/* Distribution Chart */}
          <Text style={[BoxTypography.h2, { color: BoxText.primary, marginBottom: BoxSpacing.md }]}>
            {t("probability.distributionChart")}
          </Text>
          <View style={{
            borderRadius: BoxRadius.xl,
            padding: BoxSpacing.lg,
            marginBottom: BoxSpacing["2xl"],
            backgroundColor: BoxSurfaces.card,
            borderWidth: 1,
            borderColor: BoxBorders.default,
          }}>
            <RarityBar height={bs(28)} style={{ marginBottom: BoxSpacing.lg, borderRadius: BoxRadius.full }} />
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: BoxSpacing.md }}>
              {GLOBAL_RATES.map((item) => {
                const rarityConfig = getRarityTier(item.rarity);
                return (
                  <View key={item.rarity} style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.xs }}>
                    <View style={{
                      width: bs(10),
                      height: bs(10),
                      borderRadius: BoxRadius.sm,
                      backgroundColor: rarityConfig.color,
                    }} />
                    <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
                      {t("rarity." + item.rarity)} {item.rate}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>

          {/* Per-Series Rates */}
          {boxes && boxes.length > 0 && (
            <>
              <Text style={[BoxTypography.h2, { color: BoxText.primary, marginBottom: BoxSpacing.md }]}>
                {t("probability.seriesDetail")}
              </Text>
              {boxes.map((box: any) => {
                const distribution = (box as any).rarityDistribution || {};
                const hasDistribution = Object.keys(distribution).length > 0;
                const isExpanded = expandedBox === box.id;
                return (
                  <Pressable
                    key={box.id}
                    onPress={() => {
                      if (hasDistribution) {
                        setExpandedBox(isExpanded ? null : box.id);
                      } else {
                        router.push(`/box/${box.id}`);
                      }
                    }}
                    style={{
                      borderRadius: BoxRadius.xl,
                      padding: BoxSpacing.lg,
                      marginBottom: BoxSpacing.md,
                      backgroundColor: BoxSurfaces.card,
                      borderWidth: 1,
                      borderColor: isExpanded ? BoxAccent.goldBorder : BoxBorders.default,
                    }}
                  >
                    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: hasDistribution ? BoxSpacing.md : 0 }}>
                      <Text style={[BoxTypography.bodyBold, { color: BoxText.primary, flex: 1 }]} numberOfLines={1}>
                        {box.name || t("wishlist.defaultSeries")}
                      </Text>
                      {hasDistribution ? (
                        <ChevronDown
                          size={bs(16)}
                          color={BoxAccent.gold}
                          style={{ transform: [{ rotate: isExpanded ? "180deg" : "0deg" }] } as any}
                        />
                      ) : (
                        <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.xs }}>
                          <Text style={[BoxTypography.caption, { color: BoxAccent.gold }]}>
                            {t("probability.viewDetail")}
                          </Text>
                          <ChevronRight size={bs(14)} color={BoxAccent.gold} />
                        </View>
                      )}
                    </View>
                    {hasDistribution ? (
                      <>
                        <RarityBar
                          items={Object.entries(distribution).map(([tier, pct]) => ({
                            tier,
                            probability: Number(pct) || 0,
                          }))}
                          height={bs(6)}
                          style={{ marginBottom: isExpanded ? BoxSpacing.md : 0 }}
                        />
                        {isExpanded && (
                          <View style={{ gap: BoxSpacing.sm, marginTop: BoxSpacing.sm }}>
                            {Object.entries(distribution).map(([rarity, pct]) => {
                              const rc = getRarityTier(rarity);
                              return (
                                <View key={rarity} style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                                  <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm }}>
                                    <View style={{
                                      width: bs(8),
                                      height: bs(8),
                                      borderRadius: bs(4),
                                      backgroundColor: rc.color,
                                    }} />
                                    <Text style={[BoxTypography.caption, { color: BoxText.secondary }]}>
                                      {t("rarity." + rarity)}
                                    </Text>
                                  </View>
                                  <Text style={[BoxTypography.caption, { color: rc.color }]}>
                                    {String(pct)}%
                                  </Text>
                                </View>
                              );
                            })}
                          </View>
                        )}
                      </>
                    ) : (
                      <Text style={[BoxTypography.micro, { color: BoxText.tertiary }]}>
                        {t("probability.useBaseRates")}
                      </Text>
                    )}
                  </Pressable>
                );
              })}
            </>
          )}

          {/* Legal Footer */}
          <View style={{
            marginTop: BoxSpacing["2xl"],
            padding: BoxSpacing.lg,
            borderRadius: BoxRadius.xl,
            backgroundColor: BoxSurfaces.deep,
            borderWidth: 1,
            borderColor: BoxBorders.subtle,
          }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm, marginBottom: BoxSpacing.sm }}>
              <Info size={bs(14)} color={BoxText.tertiary} />
              <Text style={[BoxTypography.caption, { color: BoxText.tertiary }]}>
                {t("probability.tips")}
              </Text>
            </View>
            <Text style={[BoxTypography.micro, { color: BoxText.disabled, lineHeight: bs(18) }]}>
              {t("probability.tip1")}{"\n"}
              {t("probability.tip2")}{"\n"}
              {t("probability.tip3")}{"\n"}
              {t("probability.tip4")}
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
