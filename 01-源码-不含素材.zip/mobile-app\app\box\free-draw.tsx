/**
 * Free Daily Draw — 免费每日一抽
 * Core retention mechanic: variable ratio reinforcement (80/18/2%)
 */
import React, { useState } from "react";
import { Pressable, Text, View, ActivityIndicator } from "react-native";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Gift, Sparkles, Zap, Clock, Package } from "lucide-react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { BoxHeader, RarityBadge, BoxActionButton } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, bs,
} from "@/lib/boxTheme";
import { useFreeDraw } from "@/hooks";
import { useAppStore } from "@/store/app";

export default function FreeDrawPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const showToast = useAppStore((s) => s.showToast);
  const [drawn, setDrawn] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [drawing, setDrawing] = useState(false);

  const { check, doDraw } = useFreeDraw();
  const { data: drawStatus, isLoading } = check();
  const drawMutation = doDraw;

  const available = drawStatus?.available ?? false;
  const todayResult = drawStatus?.draw_result;

  const handleDraw = async () => {
    if (!available || drawing) return;
    setDrawing(true);
    try {
      const res = await drawMutation.mutateAsync();
      setResult(res);
      setDrawn(true);
    } catch (err: any) {
      showToast(err?.message || "Draw failed", "error");
    }
    setDrawing(false);
  };

  const rarityColors: Record<number, string> = { 1: BoxText.secondary, 2: "#04A8AE", 3: "#04A8AE" };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("freeDraw.title")} showThemeToggle={false} />

      <View style={{ flex: 1, padding: BoxSpacing.lg, alignItems: "center", justifyContent: "center" }}>
        {isLoading ? (
          <ActivityIndicator size="large" color={BoxAccent.gold} />
        ) : drawn && result ? (
          <View style={{ alignItems: "center", width: "100%" }}>
            <LinearGradient
              colors={result.rarity_level >= 3 ? BoxGradients.goldWarm : [BoxSurfaces.card, BoxSurfaces.deep]}
              style={{ width: "100%", borderRadius: BoxRadius["3xl"], padding: BoxSpacing["2xl"],
                alignItems: "center", borderWidth: 2,
                borderColor: result.rarity_level >= 3 ? BoxAccent.gold : BoxBorders.default, ...BoxShadows.elevated }}>
              {result.rarity_level >= 3 ? <Sparkles size={bs(48)} color={BoxAccent.gold} /> : <Gift size={bs(48)} color={BoxText.secondary} />}
              <Text style={[BoxTypography.h1, { color: rarityColors[result.rarity_level] || BoxText.primary, marginTop: BoxSpacing.lg, textAlign: "center" }]}>
                {result.item_name}
              </Text>
              <RarityBadge tier={String(result.rarity_level)} size="md" style={{ marginTop: BoxSpacing.md }} />
              {result.is_rare && (
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: BoxSpacing.md }}>
                  <Sparkles size={bs(15)} color={BoxAccent.gold} />
                  <Text style={[BoxTypography.body, { color: BoxAccent.gold, textAlign: "center" }]}>{t("freeDraw.rareCongrats")}</Text>
                </View>
              )}
            </LinearGradient>
            <BoxActionButton title={t("freeDraw.goToBackpack")} variant="primary"
              onPress={() => router.push("/box/backpack")} style={{ marginTop: BoxSpacing["2xl"], width: "100%" }} />
          </View>
        ) : todayResult && !available ? (
          <View style={{ alignItems: "center", width: "100%" }}>
            <LinearGradient colors={BoxGradients.goldWarm} style={{ width: "100%", borderRadius: BoxRadius["3xl"],
              padding: BoxSpacing["2xl"], alignItems: "center", ...BoxShadows.glow(BoxAccent.gold) }}>
              <Clock size={bs(48)} color={BoxAccent.gold} />
              <Text style={[BoxTypography.h2, { color: BoxText.primary, marginTop: BoxSpacing.lg, textAlign: "center" }]}>{t("freeDraw.alreadyDrawn")}</Text>
              <View style={{ borderRadius: BoxRadius.xl, padding: BoxSpacing.lg, marginTop: BoxSpacing.lg,
                backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: BoxBorders.default, width: "100%",
                flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 }}>
                <Package size={bs(15)} color={BoxAccent.gold} />
                <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>{todayResult.item_name}</Text>
                <RarityBadge tier={todayResult.rarity} size="sm" style={{ marginTop: BoxSpacing.sm }} />
              </View>
              <Text style={[BoxTypography.caption, { color: BoxText.tertiary, marginTop: BoxSpacing.lg, textAlign: "center" }]}>{t("freeDraw.comeBackTomorrow")}</Text>
            </LinearGradient>
          </View>
        ) : (
          <View style={{ alignItems: "center", width: "100%" }}>
            <LinearGradient colors={BoxGradients.goldWarm} style={{ width: bs(160), height: bs(160),
              borderRadius: bs(80), alignItems: "center", justifyContent: "center",
              marginBottom: BoxSpacing["2xl"], ...BoxShadows.glow(BoxAccent.gold) }}>
              <Gift size={bs(64)} color={BoxAccent.gold} />
            </LinearGradient>
            <Text style={[BoxTypography.h1, { color: BoxText.primary, textAlign: "center" }]}>{t("freeDraw.dailyFree")}</Text>
            <Text style={[BoxTypography.body, { color: BoxText.secondary, textAlign: "center", marginTop: BoxSpacing.md }]}>{t("freeDraw.description")}</Text>
            <View style={{ flexDirection: "row", gap: BoxSpacing.md, marginTop: BoxSpacing["2xl"], marginBottom: BoxSpacing["2xl"] }}>
              {[{ label: "Common", pct: "80%", color: BoxText.secondary }, { label: "Uncommon", pct: "18%", color: "#04A8AE" }, { label: "Rare", pct: "2%", color: "#04A8AE" }].map((r) => (
                <View key={r.label} style={{ alignItems: "center", padding: BoxSpacing.md, borderRadius: BoxRadius.lg,
                  backgroundColor: BoxSurfaces.card, borderWidth: 1, borderColor: BoxBorders.default }}>
                  <Text style={[BoxTypography.hero, { color: r.color }]}>{r.pct}</Text>
                  <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>{r.label}</Text>
                </View>
              ))}
            </View>
            <Pressable onPress={handleDraw} disabled={drawing} style={{ width: "100%", height: bs(56),
              borderRadius: BoxRadius["2xl"], alignItems: "center", justifyContent: "center",
              backgroundColor: drawing ? BoxAccent.goldDim : BoxAccent.gold,
              ...BoxShadows.glow(BoxAccent.gold), opacity: drawing ? 0.6 : 1 }}>
              {drawing ? <ActivityIndicator color={BoxText.onGold} /> : (
                <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm }}>
                  <Zap size={bs(20)} color={BoxText.onGold} />
                  <Text style={[BoxTypography.buttonLarge, { color: BoxText.onGold }]}>{t("freeDraw.drawNow")}</Text>
                </View>
              )}
            </Pressable>
            <Text style={[BoxTypography.micro, { color: BoxText.tertiary, marginTop: BoxSpacing.md, textAlign: "center" }]}>{t("freeDraw.resetsDaily")}</Text>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}
