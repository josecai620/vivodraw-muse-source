import React from "react";
import { Pressable, Text, View, ActivityIndicator, type ViewStyle } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import {
  BoxAccent, BoxText, BoxSurfaces, BoxBorders, BoxGradients,
  BoxTypography, BoxRadius, BoxShadows, BoxAnimation, bs,
} from "@/lib/boxTheme";

type Variant = "primary" | "secondary" | "ghost" | "danger";

interface BoxActionButtonProps {
  title: string;
  variant?: Variant;
  icon?: React.ReactNode;
  loading?: boolean;
  disabled?: boolean;
  compact?: boolean;
  onPress?: () => void;
  style?: ViewStyle;
}

export function BoxActionButton({
  title,
  variant = "primary",
  icon,
  loading,
  disabled,
  compact,
  onPress,
  style,
}: BoxActionButtonProps) {
  const isDisabled = disabled || loading;
  const h = compact ? bs(40) : bs(52);

  if (variant === "primary" && !isDisabled) {
    return (
      <Pressable
        onPress={onPress}
        disabled={isDisabled}
        style={({ pressed }) => [
          { borderRadius: BoxRadius.lg, overflow: "hidden", transform: [{ scale: pressed ? BoxAnimation.press.scale : 1 }] },
          style,
        ]}
      >
        <LinearGradient
          colors={BoxGradients.goldCta}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={{
            height: h,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            paddingHorizontal: 20,
            ...BoxShadows.glow(BoxAccent.gold),
          }}
        >
          {/* 顶部白色内高光 */}
          <View style={{
            position: "absolute", top: 0, left: 10, right: 10, height: "42%",
            borderTopLeftRadius: BoxRadius.lg, borderTopRightRadius: BoxRadius.lg,
            borderBottomLeftRadius: 999, borderBottomRightRadius: 999,
            backgroundColor: "rgba(255,255,255,0.18)",
          }} />
          {loading ? (
            <ActivityIndicator size="small" color={BoxText.onGold} />
          ) : (
            <>
              {icon}
              <Text style={[compact ? BoxTypography.buttonSmall : BoxTypography.button, { color: BoxText.onGold }]}>
                {title}
              </Text>
            </>
          )}
        </LinearGradient>
      </Pressable>
    );
  }

  const variantStyles: Record<string, { bg: string; text: string; border?: string }> = {
    primary: { bg: BoxSurfaces.elevated, text: BoxText.disabled },
    secondary: { bg: BoxSurfaces.card, text: BoxText.primary, border: BoxBorders.default },
    ghost: { bg: "transparent", text: BoxAccent.gold },
    danger: { bg: BoxAccent.redMuted, text: BoxAccent.red, border: "rgba(239,68,68,0.3)" },
  };
  const vs = variantStyles[isDisabled ? "primary" : variant];

  return (
    <Pressable
      onPress={onPress}
      disabled={isDisabled}
      style={({ pressed }) => [
        {
          height: h,
          borderRadius: BoxRadius.lg,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          gap: 8,
          paddingHorizontal: 20,
          backgroundColor: vs.bg,
          borderWidth: vs.border ? 1 : 0,
          borderColor: vs.border,
          opacity: isDisabled ? 0.5 : 1,
          transform: [{ scale: pressed ? BoxAnimation.press.scale : 1 }],
        },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator size="small" color={vs.text} />
      ) : (
        <>
          {icon}
          <Text style={[compact ? BoxTypography.buttonSmall : BoxTypography.button, { color: vs.text }]}>
            {title}
          </Text>
        </>
      )}
    </Pressable>
  );
}
