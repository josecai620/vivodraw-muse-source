import AsyncStorage from "@react-native-async-storage/async-storage";

const KEY = "@search_history";
const MAX = 10;

export async function getRecentSearches(): Promise<string[]> {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.slice(0, MAX) : [];
  } catch {
    return [];
  }
}

export async function saveRecentSearches(list: string[]): Promise<void> {
  try {
    const trimmed = list.slice(0, MAX);
    await AsyncStorage.setItem(KEY, JSON.stringify(trimmed));
  } catch {
    // ignore
  }
}
