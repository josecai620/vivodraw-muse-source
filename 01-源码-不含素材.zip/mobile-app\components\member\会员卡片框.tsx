import React, { useEffect, useRef } from "react";
import { Animated, Easing, View } from "react-native";
import { Image as ExpoImage } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { MEMBER_FRAME_TIERS, MEMBER_TRIAL_SKIN, type MemberFrameLevel } from "@/lib/会员等级";

const LV5_CARD = require("../../assets/member/名片卡-LV5-钻石.webp");
const LV5_CARD_RATIO = 320 / 191;

export function 会员卡片框({
  level = 0,
  children,
  trial = false,
  motion,
}: {
  level?: MemberFrameLevel;
  children: React.ReactNode;
  trial?: boolean;
  motion?: boolean;
}) {
  const tier =
    trial && level === 0
      ? MEMBER_TRIAL_SKIN
      : (MEMBER_FRAME_TIERS[level] ?? MEMBER_FRAME_TIERS[0]);
  const animated = motion ?? tier.motion;
  const useArt = level === 5 && !trial;
  const shine = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (useArt) return;
    const duration = !animated
      ? 0
      : trial
        ? 2200
        : level >= 6
          ? 1500
          : level >= 5
            ? 1800
            : level >= 4
              ? 2600
              : level >= 3
                ? 3400
                : 2800;
    if (!duration) return;
    const loop = Animated.loop(
      Animated.timing(shine, {
        toValue: 1,
        duration,
        easing: Easing.inOut(Easing.quad),
        useNativeDriver: true,
      }),
    );
    loop.start();
    return () => loop.stop();
  }, [animated, level, shine, trial, useArt]);

  const translateX = shine.interpolate({ inputRange: [0, 1], outputRange: [-80, 160] });

  if (useArt) {
    return (
      <View style={{ width: "100%", aspectRatio: LV5_CARD_RATIO }}>
        <ExpoImage
          source={LV5_CARD}
          style={{ position: "absolute", left: 0, top: 0, right: 0, bottom: 0 }}
          contentFit="contain"
          pointerEvents="none"
        />
        <View style={{ width: "48%", height: "100%", paddingLeft: "8%", paddingTop: "18%", paddingRight: 6, justifyContent: "center" }}>
          {children}
        </View>
      </View>
    );
  }

  return (
    <View
      style={{
        borderRadius: 18,
        padding: level >= 4 ? 2 : 1,
        overflow: "hidden",
        backgroundColor: tier.ring,
        shadowColor: tier.ring,
        shadowOpacity: 0.28 + level * 0.06,
        shadowRadius: 6 + level * 2,
        shadowOffset: { width: 0, height: 4 },
        elevation: 3 + level,
      }}
    >
      <LinearGradient
        colors={[tier.cardFrom, tier.cardTo, "#FFFFFF"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ borderRadius: 16, padding: 10, overflow: "hidden" }}
      >
        {animated ? (
          <Animated.View
            pointerEvents="none"
            style={{
              position: "absolute",
              top: -20,
              bottom: -20,
              width: 36,
              backgroundColor: "rgba(255,255,255,0.45)",
              transform: [{ translateX }, { rotate: "18deg" }],
            }}
          />
        ) : null}
        {children}
      </LinearGradient>
    </View>
  );
}
