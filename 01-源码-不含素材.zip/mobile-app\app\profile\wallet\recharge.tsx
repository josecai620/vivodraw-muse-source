import PageHeader from "@/components/shared/PageHeader";
import { Colors, s } from "@/constants/theme";
import { unwrapApiRecord } from "@/lib/api/response";
import { getRechargeIndex } from "@/lib/api/wallet";
import type { RechargeQuota } from "@/lib/api/wallet";
import { useQuery } from "@tanstack/react-query";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";

const PRESET_AMOUNTS = [10, 50, 100, 200, 500, 1000];

type RechargeIndexData = {
  recharge_quota?: RechargeQuota[];
  recharge_attention?: string[];
  [key: string]: unknown;
};

export default function RechargeScreen() {
  const { t } = useTranslation();
  const [amount, setAmount] = useState("");
  const [selectedQuotaId, setSelectedQuotaId] = useState<number | null>(null);

  const { data } = useQuery({
    queryKey: ["rechargeIndex"],
    queryFn: getRechargeIndex,
  });

  const rechargeIndex = unwrapApiRecord<RechargeIndexData>(data, {});
  const quotaList = Array.isArray(rechargeIndex.recharge_quota) ? rechargeIndex.recharge_quota : [];
  const attention = Array.isArray(rechargeIndex.recharge_attention)
    ? rechargeIndex.recharge_attention.filter(
        (item): item is string => typeof item === "string" && item.trim().length > 0,
      )
    : [];

  const handleSubmit = () => {
    const price =
      selectedQuotaId != null ? Number(quotaList[selectedQuotaId]?.price ?? 0) : Number(amount);
    if (!price || price <= 0) {
      Alert.alert(t("common.notice"), t("wallet.recharge.enterAmount"));
      return;
    }
    Alert.alert(t("wallet.recharge.comingSoonTitle"), t("wallet.recharge.comingSoonDesc"));
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("wallet.recharge.title")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
        showsVerticalScrollIndicator={false}
      >
        {quotaList.length > 0 ? (
          <View className="mb-4">
            <Text className="font-semibold mb-3" style={{ color: Colors.neutral[800] }}>
              {t("wallet.recharge.selectAmount")}
            </Text>
            <View className="flex-row flex-wrap gap-2">
              {quotaList.map((q, i) => {
                const p = Number(q.price ?? 0);
                const give = q.give_price ? `+${q.give_price}` : "";
                const quotaKey =
                  typeof q.id === "number" || typeof q.id === "string"
                    ? q.id
                    : `${p}-${q.give_price ?? 0}`;
                return (
                  <Pressable
                    key={quotaKey}
                    onPress={() => {
                      setSelectedQuotaId(i);
                      setAmount("");
                    }}
                    style={{
                      paddingHorizontal: s(16),
                      paddingVertical: s(12),
                      borderRadius: s(12),
                      backgroundColor:
                        selectedQuotaId === i ? `${Colors.brand.red}15` : Colors.white,
                      borderWidth: 1,
                      borderColor: selectedQuotaId === i ? Colors.brand.red : Colors.neutral[200],
                    }}
                  >
                    <Text
                      style={{
                        fontWeight: "600",
                        color: selectedQuotaId === i ? Colors.brand.red : Colors.neutral[700],
                      }}
                    >
                      ${p}
                      {give ? ` ${give}` : ""}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
          </View>
        ) : (
          <View className="mb-4">
            <Text className="font-semibold mb-3" style={{ color: Colors.neutral[800] }}>
              {t("wallet.recharge.presetAmounts")}
            </Text>
            <View className="flex-row flex-wrap gap-2">
              {PRESET_AMOUNTS.map((a) => (
                <Pressable
                  key={a}
                  onPress={() => {
                    setSelectedQuotaId(null);
                    setAmount(String(a));
                  }}
                  style={{
                    paddingHorizontal: s(16),
                    paddingVertical: s(12),
                    borderRadius: s(12),
                    backgroundColor: amount === String(a) ? `${Colors.brand.red}15` : Colors.white,
                    borderWidth: 1,
                    borderColor: amount === String(a) ? Colors.brand.red : Colors.neutral[200],
                  }}
                >
                  <Text
                    style={{
                      fontWeight: "600",
                      color: amount === String(a) ? Colors.brand.red : Colors.neutral[700],
                    }}
                  >
                    ${a}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        )}

        <View className="mb-4">
          <Text className="font-semibold mb-2" style={{ color: Colors.neutral[800] }}>
            {t("wallet.recharge.customAmount")}
          </Text>
          <TextInput
            value={amount}
            onChangeText={(t) => {
              setAmount(t.replace(/[^0-9.]/g, ""));
              setSelectedQuotaId(null);
            }}
            placeholder="0.00"
            placeholderTextColor={Colors.neutral[400]}
            keyboardType="decimal-pad"
            style={{
              padding: s(14),
              borderRadius: s(12),
              backgroundColor: Colors.white,
              borderWidth: 1,
              borderColor: Colors.neutral[200],
              color: Colors.neutral[800],
              fontSize: s(16),
            }}
          />
        </View>

        {attention?.length > 0 && (
          <View className="mb-4 p-4 rounded-xl" style={{ backgroundColor: Colors.neutral[100] }}>
            <Text className="text-sm" style={{ color: Colors.neutral[600] }}>
              {attention.join("\n")}
            </Text>
          </View>
        )}

        <Pressable
          onPress={handleSubmit}
          style={{
            paddingVertical: s(14),
            borderRadius: s(12),
            backgroundColor: "#08AEB4",
            alignItems: "center",
            shadowColor: "#04A8AE",
            shadowOffset: { width: 0, height: 6 },
            shadowOpacity: 0.3,
            shadowRadius: 12,
            elevation: 6,
          }}
        >
          <Text className="font-semibold" style={{ color: "#FFF", fontSize: s(16) }}>
            {t("wallet.recharge.ctaComingSoon")}
          </Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}
