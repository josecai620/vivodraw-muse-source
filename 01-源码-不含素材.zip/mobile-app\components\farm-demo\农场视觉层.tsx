import { Image, Pressable, StyleSheet, Text, View } from "react-native";

const avatar = require("../../assets/极简农场/hud-头像.webp");
const coinBar = require("../../assets/极简农场/hud-金币条.webp");
const star = require("../../assets/极简农场/hud-等级星.webp");
const progress = require("../../assets/极简农场/hud-进度条.webp");
const guardCard = require("../../assets/极简农场/hud-守护卡.webp");
const dog = require("../../assets/极简农场/hud-看门狗.webp");
const dockTray = require("../../assets/极简农场/dock-托盘.webp");
const utilBubble = require("../../assets/极简农场/util-气泡.webp");
const iconPlant = require("../../assets/极简农场/icon-种植.webp");
const iconHarvest = require("../../assets/极简农场/icon-收成.webp");
const iconClear = require("../../assets/极简农场/icon-清除.webp");
const iconGuard = require("../../assets/极简农场/icon-守护.webp");
const iconFriends = require("../../assets/极简农场/icon-偷菜.webp");
const iconStorage = require("../../assets/极简农场/icon-仓库.webp");
const iconAlert = require("../../assets/极简农场/icon-提醒.webp");
const iconLab = require("../../assets/极简农场/icon-实验室.webp");

type Props = {
  remaining: number;
  harvestCount?: number;
  balanceLabel?: string;
  onHarvest: () => void;
  onChromeTap?: (id: string) => void;
  harvestDisabled?: boolean;
};

export function FarmVisualChrome({
  remaining,
  harvestCount = 18,
  balanceLabel = "12,680",
  onHarvest,
  onChromeTap,
  harvestDisabled,
}: Props) {
  const tap = (id: string) => () => onChromeTap?.(id);

  return (
    <View pointerEvents="box-none" style={styles.wrap}>
      {/* Top HUD */}
      <View style={styles.topHud} pointerEvents="box-none">
        <Pressable style={styles.avatarWrap} onPress={tap("avatar")}>
          <Image source={avatar} style={styles.avatar} />
          <Text style={styles.avatarFace}></Text>
        </Pressable>
        <Pressable style={styles.levelWrap} onPress={tap("level")}>
          <Image source={progress} style={styles.progress} />
          <View style={styles.starWrap}>
            <Image source={star} style={styles.star} />
            <Text style={styles.starText}>2</Text>
          </View>
          <Text style={styles.levelLabel}>{harvestCount} 次收成</Text>
        </Pressable>
        <Pressable style={styles.coinWrap} onPress={tap("balance")}>
          <Image source={coinBar} style={styles.coinBar} />
          <Text style={styles.coinText}>{balanceLabel}</Text>
        </Pressable>
      </View>

      <Pressable style={styles.guardCard} onPress={tap("guard")}>
        <Image source={guardCard} style={styles.guardCardImg} />
        <View style={styles.guardCopy}>
          <Text style={styles.guardTitle}>看门犬巡逻</Text>
          <Text style={styles.guardMeta}>{remaining >= 900 ? "试玩无限" : `剩余次数 ${remaining}`}</Text>
        </View>
      </Pressable>

      <View style={styles.utilityRail}>
        {[
          { id: "storage", icon: iconStorage, label: "仓库" },
          { id: "alert", icon: iconAlert, label: "提醒", badge: "3" },
          { id: "lab", icon: iconLab, label: "实验室" },
        ].map((item) => (
          <Pressable key={item.id} style={styles.utilPill} onPress={tap(item.id)}>
            <Image source={utilBubble} style={styles.utilBubble} />
            <Image source={item.icon} style={styles.utilIcon} />
            <Text style={styles.utilLabel}>{item.label}</Text>
            {item.badge ? (
              <View style={styles.utilBadge}>
                <Text style={styles.utilBadgeText}>{item.badge}</Text>
              </View>
            ) : null}
          </Pressable>
        ))}
      </View>

      <Image source={dog} style={styles.dog} />

      {/* Bottom dock — harvest is the only real action */}
      <View style={styles.dock}>
        <Image source={dockTray} style={styles.dockBg} />
        <View style={styles.dockActions}>
          {[
            { id: "plant", icon: iconPlant, label: "种植", action: false },
            { id: "harvest", icon: iconHarvest, label: "收成", action: true },
            { id: "clear", icon: iconClear, label: "清除", action: false },
            { id: "guardBtn", icon: iconGuard, label: "守护", action: false },
            { id: "friends", icon: iconFriends, label: "偷菜", action: false },
          ].map((item) => (
            <Pressable
              key={item.id}
              disabled={item.action ? harvestDisabled : false}
              onPress={item.action ? onHarvest : tap(item.id)}
              style={({ pressed }) => [
                styles.dockBtn,
                item.action && styles.dockHero,
                pressed && styles.dockPressed,
                item.action && harvestDisabled && styles.dockDisabled,
              ]}
            >
              <Image source={item.icon} style={styles.dockIcon} />
              <Text style={[styles.dockLabel, item.action && styles.dockHeroLabel]}>{item.label}</Text>
            </Pressable>
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { ...StyleSheet.absoluteFillObject, zIndex: 8 },
  topHud: {
    position: "absolute",
    top: 8,
    left: 12,
    right: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  avatarWrap: { width: 58, height: 58, alignItems: "center", justifyContent: "center" },
  avatar: { width: 58, height: 58, position: "absolute" },
  avatarFace: { fontSize: 22 },
  levelWrap: { flex: 1, height: 44, justifyContent: "center" },
  progress: { width: "100%", height: 28, resizeMode: "contain" },
  starWrap: { position: "absolute", left: 0, top: -2, width: 36, height: 36, alignItems: "center", justifyContent: "center" },
  star: { width: 36, height: 36, position: "absolute" },
  starText: { color: "#5a2f0e", fontWeight: "900", fontSize: 12 },
  levelLabel: { position: "absolute", right: 8, color: "#5a2f0e", fontSize: 11, fontWeight: "800" },
  coinWrap: { width: 120, height: 40, alignItems: "center", justifyContent: "center" },
  coinBar: { width: 120, height: 36, position: "absolute", resizeMode: "contain" },
  coinText: { color: "#5a2f0e", fontWeight: "900", fontSize: 14, marginLeft: 12 },
  guardCard: { position: "absolute", top: 66, left: 12, width: 168, height: 56 },
  guardCardImg: { width: 168, height: 56, position: "absolute", resizeMode: "contain" },
  guardCopy: { flex: 1, paddingLeft: 14, paddingTop: 10 },
  guardTitle: { color: "#3d2a12", fontSize: 12, fontWeight: "900" },
  guardMeta: { color: "#6a4a22", fontSize: 11, fontWeight: "700" },
  utilityRail: { position: "absolute", top: 70, right: 8, gap: 8, alignItems: "center" },
  utilPill: { width: 64, height: 64, alignItems: "center", justifyContent: "center" },
  utilBubble: { width: 64, height: 64, position: "absolute" },
  utilIcon: { width: 28, height: 28, marginTop: -6 },
  utilLabel: { marginTop: 2, color: "#3d2a12", fontSize: 10, fontWeight: "800" },
  utilBadge: {
    position: "absolute",
    top: 4,
    right: 6,
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: "#e85a3a",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 3,
  },
  utilBadgeText: { color: "#fff", fontSize: 10, fontWeight: "900" },
  dog: { position: "absolute", right: 18, bottom: 118, width: 92, height: 120, resizeMode: "contain" },
  dock: { position: "absolute", left: 8, right: 8, bottom: 8, height: 92, justifyContent: "center" },
  dockBg: { position: "absolute", left: 0, right: 0, height: 92, width: "100%", resizeMode: "stretch" },
  dockActions: { flexDirection: "row", alignItems: "center", justifyContent: "space-around", paddingHorizontal: 10 },
  dockBtn: { alignItems: "center", justifyContent: "center", minWidth: 56, paddingVertical: 6 },
  dockHero: {
    backgroundColor: "rgba(255, 210, 120, 0.55)",
    borderRadius: 16,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: "rgba(160, 96, 24, 0.35)",
  },
  dockPressed: { opacity: 0.88, transform: [{ scale: 0.96 }] },
  dockDisabled: { opacity: 0.45 },
  dockIcon: { width: 34, height: 34 },
  dockLabel: { marginTop: 2, color: "#3d2a12", fontSize: 11, fontWeight: "800" },
  dockHeroLabel: { color: "#5a2f0e", fontWeight: "900" },
});
