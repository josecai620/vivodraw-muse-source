/**
 * 盲盒模块布局 - 复用揭晓主题系统（方向 C：白底白浮卡 + teal 轻立体）
 */
import React from "react";
import { Stack } from "expo-router";
import { RevealColorSchemeProvider } from "@/contexts/RevealColorSchemeContext";

export default function BoxLayout() {
  return (
    <RevealColorSchemeProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="[id]" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="[id]/opening" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="backpack" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="history" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="recycle" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="collection" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="orders" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="order-detail" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="shipping" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="brands" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="brand/[id]" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="draws" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="checkin" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="leaderboard" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="exchange" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="synthesis" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="wishlist" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="pity" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="probability" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="activity" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="replay" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="friends" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="newbie" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="free-draw" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="invite" options={{ animation: "slide_from_right" }} />
      </Stack>
    </RevealColorSchemeProvider>
  );
}
