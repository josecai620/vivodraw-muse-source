import React from "react";
import { View, Text, type ViewStyle } from "react-native";
import { getRarityTier, BoxTypography, type RarityTier } from "@/lib/boxTheme";

interface RarityBadgeProps {
  tier?: string;
  size?: "sm" | "md" | "lg";
  style?: ViewStyle;
}

const SIZES = {
  sm: { height: 18, px: 6, fontSize: 9 },
  md: { height: 22, px: 8, fontSize: 10 },
  lg: { height: 28, px: 12, fontSize: 12 },
};

export function RarityBadge({ tier, size = "md", style }: RarityBadgeProps) {
  const config = getRarityTier(tier);
  const s = SIZES[size];

  return (
    <View
      style={[{
        height: s.height,
        paddingHorizontal: s.px,
        borderRadius: 6,
        backgroundColor: config.bgSubtle,
        borderWidth: 1,
        borderColor: config.borderColor,
        justifyContent: "center",
        alignItems: "center",
        alignSelf: "flex-start",
      }, style]}
    >
      <Text style={{ fontSize: s.fontSize, fontWeight: "700", color: config.color }}>
        {config.label}
      </Text>
    </View>
  );
}

interface RarityBarProps {
  items?: { tier: string; probability?: number }[];
  height?: number;
  style?: ViewStyle;
}

export function RarityBar({ items, height = 6, style }: RarityBarProps) {
  const defaults = [
    { tier: "common", probability: 45 },
    { tier: "uncommon", probability: 30 },
    { tier: "rare", probability: 15 },
    { tier: "epic", probability: 7 },
    { tier: "legendary", probability: 2.5 },
    { tier: "secret", probability: 0.5 },
  ];
  const data = items?.length ? items : defaults;

  return (
    <View style={[{ flexDirection: "row", height, borderRadius: height, overflow: "hidden" }, style]}>
      {data.map((item, i) => {
        const config = getRarityTier(item.tier);
        return (
          <View
            key={i}
            style={{
              flex: item.probability ?? 1,
              backgroundColor: config.color,
            }}
          />
        );
      })}
    </View>
  );
}
