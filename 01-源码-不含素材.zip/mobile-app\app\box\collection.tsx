import React from "react";
import { useTranslation } from "react-i18next";
import { ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Gift, Lock, Package } from "lucide-react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { BoxHeader, RarityBadge, BoxEmptyState, BoxProgressBar } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  getRarityTier, bs, type RarityTier,
} from "@/lib/boxTheme";
import { USE_DEV_MOCK_DATA } from "@/constants/env";

interface CollectionItem {
  id: number;
  name: string;
  image: string;
  rarity: RarityTier;
  unlocked: boolean;
}

interface Series {
  id: number;
  name: string;
  boxImage: string;
  total: number;
  collected: number;
  items: CollectionItem[];
  reward?: { name: string; image: string };
}

const MOCK_SERIES: Series[] = [
  {
    id: 1,
    name: "Digital Gadgets Box",
    boxImage: "",
    total: 8,
    collected: 5,
    items: [
      { id: 1, name: "AirPods Pro", image: "", rarity: "epic", unlocked: true },
      { id: 2, name: "iPhone 15", image: "", rarity: "legendary", unlocked: true },
      { id: 3, name: "Power Bank", image: "", rarity: "common", unlocked: true },
      { id: 4, name: "Bluetooth Earbuds", image: "", rarity: "uncommon", unlocked: true },
      { id: 5, name: "Limited Figure", image: "", rarity: "secret", unlocked: true },
      { id: 6, name: "???", image: "", rarity: "common", unlocked: false },
      { id: 7, name: "???", image: "", rarity: "common", unlocked: false },
      { id: 8, name: "???", image: "", rarity: "common", unlocked: false },
    ],
    reward: { name: "100 Points", image: "" },
  },
  {
    id: 2,
    name: "Beauty Surprise Box",
    boxImage: "",
    total: 6,
    collected: 2,
    items: [
      { id: 1, name: "Dior Lipstick", image: "", rarity: "rare", unlocked: true },
      { id: 2, name: "Perfume", image: "", rarity: "uncommon", unlocked: true },
      { id: 3, name: "???", image: "", rarity: "common", unlocked: false },
      { id: 4, name: "???", image: "", rarity: "common", unlocked: false },
      { id: 5, name: "???", image: "", rarity: "common", unlocked: false },
      { id: 6, name: "???", image: "", rarity: "common", unlocked: false },
    ],
    reward: { name: "50 Points", image: "" },
  },
];

export default function CollectionScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const seriesList = USE_DEV_MOCK_DATA ? MOCK_SERIES : [];

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("collection.title")} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{
          paddingHorizontal: BoxSpacing.lg,
          paddingTop: BoxSpacing["2xl"],
          paddingBottom: bs(96),
        }}>
          {seriesList.length === 0 ? (
            <BoxEmptyState
              icon={<Gift size={bs(36)} color={BoxText.disabled} />}
              title={t("collection.empty", { defaultValue: "No Collection Yet" })}
              description={t("collection.emptyHint", { defaultValue: "Open boxes to build your collection." })}
              actionLabel={t("collection.openBoxes")}
              onAction={() => router.push("/(tabs)/box" as any)}
            />
          ) : seriesList.map((series) => {
            const progress = series.total > 0 ? (series.collected / series.total) * 100 : 0;
            const isComplete = series.collected >= series.total;
            return (
              <View
                key={series.id}
                style={{
                  borderRadius: BoxRadius.xl,
                  marginBottom: BoxSpacing["2xl"],
                  overflow: "hidden",
                  backgroundColor: BoxSurfaces.card,
                  borderWidth: 1,
                  borderColor: BoxBorders.default,
                  ...BoxShadows.card,
                }}
              >
                {/* Series Header */}
                <View style={{
                  padding: BoxSpacing.lg,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.md }}>
                    <View style={{
                      width: bs(56), height: bs(56), borderRadius: BoxRadius.lg,
                      alignItems: "center", justifyContent: "center",
                      backgroundColor: BoxSurfaces.deep,
                    }}>
                      <Package size={bs(26)} color={BoxAccent.gold} strokeWidth={1.5} />
                    </View>
                    <View>
                      <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>
                        {series.name}
                      </Text>
                      <Text style={[BoxTypography.caption, { color: BoxText.secondary }]}>
                        {t("collection.collected", { current: series.collected, total: series.total })}
                      </Text>
                    </View>
                  </View>
                  {series.reward && (
                    <View style={{
                      paddingHorizontal: BoxSpacing.md,
                      paddingVertical: BoxSpacing.sm,
                      borderRadius: BoxRadius.full,
                      flexDirection: "row",
                      alignItems: "center",
                      gap: BoxSpacing.xs,
                      backgroundColor: isComplete ? BoxAccent.goldMuted : BoxSurfaces.deep,
                    }}>
                      <Gift size={bs(14)} color={isComplete ? BoxAccent.gold : BoxText.secondary} />
                      <Text style={[BoxTypography.caption, {
                        color: isComplete ? BoxAccent.gold : BoxText.secondary,
                      }]}>
                        {series.reward.name}
                      </Text>
                    </View>
                  )}
                </View>

                {/* Progress Bar */}
                <View style={{ paddingHorizontal: BoxSpacing.lg, paddingBottom: BoxSpacing.lg }}>
                  <BoxProgressBar
                    progress={progress}
                    color={isComplete ? BoxAccent.gold : BoxAccent.purple}
                    glow={isComplete}
                  />
                </View>

                {/* Item Grid */}
                <View style={{
                  flexDirection: "row",
                  flexWrap: "wrap",
                  padding: BoxSpacing.lg,
                  paddingTop: 0,
                  gap: BoxSpacing.md,
                }}>
                  {series.items.map((item) => {
                    const rc = getRarityTier(item.rarity);
                    return (
                      <View
                        key={item.id}
                        style={{
                          width: "22%",
                          aspectRatio: 1,
                          borderRadius: BoxRadius.lg,
                          overflow: "hidden",
                          backgroundColor: item.unlocked ? BoxSurfaces.deep : BoxSurfaces.elevated,
                          borderWidth: 1,
                          borderColor: item.unlocked ? rc.borderColor : BoxBorders.subtle,
                          ...(item.unlocked ? BoxShadows.subtle : {}),
                        }}
                      >
                        <View style={{
                          flex: 1,
                          alignItems: "center",
                          justifyContent: "center",
                          padding: BoxSpacing.xs,
                        }}>
                          {item.unlocked ? (
                            <>
                              <Package size={bs(20)} color={BoxAccent.gold} strokeWidth={1.6} style={{ marginBottom: 2 }} />
                              <Text
                                numberOfLines={2}
                                style={[BoxTypography.micro, { color: BoxText.primary, textAlign: "center" }]}
                              >
                                {item.name}
                              </Text>
                              <RarityBadge tier={item.rarity} size="sm" style={{ marginTop: 2 }} />
                            </>
                          ) : (
                            <>
                              <Lock size={bs(20)} color={BoxText.disabled} />
                              <Text style={[BoxTypography.micro, { color: BoxText.disabled, marginTop: BoxSpacing.xs }]}>
                                {t("collection.locked")}
                              </Text>
                            </>
                          )}
                        </View>
                      </View>
                    );
                  })}
                </View>

                {/* Completion Reward CTA */}
                {isComplete && series.reward && (
                  <View style={{ marginHorizontal: BoxSpacing.lg, marginBottom: BoxSpacing.lg }}>
                    <LinearGradient
                      colors={BoxGradients.goldWarm}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 0 }}
                      style={{
                        padding: BoxSpacing.lg,
                        borderRadius: BoxRadius.lg,
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: BoxSpacing.sm,
                      }}
                    >
                      <Gift size={bs(20)} color={BoxAccent.gold} />
                      <Text style={[BoxTypography.bodyBold, { color: BoxAccent.gold }]}>
                        {t("collection.claimReward", { reward: series.reward.name })}
                      </Text>
                    </LinearGradient>
                  </View>
                )}
              </View>
            );
          })}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
