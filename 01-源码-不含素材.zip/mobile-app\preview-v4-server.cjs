// Local simulator for the production /v4/ subpath deployment.
// Serves dist-v4 ONLY under http://127.0.0.1:8091/v4/ to mirror the planned
// nginx `location ^~ /v4/ { alias .../frontend-v4-preview/current/; }` setup,
// including client-route deep links and SPA fallback.
//
// 本地预览取数：web 端 API_BASE_URL 恒为当前 origin（见 constants/env.ts），
// 线上由 nginx 同源反代，本地静态服没有后端，因此这里把 /v4 之外的请求
// （/api 数据、/static、/uploads 商品图等）反向代理到 https://vivodraw.com，
// 仅用于本机预览，不参与构建产物、不影响线上。
const http = require("http");
const https = require("https");
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "dist-v4");
const BASE = "/v4";
const PORT = 8091;
const UPSTREAM_HOST = "vivodraw.com";
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webm": "video/webm",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".ttf": "font/ttf",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ico": "image/x-icon",
};

// 逐跳头不应向上游转发
const HOP_BY_HOP = new Set([
  "connection",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailer",
  "transfer-encoding",
  "upgrade",
  "host",
  "origin",
  "referer",
  "content-length",
]);

function proxyRequest(req, res) {
  const forwardHeaders = { ...req.headers };
  for (const key of Object.keys(forwardHeaders)) {
    if (HOP_BY_HOP.has(key.toLowerCase())) delete forwardHeaders[key];
  }
  forwardHeaders.host = UPSTREAM_HOST;
  forwardHeaders.origin = `https://${UPSTREAM_HOST}`;
  forwardHeaders.referer = `https://${UPSTREAM_HOST}/`;
  forwardHeaders["x-client"] = "mobile-app";

  const upstreamReq = https.request(
    {
      host: UPSTREAM_HOST,
      port: 443,
      path: req.url,
      method: req.method,
      headers: forwardHeaders,
    },
    (upstreamRes) => {
      res.writeHead(upstreamRes.statusCode || 502, upstreamRes.headers);
      upstreamRes.pipe(res);
    },
  );

  upstreamReq.on("error", (err) => {
    res.writeHead(502, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("preview proxy error: " + err.message);
  });

  req.pipe(upstreamReq);
}

function tryFile(p) {
  try {
    const st = fs.statSync(p);
    if (st.isFile()) return p;
    const idx = path.join(p, "index.html");
    if (fs.statSync(idx).isFile()) return idx;
  } catch {}
  return null;
}

const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent(req.url.split("?")[0]);

  // /v4 -> /v4/
  if (urlPath === BASE) {
    res.writeHead(301, { Location: BASE + "/" });
    return res.end();
  }

  // Only the /v4/ namespace belongs to this preview (mirrors nginx prefix match).
  // 其它一切路径（/api、/static、/uploads…）反代到线上，供本地预览取真实数据/图片。
  if (!urlPath.startsWith(BASE + "/")) {
    return proxyRequest(req, res);
  }

  // Strip the /v4 prefix -> path inside dist-v4.
  let rel = urlPath.slice(BASE.length + 1);
  let target = path.join(ROOT, rel);
  let found = tryFile(target);
  if (!found && !path.extname(rel)) {
    found = tryFile(target + ".html");
  }
  // SPA fallback for client routes.
  if (!found) found = tryFile(path.join(ROOT, "index.html"));

  if (!found) {
    res.writeHead(404);
    return res.end("not found");
  }
  const ext = path.extname(found).toLowerCase();
  res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
  fs.createReadStream(found).pipe(res);
});

server.listen(PORT, "127.0.0.1", () =>
  console.log("v4 subpath preview on http://127.0.0.1:" + PORT + "/v4/ (api proxy -> https://vivodraw.com)")
);
