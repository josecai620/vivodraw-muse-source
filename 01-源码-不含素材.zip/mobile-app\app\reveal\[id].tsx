import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { ChevronRight } from "lucide-react-native";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import CloudBuyImageSlider from "@/components/points/CloudBuyImageSlider";
import { ProductImageRevealStamp, WinnerAvatar } from "@/components/reveal/WinnerBadges";
import { useRevealDetail } from "@/hooks/usePoints";
import { normalizeImageUrl } from "@/lib/utils";

const TEAL = Colors.primary.DEFAULT;

function pad2(n: number) {
  return String(Math.max(0, Math.floor(n))).padStart(2, "0");
}

function splitRemain(ms: number) {
  const safe = Math.max(0, ms);
  const minute = Math.floor(safe / 60000);
  const second = Math.floor((safe % 60000) / 1000);
  const milli = Math.floor((safe % 1000) / 10);
  return { minute, second, milli };
}

export default function RevealDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const kaijiangId = Number(id) || 0;
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { t } = useTranslation();
  const { data: detailData, isLoading, error, refetch } = useRevealDetail(kaijiangId);
  const [now, setNow] = useState(() => Date.now());

  const raw = (detailData as any)?.data ?? {};
  const detail = raw?.detail ?? {};
  const productData = raw?.product ?? {};
  const kaijiang = raw?.kaijiang ?? {};
  const periods: Array<{ id: number; bianhao: number; kind: string; productId: number }> = Array.isArray(raw?.periods)
    ? raw.periods
    : [];
  const prevWinner = raw?.prev_winner ?? null;
  const slider = Array.isArray(raw?.slider_image) ? raw.slider_image : [];
  const images = (slider.length ? slider : [productData.image ?? detail.image])
    .map((u: unknown) => normalizeImageUrl(String(u ?? "")))
    .filter(Boolean);
  const name = String(productData.store_name ?? detail.store_name ?? "");
  const period = String(detail.bianhao ?? productData.bianhao ?? "");
  const productId = Number(productData.id ?? detail.product_id ?? 0);
  const nextPeriod = Number(raw?.next_period ?? productData.bianhao ?? 0);
  const value = Number(productData.reference_price ?? productData.ot_price ?? detail.price ?? 0);
  const luckyCode = String(detail.lucky_code ?? detail.zj_unique ?? detail.unique ?? "");
  const winner = String(kaijiang.nickname ?? detail.nickname ?? "");
  const avatar = normalizeImageUrl(String(kaijiang.avatar ?? detail.avatar ?? ""));
  const shares = Number(detail.huanqu_num ?? 0);
  const revealAt = String(detail.zhongjiang_time ?? "");
  const buyTime = String(detail.buy_time ?? "");
  const endAt = Number(detail.kaijiang_time ?? 0) * 1000;
  const liveRemain = endAt > 0 ? Math.max(0, endAt - now) : Math.max(0, Number(detail.djs ?? 0));
  const hiding = liveRemain > 0;
  const liveClock = splitRemain(liveRemain);

  useEffect(() => {
    if (!hiding) return;
    const tmr = setInterval(() => setNow(Date.now()), 41);
    return () => clearInterval(tmr);
  }, [hiding]);

  useEffect(() => {
    if (hiding) return;
    if (!detail.kaijiang_time) return;
    if (!luckyCode) refetch();
  }, [hiding, detail.kaijiang_time, luckyCode, refetch]);

  const title = hiding ? t("pointsMall.revealingNow") : t("pointsMall.tabReveal");

  const periodChips = useMemo(() => periods.slice(0, 12), [periods]);

  if (isLoading && !raw?.detail && !raw?.product) {
    return (
      <View className="flex-1 items-center justify-center" style={{ backgroundColor: Colors.screen.bg }}>
        <ActivityIndicator color={TEAL} />
      </View>
    );
  }

  if ((error && !raw?.detail) || kaijiangId <= 0) {
    return (
      <View className="flex-1 items-center justify-center p-6" style={{ backgroundColor: Colors.screen.bg }}>
        <Text className="text-center text-gray-500 mb-3">
          {(error as Error)?.message || t("pointsMall.productMissing")}
        </Text>
        <Pressable onPress={() => router.back()} className="px-5 py-2 rounded-full" style={{ backgroundColor: TEAL }}>
          <Text className="text-white font-bold">{t("common.back")}</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={title} />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 8 }}
      >
        {periodChips.length > 0 ? (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} className="bg-white" contentContainerStyle={{ paddingHorizontal: 8, paddingVertical: 10 }}>
            {periodChips.map((p) => {
              const current = p.kind === "current";
              const ongoing = p.kind === "ongoing";
              return (
                <Pressable
                  key={`${p.kind}-${p.bianhao}-${p.id}`}
                  className="px-3 py-1.5 mr-2 rounded-full"
                  style={{ backgroundColor: current ? TEAL : "#F3F4F6" }}
                  onPress={() => {
                    if (ongoing && p.productId) {
                      router.push({ pathname: "/points/product", params: { id: String(p.productId) } } as never);
                    } else if (p.id > 0 && p.id !== kaijiangId) {
                      router.push(`/reveal/${p.id}` as never);
                    }
                  }}
                >
                  <Text className="text-xs font-bold" style={{ color: current ? "#fff" : "#374151" }}>
                    {t("pointsMall.periodN", { n: p.bianhao })}
                    {ongoing ? " · " + t("pointsMall.ongoingNow") : ""}
                  </Text>
                </Pressable>
              );
            })}
          </ScrollView>
        ) : null}

        {hiding ? (
          <View className="bg-white mt-2 mx-3 rounded-xl px-3 py-4">
            <View className="flex-row items-center justify-center">
              <Text className="text-xs text-gray-500 mr-3 text-center" style={{ width: 48 }}>
                {t("pointsMall.revealCountdown")}
              </Text>
              <View className="items-center mx-2">
                <View className="w-16 h-16 rounded-lg items-center justify-center" style={{ backgroundColor: TEAL }}>
                  <Text className="text-white text-2xl font-black">{pad2(liveClock.minute)}</Text>
                </View>
                <Text className="text-[10px] text-gray-500 mt-1">{t("pointsMall.minuteUnit")}</Text>
              </View>
              <View className="items-center mx-2">
                <View className="w-16 h-16 rounded-lg items-center justify-center" style={{ backgroundColor: TEAL }}>
                  <Text className="text-white text-2xl font-black">{pad2(liveClock.second)}</Text>
                </View>
                <Text className="text-[10px] text-gray-500 mt-1">{t("pointsMall.secondUnit")}</Text>
              </View>
              <View className="items-center mx-2">
                <View className="w-16 h-16 rounded-lg items-center justify-center" style={{ backgroundColor: TEAL }}>
                  <Text className="text-white text-2xl font-black">{pad2(liveClock.milli)}</Text>
                </View>
                <Text className="text-[10px] text-gray-500 mt-1">{t("pointsMall.milliUnit")}</Text>
              </View>
            </View>
          </View>
        ) : (
          <View className="bg-white mt-2 mx-3 rounded-xl p-4" style={{ overflow: "visible", position: "relative" }}>
            <View className="flex-row items-center">
              <View style={{ marginRight: 12 }}>
                <WinnerAvatar
                  uri={avatar || undefined}
                  uid={Number(kaijiang.uid ?? detail.uid ?? 0) || undefined}
                  seed={winner || period}
                  size={80}
                  variant="winner"
                  rounded="square"
                />
              </View>
              <View className="flex-1">
                <Text className="text-base font-bold" style={{ color: TEAL }}>
                  {winner || t("pointsMall.anonymous")}
                </Text>
                <Text className="text-xs text-gray-500 mt-1">
                  {t("pointsMall.prevTotalShares")}：{shares || "-"}
                  {t("pointsMall.shareUnit")}
                </Text>
                <Text className="text-xs text-gray-500">
                  {t("pointsMall.revealTime")}：{revealAt || "-"}
                </Text>
                <Text className="text-xs text-gray-500">
                  {t("pointsMall.joinTime")}：{buyTime || "-"}
                </Text>
              </View>
            </View>
            <View className="flex-row items-center justify-between mt-3">
              <Text className="text-sm">
                {t("pointsMall.luckyCode")}：
                <Text className="font-black" style={{ color: Colors.primary.dark }}>
                  {luckyCode || "-"}
                </Text>
              </Text>
              <Pressable
                onPress={() =>
                  router.push({
                    pathname: "/reveal/algorithm",
                    params: { id: String(kaijiangId), productId: String(productId), bianhao: period },
                  } as never)
                }
              >
                <Text className="text-xs font-bold" style={{ color: TEAL }}>
                  {t("pointsMall.viewCalc")}
                </Text>
              </Pressable>
            </View>
          </View>
        )}

        <View style={{ position: "relative" }}>
          <CloudBuyImageSlider images={images} height={240} />
          {!hiding ? <ProductImageRevealStamp imageHeight={240} /> : null}
        </View>

        <View className="bg-white px-3 py-3">
          <Text className="text-base font-bold text-gray-900">
            {period ? `(${t("pointsMall.periodN", { n: period })})` : ""}
            {name}
          </Text>
          <Text className="text-sm text-gray-500 mt-1">
            {t("pointsMall.valueLabel")}：{value > 0 ? value : "-"}
          </Text>
          <View className="mt-3 h-10 rounded items-center justify-center" style={{ backgroundColor: hiding ? "#9CA3AF" : TEAL }}>
            <Text className="text-white font-bold">{hiding ? t("pointsMall.revealingNow") : t("pointsMall.periodRevealed")}</Text>
          </View>
          {productId > 0 && nextPeriod > 0 ? (
            <Pressable
              className="mt-2 h-10 px-3 flex-row items-center rounded"
              style={{ backgroundColor: "#111827" }}
              onPress={() => router.push({ pathname: "/points/product", params: { id: String(productId) } } as never)}
            >
              <Text className="flex-1 text-white text-sm">
                {t("pointsMall.periodN", { n: nextPeriod })} {t("pointsMall.ongoingNow")}
              </Text>
              <Text className="text-white text-sm font-bold">{t("pointsMall.viewDetail")}</Text>
            </Pressable>
          ) : null}
        </View>

        <Pressable
          className="bg-white mx-3 mt-2 h-10 px-3 flex-row items-center rounded-lg"
          onPress={() =>
            router.push({
              pathname: "/points/buy-records",
              params: { id: String(productId), bianhao: period },
            } as never)
          }
        >
          <Text className="flex-1 text-sm text-gray-700">{t("pointsMall.allJoinRecords")}</Text>
          <ChevronRight size={14} color="#9CA3AF" />
        </Pressable>
        <Pressable
          className="bg-white mx-3 mt-2 h-10 px-3 flex-row items-center rounded-lg"
          onPress={() => router.push({ pathname: "/points/goods-desc", params: { id: String(productId) } } as never)}
        >
          <Text className="flex-1 text-sm text-gray-700">{t("pointsMall.richDetailHint")}</Text>
          <ChevronRight size={14} color="#9CA3AF" />
        </Pressable>

        {prevWinner?.id ? (
          <Pressable
            className="bg-white mx-3 mt-2 mb-3 p-3 rounded-lg flex-row"
            style={{ overflow: "visible" }}
            onPress={() => router.push(`/reveal/${prevWinner.id}` as never)}
          >
            <WinnerAvatar
              uri={prevWinner.avatar ? normalizeImageUrl(String(prevWinner.avatar)) : undefined}
              uid={Number(prevWinner.uid ?? 0) || undefined}
              seed={String(prevWinner.nickname ?? prevWinner.id ?? "")}
              size={56}
              variant="prev"
              rounded="square"
            />
            <View className="ml-3 flex-1">
              <Text className="text-sm font-bold" style={{ color: TEAL }}>
                {prevWinner.nickname || t("pointsMall.anonymous")}
              </Text>
              <Text className="text-xs text-gray-500">
                {t("pointsMall.prevTotalShares")}：{prevWinner.shares || "-"}
                {t("pointsMall.shareUnit")}
              </Text>
              <Text className="text-xs text-gray-500">
                {t("pointsMall.luckyCode")}：{prevWinner.luckyCode || "-"}
              </Text>
              <Text className="text-xs text-gray-500">
                {t("pointsMall.revealTime")}：{prevWinner.revealAt || "-"}
              </Text>
            </View>
            <ChevronRight size={14} color="#9CA3AF" />
          </Pressable>
        ) : (
          <View className="h-3" />
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
