import React, { memo } from "react";
import { Image, StyleSheet, View, type StyleProp, type ViewStyle } from "react-native";

export type PearlShellState = "closed" | "open";
type Bounds = { x: number; y: number; width: number; height: number };

type Atlas = {
  source: number;
  width: number;
  height: number;
  bounds: readonly Bounds[];
};

// 每格边界将在两张实际图集交付后替换成透明通道测得的主体范围。
const GRID_BOUNDS: readonly Bounds[] = Array.from({ length: 6 }, (_, index) => ({
  x: (index % 3) * 512,
  y: Math.floor(index / 3) * 512,
  width: 512,
  height: 512,
}));

const ATLASES: Record<PearlShellState, Atlas> = {
  closed: {
    source: require("../../assets/海底寻珠/六款珍珠蚌-闭合图集.png"),
    width: 1536,
    height: 1024,
    bounds: GRID_BOUNDS,
  },
  open: {
    source: require("../../assets/海底寻珠/六款珍珠蚌-打开图集.png"),
    width: 1536,
    height: 1024,
    bounds: GRID_BOUNDS,
  },
};

// 打开图中六款壳的铰链高度各不相同，保留各自造型的开合位置。
const OPEN_HINGE_Y = [320, 312, 325, 793, 781, 800] as const;

function normalizeVariant(variant: number) {
  return Number.isFinite(variant) ? Math.max(0, Math.min(5, Math.trunc(variant))) : 0;
}

function getBounds(variant: number, state: PearlShellState) {
  return ATLASES[state].bounds[normalizeVariant(variant)];
}

/** 按每款自身宽高比缩放，使不同轮廓保持形状并共用落地基线。 */
export function getPearlShellSize(variant: number, state: PearlShellState, maxWidth: number, maxHeight: number) {
  const bounds = getBounds(variant, state);
  const scale = Math.min(maxWidth / bounds.width, maxHeight / bounds.height);
  return { width: bounds.width * scale, height: bounds.height * scale };
}

export function getPearlShellHinge(variant: number) {
  const bounds = getBounds(variant, "open");
  return (OPEN_HINGE_Y[normalizeVariant(variant)] - bounds.y) / bounds.height;
}

export type PearlShellSpriteProps = {
  variant: number;
  state: PearlShellState;
  width: number;
  height: number;
  style?: StyleProp<ViewStyle>;
};

/** 只裁切同序号的美术素材，不接受珍珠结果或奖励参数。 */
export const PearlShellSprite = memo(function PearlShellSprite({
  variant,
  state,
  width,
  height,
  style,
}: PearlShellSpriteProps) {
  const atlas = ATLASES[state];
  const bounds = getBounds(variant, state);
  const scale = Math.min(width / bounds.width, height / bounds.height);
  const drawnWidth = bounds.width * scale;
  const drawnHeight = bounds.height * scale;

  return (
    <View
      pointerEvents="none"
      accessible={false}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
      style={[styles.frame, { width, height }, style]}
    >
      <View style={[styles.crop, {
        left: (width - drawnWidth) / 2,
        bottom: 0,
        width: drawnWidth,
        height: drawnHeight,
      }]}>
        <Image
          source={atlas.source}
          accessible={false}
          resizeMode="stretch"
          fadeDuration={0}
          style={{
            position: "absolute",
            left: -bounds.x * scale,
            top: -bounds.y * scale,
            width: atlas.width * scale,
            height: atlas.height * scale,
          }}
        />
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  frame: { overflow: "hidden" },
  crop: { position: "absolute", overflow: "hidden" },
});
