import React from "react";
import { View, Text, ScrollView, Pressable } from "react-native";
import { Check, Globe } from "lucide-react-native";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";
import { useLanguage } from "@/hooks/useLanguage";
import { useAppStore } from "@/store/app";

export default function LanguageScreen() {
  const { t } = useTranslation();
  const { currentLanguage, languages, setLanguage } = useLanguage();
  const showToast = useAppStore((s) => s.showToast);

  const handleSelect = async (code: string) => {
    if (code === currentLanguage) return;
    await setLanguage(code as any);
    showToast(t("settings.languageChanged"), "success");
  };

  return (
    <View className="flex-1 bg-neutral-50">
      <PageHeader title={t("settings.selectLanguage")} />

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="mt-6 mx-4 bg-white rounded-2xl overflow-hidden">
          {languages.map((lang, i) => {
            const isActive = currentLanguage === lang.code;
            return (
              <Pressable
                key={lang.code}
                className={`flex-row items-center px-5 py-4 ${i < languages.length - 1 ? "border-b border-neutral-100" : ""} active:bg-neutral-50`}
                onPress={() => handleSelect(lang.code)}
              >
                <Globe size={20} color={isActive ? Colors.brand.red : Colors.neutral[400]} />
                <View className="flex-1 ml-4">
                  <Text
                    className={`text-base ${isActive ? "font-semibold" : ""}`}
                    style={{ color: isActive ? Colors.brand.red : Colors.neutral[700] }}
                  >
                    {lang.nativeLabel}
                  </Text>
                  <Text className="text-sm text-neutral-400">{lang.label}</Text>
                </View>
                {isActive && <Check size={20} color={Colors.brand.red} />}
              </Pressable>
            );
          })}
        </View>

        <Text className="text-center text-xs text-neutral-400 mt-4 px-6">
          {t("settings.currentLanguage")}: {languages.find((l) => l.code === currentLanguage)?.label}
        </Text>
      </ScrollView>
    </View>
  );
}
