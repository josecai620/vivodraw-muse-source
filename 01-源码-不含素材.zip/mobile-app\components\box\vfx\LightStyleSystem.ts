import { Container, Graphics } from 'pixi.js';
import type { OreVFXConfig, VFXRhythm } from './OreVFX';

export type LightStyleId =
  | 'spiralGold'
  | 'iceWaterfall'
  | 'violetRift'
  | 'infernoSurge'
  | 'runeHalo'
  | 'starOrbit'
  | 'auroraVeil'
  | 'prismShower';

interface StyleNode {
  node: Graphics; // node：单个图形节点
  seed: number; // seed：随机种子
  index: number; // index：节点序号
}

interface MovingShard {
  node: Graphics; // node：移动光片节点
  x: number; // x：基础 X 坐标
  y: number; // y：基础 Y 坐标
  speed: number; // speed：移动速度
  size: number; // size：光片尺寸
  seed: number; // seed：随机种子
}

export class LightStyleSystem { // LightStyleSystem：多风格动态光效系统
  private readonly backLayer: Container; // backLayer：主体后方风格光层
  private readonly frontLayer: Container; // frontLayer：主体前方风格光层
  private readonly centerX: number; // centerX：主体中心 X
  private readonly centerY: number; // centerY：主体中心 Y
  private style: LightStyleId = 'spiralGold'; // style：当前光效风格
  private readonly backNodes: StyleNode[] = []; // backNodes：后层绘制节点
  private readonly frontNodes: StyleNode[] = []; // frontNodes：前层绘制节点
  private readonly shards: MovingShard[] = []; // shards：光片节点

  constructor(backLayer: Container, frontLayer: Container, centerX: number, centerY: number) {
    this.backLayer = backLayer; // backLayer：保存后层
    this.frontLayer = frontLayer; // frontLayer：保存前层
    this.centerX = centerX; // centerX：保存中心 X
    this.centerY = centerY; // centerY：保存中心 Y
    this.createNodes();
  }

  setStyle(style: LightStyleId) {
    this.style = style; // style：切换光效风格
    this.clearAll();
  }

  update(time: number, config: OreVFXConfig, rhythm: VFXRhythm) {
    this.clearAll();
    if (this.style === 'spiralGold') this.drawSpiralGold(time, config, rhythm);
    if (this.style === 'iceWaterfall') this.drawIceWaterfall(time, config, rhythm);
    if (this.style === 'violetRift') this.drawVioletRift(time, config, rhythm);
    if (this.style === 'infernoSurge') this.drawInfernoSurge(time, config, rhythm);
    if (this.style === 'runeHalo') this.drawRuneHalo(time, config, rhythm);
    if (this.style === 'starOrbit') this.drawStarOrbit(time, config, rhythm);
    if (this.style === 'auroraVeil') this.drawAuroraVeil(time, config, rhythm);
    if (this.style === 'prismShower') this.drawPrismShower(time, config, rhythm);
  }

  private createNodes() {
    for (let index = 0; index < 34; index += 1) { // index：后层节点序号
      const node = new Graphics(); // node：后层光效节点
      node.blendMode = 'add';
      this.backNodes.push({ node, seed: index * 4.731 + 1.7, index });
      this.backLayer.addChild(node);
    }

    for (let index = 0; index < 46; index += 1) { // index：前层节点序号
      const node = new Graphics(); // node：前层光效节点
      node.blendMode = 'add';
      this.frontNodes.push({ node, seed: index * 6.137 + 2.9, index });
      this.frontLayer.addChild(node);
    }

    for (let index = 0; index < 38; index += 1) { // index：光片序号
      const node = new Graphics(); // node：光片节点
      node.blendMode = 'add';
      this.shards.push({
        node,
        x: this.centerX - 190 + Math.random() * 380,
        y: this.centerY - 210 + Math.random() * 420,
        speed: 0.42 + Math.random() * 1.08,
        size: 8 + Math.random() * 18,
        seed: Math.random() * 99,
      });
      this.frontLayer.addChild(node);
    }
  }

  private clearAll() {
    this.backNodes.forEach((item) => item.node.clear());
    this.frontNodes.forEach((item) => item.node.clear());
    this.shards.forEach((item) => item.node.clear());
  }

  private drawSpiralGold(time: number, config: OreVFXConfig, rhythm: VFXRhythm) {
    const power = this.power(config, rhythm); // power：当前强度
    this.backNodes.slice(0, 8).forEach((item) => {
      const phase = time * (0.7 + item.index * 0.035) + item.seed; // phase：旋转相位
      const startAngle = phase + item.index * 0.72; // startAngle：起始角度
      const color = item.index % 2 === 0 ? 0x33c6cc : 0x9fe4e6; // color：螺旋颜色
      this.drawSpiralRibbon(item.node, startAngle, 42 + item.index * 10, 178 - item.index * 5, color, (0.1 + rhythm.charge * 0.16 + rhythm.afterglow * 0.08) * power);
    });

    this.frontNodes.slice(0, 10).forEach((item) => {
      const angle = time * 1.15 + item.index * 0.62; // angle：前景光点角度
      const radius = 58 + item.index * 13 + Math.sin(time * 1.8 + item.seed) * 10; // radius：前景光点半径
      const x = this.centerX + Math.cos(angle) * radius; // x：光点 X
      const y = this.centerY + Math.sin(angle) * radius * 0.82; // y：光点 Y
      this.drawComet(item.node, x, y, angle + Math.PI * 0.65, 18 + item.index % 3 * 8, 0xcff3f4, (0.22 + rhythm.scatter * 0.18) * power);
    });
  }

  private drawIceWaterfall(time: number, config: OreVFXConfig, rhythm: VFXRhythm) {
    const power = this.power(config, rhythm); // power：当前强度
    this.backNodes.slice(0, 12).forEach((item) => {
      const lane = (item.index - 5.5) * 28; // lane：瀑布光带横向位置
      const drift = Math.sin(time * 0.9 + item.seed) * 18; // drift：横向漂移
      const progress = (time * item.seed * 0.035 + item.index * 0.19) % 1; // progress：下落进度
      const top = this.centerY - 250 + progress * 125; // top：光带顶部
      const x = this.centerX + lane + drift; // x：光带 X
      item.node.moveTo(x, top);
      item.node.bezierCurveTo(x + 16, top + 72, x - 26, top + 144, x + 8, top + 232);
      item.node.stroke({ width: 4 + (item.index % 3) * 2, color: 0x9fe4e6, alpha: (0.08 + rhythm.charge * 0.08) * power });
      item.node.moveTo(x + 7, top + 38);
      item.node.bezierCurveTo(x + 17, top + 96, x - 13, top + 138, x + 1, top + 194);
      item.node.stroke({ width: 1.2, color: 0xeafbfb, alpha: (0.18 + rhythm.afterglow * 0.12) * power });
    });

    this.shards.slice(0, 22).forEach((item, index) => {
      const fall = (time * item.speed * 92 + item.seed * 19) % 430; // fall：下落距离
      const x = item.x + Math.sin(time * 1.4 + item.seed) * 16; // x：光片 X
      const y = this.centerY - 232 + fall; // y：光片 Y
      const angle = Math.PI * 0.5 + Math.sin(time + item.seed) * 0.18; // angle：下落角度
      this.drawComet(item.node, x, y, angle, item.size * 1.4, index % 3 === 0 ? 0xffffff : 0x7fd8dc, (0.12 + rhythm.scatter * 0.14) * power);
    });
  }

  private drawVioletRift(time: number, config: OreVFXConfig, rhythm: VFXRhythm) {
    const power = this.power(config, rhythm); // power：当前强度
    this.backNodes.slice(0, 9).forEach((item) => {
      const angle = -0.62 + item.index * 0.16 + Math.sin(time * 0.7 + item.seed) * 0.05; // angle：裂隙角度
      const length = 155 + Math.sin(time * 1.2 + item.seed) * 34; // length：裂隙长度
      const startX = this.centerX + Math.cos(angle) * 38; // startX：裂隙起点 X
      const startY = this.centerY + Math.sin(angle) * 26; // startY：裂隙起点 Y
      this.drawLightning(item.node, startX, startY, angle, length, 0x08aeb4, (0.12 + rhythm.burst * 0.24 + rhythm.charge * 0.08) * power, item.seed);
    });

    this.frontNodes.slice(0, 15).forEach((item) => {
      const angle = time * (item.index % 2 === 0 ? 0.2 : -0.17) + item.index * 0.61; // angle：碎裂漂浮角度
      const radius = 120 + Math.sin(time * 1.1 + item.seed) * 46; // radius：碎裂漂浮半径
      const x = this.centerX + Math.cos(angle) * radius; // x：碎裂光片 X
      const y = this.centerY + Math.sin(angle) * radius * 0.75; // y：碎裂光片 Y
      this.drawFeather(item.node, x, y, 14 + (item.index % 4) * 5, angle + Math.PI * 0.5, item.index % 2 === 0 ? 0xb2ecee : 0x9fe4e6, (0.14 + rhythm.scatter * 0.18) * power);
    });
  }

  private drawInfernoSurge(time: number, config: OreVFXConfig, rhythm: VFXRhythm) {
    const power = this.power(config, rhythm); // power：当前强度
    this.backNodes.slice(0, 14).forEach((item) => {
      const baseX = this.centerX - 150 + item.index * 23 + Math.sin(time + item.seed) * 9; // baseX：火舌底部 X
      const baseY = this.centerY + 182 + Math.sin(time * 1.4 + item.seed) * 7; // baseY：火舌底部 Y
      const height = 86 + (item.index % 4) * 22 + Math.sin(time * 2 + item.seed) * 16; // height：火舌高度
      const width = 24 + (item.index % 3) * 10; // width：火舌宽度
      this.drawFlameTongue(item.node, baseX, baseY, width, height, time * (1.1 + item.index * 0.03) + item.seed, (0.16 + rhythm.afterglow * 0.14) * power);
    });

    this.shards.slice(0, 28).forEach((item) => {
      const rise = (time * item.speed * 112 + item.seed * 31) % 360; // rise：上升距离
      const x = this.centerX - 145 + ((item.seed * 37) % 290) + Math.sin(time * 2.4 + item.seed) * 20; // x：火星 X
      const y = this.centerY + 190 - rise; // y：火星 Y
      this.drawComet(item.node, x, y, -Math.PI * 0.5 + Math.sin(time + item.seed) * 0.38, item.size * 1.15, 0x33c6cc, (0.14 + rhythm.scatter * 0.2) * power);
    });
  }

  private drawRuneHalo(time: number, config: OreVFXConfig, rhythm: VFXRhythm) {
    const power = this.power(config, rhythm); // power：当前强度
    const radius = 198 + Math.sin(time * 1.1) * 7 + rhythm.charge * 14; // radius：符文环半径
    this.backNodes.slice(0, 18).forEach((item) => {
      const angle = item.index / 18 * Math.PI * 2 + time * 0.24; // angle：符文角度
      const x = this.centerX + Math.cos(angle) * radius; // x：符文 X
      const y = this.centerY + Math.sin(angle) * radius * 0.86; // y：符文 Y
      this.drawRuneGlyph(item.node, x, y, 18 + (item.index % 3) * 4, angle + Math.PI * 0.5, item.index % 2 === 0 ? 0x33c6cc : 0x7fd8dc, (0.22 + rhythm.charge * 0.18 + rhythm.burst * 0.22) * power);
    });

    this.frontNodes.slice(0, 4).forEach((item) => {
      const spin = time * (item.index % 2 === 0 ? 0.34 : -0.28) + item.seed; // spin：环旋转
      this.drawBrokenEllipse(item.node, this.centerX, this.centerY, 178 + item.index * 18, 132 + item.index * 10, spin, item.index % 2 === 0 ? 0x33c6cc : 0x7fd8dc, (0.13 + rhythm.afterglow * 0.12) * power);
    });
  }

  private drawStarOrbit(time: number, config: OreVFXConfig, rhythm: VFXRhythm) {
    const power = this.power(config, rhythm); // power：当前强度
    this.backNodes.slice(0, 5).forEach((item) => {
      const spin = time * (0.24 + item.index * 0.06) + item.seed; // spin：轨道旋转
      this.drawOrbit(item.node, this.centerX, this.centerY, 116 + item.index * 22, 64 + item.index * 13, spin, item.index % 2 === 0 ? 0x33c6cc : 0x7fd8dc, (0.09 + rhythm.charge * 0.08) * power);
    });

    this.frontNodes.slice(0, 18).forEach((item) => {
      const angle = time * (0.9 + item.index * 0.025) + item.index * 1.37; // angle：星屑轨道角度
      const orbitX = 112 + (item.index % 4) * 28; // orbitX：轨道 X 半径
      const orbitY = 58 + (item.index % 5) * 15; // orbitY：轨道 Y 半径
      const tilt = item.index % 2 === 0 ? 0.36 : -0.48; // tilt：轨道倾斜
      const localX = Math.cos(angle) * orbitX; // localX：局部 X
      const localY = Math.sin(angle) * orbitY; // localY：局部 Y
      const x = this.centerX + localX * Math.cos(tilt) - localY * Math.sin(tilt); // x：星屑 X
      const y = this.centerY + localX * Math.sin(tilt) + localY * Math.cos(tilt); // y：星屑 Y
      this.drawStar(item.node, x, y, 5 + (item.index % 4) * 2, item.index % 3 === 0 ? 0xffffff : 0x9fe4e6, (0.18 + rhythm.scatter * 0.2) * power);
    });
  }

  private drawAuroraVeil(time: number, config: OreVFXConfig, rhythm: VFXRhythm) {
    const power = this.power(config, rhythm); // power：当前强度
    const colors = [0x7fd8dc, 0x33c6cc, 0x08aeb4, 0x9fe4e6]; // colors：极光颜色列表（teal 明度阶梯）
    this.backNodes.slice(0, 9).forEach((item) => {
      const baseY = this.centerY - 138 + item.index * 28; // baseY：丝带基础 Y
      const color = colors[item.index % colors.length]; // color：丝带颜色
      const offset = time * (0.72 + item.index * 0.04) + item.seed; // offset：流动偏移
      this.drawAuroraRibbon(item.node, baseY, offset, color, (0.08 + rhythm.afterglow * 0.08 + rhythm.charge * 0.05) * power, 30 + item.index * 3);
    });

    this.frontNodes.slice(0, 10).forEach((item) => {
      const angle = -0.42 + Math.sin(time * 0.8 + item.seed) * 0.24; // angle：前景丝光角度
      const x = this.centerX - 180 + item.index * 40 + Math.sin(time + item.seed) * 26; // x：前景丝光 X
      const y = this.centerY - 110 + Math.sin(time * 1.6 + item.seed) * 120; // y：前景丝光 Y
      this.drawComet(item.node, x, y, angle, 38 + (item.index % 3) * 14, colors[(item.index + 1) % colors.length], (0.09 + rhythm.scatter * 0.12) * power);
    });
  }

  private drawPrismShower(time: number, config: OreVFXConfig, rhythm: VFXRhythm) {
    const power = this.power(config, rhythm); // power：当前强度
    const colors = [0xcff3f4, 0x7fd8dc, 0x33c6cc, 0x9fe4e6]; // colors：棱镜光色（teal 明度阶梯）
    this.backNodes.slice(0, 10).forEach((item) => {
      const angle = -0.9 + item.index * 0.15 + Math.sin(time * 0.8 + item.seed) * 0.08; // angle：折射光角度
      const x = this.centerX - 160 + item.index * 36; // x：折射起点 X
      const y = this.centerY - 200 + Math.sin(time + item.seed) * 18; // y：折射起点 Y
      this.drawPrismBeam(item.node, x, y, angle, 290, colors[item.index % colors.length], (0.08 + rhythm.charge * 0.12 + rhythm.burst * 0.12) * power);
    });

    this.shards.forEach((item, index) => {
      const slide = (time * item.speed * 86 + item.seed * 23) % 520; // slide：斜向滑动距离
      const x = this.centerX - 250 + slide + Math.sin(time + item.seed) * 12; // x：光片 X
      const y = this.centerY - 210 + ((item.seed * 47) % 390) + slide * 0.18; // y：光片 Y
      this.drawFeather(item.node, x, y, item.size, -0.78, colors[index % colors.length], (0.12 + rhythm.scatter * 0.16) * power);
    });
  }

  private power(config: OreVFXConfig, rhythm: VFXRhythm) {
    return Math.max(0.05, config.glowIntensity) * (0.72 + rhythm.charge * 0.18 + rhythm.burst * 0.24 + rhythm.afterglow * 0.12); // power：整体光效强度
  }

  private drawSpiralRibbon(node: Graphics, startAngle: number, innerRadius: number, outerRadius: number, color: number, alpha: number) {
    const points = 22; // points：螺旋采样点数
    for (let point = 0; point < points; point += 1) { // point：当前采样点
      const t0 = point / points; // t0：起点进度
      const t1 = (point + 1) / points; // t1：终点进度
      const radius0 = innerRadius + (outerRadius - innerRadius) * t0; // radius0：起点半径
      const radius1 = innerRadius + (outerRadius - innerRadius) * t1; // radius1：终点半径
      const angle0 = startAngle + t0 * Math.PI * 2.35; // angle0：起点角度
      const angle1 = startAngle + t1 * Math.PI * 2.35; // angle1：终点角度
      const x0 = this.centerX + Math.cos(angle0) * radius0; // x0：起点 X
      const y0 = this.centerY + Math.sin(angle0) * radius0 * 0.78; // y0：起点 Y
      const x1 = this.centerX + Math.cos(angle1) * radius1; // x1：终点 X
      const y1 = this.centerY + Math.sin(angle1) * radius1 * 0.78; // y1：终点 Y
      node.moveTo(x0, y0);
      node.lineTo(x1, y1);
      node.stroke({ width: 10 * (1 - t0) + 1.5, color, alpha: alpha * (1 - t0 * 0.78) });
    }
  }

  private drawComet(node: Graphics, x: number, y: number, angle: number, length: number, color: number, alpha: number) {
    const tailX = x - Math.cos(angle) * length; // tailX：拖尾 X
    const tailY = y - Math.sin(angle) * length; // tailY：拖尾 Y
    const sideX = Math.cos(angle + Math.PI / 2) * length * 0.12; // sideX：侧向 X
    const sideY = Math.sin(angle + Math.PI / 2) * length * 0.12; // sideY：侧向 Y
    node.moveTo(tailX, tailY);
    node.bezierCurveTo(x - sideX, y - sideY, x + sideX, y + sideY, x, y);
    node.stroke({ width: Math.max(1.2, length * 0.12), color, alpha });
    node.circle(x, y, Math.max(1.6, length * 0.1));
    node.fill({ color: 0xffffff, alpha: alpha * 0.92 });
  }

  private drawLightning(node: Graphics, startX: number, startY: number, angle: number, length: number, color: number, alpha: number, seed: number) {
    let x = startX; // x：当前 X
    let y = startY; // y：当前 Y
    node.moveTo(x, y);
    for (let step = 1; step <= 9; step += 1) { // step：闪电分段
      const progress = step / 9; // progress：分段进度
      const jitter = Math.sin(seed + step * 2.17) * 18 * (1 - progress * 0.34); // jitter：折线扰动
      x = startX + Math.cos(angle) * length * progress + Math.cos(angle + Math.PI / 2) * jitter;
      y = startY + Math.sin(angle) * length * progress + Math.sin(angle + Math.PI / 2) * jitter;
      node.lineTo(x, y);
    }
    node.stroke({ width: 5.8, color, alpha: alpha * 0.45 });
    node.stroke({ width: 1.4, color: 0xffffff, alpha: alpha });
  }

  private drawFeather(node: Graphics, x: number, y: number, size: number, angle: number, color: number, alpha: number) {
    const tipX = x + Math.cos(angle) * size; // tipX：羽片尖端 X
    const tipY = y + Math.sin(angle) * size; // tipY：羽片尖端 Y
    const tailX = x - Math.cos(angle) * size * 0.9; // tailX：羽片尾端 X
    const tailY = y - Math.sin(angle) * size * 0.9; // tailY：羽片尾端 Y
    const sideX = Math.cos(angle + Math.PI / 2) * size * 0.32; // sideX：侧边 X
    const sideY = Math.sin(angle + Math.PI / 2) * size * 0.32; // sideY：侧边 Y
    node.moveTo(tailX, tailY);
    node.bezierCurveTo(x + sideX, y + sideY, x + sideX * 0.4, y + sideY * 0.4, tipX, tipY);
    node.bezierCurveTo(x - sideX * 0.2, y - sideY * 0.2, x - sideX, y - sideY, tailX, tailY);
    node.fill({ color, alpha });
    node.stroke({ width: 1.2, color: 0xffffff, alpha: alpha * 0.55 });
  }

  private drawFlameTongue(node: Graphics, baseX: number, baseY: number, width: number, height: number, phase: number, alpha: number) {
    const sway = Math.sin(phase) * width * 0.45; // sway：顶部摆动
    const split = Math.sin(phase * 1.7) > 0.24; // split：是否分叉
    node.moveTo(baseX - width, baseY);
    node.bezierCurveTo(baseX - width * 1.2, baseY - height * 0.42, baseX - width * 0.42 + sway, baseY - height * 0.72, baseX + sway, baseY - height);
    if (split) {
      node.bezierCurveTo(baseX + width * 0.24, baseY - height * 0.76, baseX + width * 0.76, baseY - height * 0.72, baseX + width * 0.48, baseY - height * 0.52);
    }
    node.bezierCurveTo(baseX + width * 1.1, baseY - height * 0.35, baseX + width * 1.15, baseY - height * 0.08, baseX + width, baseY);
    node.closePath();
    node.fill({ color: 0x07858c, alpha: alpha * 0.72 });
    node.stroke({ width: 2, color: 0x7fd8dc, alpha: alpha * 0.42 });
    node.moveTo(baseX - width * 0.42, baseY);
    node.bezierCurveTo(baseX - width * 0.52, baseY - height * 0.3, baseX - width * 0.06 + sway * 0.5, baseY - height * 0.55, baseX + sway * 0.5, baseY - height * 0.72);
    node.bezierCurveTo(baseX + width * 0.36, baseY - height * 0.42, baseX + width * 0.46, baseY - height * 0.16, baseX + width * 0.34, baseY);
    node.closePath();
    node.fill({ color: 0x33c6cc, alpha: alpha * 0.7 });
  }

  private drawRuneGlyph(node: Graphics, x: number, y: number, size: number, angle: number, color: number, alpha: number) {
    const cos = Math.cos(angle); // cos：旋转余弦
    const sin = Math.sin(angle); // sin：旋转正弦
    const point = (px: number, py: number) => ({ x: x + px * cos - py * sin, y: y + px * sin + py * cos }); // point：局部坐标转世界坐标
    const a = point(-size * 0.35, -size * 0.4);
    const b = point(size * 0.32, -size * 0.08);
    const c = point(-size * 0.1, size * 0.46);
    node.moveTo(a.x, a.y);
    node.lineTo(b.x, b.y);
    node.lineTo(c.x, c.y);
    node.stroke({ width: 2.1, color, alpha });
    const d = point(size * 0.34, size * 0.42);
    node.moveTo(b.x, b.y);
    node.lineTo(d.x, d.y);
    node.stroke({ width: 1.3, color: 0xffffff, alpha: alpha * 0.55 });
  }

  private drawBrokenEllipse(node: Graphics, x: number, y: number, radiusX: number, radiusY: number, spin: number, color: number, alpha: number) {
    for (let segment = 0; segment < 9; segment += 1) { // segment：断裂环段序号
      const start = spin + segment * 0.68; // start：断裂段起点角度
      const end = start + 0.34; // end：断裂段终点角度
      node.moveTo(x + Math.cos(start) * radiusX, y + Math.sin(start) * radiusY);
      node.bezierCurveTo(
        x + Math.cos((start + end) / 2) * radiusX * 1.04,
        y + Math.sin((start + end) / 2) * radiusY * 1.04,
        x + Math.cos((start + end) / 2) * radiusX * 1.04,
        y + Math.sin((start + end) / 2) * radiusY * 1.04,
        x + Math.cos(end) * radiusX,
        y + Math.sin(end) * radiusY,
      );
      node.stroke({ width: 2.2, color, alpha });
    }
  }

  private drawOrbit(node: Graphics, x: number, y: number, radiusX: number, radiusY: number, spin: number, color: number, alpha: number) {
    for (let step = 0; step < 32; step += 1) { // step：轨道采样点
      const a0 = step / 32 * Math.PI * 2 + spin; // a0：起点角度
      const a1 = (step + 0.55) / 32 * Math.PI * 2 + spin; // a1：终点角度
      node.moveTo(x + Math.cos(a0) * radiusX, y + Math.sin(a0) * radiusY);
      node.lineTo(x + Math.cos(a1) * radiusX, y + Math.sin(a1) * radiusY);
      node.stroke({ width: 1.2, color, alpha: alpha * (step % 3 === 0 ? 1 : 0.42) });
    }
  }

  private drawStar(node: Graphics, x: number, y: number, size: number, color: number, alpha: number) {
    node.moveTo(x - size, y);
    node.lineTo(x + size, y);
    node.stroke({ width: 1.3, color, alpha });
    node.moveTo(x, y - size);
    node.lineTo(x, y + size);
    node.stroke({ width: 1.3, color, alpha });
    node.circle(x, y, size * 0.22);
    node.fill({ color: 0xffffff, alpha: alpha * 0.8 });
  }

  private drawAuroraRibbon(node: Graphics, baseY: number, offset: number, color: number, alpha: number, wave: number) {
    const left = this.centerX - 260; // left：丝带左边界
    node.moveTo(left, baseY);
    for (let step = 1; step <= 18; step += 1) { // step：丝带采样
      const x = left + step * 30; // x：采样 X
      const y = baseY + Math.sin(step * 0.78 + offset) * wave + Math.sin(step * 1.54 - offset * 0.6) * 10; // y：采样 Y
      node.lineTo(x, y);
    }
    node.stroke({ width: 18, color, alpha: alpha * 0.42 });
    node.stroke({ width: 3, color: 0xffffff, alpha: alpha * 0.38 });
  }

  private drawPrismBeam(node: Graphics, x: number, y: number, angle: number, length: number, color: number, alpha: number) {
    const endX = x + Math.cos(angle) * length; // endX：光束终点 X
    const endY = y + Math.sin(angle) * length; // endY：光束终点 Y
    const sideX = Math.cos(angle + Math.PI / 2) * 16; // sideX：光束侧边 X
    const sideY = Math.sin(angle + Math.PI / 2) * 16; // sideY：光束侧边 Y
    node.moveTo(x - sideX, y - sideY);
    node.lineTo(x + sideX, y + sideY);
    node.lineTo(endX + sideX * 0.24, endY + sideY * 0.24);
    node.lineTo(endX - sideX * 0.24, endY - sideY * 0.24);
    node.closePath();
    node.fill({ color, alpha });
  }
}
