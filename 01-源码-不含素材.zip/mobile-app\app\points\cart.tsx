import { PageHeader } from "@/components/shared";
import CloudBuyProgress from "@/components/points/CloudBuyProgress";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { Colors } from "@/constants/theme";
import {
  useAddPointsCart,
  useDelPointsCart,
  usePointsCart,
  usePointsProducts,
  useUpdatePointsCartNum,
} from "@/hooks";
import { unwrapApiPagedList } from "@/lib/api/response";
import { mapCloudProduct, pickSoonToReveal } from "@/lib/points/cloudBuyParse";
import { mergePendingCartItem, parseCloudBuyCart, QTY_PRESETS } from "@/lib/points/cloudBuyCart";
import type { CloudBuyCartItem } from "@/lib/points/cloudBuyCart";
import { clearPendingCartItem, peekPendingCartItem } from "@/lib/points/openCloudBuyCart";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import { useRouter } from "expo-router";
import { ShoppingCart, Trash2 } from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Modal,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const TEAL = Colors.primary.DEFAULT;
const TEAL_DARK = Colors.primary.dark;

export default function PointsCartScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const { data, isLoading, refetch } = usePointsCart();
  const showToast = useAppStore((s) => s.showToast);
  const { data: productData } = usePointsProducts(1, 80);
  const delCart = useDelPointsCart();
  const addCart = useAddPointsCart();
  const updateNum = useUpdatePointsCartNum();
  const [draft, setDraft] = useState<Record<number, string>>({});
  const [batchQty, setBatchQty] = useState("");
  const [askDelete, setAskDelete] = useState<CloudBuyCartItem | "all" | null>(null);
  const [hiddenPids, setHiddenPids] = useState<number[]>([]);

  const items = useMemo(
    () =>
      mergePendingCartItem(parseCloudBuyCart(data), peekPendingCartItem()).filter(
        (it) => !hiddenPids.includes(it.productId),
      ),
    [data, hiddenPids],
  );
  const totalShares = items.reduce((s, it) => s + Math.max(1, Number(draft[it.id] ?? it.num) || it.num), 0);

  const history = useMemo(() => {
    const inCart = new Set(items.map((it) => it.productId));
    const pool = unwrapApiPagedList<any>(productData)
      .map(mapCloudProduct)
      .filter((p): p is NonNullable<ReturnType<typeof mapCloudProduct>> => !!p && !inCart.has(p.id));
    return pickSoonToReveal(pool, 8);
  }, [productData, items]);

  const commitQty = (item: CloudBuyCartItem, raw: string | number) => {
    if (item.remain <= 0) return;
    let n = Math.floor(Number(raw) || 1);
    n = Math.max(1, Math.min(item.remain, n));
    setDraft((d) => ({ ...d, [item.id]: String(n) }));
    if (item.id > 0 && n !== item.num) updateNum.mutate({ id: item.id, number: n });
  };

  const applyBatch = () => {
    const n = Math.floor(Number(batchQty) || 0);
    if (n < 1) return;
    items.forEach((it) => commitQty(it, n));
  };

  const resolveCartId = (item: CloudBuyCartItem) => {
    if (item.id > 0) return item.id;
    return parseCloudBuyCart(data).find((row) => row.productId === item.productId)?.id ?? 0;
  };

  const removeItem = (item: CloudBuyCartItem) => {
    setHiddenPids((prev) => (prev.includes(item.productId) ? prev : [...prev, item.productId]));
    clearPendingCartItem();
    const cartId = resolveCartId(item);
    if (cartId > 0) delCart.mutate([cartId]);
    setAskDelete(null);
  };

  const removeAll = () => {
    setHiddenPids(items.map((it) => it.productId));
    clearPendingCartItem();
    const ids = items.map(resolveCartId).filter((id) => id > 0);
    if (ids.length) delCart.mutate(ids);
    setAskDelete(null);
  };

  const onCheckout = async () => {
    if (!isLoggedIn) {
      router.push("/auth");
      return;
    }
    if (updateNum.isPending) {
      showToast(t("pointsMall.payWaitCart"), "info");
      return;
    }
    if (!items.length) return;
    let ids = items.map(resolveCartId).filter((id) => id > 0);
    if (!ids.length) {
      const fresh = await refetch();
      ids = parseCloudBuyCart(fresh.data)
        .map((it) => it.id)
        .filter((id) => id > 0);
    }
    if (!ids.length) {
      showToast(t("pointsMall.payCartNotReady"), "error");
      return;
    }
    router.push({
      pathname: "/points/pay",
      params: { ids: ids.join(",") },
    } as never);
  };

  const addHistoryAll = () => {
    history.forEach((p) => addCart.mutate({ productId: p.id, cartNum: 1 }));
    setHiddenPids([]);
  };

  const barBottom = pointsMallTabPaddingBottom(insets.bottom);

  return (
    <View className="flex-1 bg-white">
      <PageHeader title={t("pointsMall.tabCart")} />
      <ScrollView contentContainerStyle={{ paddingBottom: barBottom + (items.length ? 168 : 24) }}>
        {isLoading && items.length === 0 ? (
          <ActivityIndicator color={TEAL} style={{ marginTop: 40 }} />
        ) : items.length === 0 ? (
          <View className="items-center pt-10 px-4">
            <View className="w-16 h-16 rounded-full items-center justify-center bg-gray-100">
              <ShoppingCart size={28} color="#C4C7C7" />
            </View>
            <Text className="mt-3 text-sm text-gray-500">{t("pointsMall.cartEmpty")}</Text>
            <View className="flex-row mt-4" style={{ gap: 10 }}>
              <Pressable
                className="h-9 px-5 rounded items-center justify-center"
                style={{ backgroundColor: TEAL }}
                onPress={() => router.push("/points")}
              >
                <Text className="text-white text-sm font-bold">{t("pointsMall.goShopping")}</Text>
              </Pressable>
              <Pressable
                className="h-9 px-5 rounded items-center justify-center"
                style={{ backgroundColor: Colors.primary.light }}
                onPress={() => router.push("/points/collection")}
              >
                <Text className="text-sm font-bold" style={{ color: TEAL_DARK }}>
                  {t("pointsMall.myFavorites")}
                </Text>
              </Pressable>
            </View>

            {history.length > 0 ? (
              <View className="w-full mt-8">
                <View className="flex-row items-center mb-2">
                  <View style={{ width: 3, height: 14, backgroundColor: TEAL, borderRadius: 2, marginRight: 6 }} />
                  <Text className="text-sm font-bold text-gray-800">{t("pointsMall.browseHistoryTitle")}</Text>
                </View>
                {history.map((p) => (
                  <View key={p.id} className="flex-row items-center py-3 border-b border-gray-100">
                    <Pressable
                      onPress={() => router.push({ pathname: "/points/product", params: { id: String(p.id) } })}
                    >
                      {p.image ? (
                        <Image source={p.image} style={{ width: 72, height: 72 }} contentFit="contain" />
                      ) : (
                        <View style={{ width: 72, height: 72, backgroundColor: "#f3f3f3" }} />
                      )}
                    </Pressable>
                    <View className="flex-1 ml-3">
                      <Text className="text-[13px] text-gray-800" numberOfLines={2}>
                        {p.name}
                      </Text>
                      <Text className="text-xs text-gray-400 mt-1">
                        {t("pointsMall.valueLabel")}:{p.points}
                      </Text>
                      <View className="mt-1">
                        <CloudBuyProgress
                          joined={p.sold}
                          total={p.total}
                          remain={p.remain}
                          joinedLabel={t("pointsMall.joined")}
                          totalLabel={t("pointsMall.totalNeed")}
                          remainLabel={t("pointsMall.remain")}
                        />
                      </View>
                    </View>
                    <Pressable
                      className="w-9 h-9 rounded-full items-center justify-center ml-2"
                      style={{ backgroundColor: TEAL }}
                      onPress={() => {
                        if (!isLoggedIn) {
                          router.push("/auth");
                          return;
                        }
                        addCart.mutate({ productId: p.id, cartNum: 1 });
                        setHiddenPids((prev) => prev.filter((id) => id !== p.id));
                      }}
                    >
                      <ShoppingCart size={16} color="#fff" />
                    </Pressable>
                  </View>
                ))}
                <Pressable
                  className="self-center mt-4 w-14 h-14 rounded-full items-center justify-center"
                  style={{ backgroundColor: TEAL }}
                  onPress={addHistoryAll}
                >
                  <Text className="text-white text-[10px] font-bold text-center">
                    {t("pointsMall.addAllToCart").replace(/ /g, "\n")}
                  </Text>
                </Pressable>
              </View>
            ) : null}
          </View>
        ) : (
          items.map((item) => {
            const qty = draft[item.id] ?? String(item.num);
            return (
              <View key={`${item.id}-${item.productId}`} className="flex-row px-3 py-3 border-b border-gray-100">
                <Pressable
                  onPress={() =>
                    router.push({ pathname: "/points/product", params: { id: String(item.productId) } })
                  }
                >
                  {item.image ? (
                    <Image source={item.image} style={{ width: 72, height: 72 }} contentFit="contain" />
                  ) : (
                    <View style={{ width: 72, height: 72, backgroundColor: "#f3f3f3" }} />
                  )}
                </Pressable>
                <View className="flex-1 ml-3">
                  <Text className="text-[13px] text-gray-800" numberOfLines={2}>
                    {item.bianhao ? `(${t("pointsMall.periodN", { n: item.bianhao })})` : ""}
                    {item.name}
                  </Text>
                  <Text className="text-xs text-gray-500 mt-1">
                    {t("pointsMall.remainShares", { n: item.remain })}
                  </Text>
                  <View className="flex-row items-center mt-2">
                    <Pressable
                      className="w-7 h-7 border border-gray-200 items-center justify-center"
                      onPress={() => commitQty(item, Number(qty) - 1)}
                    >
                      <Text className="text-gray-500">-</Text>
                    </Pressable>
                    <TextInput
                      value={qty}
                      keyboardType="number-pad"
                      onChangeText={(v) => setDraft((d) => ({ ...d, [item.id]: v.replace(/[^\d]/g, "") }))}
                      onBlur={() => commitQty(item, qty)}
                      style={{
                        width: 48,
                        height: 28,
                        textAlign: "center",
                        color: TEAL_DARK,
                        fontWeight: "700",
                        borderTopWidth: 1,
                        borderBottomWidth: 1,
                        borderColor: "#eee",
                      }}
                    />
                    <Pressable
                      className="w-7 h-7 border border-gray-200 items-center justify-center"
                      onPress={() => commitQty(item, Number(qty) + 1)}
                    >
                      <Text className="text-gray-500">+</Text>
                    </Pressable>
                    <Pressable className="ml-auto p-2" onPress={() => setAskDelete(item)}>
                      <Trash2 size={16} color="#9CA3AF" />
                    </Pressable>
                  </View>
                  <View className="flex-row mt-2" style={{ gap: 8 }}>
                    {QTY_PRESETS.map((n) => (
                      <Pressable
                        key={n}
                        onPress={() => commitQty(item, Math.min(n, item.remain))}
                        className="px-3 h-7 border border-gray-200 rounded items-center justify-center"
                      >
                        <Text className="text-xs text-gray-700">{n}</Text>
                      </Pressable>
                    ))}
                    <Pressable
                      onPress={() => commitQty(item, item.remain)}
                      className="px-3 h-7 border rounded items-center justify-center"
                      style={{ borderColor: TEAL }}
                    >
                      <Text className="text-xs" style={{ color: TEAL }}>
                        {t("pointsMall.allIn")}
                      </Text>
                    </Pressable>
                  </View>
                </View>
              </View>
            );
          })
        )}
      </ScrollView>

      {items.length > 0 ? (
        <View style={{ position: "absolute", left: 0, right: 0, bottom: barBottom, backgroundColor: "#fff" }}>
          <View className="flex-row items-center px-2 py-2 border-t border-gray-200" style={{ gap: 6 }}>
            <TextInput
              value={batchQty}
              onChangeText={(v) => setBatchQty(v.replace(/[^\d]/g, ""))}
              onSubmitEditing={applyBatch}
              keyboardType="number-pad"
              placeholder=""
              style={{
                width: 72,
                height: 36,
                borderWidth: 1,
                borderColor: TEAL,
                borderRadius: 4,
                textAlign: "center",
              }}
            />
            <Text className="text-sm text-gray-600">{t("pointsMall.perPiece")}</Text>
            <Pressable
              onPress={() => router.push("/points/glist")}
              className="flex-1 h-9 items-center justify-center rounded"
              style={{ borderWidth: 1, borderColor: TEAL }}
            >
              <Text style={{ color: TEAL }}>{t("pointsMall.continueAdd")}</Text>
            </Pressable>
            <Pressable
              onPress={() => setAskDelete("all")}
              className="h-9 px-3 items-center justify-center rounded"
              style={{ borderWidth: 1, borderColor: Colors.error }}
            >
              <Text style={{ color: Colors.error }}>{t("pointsMall.clearCart")}</Text>
            </Pressable>
          </View>
          <View className="flex-row items-center border-t border-gray-100" style={{ height: 56 }}>
            <View className="flex-1 px-3">
              <Text className="text-sm text-gray-700">
                {t("pointsMall.cartTotal")}：
                <Text style={{ color: TEAL_DARK, fontWeight: "700" }}>{totalShares}</Text>
              </Text>
              <Text className="text-xs text-gray-400">{t("pointsMall.totalItems", { n: items.length })}</Text>
            </View>
            <Pressable
              onPress={onCheckout}
              style={{ width: 140, height: 56, backgroundColor: TEAL, alignItems: "center", justifyContent: "center" }}
            >
              <Text className="text-white text-base font-bold">{t("pointsMall.goCheckout")}</Text>
            </Pressable>
          </View>
        </View>
      ) : null}

      <Modal transparent visible={!!askDelete} animationType="fade" onRequestClose={() => setAskDelete(null)}>
        <Pressable
          style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.35)", alignItems: "center", justifyContent: "center" }}
          onPress={() => setAskDelete(null)}
        >
          <Pressable
            onPress={() => {}}
            style={{ width: 280, backgroundColor: "#fff", borderRadius: 8, overflow: "hidden" }}
          >
            <Text className="text-center text-[15px] text-gray-800 px-5 py-6">{t("pointsMall.confirmDeleteCart")}</Text>
            <View className="flex-row border-t border-gray-100">
              <Pressable className="flex-1 h-11 items-center justify-center bg-gray-50" onPress={() => setAskDelete(null)}>
                <Text className="text-gray-600">{t("common.cancel")}</Text>
              </Pressable>
              <Pressable
                className="flex-1 h-11 items-center justify-center"
                style={{ backgroundColor: TEAL }}
                onPress={() => {
                  if (askDelete === "all") removeAll();
                  else if (askDelete) removeItem(askDelete);
                }}
              >
                <Text className="text-white font-bold">{t("common.confirm")}</Text>
              </Pressable>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
      <PointsMallTabBar />
    </View>
  );
}
