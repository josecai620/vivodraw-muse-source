import React, { useEffect, useRef, useState } from "react";
import { Animated, Easing, Pressable, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useLuckyNotices } from "@/hooks";
import { Colors } from "@/constants/theme";
import { pickLang } from "./utils";

interface HlBoxRevealProps {
  props: {
    title?: { en?: string; zh?: string } | string;
    link?: string;
    interval?: number;
  };
  lang: string;
}

interface LuckyItem {
  nickname?: string;
  item_name?: string;
  box_name?: string;
}

/** 盲盒开奖条：滚动显示最近中奖记录，点击跳盲盒首页 */
export default function HlBoxReveal({ props, lang }: HlBoxRevealProps) {
  const router = useRouter();
  const { data } = useLuckyNotices();
  const list: LuckyItem[] = Array.isArray((data as any)?.data)
    ? (data as any).data
    : Array.isArray(data)
      ? (data as any)
      : [];
  const [idx, setIdx] = useState(0);
  const fade = useRef(new Animated.Value(1)).current;
  const interval = Math.max(1500, props.interval ?? 3000);

  useEffect(() => {
    if (list.length <= 1) return;
    const t = setInterval(() => {
      Animated.sequence([
        Animated.timing(fade, { toValue: 0, duration: 200, easing: Easing.linear, useNativeDriver: true }),
        Animated.timing(fade, { toValue: 1, duration: 200, easing: Easing.linear, useNativeDriver: true }),
      ]).start();
      setTimeout(() => setIdx((i) => (i + 1) % list.length), 200);
    }, interval);
    return () => clearInterval(t);
  }, [list.length, interval]);

  if (list.length === 0) return null;
  const cur = list[idx] ?? {};
  const title = pickLang(props.title, lang) || (lang === "en" ? "Latest Wins" : "最近開獎");
  const msg = `${cur.nickname || "***"} · ${cur.item_name || cur.box_name || "?"}`;
  const link = props.link || "/box";

  return (
    <Pressable onPress={() => router.push(link as any)} className="mx-4 mt-3 h-10 px-3 rounded-full flex-row items-center" style={{ backgroundColor: "#F7F8F8", gap: 8 }}>
      <Text style={{ fontSize: 12, color: Colors.brand.red, fontWeight: "600" }}>{title}</Text>
      <Animated.View style={{ flex: 1, opacity: fade }}>
        <Text numberOfLines={1} style={{ color: Colors.neutral[800], fontSize: 12 }}>{msg}</Text>
      </Animated.View>
      <Text style={{ fontSize: 12, color: Colors.neutral[500] }}>›</Text>
    </Pressable>
  );
}
