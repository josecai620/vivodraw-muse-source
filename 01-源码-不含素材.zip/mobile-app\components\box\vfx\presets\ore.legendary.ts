import type { VFXPresetConfig } from '../core/VFXConfig';

export const oreLegendaryPreset: VFXPresetConfig = { // oreLegendaryPreset：传说金色 SSR 矿石
  id: 'legendary',
  label: 'legendary',
  glow: {
    enabled: true,
    glowColor: 0x04a8ae,
    glowStrength: 1.22,
    glowSpeed: 1.28,
  },
  flow: {
    enabled: true,
    flowColor: 0x33c6cc,
    flowSpeed: 1.22,
    sweepSpeed: 1.16,
  },
  energy: {
    enabled: true,
    energyColor: 0x04a8ae,
    energyWaveSize: 1.25,
    energyWaveStrength: 1.18,
  },
  explosion: {
    enabled: true,
    explosionStrength: 1,
    explosionDuration: 0.95,
  },
  fire: {
    enabled: true,
    fireIntensity: 0.58,
    fireSpeed: 0.8,
  },
  spark: {
    enabled: true,
    particleColor: 0x7fd8dc,
    particleCount: 54,
    particleSize: 1.12,
  },
};
