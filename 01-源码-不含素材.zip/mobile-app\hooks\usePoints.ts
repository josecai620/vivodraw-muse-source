import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getPointsBalance,
  getPointsLog,
  getPointsIndex,
  getPointsProducts,
  getPointsProductDetail,
  getPointsCategories,
  getPointsCategoryProducts,
  getPointsOrderList,
  getPointsOrderDetail,
  getPointsOrderExpress,
  exchangePoints,
  integralOrderConfirm,
  createIntegralOrder,
  deleteIntegralOrder,
  getPointsCartList,
  addPointsCart,
  delPointsCart,
  updatePointsCartNum,
  getPointsCollectList,
  addPointsCollect,
  delPointsCollect,
  getSignConfig,
  getSignUser,
  getSignList,
  doSign,
  getPointsTasks,
  claimPointsTask,
  trackPointsTaskEvent,
  getLotteryInfo,
  drawLottery,
  getLotteryRecord,
  getPointsNotifications,
  getShaidanList,
  getShaidanDetail,
  getShaidanDetailComments,
  addShaidanComment,
  shaidanLike,
  postShaidan,
  getUserShaidanList,
  getRedemptionList,
  getPointsHelpList,
  getPointsHelpDetail,
  getFanxianList,
  getHuandeInfo,
  confirmHuandeAddress,
  recycleItem,
  getRevealIndex,
  getRevealLists,
  getRevealDetail,
  getRevealMyRecords,
  getRevealView,
  getRevealVerify,
  type RevealPeriodLocator,
  exchangeAll,
  getLuckyShop,
  redeemLuckyShop,
  pointsTransfer,
  getTanchuang,
  getHqjlLists,
  getHqjlInfo,
  getUserHqjlLists,
  getDetailHqjl,
  getDetailLshqz,
  getDetailJsxq,
  getDetailJsxqLists,
  getProductShaidanList,
  getProductReplyList,
  getProductReplyConfig,
  getNewIntegralList,
  getNewIntegralCategory,
  getSignMonth,
  getPointsCartCount,
  getDetailDesc,
  getNotice,
  getTongzhi,
  deleteTongzhi,
  getShaidanNum,
  getDetailHqjlUnique,
  cartAddAll,
  collectAll,
  collectAddAll,
  collectAllDel,
} from "@/lib/api/points";
import i18n from "i18next";
import { unwrapApiData } from "@/lib/api/response";
import { peekPendingCartItem, rememberPendingCartItem } from "@/lib/points/openCloudBuyCart";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";

export function usePointsBalance(enabled = true) {
  return useQuery({ queryKey: ["pointsBalance"], queryFn: getPointsBalance, enabled });
}

export function usePointsLog(page = 1, kind: "points" | "bond" = "points") {
  return useQuery({
    queryKey: ["pointsLog", page, kind],
    queryFn: () => getPointsLog({ page, limit: kind === "bond" ? 50 : 20, kind }),
  });
}

export function usePointsIndex() {
  return useQuery({ queryKey: ["pointsIndex"], queryFn: getPointsIndex });
}

export function usePointsProducts(page = 1, limit = 20) {
  return useQuery({
    queryKey: ["pointsProducts", page, limit],
    queryFn: () => getPointsProducts({ page, limit }),
  });
}

export function usePointsProductDetail(id: number) {
  return useQuery({ queryKey: ["pointsProduct", id], queryFn: () => getPointsProductDetail(id), enabled: id > 0 });
}

export function usePointsCategories() {
  return useQuery({ queryKey: ["pointsCategories"], queryFn: getPointsCategories });
}

export function usePointsCategoryProducts(cid: number, page = 1) {
  return useQuery({ queryKey: ["pointsCatProducts", cid, page], queryFn: () => getPointsCategoryProducts({ cid, page, limit: 20 }), enabled: cid > 0 });
}

export function usePointsOrderList(type = -1, page = 1) {
  return useQuery({ queryKey: ["pointsOrders", type, page], queryFn: () => getPointsOrderList({ type, page, limit: 20 }) });
}

export function usePointsOrderDetail(id: string) {
  return useQuery({ queryKey: ["pointsOrderDetail", id], queryFn: () => getPointsOrderDetail(id), enabled: !!id });
}

export function usePointsOrderExpress(id: string) {
  return useQuery({ queryKey: ["pointsExpress", id], queryFn: () => getPointsOrderExpress(id), enabled: !!id });
}

export function useExchangePoints() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: exchangePoints,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["pointsBalance"] }); showToast("Redeemed successfully!", "success"); },
    onError: (e: Error) => {
      showToast(e.message, "error");
    },
  });
}

export function usePointsCart() {
  const isHydrated = useAuthStore((s) => s.isHydrated);
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  return useQuery({
    queryKey: ["pointsCart"],
    queryFn: getPointsCartList,
    enabled: isHydrated && isLoggedIn,
  });
}

export function useAddPointsCart() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: addPointsCart,
    onSuccess: (res: any) => {
      const cartId = Number(res?.data?.cartId ?? res?.data?.data?.cartId ?? res?.cartId ?? 0);
      const pending = peekPendingCartItem();
      if (pending && cartId > 0) {
        rememberPendingCartItem({ ...pending, id: cartId });
      }
      qc.invalidateQueries({ queryKey: ["pointsCart"] });
      qc.invalidateQueries({ queryKey: ["pointsCartCount"] });
      qc.invalidateQueries({ queryKey: ["pointsCartList"] });
      void qc.refetchQueries({ queryKey: ["pointsCartCount"] });
      showToast(i18n.t("pointsMall.addedToCartDesc"), "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useDelPointsCart() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: delPointsCart,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pointsCart"] });
      qc.invalidateQueries({ queryKey: ["pointsCartList"] });
      qc.invalidateQueries({ queryKey: ["pointsCartCount"] });
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useUpdatePointsCartNum() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: updatePointsCartNum,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pointsCart"] });
      qc.invalidateQueries({ queryKey: ["pointsCartList"] });
      qc.invalidateQueries({ queryKey: ["pointsCartCount"] });
    },
  });
}

export function usePointsCollection(page = 1) {
  const isHydrated = useAuthStore((s) => s.isHydrated);
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  return useQuery({
    queryKey: ["pointsCollection", page],
    queryFn: () => getPointsCollectList({ page, limit: 20 }),
    enabled: isHydrated && isLoggedIn,
  });
}

export function useAddPointsCollect() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: addPointsCollect,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pointsCollection"] });
      void qc.refetchQueries({ queryKey: ["pointsCollection"] });
      showToast(i18n.t("pointsMall.collected"), "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useDelPointsCollect() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: delPointsCollect,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pointsCollection"] });
      void qc.refetchQueries({ queryKey: ["pointsCollection"] });
      showToast(i18n.t("pointsMall.uncollected"), "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useSignConfig(enabled = true) {
  return useQuery({ queryKey: ["signConfig"], queryFn: getSignConfig, enabled });
}

export function useSignUser(enabled = true) {
  return useQuery({
    queryKey: ["signUser"],
    queryFn: () => getSignUser({ sign: 1 }),
    enabled,
  });
}

export function useSignList(page = 1) {
  return useQuery({ queryKey: ["signList", page], queryFn: () => getSignList({ page, limit: 20 }) });
}

export function useDoSign() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: doSign,
    onSuccess: (res: unknown) => {
      qc.invalidateQueries({ queryKey: ["signConfig"] });
      qc.invalidateQueries({ queryKey: ["signUser"] });
      qc.invalidateQueries({ queryKey: ["signMonth"] });
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      qc.invalidateQueries({ queryKey: ["pointsTasks"] });
      const payload = unwrapApiData<Record<string, unknown>>(res, {});
      const pts = Number(payload.integral ?? 0);
      const exp = Number(payload.exp ?? 0);
      if (exp > 0) {
        showToast(i18n.t("home.claimBar.claimedExpToast", { exp }), "success");
      } else if (pts > 0) {
        showToast(i18n.t("home.claimBar.claimedToast", { pts }), "success");
      } else {
        showToast(i18n.t("home.claimBar.claimed"), "success");
      }
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useLotteryInfo(factor?: string) {
  return useQuery({ queryKey: ["lotteryInfo", factor], queryFn: () => getLotteryInfo(factor) });
}

export function useDrawLottery() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: drawLottery,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["pointsBalance"] }); qc.invalidateQueries({ queryKey: ["lotteryRecord"] }); },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useLotteryRecord(page = 1) {
  return useQuery({ queryKey: ["lotteryRecord", page], queryFn: () => getLotteryRecord({ page, limit: 20 }) });
}

export function usePointsNotifications(page = 1) {
  return useQuery({ queryKey: ["pointsNotifications", page], queryFn: () => getPointsNotifications({ page, limit: 20 }) });
}

export function useShaidanList(page = 1) {
  return useQuery({ queryKey: ["shaidanList", page], queryFn: () => getShaidanList({ page, limit: 20 }) });
}

export function useRedemptionList(page = 1) {
  return useQuery({ queryKey: ["redemptionList", page], queryFn: () => getRedemptionList({ page, limit: 20 }) });
}

// ─── 积分订单确认/创建 ──────────────────────────────────────────────────

export function useIntegralOrderConfirm(unique: string, num: number) {
  return useQuery({
    queryKey: ["integralOrderConfirm", unique, num],
    queryFn: () => integralOrderConfirm({ unique, num }),
    enabled: !!unique,
  });
}

export function useCreateIntegralOrder() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: createIntegralOrder,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      qc.invalidateQueries({ queryKey: ["pointsOrders"] });
      showToast("Order created!", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useDeleteIntegralOrder() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: deleteIntegralOrder,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pointsOrders"] });
      showToast("Order deleted", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

// ─── 帮助中心 ────────────────────────────────────────────────────────────

export function usePointsHelpList(cid = 1) {
  return useQuery({ queryKey: ["pointsHelp", cid], queryFn: () => getPointsHelpList(cid) });
}

export function usePointsHelpDetail(id: number) {
  return useQuery({ queryKey: ["pointsHelpDetail", id], queryFn: () => getPointsHelpDetail(id), enabled: id > 0 });
}

// ─── 返现记录 ────────────────────────────────────────────────────────────

export function usePointsFanxianList(page = 1) {
  return useQuery({ queryKey: ["fanxianList", page], queryFn: () => getFanxianList({ page, limit: 20 }) });
}

// ─── 晒单详情/评论/点赞/发布 ─────────────────────────────────────────────

export function useShaidanDetail(shaidanId: number) {
  return useQuery({ queryKey: ["shaidanDetail", shaidanId], queryFn: () => getShaidanDetail(shaidanId), enabled: shaidanId > 0 });
}

export function useShaidanDetailComments(shaidanId: number, page = 1) {
  return useQuery({ queryKey: ["shaidanComments", shaidanId, page], queryFn: () => getShaidanDetailComments(shaidanId, page), enabled: shaidanId > 0 });
}

export function useAddShaidanComment() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: (data: { shaidanId: number; content: string }) =>
      addShaidanComment({ shaidan_id: data.shaidanId, content: data.content }),
    onSuccess: (_d, vars) => {
      qc.invalidateQueries({ queryKey: ["shaidanComments", vars.shaidanId] });
      qc.invalidateQueries({ queryKey: ["shaidanDetail", vars.shaidanId] });
      qc.invalidateQueries({ queryKey: ["shaidanList"] });
      if (!["❤️", "👍", "😂", "🎉", "🔥"].includes(vars.content)) {
        showToast("Comment posted!", "success");
      }
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useShaidanLike() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: number) => shaidanLike({ id }),
    onSuccess: (_d, id) => {
      qc.invalidateQueries({ queryKey: ["shaidanDetail", id] });
      qc.invalidateQueries({ queryKey: ["shaidanList"] });
    },
  });
}

export function usePostShaidan() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: postShaidan,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["shaidanList"] });
      qc.invalidateQueries({ queryKey: ["userShaidanList"] });
      showToast("Review posted!", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useUserShaidanList(page = 1) {
  return useQuery({ queryKey: ["userShaidanList", page], queryFn: () => getUserShaidanList({ page, limit: 20 }) });
}

// ─── 兑换详情/确认地址/回收 ───────────────────────────────────────────────

export function useHuandeInfo(id: number) {
  return useQuery({ queryKey: ["huandeInfo", id], queryFn: () => getHuandeInfo(id), enabled: id > 0 });
}

export function useConfirmHuandeAddress() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: (data: { id: number; addressId: number }) => confirmHuandeAddress(data.id, data.addressId),
    onSuccess: (_d, vars) => {
      qc.invalidateQueries({ queryKey: ["huandeInfo", vars.id] });
      qc.invalidateQueries({ queryKey: ["redemptionList"] });
      showToast("Address confirmed!", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useRecycleItem() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: recycleItem,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["huandeInfo"] });
      qc.invalidateQueries({ queryKey: ["redemptionList"] });
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      showToast("Item recycled for points!", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

// ─── 批量兑换 / 积分互转 / 弹窗 ─────────────────────────────────────────

export function useExchangeAll() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: exchangeAll,
    onSuccess: (res: any) => {
      const payload = res?.data ?? res ?? {};
      const after = Number(payload?.balanceAfter ?? payload?.data?.balanceAfter);
      const luckyAfter = Number(payload?.luckyBalanceAfter ?? payload?.data?.luckyBalanceAfter);
      const user = useAuthStore.getState().user;
      if (user) {
        useAuthStore.getState().setUser({
          ...user,
          ...(Number.isFinite(after) && after >= 0 ? { integral: after } : {}),
          ...(Number.isFinite(luckyAfter) && luckyAfter >= 0 ? { lucky_num: luckyAfter } : {}),
        });
      }
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      qc.invalidateQueries({ queryKey: ["pointsCart"] });
      qc.invalidateQueries({ queryKey: ["pointsCartCount"] });
      qc.invalidateQueries({ queryKey: ["pointsCartList"] });
      qc.invalidateQueries({ queryKey: ["hqjlLists"] });
      qc.invalidateQueries({ queryKey: ["pointsProducts"] });
      qc.invalidateQueries({ queryKey: ["pointsIndex"] });
      qc.invalidateQueries({ queryKey: ["pointsProduct"] });
      qc.invalidateQueries({ queryKey: ["pointsCatProducts"] });
      qc.invalidateQueries({ queryKey: ["newIntegralList"] });
      qc.invalidateQueries({ queryKey: ["revealIndex"] });
      qc.invalidateQueries({ queryKey: ["pointsLog"] });
      qc.invalidateQueries({ queryKey: ["luckyShop"] });
      showToast(i18n.t("pointsMall.joinedSuccess"), "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useLuckyShop() {
  return useQuery({ queryKey: ["luckyShop"], queryFn: getLuckyShop });
}

export function useLuckyRedeem() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: redeemLuckyShop,
    onSuccess: (res: any) => {
      const payload = res?.data ?? res ?? {};
      const luckyAfter = Number(payload?.balanceAfter ?? payload?.data?.balanceAfter);
      const user = useAuthStore.getState().user;
      if (user && Number.isFinite(luckyAfter) && luckyAfter >= 0) {
        useAuthStore.getState().setUser({ ...user, lucky_num: luckyAfter });
      }
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      qc.invalidateQueries({ queryKey: ["luckyShop"] });
      showToast(i18n.t("pointsMall.luckyRedeemOk"), "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function usePointsTransfer() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: pointsTransfer,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      showToast("Transfer success!", "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useTanchuang(userId?: number) {
  return useQuery({
    queryKey: ["tanchuang", userId],
    queryFn: () => getTanchuang(userId),
    enabled: (userId ?? 0) > 0,
  });
}

// ─── 换取记录体系 ─────────────────────────────────────────────────────────

export function useHqjlLists(params?: { status?: number; page?: number }) {
  return useQuery({
    queryKey: ["hqjlLists", params?.status, params?.page],
    queryFn: () => getHqjlLists({ status: params?.status ?? -1, page: params?.page ?? 1, limit: 20 }),
  });
}

export function useHqjlInfo(id: number) {
  return useQuery({
    queryKey: ["hqjlInfo", id],
    queryFn: () => getHqjlInfo(id),
    enabled: id > 0,
  });
}

export function useUserHqjlLists(params?: { status?: number; page?: number }) {
  return useQuery({
    queryKey: ["userHqjlLists", params?.status, params?.page],
    queryFn: () => getUserHqjlLists({ status: params?.status ?? -1, page: params?.page ?? 1, limit: 20 }),
  });
}

// ─── 商品维度换取记录 / 历史换取者 ────────────────────────────────────────

export function useDetailHqjl(productId: number, bianhao: string, page = 1, limit = 20) {
  return useQuery({
    queryKey: ["detailHqjl", productId, bianhao, page, limit],
    queryFn: () => getDetailHqjl(productId, bianhao, page, limit),
    enabled: productId > 0 && !!bianhao,
  });
}

export function useDetailLshqz(productId: number, page = 1, limit = 50) {
  return useQuery({
    queryKey: ["detailLshqz", productId, page, limit],
    queryFn: () => getDetailLshqz(productId, page, limit),
    enabled: productId > 0,
  });
}

// ─── 揭晓算法详情 ─────────────────────────────────────────────────────────

export function useDetailJsxq(id: number) {
  return useQuery({
    queryKey: ["detailJsxq", id],
    queryFn: () => getDetailJsxq(id),
    enabled: id > 0,
  });
}

export function useDetailJsxqLists(productId: number, bianhao: string) {
  return useQuery({
    queryKey: ["detailJsxqLists", productId, bianhao],
    queryFn: () => getDetailJsxqLists(productId, bianhao),
    enabled: productId > 0 && !!bianhao,
  });
}

// ─── 商品维度晒单列表 ─────────────────────────────────────────────────────

export function useProductShaidanList(productId: number, page = 1) {
  return useQuery({
    queryKey: ["productShaidanList", productId, page],
    queryFn: () => getProductShaidanList(productId, page),
    enabled: productId > 0,
  });
}

// ─── 商品评价 ──────────────────────────────────────────────────────────────

export function useProductReplyList(productId: number, type = 0, page = 1) {
  return useQuery({
    queryKey: ["productReplyList", productId, type, page],
    queryFn: () => getProductReplyList(productId, { type, page, limit: 20 }),
    enabled: productId > 0,
  });
}

export function useProductReplyConfig(productId: number) {
  return useQuery({
    queryKey: ["productReplyConfig", productId],
    queryFn: () => getProductReplyConfig(productId),
    enabled: productId > 0,
  });
}

// ─── 新版积分列表 / 分类 ──────────────────────────────────────────────────

export function useNewIntegralList(params?: {
  page?: number;
  cate?: number;
  order?: number;
  keyword?: string;
  enabled?: boolean;
}) {
  return useQuery({
    queryKey: ["newIntegralList", params?.page, params?.cate, params?.order, params?.keyword],
    queryFn: () =>
      getNewIntegralList({
        page: params?.page ?? 1,
        cate: params?.cate,
        order: params?.order,
        keyword: params?.keyword,
      }),
    enabled: params?.enabled !== false,
  });
}

export function useNewIntegralCategory() {
  return useQuery({
    queryKey: ["newIntegralCategory"],
    queryFn: () => getNewIntegralCategory(),
  });
}

// ─── 签到月历 ──────────────────────────────────────────────────────────────

export function useSignMonth() {
  return useQuery({
    queryKey: ["signMonth"],
    queryFn: getSignMonth,
  });
}

// ─── 揭晓 Hooks ─────────────────────────────────────────────────────────

export function useRevealIndex(refetchInterval?: number) {
  return useQuery({
    queryKey: ["revealIndex"],
    queryFn: getRevealIndex,
    refetchInterval,
  });
}

export function useRevealLists(params?: { cid?: number; page?: number; limit?: number }) {
  return useQuery({
    queryKey: ["revealLists", params?.cid, params?.page],
    queryFn: () => getRevealLists({ cid: params?.cid ?? -1, page: params?.page ?? 1, limit: params?.limit ?? 20 }),
  });
}

export function useRevealDetail(id: number, pid?: number) {
  return useQuery({
    queryKey: ["revealDetail", id, pid],
    queryFn: () => getRevealDetail(id, pid),
    enabled: id > 0,
    refetchInterval: (query) => {
      const djs = Number((query.state.data as { data?: { detail?: { djs?: number; kaijiang_time?: number } } })?.data?.detail?.djs ?? 0);
      const endAt = Number((query.state.data as { data?: { detail?: { kaijiang_time?: number } } })?.data?.detail?.kaijiang_time ?? 0) * 1000;
      if (endAt > Date.now() || djs > 0) return 1000;
      return false;
    },
  });
}

export function useRevealMyRecords(params?: { page?: number; status?: number }) {
  return useQuery({
    queryKey: ["revealMyRecords", params?.page, params?.status],
    queryFn: () => getRevealMyRecords({ page: params?.page ?? 1, limit: 20, status: params?.status }),
  });
}

// ─── T10 可验算揭晓：验算页只读快照 ───────────────────────────────────────

function revealLocatorReady(loc: RevealPeriodLocator) {
  return Boolean(loc.periodId || (loc.productId && loc.bianhao) || loc.kaijiangId);
}

/** 验算页数据（RevealView）。未开奖时每 15 秒刷新，开奖后不再轮询。 */
export function useRevealView(loc: RevealPeriodLocator) {
  return useQuery({
    queryKey: ["revealView", loc.periodId, loc.productId, loc.bianhao, loc.kaijiangId],
    queryFn: () => getRevealView(loc),
    enabled: revealLocatorReady(loc),
    refetchInterval: (query) => {
      const status = (query.state.data as { data?: { status?: string } } | undefined)?.data?.status;
      return status === "resolved" || status === "error" ? false : 15000;
    },
  });
}

/** 服务端复算报告（VerifyReport），按需触发 */
export function useRevealVerify(loc: RevealPeriodLocator, enabled = false) {
  return useQuery({
    queryKey: ["revealVerify", loc.periodId, loc.productId, loc.bianhao, loc.kaijiangId],
    queryFn: () => getRevealVerify(loc),
    enabled: enabled && revealLocatorReady(loc),
  });
}

// ─── 公告 / 通知增强 / 晒单统计 / 唯一号 / 批量操作 ───────────────────────

export function usePointsCartCount() {
  const isHydrated = useAuthStore((s) => s.isHydrated);
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  return useQuery({
    queryKey: ["pointsCartCount"],
    queryFn: getPointsCartCount,
    enabled: isHydrated && isLoggedIn,
    refetchOnMount: "always",
    staleTime: 0,
  });
}

export function useDetailDesc(id: number) {
  return useQuery({
    queryKey: ["detailDesc", id],
    queryFn: () => getDetailDesc(id),
    enabled: id > 0,
  });
}

export function useNotice() {
  return useQuery({ queryKey: ["notice"], queryFn: getNotice });
}

export function useTongzhi() {
  return useQuery({ queryKey: ["tongzhi"], queryFn: getTongzhi });
}

export function useDeleteTongzhi() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (params: { type?: string; id?: number }) => deleteTongzhi(params),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["tongzhi"] }); qc.invalidateQueries({ queryKey: ["pointsNotifications"] }); },
  });
}

export function useShaidanNum(pid: number) {
  return useQuery({
    queryKey: ["shaidanNum", pid],
    queryFn: () => getShaidanNum(pid),
    enabled: pid > 0,
  });
}

export function useDetailHqjlUnique(hid: number, page = 1) {
  return useQuery({
    queryKey: ["detailHqjlUnique", hid, page],
    queryFn: () => getDetailHqjlUnique(hid, page),
    enabled: hid > 0,
  });
}

export function useCartAddAll() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (params: { pids: number[]; cartNum?: number }) => cartAddAll(params.pids, params.cartNum),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["pointsCart"] }),
  });
}

export function useCollectAll() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (ids: number[]) => collectAll(ids),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["pointsCollection"] }),
  });
}

export function useCollectAddAll() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (ids: number[]) => collectAddAll(ids),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["pointsCollection"] }); qc.invalidateQueries({ queryKey: ["pointsCart"] }); },
  });
}

export function useCollectAllDel() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (ids: number[]) => collectAllDel(ids),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["pointsCollection"] }),
  });
}

export function usePointsTasks(enabled = true) {
  return useQuery({ queryKey: ["pointsTasks"], queryFn: getPointsTasks, enabled });
}

export function useClaimPointsTask() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: (taskId: number) => claimPointsTask({ task_id: taskId }),
    onSuccess: (res: unknown) => {
      qc.invalidateQueries({ queryKey: ["pointsTasks"] });
      qc.invalidateQueries({ queryKey: ["pointsBalance"] });
      const payload = unwrapApiData<Record<string, unknown>>(res, {});
      const lucky = Number(payload.lucky ?? 0);
      showToast(lucky > 0 ? `+${lucky}` : i18n.t("pointsTasks.claim"), "success");
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useTrackPointsTaskEvent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (params: { event: string; ref?: string }) => trackPointsTaskEvent(params),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["pointsTasks"] });
    },
  });
}
