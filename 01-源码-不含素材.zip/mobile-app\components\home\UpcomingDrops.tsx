
// components/home/UpcomingDrops.tsx
// 即将上新深色背景

import React from 'react';
import { View, Text, Pressable, ImageBackground, TextInput } from 'react-native';
import { Clock, Bell, MessageCircle } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import TealSurface from '@/components/ui/TealSurface';

interface UpcomingDrop {
  id: number;
  title: string;
  category: string;
  description: string;
  image: string;
  countdown: string;
  launchDate: string;
  startingPrice: string;
}

export default function UpcomingDrops() {
  const upcomingDrops: UpcomingDrop[] = [
    {
      id: 1,
      title: 'Summer Collection 2026',
      category: 'Fashion',
      description: 'Vibrant colors and breathable fabrics perfect for the summer season',
      image: 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=800&q=80',
      countdown: 'Drops in 3 days',
      launchDate: 'June 15, 2026',
      startingPrice: '$29',
    },
    {
      id: 2,
      title: 'Smart Home Bundle',
      category: 'Electronics',
      description: 'Complete home automation system with voice control and app integration',
      image: 'https://images.unsplash.com/photo-1558002038-1055907df827?w=800&q=80',
      countdown: 'Drops in 5 days',
      launchDate: 'June 17, 2026',
      startingPrice: '$199',
    },
    {
      id: 3,
      title: 'Limited Edition Sneakers',
      category: 'Footwear',
      description: 'Exclusive collaboration with renowned designer. Only 500 pairs available',
      image: 'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=800&q=80',
      countdown: 'Drops in 1 week',
      launchDate: 'June 19, 2026',
      startingPrice: '$149',
    },
  ];

  return (
    <LinearGradient
      colors={['#1A1A1A', '#2D2D2D']}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      className="py-16 px-6 rounded-3xl mx-6"
    >
      {/* 标题区域 */}
      <View className="items-center mb-12">
        <Text className="text-4xl font-bold text-white mb-2">
          🔥 Upcoming Drops
        </Text>
        <Text className="text-lg text-white/80">
          Be the first to get exclusive new arrivals
        </Text>
      </View>
      
      {/* 新品网格 - 3列 */}
      <View className="flex-row flex-wrap gap-6 mb-16">
        {upcomingDrops.map((drop) => (
          <Pressable
            key={drop.id}
            className="rounded-2xl overflow-hidden active:scale-95"
            style={{ width: '31%', height: 480 }}
          >
            <ImageBackground
              source={{ uri: drop.image }}
              className="w-full h-full"
              resizeMode="cover"
            >
              {/* 渐变遮罩 */}
              <LinearGradient
                colors={['rgba(0,0,0,0.3)', 'rgba(0,0,0,0.8)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                className="flex-1 p-6 justify-between"
              >
                {/* 倒计时标签 */}
                <View className="bg-brand-red px-4 py-2 rounded-lg flex-row items-center gap-2 self-start">
                  <Clock size={16} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
                  <Text className="text-white text-sm font-bold">{drop.countdown}</Text>
                </View>
                
                {/* 商品信息 */}
                <View>
                  <View className="bg-white/20 px-3 py-1 rounded-md self-start mb-3">
                    <Text className="text-white text-xs font-bold uppercase tracking-wide">
                      {drop.category}
                    </Text>
                  </View>
                  
                  <Text className="text-white text-2xl font-bold mb-3">
                    {drop.title}
                  </Text>
                  
                  <Text className="text-white/90 text-sm leading-5 mb-5">
                    {drop.description}
                  </Text>
                  
                  {/* 详细信息 */}
                  <View className="flex-row gap-6 mb-5 pb-5 border-b border-white/20">
                    <View>
                      <Text className="text-white/70 text-xs uppercase tracking-wide mb-1">
                        Launching
                      </Text>
                      <Text className="text-white text-base font-bold">
                        {drop.launchDate}
                      </Text>
                    </View>
                    <View>
                      <Text className="text-white/70 text-xs uppercase tracking-wide mb-1">
                        Starting at
                      </Text>
                      <Text className="text-white text-base font-bold">
                        {drop.startingPrice}
                      </Text>
                    </View>
                  </View>
                  
                  {/* 通知按钮 */}
                  <Pressable className="bg-white h-12 rounded-lg flex-row items-center justify-center gap-2 active:bg-brand-red">
                    <Bell size={18} color="#333333" />
                    <Text className="text-gray-700 text-base font-bold">Notify Me</Text>
                  </Pressable>
                </View>
              </LinearGradient>
            </ImageBackground>
          </Pressable>
        ))}
      </View>
      
      {/* 订阅区域 */}
      <View className="bg-white/5 border border-white/10 rounded-2xl p-12 items-center">
        {/* 图标 */}
        <View className="w-16 h-16 bg-brand-red rounded-full items-center justify-center mb-6">
          <MessageCircle size={32} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
        </View>
        
        <Text className="text-white text-3xl font-bold mb-3">
          Never Miss a Drop
        </Text>
        <Text className="text-white/80 text-base text-center mb-8 max-w-xl">
          Subscribe to get notified about new product launches and exclusive deals
        </Text>
        
        {/* 订阅表单 */}
        <View className="flex-row gap-4 w-full max-w-lg">
          <TextInput
            className="flex-1 h-14 px-6 bg-white/10 border border-white/20 rounded-xl text-white text-base"
            placeholder="Enter your email address"
            placeholderTextColor="rgba(255,255,255,0.5)"
            keyboardType="email-address"
          />
          <Pressable className="h-14 px-10" style={({ pressed }) => ({ transform: [{ scale: pressed ? 0.97 : 1 }] })}>
          <TealSurface direction="tb" radius={12} style={{ height: 56 }} contentStyle={{ alignItems: "center", justifyContent: "center" }}>
            <Text className="text-white text-base font-bold">Subscribe</Text>
          </TealSurface>
        </Pressable>
        </View>
      </View>
    </LinearGradient>
  );
}
