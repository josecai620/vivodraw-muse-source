import PageHeader from "@/components/shared/PageHeader";
import { API_ENDPOINTS } from "@/constants/api";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import { unwrapApiRecord } from "@/lib/api/response";
import { getExtractBank, submitPaypalExtract } from "@/lib/api/wallet";
import { http } from "@/lib/http";
import { useAuthStore } from "@/store/auth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type AgentInfo = {
  is_agent?: number;
  is_promoter?: number;
  withdrawable?: number | string;
  pending_cooldown?: number | string;
  [key: string]: unknown;
};

type ExtractBankData = {
  minPrice?: number | string;
  extract_min_price?: number | string;
  [key: string]: unknown;
};

export default function WithdrawScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const queryClient = useQueryClient();
  const user = useAuthStore((s) => s.user);

  const [money, setMoney] = useState("");
  const [paypalEmail, setPaypalEmail] = useState("");
  const [name, setName] = useState("");

  const { data, isLoading } = useQuery({
    queryKey: ["extractBank"],
    queryFn: getExtractBank,
  });
  const { data: agentData } = useQuery({
    queryKey: ["agentInfo"],
    queryFn: () => http.get(API_ENDPOINTS.commission.agentInfo),
  });

  const agentRaw = unwrapApiRecord<AgentInfo>(agentData, {});
  const available = Number(agentRaw?.withdrawable ?? 0);
  const pending = Number(agentRaw?.pending_cooldown ?? 0);
  const balance = available;

  const extractMutation = useMutation({
    mutationFn: submitPaypalExtract,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user"] });
      Alert.alert(t("common.success"), t("commission.withdraw.submitted"), [
        { text: "OK", onPress: () => router.back() },
      ]);
    },
    onError: (err: unknown) => {
      const message = err instanceof Error ? err.message : t("common.failed");
      Alert.alert(t("common.failed"), message);
    },
  });

  const raw = unwrapApiRecord<ExtractBankData>(data, {});
  const minPrice = Number(raw?.minPrice ?? raw?.extract_min_price ?? 0);

  const handleSubmit = () => {
    const amt = Number(money);
    if (!amt || amt <= 0) {
      Alert.alert(t("common.notice"), t("commission.withdraw.enterAmount"));
      return;
    }
    if (amt > balance) {
      const msg =
        pending > 0
          ? t("commission.withdraw.cooldownBanner", {
              available: available.toFixed(2),
              pending: pending.toFixed(2),
            })
          : t("commission.withdraw.insufficient");
      Alert.alert(t("common.notice"), msg);
      return;
    }
    if (minPrice > 0 && amt < minPrice) {
      Alert.alert(t("common.notice"), t("commission.withdraw.minNote", { amount: minPrice }));
      return;
    }
    const email = paypalEmail.trim();
    if (!email) {
      Alert.alert(t("common.notice"), t("commission.withdraw.enterEmail"));
      return;
    }
    if (!EMAIL_RE.test(email)) {
      Alert.alert(t("common.notice"), t("commission.withdraw.invalidEmail"));
      return;
    }
    extractMutation.mutate({
      money: amt,
      paypal_email: email,
      name: name.trim() || undefined,
    });
  };

  const inputStyle = {
    padding: s(14),
    borderRadius: s(12),
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    color: Colors.neutral[800],
    fontSize: s(14),
  } as const;

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("commission.withdraw.title")} />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView
          className="flex-1"
          contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
          showsVerticalScrollIndicator={false}
        >
          <View className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
            <View className="flex-row justify-between">
              <View className="flex-1">
                <Text className="text-sm mb-1" style={{ color: Colors.neutral[500] }}>
                  {t("commission.balance.available")}
                </Text>
                <Text className="text-2xl font-bold" style={{ color: Colors.brand.red }}>
                  ${available.toFixed(2)}
                </Text>
              </View>
              {pending > 0 && (
                <View className="items-end flex-1">
                  <Text className="text-sm mb-1" style={{ color: Colors.neutral[500] }}>
                    {t("commission.balance.pending")}
                  </Text>
                  <Text className="text-2xl font-bold" style={{ color: Colors.accent.orange }}>
                    ${pending.toFixed(2)}
                  </Text>
                </View>
              )}
            </View>
            {pending > 0 && (
              <Text className="text-xs mt-2" style={{ color: Colors.neutral[500] }}>
                {t("commission.withdraw.cooldownDetail")}
              </Text>
            )}
            {minPrice > 0 && (
              <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }}>
                {t("commission.withdraw.minNote", { amount: minPrice })}
              </Text>
            )}
          </View>

          <View className="mb-4">
            <Text className="font-semibold mb-2" style={{ color: Colors.neutral[800] }}>
              {t("commission.withdraw.method")}
            </Text>
            <View
              style={{
                paddingVertical: s(14),
                paddingHorizontal: s(16),
                borderRadius: s(12),
                backgroundColor: `${Colors.brand.red}10`,
                borderWidth: 1,
                borderColor: Colors.brand.red,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Text className="font-semibold" style={{ color: Colors.brand.red, fontSize: s(15) }}>
                PayPal
              </Text>
              <View
                style={{
                  paddingVertical: s(2),
                  paddingHorizontal: s(8),
                  borderRadius: s(8),
                  }}
              >
                <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 8, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 8 }} />
                <Text className="text-white text-xs font-semibold">USD</Text>
              </View>
            </View>
          </View>

          <View className="mb-4">
            <Text className="font-semibold mb-2" style={{ color: Colors.neutral[800] }}>
              {t("commission.withdraw.amount")} *
            </Text>
            <TextInput
              value={money}
              onChangeText={(t) => setMoney(t.replace(/[^0-9.]/g, ""))}
              placeholder={t("commission.withdraw.amountPlaceholder")}
              placeholderTextColor={Colors.neutral[400]}
              keyboardType="decimal-pad"
              style={{ ...inputStyle, fontSize: s(16) }}
            />
          </View>

          <View className="mb-4">
            <Text className="font-semibold mb-2" style={{ color: Colors.neutral[800] }}>
              {t("commission.withdraw.paypalEmail")} *
            </Text>
            <TextInput
              value={paypalEmail}
              onChangeText={setPaypalEmail}
              placeholder={t("commission.withdraw.paypalEmailPlaceholder")}
              placeholderTextColor={Colors.neutral[400]}
              keyboardType="email-address"
              autoCapitalize="none"
              autoCorrect={false}
              style={inputStyle}
            />
          </View>

          <View className="mb-4">
            <Text className="font-semibold mb-2" style={{ color: Colors.neutral[800] }}>
              {t("commission.withdraw.realName")}
            </Text>
            <TextInput
              value={name}
              onChangeText={setName}
              placeholder={t("commission.withdraw.realNamePlaceholder")}
              placeholderTextColor={Colors.neutral[400]}
              style={inputStyle}
            />
          </View>

          <Text className="text-xs mb-4 text-center" style={{ color: Colors.neutral[500] }}>
            {t("commission.withdraw.reviewNote")}
          </Text>

          <Pressable
            onPress={handleSubmit}
            disabled={extractMutation.isPending}
            style={{
              paddingVertical: s(14),
              borderRadius: s(12),
              alignItems: "center",
            }}
          >
            <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
            <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
            {extractMutation.isPending ? (
              <ActivityIndicator color="#FFF" />
            ) : (
              <Text className="font-semibold" style={{ color: "#FFF", fontSize: s(16) }}>
                {t("commission.withdraw.submit")}
              </Text>
            )}
          </Pressable>
        </ScrollView>
      )}
    </View>
  );
}
