import React from "react";
import { ActivityIndicator, Image, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";
import { normalizeImageUrl, formatPrice } from "@/lib/utils";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

export default function BargainScreen() {
  const router = useRouter();
  const { data, isLoading } = useQuery({
    queryKey: ["bargainList"],
    queryFn: () => http.get(API_ENDPOINTS.bargain.list),
  });

  const raw = (data as any)?.data ?? data;
  const list = raw?.list ?? raw ?? [];

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Bargain" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : list.length === 0 ? (
        <View className="flex-1 items-center justify-center px-6">
          <Text style={{ color: Colors.neutral[500] }}>No bargain at the moment</Text>
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }} showsVerticalScrollIndicator={false}>
          {list.map((item: any, i: number) => (
            <Pressable
              key={item.id ?? i}
              onPress={() => router.push(`/marketing/bargain/${item.id}`)}
              className="bg-white rounded-2xl flex-row p-4 mb-3 border border-gray-100"
            >
              <Image source={{ uri: normalizeImageUrl(item.image ?? item.pic) }} style={{ width: s(88), height: s(88), borderRadius: s(12), backgroundColor: Colors.neutral[100] }} resizeMode="cover" />
              <View className="flex-1 ml-3 justify-center">
                <Text className="font-semibold" style={{ color: Colors.neutral[800] }} numberOfLines={2}>{item.store_name ?? item.title}</Text>
                <View className="flex-row items-center mt-2">
                  <Text className="font-bold" style={{ color: Colors.brand.red }}>{formatPrice(item.min_price ?? item.bargain_price)}</Text>
                  <Text className="text-xs ml-2 line-through" style={{ color: Colors.neutral[400] }}>{formatPrice(item.price ?? item.ot_price)}</Text>
                </View>
              </View>
            </Pressable>
          ))}
        </ScrollView>
      )}
    </View>
  );
}
