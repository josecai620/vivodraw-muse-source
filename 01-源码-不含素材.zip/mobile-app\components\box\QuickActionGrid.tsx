import React from "react";
import { View, Text, Pressable, ScrollView, type ViewStyle } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import {
  BoxAccent, BoxText, BoxSurfaces, BoxBorders,
  BoxTypography, BoxSpacing, BoxLayout, bs,
} from "@/lib/boxTheme";

interface QuickAction {
  key: string;
  label: string;
  icon: React.ReactNode;
  color?: string;
  bgColor?: string;
  onPress: () => void;
}

interface QuickActionGridProps {
  actions: QuickAction[];
  style?: ViewStyle;
}

export function QuickActionGrid({ actions, style }: QuickActionGridProps) {
  return (
    <View style={[{
      backgroundColor: BoxSurfaces.card,
      borderBottomWidth: 1,
      borderBottomColor: BoxBorders.subtle,
      paddingVertical: BoxSpacing.md,
    }, style]}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: BoxSpacing.lg, gap: BoxSpacing.lg }}
      >
        {actions.map((action) => (
          <Pressable
            key={action.key}
            onPress={action.onPress}
            style={({ pressed }) => ({
              alignItems: "center",
              gap: BoxSpacing.sm,
              transform: [{ scale: pressed ? 0.92 : 1 }],
            })}
          >
            <View style={{
              width: BoxLayout.quickActionSize,
              height: BoxLayout.quickActionSize,
              borderRadius: BoxLayout.quickActionSize / 2,
              backgroundColor: action.bgColor || BoxAccent.goldDim,
              borderWidth: 1,
              borderColor: action.color ? `${action.color}40` : BoxAccent.goldBorder,
              alignItems: "center",
              justifyContent: "center",
            }}>
              {action.icon}
            </View>
            <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
              {action.label}
            </Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}
