import React from "react";
import Svg, { Circle, Path, Rect } from "react-native-svg";

type TabLineIconProps = {
  size?: number;
  color?: string;
  strokeWidth?: number;
};

function stroke(color: string, strokeWidth: number) {
  return {
    fill: "none" as const,
    stroke: color,
    strokeWidth,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
}

/** 首页：双提手购物袋 */
export function TabBagIcon({
  size = 22,
  color = "#5E5F5E",
  strokeWidth = 1.65,
}: TabLineIconProps) {
  const s = stroke(color, strokeWidth);
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24">
      <Path
        {...s}
        d="M5.4 8.55h13.2l-1.08 11c-.14.85-.86 1.45-1.72 1.45H8.2c-.86 0-1.58-.6-1.72-1.45L5.4 8.55z"
      />
      <Path {...s} d="M8.55 8.55V6.2a1.65 1.65 0 0 1 3.3 0V8.55" />
      <Path {...s} d="M12.15 8.55V6.2a1.65 1.65 0 0 1 3.3 0V8.55" />
    </Svg>
  );
}

/** 分类：空心五角星 + 百分号 */
export function TabDealIcon({
  size = 22,
  color = "#5E5F5E",
  strokeWidth = 1.65,
}: TabLineIconProps) {
  const s = stroke(color, strokeWidth);
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24">
      <Path
        {...s}
        d="M8.2 4.7 9.62 8.55l4.05.16-3.18 2.5 1.1 3.88L8.2 12.8l-3.39 2.29 1.1-3.88-3.18-2.5 4.05-.16Z"
      />
      <Circle {...s} cx="16.55" cy="7.05" r="1.7" />
      <Path {...s} d="M19.15 6.7 14.85 16.7" />
      <Circle {...s} cx="17.85" cy="16.45" r="1.7" />
    </Svg>
  );
}

/** 购物车：宝箱 */
export function TabChestIcon({
  size = 22,
  color = "#5E5F5E",
  strokeWidth = 1.65,
}: TabLineIconProps) {
  const s = stroke(color, strokeWidth);
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24">
      <Path
        {...s}
        d="M5.6 10.35V7.2c0-1.15.9-2.05 2.05-2.05h8.7c1.15 0 2.05.9 2.05 2.05v3.15"
      />
      <Path
        {...s}
        d="M4.95 10.35h14.1v8.15c0 1.15-.95 2.1-2.1 2.1H7.05c-1.15 0-2.1-.95-2.1-2.1V10.35z"
      />
      <Path {...s} d="M4.95 10.35h14.1" />
      <Rect {...s} x="11.05" y="6.15" width="1.9" height="2.85" rx="0.9" />
      <Path {...s} d="M11.25 15.55v-.95a.85.85 0 0 1 1.7 0v.95" />
      <Rect {...s} x="10.75" y="15.55" width="2.7" height="2.15" rx="0.4" />
    </Svg>
  );
}

function PersonGlyph({
  cx,
  color,
  strokeWidth,
}: {
  cx: number;
  color: string;
  strokeWidth: number;
}) {
  const s = stroke(color, strokeWidth);
  const left = cx - 2.05;
  const hip = cx - 0.85;
  const hipR = cx + 0.85;
  return (
    <>
      <Circle {...s} cx={cx} cy={5.7} r={2.15} />
      <Path
        {...s}
        d={`M${left} 10.15h4.1v4.35H${hipR}V20.9h-1.7v-6.4H${left}z`}
      />
    </>
  );
}

/** 我的：三个人站立 */
export function TabPeopleIcon({
  size = 22,
  color = "#5E5F5E",
  strokeWidth = 1.65,
}: TabLineIconProps) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24">
      <PersonGlyph cx={6.1} color={color} strokeWidth={strokeWidth} />
      <PersonGlyph cx={12} color={color} strokeWidth={strokeWidth} />
      <PersonGlyph cx={17.9} color={color} strokeWidth={strokeWidth} />
    </Svg>
  );
}
