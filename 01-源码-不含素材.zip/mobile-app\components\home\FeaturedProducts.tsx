
// components/home/FeaturedProducts.tsx
// 精选商品网格

import React from 'react';
import { View, Text, Pressable, Image } from 'react-native';
import { ArrowRight, Star, Heart, Eye, ShoppingCart } from 'lucide-react-native';
import TealSurface from '@/components/ui/TealSurface';

interface Product {
  id: number;
  name: string;
  category: string;
  description: string;
  image: string;
  currentPrice: string;
  originalPrice?: string;
  rating: string;
  reviews: string;
  badge?: string;
  badgeType?: 'bestseller' | 'new' | 'discount';
}

export default function FeaturedProducts() {
  const products: Product[] = [
    {
      id: 1,
      name: 'Luxury Designer Watch',
      category: 'Accessories',
      description: 'Timeless elegance for every occasion',
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&q=80',
      currentPrice: '$249',
      rating: '4.9',
      reviews: '856',
      badge: 'Bestseller',
      badgeType: 'bestseller',
    },
    {
      id: 2,
      name: 'Modern Laptop Stand',
      category: 'Office',
      description: 'Ergonomic design for better posture',
      image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400&q=80',
      currentPrice: '$79',
      originalPrice: '$129',
      rating: '4.7',
      reviews: '423',
      badge: '-39%',
      badgeType: 'discount',
    },
    {
      id: 3,
      name: 'Premium Leather Bag',
      category: 'Fashion',
      description: 'Handcrafted from finest Italian leather',
      image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=400&q=80',
      currentPrice: '$189',
      rating: '4.8',
      reviews: '612',
      badge: 'New',
      badgeType: 'new',
    },
    {
      id: 4,
      name: 'Smart Home Speaker',
      category: 'Electronics',
      description: 'Voice-controlled assistant with premium sound',
      image: 'https://images.unsplash.com/photo-1543512214-318c7553f230?w=400&q=80',
      currentPrice: '$99',
      originalPrice: '$149',
      rating: '4.6',
      reviews: '1.2k',
      badge: '-34%',
      badgeType: 'discount',
    },
    {
      id: 5,
      name: 'Ceramic Coffee Mug Set',
      category: 'Home & Kitchen',
      description: 'Set of 4 handmade mugs',
      image: 'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=400&q=80',
      currentPrice: '$45',
      rating: '4.9',
      reviews: '289',
      badge: 'Bestseller',
      badgeType: 'bestseller',
    },
    {
      id: 6,
      name: 'Yoga Mat Pro',
      category: 'Sports',
      description: 'Non-slip surface with carrying strap',
      image: 'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400&q=80',
      currentPrice: '$39',
      originalPrice: '$69',
      rating: '4.7',
      reviews: '534',
      badge: '-43%',
      badgeType: 'discount',
    },
  ];

  const getBadgeColor = (type?: string) => {
    switch (type) {
      case 'bestseller':
        return 'bg-teal-500';
      case 'new':
        return 'bg-brand-red';
      case 'discount':
        return 'bg-brand-red';
      default:
        return 'bg-gray-400';
    }
  };

  return (
    <View className="px-6 py-16">
      {/* 标题区域 */}
      <View className="flex-row items-start justify-between mb-10">
        <View>
          <Text className="text-4xl font-bold text-gray-700 mb-2">
            Featured Products
          </Text>
          <Text className="text-lg text-gray-500">
            Hand-picked items just for you
          </Text>
        </View>
        <Pressable className="border-2 border-brand-red h-10 px-6 rounded-lg flex-row items-center gap-2 active:bg-brand-red">
          <Text className="text-brand-red text-base font-bold">View All</Text>
          <ArrowRight size={16} color="#04A8AE" />
        </Pressable>
      </View>
      
      {/* 商品网格 - 2列 */}
      <View className="flex-row flex-wrap gap-8">
        {products.map((product) => (
          <Pressable
            key={product.id}
            className="bg-white rounded-2xl overflow-hidden border border-gray-100 active:scale-95"
            style={{ width: '47%' }}
          >
            {/* 商品图片 */}
            <View className="relative">
              <Image
                source={{ uri: product.image }}
                className="w-full h-72"
                resizeMode="cover"
              />
              
              {/* 标签 */}
              {product.badge && (
                <View className={`absolute top-3 left-3 ${getBadgeColor(product.badgeType)} px-3 py-1.5 rounded-md`}>
                  <Text className="text-white text-xs font-bold uppercase tracking-wide">
                    {product.badge}
                  </Text>
                </View>
              )}
              
              {/* 快速操作按钮 */}
              <View className="absolute top-3 right-3 gap-2">
                <Pressable className="w-10 h-10 bg-white rounded-full items-center justify-center active:bg-brand-red">
                  <Heart size={18} color="#333333" />
                </Pressable>
                <Pressable className="w-10 h-10 bg-white rounded-full items-center justify-center active:bg-brand-red">
                  <Eye size={18} color="#333333" />
                </Pressable>
              </View>
            </View>
            
            {/* 商品信息 */}
            <View className="p-5">
              <Text className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">
                {product.category}
              </Text>
              <Text className="text-lg font-bold text-gray-700 mb-2" numberOfLines={2}>
                {product.name}
              </Text>
              <Text className="text-sm text-gray-500 mb-3" numberOfLines={2}>
                {product.description}
              </Text>
              
              {/* 评分 */}
              <View className="flex-row items-center gap-2 mb-4">
                <View className="flex-row gap-0.5">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} size={14} color="#171A1A" fill="#171A1A" />
                  ))}
                </View>
                <Text className="text-xs font-semibold text-gray-500">
                  {product.rating} ({product.reviews} reviews)
                </Text>
              </View>
              
              {/* 价格和按钮 */}
              <View className="flex-row items-center justify-between pt-4 border-t border-gray-100">
                <View className="flex-row items-baseline gap-2">
                  <Text className="text-2xl font-bold text-brand-red">
                    {product.currentPrice}
                  </Text>
                  {product.originalPrice && (
                    <Text className="text-base text-gray-400 line-through">
                      {product.originalPrice}
                    </Text>
                  )}
                </View>
                <Pressable style={({ pressed }) => ({ transform: [{ scale: pressed ? 0.96 : 1 }] })}>
                  <TealSurface direction="tb" radius={8} style={{ width: 44, height: 44 }} contentStyle={{ alignItems: "center", justifyContent: "center" }}>
                  <ShoppingCart size={20} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
                </TealSurface>
                </Pressable>
              </View>
            </View>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
