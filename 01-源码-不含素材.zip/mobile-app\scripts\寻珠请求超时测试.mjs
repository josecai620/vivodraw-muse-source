import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import { runInNewContext } from 'node:vm';
import ts from 'typescript';

// 真实 API 包装 + 真实 HTTP 层；fetch、token、时间全隔离，不触碰生产账号。
const tick = () => new Promise(resolve => setImmediate(resolve));
function runtime(fetchImpl) {
  let now = 0, seq = 0, nonce = 0;
  const timers = new Map(), calls = [];
  const globals = {
    AbortController, Headers,
    crypto: { randomUUID: () => `read-only-nonce-${++nonce}` },
    setTimeout(callback, delay) { const id = ++seq; timers.set(id, { callback, at: now + delay }); return id; },
    clearTimeout(id) { timers.delete(id); },
    fetch(url, init) {
      assert.ok(url.startsWith('https://pearl-test.invalid/'));
      calls.push({ url, init });
      return fetchImpl(url, init, globals);
    },
  };
  function load(path, dependencies) {
    const module = { exports: {} };
    const code = ts.transpileModule(readFileSync(new URL('../' + path, import.meta.url), 'utf8'), {
      compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
    }).outputText;
    runInNewContext(code, { ...globals, module, exports: module.exports, require(name) {
      assert.ok(Object.hasOwn(dependencies, name), 'Unexpected dependency: ' + name);
      return dependencies[name];
    } });
    return module.exports;
  }
  const http = load('lib/api/legacyHttp.ts', {
    '@/constants/api': { API_BASE_URL: 'https://pearl-test.invalid' },
    '@/store/auth': { useAuthStore: { getState: () => ({ token: 'fake-test-token' }) } },
  });
  const api = load('lib/api/pearl.ts', { '@/lib/api/legacyHttp': http });
  return { api, calls, timers, async advance(ms) {
    const end = now + ms;
    while (true) {
      const next = [...timers].filter(([, timer]) => timer.at <= end).sort((a, b) => a[1].at - b[1].at)[0];
      if (!next) break;
      now = next[1].at; timers.delete(next[0]); next[1].callback(); await tick();
    }
    now = end; await tick();
  } };
}
const success = () => ({ ok: true, status: 200, json: async () => ({ status: 200, data: { accepted: true } }) });

test('10秒成功响应不被8秒伪超时丢弃，不并发重发POST', async () => {
  const env = runtime((url, init, clock) => new Promise(resolve => clock.setTimeout(() => resolve(success()), 10000)));
  const pending = env.api.pickPearlShell('same-round-001', 2, 1);
  await env.advance(8500); assert.equal(env.calls.length, 1);
  await env.advance(1500); assert.equal((await pending).ok, true);
  assert.equal(env.calls.length, 1); assert.equal(env.timers.size, 0);
});

test('挂起请求15秒实际abort，返回失败，原请求标识不变', async () => {
  let aborted = false;
  const env = runtime((url, init) => new Promise((resolve, reject) => {
    init.signal.addEventListener('abort', () => { aborted = true; reject(new Error('aborted')); });
  }));
  const pending = env.api.pickPearlShell('same-round-002', 4, 1);
  await env.advance(15000);
  assert.equal((await pending).ok, false); assert.equal(aborted, true);
  assert.equal(env.calls.length, 1); assert.equal(env.timers.size, 0);
  assert.deepEqual(JSON.parse(env.calls[0].init.body), { requestId: 'same-round-002', selectedShell: 4, selectionStep: 1 });
});

test('登录失效401、业务拒绝和网络断开均不叠加自动重试', async () => {
  for (const payload of [{ status: 410000 }, { status: 400 }]) {
    const env = runtime(async () => ({ ok: true, status: 200, json: async () => payload }));
    const response = await env.api.getPearlState();
    assert.equal(response.ok, false); assert.equal(response.status, payload.status);
    assert.equal(env.calls.length, 1); assert.equal(env.timers.size, 0);
  }
  const env = runtime(async () => { throw new Error('offline'); });
  assert.equal((await env.api.startPearlRound('same-round-003', 0)).ok, false);
  assert.equal(env.calls.length, 1); assert.equal(env.timers.size, 0);
});

test('响应头已到但JSON挂起也能abort', async () => {
  const env = runtime(async (url, init) => ({ ok: true, status: 200, json: () => new Promise((resolve, reject) => {
    init.signal.addEventListener('abort', () => reject(new Error('body aborted')));
  }) }));
  const pending = env.api.getPearlState();
  await tick(); await env.advance(15000);
  assert.equal((await pending).ok, false); assert.equal(env.calls.length, 1);
});

test('权威state核对使用每次独有nonce，仅GET一次且普通读取不变', async () => {
  const env = runtime(async () => success());
  await env.api.getPearlState();
  await env.api.getPearlState(true);
  await env.api.getPearlState(true);
  assert.equal(env.calls.length, 3);
  const urls = env.calls.map((call) => new URL(call.url));
  assert.equal(urls[0].pathname, '/api/pearl/state');
  assert.equal(urls[0].search, '');
  assert.ok(urls[1].searchParams.get('_fresh'));
  assert.notEqual(urls[1].searchParams.get('_fresh'), urls[2].searchParams.get('_fresh'));
  assert.ok(env.calls.every((call) => call.init.method === 'GET' && call.init.body === undefined));
  assert.equal(env.timers.size, 0);
});
