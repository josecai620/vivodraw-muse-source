import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

export interface BannerItem {
  id?: number;
  img?: string;
  image?: string;
  pic?: string;
  url?: string;
  title?: string;
}

export interface MenuItem {
  id?: number;
  name?: string;
  title?: string;
  icon?: string;
  image?: string;
  url?: string;
}

export interface IndexData {
  banner: BannerItem[];
  menus: MenuItem[];
  roll: unknown[];
  activity: unknown[];
  info: { fastList: unknown[]; firstList: unknown[] };
  lovely: unknown[];
  benefit: unknown[];
  likeInfo: unknown[];
  couponList: unknown[];
}

// ---------- 自研首页装修（不依赖 CRMEB DIY）----------

export type HomeLayoutBlockType =
  | "banner"
  | "quick_grid"
  | "notice"
  | "group_lottery"
  | "points_balance"
  | "category_nav"
  | "product_list"
  | "single_image"
  | "rich_text"
  | "spacer"
  | "checkin_card"
  | "box_reveal"
  | "countdown"
  | "live_entry";

export interface HomeLayoutBlock {
  id: string;
  type: HomeLayoutBlockType;
  visible?: boolean;
  props: Record<string, any>;
}

export interface HomeLayoutData {
  id: number;
  name: string;
  status: number;
  blocks: HomeLayoutBlock[];
  theme: {
    bg_color?: string;
    bg_image?: string;
    header_text_color?: string;
  };
  update_time?: number;
}

export function getHomeLayout() {
  return http.get<HomeLayoutData>(`/api/home_layout`);
}

export function getHomeIndex() {
  return http.get<IndexData>(API_ENDPOINTS.home.index);
}

export function getGroomList(type: number, params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.home.groom(type), { params });
}
