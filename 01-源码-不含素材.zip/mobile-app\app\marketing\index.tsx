import React from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { Video, Zap, Users, Scissors, Calendar, Gift } from "lucide-react-native";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

const PROMOS = [
  { id: "seckill", label: "Flash Sale", desc: "Limited time discounts", Icon: Zap, route: "/marketing/seckill", color: "#04A8AE" },
  { id: "combination", label: "Group Buy", desc: "Buy together, save more", Icon: Users, route: "/marketing/combination", color: "#04A8AE" },
  { id: "bargain", label: "Bargain", desc: "Get friends to help cut price", Icon: Scissors, route: "/marketing/bargain", color: "#04A8AE" },
  { id: "live", label: "Live", desc: "Live streaming & replays", Icon: Video, route: "/marketing/live", color: "#04A8AE" },
  { id: "presale", label: "Presale", desc: "Pre-order products", Icon: Calendar, route: "/marketing/presale", color: "#04A8AE" },
  { id: "groupLottery", label: "Group Lottery", desc: "Win products in a group draw; losers get +5% bonus refund", Icon: Gift, route: "/group-lottery", color: "#04A8AE" },
];

export default function MarketingScreen() {
  const router = useRouter();
  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Promotions" />
      <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16) }} showsVerticalScrollIndicator={false}>
        {PROMOS.map((p) => {
          const Icon = p.Icon;
          return (
          <Pressable
            key={p.id}
            onPress={() => router.push(p.route as any)}
            className="bg-white rounded-2xl p-4 mb-3 flex-row items-center border border-gray-100"
          >
            <View className="w-12 h-12 rounded-xl items-center justify-center mr-3" style={{ backgroundColor: `${p.color}20` }}>
              <Icon size={s(24)} color={p.color} />
            </View>
            <View className="flex-1">
              <Text className="font-semibold" style={{ color: Colors.neutral[800] }}>{p.label}</Text>
              <Text className="text-sm mt-0.5" style={{ color: Colors.neutral[500] }}>{p.desc}</Text>
            </View>
            <Text className="text-sm font-medium" style={{ color: p.color }}>Go</Text>
          </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}
