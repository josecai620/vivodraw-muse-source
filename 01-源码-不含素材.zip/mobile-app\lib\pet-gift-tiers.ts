import type { PixelDeskPetId } from "@/lib/pets";

export type PetGiftTier = {
  tier: 1 | 2 | 3;
  min: number;
  commonMax: number;
  max: number;
};

const TIER_1: PetGiftTier = { tier: 1, min: 10, commonMax: 36, max: 60 };
const TIER_2: PetGiftTier = { tier: 2, min: 15, commonMax: 45, max: 75 };
const TIER_3: PetGiftTier = { tier: 3, min: 20, commonMax: 60, max: 100 };

export const petGiftTiers: Record<PixelDeskPetId, PetGiftTier> = {
  cat_programmer: TIER_1,
  octopus_wizard: TIER_2,
  shiba_bone: TIER_2,
  penguin_sign: TIER_2,
  axolotl_writer: TIER_2,
  gray_yarn_cat: TIER_2,
  blue_sprout_slime: TIER_2,
  nibble_mouse: TIER_2,
  dino_sipper: TIER_3,
  raccoon_reader: TIER_3,
  honglang: TIER_3,
  "jj-duck": TIER_3,
  bitboy: TIER_3,
  wukong: TIER_3,
};

export function getPetGiftTier(petId: PixelDeskPetId): PetGiftTier {
  return petGiftTiers[petId] ?? TIER_1;
}

export function formatPetGiftRange(petId: PixelDeskPetId): string {
  const tier = getPetGiftTier(petId);
  return `${tier.min}-${tier.max}`;
}
