/**
 * API 配置常量
 * 对接 CRMEB 后端接口
 * API_BASE_URL 现统一由 constants/env.ts 导出，这里重新导出保持向后兼容。
 * 可通过 .env 的 EXPO_PUBLIC_API_BASE_URL 或 app.json extra.ApiBaseUrl 覆盖。
 */
export { API_BASE_URL } from "./env";

export const API_TIMEOUT = 15_000;

export const API_ENDPOINTS = {
  // 首页
  home: {
    diy: "/api/diy",
    banner: "/api/diy/get_diy/0",
    index: "/api/index",
    groom: (type: number) => `/api/groom/list/${type}`,
  },

  // 搜索
  search: {
    keyword: "/api/search/keyword",
    products: "/api/products",
  },

  // 商品
  product: {
    list: "/api/products",
    detail: (id: number) => `/api/product/detail/${id}`,
    hot: "/api/product/hot",
    category: "/api/category",
    search: "/api/products",
  },

  // 购物车
  cart: {
    list: "/api/cart/list",
    add: "/api/cart/add",
    delete: "/api/cart/del",
    update: "/api/cart/num",
    count: "/api/cart/count",
  },

  // 订单（流程：confirm → 取 orderKey → computed/:key → create/:key）
  order: {
    confirm: "/api/order/confirm",
    computed: (key: string) => `/api/order/computed/${key}`,
    create: (key: string) => `/api/order/create/${key}`,
    list: "/api/order/list",
    detail: (uni: string) => `/api/order/detail/${uni}`,
    cancel: "/api/order/cancel",
    take: "/api/order/take",
    again: "/api/order/again",
    comment: "/api/order/comment",
    express: (uni: string) => `/api/order/express/${uni}`,
    refund: {
      reason: "/api/order/refund/reason",
      cartInfo: (id: number) => `/api/order/refund/cart_info/${id}`,
      apply: (id: number) => `/api/order/refund/apply/${id}`,
      list: "/api/order/refund/list",
      detail: (uni: string) => `/api/order/refund/detail/${uni}`,
    },
  },

  // 钱包（充值/提现）
  wallet: {
    recharge: {
      index: "/api/recharge/index",
      submit: "/api/recharge/recharge",
    },
    extract: {
      bank: "/api/extract/bank",
      cash: "/api/extract/cash",
    },
  },

  // 用户
  user: {
    login: "/api/login",
    register: "/api/register",
    profile: "/api/user",
    petDialogue: "/api/user/pet-world/dialogue",
    logout: "/api/logout",
    /** 获取验证码 key（发送短信前必调） */
    verifyCodeKey: "/api/verify_code",
    sendCode: "/api/register/verify",
    /** 邮箱注册验证码 */
    emailVerifyCode: "/api/email/verify_code",
    emailVerify: "/api/email/verify",
    /** 找回密码：account + captcha + password */
    reset: "/api/register/reset",
    /** 登录图形验证码（失败 3 次后需要） */
    loginCaptcha: "/api/login_captcha",
    changePassword: "/api/user/change_password",
    /** 注销账号（需登录，body: { confirm: "DELETE" }） */
    cancelAccount: "/api/cancel/user",
    edit: "/api/user/edit",
    edits: "/api/user/edits",
    avatarFrame: "/api/user/avatar_frame",
    uploadImage: "/api/upload/image",
    level: {
      grade: "/api/user/level/grade",
      info: "/api/user/level/info",
      expList: "/api/user/level/expList",
    },
    memberCard: {
      index: "/api/user/member/card/index",
      draw: "/api/user/member/card/draw",
      create: "/api/user/member/card/create",
      coupons: "/api/user/member/coupons/list",
      overdueTime: "/api/user/member/overdue/time",
    },
    messageSystem: {
      list: "/api/user/message_system/list",
      detail: (id: number) => `/api/user/message_system/detail/${id}`,
    },
    service: {
      list: "/api/user/service/list",
      record: "/api/user/service/record",
      send: "/api/user/service/send",
      feedback: "/api/user/service/feedback",
      getFeedbackInfo: "/api/user/service/feedback",
      getFeedbackType: "/api/user/service/getFeedbackType",
    },
    visitList: "/api/user/visit_list",
    visitDelete: "/api/user/visit",
    rank: "/api/rank",
    brokerageRank: "/api/brokerage_rank",
  },

  // 用户协议（type: user_agreement | privacy_agreement）
  userAgreement: (type: string) => `/api/user_agreement/${type}`,

  // 发票（v2）
  invoice: {
    list: "/api/v2/invoice",
    detail: (id: number) => `/api/v2/invoice/detail/${id}`,
    save: "/api/v2/invoice/save",
    makeUp: "/api/v2/order/make_up_invoice",
    orderList: "/api/v2/order/invoice_list",
    setDefault: (id: number) => `/api/v2/invoice/set_default/${id}`,
    del: (id: number) => `/api/v2/invoice/del/${id}`,
  },

  // 文章/资讯
  article: {
    categoryList: "/api/article/category/list",
    list: (cid: number) => `/api/article/list/${cid}`,
    details: (id: number) => `/api/article/details/${id}`,
    hot: "/api/article/hot/list",
    new: "/api/article/new/list",
  },

  // 积分
  points: {
    balance: "/api/user",
    log: "/api/integral/user_integral_lists",
    luckyShop: "/api/integral/lucky_shop",
    luckyRedeem: "/api/integral/lucky_redeem",
    products: "/api/store_integral/list",
    productDetail: (id: number) => `/api/integral/detail/${id}`,
    index: "/api/store_integral/index",
    category: "/api/integral/category",
    categoryProducts: "/api/integral/lists",
    orderList: "/api/integral/order/list",
    orderDetail: (id: string) => `/api/integral/order/detail/${id}`,
    orderExpress: (id: string) => `/api/integral/order/express/${id}`,
    orderConfirm: "/api/integral/order/confirm",
    orderCreate: "/api/integral/order/create",
    orderTake: "/api/integral/order/take",
    orderCancel: "/api/integral/order/cancel",
    orderDel: "/api/integral/order/del",
    exchange: "/api/integral/order/exchange",
    cart: {
      list: "/api/integral/cart/list",
      add: "/api/integral/cart/add",
      del: "/api/integral/cart/del",
      num: "/api/integral/cart/num",
      count: "/api/integral/cart/count",
    },
    collect: {
      list: "/api/integral/collect/user",
      add: "/api/integral/collect/add",
      del: "/api/integral/collect/del",
    },
    sign: {
      config: "/api/sign/config",
      list: "/api/sign/list",
      integral: "/api/sign/integral",
      month: "/api/sign/month",
      user: "/api/sign/user",
      pointsTasks: "/api/sign/points_tasks",
      pointsTaskClaim: "/api/sign/points_task_claim",
      pointsTaskEvent: "/api/sign/points_task_event",
    },
    lottery: "/api/v2/lottery/info",
    lotteryDraw: "/api/v2/lottery",
    lotteryRecord: "/api/v2/lottery/record",
    notifications: "/api/integral/user_tongzhi_lists",
    shaidan: "/api/integral/shaidan_lists",
    shaidanDetail: "/api/integral/shaidan_detail",
    shaidanDetailComments: "/api/integral/shaidan_detail_pinglun",
    shaidanAddComment: "/api/integral/shaidan_add_pinglun",
    shaidanLike: "/api/integral/shaidan_dianzhan",
    shaidanEdit: "/api/integral/shaidan_edit",
    userShaidanList: "/api/integral/user_shaidan_lists",
    help: "/api/integral/help",
    helpDetail: "/api/integral/help_detail",
    fanxianList: "/api/integral/user_fanxian_lists",
    redemptions: "/api/integral/huande_lists",
    huandeInfo: "/api/integral/huande_info",
    huandeInfoAddress: "/api/integral/huande_info_address",
    huishou: "/api/integral/huishou",
    exchangeAll: "/api/integral/order/exchange_all",
    huzuan: "/api/integral/huzuan",
    tanchuang: "/api/integral/get_tanchuang",
    hqjlLists: "/api/integral/hqjl_lists",
    hqjlInfo: "/api/integral/hqjl_info",
    userHqjlLists: "/api/integral/user_hqjl_lists",
    detailHqjl: "/api/integral/detail_hqjl",
    detailLshqz: "/api/integral/detail_lshqz",
    detailJsxq: "/api/integral/detail_jsxq",
    detailJsxqLists: "/api/integral/detail_jsxq_lists",
    detailShaidanList: (id: number) => `/api/integral/detail_shaidan_list/${id}`,
    replyList: (id: number) => `/api/integral/reply/list/${id}`,
    replyConfig: (id: number) => `/api/integral/reply/config/${id}`,
    newlist: "/api/integral/newlist",
    newcategory: "/api/integral/newcategory",
    getnotice: "/api/integral/getnotice",
    detailDesc: (id: number) => `/api/integral/detail_desc/${id}`,
    tongzhi: "/api/integral/user_tongzhi",
    tongzhiDel: "/api/integral/user_tongzhi_del",
    shaidanNum: (pid: number) => `/api/integral/shaidan_num?pid=${pid}`,
    detailHqjlUnique: "/api/integral/detail_hqjl_unique",
    cartAddAll: "/api/integral/cart/add_all",
    collectAll: "/api/integral/collect/all",
    collectAddAll: "/api/integral/collect/collect_add_all",
    collectAllDel: "/api/integral/collect/collect_all_del",
    // 揭晓
    reveal: {
      index: "/api/integral/index",
      jiexiaoLists: "/api/integral/jiexiao_lists",
      jiexiaoDetail: "/api/integral/jiexiao_detail",
      huandeLists: "/api/integral/huande_lists",
      huandeInfo: "/api/integral/huande_info",
      exchange: "/api/integral/order/exchange",
      // T10 可验算揭晓：只读开奖快照（draw_snapshot），不查活表
      view: "/api/integral/reveal_view",
      verify: "/api/integral/reveal_verify",
    },
  },

  // 地址（delete 为 POST body { id }）
  address: {
    list: "/api/address/list",
    create: "/api/address/edit",
    update: "/api/address/edit",
    del: "/api/address/del",
    default: "/api/address/default",
    setDefault: "/api/address/default/set",
  },

  // 收藏
  collect: {
    list: "/api/collect/user",
    add: "/api/collect/add",
    del: "/api/collect/del",
  },

  // 优惠券
  coupon: {
    list: "/api/coupons",
    /** 用户已领券：types 0=全部 1=未用 2=已用 3=过期 */
    myCoupons: (types: number) => `/api/coupons/user/${types}`,
    /** 订单可用券：price 为订单金额或 cartId */
    orderCoupons: (price: string | number) => `/api/coupons/order/${price}`,
    receive: "/api/coupon/receive",
  },

  // 营销活动
  seckill: {
    index: "/api/seckill/index",
    list: (time: string) => `/api/seckill/list/${time}`,
    detail: (id: number, time: string) => `/api/seckill/detail/${id}/${time}`,
  },
  combination: {
    list: "/api/combination/list",
    detail: (id: number) => `/api/combination/detail/${id}`,
    pink: (id: number) => `/api/combination/pink/${id}`,
  },
  groupLottery: {
    list: "/api/group-lottery/list",
    detail: (id: number) => `/api/group-lottery/detail/${id}`,
    createPink: "/api/group-lottery/create-pink",
    pinkDetail: (id: number) => `/api/group-lottery/pink/${id}`,
    join: "/api/group-lottery/join",
    cancelApply: "/api/group-lottery/cancel-apply",
    reviewCancel: "/api/group-lottery/review-cancel",
    leaderCancel: "/api/group-lottery/leader-cancel",
    winnerChoice: "/api/group-lottery/winner-choice",
    myRecord: "/api/group-lottery/my-record",
    verify: (id: number) => `/api/group-lottery/verify/${id}`,
  },
  bargain: {
    config: "/api/bargain/config",
    list: "/api/bargain/list",
    detail: (id: number) => `/api/bargain/detail/${id}`,
    start: "/api/bargain/start",
    help: "/api/bargain/help",
  },

  // 直播
  live: {
    list: "/api/live/list",
    playbacks: (id: number) => `/api/live/playbacks/${id}`,
  },

  // 预售
  presale: {
    list: "/api/presale/list",
  },

  // 优惠套餐（搭配商品）
  discounts: {
    list: (productId: number) => `/api/store_discounts/list/${productId}`,
  },

  // 分销
  commission: {
    index: "/api/commission",
    spreadPeople: "/api/spread/people",
    spreadOrder: "/api/spread/order",
    agentInfo: "/api/agent/agent_info",
    spreadInfo: "/api/user/spread_info",
    apply: "/api/agent/apply",
    qrcode: (uid: number | string) => `/api/agent/qrcode/${uid}`,
    poster: (uid: number | string) => `/api/agent/poster/${uid}`,
  },

  // 盲盒
  box: {
    hall: "/api/manghe/hall",
    shopwindow: "/api/manghe/shopwindow",
    getBoxShop: "/api/manghe/getBoxShop",
    box: "/api/manghe/box",
    detail: "/api/manghe/detail",
    boxList: "/api/manghe/boxList",
    boxLog: "/api/manghe/boxLog",
    boxLogInfo: "/api/manghe/boxLogInfo",
    recovery: "/api/manghe/recovery",
    addBox: "/api/manghe/addBox",
    createOrder: "/api/manghe/createOrder",
    boxBrandList: "/api/manghe/boxBrandList",
    boxBrand: "/api/manghe/boxBrand",
    listLuckyNotice: "/api/manghe/list_lucky_notice",
    boxTuijian: "/api/manghe/boxTuijian",
    getConfig: "/api/manghe/getConfig",
    getYuanqiConfig: "/api/manghe/get_yuanqi_config",
    getUserCoupon: "/api/manghe/getUserCoupon",
    orderPay: "/api/manghe/orderPay",
    orderDetail: "/api/manghe/orderDetail",
    checkOrderPay: "/api/manghe/check_order_pay",
    sendPay: "/api/manghe/sendPay",
    sendCreateOrder: "/api/manghe/sendCreateOrder",
    sendOrderDetail: "/api/manghe/sendOrderDetail",
    sendOrderList: "/api/manghe/sendOrderList",
    getSendAll: "/api/manghe/getSendAll",
    boxChoujiangList: "/api/manghe/boxChoujiangList",
    kaijiangInfo: "/api/manghe/kaijiangInfo",
    getTongzhi: "/api/manghe/get_tongzhi",
    getOne: "/api/manghe/getOne",
    SgetOne: "/api/manghe/SgetOne",
    wangqiJixiao: "/api/manghe/wangqiJixiao",
    // 签到系统
    checkinInfo: "/api/manghe/checkinInfo",
    checkin: "/api/manghe/checkin",
    checkinTasks: "/api/manghe/checkinTasks",
    checkinTaskClaim: "/api/manghe/checkinTaskClaim",
    checkinTaskEvent: "/api/manghe/checkin_task_event",
    claimSignPrize: "/api/manghe/claim_sign_prize",
    // 保底系统
    pityInfo: "/api/manghe/pityInfo",
    // 心愿池
    wishlistList: "/api/manghe/wishlistList",
    wishlistAdd: "/api/manghe/wishlistAdd",
    wishlistRemove: "/api/manghe/wishlistRemove",
    // 交换市场
    exchangeList: "/api/manghe/exchangeList",
    exchangeCreate: "/api/manghe/exchangeCreate",
    exchangeApply: "/api/manghe/exchangeApply",
    // 合成系统
    synthesize: "/api/manghe/synthesize",
    // 排行榜
    leaderboard: "/api/manghe/leaderboard",
    // 限时活动
    activityList: "/api/manghe/activityList",
    activityDetail: "/api/manghe/activityDetail",
    // 开盒回放
    replayList: "/api/manghe/replayList",
    // 好友系统
    friendBoxList: "/api/manghe/friendBoxList",
    friendGift: "/api/manghe/friendGift",
    // 新人礼包
    newbieCheck: "/api/manghe/newbieCheck",
    newbieClaim: "/api/manghe/newbieClaim",
    // Exchange market (enhanced)
    exchangeMyList: "/api/manghe/exchangeMyList",
    exchangeCancel: "/api/manghe/exchangeCancel",
    exchangeConfirm: "/api/manghe/exchangeConfirm",
    exchangeOffers: "/api/manghe/exchangeOffers",
    // Wishlist notifications
    wishlistNotifications: "/api/manghe/wishlistNotifications",
    wishlistUnreadCount: "/api/manghe/wishlistUnreadCount",
    // Quick buy / optimized detail
    boxQuickDetail: "/api/manghe/boxQuickDetail",
    // New features (Phase 2)
    probability: "/api/manghe/probability",
    freeDrawCheck: "/api/manghe/freeDrawCheck",
    freeDraw: "/api/manghe/freeDraw",
    inviteInfo: "/api/manghe/inviteInfo",
    inviteClaim: "/api/manghe/inviteClaim",
  },
} as const;
