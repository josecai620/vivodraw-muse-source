import type { GlowEffectConfig, FlowLightEffectConfig } from './VFXConfig';

export class GlowEffect { // GlowEffect：发光效果配置组件
  constructor(public config: GlowEffectConfig) {} // config：发光配置

  setConfig(config: Partial<GlowEffectConfig>) {
    this.config = { ...this.config, ...config }; // config：合并后的发光配置
  }
}

export class FlowLightEffect { // FlowLightEffect：边缘流光配置组件
  constructor(public config: FlowLightEffectConfig) {} // config：流光配置

  setConfig(config: Partial<FlowLightEffectConfig>) {
    this.config = { ...this.config, ...config }; // config：合并后的流光配置
  }
}

export class GlowSystem { // GlowSystem：发光系统
  readonly glowEffect: GlowEffect; // glowEffect：发光效果组件
  readonly flowLightEffect: FlowLightEffect; // flowLightEffect：流光效果组件

  constructor(glow: GlowEffectConfig, flow: FlowLightEffectConfig) {
    this.glowEffect = new GlowEffect(glow);
    this.flowLightEffect = new FlowLightEffect(flow);
  }
}
