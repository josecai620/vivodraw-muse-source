import { Container, Sprite, Texture } from 'pixi.js';

export interface FireFilterConfig {
  flamePower: number; // flamePower：火焰强度
  fireSpeed: number; // fireSpeed：火焰速度
}

interface FireRhythm {
  charge: number; // charge：聚能强度
  burst: number; // burst：爆闪强度
  afterglow: number; // afterglow：余辉强度
  brightness: number; // brightness：整体亮度节奏
}

interface FlameLayer {
  sprite: Sprite; // sprite：连续火焰纹理层
  baseY: number; // baseY：基础 Y 坐标
  width: number; // width：基础宽度
  height: number; // height：基础高度
  alpha: number; // alpha：基础透明度
  speed: number; // speed：动画速度
  seed: number; // seed：随机种子
  sway: number; // sway：左右摆动幅度
}

export class FireFilter { // FireFilter：连续流动火焰滤镜
  private readonly flameLayers: FlameLayer[] = []; // flameLayers：多层火焰深度列表
  private readonly baseGlow: Sprite; // baseGlow：底部柔光
  private readonly centerX: number; // centerX：矿石中心 X
  private readonly baseY: number; // baseY：火焰底部 Y

  constructor(layer: Container, centerX: number, baseY: number) {
    this.centerX = centerX; // centerX：保存中心 X
    this.baseY = baseY; // baseY：保存火焰底部 Y
    this.baseGlow = new Sprite(this.createFireGlowTexture()); // baseGlow：创建火焰底部柔光
    this.baseGlow.anchor.set(0.5);
    this.baseGlow.x = centerX;
    this.baseGlow.y = baseY - 16;
    this.baseGlow.width = 310;
    this.baseGlow.height = 112;
    this.baseGlow.blendMode = 'add';
    layer.addChild(this.baseGlow);

    this.createLayer(layer, 0x07858c, 0x08aeb4, 276, 104, 0.24, 0.92, 0.6);
    this.createLayer(layer, 0x04a8ae, 0x7fd8dc, 210, 72, 0.3, 1.18, 4.2);
    this.createLayer(layer, 0x9fe4e6, 0xeafbfb, 136, 46, 0.34, 1.44, 7.6);
  }

  update(time: number, config: FireFilterConfig, rhythm: FireRhythm) {
    const power = Math.max(0, config.flamePower) * (0.72 + rhythm.charge * 0.12 + rhythm.afterglow * 0.16); // power：当前火焰强度
    const pulse = 0.68 + Math.sin(time * 2.2) * 0.14; // pulse：底部光呼吸
    this.baseGlow.alpha = 0.09 * pulse * Math.min(power, 1.15) + rhythm.afterglow * 0.04;
    this.baseGlow.scale.set(0.95 + Math.sin(time * 1.4) * 0.035, 0.9 + Math.sin(time * 2.0) * 0.05);

    this.flameLayers.forEach((flameLayer) => {
      const flow = time * flameLayer.speed * config.fireSpeed + flameLayer.seed; // flow：流动相位
      const yFloat = Math.sin(flow * 1.7) * 6; // yFloat：上下流动
      const xFloat = Math.sin(flow * 1.25) * flameLayer.sway; // xFloat：左右流动
      const stretch = 0.86 + Math.sin(flow * 1.9) * 0.09; // stretch：纵向拉伸
      flameLayer.sprite.x = this.centerX + xFloat;
      flameLayer.sprite.y = flameLayer.baseY + yFloat;
      flameLayer.sprite.alpha = flameLayer.alpha * (0.62 + Math.sin(flow * 2.2) * 0.14 + rhythm.afterglow * 0.16) * Math.min(power, 1.08);
      flameLayer.sprite.scale.set(0.9 + Math.sin(flow) * 0.03, stretch * Math.max(0.42, power));
    });
  }

  private createLayer(layer: Container, outerColor: number, innerColor: number, width: number, height: number, alpha: number, speed: number, seed: number) {
    const sprite = new Sprite(this.createFlameTexture(outerColor, innerColor, seed)); // sprite：连续火焰纹理层
    sprite.anchor.set(0.5, 1);
    sprite.x = this.centerX;
    sprite.y = this.baseY;
    sprite.width = width;
    sprite.height = height;
    sprite.blendMode = 'add';
    this.flameLayers.push({
      sprite,
      baseY: this.baseY,
      width,
      height,
      alpha,
      speed,
      seed,
      sway: 5 + seed * 0.9,
    });
    layer.addChild(sprite);
  }

  private createFlameTexture(outerColor: number, innerColor: number, seed: number) {
    const canvas = document.createElement('canvas'); // canvas：火焰离屏画布
    canvas.width = 384;
    canvas.height = 192;
    const context = canvas.getContext('2d'); // context：画布上下文
    if (!context) return Texture.EMPTY;
    context.clearRect(0, 0, canvas.width, canvas.height);

    const baseGlow = context.createRadialGradient(192, 168, 12, 192, 166, 180); // baseGlow：火焰底部扩散光
    baseGlow.addColorStop(0, this.rgba(innerColor, 0.78));
    baseGlow.addColorStop(0.42, this.rgba(outerColor, 0.34));
    baseGlow.addColorStop(1, this.rgba(outerColor, 0));
    context.fillStyle = baseGlow;
    context.fillRect(0, 0, canvas.width, canvas.height);

    for (let index = 0; index < 9; index += 1) { // index：连续火舌序号
      const ratio = index / 8; // ratio：横向比例
      const x = 54 + ratio * 276 + this.noise(index, seed) * 18; // x：火舌根部 X
      const width = 42 + this.noise(index + 3, seed) * 12; // width：火舌宽度
      const height = 72 + Math.sin(index * 1.7 + seed) * 22; // height：火舌高度
      const tipX = x + this.noise(index + 8, seed) * 24; // tipX：火舌尖端 X
      const tipY = 156 - height; // tipY：火舌尖端 Y
      const gradient = context.createLinearGradient(x, 166, tipX, tipY); // gradient：单条火舌渐变
      gradient.addColorStop(0, this.rgba(outerColor, 0));
      gradient.addColorStop(0.26, this.rgba(outerColor, 0.45));
      gradient.addColorStop(0.68, this.rgba(innerColor, 0.62));
      gradient.addColorStop(1, this.rgba(innerColor, 0));
      context.fillStyle = gradient;
      context.shadowColor = this.rgba(outerColor, 0.58);
      context.shadowBlur = 14;
      context.beginPath();
      context.moveTo(x - width, 172);
      context.bezierCurveTo(x - width * 1.05, 134, tipX - width * 0.45, 102, tipX, tipY);
      context.bezierCurveTo(tipX + width * 0.52, 104, x + width * 1.08, 136, x + width, 172);
      context.bezierCurveTo(x + width * 0.34, 184, x - width * 0.34, 184, x - width, 172);
      context.closePath();
      context.fill();

      if (index % 2 === 0) {
        this.drawFork(context, tipX, tipY + 12, width * 0.36, height * 0.32, innerColor, seed + index);
      }
    }

    return Texture.from(canvas);
  }

  private drawFork(context: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, color: number, seed: number) {
    const lean = this.noise(seed, 2) * 22; // lean：分叉倾斜
    const gradient = context.createLinearGradient(x, y + height, x + lean, y - height); // gradient：分叉渐变
    gradient.addColorStop(0, this.rgba(color, 0));
    gradient.addColorStop(0.45, this.rgba(color, 0.42));
    gradient.addColorStop(1, this.rgba(color, 0));
    context.fillStyle = gradient;
    context.beginPath();
    context.moveTo(x - width, y + height);
    context.bezierCurveTo(x - width * 0.8, y, x + lean - width * 0.3, y - height * 0.6, x + lean, y - height);
    context.bezierCurveTo(x + lean + width * 0.34, y - height * 0.55, x + width * 0.9, y, x + width, y + height);
    context.closePath();
    context.fill();
  }

  private createFireGlowTexture() {
    const canvas = document.createElement('canvas'); // canvas：离屏柔光画布
    canvas.width = 256;
    canvas.height = 128;
    const context = canvas.getContext('2d'); // context：画布上下文
    if (!context) return Texture.EMPTY;
    const gradient = context.createRadialGradient(128, 82, 8, 128, 80, 116); // gradient：径向火光渐变
    gradient.addColorStop(0, 'rgba(127, 216, 220, 0.46)');
    gradient.addColorStop(0.32, 'rgba(8, 174, 180, 0.22)');
    gradient.addColorStop(0.72, 'rgba(7, 133, 140, 0.08)');
    gradient.addColorStop(1, 'rgba(7, 133, 140, 0)');
    context.fillStyle = gradient;
    context.fillRect(0, 0, 256, 128);
    return Texture.from(canvas);
  }

  private rgba(color: number, alpha: number) {
    const red = (color >> 16) & 255; // red：红色通道
    const green = (color >> 8) & 255; // green：绿色通道
    const blue = color & 255; // blue：蓝色通道
    return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
  }

  private noise(x: number, y: number) {
    return Math.sin(x * 12.9898 + y * 78.233) * Math.cos(x * 4.1414 + y * 37.719); // noise：轻量伪噪声
  }
}
