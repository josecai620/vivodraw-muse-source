import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

// 盲盒接口返回数据类型定义
export interface BoxItem {
  id: number;
  name: string;
  image: string;
  price: number;
  integral: number;
  description: string;
  category: string;
  status: number;
}

export interface BoxDetail {
  id: number;
  name: string;
  image: string;
  price: number;
  integral: number;
  description: string;
  items: Array<{
    id: number;
    name: string;
    image: string;
    rarity: string;
    probability: number;
  }>;
  maxValue?: number;
  opened?: number;
  rarityDistribution?: Record<string, number>;
}

export interface BackpackItem {
  id: number;
  name: string;
  image: string;
  rarity: string;
  status: number;
  recycleValue: number;
  boxName: string;
  addTime: string;
}

export interface OpeningHistoryItem {
  id: number;
  boxId: number;
  boxName: string;
  itemId: number;
  itemName: string;
  itemImage: string;
  rarity: string;
  openTime: string;
  userNickname?: string;
  avatar?: string;
}

export interface LuckyNotice {
  id: number;
  userNickname: string;
  itemName: string;
  rarity: string;
  time: string;
}

/** 盲盒分类（用于大厅列表，含扩展字段） */
export interface BoxCategoryItem extends BoxItem {
  maxValue?: number;
  opened?: number;
  total?: number;
  rarityDistribution?: Record<string, number>;
}

// 盲盒大厅
export function getBoxHall() {
  return http.get(API_ENDPOINTS.box.hall);
}

// 橱窗
export function getBoxShopwindow() {
  return http.get(API_ENDPOINTS.box.shopwindow);
}

// 盲盒商城列表/盲盒可抽商品
export function getBoxShop(params?: { id?: number; page?: number; limit?: number; cid?: number }) {
  return http.post(API_ENDPOINTS.box.getBoxShop, {
    ...params,
    id: params?.id ?? params?.cid,
  });
}

// 盲盒详情
export function getBoxDetail(params: { id: number }) {
  return getBoxShop(params);
}

// 盲盒详情(另一接口)
export function getBoxDetail2(params: { id: number }) {
  return http.post(API_ENDPOINTS.box.detail, params);
}

// 我的盲盒列表(背包)
export function getBoxList(params?: { page?: number; limit?: number; status?: number }) {
  return http.post(API_ENDPOINTS.box.boxList, params);
}

// 开盒记录
export function getBoxLog(params?: { page?: number; limit?: number; cid?: number }) {
  return http.post(API_ENDPOINTS.box.boxLog, params);
}

// 开盒记录详情
export function getBoxLogInfo(params: { id: number }) {
  return http.post(API_ENDPOINTS.box.boxLogInfo, params);
}

// 回收
export function doRecovery(params: { ids: number[] }) {
  return http.post(API_ENDPOINTS.box.recovery, params);
}

// 添加盲盒(开盒)
export function addBox(params: { id: number; num?: number }) {
  return http.post(API_ENDPOINTS.box.addBox, params);
}

// 创建盲盒订单
export function createBoxOrder(params: { id: number; num: number }) {
  return http.post(API_ENDPOINTS.box.createOrder, params);
}

// 品牌列表
export function getBoxBrandList(params?: { page?: number; limit?: number }) {
  return http.post(API_ENDPOINTS.box.boxBrandList, params);
}

// 品牌详情
export function getBoxBrand(params: { id: number }) {
  return http.post(API_ENDPOINTS.box.boxBrand, params);
}

// 中奖滚屏列表
export function getLuckyNotices() {
  return http.get(API_ENDPOINTS.box.listLuckyNotice);
}

// 推荐盲盒列表（盲盒分类，用于大厅）
export function getBoxTuijian() {
  return http.post(API_ENDPOINTS.box.boxTuijian, {});
}

// 盲盒配置
export function getBoxConfig() {
  return http.post(API_ENDPOINTS.box.getConfig, {});
}

// 元气配置
export function getYuanqiConfig() {
  return http.post(API_ENDPOINTS.box.getYuanqiConfig, {});
}

// 用户可用优惠券
export function getUserCoupon(params: { money: number }) {
  return http.post(API_ENDPOINTS.box.getUserCoupon, params);
}

// 盲盒订单支付
export function boxOrderPay(params: { id: number; payType: string }) {
  return http.post(API_ENDPOINTS.box.orderPay, params);
}

// 盲盒订单详情
export function getBoxOrderDetail(params: { id: number }) {
  return http.post(API_ENDPOINTS.box.orderDetail, params);
}

// 检查订单支付状态
export function checkBoxOrderPay(params: { id: number }) {
  return http.post(API_ENDPOINTS.box.checkOrderPay, params);
}

// 发货支付运费
export function sendPay(params: { id: number; payType: string }) {
  return http.post(API_ENDPOINTS.box.sendPay, params);
}

// 创建发货订单
export function sendCreateOrder(params: { arr: any[]; address_id: number }) {
  return http.post(API_ENDPOINTS.box.sendCreateOrder, params);
}

// 发货订单详情
export function getSendOrderDetail(params: { id: number }) {
  return http.post(API_ENDPOINTS.box.sendOrderDetail, params);
}

// 发货订单列表
export function getSendOrderList(params?: { page?: number; status?: number }) {
  return http.post(API_ENDPOINTS.box.sendOrderList, params);
}

// 可发货盲盒列表
export function getSendAll() {
  return http.post(API_ENDPOINTS.box.getSendAll, {});
}

// 抽奖列表
export function getBoxChoujiangList(params: { id: number; page?: number; status?: number }) {
  return http.post(API_ENDPOINTS.box.boxChoujiangList, params);
}

// 开奖详情
export function getKaijiangInfo(params: { id: number }) {
  return http.post(API_ENDPOINTS.box.kaijiangInfo, params);
}

// 盲盒通知弹窗
export function getBoxTongzhi() {
  return http.post(API_ENDPOINTS.box.getTongzhi, {});
}

// 抽奖结果（单次开盒）
export function getBoxOne(params: { id: number }) {
  return http.post(API_ENDPOINTS.box.getOne, params);
}

// 批量开盒结果
export function getBoxSgetOne(params: { id: number; num: number }) {
  return http.post(API_ENDPOINTS.box.SgetOne, params);
}

// 往期揭晓
export function getWangqiJixiao(params: { id: number; page?: number }) {
  return http.post(API_ENDPOINTS.box.wangqiJixiao, params);
}

// ========== 签到系统 ==========

export function getCheckinInfo() {
  return http.post(API_ENDPOINTS.box.checkinInfo, {});
}

export function doCheckin() {
  return http.post(API_ENDPOINTS.box.checkin, {});
}

export function getCheckinTasks() {
  return http.post(API_ENDPOINTS.box.checkinTasks, {});
}

export function claimCheckinTask(params: { task_id: string }) {
  return http.post(API_ENDPOINTS.box.checkinTaskClaim, params);
}

export function trackBoxTaskEvent(params: { event: string; ref?: string; cate_id?: string | number }) {
  return http.post(API_ENDPOINTS.box.checkinTaskEvent, params);
}

export function claimSignPrize() {
  return http.post(API_ENDPOINTS.box.claimSignPrize, {});
}

// ========== 保底系统 ==========

export function getPityInfo() {
  return http.post(API_ENDPOINTS.box.pityInfo, {});
}

// ========== 心愿池 ==========

export function getWishlistList() {
  return http.post(API_ENDPOINTS.box.wishlistList, {});
}

export function addWishlistItem(params: { box_id: number; item_name?: string; rarity?: string }) {
  return http.post(API_ENDPOINTS.box.wishlistAdd, params);
}

export function removeWishlistItem(params: { id: number }) {
  return http.post(API_ENDPOINTS.box.wishlistRemove, params);
}

// ========== 交换市场 ==========

export function getExchangeList(params?: { page?: number; rarity?: string; search?: string }) {
  return http.post(API_ENDPOINTS.box.exchangeList, params);
}

export function createExchangeListing(params: { user_box_id: number; want_desc: string; want_rarity?: string }) {
  return http.post(API_ENDPOINTS.box.exchangeCreate, params);
}

export function applyExchange(params: { listing_id: number }) {
  return http.post(API_ENDPOINTS.box.exchangeApply, params);
}

// ========== 合成系统 ==========

export function doSynthesize(params: { item_ids: number[]; recipe: string }) {
  return http.post(API_ENDPOINTS.box.synthesize, params);
}

// ========== 排行榜 ==========

export function getLeaderboard(type: string = "luck") {
  return http.get(API_ENDPOINTS.box.leaderboard, { params: { type } });
}

// 数据映射函数
export function mapBoxItem(raw: any): BoxItem {
  return {
    id: raw.id || raw.box_id || 0,
    name: raw.name || raw.box_name || raw.cate_name || raw.store_name || "",
    image: raw.image || raw.pic || raw.img || "",
    price: raw.price || raw.min_price || raw.goods_price || 0,
    integral: raw.integral || 0,
    description: raw.description || raw.desc || "",
    category: raw.category || raw.cate || "",
    status: raw.status || 1,
  };
}

/** 盲盒分类映射（store_category 用于大厅列表），含扩展字段供大厅展示 */
export function mapBoxCategoryItem(raw: any): BoxItem & { maxValue?: number; opened?: number; total?: number; rarityDistribution?: Record<string, number> } {
  return {
    id: raw.id || 0,
    name: raw.cate_name || raw.name || raw.store_name || "",
    image: raw.pic || raw.image || raw.img || "",
    price: Number(raw.price || raw.price1 || raw.min_price || 0),
    integral: 0,
    description: raw.cate_desc || raw.description || raw.desc || "",
    category: raw.category || raw.cate || "",
    status: 1,
    maxValue: raw.max_price || raw.maxPrice || 0,
    opened: raw.sales || 0,
    total: raw.total || 100,
    rarityDistribution: raw.rarityDistribution || getCategoryRarityDistribution(raw),
  };
}

export function mapBoxDetail(raw: any): BoxDetail {
  const category = raw.mh || raw.box || raw.detail || raw;
  const rawItems = raw.shop || raw.items || raw.list || [];
  const rarityDistributionRaw = category.rarityDistribution || category.rarity_distribution || {};
  const fallbackRarityDistribution = getCategoryRarityDistribution(category);
  const rarityDistribution =
    Object.keys(rarityDistributionRaw).length > 0 ? rarityDistributionRaw : fallbackRarityDistribution;
  const tagCounts = rawItems.reduce((acc: Record<string, number>, item: any) => {
    const tag = String(item.tag || item.rarity || item.level || 1);
    acc[tag] = (acc[tag] || 0) + 1;
    return acc;
  }, {});
  const prices = rawItems
    .map((item: any) => Number(item.goods_price || item.price || item.product_price || 0))
    .filter((price: number) => price > 0);

  return {
    id: category.id || category.box_id || 0,
    name: category.cate_name || category.name || category.box_name || "",
    image: category.pic || category.image || category.img || "",
    price: Number(category.price || category.price1 || category.min_price || 0),
    integral: Number(category.integral || 0),
    description: category.cate_desc || category.description || category.desc || "",
    items: rawItems.map((item: any) => {
      const tag = String(item.tag || item.rarity || item.level || 1);
      const rarity = mapRarity(tag);
      const tagProbability = Number(category[`tag${tag}`] || 0);
      return {
      id: item.id || item.item_id || 0,
      name: item.name || item.item_name || item.goods_name || item.store_name || "",
      image: item.image || item.pic || item.img || item.product_image || "",
      rarity,
      probability: Number(item.probability || item.chance || item.rate || 0)
        || (tagProbability > 0 ? Number((tagProbability / (tagCounts[tag] || 1)).toFixed(2)) : 0),
      };
    }),
    maxValue: Number(category.maxValue || category.max_price || category.maxPrice || Math.max(0, ...prices)),
    opened: Number(category.opened || category.sales || category.sale || category.open_count || 0),
    rarityDistribution,
  };
}

function getCategoryRarityDistribution(raw: any): Record<string, number> {
  return {
    common: Number(raw.tag1 || 0),
    uncommon: Number(raw.tag2 || 0),
    rare: Number(raw.tag3 || 0),
    epic: Number(raw.tag4 || 0),
  };
}

export function mapBackpackItem(raw: any): BackpackItem {
  return {
    id: raw.id || raw.item_id || 0,
    name: raw.name || raw.item_name || "",
    image: raw.image || raw.pic || raw.img || "",
    rarity: mapRarity(raw.rarity || raw.level),
    status: raw.status || 1,
    recycleValue: raw.recycle_value || raw.recycle || 0,
    boxName: raw.box_name || "",
    addTime: raw.add_time || new Date().toISOString(),
  };
}

export function mapOpeningHistoryItem(raw: any): OpeningHistoryItem {
  const prize = raw.prize || {};
  return {
    id: raw.id || raw.log_id || 0,
    boxId: raw.box_id || 0,
    boxName: raw.box_name || raw.cate_name || "",
    itemId: raw.item_id || 0,
    itemName: raw.item_name || prize.name || raw.store_name || "",
    itemImage: raw.item_image || prize.image || raw.image || raw.cate_image || "",
    rarity: mapRarity(raw.rarity || raw.level),
    openTime: raw.open_time || raw.add_time || raw.createtime || new Date().toISOString(),
    userNickname: raw.nickname || raw.user_nickname || raw.user_name || "",
    avatar: raw.avatar || raw.user_avatar || "",
  };
}

export function mapLuckyNotice(raw: any): LuckyNotice {
  return {
    id: raw.id || 0,
    userNickname: raw.nickname || raw.user_nickname || "Anonymous",
    itemName: raw.item_name || "",
    rarity: mapRarity(raw.rarity || raw.level),
    time: raw.time || raw.add_time || new Date().toISOString(),
  };
}

// ==================== Phase 2 API 函数 ====================

export async function getActivityList(): Promise<any[]> {
  const res = await http.get(API_ENDPOINTS.box.activityList);
  return (res?.data || []).map((a: any) => ({
    id: a.id,
    title: a.title,
    description: a.description,
    cateId: a.cate_id,
    boostType: a.boost_type,
    boostValue: parseFloat(a.boost_value),
    bannerImage: a.banner_image,
    startTime: a.start_time,
    endTime: a.end_time,
    remainingSeconds: a.remaining_seconds,
    cateInfo: a.cate_info,
  }));
}

export async function getActivityDetail(id: number): Promise<any> {
  const res = await http.get(`${API_ENDPOINTS.box.activityDetail}/${id}`);
  const a = res?.data || {};
  return {
    ...a,
    boostValue: parseFloat(a.boost_value || 0),
    remainingSeconds: a.remaining_seconds || 0,
    isActive: a.is_active === 1,
    products: (a.products || []).map((p: any) => ({
      id: p.id,
      name: p.store_name,
      image: p.image,
      price: p.price,
      rarity: p.rarity || "common",
    })),
  };
}

export async function getReplayList(page: number = 1, limit: number = 20): Promise<any> {
  const res = await http.post(API_ENDPOINTS.box.replayList, { page, limit });
  const data = res?.data || {};
  return {
    list: (data.list || []).map((item: any) => ({
      id: item.id,
      cateId: item.cate_id,
      cateName: item.cate_name,
      productId: item.product_id,
      productName: item.product_name,
      productImage: item.product_image,
      productPrice: item.product_price,
      rarity: item.rarity || "common",
      createDate: item.create_date,
    })),
    total: data.total || 0,
    page: data.page || page,
    hasMore: data.has_more || false,
  };
}

export async function getFriendBoxList(): Promise<any[]> {
  const res = await http.post(API_ENDPOINTS.box.friendBoxList);
  return (res?.data?.list || []).map((f: any) => ({
    uid: f.uid,
    nickname: f.nickname || "Unknown User",
    avatar: f.avatar || "",
    addTime: f.add_time,
    totalOpens: f.total_opens || 0,
    maxRarity: f.max_rarity || "common",
    recentRare: (f.recent_rare || []).map((r: any) => ({
      name: r.product_name,
      image: r.product_image,
      rarity: r.rarity || "common",
    })),
  }));
}

export async function friendGift(friendUid: number, userBoxId: number): Promise<any> {
  return http.post(API_ENDPOINTS.box.friendGift, { friend_uid: friendUid, user_box_id: userBoxId });
}

export async function getNewbieCheck(): Promise<any> {
  const res = await http.post(API_ENDPOINTS.box.newbieCheck);
  const d = res?.data || {};
  return {
    claimed: d.claimed || false,
    eligible: d.eligible || false,
    daysSinceRegister: d.days_since_register || 0,
    rewardPreview: d.reward_preview || {},
  };
}

export async function claimNewbieGift(): Promise<any> {
  return http.post(API_ENDPOINTS.box.newbieClaim);
}

// 稀有度映射函数
function mapRarity(rawRarity: string | number): string {
  const rarityMap: Record<string | number, string> = {
    1: "common",
    2: "uncommon",
    3: "rare",
    4: "epic",
    5: "legendary",
    6: "secret",
    "common": "common",
    "uncommon": "uncommon",
    "rare": "rare",
    "epic": "epic",
    "legendary": "legendary",
    "secret": "secret",
  };
  return rarityMap[rawRarity] || "common";
}
// ==================== Enhanced Exchange Market API ====================

export async function getExchangeMyList(status?: number): Promise<any[]> {
  const res = await http.post(API_ENDPOINTS.box.exchangeMyList, { status: status ?? '' });
  return (res?.data?.list || []).map((e: any) => ({
    id: e.id,
    userBoxId: e.user_box_id,
    itemName: e.item_name,
    itemImage: e.item_image,
    itemRarity: e.item_rarity || 'common',
    wantDesc: e.want_desc,
    wantRarity: e.want_rarity,
    status: e.status, // 0=active, 1=pending, 2=completed, 3=cancelled
    applicantUid: e.applicant_uid,
    createtime: e.createtime,
  }));
}

export async function cancelExchangeListing(listingId: number): Promise<any> {
  return http.post(API_ENDPOINTS.box.exchangeCancel, { listing_id: listingId });
}

export async function confirmExchange(listingId: number, applicantBoxId: number): Promise<any> {
  return http.post(API_ENDPOINTS.box.exchangeConfirm, { listing_id: listingId, applicant_box_id: applicantBoxId });
}

export async function getExchangeOffers(): Promise<any[]> {
  const res = await http.post(API_ENDPOINTS.box.exchangeOffers);
  return (res?.data?.offers || []).map((o: any) => ({
    id: o.id,
    itemName: o.item_name,
    itemImage: o.item_image,
    wantDesc: o.want_desc,
    applicantName: o.applicant_name || 'User',
    applicantAvatar: o.applicant_avatar,
    applicantUid: o.applicant_uid,
    status: o.status,
  }));
}

// ==================== Wishlist Notifications API ====================

export async function getWishlistNotifications(page: number = 1): Promise<any> {
  const res = await http.post(API_ENDPOINTS.box.wishlistNotifications, { page });
  const data = res?.data || {};
  return {
    list: data.list || [],
    total: data.total || 0,
    hasMore: data.has_more || false,
  };
}

export async function getWishlistUnreadCount(): Promise<number> {
  const res = await http.post(API_ENDPOINTS.box.wishlistUnreadCount);
  return res?.data?.count || 0;
}

// ==================== Quick Buy API ====================

export async function getBoxQuickDetail(id: number): Promise<any> {
  const res = await http.post(API_ENDPOINTS.box.boxQuickDetail, { id });
  const d = res?.data || {};
  return {
    id: d.id,
    name: d.name || '',
    image: d.image || '',
    desc: d.desc || '',
    sale: d.sale || 0,
    prices: (d.prices || []).map((p: any) => ({
      count: p.count,
      price: p.price,
      perBox: p.per_box,
    })),
    topItems: (d.top_items || []).map((i: any) => ({
      id: i.id,
      name: i.store_name || i.name,
      image: i.image,
      rarity: i.rarity || 'common',
    })),
    recentWinners: d.recent_winners || [],
    balance: d.balance || 0,
    points: d.points || 0,
    pityInfo: d.pity_info ? {
      consecutiveNonRare: d.pity_info.consecutive_non_rare,
      nextPity: d.pity_info.next_pity,
    } : null,
  };
}

// ==================== New Features (Phase 2) API ====================

export async function getProbability(cateId: number): Promise<any> {
  const res = await http.post(API_ENDPOINTS.box.probability, { cate_id: cateId });
  const d = res?.data || {};
  return {
    cateName: d.cate_name,
    totalItems: d.total_items,
    distribution: d.distribution || [],
    pityThresholds: d.pity_thresholds || [],
    items: d.items || [],
  };
}

export async function checkFreeDraw(): Promise<any> {
  const res = await http.post(API_ENDPOINTS.box.freeDrawCheck);
  return res?.data || { available: false, today_drawn: false };
}

export async function doFreeDraw(): Promise<any> {
  const res = await http.post(API_ENDPOINTS.box.freeDraw);
  return res?.data || {};
}

export async function getInviteInfo(): Promise<any> {
  const res = await http.post(API_ENDPOINTS.box.inviteInfo);
  return res?.data || {};
}

export async function claimInviteReward(level: number): Promise<any> {
  return http.post(API_ENDPOINTS.box.inviteClaim, { level });
}
