import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { useAppStore } from "@/store/app";
import {
  getGroupLotteryList,
  getGroupLotteryDetail,
  createPink,
  getPinkDetail,
  joinPink,
  cancelApply,
  reviewCancel,
  leaderCancel,
  winnerChoice,
  getMyRecords,
  getVerifyInfo,
} from "../lib/api/groupLottery";

const QK = {
  list: "groupLotteryList",
  detail: "groupLotteryDetail",
  pink: "groupLotteryPink",
  myRecords: "groupLotteryMyRecords",
  verify: "groupLotteryVerify",
};

export function useGroupLotteryList(page = 1) {
  return useQuery({
    queryKey: [QK.list, page],
    queryFn: () => getGroupLotteryList({ page, limit: 20 }),
  });
}

export function useGroupLotteryDetail(id: number) {
  return useQuery({
    queryKey: [QK.detail, id],
    queryFn: () => getGroupLotteryDetail(id),
    enabled: id > 0,
  });
}

export function usePinkDetail(id: number) {
  return useQuery({
    queryKey: [QK.pink, id],
    queryFn: () => getPinkDetail(id),
    enabled: id > 0,
    refetchInterval: 10000,
  });
}

export function useCreatePink() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: createPink,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [QK.list] });
      qc.invalidateQueries({ queryKey: [QK.detail] });
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useJoinPink() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  return useMutation({
    mutationFn: joinPink,
    onSuccess: (_, variables) => {
      qc.invalidateQueries({ queryKey: [QK.pink, variables.pink_id] });
      qc.invalidateQueries({ queryKey: [QK.detail] });
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useCancelApply() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  const { t } = useTranslation();
  return useMutation({
    mutationFn: cancelApply,
    onSuccess: (_, variables) => {
      qc.invalidateQueries({ queryKey: [QK.pink, variables.pink_id] });
      showToast(t("groupLottery.cancelApplySubmitted"));
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useReviewCancel() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  const { t } = useTranslation();
  return useMutation({
    mutationFn: reviewCancel,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [QK.pink] });
      showToast(t("groupLottery.reviewDone"));
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useLeaderCancel() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  const { t } = useTranslation();
  return useMutation({
    mutationFn: leaderCancel,
    onSuccess: (_, variables) => {
      qc.invalidateQueries({ queryKey: [QK.pink, variables.pink_id] });
      showToast(t("groupLottery.cancelApplySubmitted"));
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useWinnerChoice() {
  const qc = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  const { t } = useTranslation();
  return useMutation({
    mutationFn: winnerChoice,
    onSuccess: (_, variables) => {
      qc.invalidateQueries({ queryKey: [QK.pink, variables.pink_id] });
      showToast(variables.choice === 1 ? t("groupLottery.shipSubmitted") : t("groupLottery.recycledToAccount"));
    },
    onError: (e: Error) => showToast(e.message, "error"),
  });
}

export function useMyGroupLotteryRecords(page = 1) {
  return useQuery({
    queryKey: [QK.myRecords, page],
    queryFn: () => getMyRecords({ page, limit: 20 }),
  });
}

export function useVerifyInfo(pinkId: number) {
  return useQuery({
    queryKey: [QK.verify, pinkId],
    queryFn: () => getVerifyInfo(pinkId),
    enabled: pinkId > 0,
  });
}
