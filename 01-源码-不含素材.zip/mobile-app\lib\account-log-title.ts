/** 账户明细标题：中英对照。只译已核对过的账本用语，不知道的不瞎编。 */

const TO_SIMPLIFIED: Array<[RegExp, string]> = [
  [/帳戶/g, "账户"],
  [/積分/g, "积分"],
  [/兌換/g, "兑换"],
  [/獎勵/g, "奖励"],
  [/簽到/g, "签到"],
  [/礦/g, "矿"],
  [/幣/g, "币"],
  [/淵/g, "渊"],
  [/貝殼/g, "贝壳"],
  [/尋珠/g, "寻珠"],
  [/雲購/g, "云购"],
  [/參與/g, "参与"],
  [/餘額/g, "余额"],
  [/餘/g, "余"],
  [/購買/g, "购买"],
  [/寵物/g, "宠物"],
  [/逗寵/g, "逗宠"],
  [/寵/g, "宠"],
  [/鎖/g, "锁"],
  [/進/g, "进"],
  [/解鎖/g, "解锁"],
  [/餵/g, "喂"],
  [/點/g, "点"],
  [/閱/g, "阅"],
  [/覽/g, "览"],
  [/場/g, "场"],
  [/種/g, "种"],
  [/還/g, "还"],
  [/舊/g, "旧"],
  [/週/g, "周"],
  [/錄/g, "录"],
  [/禮/g, "礼"],
  [/辦/g, "办"],
  [/減/g, "减"],
  [/經/g, "经"],
  [/驗/g, "验"],
  [/優/g, "优"],
  [/華/g, "华"],
  [/員/g, "员"],
  [/單/g, "单"],
  [/開/g, "开"],
  [/氣/g, "气"],
  [/後/g, "后"],
  [/臺/g, "台"],
  [/獎/g, "奖"],
  [/勵/g, "励"],
  [/戶/g, "户"],
  [/積/g, "积"],
  [/兌/g, "兑"],
  [/換/g, "换"],
  [/余/g, "余"],
  [/額/g, "额"],
  [/購/g, "购"],
  [/任務/g, "任务"],
  [/務/g, "务"],
  [/創/g, "创"],
];

const TITLE_EN: Record<string, string> = {
  金币兑换积分: "Farm coins to points",
  农场金币兑换积分: "Farm coins to points",
  积分兑换农场金币: "Points to farm coins",
  积分兑换金币: "Points to farm coins",
  积分兑换矿币: "Points to mine coins",
  矿币兑换积分: "Mine coins to points",
  积分兑换贝壳币: "Points to shell coins",
  贝壳币兑换积分: "Shell coins to points",
  美元余额购买积分: "Bought points with USD",
  深渊矿洞奖励: "Abyss Mine reward",
  海底寻珠奖励: "Pearl Lagoon reward",
  签到奖励: "Check-in reward",
  盲盒每日签到: "Blind box daily check-in",
  盲盒每日任务: "Blind box daily task",
  云购参与: "Cloud Buy entry",
  云购退回: "Cloud Buy refund",
  云购中奖积分: "Cloud Buy prize points",
  系统增加积分: "Admin points credit",
  系统减少积分: "Admin points debit",
  系统增加余额: "Admin USD credit",
  系统减少余额: "Admin USD debit",
  晒单奖励: "Showcase reward",
  用户充值余额: "Wallet top-up",
  用户充值退款: "Top-up refund",
  会员日赠积分: "Membership daily points",
  会员日赠入账: "Membership daily points",
  购买商品赠送积分: "Purchase bonus points",
  下单赠送积分: "Order bonus points",
  购物赠分入账: "Purchase bonus points",
  下单优惠活动赠送积分: "Promotion bonus points",
  积分回退: "Points refund",
  返还下单使用积分: "Points refund",
  商品退积分: "Order points refund",
  积分抵扣: "Points used at checkout",
  积分兑换商品: "Redeemed with points",
  兑换商品: "Redeemed with points",
  参与抽奖使用积分: "Lottery entry",
  抽奖中奖赠送积分: "Lottery prize points",
  抽奖已中奖: "Lottery win",
  到期自动清除积分: "Expired points cleared",
  分享奖励积分: "Share reward points",
  商品回收: "Item recycled",
  盲盒回收: "Blind box recycle",
  盲盒元气抵扣: "Blind box energy",
  开盒1次: "Open 1 box",
  浏览3个系列: "Browse 3 series",
  开盒3次: "Open 3 boxes",
  分享1次: "Share once",
  开盒10次: "Open 10 boxes",
  新人礼包: "Newcomer gift",
  宠物手办礼: "Pet daily gift",
  宠物喂养: "Pet feeding",
  桌宠默契: "Pet bond",
  桌宠默契·逗宠: "Bond · play",
  桌宠默契·零食: "Bond · snack",
  桌宠捡到积分: "Pet found points",
  桌宠解锁: "Unlocked desk pet",
  桌宠解锁买断: "Bought desk pet",
  桌宠解锁补差价: "Paid pet remainder",
  桌宠解锁·原进度保留: "Desk pet unlock · progress kept",
  后台调整: "Admin adjustment",
  农场播种本金返还: "Farm seed refund",
  农场旧积分周期清算: "Farm points settlement",
  游戏金币奖励: "Game coin reward",
  游戏继续费用: "Paid game continue",
};

const TITLE_ZH: Record<string, string> = {
  金币兑换积分: "金幣兌換積分",
  农场金币兑换积分: "農場金幣兌換積分",
  积分兑换农场金币: "積分兌換農場金幣",
  积分兑换金币: "積分兌換金幣",
  积分兑换矿币: "積分兌換礦幣",
  矿币兑换积分: "礦幣兌換積分",
  积分兑换贝壳币: "積分兌換貝殼幣",
  贝壳币兑换积分: "貝殼幣兌換積分",
  美元余额购买积分: "美元餘額購買積分",
  深渊矿洞奖励: "深淵礦洞獎勵",
  海底寻珠奖励: "海底尋珠獎勵",
  签到奖励: "簽到獎勵",
  盲盒每日签到: "盲盒每日簽到",
  盲盒每日任务: "盲盒每日任務",
  云购参与: "雲購參與",
  云购退回: "雲購退回",
  云购中奖积分: "雲購中獎積分",
  系统增加积分: "系統增加積分",
  系统减少积分: "系統減少積分",
  系统增加余额: "系統增加餘額",
  系统减少余额: "系統減少餘額",
  晒单奖励: "曬單獎勵",
  用户充值余额: "用戶充值餘額",
  用户充值退款: "用戶充值退款",
  会员日赠积分: "會員日贈積分",
  购买商品赠送积分: "購買商品贈送積分",
  下单赠送积分: "下單贈送積分",
  购物赠分入账: "購物贈分入賬",
  积分兑换商品: "積分兌換商品",
  兑换商品: "兌換商品",
  宠物手办礼: "寵物手辦禮",
  桌宠默契: "桌寵默契",
  桌宠默契·逗宠: "桌寵默契·逗寵",
  桌宠默契·零食: "桌寵默契·零食",
  桌宠捡到积分: "桌寵撿到積分",
  桌宠解锁: "桌寵解鎖",
  桌宠解锁买断: "桌寵解鎖買斷",
  桌宠解锁补差价: "桌寵解鎖補差價",
  桌宠解锁·原进度保留: "桌寵解鎖·原進度保留",
  后台调整: "後台調整",
};

const TYPE_EN: Record<string, string> = {
  sign: "Check-in reward",
  cloud_buy: "Cloud Buy entry",
  cloud_buy_refund: "Cloud Buy refund",
  draw_prize_points: "Cloud Buy prize points",
  game_wallet_points_to_coins: "Points to game coins",
  game_wallet_coins_to_points: "Game coins to points",
  shaidan_reward: "Showcase reward",
  system_add: "Admin credit",
  system_sub: "Admin debit",
  desk_pet_bond: "Bond",
  desk_pet_unlock: "Desk pet unlock",
  pet_found_points: "Pet found points",
  recharge: "Wallet top-up",
  member_daily: "Membership daily points",
  gain: "Bonus points",
  lottery_use: "Lottery entry",
  lottery_add: "Lottery prize points",
  storeIntegral_use: "Redeemed with points",
  farm_harvest: "Farm harvest",
  farm_steal: "Farm steal",
  farm_task: "Farm task",
  task_reward: "Blind box daily task",
  mine_dig: "Abyss Mine reward",
  pearl_open: "Pearl Lagoon reward",
  exchange: "Redeemed with points",
  checkin: "Blind box daily check-in",
  recovery: "Blind box recycle",
  point_purchase: "Bought points with USD",
  reward_coin_exchange: "Farm coins to points",
  agent_promo_grant: "Creator promo points",
};

const COIN_EN: Record<string, string> = {
  矿币: "mine coins",
  贝壳币: "shell coins",
  农场金币: "farm coins",
  金币: "farm coins",
};

function simplifyTitle(raw: string): string {
  let text = raw.trim().replace(/\s+/g, "");
  for (const [from, to] of TO_SIMPLIFIED) text = text.replace(from, to);
  return text;
}

function byExchangePattern(simplified: string, zh: boolean): string | null {
  const toPoints = simplified.match(/^(.+?)兑换积分$/);
  if (toPoints) {
    const coin = COIN_EN[toPoints[1]];
    if (coin) return zh ? `${TITLE_ZH[simplified] ?? simplified}` : `${capitalize(coin)} to points`;
  }
  const fromPoints = simplified.match(/^积分兑换(.+)$/);
  if (fromPoints) {
    const coin = COIN_EN[fromPoints[1]];
    if (coin) return zh ? `${TITLE_ZH[simplified] ?? simplified}` : `Points to ${coin}`;
  }
  return null;
}

function capitalize(value: string): string {
  return value ? value.charAt(0).toUpperCase() + value.slice(1) : value;
}

function byLooseHint(simplified: string, zh: boolean): string | null {
  if (simplified.includes("深渊矿洞")) return zh ? "深淵礦洞獎勵" : "Abyss Mine reward";
  if (simplified.includes("海底寻珠")) return zh ? "海底尋珠獎勵" : "Pearl Lagoon reward";
  if (simplified.includes("云购参与")) return zh ? "雲購參與" : "Cloud Buy entry";
  if (simplified.includes("美元") && simplified.includes("积分")) return zh ? "美元餘額購買積分" : "Bought points with USD";
  if (simplified.includes("签到奖励") || simplified === "签到") return zh ? "簽到獎勵" : "Check-in reward";
  if (simplified.includes("盲盒每日任务")) return zh ? "盲盒每日任務" : "Blind box daily task";
  if (simplified.includes("购物赠分入账")) return zh ? "購物贈分入賬" : "Purchase bonus points";
  if (simplified.includes("会员日赠入账") || simplified.includes("会员日赠积分")) return zh ? "會員日贈積分" : "Membership daily points";
  if (simplified.includes("晒单")) return zh ? "曬單獎勵" : "Showcase reward";
  if (simplified.includes("默契") && simplified.includes("零食")) return zh ? "桌寵默契·零食" : "Bond · snack";
  if (simplified.includes("默契")) return zh ? "桌寵默契·逗寵" : "Bond · play";
  if (simplified.includes("桌宠捡到")) return zh ? "桌寵撿到積分" : "Pet found points";
  if (simplified.includes("解锁买断")) return zh ? "桌寵解鎖買斷" : "Bought desk pet";
  if (simplified.includes("补差价")) return zh ? "桌寵解鎖補差價" : "Paid pet remainder";
  if (simplified.includes("桌宠解锁") || simplified.includes("原进度保留")) return zh ? "桌寵解鎖" : "Desk pet unlock";
  return null;
}

export function localizeAccountLogTitle(input: {
  title?: unknown;
  mark?: unknown;
  type?: unknown;
  zh: boolean;
}): string {
  const raw = String(input.title ?? "").trim();
  const type = String(input.type ?? "").trim();
  const simplified = simplifyTitle(raw);

  if (simplified) {
    if (input.zh && TITLE_ZH[simplified]) return TITLE_ZH[simplified];
    if (!input.zh && TITLE_EN[simplified]) return TITLE_EN[simplified];

    const patterned = byExchangePattern(simplified, input.zh);
    if (patterned) return patterned;

    const hinted = byLooseHint(simplified, input.zh);
    if (hinted) return hinted;
  }

  if (!input.zh && type && TYPE_EN[type]) return TYPE_EN[type];
  if (input.zh) return raw || simplified;
  if (!raw) return "Account entry";
  if (/[\u4e00-\u9fff]/.test(raw)) return "Account entry";
  return raw;
}
