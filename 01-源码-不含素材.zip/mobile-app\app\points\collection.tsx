import React, { useMemo } from "react";
import { Image, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useAddPointsCart, useDelPointsCollect, usePointsCollection } from "@/hooks";
import { normalizeImageUrl } from "@/lib/utils";
import { unwrapApiPagedList } from "@/lib/api/response";
import { useAuthStore } from "@/store/auth";

const TEAL = Colors.primary.DEFAULT;

export default function PointsCollectionScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const { data, isLoading } = usePointsCollection();
  const delCollect = useDelPointsCollect();
  const addCart = useAddPointsCart();

  const items = useMemo(() => {
    return unwrapApiPagedList<any>(data)
      .map((item: any) => ({
        id: Number(item.id ?? item.pid ?? item.product_id ?? 0),
        productId: Number(item.product_id ?? item.pid ?? item.id ?? 0),
        name: String(item.store_name ?? item.name ?? ""),
        image: normalizeImageUrl(String(item.image ?? "")),
        period: String(item.bianhao ?? ""),
        remain: Number(item.surplus ?? item.remain ?? 0),
      }))
      .filter((row: { id: number }) => row.id > 0);
  }, [data]);

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.myFavorites")} />
      <ScrollView contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}>
        {isLoading ? (
          <Text className="text-center text-gray-400 py-16">{t("common.loading")}</Text>
        ) : items.length === 0 ? (
          <View className="items-center py-16 px-8">
            <Text className="text-gray-400 text-center">{t("pointsMall.noFavorites")}</Text>
            <Pressable
              className="mt-4 h-10 px-4 rounded items-center justify-center"
              style={{ backgroundColor: TEAL }}
              onPress={() => router.push("/(tabs)/points")}
            >
              <Text className="text-white font-bold">{t("pointsMall.tabHome")}</Text>
            </Pressable>
          </View>
        ) : (
          items.map((item) => (
            <View key={item.id} className="flex-row bg-white px-3 py-3 border-b border-gray-100">
              <Pressable
                className="flex-1 flex-row"
                onPress={() =>
                  router.push({ pathname: "/points/product", params: { id: String(item.productId) } })
                }
              >
                <View className="w-16 h-16 bg-gray-50 rounded overflow-hidden mr-3">
                  {item.image ? (
                    <Image source={{ uri: item.image }} className="w-full h-full" resizeMode="contain" />
                  ) : null}
                </View>
                <View className="flex-1">
                  {item.period ? (
                    <Text className="text-[11px]" style={{ color: TEAL }}>
                      {t("pointsMall.periodN", { n: item.period })}
                    </Text>
                  ) : null}
                  <Text className="text-sm text-gray-900 mt-0.5" numberOfLines={2}>
                    {item.name || t("pointsMall.pointsProduct")}
                  </Text>
                </View>
              </Pressable>
              <View className="justify-center" style={{ gap: 6 }}>
                <Pressable
                  className="h-8 px-2 rounded items-center justify-center"
                  style={{ backgroundColor: TEAL }}
                  onPress={() => {
                    if (!isLoggedIn) {
                      router.push("/auth");
                      return;
                    }
                    addCart.mutate({ productId: item.productId, cartNum: 1 });
                  }}
                >
                  <Text className="text-white text-xs font-bold">{t("pointsMall.appendBuy")}</Text>
                </Pressable>
                <Pressable
                  className="h-8 px-2 rounded items-center justify-center border"
                  style={{ borderColor: "#E5E7EB" }}
                  onPress={() => delCollect.mutate({ id: item.id } as any)}
                >
                  <Text className="text-xs text-gray-500">{t("pointsMall.removeFavorite")}</Text>
                </Pressable>
              </View>
            </View>
          ))
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
