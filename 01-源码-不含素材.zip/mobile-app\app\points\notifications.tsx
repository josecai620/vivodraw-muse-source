import React, { useState } from "react";
import { Alert, Pressable, ScrollView, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import {
  TrendingUp,
  TrendingDown,
  Bell,
  Trash2,
} from "lucide-react-native";
import { useRouter } from "expo-router";
import { TealGradient, Colors, s } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { usePointsNotifications, useTongzhi, useDeleteTongzhi } from "@/hooks";
import { USE_DEV_MOCK_DATA } from "@/constants/env";

type NotificationType = "earn" | "spend" | "system";

interface Notification {
  id: number;
  type: NotificationType;
  title: string;
  content: string;
  time: string;
  isRead: boolean;
  points?: number;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: 1,
    type: "earn",
    title: "Points Earned",
    content: "You earned 500 points from purchase order #12345",
    time: "10 mins ago",
    isRead: false,
    points: 500,
  },
  {
    id: 2,
    type: "spend",
    title: "Points Redeemed",
    content: "You redeemed Wireless Headphones Pro for 3,500 points",
    time: "2 hours ago",
    isRead: false,
    points: -3500,
  },
  {
    id: 3,
    type: "system",
    title: "New Products Available",
    content: "Check out the latest premium products in Points Mall!",
    time: "5 hours ago",
    isRead: true,
  },
  {
    id: 4,
    type: "earn",
    title: "Daily Check-in Reward",
    content: "Congratulations! You earned 50 points for daily check-in",
    time: "1 day ago",
    isRead: true,
    points: 50,
  },
  {
    id: 5,
    type: "system",
    title: "Points Expiring Soon",
    content: "1,200 points will expire in 7 days. Use them before they expire!",
    time: "2 days ago",
    isRead: true,
  },
  {
    id: 6,
    type: "earn",
    title: "Review Reward",
    content: "Thanks for your review! You earned 100 bonus points",
    time: "3 days ago",
    isRead: true,
    points: 100,
  },
];

const ICON_CONFIG: Record<
  NotificationType,
  { Icon: typeof Bell; color: string; bg: string }
> = {
  earn: { Icon: TrendingUp, color: "#04A8AE", bg: "bg-teal-50" },
  spend: { Icon: TrendingDown, color: "#EF4444", bg: "bg-brand-red-light" },
  system: { Icon: Bell, color: Colors.brand.red, bg: "bg-brand-red-light" },
};

export default function PointsNotificationsScreen() {
  const router = useRouter();
  const { data } = usePointsNotifications();
  const { data: tongzhiData } = useTongzhi();
  const deleteTongzhi = useDeleteTongzhi();

  const rawLists: any[] = (data as any)?.data?.lists ?? (data as any)?.data?.list ?? [];
  const tongzhiObj = (tongzhiData as any)?.data ?? {};
  const categorySummary = [
    { key: "huangou", label: "Exchange Notices", type: "earn" as NotificationType, data: tongzhiObj.huangou },
    { key: "wuliu", label: "Shipping Notices", type: "system" as NotificationType, data: tongzhiObj.wuliu },
    { key: "shaidan", label: "Review Notices", type: "earn" as NotificationType, data: tongzhiObj.shaidan },
    { key: "zhongjiang", label: "Winning Notices", type: "earn" as NotificationType, data: tongzhiObj.zhongjiang },
  ].filter((c) => c.data);

  const apiNotifications: Notification[] = rawLists.map((item: any, i: number) => ({
    id: item.id ?? i,
    type: (item.type === "wuliu" ? "system" : item.type === "huangou" || item.type === "zhongjiang" || item.type === "shaidan" ? "earn" : "system") as NotificationType,
    title: item.title ?? item.type ?? "Notification",
    content: item.content ?? item.remark ?? "",
    time: item.add_time ?? "",
    isRead: false,
    points: item.points ?? undefined,
  }));
  const displayNotifications: Notification[] = apiNotifications.length > 0 ? apiNotifications : USE_DEV_MOCK_DATA ? MOCK_NOTIFICATIONS : [];
  const [notifications, setNotifications] = useState<Notification[]>(displayNotifications);
  const [hiddenIds, setHiddenIds] = useState<Set<number>>(new Set());

  const visibleNotifications = notifications.filter((n) => !hiddenIds.has(n.id));
  const unreadCount = visibleNotifications.filter((n) => !n.isRead).length + categorySummary.length;

  const markAsRead = (id: number) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)),
    );
  };

  const deleteNotification = (id: number) => {
    deleteTongzhi.mutate({ id });
    setHiddenIds((prev) => new Set(prev).add(id));
  };

  const clearAll = () => {
    deleteTongzhi.mutate({ type: "huangou" });
    deleteTongzhi.mutate({ type: "wuliu" });
    deleteTongzhi.mutate({ type: "shaidan" });
    deleteTongzhi.mutate({ type: "zhongjiang" });
    setHiddenIds(new Set(notifications.map((n) => n.id)));
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader
        title="Notifications"
        rightElement={
          visibleNotifications.length > 0 || categorySummary.length > 0 ? (
            <Pressable
              className="px-3 py-1.5 bg-white/20 rounded-lg"
              onPress={clearAll}
            >
              <Text className="text-xs font-semibold text-gray-700">
                Clear All
              </Text>
            </Pressable>
          ) : undefined
        }
      />

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Unread Banner */}
        {unreadCount > 0 && (
          <View className="px-4 pt-4">
            <View className="bg-neutral-50 border border-neutral-200 rounded-xl p-3 flex-row items-center gap-3">
              <View className="w-10 h-10 bg-teal-500 rounded-full items-center justify-center">
                <Bell size={s(20)} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-bold text-gray-900">
                  {unreadCount} Unread Notification{unreadCount > 1 ? "s" : ""}
                </Text>
                <Text className="text-xs text-gray-600">
                  Stay updated with your points activities
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* Category Summary */}
        {categorySummary.length > 0 && (
          <View className="px-4 pt-4 gap-2">
            {categorySummary.map((cat) => {
              const config = ICON_CONFIG[cat.type];
              return (
                <View key={cat.key} className="bg-white rounded-xl p-3 flex-row items-center gap-3 border border-gray-100">
                  <View className={`w-8 h-8 rounded-full ${config.bg} items-center justify-center`}>
                    <config.Icon size={16} color={config.color} />
                  </View>
                  <View className="flex-1">
                    <Text className="text-sm font-semibold text-gray-900">{cat.label}</Text>
                    <Text className="text-xs text-gray-500" numberOfLines={1}>{cat.data?.remark ?? cat.data?.content ?? cat.data?.add_time ?? ""}</Text>
                  </View>
                  <Pressable onPress={() => deleteTongzhi.mutate({ type: cat.key })} className="p-1.5">
                    <Trash2 size={14} color={Colors.neutral[400]} />
                  </Pressable>
                </View>
              );
            })}
          </View>
        )}

        {visibleNotifications.length === 0 && categorySummary.length === 0 ? (
          <View className="items-center justify-center px-8 py-20">
            <View className="w-32 h-32 rounded-full bg-gray-100 items-center justify-center mb-6">
              <Bell size={64} color={Colors.neutral[300]} />
            </View>
            <Text className="text-xl font-bold text-gray-900 mb-2">
              No Notifications
            </Text>
            <Text className="text-gray-500 text-center text-sm">
              You're all caught up! New notifications will appear here
            </Text>
          </View>
        ) : (
          <View className="px-4 pt-4 pb-6 gap-2">
            {visibleNotifications.map((notification) => {
              const config = ICON_CONFIG[notification.type];
              const IconComponent = config.Icon;

              return (
                <Pressable
                  key={notification.id}
                  onPress={() =>
                    !notification.isRead && markAsRead(notification.id)
                  }
                  className={`bg-white rounded-2xl overflow-hidden border ${
                    notification.isRead
                      ? "border-gray-100"
                      : "border-brand-red-light"
                  }`}
                >
                  <View className="p-4 flex-row gap-3">
                    {/* Icon */}
                    <View
                      className={`w-10 h-10 rounded-full ${config.bg} items-center justify-center`}
                    >
                      <IconComponent size={s(20)} color={config.color} />
                    </View>

                    {/* Content */}
                    <View className="flex-1">
                      <View className="flex-row items-start justify-between gap-2 mb-1">
                        <Text className="text-sm font-bold text-gray-900 flex-1">
                          {notification.title}
                        </Text>
                        {!notification.isRead && (
                          <View
                            className="w-2 h-2 rounded-full mt-1"
                            style={{ backgroundColor: Colors.brand.red }}
                          />
                        )}
                      </View>

                      <Text className="text-sm text-gray-600 mb-2 leading-5">
                        {notification.content}
                      </Text>

                      {notification.points != null && (
                        <View
                          className={`self-start flex-row items-center gap-1 px-2 py-1 rounded-lg ${
                            notification.points > 0
                              ? "bg-teal-50"
                              : "bg-brand-red-light"
                          }`}
                        >
                          <Text
                            className={`text-xs font-bold ${
                              notification.points > 0
                                ? "text-teal-700"
                                : "text-brand-red"
                            }`}
                          >
                            {notification.points > 0 ? "+" : ""}
                            {notification.points.toLocaleString()} pts
                          </Text>
                        </View>
                      )}

                      <View className="flex-row items-center justify-between mt-2">
                        <Text className="text-xs text-gray-400">
                          {notification.time}
                        </Text>
                        <Pressable
                          className="p-1.5 rounded-lg"
                          onPress={() => deleteNotification(notification.id)}
                        >
                          <Trash2 size={s(14)} color={Colors.neutral[400]} />
                        </Pressable>
                      </View>
                    </View>
                  </View>
                </Pressable>
              );
            })}
          </View>
        )}

        {/* Bottom Tip */}
        {visibleNotifications.length > 0 && (
          <View className="px-4 pb-6">
            <View className="rounded-xl overflow-hidden">
              <LinearGradient
                colors={[Colors.home.warmSurface, Colors.home.background]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <View className="p-4 border border-brand-red-light rounded-xl">
                  <View className="flex-row items-start gap-3">
                    <View className="w-10 h-10 overflow-hidden rounded-full items-center justify-center">
                      <LinearGradient
                        colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                        start={{ x: 0.5, y: 0 }}
                        end={{ x: 0.5, y: 1 }}
                        style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6, 
                          width: 40,
                          height: 40,
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                        <Bell size={s(20)} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
                      </LinearGradient>
                    </View>
                    <View className="flex-1">
                      <Text className="text-sm font-bold text-gray-900 mb-1">
                        Notification Settings
                      </Text>
                      <Text className="text-xs text-gray-600 leading-4 mb-2">
                        Manage your notification preferences to stay updated
                      </Text>
                      <Pressable onPress={() => router.push("/profile/settings")}>
                        <Text className="text-xs font-bold text-brand-red">
                          Go to Settings →
                        </Text>
                      </Pressable>
                    </View>
                  </View>
                </View>
              </LinearGradient>
            </View>
          </View>
        )}

        <View className="h-8" />
      </ScrollView>
    </View>
  );
}
