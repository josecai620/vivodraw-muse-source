import React from "react";
import { View, type StyleProp, type ViewStyle } from "react-native";
import { s } from "@/constants/theme";

interface MasonryGridProps<T> {
  data: T[];
  /** 渲染单个卡片；卡片宽度由列容器决定，不要再写固定百分比宽度 */
  renderItem: (item: T, index: number) => React.ReactNode;
  /** 列间距 / 纵向卡片间距，设计稿 = 10 */
  gap?: number;
  /** 左右内边距 */
  contentPadding?: number;
  style?: StyleProp<ViewStyle>;
}

/**
 * MasonryGrid —— 轻量双列瀑布流（无第三方依赖）。
 * 做法：按原始下标奇偶分到左右两列，两列各自纵向堆叠（gap），
 * 配合 ProductCard 内部按 id 交错的图片高度，得到稳定、无跳动的高低错落。
 */
export default function MasonryGrid<T>({
  data,
  renderItem,
  gap = 10,
  contentPadding = 16,
  style,
}: MasonryGridProps<T>) {
  const indexed = data.map((item, index) => ({ item, index }));
  const leftCells = indexed.filter((cell) => cell.index % 2 === 0);
  const rightCells = indexed.filter((cell) => cell.index % 2 !== 0);
  const g = s(gap);

  const renderColumn = (cells: typeof indexed) => (
    <View style={{ flex: 1, gap: g }}>
      {cells.map(({ item, index }) => (
        <React.Fragment key={index}>{renderItem(item, index)}</React.Fragment>
      ))}
    </View>
  );

  return (
    <View
      style={[
        { flexDirection: "row", gap: g, paddingHorizontal: s(contentPadding) },
        style,
      ]}
    >
      {renderColumn(leftCells)}
      {renderColumn(rightCells)}
    </View>
  );
}
