'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { optimizeHtml, versionChunkUrls, shellCss } = require('./优化网页首屏.cjs');
const script = fs.readFileSync(path.join(__dirname, '网页启动保护.js'), 'utf8');
function boot(options = {}) {
  const timers = new Map(), listeners = new Map();
  let nextTimer = 0, reloads = 0, removed = false, disconnected = false, mutate;
  const message = {}, retry = { hidden: true, addEventListener(name, fn) { this[name] = fn; } };
  const root = { textContent: options.text || '', querySelector() { return options.ready || false; } };
  const shell = { querySelector: s => s === 'button' ? retry : message, setAttribute() {}, remove() { removed = true; } };
  const window = { location: { reload() { reloads++; } }, addEventListener(n, f) { listeners.set(n, f); }, removeEventListener(n) { listeners.delete(n); } };
  vm.runInNewContext(script, {
    document: { getElementById: id => id === 'root' ? root : shell }, window,
    navigator: { language: options.language || 'en', onLine: options.online !== false },
    setTimeout(fn, ms) { const id = ++nextTimer; timers.set(id, {fn, ms}); return id; },
    clearTimeout(id) { timers.delete(id); },
    MutationObserver: class { constructor(fn) { mutate = fn; } observe() {} disconnect() { disconnected = true; } },
  });
  return {root, retry, message, timers, listeners, mutate, state: () => ({reloads, removed, disconnected}), emit: (n,e) => listeners.get(n)?.(e)};
}
const waiting = boot({ text: 'EN' });
assert.equal(waiting.state().removed, false, 'Language FAB must not count as loaded');
assert.equal(waiting.retry.hidden, true);
assert.equal([...waiting.timers.values()][0].ms, 12000);
[...waiting.timers.values()][0].fn();
assert.equal(waiting.retry.hidden, false);
assert.match(waiting.message.textContent, /keep waiting/);
assert.equal(waiting.state().reloads, 0, 'Never automatically reload');
waiting.retry.click(); assert.equal(waiting.state().reloads, 1);
waiting.root.textContent = 'Pocket Turbo Handheld Fan $39 Add to Cart Buy Now'; waiting.mutate();
assert.deepEqual(waiting.state(), {reloads:1,removed:true,disconnected:true});
assert.equal(waiting.listeners.size, 0); assert.equal(waiting.timers.size, 0);
const failure = boot();
failure.emit('error', {target:{tagName:'IMG',src:'/_expo/example.png'}}); assert.equal(failure.retry.hidden,true);
failure.emit('error', {target:{tagName:'SCRIPT',src:'/_expo/static/js/web/entry.js'}});
assert.match(failure.message.textContent,/interrupted/); assert.equal(failure.retry.hidden,false);
const offline = boot({online:false,language:'zh-CN'});
assert.match(offline.message.textContent,/沒有網路/); assert.equal(offline.retry.hidden,false);
assert.equal(boot({ready:true}).state().removed,true, 'Tabs/auth forms release startup overlay');
assert.equal(boot({text:'Something went wrong. Please try again.'}).state().removed,true);
const html = '<html><head><link rel="preload" href="/font.ttf" as="font" crossorigin="" /><style>@font-face{src:url(/font.ttf)}</style></head><body><div id="root"><div role="progressbar">original SSR</div></div>'+['runtime','common','entry'].map(x=>'<script src="/_expo/'+x+'.js" defer></script>').join('')+'</body></html>';
const result = optimizeHtml(html);
assert(result.includes('<div id="root"><div role="progressbar">original SSR</div></div>'));
assert.equal((result.match(/as="script"/g)||[]).length,3);
assert(!result.includes('as="font"')); assert(result.includes('@font-face'));
assert(result.indexOf('vivo-startup-guard') < result.indexOf('<script src='));
assert(result.includes('aria-live="polite"')); assert(shellCss.includes('prefers-reduced-motion'));
assert.throws(()=>optimizeHtml(result),/Already optimized/);
assert.throws(()=>optimizeHtml('<html></html>'),/Expected Expo root/);
assert.throws(()=>optimizeHtml(html,'</script>'),/must not close/);
assert(!/localStorage|sessionStorage|fetch\(|XMLHttpRequest/.test(script));
const chunk = '/_expo/static/js/web/[id]-abc123.js';
const entry = 'globalThis.map=JSON.parse(' + JSON.stringify(JSON.stringify({4453:chunk})) + ');';
const versioned = versionChunkUrls(entry, file => { assert.equal(file, chunk.slice(1)); return 'a'.repeat(64); });
const before = {}, after = {}; vm.runInNewContext(entry, before); vm.runInNewContext(versioned.output, after);
assert.deepEqual(Object.keys(after.map), Object.keys(before.map));
assert.equal(after.map[4453], before.map[4453] + '?v=' + 'a'.repeat(16));
assert.throws(() => versionChunkUrls(versioned.output, () => 'a'.repeat(64)), /No unversioned/);
assert.throws(() => versionChunkUrls(entry, () => 'bad'), /Invalid chunk/);
console.log('PASS: startup normal/slow/failure/offline/recovery/manual retry, route fallback, SSR preservation and HTML guard');
