import React from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useQuery } from "@tanstack/react-query";
import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

export default function CommissionOrdersScreen() {
  const { data, isLoading } = useQuery({
    queryKey: ["spreadOrder"],
    queryFn: () => http.post(API_ENDPOINTS.commission.spreadOrder, { page: 1, limit: 20 }),
  });

  const raw = (data as any)?.data ?? data;
  const list = raw?.list ?? raw ?? [];

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Commission Orders" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16) }} showsVerticalScrollIndicator={false}>
          {Array.isArray(list) && list.length > 0 ? (
            list.map((item: any, i: number) => (
              <View key={i} className="bg-white rounded-2xl p-4 mb-3 border border-gray-100">
                <Text className="font-medium" style={{ color: Colors.neutral[800] }}>Order #{item.order_id ?? item.id}</Text>
                <Text className="text-sm mt-1" style={{ color: Colors.brand.red }}>+${item.brokerage_price ?? item.price ?? "0"}</Text>
                <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }}>{item.add_time ?? ""}</Text>
              </View>
            ))
          ) : (
            <View className="flex-1 items-center justify-center py-12">
              <Text style={{ color: Colors.neutral[500] }}>No commission orders yet</Text>
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}
