import React from "react";
import { Image, Pressable, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { Colors } from "@/constants/theme";
import { useAuthStore } from "@/store/auth";
import { formatNumber } from "@/lib/utils";
import { resolveUserAvatarSource } from "@/lib/userAvatar";
import { usePointsBalance, useRedemptionList } from "@/hooks";
import {
  ChevronRight,
  ClipboardList,
  Gift,
  Heart,
  History,
  MessageSquare,
  Sparkles,
  UserRound,
} from "lucide-react-native";

const TEAL = Colors.primary.DEFAULT;

type Row = { label: string; route: string; Icon: typeof Gift; hint?: string };

export default function PointsPersonalCenterScreen() {
  const insets = useSafeAreaInsets();
  const { t } = useTranslation();
  const router = useRouter();
  const user = useAuthStore((s) => s.user);
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);

  const { data: pointsData } = usePointsBalance();
  const { data: redeemData } = useRedemptionList();

  const points = (pointsData as any)?.data?.integral ?? (pointsData as any)?.integral ?? user?.integral ?? 0;
  const luckyValue =
    Number((pointsData as any)?.data?.lucky_num ?? (pointsData as any)?.lucky_num ?? (user as any)?.lucky_num ?? 0) || 0;
  const redeemCount = Array.isArray((redeemData as any)?.data?.list)
    ? (redeemData as any).data.list.length
    : Array.isArray((redeemData as any)?.list)
      ? (redeemData as any).list.length
      : 0;

  const rows: Row[] = [
    { label: t("pointsMall.buyRecords"), route: "/points/exchange-records", Icon: ClipboardList },
    { label: t("pointsMall.wonGoods"), route: "/points/redemptions", Icon: Gift, hint: redeemCount ? String(redeemCount) : undefined },
    { label: t("pointsMall.luckyShop"), route: "/points/lucky-shop", Icon: Sparkles },
    { label: t("pointsMall.myFavorites"), route: "/points/collection", Icon: Heart },
    { label: t("pointsMall.showcasePlaza"), route: "/points/reviews", Icon: MessageSquare },
    { label: t("pointsMall.myShowcases"), route: "/points/reviews?tab=my", Icon: MessageSquare },
    { label: t("pointsMall.accountLog"), route: "/points/history", Icon: History },
  ];

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.tabMe")} />
      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}
      >
        <View className="mx-3 mt-3 rounded-2xl p-4 bg-white" style={{ borderWidth: 1, borderColor: Colors.screen.hairline }}>
          <View className="flex-row items-center">
            <Image source={resolveUserAvatarSource(user?.avatar, user?.uid)} style={{ width: 48, height: 48, borderRadius: 24 }} />
            <View className="flex-1 ml-3">
              <Text className="text-base font-bold text-gray-900">
                {user?.nickname || t("pointsCenter.pointsMember")}
              </Text>
              <Text className="text-xs text-gray-500 mt-0.5">
                {isLoggedIn ? t("pointsCenter.signedIn") : t("pointsCenter.notSignedIn")}
              </Text>
            </View>
            <Pressable hitSlop={12} onPress={() => router.push("/profile" as never)}>
              <Text className="text-xs font-semibold" style={{ color: TEAL }}>
                {t("pointsMall.goVivodrawProfile")}
              </Text>
            </Pressable>
          </View>

          <View className="flex-row mt-4" style={{ gap: 8 }}>
            <Pressable
              className="flex-1 rounded-xl p-3"
              style={{ backgroundColor: Colors.primary.softer }}
              onPress={() => router.push("/points/history" as never)}
            >
              <Text className="text-xs text-gray-500">{t("pointsMall.balance")}</Text>
              <Text className="text-xl font-black mt-1" style={{ color: TEAL }}>
                {formatNumber(points)}
              </Text>
              <Text className="text-[10px] text-gray-400 mt-1">{t("pointsMall.tapAccountLog")}</Text>
            </Pressable>
            <Pressable
              className="flex-1 rounded-xl p-3"
              style={{ backgroundColor: Colors.primary.softer }}
              onPress={() => router.push("/points/lucky-shop" as never)}
            >
              <View className="flex-row items-center" style={{ gap: 4 }}>
                <Sparkles size={12} color={TEAL} />
                <Text className="text-xs text-gray-500">{t("pointsMall.luckyValue")}</Text>
              </View>
              <Text className="text-[28px] font-black mt-1" style={{ color: TEAL }}>
                {formatNumber(luckyValue)}
              </Text>
              <Text className="text-[10px] text-gray-500 mt-1 leading-4">{t("pointsMall.luckyCardHint")}</Text>
              <Pressable hitSlop={8} onPress={() => router.push("/reveal/rules" as never)}>
                <Text className="text-[10px] font-bold mt-1" style={{ color: TEAL }}>
                  {t("pointsMall.rules")}
                </Text>
              </Pressable>
            </Pressable>
          </View>
        </View>

        <View className="mx-3 mt-3 rounded-2xl bg-white overflow-hidden" style={{ borderWidth: 1, borderColor: Colors.screen.hairline }}>
          {rows.map((row, idx) => {
            const Icon = row.Icon;
            return (
              <Pressable
                key={row.route}
                className="flex-row items-center px-4 py-3.5"
                style={{ borderTopWidth: idx ? 1 : 0, borderTopColor: "#F3F4F6" }}
                onPress={() => router.push(row.route as never)}
              >
                <Icon size={18} color={TEAL} />
                <Text className="ml-3 flex-1 text-sm text-gray-900">{row.label}</Text>
                {row.hint ? (
                  <View className="px-2 py-0.5 rounded-full mr-2" style={{ backgroundColor: Colors.primary.light }}>
                    <Text className="text-xs font-bold" style={{ color: TEAL }}>
                      {row.hint}
                    </Text>
                  </View>
                ) : null}
                <ChevronRight size={16} color="#919290" />
              </Pressable>
            );
          })}
        </View>

        <Pressable
          className="mx-3 mt-3 mb-4 rounded-2xl bg-white px-4 py-3.5 flex-row items-center"
          style={{ borderWidth: 1, borderColor: Colors.screen.hairline }}
          onPress={() => router.push("/(tabs)/profile" as never)}
        >
          <UserRound size={18} color={TEAL} />
          <Text className="ml-3 flex-1 text-sm text-gray-900">{t("pointsCenter.goToProfile")}</Text>
          <ChevronRight size={16} color="#919290" />
        </Pressable>
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
