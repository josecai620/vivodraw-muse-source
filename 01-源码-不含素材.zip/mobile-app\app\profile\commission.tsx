import React from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import {
  BookOpen,
  ChevronRight,
  DollarSign,
  Rocket,
  Share2,
  Trophy,
  UserPlus,
  Users,
} from "lucide-react-native";
import { useQuery } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

export default function CommissionScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const { data, isLoading } = useQuery({
    queryKey: ["commission"],
    queryFn: () => http.get(API_ENDPOINTS.commission.index),
  });
  const { data: agentData } = useQuery({
    queryKey: ["agentInfo"],
    queryFn: () => http.get(API_ENDPOINTS.commission.agentInfo),
  });

  const raw = (data as any)?.data ?? data;
  const totalEarned = raw?.total_commission ?? raw?.all_brokerage_price ?? "0";
  const extracted = raw?.extract_price ?? "0";

  const agentRaw = (agentData as any)?.data ?? agentData ?? {};
  const isAgent = agentRaw?.is_agent === 1 || agentRaw?.is_promoter === 1;
  const withdrawable = Number(agentRaw?.withdrawable ?? 0);
  const pending = Number(agentRaw?.pending_cooldown ?? 0);

  const entries = [
    ...(isAgent
      ? [
          {
            icon: Share2,
            tint: Colors.brand.red,
            title: t("commission.promoteCenter"),
            desc: t("commission.promoteCenterDesc"),
            to: "/profile/commission/promote",
          },
        ]
      : [
          {
            icon: UserPlus,
            tint: Colors.brand.red,
            title: t("commission.becomeAffiliate"),
            desc: t("commission.becomeAffiliateDesc"),
            to: "/profile/commission/apply",
          },
        ]),
    {
      icon: Users,
      tint: "#04A8AE",
      title: t("commission.myTeam"),
      desc: t("commission.myTeamDesc"),
      to: "/profile/commission/people",
    },
    {
      icon: DollarSign,
      tint: Colors.accent.orange,
      title: t("commission.commissionOrders"),
      desc: t("commission.commissionOrdersDesc"),
      to: "/profile/commission/orders",
    },
    {
      icon: Trophy,
      tint: "#04A8AE",
      title: t("commission.commissionRank"),
      desc: t("commission.commissionRankDesc"),
      to: "/profile/commission/rank",
    },
    {
      icon: Rocket,
      tint: "#04A8AE",
      title: t("commission.withdraw.title"),
      desc: "",
      to: "/profile/wallet/withdraw",
    },
    {
      icon: BookOpen,
      tint: "#04A8AE",
      title: t("commission.rules"),
      desc: t("commission.rulesDesc"),
      to: "/profile/commission/rules",
    },
  ] as const;

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("commission.title")} />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView
          className="flex-1"
          contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
          showsVerticalScrollIndicator={false}
        >
          <View className="bg-white rounded-2xl p-6 mb-4 border border-gray-100">
            <View className="flex-row justify-between mb-4">
              <View className="flex-1">
                <Text
                  className="text-sm"
                  style={{ color: Colors.neutral[500] }}
                >
                  {t("commission.balance.available")}
                </Text>
                <Text
                  className="text-2xl font-bold"
                  style={{ color: Colors.brand.red }}
                >
                  ${withdrawable.toFixed(2)}
                </Text>
              </View>
              <View className="items-end flex-1">
                <Text
                  className="text-sm"
                  style={{ color: Colors.neutral[500] }}
                >
                  {t("commission.balance.pending")}
                </Text>
                <Text
                  className="text-2xl font-bold"
                  style={{ color: Colors.accent.orange }}
                >
                  ${pending.toFixed(2)}
                </Text>
              </View>
            </View>
            {pending > 0 && (
              <Text
                className="text-xs mb-2"
                style={{ color: Colors.neutral[500] }}
              >
                {t("commission.balance.pendingHint")}
              </Text>
            )}
            <View className="pt-3 border-t border-gray-100 flex-row justify-between">
              <View>
                <Text
                  className="text-xs"
                  style={{ color: Colors.neutral[500] }}
                >
                  {t("commission.balance.total")}
                </Text>
                <Text
                  className="text-base font-semibold"
                  style={{ color: Colors.neutral[700] }}
                >
                  ${Number(totalEarned).toFixed(2)}
                </Text>
              </View>
              <View className="items-end">
                <Text
                  className="text-xs"
                  style={{ color: Colors.neutral[500] }}
                >
                  {t("commission.withdrawn")}
                </Text>
                <Text
                  className="text-base font-semibold"
                  style={{ color: Colors.neutral[700] }}
                >
                  ${Number(extracted).toFixed(2)}
                </Text>
              </View>
            </View>
          </View>

          {entries.map((e, i) => (
            <Pressable
              key={i}
              onPress={() => router.push(e.to as any)}
              className="bg-white rounded-2xl p-4 mb-3 flex-row items-center justify-between border border-gray-100"
            >
              <View className="flex-row items-center gap-3 flex-1">
                <View
                  className="w-10 h-10 rounded-xl items-center justify-center"
                  style={{ backgroundColor: `${e.tint}20` }}
                >
                  <e.icon size={s(22)} color={e.tint} />
                </View>
                <View className="flex-1">
                  <Text
                    className="font-semibold"
                    style={{ color: Colors.neutral[800] }}
                  >
                    {e.title}
                  </Text>
                  {e.desc ? (
                    <Text
                      className="text-sm"
                      style={{ color: Colors.neutral[500] }}
                    >
                      {e.desc}
                    </Text>
                  ) : null}
                </View>
              </View>
              <ChevronRight size={s(22)} color={Colors.neutral[400]} />
            </Pressable>
          ))}
        </ScrollView>
      )}
    </View>
  );
}
