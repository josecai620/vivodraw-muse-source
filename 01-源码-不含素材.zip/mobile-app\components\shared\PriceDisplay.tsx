import React from "react";
import { Text, View } from "react-native";
import { Colors, s } from "@/constants/theme";

interface PriceDisplayProps {
  price: number | string;
  originalPrice?: number | string;
  size?: "sm" | "md" | "lg";
  showDiscount?: boolean;
  currency?: string;
}

const SIZES = {
  sm: { price: 13, old: 10, discount: 9 },
  md: { price: 16, old: 13, discount: 11 },
  lg: { price: 28, old: 18, discount: 13 },
};

export default function PriceDisplay({
  price,
  originalPrice,
  size = "md",
  showDiscount = true,
  currency = "$",
}: PriceDisplayProps) {
  const p = typeof price === "string" ? parseFloat(price) : price;
  const op = originalPrice
    ? typeof originalPrice === "string"
      ? parseFloat(originalPrice)
      : originalPrice
    : 0;
  const hasDiscount = op > p;
  const discountPct = hasDiscount ? Math.round(((op - p) / op) * 100) : 0;
  const sz = SIZES[size];

  return (
    <View className="flex-row items-center gap-1.5">
      <Text
        className="font-bold"
        style={{ fontSize: s(sz.price), color: Colors.primary.DEFAULT, fontWeight: "800" }}
      >
        {currency}
        {p.toFixed(size === "lg" ? 2 : 0)}
      </Text>
      {hasDiscount && (
        <Text className="line-through" style={{ fontSize: s(sz.old), color: Colors.neutral[400] }}>
          {currency}
          {op.toFixed(size === "lg" ? 2 : 0)}
        </Text>
      )}
      {hasDiscount && showDiscount && size === "lg" && (
        <View
          className="px-2 py-0.5 rounded-md"
          style={{ backgroundColor: Colors.primary.softer }}
        >
          <Text className="font-bold" style={{ fontSize: s(sz.discount), color: Colors.primary.DEFAULT }}>
            -{discountPct}%
          </Text>
        </View>
      )}
    </View>
  );
}
