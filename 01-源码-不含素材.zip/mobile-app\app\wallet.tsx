import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import { MAX_RECHARGE_MINOR } from "@/lib/api/walletRecharge";
import { rechargeMinor } from "@/lib/game/rechargeRecovery";
import { useRechargeReturn } from "@/hooks/useRechargeReturn";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams, useRouter } from "expo-router";
import { CreditCard, RefreshCw } from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";

const QUICK_AMOUNTS = ["5.00", "10.00", "25.00"];

export default function WalletRechargeScreen() {
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const params = useLocalSearchParams<{
    game?: string | string[];
    pointPurchase?: string | string[];
    order_id?: string | string[];
    recharge?: string | string[];
  }>();
  const recharge = useRechargeReturn(params);
  const [amount, setAmount] = useState("10.00");
  const zh = i18n.language?.startsWith("zh");

  const minimum = Math.max(50, recharge.state?.min_recharge_minor ?? 50);
  const minor = rechargeMinor(amount);
  const canRecharge =
    recharge.canRecharge && (!!recharge.pending || (minor !== null && minor >= minimum));
  const availableCredit = recharge.state ? recharge.state.money_balance_minor / 100 : null;

  const messages = useMemo<Record<string, string>>(
    () => ({
      load_failed: t("walletRecharge.loadFailed"),
      storage: t("walletRecharge.storage"),
      wrong_account: t("walletRecharge.wrongAccount"),
      unconfirmed: t("walletRecharge.unconfirmed"),
      balance_unconfirmed: t("walletRecharge.balanceUnconfirmed"),
      paid: t("walletRecharge.paid"),
      invalid_amount: t("walletRecharge.invalidAmount", {
        min: (minimum / 100).toFixed(2),
        max: (MAX_RECHARGE_MINOR / 100).toFixed(2),
      }),
      invalid_saved_amount: t("walletRecharge.invalidSaved"),
      lock_unavailable: t("walletRecharge.lock"),
      request_changed: t("walletRecharge.requestChanged"),
      unavailable: t("walletRecharge.unavailable"),
      check_first: t("walletRecharge.checkFirst"),
      prepared_amount: t("walletRecharge.prepared"),
      checkout_unconfirmed: t("walletRecharge.checkoutUnconfirmed"),
      invalid_checkout: t("walletRecharge.invalidCheckout"),
      open_failed: t("walletRecharge.openFailed"),
    }),
    [t, minimum],
  );

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-neutral-50"
    >
      <PageHeader title={t("walletRecharge.title")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 120 }}
        keyboardShouldPersistTaps="handled"
      >
        {/* 余额卡 */}
        <LinearGradient
          colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          className="rounded-3xl p-5"
        >
          <Text className="text-white/80 text-xs font-semibold">{t("walletRecharge.available")}</Text>
          <Text className="text-white text-4xl font-bold mt-1">
            {availableCredit === null ? "—" : `$${availableCredit.toFixed(2)}`}
          </Text>
          {recharge.returnGame ? (
            <Text className="text-white/85 text-xs mt-3 leading-4">
              {zh ? "充值美元餘額 → 購買積分 → 兌換遊戲幣" : "Add USD balance → Buy points → Exchange for game coins"}
            </Text>
          ) : null}
        </LinearGradient>

        {/* 充值面板 */}
        <View className="bg-white rounded-2xl p-5 gap-4">
          <View className="flex-row items-center">
            <CreditCard size={18} color={Colors.brand.red} />
            <Text className="text-base font-bold text-neutral-900 ml-2">
              {t("walletRecharge.stripeTitle")}
            </Text>
          </View>
          <Text className="text-xs text-neutral-500 leading-4">{t("walletRecharge.stripeCopy")}</Text>

          <View className="flex-row gap-2">
            {QUICK_AMOUNTS.map((a) => (
              <Pressable
                key={a}
                disabled={recharge.starting || !!recharge.pending}
                onPress={() => setAmount(a)}
                className="flex-1 h-10 rounded-full border items-center justify-center"
                style={{
                  borderColor: amount === a ? Colors.brand.red : "rgba(12,31,31,0.08)",
                  backgroundColor: amount === a ? "#ECFBFB" : "#fff",
                }}
              >
                <Text
                  className="text-sm font-bold"
                  style={{ color: amount === a ? Colors.brand.redDark : Colors.neutral[600] }}
                >
                  ${a}
                </Text>
              </Pressable>
            ))}
          </View>

          <TextInput
            inputMode="decimal"
            keyboardType="decimal-pad"
            value={recharge.pending ? (recharge.pending.amount_minor / 100).toFixed(2) : amount}
            editable={!recharge.starting && !recharge.pending}
            onChangeText={setAmount}
            placeholder="10.00"
            placeholderTextColor={Colors.neutral[400]}
            className="w-full h-14 bg-neutral-50 border border-neutral-200 rounded-xl px-4 text-2xl font-bold text-neutral-900"
          />
          <Text className="text-xs text-neutral-400">
            {t("walletRecharge.range", {
              min: (minimum / 100).toFixed(2),
              max: (MAX_RECHARGE_MINOR / 100).toFixed(2),
            })}
          </Text>

          <Pressable disabled={!canRecharge} onPress={() => void recharge.start(amount)}>
            <LinearGradient
              colors={
                canRecharge
                  ? [TealGradient.light, TealGradient.base, TealGradient.dark]
                  : [Colors.neutral[300], Colors.neutral[300]]
              }
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              className="h-12 rounded-xl items-center justify-center"
            >
              {recharge.starting ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : (
                <Text className="text-white font-bold text-base">
                  {recharge.pending
                    ? t("walletRecharge.continueSame")
                    : t("walletRecharge.addFunds")}
                </Text>
              )}
            </LinearGradient>
          </Pressable>

          {recharge.message ? (
            <Text className="text-sm leading-5" style={{ color: Colors.error }}>
              {messages[recharge.message] ?? recharge.message}
            </Text>
          ) : null}
          {recharge.order ? (
            <Text className="text-xs text-neutral-400" selectable>
              {t("walletRecharge.orderNo")}: {recharge.order}
            </Text>
          ) : null}

          {!recharge.signedIn && recharge.ready ? (
            <Pressable
              className="h-12 rounded-xl border border-neutral-200 items-center justify-center"
              onPress={() => router.push("/auth")}
            >
              <Text className="font-semibold text-neutral-700">{t("walletRecharge.signInToAdd")}</Text>
            </Pressable>
          ) : null}

          <Pressable
            className="h-10 flex-row items-center justify-center"
            disabled={recharge.loading || recharge.starting}
            onPress={() => void recharge.refresh()}
          >
            <RefreshCw size={14} color={Colors.neutral[500]} />
            <Text className="text-sm text-neutral-500 ml-2">
              {recharge.loading
                ? t("walletRecharge.checking")
                : recharge.order
                  ? t("walletRecharge.checkStatus")
                  : t("walletRecharge.reload")}
            </Text>
          </Pressable>

          {recharge.returnGame ? (
            <Pressable
              disabled={!recharge.canReturnToPurchase}
              className="h-12 rounded-xl items-center justify-center"
              style={{ backgroundColor: Colors.brand.red }}
              onPress={() => router.push(`/point-purchase?game=${recharge.returnGame}`)}
            >
              <Text className="text-white font-bold">{t("walletRecharge.returnToBuy")}</Text>
            </Pressable>
          ) : null}
        </View>

        <Pressable
          className="h-12 rounded-xl bg-white border border-neutral-200 items-center justify-center"
          onPress={() => router.push("/profile/wallet")}
        >
          <Text className="font-semibold text-neutral-700">{t("walletRecharge.fullWallet")}</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
