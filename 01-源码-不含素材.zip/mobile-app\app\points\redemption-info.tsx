import React, { useEffect, useMemo, useState } from "react";
import { Alert, Pressable, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useFocusEffect } from "@react-navigation/native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { Colors } from "@/constants/theme";
import { getAddressList, type Address } from "@/lib/api/address";
import { unwrapApiPagedList } from "@/lib/api/response";
import { useConfirmHuandeAddress, useHuandeInfo } from "@/hooks";

const TEAL = Colors.primary.DEFAULT;

export default function PointsRedemptionInfoScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const infoId = Number(id ?? 0);
  const { data, refetch } = useHuandeInfo(infoId);
  const detail = (data as any)?.data?.detail ?? {};
  const address = (data as any)?.data?.address ?? null;
  const confirmAddress = useConfirmHuandeAddress();
  const needsAddress = Number(detail?.status) === 1 && !address;

  const { data: addressData, refetch: refetchAddress } = useQuery({
    queryKey: ["addresses"],
    queryFn: getAddressList,
    enabled: needsAddress,
  });
  const addresses = useMemo(() => unwrapApiPagedList<Address>(addressData), [addressData]);
  const [selectedAddressId, setSelectedAddressId] = useState(0);

  useFocusEffect(
    React.useCallback(() => {
      refetch();
      if (needsAddress) refetchAddress();
    }, [refetch, refetchAddress, needsAddress]),
  );

  useEffect(() => {
    if (selectedAddressId > 0 || !needsAddress) return;
    const def = addresses.find((a: any) => Number(a?.is_default) === 1);
    if (def?.id) setSelectedAddressId(Number(def.id));
    else if (addresses[0]?.id) setSelectedAddressId(Number(addresses[0].id));
  }, [addresses, selectedAddressId, needsAddress]);

  const onConfirm = async () => {
    if (!selectedAddressId) {
      Alert.alert(t("common.notice"), t("pointsMall.pickAddressFirst"));
      return;
    }
    await confirmAddress.mutateAsync({ id: infoId, addressId: selectedAddressId });
  };

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.wonGoods")} />
      <ScrollView contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 72 }}>
        <View className="bg-white mx-3 mt-3 rounded-xl p-4">
          <Text className="text-base font-bold text-gray-900">{detail?.store_name ?? t("pointsMall.pointsProduct")}</Text>
          <Text className="text-xs mt-1" style={{ color: TEAL }}>
            {t("pointsMall.periodN", { n: detail?.bianhao ?? "-" })}
          </Text>
          <Text className="text-sm text-gray-600 mt-2">
            {t("pointsMall.luckyCode")}：{detail?.zj_unique ?? detail?.unique ?? "-"}
          </Text>
          <Text className="text-xs text-gray-500 mt-1">
            {t("pointsMall.revealTime")}：{detail?.zhongjiang_time ?? "-"}
          </Text>
        </View>

        <View className="bg-white mx-3 mt-3 rounded-xl p-4">
          <Text className="text-sm font-bold text-gray-900 mb-2">{t("pointsMall.shipAddress")}</Text>
          {address ? (
            <>
              <Text className="text-sm text-gray-800">{address?.real_name} {address?.phone}</Text>
              <Text className="text-sm text-gray-600 mt-1">
                {[address?.province, address?.city, address?.district, address?.detail].filter(Boolean).join(" ")}
              </Text>
            </>
          ) : needsAddress ? (
            <View style={{ gap: 8 }}>
              {addresses.map((item: any) => {
                const on = Number(item?.id) === selectedAddressId;
                return (
                  <Pressable
                    key={item?.id}
                    className="rounded-lg border p-3"
                    style={{ borderColor: on ? TEAL : "#E5E7EB", backgroundColor: on ? Colors.primary.softer : "#fff" }}
                    onPress={() => setSelectedAddressId(Number(item?.id))}
                  >
                    <Text className="text-sm font-semibold text-gray-900">
                      {item?.real_name} {item?.phone}
                    </Text>
                    <Text className="text-xs text-gray-600 mt-1">
                      {[item?.province, item?.city, item?.district, item?.detail].filter(Boolean).join(" ")}
                    </Text>
                  </Pressable>
                );
              })}
              {addresses.length === 0 ? (
                <Text className="text-sm text-gray-500">{t("pointsMall.noAddressGoProfile")}</Text>
              ) : null}
              <Pressable className="h-10 rounded items-center justify-center" style={{ borderWidth: 1, borderColor: TEAL }} onPress={() => router.push("/profile/address")}>
                <Text className="text-sm font-bold" style={{ color: TEAL }}>
                  {t("pointsCenter.goToProfile")}
                </Text>
              </Pressable>
            </View>
          ) : (
            <Text className="text-sm text-gray-500">{t("pointsMall.waitAddress")}</Text>
          )}
        </View>

        {Number(detail?.status) >= 3 ? (
          <Pressable
            className="mx-3 mt-3 h-11 rounded items-center justify-center"
            style={{ backgroundColor: TEAL }}
            onPress={() =>
              router.push({
                pathname: "/points/shaidan-post",
                params: { productId: String(detail?.product_id ?? ""), name: String(detail?.store_name ?? "") },
              } as never)
            }
          >
            <Text className="text-white font-bold">{t("pointsMall.postShowcase")}</Text>
          </Pressable>
        ) : null}
      </ScrollView>

      {needsAddress ? (
        <View style={{ position: "absolute", left: 12, right: 12, bottom: pointsMallTabPaddingBottom(insets.bottom) }}>
          <Pressable
            className="h-12 rounded items-center justify-center"
            style={{ backgroundColor: TEAL }}
            onPress={onConfirm}
            disabled={confirmAddress.isPending}
          >
            <Text className="text-white font-bold">
              {confirmAddress.isPending ? t("common.submitting") : t("pointsMall.confirmAddress")}
            </Text>
          </Pressable>
        </View>
      ) : null}
      <PointsMallTabBar />
    </View>
  );
}
