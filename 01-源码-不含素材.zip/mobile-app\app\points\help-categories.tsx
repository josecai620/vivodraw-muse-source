import React from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { BookOpen, ShieldQuestion, Truck, Wallet } from "lucide-react-native";
import { PageHeader } from "@/components/shared";
import { Colors } from "@/constants/theme";

export default function PointsHelpCategoriesScreen() {
  const { t } = useTranslation();
  const router = useRouter();

  const HELP_CATEGORIES = [
    { id: 1, title: t("helpCenter.pointsRules"),   desc: t("helpCenter.pointsRulesDesc"),   Icon: BookOpen },
    { id: 2, title: t("helpCenter.redeemFlow"),    desc: t("helpCenter.redeemFlowDesc"),    Icon: Truck },
    { id: 3, title: t("helpCenter.accountIssues"), desc: t("helpCenter.accountIssuesDesc"), Icon: ShieldQuestion },
    { id: 4, title: t("helpCenter.cashback"),      desc: t("helpCenter.cashbackDesc"),      Icon: Wallet },
  ];

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("helpCenter.title")} />
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="p-4 gap-3">
          {HELP_CATEGORIES.map((item) => (
            <Pressable
              key={item.id}
              className="bg-white rounded-2xl border border-gray-100 p-4"
              onPress={() =>
                router.push({
                  pathname: "/points/help",
                  params: { cid: String(item.id), title: item.title },
                } as any)
              }
            >
              <View className="flex-row items-start gap-3">
                <View
                  className="w-10 h-10 rounded-xl items-center justify-center"
                  style={{ backgroundColor: `${Colors.brand.red}15` }}
                >
                  <item.Icon size={20} color={Colors.brand.red} />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-gray-900">{item.title}</Text>
                  <Text className="text-xs text-gray-500 mt-1">{item.desc}</Text>
                </View>
              </View>
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}
