import type { EnergyWaveEffectConfig, ExplosionEffectConfig } from './VFXConfig';

export class EnergyWaveEffect { // EnergyWaveEffect：能量波效果配置组件
  constructor(public config: EnergyWaveEffectConfig) {} // config：能量波配置

  setConfig(config: Partial<EnergyWaveEffectConfig>) {
    this.config = { ...this.config, ...config }; // config：合并后的能量波配置
  }
}

export class ExplosionEffect { // ExplosionEffect：爆闪效果配置组件
  constructor(public config: ExplosionEffectConfig) {} // config：爆闪配置

  setConfig(config: Partial<ExplosionEffectConfig>) {
    this.config = { ...this.config, ...config }; // config：合并后的爆闪配置
  }
}

export class EnergyRing { // EnergyRing：能量波系统
  readonly energyWaveEffect: EnergyWaveEffect; // energyWaveEffect：能量波组件
  readonly explosionEffect: ExplosionEffect; // explosionEffect：爆闪组件

  constructor(energy: EnergyWaveEffectConfig, explosion: ExplosionEffectConfig) {
    this.energyWaveEffect = new EnergyWaveEffect(energy);
    this.explosionEffect = new ExplosionEffect(explosion);
  }
}
