# codemod-teal.ps1
# Upgrade flat two-stop <LinearGradient colors={[Colors.brand.red, Colors.brand.redDark]}>
# to three-stop teal gradient with a top white gloss. Self-closing progress bars are skipped.
# Usage: powershell -File codemod-teal.ps1 -Path <file> [-Override @{ 0='lr'; 1='tb' }]
param(
  [Parameter(Mandatory=$true)][string]$Path,
  [hashtable]$Override = @{}
)

$utf8 = New-Object System.Text.UTF8Encoding($false)
$L = New-Object System.Collections.ArrayList
$L.AddRange([System.IO.File]::ReadAllLines($Path))

$glossTemplate = '<LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />'

function Get-Dir($blockText, $idx) {
  if ($blockText -match 'rounded-full|aspect-square') { return 'tb' }
  if ($blockText -match 'width:\s*\d+') { return 'tb' }
  if ($blockText -match 'className="[^"]*\bp-[0-9]' -or $blockText -match 'padding:\s*\d+') { return 'tb' }
  if ($idx % 2 -eq 0) { return 'lr' } else { return 'rl' }
}
$DIRMAP = @{
  'lr' = @('start={{ x: 0, y: 0.5 }}','end={{ x: 1, y: 0.5 }}');
  'rl' = @('start={{ x: 1, y: 0.5 }}','end={{ x: 0, y: 0.5 }}');
  'tb' = @('start={{ x: 0.5, y: 0 }}','end={{ x: 0.5, y: 1 }}');
  'bt' = @('start={{ x: 0.5, y: 1 }}','end={{ x: 0.5, y: 0 }}');
}

$targets = @()
for ($i=0; $i -lt $L.Count; $i++) {
  if ($L[$i] -match 'colors=\{\[Colors\.brand\.red, Colors\.brand\.redDark\]\}') { $targets += $i }
}
$btnIdx = 0
$changed = 0
for ($t=$targets.Count-1; $t -ge 0; $t--) {
  $i = $targets[$t]
  $j = $i
  $selfClose = $false
  $foundClose = $false
  while ($j -lt $L.Count -and $j -lt $i+30) {
    $tr = $L[$j].TrimEnd()
    if ($tr -match '/>\s*$') { $selfClose=$true; $foundClose=$true; break }
    if ($tr -match '[^/]\>\s*$' -or $tr -eq '>') { $foundClose=$true; break }
    $j++
  }
  if ($selfClose) { continue }
  if (-not $foundClose) { continue }
  $block = ($L[$i..$j] -join ' ')
  $seq = $btnIdx; $btnIdx++
  $dir = if ($Override.ContainsKey($seq)) { $Override[$seq] } else { Get-Dir $block $seq }
  $d = $DIRMAP[$dir]
  $indent = ($L[$i] -replace '^(\s*).*$','$1')
  $L[$i] = $L[$i] -replace 'colors=\{\[Colors\.brand\.red, Colors\.brand\.redDark\]\}', 'colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}'
  for ($k=$i; $k -le $j; $k++) {
    if ($L[$k] -match 'start=\{\{') { $L[$k] = $L[$k] -replace 'start=\{\{[^}]*\}\}[^,]*', ($d[0]) }
    if ($L[$k] -match 'end=\{\{')   { $L[$k] = $L[$k] -replace 'end=\{\{[^}]*\}\}[^,]*', ($d[1]) }
  }
  $g = $indent + '  ' + $glossTemplate
  $L.Insert($j+1, $g)
  $changed++
}

$txt = ($L -join "`n")
if ($changed -gt 0 -and $txt -notmatch 'TealGradient,|TealGradient \}') {
  for ($i=0;$i -lt $L.Count;$i++){
    if ($L[$i] -match 'from "@/constants/theme"') {
      if ($L[$i] -match 'import \{([^}]*)\} from "@/constants/theme"') {
        $names = $Matches[1]
        if ($names -notmatch 'TealGradient') { $L[$i] = $L[$i] -replace 'import \{', 'import { TealGradient,' }
      }
      break
    }
  }
}

[System.IO.File]::WriteAllLines($Path, $L, $utf8)
Write-Output ("{0} -> upgraded {1}" -f (Split-Path $Path -Leaf), $changed)
