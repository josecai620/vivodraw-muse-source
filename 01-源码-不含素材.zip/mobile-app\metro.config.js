const { getDefaultConfig } = require("expo/metro-config");
const { withNativeWind } = require("nativewind/metro");

const config = getDefaultConfig(__dirname);
if (!config.resolver.assetExts.includes("svga")) {
  config.resolver.assetExts.push("svga");
}

module.exports = withNativeWind(config, { input: "./global.css" });
