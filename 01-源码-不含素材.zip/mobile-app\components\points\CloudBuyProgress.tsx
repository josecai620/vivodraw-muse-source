import { Colors } from "@/constants/theme";
import React from "react";
import { Text, View } from "react-native";

const TEAL = Colors.primary.DEFAULT;
const TEAL_DARK = Colors.primary.dark;

/** 参考实现进度三字段：已参与 / 总需 / 剩余。纯色条，无动画。 */
export default function CloudBuyProgress({
  joined,
  total,
  remain,
  joinedLabel,
  totalLabel,
  remainLabel,
}: {
  joined: number;
  total: number;
  remain: number;
  joinedLabel?: string;
  totalLabel?: string;
  remainLabel?: string;
}) {
  const pct = total > 0 ? Math.max(2, Math.min(100, (joined / Math.max(total, 1)) * 100)) : 0;
  return (
    <View>
      <View
        style={{
          height: 6,
          borderRadius: 3,
          backgroundColor: Colors.neutral[100],
          overflow: "hidden",
        }}
      >
        <View
          style={{
            height: "100%",
            width: `${pct}%`,
            borderRadius: 3,
            backgroundColor: TEAL,
          }}
        />
      </View>
      <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 4 }}>
        <Text style={{ fontSize: 10, fontWeight: "700", color: TEAL }}>
          {joined}
          {joinedLabel ? `\u00A0${joinedLabel}` : ""}
        </Text>
        <Text style={{ fontSize: 10, color: "#9CA3AF" }}>
          {total}
          {totalLabel ? `\u00A0${totalLabel}` : ""}
        </Text>
        <Text style={{ fontSize: 10, fontWeight: "700", color: TEAL_DARK }}>
          {remain}
          {remainLabel ? `\u00A0${remainLabel}` : ""}
        </Text>
      </View>
    </View>
  );
}
