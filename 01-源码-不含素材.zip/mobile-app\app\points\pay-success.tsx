import React, { useMemo, useState } from "react";
import { Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { CheckCircle, ChevronRight } from "lucide-react-native";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useAddPointsCart, useAddPointsCollect } from "@/hooks";
import { QTY_PRESETS } from "@/lib/points/cloudBuyCart";
import { toNum } from "@/lib/points/cloudBuyParse";
import { Colors } from "@/constants/theme";

const TEAL = Colors.primary.DEFAULT;
const ORANGE = Colors.primary.dark;

type Bought = {
  productId: number;
  name: string;
  image: string;
  bianhao: string;
  shares: number;
  remain: number;
};

function parseBought(raw: string | undefined): Bought[] {
  try {
    const parsed = JSON.parse(decodeURIComponent(String(raw ?? "[]")));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    try {
      const parsed = JSON.parse(String(raw ?? "[]"));
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
}

export default function CloudBuyPaySuccessScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { items: itemsParam } = useLocalSearchParams<{ items?: string }>();
  const addToCart = useAddPointsCart();
  const addCollect = useAddPointsCollect();
  const bought = useMemo(() => parseBought(Array.isArray(itemsParam) ? itemsParam[0] : itemsParam), [itemsParam]);
  const [qtyMap, setQtyMap] = useState<Record<number, string>>({});

  const remainOf = (row: Bought) => Math.max(0, toNum(row.remain));
  const qtyOf = (row: Bought) => {
    const left = remainOf(row);
    if (left <= 0) return "0";
    return qtyMap[row.productId] ?? "1";
  };

  const commitQty = (row: Bought, raw: string | number) => {
    const left = remainOf(row);
    if (left <= 0) {
      setQtyMap((m) => ({ ...m, [row.productId]: "0" }));
      return 0;
    }
    let n = Math.floor(Number(raw) || 1);
    n = Math.max(1, Math.min(left, n));
    setQtyMap((m) => ({ ...m, [row.productId]: String(n) }));
    return n;
  };

  const onAppend = (row: Bought) => {
    if (!row.productId) return;
    const left = remainOf(row);
    if (left <= 0) return;
    const n = commitQty(row, qtyOf(row));
    if (n < 1) return;
    addToCart.mutate(
      { productId: row.productId, cartNum: n },
      {
        onSuccess: () => router.push("/points/pay" as never),
        onError: (e: any) => Alert.alert(t("common.error"), e?.message ?? "Failed"),
      },
    );
  };

  return (
    <View className="flex-1 bg-white">
      <PageHeader title={t("pointsMall.payResult")} />
      <ScrollView
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 16 }}
      >
        <View className="items-center px-6 pt-8 pb-5">
          <CheckCircle size={36} color="#22c55e" />
          <Text className="text-center text-[15px] font-semibold text-gray-800 mt-3">
            {t("pointsMall.paySuccessWait")}
          </Text>
        </View>

        <View className="flex-row px-4 mb-5" style={{ gap: 12 }}>
          <Pressable
            className="flex-1 h-11 items-center justify-center rounded"
            style={{ backgroundColor: TEAL }}
            onPress={() => router.push("/points/exchange-records" as never)}
          >
            <Text className="text-white font-bold">{t("pointsMall.viewDetail")}</Text>
          </Pressable>
          <Pressable
            className="flex-1 h-11 items-center justify-center rounded"
            style={{ backgroundColor: ORANGE }}
            onPress={() => {
              const first = bought[0];
              if (!first?.productId) return;
              addCollect.mutate({ id: first.productId });
            }}
          >
            <Text className="text-white font-bold">{t("pointsMall.collect")}</Text>
          </Pressable>
        </View>

        <View className="flex-row items-center justify-center mb-2">
          <View className="flex-1 h-px bg-gray-100 mx-4" />
          <Text className="text-xs text-gray-500">
            {t("pointsMall.buyRecordN", { n: bought.length || 1 })}
          </Text>
          <View className="flex-1 h-px bg-gray-100 mx-4" />
        </View>

        {bought.map((row) => {
          const qty = qtyOf(row);
          const remain = remainOf(row);
          return (
            <View key={`${row.productId}-${row.bianhao}`} className="px-3 py-3 border-b border-gray-50">
              <Pressable
                className="flex-row items-center"
                onPress={() =>
                  router.push({ pathname: "/points/product", params: { id: String(row.productId) } })
                }
              >
                {row.image ? (
                  <Image source={row.image} style={{ width: 56, height: 56 }} contentFit="contain" />
                ) : (
                  <View style={{ width: 56, height: 56, backgroundColor: "#f3f3f3" }} />
                )}
                <View className="flex-1 ml-3">
                  <Text className="text-[13px] text-gray-800" numberOfLines={2}>
                    {row.bianhao ? `(${t("pointsMall.periodN", { n: row.bianhao })})` : ""}
                    {row.name}
                  </Text>
                  <Text className="text-xs mt-1" style={{ color: ORANGE }}>
                    {t("pointsMall.thisJoinRemain", { n: row.shares, left: row.remain })}
                  </Text>
                </View>
                <ChevronRight size={16} color="#ccc" />
              </Pressable>

              {remain > 0 ? (
              <View className="flex-row items-center mt-3" style={{ gap: 6 }}>
                <TextInput
                  value={qty}
                  keyboardType="number-pad"
                  onChangeText={(v) =>
                    setQtyMap((m) => ({ ...m, [row.productId]: v.replace(/[^\d]/g, "") || "1" }))
                  }
                  onBlur={() => commitQty(row, qty)}
                  style={{
                    width: 48,
                    height: 32,
                    borderWidth: 1,
                    borderColor: "#ddd",
                    textAlign: "center",
                    color: ORANGE,
                    fontWeight: "700",
                    borderRadius: 4,
                  }}
                />
                {QTY_PRESETS.map((n) => (
                  <Pressable
                    key={n}
                    onPress={() => commitQty(row, Math.min(n, remain))}
                    className="h-8 px-2.5 border border-gray-200 rounded items-center justify-center"
                  >
                    <Text className="text-xs text-gray-700">{n}</Text>
                  </Pressable>
                ))}
                <Pressable
                  onPress={() => commitQty(row, remain)}
                  className="h-8 px-2.5 border rounded items-center justify-center"
                  style={{ borderColor: "#ddd" }}
                >
                  <Text className="text-xs text-gray-700">{t("pointsMall.allIn")}</Text>
                </Pressable>
                <Pressable
                  onPress={() => onAppend(row)}
                  className="h-8 px-3 items-center justify-center rounded"
                  style={{ backgroundColor: TEAL }}
                >
                  <Text className="text-white text-xs font-bold">{t("pointsMall.appendBuy")}</Text>
                </Pressable>
              </View>
              ) : null}
            </View>
          );
        })}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
