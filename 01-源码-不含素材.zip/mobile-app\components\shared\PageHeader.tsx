import { Colors, Shadows, s } from "@/constants/theme";
import { useRouter } from "expo-router";
import { ChevronLeft } from "lucide-react-native";
import type React from "react";
import { Pressable, Text, View, type ViewStyle } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface PageHeaderProps {
  title: string;
  showBack?: boolean;
  onBackPress?: () => void;
  rightElement?: React.ReactNode;
  transparent?: boolean;
  inverted?: boolean;
  style?: ViewStyle;
}

export default function PageHeader({
  title,
  showBack = true,
  onBackPress,
  rightElement,
  transparent = false,
  inverted = false,
  style,
}: PageHeaderProps) {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const bg = transparent ? "transparent" : inverted ? "#050816" : Colors.screen.bg;
  const titleColor = inverted ? "#eef1ff" : "#171A1A";
  const iconBg = inverted ? "rgba(255,255,255,0.12)" : "#FFFFFF";
  const iconColor = inverted ? "#eef1ff" : "#171A1A";

  return (
    <View
      style={[
        {
          paddingTop: insets.top,
          backgroundColor: bg,
        },
        style,
      ]}
    >
      <View
        style={{
          height: s(52),
          paddingHorizontal: s(12),
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        {showBack ? (
          <Pressable
            hitSlop={10}
            onPress={
              onBackPress ??
              (() => {
                if (router.canGoBack()) router.back();
              })
            }
            style={{
              width: s(38),
              height: s(38),
              borderRadius: s(19),
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: iconBg,
              ...(inverted ? null : Shadows.raisedSm),
            }}
          >
            <ChevronLeft size={s(24)} color={iconColor} strokeWidth={2} />
          </Pressable>
        ) : (
          <View style={{ width: s(38) }} />
        )}
        <Text
          style={{
            fontSize: s(17),
            lineHeight: s(22),
            color: titleColor,
            fontWeight: "800",
            flexShrink: 1,
            textAlign: "center",
            paddingHorizontal: s(8),
          }}
          numberOfLines={1}
        >
          {title}
        </Text>
        {rightElement ?? <View style={{ width: s(38) }} />}
      </View>
    </View>
  );
}
