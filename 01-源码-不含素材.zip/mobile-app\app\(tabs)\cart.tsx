import { LuxeIcon, PageHeader } from "@/components/shared";
import { Colors, s, Shadows } from "@/constants/theme";
import TealSurface from "@/components/ui/TealSurface";
import { useCartList, useRemoveFromCart, useUpdateCartNum } from "@/hooks";
import { normalizeImageUrl } from "@/lib/utils";
import { useAuthStore } from "@/store/auth";
import { useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { Check, Minus, Plus, Trash2 } from "lucide-react-native";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Image,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function CartScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const isLoggedIn = useAuthStore((st) => st.isLoggedIn);

  const { data: cartRaw, isLoading } = useCartList();
  const removeMutation = useRemoveFromCart();
  const updateNumMutation = useUpdateCartNum();

  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);
  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["cart"] }),
      queryClient.invalidateQueries({ queryKey: ["cartCount"] }),
    ]);
    setRefreshing(false);
  };

  const validItems = cartRaw?.valid ?? [];
  const displayItems = validItems.length > 0 ? validItems : [];

  if (!isLoggedIn) {
    return (
      <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
        <PageHeader title={t("cart.title")} showBack={false} />
        <View className="flex-1 items-center justify-center px-6">
          <LuxeIcon glyph="cart" tone="gold" size={88} iconSize={58} />
          <Text className="text-xl font-bold text-gray-900 mt-4 mb-2">
            {t("cart.pleaseSignIn")}
          </Text>
          <Text className="text-sm text-center mb-6" style={{ color: Colors.neutral[400] }}>
            {t("cart.signInToView")}
          </Text>
          <Pressable
            onPress={() => router.push("/auth")}
            style={({ pressed }) => [Shadows.teal, { transform: [{ scale: pressed ? 0.97 : 1 }] }]}
          >
            <TealSurface direction="tb" radius={12} style={{ alignSelf: "center" }} contentStyle={{ height: 44, paddingHorizontal: 24, alignItems: "center", justifyContent: "center" }}>
              <Text className="text-white font-semibold" style={{ backgroundColor: "transparent" }}>{t("cart.signIn")}</Text>
            </TealSurface>
          </Pressable>
        </View>
      </View>
    );
  }

  if (isLoading) {
    return (
      <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
        <PageHeader title={t("cart.title")} showBack={false} />
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      </View>
    );
  }

  if (displayItems.length === 0) {
    return (
      <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
        <PageHeader title={t("cart.title")} showBack={false} />
        <View className="flex-1 items-center justify-center px-6">
          <View className="mb-4">
            <LuxeIcon glyph="cart" tone="gold" size={112} iconSize={72} />
          </View>
          <Text className="text-xl font-bold text-gray-900 mb-2">{t("cart.emptyCart")}</Text>
          <Text className="text-sm text-center mb-6" style={{ color: Colors.neutral[400] }}>
            {t("cart.emptyCartDesc")}
          </Text>
          <Pressable
            onPress={() => router.replace("/(tabs)")}
            style={({ pressed }) => [Shadows.teal, { transform: [{ scale: pressed ? 0.97 : 1 }] }]}
          >
            <TealSurface direction="bt" radius={12} style={{ alignSelf: "center" }} contentStyle={{ height: 44, paddingHorizontal: 24, alignItems: "center", justifyContent: "center" }}>
              <Text className="text-white font-semibold" style={{ backgroundColor: "transparent" }}>{t("cart.startShopping")}</Text>
            </TealSurface>
          </Pressable>
        </View>
      </View>
    );
  }

  const subtotal = displayItems.reduce((sum, item) => {
    const price = Number(item.productInfo?.attrInfo?.price ?? item.productInfo?.price ?? 0);
    return sum + price * (item.cart_num ?? 1);
  }, 0);
  const shipping = subtotal > 50 ? 0 : 5.99;
  const total = subtotal + shipping;

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("cart.title")} showBack={false} />

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        bounces={false}
        overScrollMode="never"
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#04A8AE" />
        }
      >
        <View className="px-4 py-4 gap-3">
          {displayItems.map((item) => {
            const info = item.productInfo ?? {};
            const attrInfo = info.attrInfo;
            const img = attrInfo?.image || info.image || "";
            const name = info.store_name || t("cart.product");
            const price = Number(attrInfo?.price ?? info.price ?? 0);
            const sku = attrInfo?.suk || "";

            return (
              <View
                key={item.id}
                className="bg-white rounded-2xl p-3"
                style={[{ borderWidth: 1, borderColor: Colors.screen.hairline }, Shadows.raisedSm]}
              >
                <View className="flex-row gap-3">
                  <Image
                    source={{ uri: normalizeImageUrl(img) }}
                    className="w-20 h-20 rounded-xl bg-gray-100"
                    resizeMode="cover"
                  />
                  <View className="flex-1">
                    <Text className="font-semibold text-sm text-gray-900 mb-0.5" numberOfLines={2}>
                      {name}
                    </Text>
                    {sku ? (
                      <Text className="text-xs mb-1" style={{ color: Colors.neutral[400] }}>
                        {sku}
                      </Text>
                    ) : null}
                    <Text className="text-base font-bold mb-2" style={{ color: Colors.brand.red }}>
                      ${price.toFixed(2)}
                    </Text>

                    <View className="flex-row items-center justify-between">
                      <View className="flex-row items-center gap-2 px-2 py-1 bg-gray-50 rounded-lg">
                        <Pressable
                          onPress={() =>
                            updateNumMutation.mutate({
                              id: item.id,
                              num: Math.max(1, (item.cart_num ?? 1) - 1),
                            })
                          }
                        >
                          <LuxeIcon Icon={Minus} tone="neutral" variant="soft" size={26} iconSize={13} />
                        </Pressable>
                        <Text className="w-6 text-center text-sm font-semibold">
                          {item.cart_num ?? 1}
                        </Text>
                        <Pressable
                          onPress={() =>
                            updateNumMutation.mutate({
                              id: item.id,
                              num: (item.cart_num ?? 1) + 1,
                            })
                          }
                        >
                          <LuxeIcon Icon={Plus} tone="brand" variant="soft" size={26} iconSize={13} />
                        </Pressable>
                      </View>

                      <Pressable className="p-1.5" onPress={() => removeMutation.mutate([item.id])}>
                        <LuxeIcon Icon={Trash2} tone="neutral" variant="soft" size={30} iconSize={15} />
                      </Pressable>
                    </View>
                  </View>
                </View>
              </View>
            );
          })}
        </View>

        <View className="h-40" />
      </ScrollView>

      {/* Bottom Bar */}
      <View
        className="absolute bottom-0 left-0 right-0 bg-white"
        style={{
          paddingBottom: insets.bottom + 8,
          borderTopWidth: 1,
          borderTopColor: Colors.screen.hairline,
          shadowColor: "#0C1F1F",
          shadowOffset: { width: 0, height: -6 },
          shadowOpacity: 0.06,
          shadowRadius: 16,
          elevation: 12,
        }}
      >
        <View className="px-4 py-2 flex-row items-center justify-between">
          <View>
            <Text className="text-xs" style={{ color: Colors.neutral[500] }}>
              {t("cart.total")}
            </Text>
            <Text className="text-xl font-bold" style={{ color: Colors.brand.red }}>
              ${total.toFixed(2)}
            </Text>
          </View>
          <Pressable
            onPress={() => router.push("/checkout")}
            style={({ pressed }) => [Shadows.teal, { transform: [{ scale: pressed ? 0.97 : 1 }] }]}
          >
            <TealSurface direction="lr" radius={12} style={{ alignSelf: "center" }} contentStyle={{ height: 48, paddingHorizontal: 32, alignItems: "center", justifyContent: "center" }}>
              <Text className="text-white font-semibold" style={{ backgroundColor: "transparent" }}>
                {t("cart.checkout", { count: displayItems.length })}
              </Text>
            </TealSurface>
          </Pressable>
        </View>
      </View>
    </View>
  );
}
