import React from "react";
import { Pressable, Text, View } from "react-native";
import { ChevronRight } from "lucide-react-native";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import type { CloudBuyPeriod } from "@/lib/points/cloudBuyParse";
import { WinnerAvatar } from "@/components/reveal/WinnerBadges";

const TEAL = Colors.primary.DEFAULT;

/** 对齐参考实现 `#prevPeriod` 上期获得者卡片；色调用 Vivodraw Teal。 */
export default function CloudBuyPrevWinner({
  winner,
  onPress,
}: {
  winner: CloudBuyPeriod;
  onPress: () => void;
}) {
  const { t } = useTranslation();
  return (
    <Pressable
      onPress={onPress}
      className="mx-2 mt-2 mb-3 bg-white flex-row items-center"
      style={{
        borderWidth: 1,
        borderColor: Colors.screen.hairline,
        borderRadius: 8,
        padding: 10,
      }}
    >
      <View style={{ marginRight: 10 }}>
        <WinnerAvatar
          uri={winner.avatar || undefined}
          uid={winner.uid || undefined}
          seed={winner.nickname || winner.bianhao}
          size={70}
          variant="prev"
          rounded="square"
        />
      </View>
      <View className="flex-1">
        <Text className="text-sm font-semibold mb-0.5" style={{ color: TEAL }} numberOfLines={1}>
          {winner.nickname || t("pointsMall.anonymous")}
        </Text>
        <Text className="text-[11px] text-gray-500">
          {t("pointsMall.prevTotalShares")}:{" "}
          <Text style={{ color: TEAL }}>{winner.shares || "-"}</Text>
          {t("pointsMall.shareUnit")}
        </Text>
        <Text className="text-[11px] text-gray-500">
          {t("pointsMall.luckyCode")}：
          <Text style={{ color: Colors.primary.dark }}>{winner.unique || "-"}</Text>
        </Text>
        <Text className="text-[11px] text-gray-500">
          {t("pointsMall.revealTime")}：{winner.revealAt || "-"}
        </Text>
        <Text className="text-[11px] text-gray-500">
          {t("pointsMall.joinTime")}：{winner.buyAt || "-"}
        </Text>
      </View>
      <ChevronRight size={16} color="#9CA3AF" />
    </Pressable>
  );
}
