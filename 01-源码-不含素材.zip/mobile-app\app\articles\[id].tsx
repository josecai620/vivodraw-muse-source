import React from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { getArticleDetail } from "@/lib/api/article";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

function stripHtml(html: string): string {
  return html.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
}

export default function ArticleDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const articleId = id ? parseInt(id, 10) : 0;

  const { data, isLoading } = useQuery({
    queryKey: ["articleDetail", articleId],
    queryFn: () => getArticleDetail(articleId),
    enabled: articleId > 0,
  });

  const raw = (data as any)?.data ?? data ?? {};
  const content = raw.content ?? raw.article_content ?? raw.detail ?? "";
  const title = raw.title ?? raw.title_zh ?? "Article";
  const plainText = content ? stripHtml(content) : "";

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Article" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }} showsVerticalScrollIndicator={false}>
          <Text className="text-xl font-bold mb-4" style={{ color: Colors.neutral[900] }}>
            {title}
          </Text>
          {plainText ? (
            <Text className="text-base leading-6" style={{ color: Colors.neutral[700] }}>
              {plainText}
            </Text>
          ) : (
            <Text style={{ color: Colors.neutral[600] }}>No content</Text>
          )}
        </ScrollView>
      )}
    </View>
  );
}
