import React, { useState } from "react";
import {
  Alert,
  Dimensions,
  Modal,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Trophy, Star, Sparkles, TrendingUp, Crown, Coins, Headphones, Gem, Watch, Gift, Banknote, Speaker, Smile, Target, type LucideIcon } from "lucide-react-native";
import { TealGradient, Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { useLotteryInfo, useDrawLottery, useLotteryRecord } from "@/hooks";

const { width: SCREEN_WIDTH } = Dimensions.get("window");
const GRID_GAP = 12;
const CELL_SIZE = (SCREEN_WIDTH - 32 - 32 - 4 - GRID_GAP * 2) / 3;

interface Prize {
  id: number;
  name: string;
  Icon: LucideIcon;
  bgColors: [string, string];
  type: "points" | "product" | "button" | "empty";
  value?: number;
}

const PRIZES: Prize[] = [
  { id: 1, name: "50 Points", Icon: Coins, bgColors: ["#04A8AE", "#04A8AE"], type: "points", value: 50 },
  { id: 2, name: "Headphones", Icon: Headphones, bgColors: ["#04A8AE", "#04A8AE"], type: "product" },
  { id: 3, name: "100 Points", Icon: Gem, bgColors: ["#04A8AE", "#04A8AE"], type: "points", value: 100 },
  { id: 4, name: "Smart Watch", Icon: Watch, bgColors: ["#04A8AE", "#04A8AE"], type: "product" },
  { id: 5, name: "GO", Icon: Target, bgColors: [Colors.brand.red, Colors.brand.redDark], type: "button" },
  { id: 6, name: "Gift Card $10", Icon: Gift, bgColors: ["#04A8AE", "#04A8AE"], type: "product" },
  { id: 7, name: "200 Points", Icon: Banknote, bgColors: ["#04A8AE", "#04A8AE"], type: "points", value: 200 },
  { id: 8, name: "Bluetooth Speaker", Icon: Speaker, bgColors: ["#04A8AE", "#04A8AE"], type: "product" },
  { id: 9, name: "Thank You", Icon: Smile, bgColors: ["#919290", "#787976"], type: "empty" },
];

const RECENT_WINNERS = [
  { user: "User***123", prize: "Smart Watch", time: "2 mins ago" },
  { user: "User***456", prize: "200 Points", time: "5 mins ago" },
  { user: "User***789", prize: "Headphones", time: "8 mins ago" },
];

const DRAW_HISTORY = [
  { date: "2026-03-06 14:30", prize: "50 Points", status: "Won" as const, claimed: true },
  { date: "2026-03-06 10:15", prize: "Thank You", status: "Miss" as const, claimed: false },
  { date: "2026-03-05 18:20", prize: "100 Points", status: "Won" as const, claimed: true },
  { date: "2026-03-05 12:45", prize: "Headphones", status: "Won" as const, claimed: false },
];

export default function PointsLotteryScreen() {
  const [currentPoints, setCurrentPoints] = useState(12580);
  const [isSpinning, setIsSpinning] = useState(false);
  const [showPrizeModal, setShowPrizeModal] = useState(false);
  const [wonPrize, setWonPrize] = useState<Prize | null>(null);

  const { data: lotteryData } = useLotteryInfo();
  const drawLottery = useDrawLottery();
  const { data: recordData } = useLotteryRecord();

  const realPrizes = (lotteryData as any)?.data?.list ?? (lotteryData as any)?.list ?? [];
  const displayPrizes = realPrizes.length > 0 ? realPrizes : PRIZES;

  const realRecords = (recordData as any)?.data?.list ?? (recordData as any)?.list ?? [];
  const displayRecords = realRecords.length > 0 ? realRecords : DRAW_HISTORY;

  const handleDraw = async () => {
    if (currentPoints < 100) {
      Alert.alert("Insufficient Points", "You need 100 points to draw.");
      return;
    }

    setIsSpinning(true);
    try {
      await drawLottery.mutateAsync();
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 1500));

    const availablePrizes = displayPrizes.filter((p: any) => p.type !== "button");
    const randomPrize = availablePrizes[Math.floor(Math.random() * availablePrizes.length)];

    setWonPrize(randomPrize);
    setCurrentPoints((prev) => prev - 100);
    setIsSpinning(false);
    setShowPrizeModal(true);
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Lucky Draw" />

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* 剩余积分 */}
        <View className="px-4 mt-4 mb-5">
          <LinearGradient
            colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
            start={{ x: 0.5, y: 0 }}
            end={{ x: 0.5, y: 1 }}
            className="p-5"
            style={{
              borderRadius: 24,
              overflow: "hidden",
              shadowColor: "#04A8AE",
              shadowOffset: { width: 0, height: 10 },
              shadowOpacity: 0.3,
              shadowRadius: 20,
              elevation: 10,
            }}
          >
              <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
            <View className="flex-row items-center justify-between">
              <View>
                <Text className="text-xs text-white/80 mb-1">Available Points</Text>
                <View className="flex-row items-center gap-2">
                  <Trophy size={28} color="#171A1A" />
                  <Text className="text-4xl font-bold text-white tracking-tight">
                    {currentPoints.toLocaleString()}
                  </Text>
                </View>
              </View>
              <View className="items-end">
                <Text className="text-xs text-white/80 mb-1">Cost per Draw</Text>
                <View className="px-3 py-1.5 bg-white/10 rounded-full flex-row items-center">
                  <Text className="text-lg font-bold" style={{ color: "#04A8AE" }}>
                    100
                  </Text>
                  <Text className="text-xs text-white ml-1">pts</Text>
                </View>
              </View>
            </View>
          </LinearGradient>
        </View>

        {/* 中奖滚动条 */}
        <View className="mb-5 bg-neutral-100 px-4 py-2.5 border-y border-neutral-200">
          <View className="flex-row flex-wrap gap-x-2 gap-y-1">
            {RECENT_WINNERS.map((winner, index) => (
              <View key={index} className="flex-row items-center gap-1">
                <Star size={12} color="#171A1A" fill="#171A1A" />
                <Text className="text-xs text-gray-700">
                  <Text className="font-bold">{winner.user}</Text>
                  {" won "}
                  <Text className="font-bold" style={{ color: Colors.brand.red }}>
                    {winner.prize}
                  </Text>
                </Text>
                {index < RECENT_WINNERS.length - 1 && (
                  <Text className="text-gray-400 mx-1">·</Text>
                )}
              </View>
            ))}
          </View>
        </View>

        {/* 九宫格抽奖 */}
        <View className="px-4 mb-6">
          <View
            className="bg-brand-red-light rounded-3xl p-4 border-2 border-brand-red-light"
            style={{
              shadowColor: "#0C1F1F",
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.12,
              shadowRadius: 16,
              elevation: 8,
            }}
          >
            <View className="flex-row flex-wrap" style={{ gap: GRID_GAP }}>
              {displayPrizes.map((prize: any) => (
                <Pressable
                  key={prize.id}
                  onPress={prize.type === "button" ? handleDraw : undefined}
                  disabled={prize.type !== "button" || isSpinning}
                >
                  <LinearGradient
                    colors={prize.bgColors}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    className="items-center justify-center"
                    style={{
                      borderRadius: 16,
                      overflow: "hidden",
                      width: CELL_SIZE,
                      height: CELL_SIZE,
                      shadowColor: prize.type === "button" ? Colors.brand.red : "#000",
                      shadowOffset: { width: 0, height: 4 },
                      shadowOpacity: prize.type === "button" ? 0.3 : 0.1,
                      shadowRadius: prize.type === "button" ? 12 : 6,
                      elevation: prize.type === "button" ? 6 : 2,
                    }}
                  >
                    <prize.Icon size={30} color="#FFFFFF" strokeWidth={2} />
                    <Text
                      className="text-xs font-bold text-white text-center px-1 mt-1"
                      numberOfLines={1}
                    >
                      {prize.name}
                    </Text>
                    {isSpinning && prize.type !== "button" && (
                      <View className="absolute inset-0 bg-white/20" />
                    )}
                  </LinearGradient>
                </Pressable>
              ))}
            </View>
          </View>

          <View className="mt-4 items-center">
            <Text className="text-sm text-gray-600">
              Tap{" "}
              <Text className="font-bold" style={{ color: Colors.brand.red }}>
                GO
              </Text>{" "}
              to start the lucky draw
            </Text>
            <Text className="text-xs text-gray-400 mt-1">100 points per draw</Text>
          </View>
        </View>

        {/* 我的抽奖记录 */}
        <View className="px-4 pb-8">
          <View className="flex-row items-center gap-2 mb-3">
            <TrendingUp size={16} color={Colors.brand.red} />
            <Text className="text-sm font-bold text-gray-900">My Draw History</Text>
          </View>
          <View
            className="bg-white rounded-2xl overflow-hidden"
            style={{
              shadowColor: "#0C1F1F",
              shadowOpacity: 0.04,
              shadowRadius: 2,
              shadowOffset: { width: 0, height: 1 },
              elevation: 1,
            }}
          >
            {displayRecords.map((record: any, index: number) => (
              <View
                key={index}
                className={`flex-row items-center justify-between px-4 py-3 ${
                  index !== displayRecords.length - 1 ? "border-b border-gray-100" : ""
                }`}
              >
                <View className="flex-row items-center gap-3">
                  <View
                    className={`w-10 h-10 rounded-full items-center justify-center ${
                      record.status === "Won" ? "bg-teal-50" : "bg-gray-50"
                    }`}
                  >
                    {record.status === "Won" ? (
                      <Star size={18} color="#04A8AE" fill="#04A8AE" />
                    ) : (
                      <Sparkles size={18} color="#919290" />
                    )}
                  </View>
                  <View>
                    <Text className="text-sm font-medium text-gray-900">{record.prize}</Text>
                    <Text className="text-xs text-gray-500">{record.date}</Text>
                  </View>
                </View>
                <View className="items-end">
                  {record.status === "Won" && !record.claimed && (
                    <Pressable>
                      <LinearGradient
                        colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                        start={{ x: 1, y: 0.5 }}
                        end={{ x: 0, y: 0.5 }}
                        className="px-3 py-1.5"
                        style={{ borderRadius: 8, overflow: "hidden" }}
                      >
                          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                        <Text className="text-white text-xs font-bold">Claim</Text>
                      </LinearGradient>
                    </Pressable>
                  )}
                  {record.status === "Won" && record.claimed && (
                    <Text className="text-xs text-teal-600 font-medium">Claimed</Text>
                  )}
                  {record.status === "Miss" && (
                    <Text className="text-xs text-gray-400">Better luck next time</Text>
                  )}
                </View>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>

      {/* 中奖弹窗 */}
      <Modal
        visible={showPrizeModal && !!wonPrize}
        transparent
        animationType="fade"
        statusBarTranslucent
        onRequestClose={() => setShowPrizeModal(false)}
      >
        <View
          className="flex-1 items-center justify-center p-4"
          style={{ backgroundColor: "rgba(0,0,0,0.6)" }}
        >
          <View
            className="bg-white rounded-3xl p-8 items-center"
            style={{
              width: "100%",
              maxWidth: 360,
              shadowColor: "#0C1F1F",
              shadowOffset: { width: 0, height: 16 },
              shadowOpacity: 0.25,
              shadowRadius: 24,
              elevation: 12,
            }}
          >
            <View className="mb-4">
              <LinearGradient
                colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                start={{ x: 0.5, y: 0 }}
                end={{ x: 0.5, y: 1 }}
                className="items-center justify-center"
                style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6,  width: 80, height: 80, borderRadius: 40 }}
              >
                  <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.32)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                <Crown size={40} color="#fff"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
              </LinearGradient>
            </View>

            <Text className="text-2xl font-bold text-gray-900 mb-2">Congratulations!</Text>
            <Text className="text-gray-600 mb-6">You won</Text>

            <View className="bg-brand-red-light rounded-2xl p-6 w-full items-center mb-6">
              {wonPrize?.Icon ? <wonPrize.Icon size={56} color="#04A8AE" strokeWidth={1.8} /> : null}
              <Text className="text-xl font-bold text-gray-900 mt-3">{wonPrize?.name}</Text>
              {wonPrize?.type === "points" && (
                <Text className="text-sm text-gray-600 mt-1">Added to your balance</Text>
              )}
            </View>

            <Pressable className="w-full" onPress={() => setShowPrizeModal(false)}>
              <LinearGradient
                colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                start={{ x: 0.5, y: 0 }}
                end={{ x: 0.5, y: 1 }}
                className="items-center justify-center"
                style={{
                  borderRadius: 12,
                  overflow: "hidden",
                  height: 48,
                  shadowColor: Colors.brand.red,
                  shadowOffset: { width: 0, height: 8 },
                  shadowOpacity: 0.3,
                  shadowRadius: 12,
                  elevation: 6,
                }}
              >
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                <Text className="text-white font-bold text-base">
                  {wonPrize?.type === "points" ? "Awesome!" : "Claim Prize"}
                </Text>
              </LinearGradient>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}
