import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  ScrollView,
  Pressable,
  ActivityIndicator,
  Modal,
  FlatList,
  Alert,
} from "react-native";
import { Image } from "expo-image";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { Users, Gift, Star, Box, X, Send } from "lucide-react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { BoxHeader, RarityBadge, BoxActionButton, BoxEmptyState, BoxTabBar } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  getRarityTier, bs,
} from "@/lib/boxTheme";
import { useFriendBoxList, useFriendGift, useBoxList } from "@/hooks";
import { useAppStore } from "@/store/app";

export default function FriendsPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const showToast = useAppStore((s) => s.showToast);
  const { data: friends = [], isLoading } = useFriendBoxList();
  const giftMutation = useFriendGift();
  const { data: boxListData } = useBoxList();

  const [giftModal, setGiftModal] = useState<{ visible: boolean; friendUid: number; friendName: string }>({
    visible: false,
    friendUid: 0,
    friendName: "",
  });

  const myItems = (boxListData?.list || []).filter((b: any) => b.status === 0 || b.status === "0");

  const openGiftModal = useCallback((uid: number, name: string) => {
    setGiftModal({ visible: true, friendUid: uid, friendName: name });
  }, []);

  const handleGift = useCallback(
    (userBoxId: number) => {
      Alert.alert(
        t("friends.confirmGiftTitle"),
        t("friends.confirmGiftMsg", { name: giftModal.friendName }),
        [
          { text: t("common.cancel"), style: "cancel" },
          {
            text: t("common.confirm"),
            onPress: () => {
              giftMutation.mutate(
                { friendUid: giftModal.friendUid, userBoxId },
                {
                  onSuccess: () => {
                    showToast(t("friends.giftSuccess"), "success");
                    setGiftModal({ visible: false, friendUid: 0, friendName: "" });
                  },
                  onError: () => showToast(t("friends.giftFail"), "error"),
                }
              );
            },
          },
        ]
      );
    },
    [giftModal, giftMutation, showToast, t]
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("friends.title")} showThemeToggle={false} />

      <ScrollView contentContainerStyle={{ padding: BoxSpacing.lg, paddingBottom: BoxSpacing["4xl"] }}>
        {isLoading ? (
          <ActivityIndicator size="large" color={BoxAccent.gold} style={{ marginTop: bs(60) }} />
        ) : friends.length === 0 ? (
          <BoxEmptyState
            icon={<Users size={bs(48)} color={BoxText.tertiary} />}
            title={t("friends.empty")}
            description={t("friends.emptySub")}
          />
        ) : (
          friends.map((friend: any) => {
            const rarityConfig = getRarityTier(friend.maxRarity);
            return (
              <View
                key={friend.uid}
                style={{
                  backgroundColor: BoxSurfaces.card,
                  borderRadius: BoxRadius.xl,
                  borderWidth: 1,
                  borderColor: BoxBorders.default,
                  padding: BoxSpacing.lg,
                  marginBottom: BoxSpacing.md,
                  ...BoxShadows.card,
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.md }}>
                  {friend.avatar ? (
                    <Image
                      source={{ uri: friend.avatar }}
                      style={{ width: bs(48), height: bs(48), borderRadius: bs(24) }}
                      contentFit="cover"
                      transition={200}
                    />
                  ) : (
                    <View style={{
                      width: bs(48), height: bs(48), borderRadius: bs(24),
                      backgroundColor: BoxSurfaces.elevated,
                      alignItems: "center", justifyContent: "center",
                    }}>
                      <Users size={bs(20)} color={BoxText.tertiary} />
                    </View>
                  )}
                  <View style={{ flex: 1, gap: BoxSpacing.xs }}>
                    <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>
                      {friend.nickname}
                    </Text>
                    <View style={{ flexDirection: "row", gap: BoxSpacing.md }}>
                      <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.xs }}>
                        <Box size={bs(12)} color={BoxText.tertiary} />
                        <Text style={[BoxTypography.micro, { color: BoxText.tertiary }]}>
                          {t("friends.opens", { count: friend.totalOpens })}
                        </Text>
                      </View>
                      <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.xs }}>
                        <Star size={bs(12)} color={rarityConfig.color} />
                        <Text style={[BoxTypography.micro, { color: rarityConfig.color }]}>
                          {t("friends.maxRarity", { rarity: t(`rarity.${friend.maxRarity}`) })}
                        </Text>
                      </View>
                    </View>
                  </View>
                  <Pressable
                    onPress={() => openGiftModal(friend.uid, friend.nickname)}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: BoxSpacing.xs,
                      backgroundColor: BoxAccent.purpleMuted,
                      borderRadius: BoxRadius.md,
                      paddingHorizontal: BoxSpacing.md,
                      paddingVertical: BoxSpacing.sm,
                    }}
                  >
                    <Gift size={bs(16)} color={BoxAccent.purpleLight} />
                    <Text style={[BoxTypography.caption, { color: BoxAccent.purpleLight }]}>
                      {t("friends.gift")}
                    </Text>
                  </Pressable>
                </View>

                {friend.recentRare.length > 0 && (
                  <View style={{
                    marginTop: BoxSpacing.md,
                    paddingTop: BoxSpacing.md,
                    borderTopWidth: 1,
                    borderTopColor: BoxBorders.subtle,
                  }}>
                    <Text style={[BoxTypography.micro, { color: BoxText.tertiary, marginBottom: BoxSpacing.sm }]}>
                      {t("friends.recentRare")}
                    </Text>
                    <View style={{ flexDirection: "row", gap: BoxSpacing.sm }}>
                      {friend.recentRare.map((item: any, idx: number) => {
                        const rc = getRarityTier(item.rarity);
                        return (
                          <View key={idx} style={{
                            borderRadius: BoxRadius.md,
                            padding: BoxSpacing.sm,
                            alignItems: "center",
                            gap: BoxSpacing.xs,
                            minWidth: bs(70),
                            backgroundColor: rc.bgSubtle,
                            borderWidth: 1,
                            borderColor: rc.borderColor,
                          }}>
                            {item.image ? (
                              <Image
                                source={{ uri: item.image }}
                                style={{ width: bs(32), height: bs(32) }}
                                contentFit="contain"
                                transition={200}
                              />
                            ) : (
                              <Box size={bs(16)} color={rc.color} />
                            )}
                            <Text
                              style={[BoxTypography.micro, { color: rc.color }]}
                              numberOfLines={1}
                            >
                              {item.name}
                            </Text>
                          </View>
                        );
                      })}
                    </View>
                  </View>
                )}
              </View>
            );
          })
        )}
      </ScrollView>

      <Modal visible={giftModal.visible} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(5,5,7,0.85)", justifyContent: "flex-end" }}>
          <View style={{
            backgroundColor: BoxSurfaces.card,
            borderTopLeftRadius: BoxRadius["3xl"],
            borderTopRightRadius: BoxRadius["3xl"],
            padding: BoxSpacing.xl,
            maxHeight: "60%",
            borderTopWidth: 1,
            borderTopColor: BoxBorders.default,
          }}>
            <View style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: BoxSpacing.xs,
            }}>
              <Text style={[BoxTypography.h3, { color: BoxText.primary }]}>
                {t("friends.selectGift")}
              </Text>
              <Pressable onPress={() => setGiftModal({ visible: false, friendUid: 0, friendName: "" })}>
                <X size={bs(22)} color={BoxText.secondary} />
              </Pressable>
            </View>
            <Text style={[BoxTypography.caption, { color: BoxText.tertiary, marginBottom: BoxSpacing.lg }]}>
              {t("friends.giftTo", { name: giftModal.friendName })}
            </Text>
            {myItems.length === 0 ? (
              <BoxEmptyState
                icon={<Box size={bs(32)} color={BoxText.tertiary} />}
                title={t("friends.noItems")}
              />
            ) : (
              <FlatList
                data={myItems}
                keyExtractor={(item: any) => String(item.id)}
                renderItem={({ item }: { item: any }) => (
                  <Pressable
                    onPress={() => handleGift(item.id)}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      backgroundColor: BoxSurfaces.deep,
                      borderRadius: BoxRadius.lg,
                      padding: BoxSpacing.md,
                      marginBottom: BoxSpacing.sm,
                      gap: BoxSpacing.md,
                      borderWidth: 1,
                      borderColor: BoxBorders.subtle,
                    }}
                  >
                    {item.productImage || item.image ? (
                      <Image
                        source={{ uri: item.productImage || item.image }}
                        style={{ width: bs(40), height: bs(40), borderRadius: BoxRadius.sm }}
                        contentFit="contain"
                        transition={200}
                      />
                    ) : (
                      <View style={{
                        width: bs(40), height: bs(40), borderRadius: BoxRadius.sm,
                        backgroundColor: BoxSurfaces.elevated,
                        alignItems: "center", justifyContent: "center",
                      }}>
                        <Box size={bs(20)} color={BoxText.tertiary} />
                      </View>
                    )}
                    <Text
                      style={[BoxTypography.bodyBold, { flex: 1, color: BoxText.primary }]}
                      numberOfLines={1}
                    >
                      {item.productName || item.name}
                    </Text>
                    <Send size={bs(16)} color={BoxAccent.purpleLight} />
                  </Pressable>
                )}
                style={{ maxHeight: 350 }}
              />
            )}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
