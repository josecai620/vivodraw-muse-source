import { API_ENDPOINTS } from "@/constants/api";
import { http } from "@/lib/http";

export interface RechargeQuota {
  price?: number;
  give_price?: number;
  [k: string]: unknown;
}

export function getRechargeIndex() {
  return http.get<{
    recharge_quota?: RechargeQuota[];
    recharge_attention?: string[];
  }>(API_ENDPOINTS.wallet.recharge.index);
}

export function submitRecharge(data: {
  price: number;
  rechar_id?: number;
  type?: number;
  from?: "stripe" | "paypal";
}) {
  return http.post(API_ENDPOINTS.wallet.recharge.submit, {
    ...data,
    type: data.type ?? 0,
  });
}

export function getExtractBank() {
  return http.get<{
    extractType?: string[];
    minPrice?: number;
    bankList?: unknown[];
    [k: string]: unknown;
  }>(API_ENDPOINTS.wallet.extract.bank);
}

export function submitExtract(data: {
  extract_type: string;
  money: number;
  name?: string;
  bankname?: string;
  cardnum?: string;
  alipay_code?: string;
  weixin?: string;
}) {
  return http.post(API_ENDPOINTS.wallet.extract.cash, data);
}

/**
 * PayPal 提现申请（面向美国市场）
 * 后端 config/pay.php 的 extractType 已改为 ['paypal']，
 * 控制器接收 paypal_email 字段，内部仍用 alipay_code 列存邮箱以免 DB 迁移。
 */
export function submitPaypalExtract(data: {
  money: number;
  paypal_email: string;
  name?: string;
}) {
  return http.post(API_ENDPOINTS.wallet.extract.cash, {
    extract_type: "paypal",
    money: data.money,
    paypal_email: data.paypal_email,
    name: data.name ?? "",
  });
}
