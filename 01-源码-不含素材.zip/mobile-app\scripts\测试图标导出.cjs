'use strict';
const fs=require('fs'),assert=require('assert/strict'),vm=require('vm');
const generate=require('@babel/generator').default;
const {optimize,registrations}=require('./优化图标导出.cjs');
const input=process.argv[2];assert(input,'node 测试图标导出.cjs exported-common.js');
const text=fs.readFileSync(input,'utf8'),result=optimize(text),before=registrations(text),after=registrations(result.output);
const ids=result.report.barrels.map(x=>x.moduleId),outer=ids.find(id=>before.find(m=>m.id===id).factory.body.body.some(s=>generate(s).code.includes('"createLucideIcon"')));
const realValues=new Map();function value(key){if(!realValues.has(key))realValues.set(key,Object.freeze({identity:key}));return realValues.get(key);}
const create=(name,nodes)=>{assert(Array.isArray(nodes));return value('real-icon:'+name);};
function runtime(mods,stub){
 const byId=new Map(mods.map(m=>[m.id,m])),cache=new Map(),loads=[];
 const first=byId.get(outer),creator=result.report.preservedEagerDependencyIds[0];
 const inner=ids.find(id=>id!==outer),icons=new Set(byId.get(inner).deps.elements.map(n=>n.value));
 function req(id){if(cache.has(id))return cache.get(id);loads.push(id);
  if(id===creator){const v={__esModule:true,default:create};cache.set(id,v);return v;}
  if(!ids.includes(id)&&(stub||!icons.has(id))){const raw=stub&&id%2?value('raw:'+id):{__esModule:true,default:value('default:'+id),extra:value('extra:'+id)};cache.set(id,raw);return raw;}
  const mod=byId.get(id);assert(mod,'Unknown require '+id);const out={};cache.set(id,out);const module={exports:out};
  const fn=vm.runInNewContext('('+generate(mod.factory).code+')',{}, {timeout:3000});
  fn({},req,x=>req(x).default,req,module,out,mod.deps.elements.map(n=>n.value));cache.set(id,module.exports);return module.exports;
 }
 return {req,loads,icons};
}
const checks=[];
for(const stub of [false,true]){
 const old=runtime(before,stub),next=runtime(after,stub),a=old.req(outer),b=next.req(outer);
 const oldInitial=old.loads.length,newInitial=next.loads.length;
 assert(newInitial<10,'Optimized import still initializes icon catalog');
 assert(oldInitial>1500,'Original fixture not full eager catalog');
 const originalKeys=Object.getOwnPropertyNames(a),optimizedKeys=Object.getOwnPropertyNames(b);assert.deepEqual(optimizedKeys,originalKeys,'Own-property order changed');assert.deepEqual(Object.keys(b),Object.keys(a),'Enumerable keys changed');
 for(const name of originalKeys){const x=Object.getOwnPropertyDescriptor(a,name),y=Object.getOwnPropertyDescriptor(b,name);assert.equal(y.enumerable,x.enumerable);assert.equal(y.configurable,x.configurable);assert.equal(typeof y.get,typeof x.get);assert.equal(y.writable,x.writable);if(name==='__esModule')assert.equal(a[name],b[name]);}
 const afterKeys=next.loads.length;assert.equal(afterKeys,newInitial,'Key enumeration must not load icons');
 const xZap=b.Zap;assert.equal(next.loads.filter(id=>next.icons.has(id)).length,1,'One accessed icon should initialize one icon');assert.equal(b.ZapIcon,xZap,'Alias identity differs');assert.equal(b.LucideZap,xZap,'Lucide alias identity differs');
 for(const name of originalKeys){if(name==='icons')continue;assert.strictEqual(b[name],a[name],'Export identity differs: '+name);assert.strictEqual(b[name],b[name],'Repeated access identity differs: '+name);}
 const ai=a.icons,bi=b.icons;assert.deepEqual(Object.getOwnPropertyNames(bi),Object.getOwnPropertyNames(ai),'Namespace interop keys differ');assert.deepEqual(Object.keys(bi),Object.keys(ai),'Namespace enumeration differs');
 for(const name of Object.keys(ai)){if(name==='default'){assert.deepEqual(Object.keys(bi.default),Object.keys(ai.default));for(const key of Object.keys(ai.default))assert.strictEqual(bi.default[key],ai.default[key]);}else assert.strictEqual(bi[name],ai[name],'Icons namespace value differs '+name);}
 assert.strictEqual(b.icons,bi,'Namespace object cache differs');assert.strictEqual(b.createLucideIcon,a.createLucideIcon);assert.strictEqual(b.Icon,a.Icon);assert.equal(next.loads.length,old.loads.length,'Full export access dependency set differs');
 checks.push({mode:stub?'mixed-ESM-and-CommonJS-dependencies':'real-static-icon-factories',exportKeys:originalKeys.length,initialRequireOld:oldInitial,initialRequireNew:newInitial,allAccessRequire:next.loads.length});
}
const badBarrel=text.replace('Object.defineProperty(f,"AlarmCheck"','globalThis.unexpectedEffect();Object.defineProperty(f,"AlarmCheck"');assert.notEqual(badBarrel,text);assert.throws(()=>optimize(badBarrel),/Unknown/);
const icon=before.find(m=>m.id===4726);assert(icon,'Fixture must contain tested icon');const mutated=text.slice(0,icon.factory.body.end-1)+';globalThis.unexpectedEffect=1;'+text.slice(icon.factory.body.end-1);assert.throws(()=>optimize(mutated),/Unknown icon|Static icon/);
assert.throws(()=>optimize('var unrelated=1;'),/Expected exactly/);
const creator=before.find(m=>m.id===result.report.preservedEagerDependencyIds[0]);const changedCreator=text.slice(0,creator.factory.body.end-1)+';globalThis.effect=1;'+text.slice(creator.factory.body.end-1);assert.throws(()=>optimize(changedCreator),/Unrecognized createLucideIcon/);
assert(result.report.afterBytes<result.report.beforeBytes&&result.report.afterGzip<result.report.beforeGzip,'No size reduction');
console.log(JSON.stringify({status:'PASS',checks,rejections:4,...result.report},null,2));
