import PageHeader from "@/components/shared/PageHeader";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import { type InvoiceItem, getInvoiceList, makeUpInvoice } from "@/lib/api/invoice";
import { unwrapApiListField } from "@/lib/api/response";
import { useAppStore } from "@/store/app";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

function getInvoiceId(invoice: InvoiceItem): number {
  return Number(invoice.id ?? invoice.invoice_id ?? 0) || 0;
}

function getInvoiceTitle(invoice: InvoiceItem, id: number, fallback: string): string {
  return invoice.header ?? invoice.title ?? invoice.name ?? `${fallback} #${id}`;
}

function getInvoiceTaxId(invoice: InvoiceItem): string {
  return invoice.duty_paragraph ?? invoice.duty_number ?? "";
}

export default function InvoiceApplyScreen() {
  const { t } = useTranslation();
  const { orderId } = useLocalSearchParams<{ orderId: string }>();
  const router = useRouter();
  const queryClient = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  const [selectedId, setSelectedId] = useState<number>(0);

  const { data, isLoading } = useQuery({
    queryKey: ["invoiceList"],
    queryFn: getInvoiceList,
  });

  const mutateApply = useMutation({
    mutationFn: () => makeUpInvoice({ order_id: orderId ?? "", invoice_id: selectedId }),
    onSuccess: () => {
      showToast(t("shopOrderInvoice.applied"), "success");
      queryClient.invalidateQueries({ queryKey: ["orderDetail", orderId] });
      queryClient.invalidateQueries({ queryKey: ["orderList"] });
      router.back();
    },
    onError: (error: unknown) =>
      showToast(getErrorMessage(error, t("shopOrderInvoice.applyFailed")), "error"),
  });

  const list = unwrapApiListField<InvoiceItem>(data).filter((invoice) => getInvoiceId(invoice) > 0);

  const handleSubmit = () => {
    if (!selectedId) {
      showToast(t("shopOrderInvoice.selectInvoice"), "error");
      return;
    }
    if (!orderId) {
      showToast(t("shopOrderInvoice.orderNotFound"), "error");
      return;
    }
    mutateApply.mutate();
  };

  if (!orderId) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("shopOrderInvoice.title")} />
        <View className="flex-1 items-center justify-center px-6">
          <Text className="text-center" style={{ color: Colors.neutral[600] }}>
            {t("shopOrderInvoice.orderNotFound")}
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("shopOrderInvoice.title")} />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView
          className="flex-1"
          contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
          showsVerticalScrollIndicator={false}
        >
          {list.length > 0 ? (
            <>
              <Text className="text-sm font-medium mb-3" style={{ color: Colors.neutral[600] }}>
                {t("shopOrderInvoice.selectInvoice")}
              </Text>
              {list.map((inv) => {
                const id = getInvoiceId(inv);
                const isSelected = id === selectedId;
                const name = getInvoiceTitle(inv, id, t("shopOrderInvoice.invoiceFallback"));
                const taxId = getInvoiceTaxId(inv);
                return (
                  <Pressable
                    key={id}
                    onPress={() => setSelectedId(id)}
                    className={`mb-2 p-4 rounded-xl border-2 ${isSelected ? "border-[#04A8AE] bg-brand-red-light" : "border-gray-200 bg-white"}`}
                  >
                    <Text className="font-semibold" style={{ color: Colors.neutral[800] }}>
                      {name}
                    </Text>
                    {taxId ? (
                      <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }}>
                        {taxId}
                      </Text>
                    ) : null}
                  </Pressable>
                );
              })}
                <Pressable
                  className="mt-6 items-center justify-center"
                  onPress={handleSubmit}
                  disabled={!selectedId || mutateApply.isPending}
                  style={{
                    paddingVertical: 14,
                    borderRadius: 12,
                    backgroundColor: selectedId ? "transparent" : Colors.neutral[300],
                    alignItems: "center",
                    shadowColor: "#04A8AE",
                    shadowOffset: { width: 0, height: 6 },
                    shadowOpacity: selectedId ? 0.3 : 0,
                    shadowRadius: 12,
                    elevation: selectedId ? 6 : 0,
                  }}
                >
                  {selectedId && (
                    <>
                      <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
                      <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
                    </>
                  )}
                <Text className="text-white font-semibold">
                  {mutateApply.isPending
                    ? t("shopOrderInvoice.submitting")
                    : t("shopOrderInvoice.submit")}
                </Text>
              </Pressable>
            </>
          ) : (
            <View className="py-12 items-center">
              <Text className="text-center" style={{ color: Colors.neutral[600] }}>
                {t("shopOrderInvoice.empty")}
              </Text>
              <Pressable
                onPress={() => router.replace("/profile/invoices/add")}
                className="mt-4 px-6 h-10 rounded-xl items-center justify-center"
                style={{ }}
              >
                <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
                <Text className="text-white font-semibold">{t("shopOrderInvoice.addInvoice")}</Text>
              </Pressable>
              <Pressable
                onPress={() => router.back()}
                className="mt-3 px-6 h-10 rounded-xl items-center justify-center border border-gray-300"
              >
                <Text className="font-semibold" style={{ color: Colors.neutral[600] }}>
                  {t("common.back")}
                </Text>
              </Pressable>
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}
