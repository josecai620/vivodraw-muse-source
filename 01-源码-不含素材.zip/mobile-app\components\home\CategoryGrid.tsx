// components/home/CategoryGrid.tsx
// 分类网格

import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { Monitor, User, Home, Trophy } from 'lucide-react-native';

interface Category {
  id: number;
  name: string;
  icon: React.ReactNode;
  color: string;
}

export default function CategoryGrid() {
  const categories: Category[] = [
    {
      id: 1,
      name: 'Electronics',
      icon: <Monitor size={40} color="#FFFFFF" />,
      color: '#04A8AE', // 蓝色
    },
    {
      id: 2,
      name: 'Fashion',
      icon: <User size={40} color="#FFFFFF" />,
      color: '#04A8AE', // 粉色
    },
    {
      id: 3,
      name: 'Home & Garden',
      icon: <Home size={40} color="#FFFFFF" />,
      color: '#04A8AE', // 绿色
    },
    {
      id: 4,
      name: 'Sports',
      icon: <Trophy size={40} color="#FFFFFF" />,
      color: '#04A8AE', // 橙色
    },
  ];

  return (
    <View className="px-6 py-16">
      {/* 标题 */}
      <Text className="text-4xl font-bold text-gray-700 mb-8">
        Shop by Category
      </Text>
      
      {/* 网格 - 2x2 */}
      <View className="flex-row flex-wrap gap-6">
        {categories.map((category) => (
          <Pressable
            key={category.id}
            className="bg-white rounded-2xl border border-gray-100 p-8 items-center active:scale-95"
            style={{ width: '47%' }}
          >
            {/* 圆形图标容器 */}
            <View
              className="w-20 h-20 rounded-full items-center justify-center mb-4"
              style={{ backgroundColor: category.color }}
            >
              {category.icon}
            </View>
            
            {/* 分类名称 */}
            <Text className="text-lg font-bold text-gray-700 text-center">
              {category.name}
            </Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}
