import { useEffect } from "react";

// 旧首页保留自己的资源图；进入开蚌时交给当前独立页面，避免混用旧规则和新素材。
export default function PearlLegacyEntry() {
  useEffect(() => {
    if (typeof window !== "undefined") {
      window.location.replace(`/pearl${window.location.search}${window.location.hash}`);
    }
  }, []);
  return null;
}
