import { Colors } from "@/constants/theme";
import { Camera, Images } from "lucide-react-native";
import { Modal, Platform, Pressable, Text, View } from "react-native";

type Props = {
  visible: boolean;
  zh: boolean;
  onClose: () => void;
  onUpload: () => void;
  onPickedFile?: (file: File) => void;
  onFrames: () => void;
};

export default function 头像操作面板({ visible, zh, onClose, onUpload, onPickedFile, onFrames }: Props) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <Pressable
        onPress={onClose}
        style={{ flex: 1, backgroundColor: "rgba(15,23,42,0.45)", justifyContent: "flex-end" }}
      >
        <Pressable
          onPress={(event) => event.stopPropagation()}
          style={{
            backgroundColor: "#fff",
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            paddingHorizontal: 16,
            paddingTop: 10,
            paddingBottom: 28,
          }}
        >
          <View style={{ alignSelf: "center", width: 36, height: 4, borderRadius: 99, backgroundColor: "#E5E7EB", marginBottom: 12 }} />
          <Text style={{ fontSize: 16, fontWeight: "800", color: "#111827", textAlign: "center", marginBottom: 4 }}>
            {zh ? "头像与头像框" : "Avatar & frames"}
          </Text>
          <Text style={{ fontSize: 12, color: "#6B7280", textAlign: "center", marginBottom: 14 }}>
            {zh ? "先裁剪照片，再挑选已获得的动态头像框穿戴" : "Crop a photo, then wear an unlocked frame"}
          </Text>
          <View style={{ position: "relative" }}>
            <Pressable
              onPress={onUpload}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 12,
                height: 52,
                borderRadius: 14,
                paddingHorizontal: 14,
                backgroundColor: "#F3FBFC",
                borderWidth: 1,
                borderColor: "rgba(4,168,174,0.18)",
              }}
            >
              <Camera size={18} color={Colors.brand.red} />
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: "800", color: "#111827" }}>{zh ? "上传并裁剪头像" : "Upload & crop"}</Text>
                <Text style={{ fontSize: 11, color: "#6B7280" }}>
                  {zh ? "放大缩小、拖动，圈出要露出的脸" : "Zoom, pan, then crop the face"}
                </Text>
              </View>
            </Pressable>
            {Platform.OS === "web" && onPickedFile ? (
              <input
                type="file"
                accept="image/*"
                aria-label={zh ? "上传并裁剪头像" : "Upload & crop"}
                onChange={(event) => {
                  const file = event.currentTarget.files?.[0];
                  event.currentTarget.value = "";
                  if (file) onPickedFile(file);
                }}
                style={{
                  position: "absolute",
                  left: 0,
                  top: 0,
                  width: "100%",
                  height: "100%",
                  opacity: 0.01,
                  fontSize: 16,
                  cursor: "pointer",
                }}
              />
            ) : null}
          </View>
          <Pressable
            onPress={onFrames}
            style={{
              flexDirection: "row",
              alignItems: "center",
              gap: 12,
              height: 52,
              borderRadius: 14,
              paddingHorizontal: 14,
              backgroundColor: "#F8FAFC",
              borderWidth: 1,
              borderColor: "#E5E7EB",
              marginTop: 10,
            }}
          >
            <Images size={18} color="#111827" />
            <View style={{ flex: 1 }}>
              <Text style={{ fontWeight: "800", color: "#111827" }}>{zh ? "头像框图库" : "Frame gallery"}</Text>
              <Text style={{ fontSize: 11, color: "#6B7280" }}>
                {zh ? "付费会员获得的动态框，点一下穿戴" : "Wear frames unlocked by membership"}
              </Text>
            </View>
          </Pressable>
          <Pressable onPress={onClose} style={{ marginTop: 12, height: 44, alignItems: "center", justifyContent: "center" }}>
            <Text style={{ color: "#6B7280", fontWeight: "700" }}>{zh ? "取消" : "Cancel"}</Text>
          </Pressable>
        </Pressable>
      </Pressable>
    </Modal>
  );
}
