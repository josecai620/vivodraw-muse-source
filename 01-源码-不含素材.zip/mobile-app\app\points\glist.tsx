import { PageHeader } from "@/components/shared";
import CloudBuyProgress from "@/components/points/CloudBuyProgress";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { Colors } from "@/constants/theme";
import { useAddPointsCart, usePointsCategories, usePointsProducts } from "@/hooks";
import { unwrapApiPagedList } from "@/lib/api/response";
import { mapCloudProduct, sortCloudBuyCards } from "@/lib/points/cloudBuyParse";
import { useAuthStore } from "@/store/auth";
import { useFocusEffect, useRouter } from "expo-router";
import { ShoppingCart } from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Image, Pressable, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const TEAL = Colors.primary.DEFAULT;
type SortKey = "hot" | "new" | "price" | "soon";

export default function PointsGlistScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [sort, setSort] = useState<SortKey>("soon");
  const [cate, setCate] = useState(0);
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const { data, refetch } = usePointsProducts();
  const { data: catData } = usePointsCategories();
  const addCart = useAddPointsCart();

  const categories = useMemo(() => {
    const list = unwrapApiPagedList<any>(catData).map((c) => ({
      id: Number(c.value ?? c.id ?? 0),
      name: String(c.cate_name ?? c.name ?? ""),
    }));
    return [{ id: 0, name: t("pointsMall.tabAllPeriods") }, ...list.filter((c) => c.id > 0 && c.name)];
  }, [catData, t]);

  const products = useMemo(() => {
    const list = unwrapApiPagedList<any>(data)
      .map(mapCloudProduct)
      .filter(Boolean) as NonNullable<ReturnType<typeof mapCloudProduct>>[];
    return sortCloudBuyCards(list, sort);
  }, [data, sort]);

  useFocusEffect(
    React.useCallback(() => {
      void refetch();
    }, [refetch]),
  );

  const sorts: Array<{ key: SortKey; label: string }> = [
    { key: "soon", label: t("pointsMall.sortSoon") },
    { key: "hot", label: t("pointsMall.sortHot") },
    { key: "new", label: t("pointsMall.sortNew") },
    { key: "price", label: t("pointsMall.sortValue") },
  ];

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.tabAllPeriods")} showBack={false} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} className="bg-white" style={{ flexGrow: 0 }}>
        {categories.map((c) => {
          const on = cate === c.id;
          return (
            <Pressable
              key={c.id}
              className="px-3 py-2.5"
              onPress={() => {
                setCate(c.id);
                if (c.id > 0) {
                  router.push({ pathname: "/points/categories", params: { cate: String(c.id) } } as never);
                }
              }}
            >
              <Text style={{ color: on ? TEAL : "#6B7280", fontWeight: on ? "800" : "600", fontSize: 13 }}>
                {c.name}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>
      <View className="px-3 py-1 flex-row flex-wrap bg-white border-b border-gray-100" style={{ gap: 4 }}>
        {sorts.map((item) => {
          const active = sort === item.key;
          return (
            <Pressable key={item.key} className="px-2 py-2" onPress={() => setSort(item.key)}>
              <Text
                className="text-sm font-bold"
                style={{
                  color: active ? TEAL : "#6B7280",
                  borderBottomWidth: active ? 2 : 0,
                  borderBottomColor: TEAL,
                  paddingBottom: 2,
                }}
              >
                {item.label}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}
        showsVerticalScrollIndicator={false}
      >
        {products.length === 0 ? (
          <Text className="text-center text-sm text-gray-400 py-16">{t("pointsMall.noProductsFound")}</Text>
        ) : (
          products.map((item) => (
            <Pressable
              key={item.id}
              className="flex-row px-3 py-3 bg-white border-b border-gray-100"
              onPress={() => router.push({ pathname: "/points/product", params: { id: String(item.id) } })}
            >
              <View className="w-24 h-24 bg-gray-50 rounded overflow-hidden items-center justify-center mr-3">
                {item.image ? (
                  <Image source={{ uri: item.image }} className="w-full h-full" resizeMode="contain" />
                ) : null}
              </View>
              <View className="flex-1 pr-2">
                <Text className="text-sm text-gray-900 mb-1" numberOfLines={2}>
                  {item.name}
                </Text>
                <Text className="text-xs text-gray-500 mb-1.5">
                  {t("pointsMall.valueLabel")}: {item.points}
                </Text>
                <CloudBuyProgress
                  joined={item.sold}
                  total={item.total}
                  remain={item.remain}
                  joinedLabel={t("pointsMall.joined")}
                  totalLabel={t("pointsMall.totalNeed")}
                  remainLabel={t("pointsMall.remain")}
                />
              </View>
              <Pressable
                className="self-center w-10 h-10 rounded-full items-center justify-center"
                style={{ backgroundColor: TEAL }}
                onPress={() => {
                  if (!isLoggedIn) {
                    router.push("/auth");
                    return;
                  }
                  addCart.mutate({ productId: item.id, cartNum: 1 } as any);
                }}
              >
                <ShoppingCart size={18} color="#fff" />
              </Pressable>
            </Pressable>
          ))
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
