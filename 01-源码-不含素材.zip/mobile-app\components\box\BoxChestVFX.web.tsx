import React, { useEffect, useRef } from "react";
import { type ImageSourcePropType, type ViewStyle } from "react-native";
import { Asset } from "expo-asset";
import { bs } from "@/lib/boxTheme";
import { VFXManager } from "./vfx/core/VFXManager";
import type { VFXPresetPatch, VFXRarity } from "./vfx/core/VFXConfig";

type ChestVFXDensity = "hero" | "compact";

interface BoxChestVFXProps {
  image?: ImageSourcePropType;
  tier?: string;
  size?: number;
  density?: ChestVFXDensity;
  style?: ViewStyle;
}

async function getAssetUrl(image?: ImageSourcePropType) {
  if (!image) return undefined;
  if (typeof image === "string") return image;
  if (Array.isArray(image)) return getAssetUrl(image[0]);
  if (typeof image === "object" && "uri" in image && typeof image.uri === "string") return image.uri;
  const asset = Asset.fromModule(image as number);
  await asset.downloadAsync();
  return asset.localUri || asset.uri;
}

function getVFXRarity(tier?: string): VFXRarity {
  const normalized = String(tier || "legendary").toLowerCase();
  if (normalized === "common") return "common";
  if (normalized === "rare" || normalized === "uncommon") return "rare";
  if (normalized === "epic" || normalized === "secret") return "epic";
  if (normalized === "fire") return "fire";
  return "legendary";
}

const chestVFXPatch: VFXPresetPatch = {
  glow: { glowColor: 0x7fd8dc, glowStrength: 1.1, glowSpeed: 0.82 },
  flow: { flowColor: 0xb2ecee, flowSpeed: 0.88, sweepSpeed: 0.74 },
  spark: { particleColor: 0x9fe4e6, particleCount: 46, particleSize: 0.94 },
  energy: { energyColor: 0x33c6cc, energyWaveSize: 0.92, energyWaveStrength: 0.88 },
  explosion: { explosionStrength: 0.66 },
  fire: { enabled: true, fireIntensity: 0.32, fireSpeed: 0.62 },
};

/** Hall/cards: keep motion, kill big ghost glow behind the chest. */
const chestVFXPatchCompact: VFXPresetPatch = {
  glow: { glowColor: 0x7fd8dc, glowStrength: 0.18, glowSpeed: 0.7 },
  flow: { flowColor: 0xb2ecee, flowSpeed: 0.55, sweepSpeed: 0.4 },
  spark: { particleColor: 0x9fe4e6, particleCount: 10, particleSize: 0.7 },
  energy: { energyColor: 0x33c6cc, energyWaveSize: 0.35, energyWaveStrength: 0.12 },
  explosion: { explosionStrength: 0.12 },
  fire: { enabled: false, fireIntensity: 0, fireSpeed: 0.4 },
};

export function BoxChestVFX({
  image,
  tier,
  size = 132,
  density = "hero",
  style,
}: BoxChestVFXProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const managerRef = useRef<VFXManager | null>(null);
  const stageSize = bs(size);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount || !image) return;
    let disposed = false;

    const start = async () => {
      const assetUrl = await getAssetUrl(image);
      if (!assetUrl || disposed || !mountRef.current) return;

      managerRef.current?.destroy();
      mountRef.current.replaceChildren();

      const manager = new VFXManager({
        mount: mountRef.current,
        assetUrl,
        width: 720,
        height: 720,
        assetSize: density === "hero" ? 520 : 560,
        assetOffsetY: density === "hero" ? -18 : -8,
        rarity: getVFXRarity(tier),
      });
      managerRef.current = manager;

      try {
        await manager.init();
        if (disposed) {
          manager.destroy();
          return;
        }
        manager.setConfig(density === "compact" ? chestVFXPatchCompact : chestVFXPatch);
        manager.setLightStyle(density === "hero" ? "spiralGold" : "starOrbit");
        manager.play();
        manager.trigger();
      } catch (err) {
        console.warn("[BoxChestVFX] WebGL failed, using static image", err);
        manager.destroy();
        managerRef.current = null;
        if (!mountRef.current || disposed) return;
        const img = document.createElement("img");
        img.src = assetUrl;
        img.alt = "chest";
        img.style.width = "100%";
        img.style.height = "100%";
        img.style.objectFit = "contain";
        mountRef.current.replaceChildren(img);
      }
    };

    void start();

    return () => {
      disposed = true;
      managerRef.current?.destroy();
      managerRef.current = null;
      mount.replaceChildren();
    };
  }, [density, image, tier]);

  return (
    <div
      ref={mountRef}
      style={{
        width: stageSize,
        height: stageSize,
        overflow: "visible",
        pointerEvents: "none",
        filter: density === "compact" ? "saturate(1.06) contrast(1.02) brightness(1.02)" : "saturate(1.18) contrast(1.04) brightness(1.08)",
        ...(style as React.CSSProperties),
      }}
    />
  );
}
