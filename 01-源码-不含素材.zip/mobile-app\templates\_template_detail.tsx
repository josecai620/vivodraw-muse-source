/**
 * 模板：详情页（Header + 大图 + 内容 + 底部操作栏）
 * 使用方法：复制到 app/xxx/[id].tsx，接入真实 API hook
 */
import React, { useState } from "react";
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Heart, ShoppingCart } from "lucide-react-native";
import { Colors, s } from "@/constants/theme";
import { PageHeader, PriceDisplay } from "@/components/shared";
import { normalizeImageUrl } from "@/lib/utils";

export default function TemplateDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  // TODO: 替换为真实 hook，例如 useProductDetail(Number(id))
  const isLoading = false;
  const product = {
    store_name: "Product Name",
    store_info: "Product description goes here",
    image: "",
    price: "99.00",
    ot_price: "149.00",
    sales: 234,
    stock: 100,
  };

  const [isFavorite, setIsFavorite] = useState(false);

  if (isLoading) {
    return (
      <View className="flex-1 bg-white items-center justify-center">
        <ActivityIndicator size="large" color={Colors.brand.red} />
      </View>
    );
  }

  return (
    <View className="flex-1 bg-white">
      <PageHeader
        title="Detail"
        rightElement={
          <Pressable className="p-2" onPress={() => router.push("/(tabs)/cart")}>
            <ShoppingCart size={s(20)} color={Colors.neutral[700]} />
          </Pressable>
        }
      />

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Hero Image */}
        <View className="w-full aspect-square bg-gray-100">
          {product.image ? (
            <Image
              source={{ uri: normalizeImageUrl(product.image) }}
              className="w-full h-full"
              resizeMode="cover"
            />
          ) : (
            <View className="w-full h-full items-center justify-center">
              <Text className="text-4xl">📷</Text>
            </View>
          )}
          <Pressable
            onPress={() => setIsFavorite(!isFavorite)}
            className="absolute top-4 right-4 w-10 h-10 bg-white/90 rounded-full items-center justify-center"
          >
            <Heart
              size={20}
              color={isFavorite ? Colors.brand.red : Colors.neutral[700]}
              fill={isFavorite ? Colors.brand.red : "none"}
            />
          </Pressable>
        </View>

        {/* Info */}
        <View className="px-4 py-5">
          <Text className="text-xl font-bold text-gray-900 mb-2">
            {product.store_name}
          </Text>
          <Text className="text-sm text-gray-500 mb-4">
            {product.store_info}
          </Text>
          <PriceDisplay
            price={product.price}
            originalPrice={product.ot_price}
            size="lg"
          />
        </View>

        <View className="h-24" />
      </ScrollView>

      {/* Bottom Action Bar */}
      <View
        className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3"
        style={{ paddingBottom: insets.bottom + 12 }}
      >
        <Pressable
          className="h-12 rounded-xl flex-row items-center justify-center gap-2"
          style={{ backgroundColor: Colors.brand.red }}
        >
          <ShoppingCart size={20} color={Colors.neutral[0]} />
          <Text className="text-white font-semibold">Add to Cart</Text>
        </Pressable>
      </View>
    </View>
  );
}
