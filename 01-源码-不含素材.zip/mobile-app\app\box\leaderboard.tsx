/**
 * 排行榜（Premium Dark Gaming UI）
 */
import React, { useState } from "react";
import { View, Text, ScrollView, ActivityIndicator } from "react-native";
import { useTranslation } from "react-i18next";
import { Trophy, Flame, Crown, Medal, User } from "lucide-react-native";
import { BoxHeader, RarityBadge, BoxTabBar, BoxEmptyState } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, bs,
} from "@/lib/boxTheme";
import { useLeaderboard } from "@/hooks";

type TabKey = "luck" | "active" | "rare";

const MEDAL_COLORS = ["#04A8AE", "#919290", "#C0C0BE"];

export default function LeaderboardPage() {
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<TabKey>("luck");
  const { data, isLoading } = useLeaderboard(activeTab);

  const list: any[] = (data as any)?.list ?? [];

  const tabs = [
    { key: "luck", label: t("leaderboard.tabLuck"), icon: <Flame size={bs(14)} color={BoxText.primary} /> },
    { key: "active", label: t("leaderboard.tabActive"), icon: <Trophy size={bs(14)} color={BoxText.primary} /> },
    { key: "rare", label: t("leaderboard.tabRare"), icon: <Crown size={bs(14)} color={BoxText.primary} /> },
  ];

  const renderValue = (user: any) => {
    if (activeTab === "luck") {
      return (
        <Text style={[BoxTypography.bodyBold, { color: BoxAccent.gold }]}>
          {t("leaderboard.times", { count: user.rare_count })}
        </Text>
      );
    }
    if (activeTab === "active") {
      return (
        <Text style={[BoxTypography.bodyBold, { color: BoxAccent.gold }]}>
          {t("leaderboard.opens", { count: user.total_opens || user.order_count })}
        </Text>
      );
    }
    return (
      <Text style={[BoxTypography.bodyBold, { color: BoxAccent.gold }]}>
        {t("leaderboard.items", { count: user.epic_count })}
      </Text>
    );
  };

  const showRarity = activeTab === "luck" || activeTab === "rare";

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("leaderboard.title")} />

      <BoxTabBar
        tabs={tabs}
        activeKey={activeTab}
        onSelect={(key) => setActiveTab(key as TabKey)}
        style={{ backgroundColor: BoxSurfaces.deep }}
      />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(100) }}>
          {isLoading ? (
            <View style={{ paddingVertical: BoxSpacing["4xl"], alignItems: "center" }}>
              <ActivityIndicator size="large" color={BoxAccent.gold} />
              <Text style={[BoxTypography.body, { color: BoxText.secondary, marginTop: BoxSpacing.lg }]}>
                {t("leaderboard.loading")}
              </Text>
            </View>
          ) : list.length === 0 ? (
            <BoxEmptyState
              icon={<Trophy size={bs(48)} color={BoxText.tertiary} />}
              title={t("leaderboard.empty")}
            />
          ) : (
            list.map((user: any, idx: number) => {
              const isTop3 = idx < 3;
              const medalColor = MEDAL_COLORS[idx];

              return (
                <View
                  key={`${user.uid}-${idx}`}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    padding: BoxSpacing.lg,
                    borderRadius: BoxRadius.xl,
                    marginBottom: BoxSpacing.sm,
                    backgroundColor: isTop3 ? `${medalColor}15` : BoxSurfaces.card,
                    borderWidth: 1,
                    borderColor: isTop3 ? `${medalColor}40` : BoxBorders.default,
                    ...(isTop3 ? BoxShadows.glow(medalColor!) : BoxShadows.subtle),
                  }}
                >
                  <View style={{ width: bs(32), alignItems: "center", marginRight: BoxSpacing.md }}>
                    {isTop3 ? (
                      <Medal size={bs(22)} color={medalColor} />
                    ) : (
                      <Text style={[BoxTypography.bodyBold, { color: BoxText.tertiary }]}>
                        {idx + 1}
                      </Text>
                    )}
                  </View>

                  <View style={{
                    width: bs(36),
                    height: bs(36),
                    borderRadius: BoxRadius.full,
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: BoxSpacing.md,
                    backgroundColor: BoxSurfaces.elevated,
                  }}>
                    <User size={bs(17)} color={BoxText.tertiary} strokeWidth={1.6} />
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>
                      {user.nickname || t("common.anonymous")}
                    </Text>
                    {showRarity && (
                      <View style={{ flexDirection: "row", alignItems: "center", marginTop: BoxSpacing.xs }}>
                        <RarityBadge tier={user.rarity} size="sm" />
                      </View>
                    )}
                  </View>

                  {renderValue(user)}
                </View>
              );
            })
          )}
        </View>
      </ScrollView>
    </View>
  );
}
