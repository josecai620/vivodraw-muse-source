import React from "react";
import { Asset } from "expo-asset";
import { Image as ExpoImage } from "expo-image";
import type { ImageSourcePropType } from "react-native";

/** Native 端没有 SVGA 运行时，先叠配套静帧。 */
export function preloadAvatarFrameAssets(
  items: { png?: ImageSourcePropType; svga?: number; bytes?: number }[] = [],
) {
  items.forEach((row) => {
    void (async () => {
      try {
        if (typeof row.png === "number") await Asset.fromModule(row.png).downloadAsync();
        if (typeof row.svga === "number") await Asset.fromModule(row.svga).downloadAsync();
      } catch {
        /* ignore */
      }
    })();
  });
}

export function 会员SVGA播放({
  still,
  size,
}: {
  source?: number;
  still: ImageSourcePropType;
  size: number;
  scale?: number;
  playing?: boolean;
  cutout?: number;
}) {
  return (
    <ExpoImage
      source={still}
      style={{ width: size, height: size }}
      contentFit="contain"
      pointerEvents="none"
    />
  );
}
