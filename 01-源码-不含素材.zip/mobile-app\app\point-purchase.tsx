import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import { isGameWalletGame, type GameWalletGame } from "@/lib/api/gameWallet";
import { quotePointPurchase, pointPurchaseExchangeHref } from "@/lib/game/pointPurchaseRecovery";
import { usePointPurchase } from "@/hooks/usePointPurchase";
import { useAuthStore } from "@/store/auth";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Coins, DollarSign, RefreshCw, Wallet } from "lucide-react-native";
import React, { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";

const GAMES: GameWalletGame[] = ["mine", "pearl", "farm"];
const usd = (minor: number) =>
  `$${Math.trunc(minor / 100)}.${String(minor % 100).padStart(2, "0")}`;

export default function PointPurchaseScreen() {
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const { game: routeGame } = useLocalSearchParams<{ game?: string | string[] }>();
  const [game, setGame] = useState<GameWalletGame | null>(null);
  useEffect(() => {
    setGame(isGameWalletGame(routeGame) ? routeGame : null);
  }, [routeGame]);

  const purchase = usePointPurchase(game);
  const { state, review, pending, receipt } = purchase;
  const zh = i18n.language?.startsWith("zh");
  const gameNames: Record<GameWalletGame, string> = {
    mine: zh ? "礦洞" : "Mine",
    pearl: zh ? "尋珠" : "Pearl Lagoon",
    farm: zh ? "農場" : "Farm",
  };
  const coinName: Record<GameWalletGame, string> = {
    mine: zh ? "礦幣" : "mine coins",
    pearl: zh ? "貝殼幣" : "shell coins",
    farm: zh ? "農場金幣" : "farm coins",
  };

  const intent = pending ?? review;
  const quote = state ? quotePointPurchase(state, purchase.pointsText) : undefined;
  const editable =
    !!state && purchase.signedIn && !pending && !purchase.submitting && !purchase.loading && !purchase.storageBlocked;

  const errors = useMemo(
    () => ({
      login: t("pointPurchase.errLogin"),
      load_failed: t("pointPurchase.errLoad"),
      invalid_points: t("pointPurchase.errInvalidPoints"),
      invalid_request: t("pointPurchase.errInvalidRequest"),
      purchase_limit: t("pointPurchase.errLimit", { max: state?.max_points_per_purchase ?? "…" }),
      insufficient_balance: t("pointPurchase.errUsdLow"),
      quote_changed: t("pointPurchase.errQuoteChanged"),
      balance_limit: t("pointPurchase.errBalanceLimit"),
      pending: t("pointPurchase.errPending"),
      request_conflict: t("pointPurchase.errConflict"),
      receipt_mismatch: t("pointPurchase.errReceipt"),
      account_changed: t("pointPurchase.errAccount"),
      storage: t("pointPurchase.errStorage"),
      lock_unavailable: t("pointPurchase.errLock"),
    }),
    [t, state],
  );

  const shownError = purchase.error || (!intent && !receipt && quote?.error ? quote.error : "");
  const rechargeNeeded =
    !intent && (quote?.error === "insufficient_balance" || purchase.error === "insufficient_balance");
  const canRetry =
    !purchase.submitting &&
    !purchase.loading &&
    !purchase.storageBlocked &&
    purchase.error !== "request_conflict" &&
    purchase.error !== "receipt_mismatch" &&
    !!state;

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-neutral-50"
    >
      <PageHeader title={t("pointPurchase.title")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 120 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Text className="text-sm text-neutral-500 leading-5">{t("pointPurchase.subtitle")}</Text>

        {!game ? (
          <View className="bg-white rounded-2xl p-5 gap-3">
            <Text className="text-sm text-neutral-600">{t("pointPurchase.chooseGame")}</Text>
            {GAMES.map((g) => (
              <Pressable
                key={g}
                className="h-11 rounded-xl border border-neutral-200 items-center justify-center active:bg-neutral-50"
                onPress={() => router.setParams({ game: g })}
              >
                <Text className="font-semibold text-neutral-700">{gameNames[g]}</Text>
              </Pressable>
            ))}
          </View>
        ) : null}

        {/* 双余额 */}
        <View className="flex-row gap-3">
          <View className="flex-1 bg-white rounded-2xl p-4">
            <View className="flex-row items-center mb-1">
              <DollarSign size={14} color={Colors.brand.red} />
              <Text className="text-xs text-neutral-500 ml-1.5 font-semibold">
                {t("pointPurchase.usdBalance")}
              </Text>
            </View>
            <Text className="text-2xl font-bold text-neutral-900">
              {state ? usd(state.money_balance_minor) : "—"}
            </Text>
          </View>
          <View className="flex-1 rounded-2xl p-4" style={{ backgroundColor: "#ECFBFB" }}>
            <View className="flex-row items-center mb-1">
              <Coins size={14} color={Colors.brand.red} />
              <Text className="text-xs font-semibold ml-1.5" style={{ color: Colors.brand.redDark }}>
                {t("pointPurchase.pointsBalance")}
              </Text>
            </View>
            <Text className="text-2xl font-bold" style={{ color: Colors.brand.red }}>
              {state ? `${state.point_balance.toLocaleString()} P` : "—"}
            </Text>
          </View>
        </View>

        {!purchase.ready ? (
          <View className="bg-white rounded-2xl p-5 items-center">
            <ActivityIndicator color={Colors.brand.red} />
          </View>
        ) : !purchase.signedIn || !isLoggedIn ? (
          <View className="bg-white rounded-2xl p-5 gap-4">
            <Text className="text-sm text-neutral-600">{t("pointPurchase.signInHint")}</Text>
            <Pressable
              className="h-12 rounded-xl items-center justify-center"
              style={{ backgroundColor: Colors.brand.red }}
              onPress={() => router.push("/auth")}
            >
              <Text className="text-white font-bold">{t("pointPurchase.signIn")}</Text>
            </Pressable>
          </View>
        ) : game ? (
          <View className="bg-white rounded-2xl p-5 gap-4">
            <Text className="text-base font-bold text-neutral-900">{t("pointPurchase.payWithUsd")}</Text>
            <Text className="text-sm text-neutral-600">
              {state
                ? t("pointPurchase.quote", { price: usd(state.price_per_point_minor) })
                : t("pointPurchase.loadingQuote")}
            </Text>
            <Text className="text-xs font-bold text-neutral-500">{t("pointPurchase.pointsToBuy")}</Text>
            <TextInput
              value={purchase.pointsText}
              onChangeText={purchase.changePoints}
              editable={editable}
              keyboardType="number-pad"
              maxLength={12}
              placeholder="0"
              placeholderTextColor={Colors.neutral[400]}
              className="w-full h-14 bg-neutral-50 border border-neutral-200 rounded-xl px-4 text-2xl font-bold text-neutral-900"
            />

            {!intent && !receipt && quote?.money ? (
              <View className="rounded-xl p-4" style={{ backgroundColor: "#F7F9F9" }}>
                <Text className="text-sm text-neutral-600">
                  {t("pointPurchase.pay")} {usd(quote.money)} USD
                </Text>
                <Text className="text-lg font-bold mt-1" style={{ color: Colors.brand.redDark }}>
                  {t("pointPurchase.receive")} {quote.points} P
                </Text>
              </View>
            ) : null}

            {intent ? (
              <View className="rounded-xl p-4 gap-3" style={{ backgroundColor: "#ECFBFB" }}>
                <Text className="text-base font-bold text-neutral-900">
                  {pending ? t("pointPurchase.reviewPrevious") : t("pointPurchase.confirmTitle")}
                </Text>
                <Text className="text-sm text-neutral-700">
                  {t("pointPurchase.deductUsd")} {usd(intent.expected_money_minor)}
                </Text>
                <Text className="text-lg font-bold" style={{ color: Colors.brand.redDark }}>
                  {t("pointPurchase.pointsReceived")} {intent.points} P
                </Text>
                <Pressable disabled={!canRetry} onPress={() => void purchase.submit()}>
                  <LinearGradient
                    colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                    start={{ x: 0, y: 0.5 }}
                    end={{ x: 1, y: 0.5 }}
                    className="h-12 rounded-xl items-center justify-center"
                  >
                    {purchase.submitting ? (
                      <ActivityIndicator color="#fff" size="small" />
                    ) : (
                      <Text className="text-white font-bold">
                        {pending ? t("pointPurchase.retrySame") : t("pointPurchase.confirmBtn")}
                      </Text>
                    )}
                  </LinearGradient>
                </Pressable>
                {!pending ? (
                  <Pressable onPress={purchase.cancelReview} className="h-10 items-center justify-center">
                    <Text className="text-sm text-neutral-500">{t("pointPurchase.editQty")}</Text>
                  </Pressable>
                ) : null}
              </View>
            ) : !receipt ? (
              <Pressable disabled={!editable || !!quote?.error} onPress={purchase.prepare}>
                <LinearGradient
                  colors={
                    editable && !quote?.error
                      ? [TealGradient.light, TealGradient.base, TealGradient.dark]
                      : [Colors.neutral[300], Colors.neutral[300]]
                  }
                  start={{ x: 0, y: 0.5 }}
                  end={{ x: 1, y: 0.5 }}
                  className="h-12 rounded-xl items-center justify-center"
                >
                  <Text className="text-white font-bold">{t("pointPurchase.reviewBtn")}</Text>
                </LinearGradient>
              </Pressable>
            ) : null}

            <Text className="text-xs text-neutral-400 leading-4">{t("pointPurchase.safeHint")}</Text>
            <Pressable
              className="h-10 flex-row items-center justify-center"
              disabled={purchase.loading || purchase.submitting}
              onPress={() => void purchase.refresh()}
            >
              <RefreshCw size={14} color={Colors.neutral[500]} />
              <Text className="text-sm text-neutral-500 ml-2">
                {purchase.loading ? t("pointPurchase.loading") : t("pointPurchase.reload")}
              </Text>
            </Pressable>
          </View>
        ) : null}

        {shownError ? (
          <Text className="text-sm leading-5" style={{ color: Colors.error }}>
            {errors[shownError as keyof typeof errors] ?? errors.pending}
          </Text>
        ) : null}

        {rechargeNeeded && state && game ? (
          <View className="bg-white rounded-2xl p-5 gap-3">
            {state.recharge_available ? (
              <>
                <Text className="text-sm text-neutral-600 leading-5">
                  {t("pointPurchase.rechargeHint", { min: usd(state.min_recharge_minor) })}
                </Text>
                <Pressable
                  className="h-12 rounded-xl bg-white border flex-row items-center justify-center"
                  style={{ borderColor: Colors.brand.red }}
                  disabled={purchase.submitting}
                  onPress={() => router.push(`/wallet?game=${game}&pointPurchase=1`)}
                >
                  <Wallet size={16} color={Colors.brand.red} />
                  <Text className="ml-2 font-bold" style={{ color: Colors.brand.redDark }}>
                    {t("pointPurchase.addUsd")}
                  </Text>
                </Pressable>
              </>
            ) : (
              <Text className="text-sm text-neutral-500">{t("pointPurchase.rechargeUnavailable")}</Text>
            )}
          </View>
        ) : null}

        {receipt ? (
          <View className="rounded-2xl p-5 gap-2" style={{ backgroundColor: "#ECFBFB" }}>
            <Text className="text-base font-bold" style={{ color: Colors.brand.redDark }}>
              {t("pointPurchase.doneTitle")}
            </Text>
            <Text className="text-sm text-neutral-700">
              {t("pointPurchase.actualSpend")} {usd(receipt.money_spent_minor)} USD
            </Text>
            <Text className="text-base font-bold" style={{ color: Colors.brand.redDark }}>
              {t("pointPurchase.actualReceive")} {receipt.point_delta} P
            </Text>
          </View>
        ) : null}

        {game ? (
          <Pressable
            className="h-12 rounded-xl items-center justify-center"
            style={{ backgroundColor: receipt ? Colors.brand.red : "#fff", borderWidth: 1, borderColor: "rgba(12,31,31,0.08)" }}
            disabled={purchase.submitting}
            onPress={() => router.push(pointPurchaseExchangeHref(game))}
          >
            <Text
              className="font-bold"
              style={{ color: receipt ? "#fff" : Colors.neutral[700] }}
            >
              {t("pointPurchase.gotoExchange", { coin: coinName[game] })}
            </Text>
          </Pressable>
        ) : null}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
