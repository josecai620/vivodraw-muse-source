import type { VFXPresetConfig } from '../core/VFXConfig';

export const oreEpicPreset: VFXPresetConfig = { // oreEpicPreset：史诗紫色能量矿石
  id: 'epic',
  label: 'epic',
  glow: {
    enabled: true,
    glowColor: 0x08aeb4,
    glowStrength: 1.05,
    glowSpeed: 1.18,
  },
  flow: {
    enabled: true,
    flowColor: 0x08aeb4,
    flowSpeed: 1.12,
    sweepSpeed: 1.05,
  },
  energy: {
    enabled: true,
    energyColor: 0x08aeb4,
    energyWaveSize: 1,
    energyWaveStrength: 0.92,
  },
  explosion: {
    enabled: true,
    explosionStrength: 0.72,
    explosionDuration: 0.82,
  },
  fire: {
    enabled: false,
    fireIntensity: 0,
    fireSpeed: 0.65,
  },
  spark: {
    enabled: true,
    particleColor: 0x9fe4e6,
    particleCount: 38,
    particleSize: 1,
  },
};
