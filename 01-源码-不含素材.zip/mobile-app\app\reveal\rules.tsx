import React, { useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";

const TEAL = Colors.primary.DEFAULT;

export default function RevealRulesScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [open, setOpen] = useState(0);

  const steps = [
    t("pointsMall.ruleStep1"),
    t("pointsMall.ruleStep2"),
    t("pointsMall.ruleStep3"),
    t("pointsMall.ruleStep4"),
  ];
  const faqs = [
    { q: t("pointsMall.ruleFaq1q"), a: t("pointsMall.ruleFaq1a") },
    { q: t("pointsMall.ruleFaq2q"), a: t("pointsMall.ruleFaq2a") },
    { q: t("pointsMall.ruleFaq3q"), a: t("pointsMall.ruleFaq3a") },
    { q: t("pointsMall.ruleFaq4q"), a: t("pointsMall.ruleFaq4a") },
  ];

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.rules")} />
      <ScrollView contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 16 }}>
        <View className="bg-white px-3 py-3">
          <Text className="text-sm text-gray-700 leading-6">{t("pointsMall.ruleIntro")}</Text>
        </View>
        <View className="bg-white mt-2 px-3 py-3">
          <Text className="text-sm font-bold text-gray-900 mb-2">{t("pointsMall.ruleHow")}</Text>
          {steps.map((text, i) => (
            <Text key={text} className="text-sm text-gray-700 leading-6 mt-1">
              {i + 1}. {text}
            </Text>
          ))}
        </View>
        <View className="bg-white mt-2 px-3 py-3">
          <Text className="text-sm font-bold text-gray-900 mb-2">{t("pointsMall.luckyValue")}</Text>
          <Text className="text-sm text-gray-700 leading-6">{t("pointsMall.ruleLucky")}</Text>
        </View>
        <View className="bg-white mt-2 px-3 py-3">
          <Text className="text-sm font-bold text-gray-900 mb-2">{t("pointsMall.ruleFaq")}</Text>
          {faqs.map((faq, i) => {
            const on = open === i;
            return (
              <Pressable key={faq.q} className="py-2 border-b border-gray-100" onPress={() => setOpen(on ? -1 : i)}>
                <Text className="text-sm font-bold" style={{ color: on ? TEAL : "#111827" }}>
                  {faq.q}
                </Text>
                {on ? <Text className="text-sm text-gray-600 mt-1 leading-6">{faq.a}</Text> : null}
              </Pressable>
            );
          })}
        </View>
        <Pressable
          className="mx-3 mt-4 h-11 rounded items-center justify-center"
          style={{ backgroundColor: TEAL }}
          onPress={() => router.replace("/(tabs)/points")}
        >
          <Text className="text-white font-bold">{t("pointsMall.tabHome")}</Text>
        </Pressable>
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
