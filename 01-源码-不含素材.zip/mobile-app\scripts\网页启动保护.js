/* 在应用脚本前执行；不访问账号、接口或存储，不自动刷新。 */
(function () {
  'use strict';
  var shell = document.getElementById('vivo-startup');
  var root = document.getElementById('root');
  if (!shell || !root) return;
  var message = shell.querySelector('[data-startup-message]');
  var retry = shell.querySelector('button');
  var zh = /^zh/i.test(navigator.language || '');
  var finished = false;
  var slowTimer, observer;
  message.textContent = zh ? '正在載入商城…' : 'Loading your store…';
  retry.textContent = zh ? '重新載入' : 'Try again';

  function ready() {
    // app-ready 事件早于路由真正可用；须等 React 替换初始加载圈。
    return Boolean(root.querySelector('[role="tablist"], input, textarea')) ||
      root.textContent.replace(/\s/g, '').length > 20;
  }
  function finish() {
    if (finished || !ready()) return;
    finished = true;
    clearTimeout(slowTimer);
    if (observer) observer.disconnect();
    window.removeEventListener('error', onError, true);
    window.removeEventListener('offline', onOffline);
    shell.remove();
  }
  function showRetry(text) {
    if (finished) return;
    message.textContent = text;
    retry.hidden = false;
    shell.setAttribute('data-slow', 'true');
  }
  function onError(event) {
    var target = event.target;
    if (target && target.tagName === 'SCRIPT' && /\/_expo\//.test(target.src || '')) {
      showRetry(zh ? '載入中斷，請檢查網路後重試。' : 'Loading was interrupted. Check your connection and try again.');
    }
  }
  function onOffline() {
    showRetry(zh ? '目前沒有網路連線，恢復後請重試。' : 'You are offline. Reconnect and try again.');
  }
  retry.addEventListener('click', function () { window.location.reload(); });
  window.addEventListener('error', onError, true);
  window.addEventListener('offline', onOffline);
  observer = new MutationObserver(finish);
  observer.observe(root, { childList: true, subtree: true, characterData: true });
  slowTimer = setTimeout(function () {
    showRetry(zh ? '載入時間較長，你可以繼續等候或重試。' : 'This is taking longer than usual. You can keep waiting or try again.');
  }, 12000);
  if (navigator.onLine === false) onOffline();
  finish();
}());
