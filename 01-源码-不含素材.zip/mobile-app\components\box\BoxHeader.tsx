import React from "react";
import { View, Text, Pressable, type ViewStyle } from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { ArrowLeft, Sparkles } from "lucide-react-native";
import { useRevealColorScheme } from "@/contexts/RevealColorSchemeContext";
import { RevealColorSchemePicker } from "@/components/reveal/RevealColorSchemePicker";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders,
  BoxTypography, BoxSpacing, BoxLayout, bs,
} from "@/lib/boxTheme";

interface BoxHeaderProps {
  title: string;
  points?: number | string;
  showBack?: boolean;
  showThemeToggle?: boolean;
  rightElement?: React.ReactNode;
  style?: ViewStyle;
}

export function BoxHeader({
  title,
  points,
  showBack = true,
  showThemeToggle = true,
  rightElement,
  style,
}: BoxHeaderProps) {
  const router = useRouter();
  const { colors } = useRevealColorScheme();

  return (
    <LinearGradient
      colors={[BoxSurfaces.deep, BoxSurfaces.card]}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={[{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: BoxSpacing.lg,
        paddingVertical: BoxSpacing.md,
        height: BoxLayout.headerHeight,
        borderBottomWidth: 1,
        borderBottomColor: BoxBorders.subtle,
      }, style]}
    >
      {showBack ? (
        <Pressable
          onPress={() => router.back()}
          hitSlop={12}
          style={{ padding: BoxSpacing.xs, width: bs(36) }}
        >
          <ArrowLeft size={bs(22)} color={BoxText.primary} />
        </Pressable>
      ) : (
        <View style={{ width: bs(36) }} />
      )}

      <View style={{ flex: 1, alignItems: "center" }}>
        <Text style={[BoxTypography.h3, { color: BoxText.primary, letterSpacing: 0.3 }]}>
          {title}
        </Text>
        {points !== undefined && (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 }}>
            <Sparkles size={bs(12)} color={BoxAccent.gold} />
            <Text style={[BoxTypography.caption, { color: BoxAccent.gold }]}>
              {typeof points === "number" ? points.toLocaleString() : points} pts
            </Text>
          </View>
        )}
      </View>

      <View style={{ width: bs(36), alignItems: "flex-end" }}>
        {rightElement ?? (showThemeToggle ? <RevealColorSchemePicker /> : null)}
      </View>
    </LinearGradient>
  );
}
