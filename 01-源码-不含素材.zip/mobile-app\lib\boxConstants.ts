/**
 * 盲盒模块共享常量
 */
export const RARITY_COLORS: Record<
  string,
  { color: string; label: string }
> = {
  common: { color: "#C0C0BE", label: "Common" },
  uncommon: { color: "#919290", label: "Uncommon" },
  rare: { color: "#5E5F5E", label: "Rare" },
  epic: { color: "#2C2E2D", label: "Epic" },
  legendary: { color: "#171A1A", label: "Legendary" },
  secret: { color: "#04A8AE", label: "Secret" },
};
