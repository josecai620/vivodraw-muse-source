import { Platform } from "react-native";
import type { GameWalletGame } from "@/lib/api/gameWallet";

type RequestScope = "recharge" | `point-purchase:${GameWalletGame}`;
const nativeQueues = new Map<string, Promise<unknown>>();

/** 浏览器跨标签使用平台原子锁；原生单JS实例使用账号/业务队列。 */
export async function withAccountRequestLock<T>(uid: number, scope: RequestScope, action: () => Promise<T> | T): Promise<T> {
  if (!Number.isSafeInteger(uid) || uid <= 0) throw new Error("Wrong request owner");
  const name = `vivodraw:${scope}:${uid}`;
  if (Platform.OS === "web") {
    if (typeof navigator === "undefined" || typeof navigator.locks?.request !== "function") throw new Error("request_lock_unavailable");
    const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 30000);
    try { return await navigator.locks.request(name, { mode: "exclusive", signal: controller.signal }, action); }
    finally { clearTimeout(timeout); }
  }
  const previous = nativeQueues.get(name) ?? Promise.resolve();
  const next = previous.catch(() => {}).then(action); nativeQueues.set(name, next);
  try { return await next; } finally { if (nativeQueues.get(name) === next) nativeQueues.delete(name); }
}
