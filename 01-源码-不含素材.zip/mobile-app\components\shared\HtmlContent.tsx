import React from "react";
import { Platform } from "react-native";

interface HtmlContentProps {
  html: string;
  baseStyle?: React.CSSProperties;
}

const defaultStyle: React.CSSProperties = {
  fontSize: 14,
  lineHeight: 1.7,
  color: "#5E5F5E",
  wordBreak: "break-word" as const,
};

export default function HtmlContent({ html, baseStyle }: HtmlContentProps) {
  if (!html) return null;

  const cleanHtml = html
    .replace(/<img /g, '<img loading="lazy" ')
    .replace(/style="[^"]*"/g, (match) => {
      if (match.includes("max-width")) return match;
      return match;
    });

  const wrapperStyle = `
    .html-content img {
      max-width: 100%;
      height: auto;
      display: block;
      border-radius: 8px;
      margin: 8px 0;
    }
    .html-content p {
      margin: 0 0 10px 0;
    }
    .html-content b, .html-content strong {
      font-weight: 600;
      color: #2C2E2D;
    }
  `;

  if (Platform.OS === "web") {
    return React.createElement(
      "div",
      { style: { ...defaultStyle, ...baseStyle } },
      React.createElement("style", null, wrapperStyle),
      React.createElement("div", {
        className: "html-content",
        dangerouslySetInnerHTML: { __html: cleanHtml },
      }),
    );
  }

  const Text = require("react-native").Text;
  const stripped = html.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
  return React.createElement(Text, { style: { fontSize: 14, lineHeight: 22, color: "#5E5F5E" } }, stripped);
}
