import type { VFXPresetConfig } from '../core/VFXConfig';

export const oreCommonPreset: VFXPresetConfig = { // oreCommonPreset：普通矿石弱特效
  id: 'common',
  label: 'common',
  glow: {
    enabled: true,
    glowColor: 0xb9dcdd,
    glowStrength: 0.45,
    glowSpeed: 0.85,
  },
  flow: {
    enabled: false,
    flowColor: 0xb9dcdd,
    flowSpeed: 0.4,
    sweepSpeed: 0.35,
  },
  energy: {
    enabled: false,
    energyColor: 0xb9dcdd,
    energyWaveSize: 0.45,
    energyWaveStrength: 0.25,
  },
  explosion: {
    enabled: false,
    explosionStrength: 0.18,
    explosionDuration: 0.5,
  },
  fire: {
    enabled: false,
    fireIntensity: 0,
    fireSpeed: 0.4,
  },
  spark: {
    enabled: true,
    particleColor: 0xb9dcdd,
    particleCount: 10,
    particleSize: 0.65,
  },
};
