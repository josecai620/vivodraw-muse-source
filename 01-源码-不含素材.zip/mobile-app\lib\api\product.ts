import { API_ENDPOINTS } from "@/constants/api";
import { http } from "@/lib/http";

export interface Product {
  id: number;
  image: string;
  store_name: string;
  price: string | number;
  ot_price: string | number;
  sales: number;
  stock: number | string;
  store_info: string;
  cate_id: number | string;
  ficti?: number;
  keyword?: string;
  unit_name?: string;
  is_hot?: number;
  is_new?: number;
  is_best?: number;
  is_benefit?: number;
  give_integral?: number | string;
}

export interface ProductAttr {
  attr_name: string;
  attr_values?: string;
  attr_value?: string | string[];
}

export interface ProductSku {
  give_integral?: string | number;
  unique?: string;
  suk?: string;
  image?: string;
  price?: string | number;
  ot_price?: string | number;
  stock?: string | number;
}

export type ProductSkuMap = Record<string, ProductSku>;

export interface ProductDetail extends Product {
  slider_image?: string[];
  images?: string[];
  description?: string;
  productAttr?: ProductAttr[];
  productValue?: ProductSkuMap | ProductSku[];
  userCollect?: boolean;
}

export interface ProductDetailPayload {
  storeInfo?: ProductDetail;
  productAttr?: ProductAttr[];
  productValue?: ProductSkuMap | ProductSku[];
}

export interface Category {
  id: number;
  pid: number;
  cate_name: string;
  cate_name_en?: string; // 英文名（双语支持）
  pic: string;
  sort: number;
  children?: Category[];
}

export interface ProductListParams {
  page?: number;
  limit?: number;
  sid?: number;
  cid?: number;
  keyword?: string;
  priceOrder?: string;
  salesOrder?: string;
  news?: number;
}

export function getProductList(params: ProductListParams) {
  return http.get<{ list: Product[]; total: number }>(API_ENDPOINTS.product.list, { params });
}

export function getProductDetail(id: number) {
  return http.get<ProductDetailPayload>(API_ENDPOINTS.product.detail(id));
}

export function getHotProducts(params?: { page?: number; limit?: number }) {
  return http.get<Product[]>(API_ENDPOINTS.product.hot, { params });
}

export function getCategories() {
  return http.get<Category[]>(API_ENDPOINTS.product.category);
}

export function searchProducts(keyword: string, params?: ProductListParams) {
  return http.get<{ list: Product[]; total: number }>(API_ENDPOINTS.product.search, {
    params: { ...params, keyword },
  });
}
