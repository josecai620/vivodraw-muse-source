import React from "react";
import { Modal, Platform, Pressable, Text, View } from "react-native";
import { CheckCircle, AlertCircle, Info } from "lucide-react-native";
import { useAppStore } from "@/store/app";
import { Colors, Shadows } from "@/constants/theme";
import LuxeIcon, { type LuxeIconTone } from "@/components/shared/LuxeIcon";

const icons = {
  success: CheckCircle,
  error: AlertCircle,
  info: Info,
};

const tones: Record<keyof typeof icons, LuxeIconTone> = {
  success: "brand",
  error: "brand",
  info: "brand",
};

function ToastCard({
  message,
  type,
}: {
  message: string;
  type: keyof typeof icons;
}) {
  const Icon = icons[type] ?? icons.info;
  return (
    <View
      className="rounded-2xl px-5 py-4 flex-row items-center gap-2"
      style={{
        maxWidth: 280,
        backgroundColor: "#fff",
        borderWidth: 1,
        borderColor: Colors.screen.hairline,
        ...Shadows.raisedLg,
      }}
    >
      <LuxeIcon Icon={Icon} tone={tones[type] ?? "brand"} size={34} iconSize={17} />
      <Text className="text-[15px] font-semibold" style={{ color: "#171A1A" }}>
        {message}
      </Text>
    </View>
  );
}

function CenterOverlay({
  children,
  onClose,
}: {
  children: React.ReactNode;
  onClose: () => void;
}) {
  return (
    <Pressable
      onPress={onClose}
      style={
        Platform.OS === "web"
          ? ({
              position: "fixed",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              zIndex: 99999,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "rgba(0,0,0,0.28)",
            } as const)
          : {
              flex: 1,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "rgba(0,0,0,0.28)",
            }
      }
    >
      <Pressable onPress={() => undefined}>{children}</Pressable>
    </Pressable>
  );
}

export default function Toast() {
  const { toastMessage, toastType, hideToast } = useAppStore();
  const visible = Boolean(toastMessage && toastType);
  if (!visible || !toastType || !toastMessage) return null;

  const body = (
    <CenterOverlay onClose={hideToast}>
      <ToastCard message={toastMessage} type={toastType} />
    </CenterOverlay>
  );

  if (Platform.OS === "web" && typeof document !== "undefined") {
    const { createPortal } = require("react-dom") as typeof import("react-dom");
    return createPortal(body, document.body);
  }

  return (
    <Modal
      visible
      transparent
      animationType="fade"
      statusBarTranslucent
      onRequestClose={hideToast}
    >
      {body}
    </Modal>
  );
}
