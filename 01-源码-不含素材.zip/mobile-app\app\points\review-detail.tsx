import React, { useMemo, useState } from "react";
import { Image, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useAddShaidanComment, useShaidanDetail, useShaidanDetailComments, useShaidanLike } from "@/hooks";
import { normalizeImageUrl } from "@/lib/utils";

const TEAL = Colors.primary.DEFAULT;
const REACTIONS = ["❤️", "👍", "😂", "🎉", "🔥"];

function toArray(value: any): any[] {
  return Array.isArray(value) ? value : [];
}

export default function PointsReviewDetailScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const reviewId = Number(id ?? 0);
  const [content, setContent] = useState("");
  const addComment = useAddShaidanComment();
  const likeMutation = useShaidanLike();
  const { data: detailData } = useShaidanDetail(reviewId);
  const { data: commentsData } = useShaidanDetailComments(reviewId);

  const detail = (detailData as any)?.data ?? detailData ?? {};
  const review = useMemo(() => {
    const images = toArray(detail?.shaidan_images ?? detail?.images)
      .map((img: string) => normalizeImageUrl(img))
      .filter(Boolean);
    return {
      nickname: String(detail?.nickname ?? t("pointsMall.anonymous")),
      avatar: normalizeImageUrl(detail?.avatar ?? ""),
      storeName: String(detail?.store_name ?? t("pointsMall.pointsProduct")),
      content: String(detail?.content ?? ""),
      addTime: String(detail?.add_time ?? ""),
      likeCount: Number(detail?.dianzhan_num ?? 0),
      commentCount: Number(detail?.pinglun_num ?? 0),
      images,
    };
  }, [detail, t]);

  const comments = useMemo(() => {
    const list = (commentsData as any)?.data?.lists ?? (commentsData as any)?.data?.list ?? (commentsData as any)?.list ?? [];
    return (Array.isArray(list) ? list : []).map((item: any) => ({
      id: Number(item?.id ?? 0),
      nickname: String(item?.nickname ?? t("pointsMall.anonymous")),
      avatar: normalizeImageUrl(item?.avatar ?? ""),
      content: String(item?.content ?? ""),
      addTime: String(item?.add_time ?? item?.create_time ?? ""),
    }));
  }, [commentsData, t]);
  const textComments = comments.filter((item) => !REACTIONS.includes(item.content));
  const reactionCounts = REACTIONS.map((emoji) => ({
    emoji,
    count: comments.filter((item) => item.content === emoji).length,
  }));

  const submitComment = async () => {
    const text = content.trim();
    if (!text || reviewId <= 0) return;
    await addComment.mutateAsync({ shaidanId: reviewId, content: text });
    setContent("");
  };

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.showcasePlaza")} />
      <ScrollView contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 64 }}>
        <View className="bg-white px-3 py-3">
          <Text className="text-sm font-bold text-gray-900">{review.nickname}</Text>
          <Text className="text-xs text-gray-400 mt-0.5">{review.addTime}</Text>
          <Text className="text-xs mt-2" style={{ color: TEAL }}>
            {review.storeName}
          </Text>
          <Text className="text-sm text-gray-700 mt-2 leading-5">{review.content}</Text>
          {review.images.length > 0 ? (
            <View className="flex-row flex-wrap mt-3" style={{ gap: 6 }}>
              {review.images.map((img: string) => (
                <Image key={img} source={{ uri: img }} className="w-[31%] aspect-square rounded bg-gray-100" />
              ))}
            </View>
          ) : null}
          <Pressable className="mt-3 self-start" onPress={() => reviewId > 0 && likeMutation.mutate(reviewId)}>
            <Text className="text-xs" style={{ color: TEAL }}>
              {t("pointsMall.likeCount", { n: review.likeCount })}
            </Text>
          </Pressable>
          <View className="flex-row mt-3" style={{ gap: 8 }}>
            {reactionCounts.map((row) => (
              <Pressable
                key={row.emoji}
                className="px-2 py-1 rounded-full bg-gray-50"
                onPress={() => reviewId > 0 && addComment.mutate({ shaidanId: reviewId, content: row.emoji })}
              >
                <Text className="text-sm">
                  {row.emoji} {row.count || ""}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View className="bg-white mt-2 px-3 py-3">
          <Text className="text-sm font-bold text-gray-900 mb-2">
            {t("pointsMall.commentsTitle", { n: textComments.length || review.commentCount })}
          </Text>
          {textComments.length === 0 ? (
            <Text className="text-xs text-gray-400">{t("pointsMall.noComments")}</Text>
          ) : (
            textComments.map((item) => (
              <View key={item.id || item.addTime} className="py-2 border-b border-gray-100">
                <Text className="text-xs font-semibold text-gray-900">{item.nickname}</Text>
                <Text className="text-sm text-gray-700 mt-1">{item.content}</Text>
                <Text className="text-[11px] text-gray-400 mt-1">{item.addTime}</Text>
              </View>
            ))
          )}
        </View>
      </ScrollView>

      <View
        className="absolute left-0 right-0 bg-white border-t border-gray-100 px-3 py-2 flex-row items-center"
        style={{ bottom: pointsMallTabPaddingBottom(insets.bottom) - 8 }}
      >
        <TextInput
          value={content}
          onChangeText={setContent}
          placeholder={t("pointsMall.writeComment")}
          placeholderTextColor="#9CA3AF"
          className="flex-1 h-10 px-3 rounded bg-gray-100 text-sm text-gray-900"
        />
        <Pressable
          className="ml-2 h-10 px-3 rounded items-center justify-center"
          style={{ backgroundColor: TEAL }}
          onPress={submitComment}
          disabled={addComment.isPending}
        >
          <Text className="text-white text-sm font-bold">{t("pointsMall.sendComment")}</Text>
        </Pressable>
      </View>
      <PointsMallTabBar />
    </View>
  );
}
