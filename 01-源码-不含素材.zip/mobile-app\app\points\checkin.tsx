import React, { useMemo, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Trophy, Calendar, Check, Lock, Sparkles, Gift } from "lucide-react-native";
import { useTranslation } from "react-i18next";
import { TealGradient, Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { BoxChestVFX } from "@/components/box";
import { SignPrizeOpenOverlay } from "@/components/points/SignPrizeOpenOverlay";
import { useSignConfig, useDoSign, useSignMonth, useClaimSignPrize, useBoxDetail } from "@/hooks";
import { unwrapApiData } from "@/lib/api/response";
import { BoxAccent, BoxGradients, BoxRadius, BoxShadows, BoxSpacing, BoxSurfaces, BoxText, BoxTypography, bs } from "@/lib/boxTheme";

const SIGNATURE_CHEST = require("../../assets/box-category-chests/signature-chest.png");

interface CheckInDay {
  day: number;
  points: number;
  checked: boolean;
  isToday?: boolean;
}

function unwrapData(value: unknown) {
  return (value as any)?.data ?? value;
}

function toSafeNumber(value: unknown, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function normalizeCheckInDays(signData: unknown): CheckInDay[] {
  const data = unwrapData(signData);
  const source = Array.isArray((data as any)?.sign_list)
    ? (data as any).sign_list
    : Array.isArray(data)
      ? data
      : [];
  if (!source.length) return [];
  return source.slice(0, 7).map((item: any, index: number) => ({
    day: index + 1,
    points: toSafeNumber(item?.points ?? item?.sign_num ?? item?.integral),
    checked: Boolean(item?.checked ?? item?.is_sign ?? false),
    isToday: Boolean(item?.isToday ?? item?.is_today ?? false),
  }));
}

function normalizeSignStats(signData: unknown) {
  const data = unwrapData(signData);
  const prize = (data as any)?.prize || {};
  return {
    signedToday: Boolean((data as any)?.is_sign ?? false),
    consecutiveDays: toSafeNumber((data as any)?.sum_sgin_day ?? (data as any)?.sign_num ?? prize.sign_num),
    prizeReady: Boolean(prize.ready),
    prizeClaimed: Boolean(prize.claimed),
    prizeName: String(prize.name || "Signature Vault"),
    prizeImage: String(prize.image || ""),
    lastItem: (data as any)?.last_item || null,
  };
}

function normalizeMonthHistory(monthData: unknown) {
  const data = unwrapData(monthData);
  const source = Array.isArray((data as any)?.list)
    ? (data as any).list
    : Array.isArray(data)
      ? data
      : [];
  if (!source.length) return [];
  return source.flatMap((monthItem: any) => {
    const month = String(monthItem?.month ?? monthItem?.time ?? "");
    const records = Array.isArray(monthItem?.list) ? monthItem.list : [];
    return records.map((record: any) => ({
      date: String(record?.add_time ?? record?.date ?? ""),
      points: toSafeNumber(record?.number ?? record?.points),
      month,
    }));
  });
}

export default function PointsCheckInScreen() {
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(false);
  const [localCheckedIn, setLocalCheckedIn] = useState(false);
  const [overlayOpen, setOverlayOpen] = useState(false);
  const [wonItem, setWonItem] = useState<{ name?: string; image?: string } | null>(null);

  const { data: signData } = useSignConfig();
  const doSign = useDoSign();
  const { data: monthData } = useSignMonth();
  const claimPrize = useClaimSignPrize();
  const { data: vault } = useBoxDetail(326);

  const displayCheckInDays = normalizeCheckInDays(signData);
  const signStats = normalizeSignStats(signData);
  const hasCheckedIn = signStats.signedToday || localCheckedIn;
  const consecutiveDays = signStats.consecutiveDays || (hasCheckedIn ? 1 : 0);
  const todayXp =
    displayCheckInDays.find((item) => item.isToday)?.points ||
    displayCheckInDays.find((item) => !item.checked)?.points ||
    0;
  const canOpen = signStats.prizeReady && !signStats.prizeClaimed;
  const signedDays = Math.min(7, consecutiveDays);

  const handleCheckIn = async () => {
    setIsLoading(true);
    try {
      await doSign.mutateAsync();
      setLocalCheckedIn(true);
    } catch {}
    setIsLoading(false);
  };

  const handleOpenGift = async () => {
    if (!canOpen || claimPrize.isPending) return;
    setOverlayOpen(true);
    setWonItem(null);
    try {
      const res = await claimPrize.mutateAsync();
      const payload = unwrapApiData<any>(res, {});
      const item = payload?.item || payload?.data?.item || {};
      setWonItem({ name: item.name, image: item.image });
    } catch {
      setOverlayOpen(false);
    }
  };

  const groupedHistory: Record<string, { date: string; points: number; month: string }[]> = {};
  for (const item of normalizeMonthHistory(monthData)) {
    const month = item.month || t("pointsCheckin.history");
    if (!groupedHistory[month]) groupedHistory[month] = [];
    groupedHistory[month].push(item);
  }

  const vaultName = vault?.name || signStats.prizeName;

  const ctaLabel = useMemo(() => {
    if (signStats.prizeClaimed) return t("pointsCheckin.claimed");
    if (canOpen) return t("pointsCheckin.openNow");
    return t("pointsCheckin.moreDays", { n: Math.max(0, 7 - signedDays) });
  }, [canOpen, signStats.prizeClaimed, signedDays, t]);

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("pointsCheckin.title")} />
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="px-4 mt-4 mb-5">
          <LinearGradient
            colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
            start={{ x: 0.5, y: 0 }}
            end={{ x: 0.5, y: 1 }}
            className="p-6"
            style={{ borderRadius: 24, overflow: "hidden" }}
          >
            <View className="flex-row items-center justify-between mb-5">
              <View>
                <Text className="text-white/80 text-sm">{t("pointsCheckin.consecutive")}</Text>
                <View className="flex-row items-end mt-1">
                  <Trophy size={22} color="#fff" />
                  <Text className="text-white text-4xl font-bold ml-2">{consecutiveDays}</Text>
                </View>
              </View>
              <View className="bg-white/20 px-3 py-1 rounded-full">
                <Text className="text-white text-xs font-semibold">
                  {hasCheckedIn ? t("pointsCheckin.checkedIn") : t("pointsCheckin.notYet")}
                </Text>
              </View>
            </View>
            <Text className="text-white/90 text-sm">{t("pointsCheckin.xpHint")}</Text>
            <View className="h-2 bg-white/20 rounded-full mt-4 overflow-hidden">
              <View className="h-full bg-white rounded-full" style={{ width: `${(signedDays / 7) * 100}%` }} />
            </View>
            <Text className="text-white/80 text-xs mt-2">{signedDays}/7</Text>
          </LinearGradient>
        </View>

        <View className="px-4 mb-5">
          <View className="flex-row items-center mb-3">
            <Calendar size={16} color={Colors.primary.DEFAULT} />
            <Text className="ml-2 text-gray-800 font-semibold">{t("pointsCheckin.calendar")}</Text>
          </View>
          <View className="flex-row justify-between">
            {displayCheckInDays.map((day) => (
              <View key={day.day} className="items-center">
                <View
                  className="w-10 h-10 rounded-full items-center justify-center mb-1"
                  style={{ backgroundColor: day.checked || (day.isToday && hasCheckedIn) ? Colors.primary.DEFAULT : "#E5E7EB" }}
                >
                  {day.checked || (day.isToday && hasCheckedIn) ? (
                    <Check size={16} color="#fff" />
                  ) : day.isToday ? (
                    <Sparkles size={16} color={Colors.primary.DEFAULT} />
                  ) : (
                    <Lock size={14} color="#9CA3AF" />
                  )}
                </View>
                <Text className="text-[10px] text-gray-500">D{day.day}</Text>
                <Text className="text-[10px] text-teal-700">+{day.points}</Text>
              </View>
            ))}
          </View>
          <Pressable
            disabled={hasCheckedIn || isLoading}
            onPress={handleCheckIn}
            className="mt-4 h-12 rounded-full items-center justify-center"
            style={{ backgroundColor: hasCheckedIn ? "#D1D5DB" : Colors.primary.DEFAULT }}
          >
            {isLoading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text className="text-white font-bold">
                {hasCheckedIn ? t("pointsCheckin.checkedToday") : t("pointsCheckin.signToday", { n: todayXp })}
              </Text>
            )}
          </Pressable>
        </View>

        <View className="px-4 mb-5">
          <Pressable
            disabled={!canOpen}
            onPress={handleOpenGift}
            style={({ pressed }) => ({
              borderRadius: BoxRadius["3xl"],
              overflow: "visible",
              opacity: canOpen ? 1 : 0.72,
              transform: [{ scale: pressed && canOpen ? 0.98 : 1 }],
              ...BoxShadows.glow(BoxAccent.gold),
            })}
          >
            <LinearGradient
              colors={BoxGradients.hotPick}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{ padding: BoxSpacing.xl, borderRadius: BoxRadius["3xl"], borderWidth: 1, borderColor: BoxAccent.goldBorder, overflow: "visible" }}
            >
              <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: BoxSpacing.lg }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: BoxSpacing.md, paddingVertical: BoxSpacing.xs, borderRadius: BoxRadius.full, backgroundColor: BoxAccent.gold }}>
                  <Gift size={bs(14)} color="#fff" />
                  <Text style={[BoxTypography.micro, { color: "#fff" }]}>{t("pointsCheckin.prizeBadge")}</Text>
                </View>
                <Text style={[BoxTypography.micro, { color: BoxAccent.gold }]}>{t("pointsCheckin.giftPrice")}</Text>
              </View>
              <View style={{ alignItems: "center" }}>
                <View
                  style={{
                    width: bs(224),
                    height: bs(208),
                    borderRadius: BoxRadius.xl,
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: BoxSpacing.lg,
                    ...BoxShadows.glow(BoxAccent.gold),
                  }}
                >
                  <LinearGradient
                    colors={["rgba(4,168,174,0.10)", "rgba(4,168,174,0.03)"]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={{
                      width: bs(216),
                      height: bs(196),
                      borderRadius: BoxRadius.lg,
                      alignItems: "center",
                      justifyContent: "center",
                      overflow: "visible",
                    }}
                  >
                    <BoxChestVFX image={SIGNATURE_CHEST} tier="legendary" size={216} />
                  </LinearGradient>
                </View>
                <Text style={[BoxTypography.h1, { color: BoxText.primary, textAlign: "center" }]} numberOfLines={2}>{vaultName}</Text>
                <Text style={[BoxTypography.body, { color: BoxText.secondary, textAlign: "center", marginTop: 2 }]}>{t("pointsCheckin.prizeTitle")}</Text>
                <View style={{ width: "100%", marginTop: BoxSpacing.md }}>
                  <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 4 }}>
                    <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>{t("pointsCheckin.progressSigned", { n: signedDays })}</Text>
                    <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>{t("pointsCheckin.progressGoal")}</Text>
                  </View>
                  <View style={{ height: 6, borderRadius: 3, backgroundColor: BoxSurfaces.elevated, overflow: "hidden" }}>
                    <View style={{ height: "100%", width: `${(signedDays / 7) * 100}%`, borderRadius: 3, backgroundColor: BoxAccent.gold }} />
                  </View>
                </View>
                <View style={{ marginTop: BoxSpacing.md, width: "100%", height: 40, borderRadius: 20, alignItems: "center", justifyContent: "center", backgroundColor: canOpen ? BoxAccent.gold : BoxSurfaces.elevated }}>
                  <Text style={{ color: canOpen ? "#fff" : BoxText.secondary, fontWeight: "700" }}>{ctaLabel}</Text>
                </View>
              </View>
              <Text style={[BoxTypography.micro, { color: BoxText.secondary, marginTop: BoxSpacing.md, textAlign: "center" }]}>
                {signStats.prizeClaimed ? t("pointsCheckin.claimedHint") : t("pointsCheckin.lockHint")}
              </Text>
            </LinearGradient>
          </Pressable>
        </View>

        <View className="px-4 mb-8">
          <Text className="text-gray-800 font-semibold mb-3">{t("pointsCheckin.history")}</Text>
          {Object.entries(groupedHistory).map(([month, rows]) => (
            <View key={month} className="mb-4">
              <Text className="text-xs text-gray-400 mb-2">{month}</Text>
              {rows.map((row, idx) => (
                <View key={`${row.date}-${idx}`} className="flex-row items-center justify-between bg-white rounded-2xl px-4 py-3 mb-2">
                  <View className="flex-row items-center">
                    <View className="w-8 h-8 rounded-full bg-teal-50 items-center justify-center mr-3">
                      <Check size={14} color={Colors.primary.DEFAULT} />
                    </View>
                    <Text className="text-sm text-gray-700">{row.date}</Text>
                  </View>
                  <Text className="text-sm text-teal-700">+{row.points} {t("pointsCheckin.xp")}</Text>
                </View>
              ))}
            </View>
          ))}
        </View>
      </ScrollView>
      <SignPrizeOpenOverlay
        visible={overlayOpen}
        opening={claimPrize.isPending}
        item={wonItem}
        onClose={() => setOverlayOpen(false)}
      />
    </View>
  );
}
