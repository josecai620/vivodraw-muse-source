import { useTranslation } from "react-i18next";
import { useCallback } from "react";
import { changeLanguage, LANGUAGE_OPTIONS, type SupportedLanguage } from "@/lib/i18n";

export function useLanguage() {
  const { i18n } = useTranslation();

  const currentLanguage = i18n.language as SupportedLanguage;

  const setLanguage = useCallback(
    async (lang: SupportedLanguage) => {
      await changeLanguage(lang);
    },
    []
  );

  const toggleLanguage = useCallback(async () => {
    const isEn = String(i18n.language || currentLanguage || "").toLowerCase().startsWith("en");
    const next: SupportedLanguage = isEn ? "zh-TW" : "en";
    await changeLanguage(next);
  }, [currentLanguage, i18n.language]);

  return {
    currentLanguage,
    setLanguage,
    toggleLanguage,
    languages: LANGUAGE_OPTIONS,
  };
}
