/**
 * 盲盒订单列表 - FlatList with infinite scroll + payment countdown
 */
import React, { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Pressable,
  FlatList,
  Text,
  View,
  ActivityIndicator,
} from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { Timer, Package } from "lucide-react-native";
import {
  BoxHeader,
  RarityBadge,
  BoxActionButton,
  BoxEmptyState,
  BoxProgressBar,
  BoxTabBar,
  CountdownTimer,
} from "@/components/box";
import { NextStepGuide } from "@/components/onboarding/PlayGuides";
import {
  BoxSurfaces,
  BoxAccent,
  BoxText,
  BoxBorders,
  BoxGradients,
  BoxTypography,
  BoxSpacing,
  BoxRadius,
  BoxShadows,
  getRarityTier,
  bs,
} from "@/lib/boxTheme";
import { useSendOrderList } from "@/hooks";

type TabKey = "all" | "pending" | "paid" | "shipped" | "completed";

const TAB_KEYS: { key: TabKey; labelKey: string; status?: number }[] = [
  { key: "all", labelKey: "orders.tabAll" },
  { key: "pending", labelKey: "orders.tabPending", status: 0 },
  { key: "paid", labelKey: "orders.tabPaid", status: 1 },
  { key: "shipped", labelKey: "orders.tabShipped", status: 2 },
  { key: "completed", labelKey: "orders.tabCompleted", status: 3 },
];

const ORDER_EXPIRE_SECONDS = 30 * 60;

function mapOrderStatus(status: number): { key: string; color: string } {
  switch (status) {
    case 0:
      return { key: "pending", color: BoxAccent.gold };
    case 1:
      return { key: "paid", color: BoxAccent.blue };
    case 2:
      return { key: "shipped", color: BoxAccent.purple };
    case 3:
      return { key: "completed", color: BoxAccent.green };
    case -1:
      return { key: "cancelled", color: BoxText.tertiary };
    default:
      return { key: "unknown", color: BoxText.tertiary };
  }
}

function parseTimestamp(raw: string | number | undefined): number {
  if (!raw) return 0;
  if (typeof raw === "number") return raw > 1e12 ? raw : raw * 1000;
  const ms = new Date(raw).getTime();
  return isNaN(ms) ? 0 : ms;
}

function CountdownBadge({
  addTime,
  t,
}: {
  addTime: string | number;
  t: (key: string, opts?: { time?: string }) => string;
}) {
  const [remaining, setRemaining] = useState(0);

  useEffect(() => {
    const createdMs = parseTimestamp(addTime);
    if (!createdMs) return;
    const expireMs = createdMs + ORDER_EXPIRE_SECONDS * 1000;

    const tick = () => Math.max(0, expireMs - Date.now());
    setRemaining(tick());

    const timer = setInterval(() => {
      const left = tick();
      setRemaining(left);
      if (left <= 0) clearInterval(timer);
    }, 1000);
    return () => clearInterval(timer);
  }, [addTime]);

  if (remaining <= 0) return null;

  const mins = Math.floor(remaining / 60000);
  const secs = Math.floor((remaining % 60000) / 1000);

  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: BoxSpacing.xs,
        marginTop: BoxSpacing.xs,
      }}
    >
      <Timer size={bs(12)} color={BoxAccent.gold} />
      <Text style={[BoxTypography.micro, { color: BoxAccent.gold }]}>
        {t("orders.autoCancel", {
          time: `${mins}:${secs.toString().padStart(2, "0")}`,
        })}
      </Text>
    </View>
  );
}

export default function BoxOrdersScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<TabKey>("all");
  const [page, setPage] = useState(1);
  const [allOrders, setAllOrders] = useState<any[]>([]);

  const currentTab = TAB_KEYS.find((tab) => tab.key === activeTab);
  const {
    data: orderData,
    isLoading,
    isFetching,
  } = useSendOrderList({
    page,
    status: currentTab?.status,
  });

  const total = orderData?.total ?? 0;
  const hasMore = allOrders.length < total;

  useEffect(() => {
    const list = Array.isArray(orderData?.list) ? orderData.list : [];
    if (list.length === 0) return;
    setAllOrders((prev) => (page === 1 ? list : [...prev, ...list]));
  }, [orderData, page]);

  const switchTab = useCallback((key: TabKey) => {
    setActiveTab(key);
    setPage(1);
    setAllOrders([]);
  }, []);

  const loadMore = useCallback(() => {
    if (!isFetching && hasMore) setPage((p) => p + 1);
  }, [isFetching, hasMore]);

  const tabs = TAB_KEYS.map((tab) => ({
    key: tab.key,
    label: t(tab.labelKey),
  }));

  const renderOrder = useCallback(
    ({ item: order }: { item: any }) => {
      const status = mapOrderStatus(order.status ?? order.pay_status ?? 0);
      const products =
        order.products ||
        (order.product_json ? JSON.parse(order.product_json) : []);
      const isPending = (order.status ?? order.pay_status) === 0;

      return (
        <Pressable
          onPress={() => router.push(`/box/order-detail?id=${order.id}`)}
          style={{
            backgroundColor: BoxSurfaces.card,
            borderRadius: BoxRadius.xl,
            borderWidth: 1,
            borderColor: BoxBorders.default,
            marginBottom: BoxSpacing.md,
            overflow: "hidden",
            ...BoxShadows.card,
          }}
        >
          <View style={{ padding: BoxSpacing.lg }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: BoxSpacing.md,
              }}
            >
              <Text style={[BoxTypography.caption, { color: BoxText.tertiary }]}>
                {t("orders.orderId", {
                  id: order.order_id || order.unique || order.id,
                })}
              </Text>
              <View
                style={{
                  paddingHorizontal: BoxSpacing.sm,
                  paddingVertical: BoxSpacing.xs,
                  borderRadius: BoxRadius.sm,
                  backgroundColor: `${status.color}20`,
                  borderWidth: 1,
                  borderColor: `${status.color}30`,
                }}
              >
                <Text style={[BoxTypography.micro, { color: status.color }]}>
                  {t(`order.status.${status.key}`)}
                </Text>
              </View>
            </View>

            {Array.isArray(products) &&
              products.slice(0, 3).map((p: any, idx: number) => (
                <View
                  key={idx}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: BoxSpacing.md,
                    marginBottom: BoxSpacing.sm,
                  }}
                >
                  <View
                    style={{
                      width: bs(48),
                      height: bs(48),
                      borderRadius: BoxRadius.md,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: BoxSurfaces.deep,
                    }}
                  >
                    {p.image && /^https?:\/\//.test(p.image) ? (
                      <Image
                        source={{ uri: p.image }}
                        style={{
                          width: bs(40),
                          height: bs(40),
                          borderRadius: BoxRadius.sm,
                        }}
                        contentFit="cover"
                      />
                    ) : (
                      <Package size={bs(20)} color={BoxAccent.gold} strokeWidth={1.6} />
                    )}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={[BoxTypography.bodyBold, { color: BoxText.primary }]}
                      numberOfLines={1}
                    >
                      {p.name || p.store_name || t("orders.defaultProduct")}
                    </Text>
                    <Text
                      style={[BoxTypography.caption, { color: BoxText.tertiary }]}
                    >
                      x{p.num || 1}
                    </Text>
                  </View>
                </View>
              ))}

            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                marginTop: BoxSpacing.sm,
                paddingTop: BoxSpacing.sm,
                borderTopWidth: 1,
                borderTopColor: BoxBorders.subtle,
              }}
            >
              <View>
                <Text
                  style={[BoxTypography.caption, { color: BoxText.tertiary }]}
                >
                  {order.add_time || order.createtime || ""}
                </Text>
                {isPending && (
                  <CountdownBadge
                    addTime={order.add_time || order.createtime || ""}
                    t={t}
                  />
                )}
              </View>
              <Text style={[BoxTypography.price, { color: BoxAccent.gold }]}>
                ¥{order.pay_price || order.total_price || 0}
              </Text>
            </View>
          </View>
        </Pressable>
      );
    },
    [router, t]
  );

  const ListFooter = () => {
    if (isFetching && page > 1) {
      return (
        <View
          style={{ alignItems: "center", paddingVertical: BoxSpacing.lg }}
        >
          <ActivityIndicator size="small" color={BoxAccent.gold} />
        </View>
      );
    }
    if (!hasMore && allOrders.length > 0) {
      return (
        <Text
          style={[
            BoxTypography.caption,
            {
              color: BoxText.tertiary,
              textAlign: "center",
              paddingVertical: BoxSpacing.lg,
            },
          ]}
        >
          {t("orders.noMore")}
        </Text>
      );
    }
    return null;
  };

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("orders.title")} showThemeToggle={false} />

      <BoxTabBar
        tabs={tabs}
        activeKey={activeTab}
        onSelect={(key) => switchTab(key as TabKey)}
        style={{
          backgroundColor: BoxSurfaces.deep,
          borderBottomWidth: 1,
          borderBottomColor: BoxBorders.subtle,
        }}
      />

      <NextStepGuide kind="boxOrders" />

      {isLoading && page === 1 ? (
        <View
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        >
          <ActivityIndicator size="large" color={BoxAccent.gold} />
          <Text
            style={[
              BoxTypography.body,
              { color: BoxText.secondary, marginTop: BoxSpacing.lg },
            ]}
          >
            {t("common.loading")}
          </Text>
        </View>
      ) : allOrders.length === 0 ? (
        <BoxEmptyState
          icon={<Package size={bs(48)} color={BoxText.tertiary} />}
          title={t("orders.empty")}
          style={{ flex: 1 }}
        />
      ) : (
        <FlatList
          data={allOrders}
          keyExtractor={(item) => String(item.id)}
          renderItem={renderOrder}
          contentContainerStyle={{
            padding: BoxSpacing.lg,
            paddingBottom: bs(96),
          }}
          onEndReached={loadMore}
          onEndReachedThreshold={0.3}
          ListFooterComponent={ListFooter}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}
