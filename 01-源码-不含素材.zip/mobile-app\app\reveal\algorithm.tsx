/**
 * 揭晓验算页（T10）——只渲染服务端开奖快照（RevealView）。
 * 公开公式：S = 时间键之和，M = S mod N，幸运码 = 10000001 + M。
 * 不读参考实现 v2/luck 校正，不伪造明细行。
 */
import React, { useMemo, useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useRevealVerify, useRevealView } from "@/hooks";
import {
  formatAtMs,
  formatCodeRanges,
  splitTimeKey,
  verifyRevealView,
  type RevealView,
} from "@/lib/reveal/drawMath";

const TEAL = Colors.primary.DEFAULT;
type Params = { id?: string; productId?: string; bianhao?: string; periodId?: string };

export default function RevealAlgorithmScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<Params>();
  const locator = useMemo(
    () => ({
      periodId: params.periodId || undefined,
      productId: Number(params.productId) || undefined,
      bianhao: Number(params.bianhao) || undefined,
      kaijiangId: Number(params.id) || undefined,
    }),
    [params.periodId, params.productId, params.bianhao, params.id],
  );

  const { data, isLoading, error, refetch } = useRevealView(locator);
  const [serverCheck, setServerCheck] = useState(false);
  const { data: verifyData, isFetching: verifying } = useRevealVerify(locator, serverCheck);

  const envelope = data as { status?: number; msg?: string; data?: RevealView | { periodId?: string; status?: string } } | undefined;
  const view = envelope && envelope.status === 200 && envelope.data && "inputs" in envelope.data ? (envelope.data as RevealView) : null;
  const local = useMemo(() => (view ? verifyRevealView(view) : null), [view]);
  const server = (verifyData as { data?: { ok?: boolean; mismatches?: string[] } } | undefined)?.data;

  if (isLoading) {
    return (
      <Shell title={t("pointsMall.calcTitle")}>
        <Text className="text-gray-400">{t("common.loading")}</Text>
      </Shell>
    );
  }

  if (!view) {
    const msg = (envelope?.msg || (error as Error | undefined)?.message || "").trim();
    return (
      <Shell title={t("pointsMall.calcTitle")}>
        <View className="bg-white rounded-xl p-5 items-center mx-3">
          <Text className="text-sm text-gray-700 text-center">{msg || t("pointsMall.calcNoSnapshot")}</Text>
          <Pressable onPress={() => refetch()} className="mt-4 h-10 px-4 rounded items-center justify-center" style={{ backgroundColor: TEAL }}>
            <Text className="text-white font-bold">{t("pointsMall.calcRefresh")}</Text>
          </Pressable>
        </View>
      </Shell>
    );
  }

  const resolved = view.status === "resolved";
  const frozen = formatAtMs(view.frozenAt * 1000, view.tz);
  const reveal = formatAtMs(view.revealAt * 1000, view.tz);
  const sumText = resolved ? String(view.sum) : "—";
  const modText = resolved ? String(view.modulo) : "—";
  const luckyText = resolved ? String(view.luckyCode) : "—";

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.calcTitle")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 16 }}
        showsVerticalScrollIndicator={false}
      >
        <View className="bg-white px-3 py-3">
          <Text className="text-sm font-bold text-gray-900">{view.product.name || t("pointsMall.pointsProduct")}</Text>
          <Text className="text-xs mt-1" style={{ color: TEAL }}>
            {t("pointsMall.periodN", { n: view.periodNo })} · N = {view.totalShares}
          </Text>
          <Text className="text-xs text-gray-400 mt-1">
            {t("pointsMall.calcFrozen")} {frozen.date} {frozen.time.slice(0, 8)}
          </Text>
          <Text className="text-xs text-gray-400">
            {t("pointsMall.calcRevealAt")} {reveal.date} {reveal.time.slice(0, 8)}
          </Text>
        </View>

        <View className="bg-white mt-2 mx-3 rounded-xl p-4">
          <Text className="text-sm font-bold text-gray-900 mb-3">{t("pointsMall.calcHow")}</Text>
          <Text className="text-sm text-gray-700 leading-6">
            1. {t("pointsMall.calcStepSum")}：
            <Text className="font-mono font-bold"> {sumText}</Text>
          </Text>
          <Text className="text-sm text-gray-700 leading-6 mt-1">
            2. {t("pointsMall.calcStepMod")}：{sumText} % {view.totalShares} =
            <Text className="font-mono font-bold"> {modText}</Text>
          </Text>
          <Text className="text-sm text-gray-700 leading-6 mt-1">
            3. {t("pointsMall.calcStepResult")}：{modText} + 10000001 =
            <Text className="font-black" style={{ color: TEAL }}>
              {" "}
              {luckyText}
            </Text>
          </Text>
          {view.winner ? (
            <Text className="text-xs text-gray-500 mt-3">
              {t("pointsMall.winnerLabel")} {view.winner.displayName} · {formatCodeRanges(view.winner.codeRanges)}
            </Text>
          ) : null}
          {view.my && view.my.codes.length > 0 ? (
            <Text className="text-xs text-gray-500 mt-1">
              {t("pointsMall.yourCodes")}
              {view.my.won ? ` · ${t("pointsMall.youWon")}` : ""}：{view.my.codes.join(", ")}
            </Text>
          ) : null}
        </View>

        {local ? (
          <View className="bg-white mt-2 mx-3 rounded-xl p-4">
            <Text className="text-sm font-bold" style={{ color: local.ok ? TEAL : "#111827" }}>
              {resolved ? (local.ok ? t("pointsMall.calcLocalOk") : t("pointsMall.calcLocalFail")) : t("pointsMall.calcLocalFrozen")}
            </Text>
            {local.recomputed ? (
              <Text className="text-xs font-mono text-gray-600 mt-1">
                S={local.recomputed.sum} · M={local.recomputed.modulo} · {local.recomputed.luckyCode}
              </Text>
            ) : null}
            {local.mismatches.map((m) => (
              <Text key={m} className="text-xs text-gray-500 mt-1">
                {m}
              </Text>
            ))}
            <Pressable className="mt-3 self-start" onPress={() => setServerCheck(true)}>
              <Text className="text-xs font-bold" style={{ color: TEAL }}>
                {verifying
                  ? t("common.loading")
                  : server
                    ? server.ok
                      ? t("pointsMall.calcServerOk")
                      : t("pointsMall.calcServerFail")
                    : t("pointsMall.calcServerCheck")}
              </Text>
            </Pressable>
          </View>
        ) : null}

        <View className="bg-white mt-2">
          <View className="px-3 py-2 border-b border-gray-100 flex-row">
            <Text className="flex-1 text-xs font-bold text-gray-500">{t("pointsMall.calcBuyTime")}</Text>
            <Text className="w-24 text-xs font-bold text-gray-500">{t("pointsMall.calcTimeKey")}</Text>
            <Text className="w-20 text-xs font-bold text-gray-500 text-right">{t("pointsMall.calcUser")}</Text>
          </View>
          {view.inputs.map((row) => {
            const time = formatAtMs(row.atMs, view.tz);
            const k = splitTimeKey(row.timeKey);
            const isEnd = row.seq === 0;
            return (
              <View
                key={`${row.seq}-${row.recordId}`}
                className="px-3 py-2 flex-row items-center border-b border-gray-50"
                style={isEnd ? { backgroundColor: Colors.primary.softer } : undefined}
              >
                <View className="flex-1">
                  <Text className="text-xs text-gray-800">
                    {time.date} {time.time}
                    {isEnd ? ` · ${t("pointsMall.filledPeriod")}` : ""}
                  </Text>
                </View>
                <Text className="w-24 text-xs font-mono text-gray-700">
                  {k.hh}
                  {k.mm}
                  {k.ss}
                  <Text className="text-gray-400">{k.ms}</Text>
                </Text>
                <Text className="w-20 text-xs text-gray-600 text-right" numberOfLines={1}>
                  {row.displayName || t("pointsMall.anonymous")}
                </Text>
              </View>
            );
          })}
        </View>
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}

function Shell({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={title} />
      <View className="flex-1 items-center justify-center px-4">{children}</View>
      <PointsMallTabBar />
    </View>
  );
}
