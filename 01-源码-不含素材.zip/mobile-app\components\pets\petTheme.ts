// 桌宠组件从 v3 移植，保留其 theme 取值方式，颜色对齐方向 C / teal 体系
export const theme = {
  colors: {
    accent: "#04A8AE",
    accentDeep: "#07858C",
    accentSoft: "#ECFBFB",
    amber: "#F59E0B",
    hairline: "rgba(12,31,31,0.08)",
    muted: "#787976",
    neon: "#33C6CC",
    nightBase: "#050816",
    nightPanel: "#0F2A2C",
    nightInk: "#eef1ff",
    nightMute: "#98a0d8",
    nightBorder: "rgba(132, 120, 255, 0.28)",
    nightPanelSoft: "#121a3e",
    violetSoft: "#2a215a",
    surface: "#FFFFFF",
    violet: "#8B5CF6",
  },
  radius: { pill: 999 },
  spacing: { xs: 4, md: 12 },
  typography: {
    family: { ui: "System" as const },
    size: { xs: 11, sm: 13, md: 15, lg: 18 },
  },
};
