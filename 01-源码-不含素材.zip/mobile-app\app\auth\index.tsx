import React, { useState, useRef, useCallback } from "react";
import {
  ActivityIndicator,
  Animated,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { Eye, EyeOff, Lock, Mail, RefreshCw, ShieldAlert } from "lucide-react-native";
import { Colors, TealGradient } from "@/constants/theme";
import { LinearGradient } from "expo-linear-gradient";
import TealSurface from "@/components/ui/TealSurface";
import { LuxeIcon, PageHeader } from "@/components/shared";
import { login, getLoginCaptcha, getUserProfile, type LoginParams } from "@/lib/api/user";
import { ApiError } from "@/lib/http";
import { useAuthStore } from "@/store/auth";
import { useAppStore } from "@/store/app";

export default function LoginScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const setToken = useAuthStore((s) => s.setToken);
  const setUser = useAuthStore((s) => s.setUser);
  const showToast = useAppStore((s) => s.showToast);

  const [account, setAccount] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [failCount, setFailCount] = useState(0);
  const [locked, setLocked] = useState(false);

  const [captchaKey, setCaptchaKey] = useState("");
  const [captchaImg, setCaptchaImg] = useState("");
  const [captchaCode, setCaptchaCode] = useState("");
  const [captchaLoading, setCaptchaLoading] = useState(false);

  const shakeAnim = useRef(new Animated.Value(0)).current;

  const triggerShake = useCallback(() => {
    shakeAnim.setValue(0);
    Animated.sequence([
      Animated.timing(shakeAnim, { toValue: 10, duration: 50, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -10, duration: 50, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 8, duration: 50, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: -8, duration: 50, useNativeDriver: true }),
      Animated.timing(shakeAnim, { toValue: 0, duration: 50, useNativeDriver: true }),
    ]).start();
  }, [shakeAnim]);

  const needCaptcha = failCount >= 3;
  const showForgotHint = failCount >= 2;

  const loadCaptcha = useCallback(async () => {
    setCaptchaLoading(true);
    try {
      const res: any = await getLoginCaptcha();
      const d = res?.data ?? res;
      setCaptchaKey(d.key);
      setCaptchaImg(d.img);
      setCaptchaCode("");
    } catch {
      showToast(t("auth.captchaFailed"), "error");
    } finally {
      setCaptchaLoading(false);
    }
  }, [showToast, t]);

  const handleLogin = async () => {
    setErrorMsg("");
    if (!account.trim()) {
      setErrorMsg(t("auth.pleaseEnterAccount"));
      triggerShake();
      return;
    }
    if (!password.trim()) {
      setErrorMsg(t("auth.pleaseEnterPassword"));
      triggerShake();
      return;
    }
    if (needCaptcha && !captchaCode.trim()) {
      setErrorMsg(t("auth.pleaseEnterCaptcha"));
      triggerShake();
      return;
    }

    setLoading(true);
    try {
      const params: LoginParams = {
        account: account.trim(),
        password: password.trim(),
      };
      if (needCaptcha) {
        params.captcha_key = captchaKey;
        params.captcha_code = captchaCode.trim();
      }
      const res: any = await login(params);
      const token = res?.data?.token ?? res?.token;
      if (!token) {
        setErrorMsg(t("auth.loginFailedNoToken"));
        triggerShake();
        return;
      }
      setToken(token);
      setFailCount(0);
      setErrorMsg("");

      try {
        const profileRes: any = await getUserProfile();
        const profile = profileRes?.data ?? profileRes;
        if (profile?.uid) setUser(profile);
      } catch {}

      showToast(t("auth.loginSuccessful"), "success");
      router.replace("/(tabs)");
    } catch (err: any) {
      const apiErr = err instanceof ApiError ? err : null;
      const data = apiErr?.data as Record<string, unknown> | undefined;
      const fc = typeof data?.fail_count === "number" ? data.fail_count : failCount + 1;
      setFailCount(fc);

      if (data?.locked) {
        setLocked(true);
        setErrorMsg(t("auth.tooManyAttempts"));
      } else {
        setLocked(false);
        setErrorMsg(t("auth.incorrectCredentials"));
      }

      if (data?.need_captcha || fc >= 3) {
        loadCaptcha();
      }
      triggerShake();
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-gray-50"
    >
      <PageHeader title="" />

      <ScrollView className="flex-1 px-4 py-8" showsVerticalScrollIndicator={false}>
        <TealSurface
          direction="tb"
          radius={16}
          style={{ width: 64, height: 64, marginBottom: 16 }}
          contentStyle={{ alignItems: "center", justifyContent: "center" }}
        >
          <Text className="text-white text-2xl font-bold" style={{ backgroundColor: "transparent" }}>S</Text>
        </TealSurface>

        <Text className="text-3xl font-bold text-gray-900 mb-2">{t("auth.welcomeBack")}</Text>
        <Text className="text-gray-600 mb-8">{t("auth.signInToContinue")}</Text>

        <Text className="text-sm font-medium text-gray-700 mb-2">{t("auth.account")}</Text>
        <View className="relative mb-4">
          <View className="absolute left-2.5 top-2.5 z-10">
            <LuxeIcon Icon={Mail} tone="neutral" variant="soft" size={28} iconSize={14} />
          </View>
          <TextInput
            value={account}
            onChangeText={(t) => { setAccount(t); setErrorMsg(""); }}
            placeholder={t("auth.phoneOrEmail")}
            placeholderTextColor={Colors.neutral[400]}
            keyboardType="email-address"
            autoCapitalize="none"
            className="w-full pl-12 pr-4 h-12 bg-white border border-gray-200 rounded-2xl text-sm"
            style={{ color: Colors.luxe.ink, fontWeight: "500" }}
          />
        </View>

        <Text className="text-sm font-medium text-gray-700 mb-2">{t("auth.password")}</Text>
        <Animated.View
          className="relative mb-1"
          style={{ transform: [{ translateX: shakeAnim }] }}
        >
          <View className="absolute left-2.5 top-2.5 z-10">
            <LuxeIcon Icon={Lock} tone="neutral" variant="soft" size={28} iconSize={14} />
          </View>
          <TextInput
            value={password}
            onChangeText={(t) => { setPassword(t); setErrorMsg(""); }}
            placeholder={t("auth.enterPassword")}
            placeholderTextColor={Colors.neutral[400]}
            secureTextEntry={!showPassword}
            className={`w-full pl-12 pr-12 h-12 bg-white border rounded-2xl text-sm ${
              errorMsg ? "border-brand-red-light" : "border-gray-200"
            }`}
            style={{ color: Colors.luxe.ink, fontWeight: "500" }}
          />
          <Pressable
            className="absolute right-2.5 top-2.5 z-10"
            onPress={() => setShowPassword(!showPassword)}
          >
            <LuxeIcon
              Icon={showPassword ? EyeOff : Eye}
              tone="neutral"
              variant="soft"
              size={28}
              iconSize={14}
            />
          </Pressable>
        </Animated.View>

        {errorMsg ? (
          <View className="flex-row items-center mb-3 mt-1">
            <LuxeIcon Icon={ShieldAlert} tone="brand" variant="soft" size={24} iconSize={12} />
            <Text className="text-brand-red text-xs ml-1 flex-1">{errorMsg}</Text>
          </View>
        ) : (
          <View className="mb-4" />
        )}

        {needCaptcha && !locked && (
          <View className="mb-4 p-3 bg-neutral-50 border border-neutral-200 rounded-xl">
            <Text className="text-sm text-neutral-700 mb-2 font-medium">
              {t("auth.captchaRequired")}
            </Text>
            <View className="flex-row items-center gap-2">
              <TextInput
                value={captchaCode}
                onChangeText={setCaptchaCode}
                placeholder={t("auth.enterCaptcha")}
                placeholderTextColor={Colors.neutral[400]}
                autoCapitalize="none"
                className="flex-1 h-10 bg-white border border-gray-200 rounded-lg px-3 text-sm"
              />
              {captchaImg ? (
                <Pressable onPress={loadCaptcha} className="flex-row items-center">
                  <Image
                    source={{ uri: captchaImg }}
                    style={{ width: 100, height: 36, borderRadius: 6 }}
                    resizeMode="contain"
                  />
                </Pressable>
              ) : (
                <Pressable
                  onPress={loadCaptcha}
                  className="h-10 px-3 bg-gray-100 rounded-lg items-center justify-center"
                >
                  {captchaLoading ? (
                    <ActivityIndicator size="small" color={Colors.brand.red} />
                  ) : (
                    <Text className="text-sm" style={{ color: Colors.brand.red }}>
                      {t("auth.getCaptcha")}
                    </Text>
                  )}
                </Pressable>
              )}
              {captchaImg ? (
                <Pressable onPress={loadCaptcha} className="p-1">
                  <LuxeIcon Icon={RefreshCw} tone="brand" variant="soft" size={30} iconSize={15} />
                </Pressable>
              ) : null}
            </View>
          </View>
        )}

        {locked && (
          <View className="mb-4 p-4 bg-brand-red-light border border-brand-red-light rounded-xl flex-row items-center">
            <LuxeIcon Icon={ShieldAlert} tone="brand" variant="soft" size={36} iconSize={18} />
            <View className="ml-3 flex-1">
              <Text className="text-brand-red font-semibold text-sm">{t("auth.accountLocked")}</Text>
              <Text className="text-brand-red text-xs mt-0.5">
                {t("auth.accountLockedDesc")}
              </Text>
            </View>
          </View>
        )}

        <View className="flex-row items-center justify-end mb-6">
          {showForgotHint && !locked && (
            <Text className="text-xs text-neutral-600 mr-2">{t("auth.multipleErrors")}</Text>
          )}
          <Pressable onPress={() => router.push("/auth/forgot-password")}>
            <Text
              className="text-sm font-semibold"
              style={{ color: showForgotHint ? "#EF4444" : Colors.brand.red }}
            >
              {t("auth.forgotPassword")}
            </Text>
          </Pressable>
        </View>

        <Pressable
          className="w-full h-12 rounded-xl items-center justify-center mb-6"
          style={{
            backgroundColor: locked ? Colors.neutral[300] : "transparent",
            opacity: loading ? 0.7 : 1,
            shadowColor: "#04A8AE",
            shadowOffset: { width: 0, height: 6 },
            shadowOpacity: locked ? 0 : 0.3,
            shadowRadius: 12,
            elevation: locked ? 0 : 6,
          }}
          onPress={handleLogin}
          disabled={loading || locked}
        >
          {!locked && (
            <>
              <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
              <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
            </>
          )}
          {loading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Text className="text-white font-semibold">
              {locked ? t("auth.accountLockedBtn") : t("auth.signIn")}
            </Text>
          )}
        </Pressable>

        <View className="flex-row justify-center mb-8">
          <Text className="text-sm text-gray-600">{t("auth.dontHaveAccount")}</Text>
          <Pressable onPress={() => router.push("/auth/register")}>
            <Text className="text-sm font-semibold" style={{ color: Colors.brand.red }}>
              {t("auth.signUp")}
            </Text>
          </Pressable>
        </View>

        <View className="flex-row flex-wrap justify-center items-center gap-x-1 mb-4">
          <Text className="text-xs text-gray-500">{t("auth.agreementPrefix")}</Text>
          <Pressable onPress={() => router.push("/agreement/register_agreement")}>
            <Text className="text-xs font-medium" style={{ color: Colors.brand.red }}>
              {t("auth.termsOfService")}
            </Text>
          </Pressable>
          <Text className="text-xs text-gray-500">{t("auth.and")}</Text>
          <Pressable onPress={() => router.push("/agreement/privacy_agreement")}>
            <Text className="text-xs font-medium" style={{ color: Colors.brand.red }}>
              {t("auth.privacyPolicy")}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
