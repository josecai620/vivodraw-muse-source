import React from "react";
import { useTranslation } from "react-i18next";
import { Pressable, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { Colors, Fonts, Shadows, s } from "@/constants/theme";
import { pickLang } from "./utils";

export interface HlGroupLotteryProps {
  props: Record<string, any>;
  lang: string;
}

export default function HlGroupLottery({ props, lang }: HlGroupLotteryProps) {
  const { t } = useTranslation();
  const router = useRouter();
  const title = pickLang(props.title, lang) || t("home.groupLottery.title");
  const desc = pickLang(props.desc, lang) || t("home.groupLottery.desc");
  const cta = pickLang(props.cta, lang) || t("home.groupLottery.cta");
  const link = typeof props.link === "string" && props.link ? props.link : "/group-lottery";

  return (
    <Pressable
      style={{
        marginHorizontal: s(16),
        marginTop: s(14),
        borderRadius: s(22),
        padding: s(18),
        backgroundColor: "#F7F8F8",
        borderWidth: 1,
        borderColor: Colors.home.border,
        ...Shadows.warmCard,
      }}
      onPress={() => router.push(link as any)}
    >
      <View className="flex-row items-center justify-between">
        <View className="flex-1 pr-3">
          <Text style={{ color: Colors.accent.orange, fontFamily: Fonts.display, fontSize: s(27), lineHeight: s(32), fontWeight: "400" }}>
            🎁 {title}
          </Text>
          <Text style={{ color: Colors.home.muted, fontSize: s(13), marginTop: s(6), fontWeight: "600" }}>
            {desc}
          </Text>
        </View>
        <View className="rounded-full px-3 py-1.5" style={{ backgroundColor: Colors.accent.orange }}>
          <Text style={{ color: Colors.white, fontSize: s(12), fontWeight: "800" }}>{cta}</Text>
        </View>
      </View>
    </Pressable>
  );
}
