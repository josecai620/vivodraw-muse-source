/** 从 { en, zh } 或纯字符串中按当前语言取文案 */
export function pickLang(val: any, lang: string): string {
  if (val == null) return "";
  if (typeof val === "string") return val;
  const isEn = lang === "en";
  return (isEn ? val.en : val.zh) ?? val.en ?? val.zh ?? "";
}
