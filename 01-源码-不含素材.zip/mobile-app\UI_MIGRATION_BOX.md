# 盲盒链路迁移清单（旧 Uniapp → mobile-app）

> 基于 `frontend_src/云小福盲盒` 对照，目标落地到 `mobile-app`。

## 1. 页面映射表

| 状态 | 旧页面（Uniapp） | 新页面（mobile-app） | 关键 API/数据 |
|---|---|---|---|
| 待核对 | `pages/index/**`（盲盒入口区块） | `app/(tabs)/index.tsx`（入口区块） | 首页装修/盲盒推荐接口 |
| 待核对 | `pages/index/mh_xq.vue` | `app/box/[id].tsx` | 盲盒详情、库存、价格区间 |
| 待核对 | `pages/activity/lottery/**`（开盒相关） | `app/box/[id]/opening.tsx` | 开盒动作、揭晓结果 |
| 待核对 | `pages/activity/lottery/grids/record.vue` | `app/reveal/index.tsx` / `app/reveal/[id].tsx` | 揭晓列表、揭晓详情 |
| 待核对 | `pages/goods_list/index.vue`（如承载盲盒列表） | `app/box/index.tsx`（或现有盲盒列表路由） | 列表、筛选、分页 |

## 2. 逐页迁移检查项

每完成一个页面，按以下项勾选：

- [ ] 路由可访问
- [ ] 加载态/空态/错误态完整
- [ ] 接口参数与返回字段对齐
- [ ] 关键交互（购买/开盒/跳转）可闭环
- [ ] TypeScript 无新增错误
- [ ] 文案与样式符合当前主题规范

## 3. 联调顺序

1. `app/box/[id].tsx`（详情数据完整）
2. `app/box/[id]/opening.tsx`（开盒动作成功）
3. `app/reveal/[id].tsx`（结果回显一致）
4. `app/(tabs)/index.tsx`（首页入口联通）

## 4. 备注

- 旧 Uniapp 页面仅作“逻辑参考”，不做直接代码迁移。
- 若旧页面存在临时业务分支逻辑，先落到注释或 TODO，避免迁移时静默丢失。
