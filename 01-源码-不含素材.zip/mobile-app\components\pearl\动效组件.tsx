import React, { createContext, forwardRef, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { Animated, AppState, Easing, Platform, Pressable, StyleSheet, Text, View, type PressableProps, type StyleProp, type TextStyle, type ViewStyle } from "react-native";

const MotionContext = createContext(false);
const AnimatedPressable = Animated.createAnimatedComponent(Pressable);
const nativeDriver = Platform.OS !== "web";
const easeOut = Easing.bezier(0.22, 1, 0.36, 1);

export function MotionProvider({ reducedMotion, children }: { reducedMotion: boolean; children: ReactNode }) {
  return <MotionContext.Provider value={reducedMotion}>{children}</MotionContext.Provider>;
}

export type MotionPressableProps = PressableProps & { glowColor?: string };

/** 原样保留 Pressable 的事件、无障碍语义和函数子节点；动画只控制合成层。 */
export const MotionPressable = forwardRef<View, MotionPressableProps>(function MotionPressable({
  children, style, disabled, glowColor = "rgba(222,255,229,0.7)", onPressIn, onPressOut, onHoverIn, onHoverOut, onFocus, onBlur, onTouchCancel, ...props
}, ref) {
  const reducedMotion = useContext(MotionContext);
  const scale = useRef(new Animated.Value(1)).current;
  const light = useRef(new Animated.Value(0)).current;
  const ripple = useRef(new Animated.Value(1)).current;
  const [pressed, setPressed] = useState(false);
  const [focused, setFocused] = useState(false);
  const [origin, setOrigin] = useState({ x: 0, y: 0 });
  const hovered = useRef(false);
  const flattened = StyleSheet.flatten(typeof style === "function" ? style({ pressed }) : style) || {};

  const toScale = (value: number, duration: number) => {
    scale.stopAnimation();
    if (reducedMotion) { scale.setValue(1); return; }
    Animated.timing(scale, { toValue: value, duration, easing: easeOut, useNativeDriver: nativeDriver }).start();
  };
  useEffect(() => () => { scale.stopAnimation(); light.stopAnimation(); ripple.stopAnimation(); }, [scale, light, ripple]);
  useEffect(() => {
    if (disabled || reducedMotion) { setPressed(false); hovered.current = false; scale.stopAnimation(); scale.setValue(1); light.stopAnimation(); light.setValue(0); ripple.stopAnimation(); ripple.setValue(1); }
  }, [disabled, reducedMotion, scale, light, ripple]);

  return <AnimatedPressable
    {...props}
    ref={ref}
    disabled={disabled}
    onPressIn={(event) => {
      setPressed(true);
      setOrigin({ x: event.nativeEvent.locationX ?? 0, y: event.nativeEvent.locationY ?? 0 });
      toScale(0.965, 85);
      light.stopAnimation(); ripple.stopAnimation();
      light.setValue(reducedMotion ? 0 : 0.17); ripple.setValue(0);
      if (!reducedMotion) Animated.parallel([
        Animated.timing(light, { toValue: 0, duration: 240, easing: Easing.out(Easing.quad), useNativeDriver: nativeDriver }),
        Animated.timing(ripple, { toValue: 1, duration: 240, easing: easeOut, useNativeDriver: nativeDriver }),
      ]).start();
      onPressIn?.(event);
    }}
    onPressOut={(event) => { setPressed(false); toScale(hovered.current ? 1.015 : 1, 170); onPressOut?.(event); }}
    onTouchCancel={(event) => { setPressed(false); toScale(1, 130); onTouchCancel?.(event); }}
    onHoverIn={(event) => { hovered.current = true; if (!disabled && !pressed) toScale(1.015, 160); onHoverIn?.(event); }}
    onHoverOut={(event) => { hovered.current = false; if (!pressed) toScale(1, 130); onHoverOut?.(event); }}
    onFocus={(event) => {
      setFocused(Platform.OS !== "web" || Boolean((event.currentTarget as unknown as HTMLElement).matches?.(":focus-visible")));
      onFocus?.(event);
    }}
    onBlur={(event) => { setFocused(false); setPressed(false); toScale(1, 130); onBlur?.(event); }}
    style={[flattened, { transform: [...(Array.isArray(flattened.transform) ? flattened.transform : []), { scale }] }]}
  >
    {(state) => <>
      {typeof children === "function" ? children(state) : children}
      <View pointerEvents="none" accessible={false} accessibilityElementsHidden importantForAccessibility="no-hide-descendants" style={[StyleSheet.absoluteFillObject, { overflow: "hidden", borderRadius: flattened.borderRadius ?? 16 }]}>
        <Animated.View style={[StyleSheet.absoluteFillObject, { backgroundColor: glowColor, opacity: light }]} />
        <Animated.View style={{ position: "absolute", left: origin.x - 42, top: origin.y - 42, width: 84, height: 84, borderRadius: 42, borderColor: glowColor, borderWidth: 2, opacity: light.interpolate({ inputRange: [0, 0.17], outputRange: [0, 0.8] }), transform: [{ scale: ripple.interpolate({ inputRange: [0, 1], outputRange: [0.18, 2.5] }) }] }} />
      </View>
      {focused && !disabled && <View pointerEvents="none" accessible={false} style={[StyleSheet.absoluteFillObject, { borderRadius: flattened.borderRadius ?? 16, borderWidth: 2, borderColor: "#f4de9b" }]} />}
    </>}
  </AnimatedPressable>;
});

export type OceanTitleProps = { text: string; reducedMotion?: boolean; compact?: boolean; tiny?: boolean };

export function IdleBob({ children, reducedMotion, amplitude = 3, duration = 2600, style }: { children: ReactNode; reducedMotion?: boolean; amplitude?: number; duration?: number; style?: StyleProp<ViewStyle> }) {
  const preference = useContext(MotionContext);
  const quiet = reducedMotion ?? preference;
  const wave = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (quiet) { wave.stopAnimation(); wave.setValue(0); return; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(wave, { toValue: 1, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: nativeDriver, isInteraction: false }),
      Animated.timing(wave, { toValue: 0, duration, easing: Easing.inOut(Easing.sin), useNativeDriver: nativeDriver, isInteraction: false }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [quiet, amplitude, duration, wave]);
  return <Animated.View style={[style, { transform: [{ translateY: wave.interpolate({ inputRange: [0, 1], outputRange: [0, -amplitude] }) }] }]}>{children}</Animated.View>;
}

export function OceanTitle({ text, reducedMotion: reducedOverride, compact = false, tiny = false }: OceanTitleProps) {
  const preference = useContext(MotionContext);
  const reducedMotion = reducedOverride ?? preference;
  return Platform.OS === "web" ? <WebOceanTitle text={text} reducedMotion={reducedMotion} compact={compact} tiny={tiny} /> : <NativeOceanTitle text={text} reducedMotion={reducedMotion} compact={compact} tiny={tiny} />;
}

function WebOceanTitle({ text, reducedMotion, compact, tiny }: Required<OceanTitleProps>) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const element = root.current;
    if (!element || reducedMotion || typeof element.animate !== "function") return;
    const animations: Animation[] = [];
    element.querySelectorAll<HTMLElement>("[data-ocean-letter]").forEach((letter, index) => {
      animations.push(letter.animate([
        { transform: "translateY(0px) rotate(0deg)" },
        { transform: `translateY(-${index % 3 === 0 ? 1.8 : 1.1}px) rotate(${index % 2 === 0 ? 0.35 : -0.35}deg)` },
        { transform: "translateY(0px) rotate(0deg)" },
      ], { duration: 4600, delay: -index * 125, iterations: Infinity, easing: "ease-in-out" }));
    });
    const glint = element.querySelector<HTMLElement>("[data-ocean-glint]");
    if (glint) animations.push(glint.animate([
      { clipPath: "polygon(-35% 0,-20% 0,-45% 100%,-60% 100%)", opacity: 0, offset: 0 },
      { clipPath: "polygon(-35% 0,-20% 0,-45% 100%,-60% 100%)", opacity: 0, offset: 0.72 },
      { clipPath: "polygon(30% 0,43% 0,18% 100%,5% 100%)", opacity: 0.55, offset: 0.79 },
      { clipPath: "polygon(145% 0,158% 0,133% 100%,120% 100%)", opacity: 0, offset: 0.96 },
      { clipPath: "polygon(145% 0,158% 0,133% 100%,120% 100%)", opacity: 0, offset: 1 },
    ], { duration: 6800, iterations: Infinity, easing: "linear" }));
    element.querySelectorAll<HTMLElement>("[data-ocean-star]").forEach((star, index) => {
      animations.push(star.animate([
        { opacity: 0.28, transform: "scale(0.65) rotate(0deg)" },
        { opacity: 0.78, transform: "scale(1) rotate(30deg)" },
        { opacity: 0.28, transform: "scale(0.65) rotate(60deg)" },
      ], { duration: 3400 + index * 900, delay: -index * 1400, iterations: Infinity, easing: "ease-in-out" }));
    });
    let visible = true;
    const sync = () => animations.forEach((animation) => { if (document.hidden || !visible) animation.pause(); else animation.play(); });
    const observer = typeof IntersectionObserver === "undefined" ? null : new IntersectionObserver((entries) => { visible = entries[0]?.isIntersecting ?? true; sync(); });
    observer?.observe(element); document.addEventListener("visibilitychange", sync); sync();
    return () => { observer?.disconnect(); document.removeEventListener("visibilitychange", sync); animations.forEach((animation) => animation.cancel()); };
  }, [text, reducedMotion]);

  const size = tiny ? 20 : compact ? 26 : text.length > 16 ? 29 : 36;
  return <div ref={root} role="heading" aria-level={1} aria-label={text} style={{ position: "relative", display: "inline-flex", marginTop: tiny ? 0 : compact ? 2 : 7, padding: tiny ? "0 2px" : compact ? "0 6px 2px" : "0 9px 3px", isolation: "isolate", maxWidth: "100%" }}>
    <span aria-hidden="true" style={{ position: "relative", display: "inline-flex", whiteSpace: "pre", fontFamily: "ui-rounded, 'SF Pro Rounded', system-ui, -apple-system, 'PingFang TC', sans-serif", fontSize: size, fontWeight: 900, letterSpacing: text.length > 8 ? "-1.2px" : "2px", lineHeight: "1.18", color: "#fff2c5", textShadow: "0 2px 0 #477e77, 0 3px 0 #256865, 0 5px 8px rgba(10,65,67,.33)" }}>
      {Array.from(text).map((character, index) => <span key={`${index}-${character}`} data-ocean-letter="" style={{ position: "relative", display: "inline-block", WebkitTextStroke: ".55px rgba(25,98,94,.5)" }}>
        {character}
      </span>)}
    </span>
    <span aria-hidden="true" data-ocean-glint="" style={{ position: "absolute", top: 0, left: tiny ? 2 : compact ? 6 : 9, opacity: 0, whiteSpace: "pre", pointerEvents: "none", color: "#fffff1", fontFamily: "ui-rounded, 'SF Pro Rounded', system-ui, -apple-system, 'PingFang TC', sans-serif", fontSize: size, fontWeight: 900, letterSpacing: text.length > 8 ? "-1.2px" : "2px", lineHeight: "1.18", textShadow: "0 0 4px rgba(255,251,205,.45)" }}>{text}</span>
    {[{ left: "-4px", top: "12px", size: 11 }, { left: "98%", top: "-1px", size: 8 }].map((star, index) => <span key={index} aria-hidden="true" data-ocean-star="" style={{ position: "absolute", left: star.left, top: star.top, width: star.size, height: star.size, opacity: 0.48, pointerEvents: "none" }}><span style={{ position: "absolute", left: "44%", top: 0, height: "100%", width: "12%", background: "#fff7c9", borderRadius: "50%", boxShadow: "0 0 5px #ffefc0" }} /><span style={{ position: "absolute", top: "44%", left: 0, width: "100%", height: "12%", background: "#fff7c9", borderRadius: "50%" }} /></span>)}
  </div>;
}

function NativeOceanTitle({ text, reducedMotion, compact, tiny }: Required<OceanTitleProps>) {
  const value = useRef(new Animated.Value(0)).current;
  const [active, setActive] = useState(AppState.currentState === "active");
  useEffect(() => { const subscription = AppState.addEventListener("change", (state) => setActive(state === "active")); return () => subscription.remove(); }, []);
  useEffect(() => {
    if (reducedMotion || !active) { value.stopAnimation(); value.setValue(0); return; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(value, { toValue: 1, duration: 2500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(value, { toValue: 0, duration: 2500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start(); return () => loop.stop();
  }, [active, reducedMotion, value]);
  return <Animated.View style={{ marginTop: tiny ? 0 : compact ? 2 : 7, transform: [{ translateY: value.interpolate({ inputRange: [0, 1], outputRange: [0, -1.5] }) }] }}>
    <Text accessibilityRole="header" style={{ fontSize: tiny ? 20 : compact ? 26 : 36, fontWeight: "900", letterSpacing: -1, color: "#fff4cc", textShadowColor: "rgba(15,76,74,0.7)", textShadowOffset: { width: 0, height: 3 }, textShadowRadius: 3 }}>{text}</Text>
  </Animated.View>;
}

export function RevealText({ children, trigger, reducedMotion: reducedOverride, style }: { children: ReactNode; trigger: string | number | boolean | null; reducedMotion?: boolean; style?: StyleProp<TextStyle> }) {
  const preference = useContext(MotionContext);
  const reducedMotion = reducedOverride ?? preference;
  const value = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    value.stopAnimation(); value.setValue(reducedMotion ? 1 : 0);
    if (reducedMotion) return;
    const animation = Animated.timing(value, { toValue: 1, duration: 240, easing: easeOut, useNativeDriver: nativeDriver });
    animation.start(); return () => animation.stop();
  }, [trigger, reducedMotion, value]);
  return <Animated.Text style={[style, { opacity: value, transform: [{ translateY: value.interpolate({ inputRange: [0, 1], outputRange: [7, 0] }) }, { scale: value.interpolate({ inputRange: [0, 1], outputRange: [0.98, 1] }) }] }]}>{children}</Animated.Text>;
}
