// [已废弃] 改由自研装修器组件替代
export default function DiyActivePartyDeprecated(): null { return null; }
