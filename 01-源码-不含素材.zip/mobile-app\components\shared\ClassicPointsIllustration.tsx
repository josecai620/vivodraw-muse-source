import { View } from "react-native";
import Svg, { Circle, Defs, Ellipse, G, LinearGradient, Path, Rect, Stop } from "react-native-svg";

export type ClassicPointsIllustrationName =
  | "bell"
  | "wishlist"
  | "points"
  | "history"
  | "center"
  | "notice"
  | "tasks"
  | "rewards"
  | "vip"
  | "flash"
  | "box"
  | "hot"
  | "trending"
  | "premium"
  | "electronics"
  | "gifts"
  | "exclusive"
  | "travel"
  | "food"
  | "gaming"
  | "books"
  | "beauty";

type Props = {
  name: ClassicPointsIllustrationName;
  size?: number;
};

const PALETTE: Record<
  ClassicPointsIllustrationName,
  { a: string; b: string; c: string; d: string; line: string; glow: string }
> = {
  bell: {
    a: "#C0C0C0",
    b: "#AAAAAA",
    c: "#787878",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  wishlist: {
    a: "#C0C0C0",
    b: "#C0C0C0",
    c: "#787878",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  points: {
    a: "#787878",
    b: "#787878",
    c: "#C0C0C0",
    d: "#ADADAD",
    line: "#787878",
    glow: "#F8F8F8",
  },
  history: {
    a: "#C0C0C0",
    b: "#787878",
    c: "#787878",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  center: {
    a: "#C0C0C0",
    b: "#AAAAAA",
    c: "#787878",
    d: "#787878",
    line: "#5F5F5F",
    glow: "#F8F8F8",
  },
  notice: {
    a: "#787878",
    b: "#787878",
    c: "#C0C0C0",
    d: "#AEAEAE",
    line: "#787878",
    glow: "#F8F8F8",
  },
  tasks: {
    a: "#787878",
    b: "#787878",
    c: "#C0C0C0",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  rewards: {
    a: "#C0C0C0",
    b: "#B0B0B0",
    c: "#787878",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  vip: { a: "#787878", b: "#787878", c: "#787878", d: "#A9A9A9", line: "#787878", glow: "#F8F8F8" },
  flash: {
    a: "#787878",
    b: "#787878",
    c: "#787878",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  box: { a: "#787878", b: "#787878", c: "#C0C0C0", d: "#ACACAC", line: "#787878", glow: "#F8F8F8" },
  hot: { a: "#787878", b: "#787878", c: "#787878", d: "#787878", line: "#787878", glow: "#F8F8F8" },
  trending: {
    a: "#787878",
    b: "#787878",
    c: "#787878",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  premium: {
    a: "#787878",
    b: "#B0B0B0",
    c: "#787878",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  electronics: {
    a: "#C0C0C0",
    b: "#787878",
    c: "#787878",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  gifts: {
    a: "#787878",
    b: "#787878",
    c: "#C0C0C0",
    d: "#AEAEAE",
    line: "#787878",
    glow: "#F8F8F8",
  },
  exclusive: {
    a: "#787878",
    b: "#787878",
    c: "#787878",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  travel: {
    a: "#D6D6D6",
    b: "#ACACAC",
    c: "#787878",
    d: "#787878",
    line: "#5F5F5F",
    glow: "#F8F8F8",
  },
  food: {
    a: "#787878",
    b: "#787878",
    c: "#D3D3D3",
    d: "#ACACAC",
    line: "#787878",
    glow: "#F8F8F8",
  },
  gaming: {
    a: "#C0C0C0",
    b: "#AAAAAA",
    c: "#787878",
    d: "#787878",
    line: "#5F5F5F",
    glow: "#F8F8F8",
  },
  books: {
    a: "#C0C0C0",
    b: "#787878",
    c: "#787878",
    d: "#787878",
    line: "#787878",
    glow: "#F8F8F8",
  },
  beauty: {
    a: "#D2D2D2",
    b: "#AFAFAF",
    c: "#787878",
    d: "#787878",
    line: "#7C7C7C",
    glow: "#F8F8F8",
  },
};

function Tile({
  name,
  children,
}: { name: ClassicPointsIllustrationName; children: React.ReactNode }) {
  const p = PALETTE[name];

  return (
    <Svg width="100%" height="100%" viewBox="0 0 64 64">
      <Defs>
        <LinearGradient id={`points-tile-${name}`} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor="#FFFFFF" />
          <Stop offset="0.58" stopColor="#F8F8F8" />
          <Stop offset="1" stopColor="#F8F8F8" />
        </LinearGradient>
        <LinearGradient id={`points-a-${name}`} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={p.a} />
          <Stop offset="1" stopColor={p.b} />
        </LinearGradient>
        <LinearGradient id={`points-b-${name}`} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={p.c} />
          <Stop offset="1" stopColor={p.d} />
        </LinearGradient>
      </Defs>
      <Ellipse cx="32" cy="49" rx="16" ry="5.2" fill="#C0C0C0" opacity="0.24" />
      <Rect x="5.8" y="6.4" width="52.4" height="52.4" rx="16.5" fill="#787878" opacity="0.38" />
      <Rect
        x="5"
        y="5"
        width="54"
        height="54"
        rx="16.5"
        fill={`url(#points-tile-${name})`}
        stroke="#C0C0C0"
        strokeWidth="1.1"
      />
      <Rect
        x="9"
        y="9"
        width="46"
        height="46"
        rx="13.5"
        fill="none"
        stroke="#C0C0C0"
        strokeWidth="1"
        strokeDasharray="2.1 2"
      />
      <Ellipse cx="32" cy="42.5" rx="14.5" ry="5.8" fill={p.glow} opacity="0.9" />
      <Path
        d="M16 13.5H48"
        stroke="#FFFFFF"
        strokeOpacity="0.82"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      <G>{children}</G>
    </Svg>
  );
}

function GiftBox({ name }: { name: ClassicPointsIllustrationName }) {
  const p = PALETTE[name];
  return (
    <>
      <Rect
        x="21"
        y="27"
        width="22"
        height="17"
        rx="3.2"
        fill={`url(#points-a-${name})`}
        stroke={p.line}
        strokeWidth="1"
      />
      <Rect
        x="19.5"
        y="24"
        width="25"
        height="6.5"
        rx="2.4"
        fill={`url(#points-b-${name})`}
        stroke={p.line}
        strokeWidth="0.9"
      />
      <Path d="M32 24.5V44" stroke="#FFFFFF" strokeWidth="1.4" />
      <Path d="M24 33H40" stroke="#FFFFFF" strokeOpacity="0.7" strokeWidth="1" />
      <Path
        d="M30.5 24C26.4 20.4 24.5 20.6 23.3 22.1C22 23.8 25.7 25.1 30.5 24Z"
        fill="#F8F8F8"
        stroke={p.line}
        strokeWidth="0.8"
      />
      <Path
        d="M33.5 24C37.6 20.4 39.5 20.6 40.7 22.1C42 23.8 38.3 25.1 33.5 24Z"
        fill="#F8F8F8"
        stroke={p.line}
        strokeWidth="0.8"
      />
    </>
  );
}

function Badge({
  name,
  crown = false,
  star = false,
}: { name: ClassicPointsIllustrationName; crown?: boolean; star?: boolean }) {
  const p = PALETTE[name];
  return (
    <>
      <Circle
        cx="32"
        cy="31"
        r="13.5"
        fill={`url(#points-a-${name})`}
        stroke={p.line}
        strokeWidth="1"
      />
      <Circle cx="32" cy="31" r="9.2" fill="#F8F8F8" stroke="#787878" strokeWidth="0.9" />
      {crown ? (
        <Path
          d="M24.8 32.4L27.2 26.5L31.8 30.2L36.5 26.5L39.2 32.4Z"
          fill={`url(#points-b-${name})`}
          stroke={p.line}
          strokeWidth="0.8"
        />
      ) : star ? (
        <Path
          d="M32 24.8L34.1 29.1L38.8 29.8L35.4 33.2L36.2 37.9L32 35.7L27.8 37.9L28.6 33.2L25.2 29.8L29.9 29.1Z"
          fill={`url(#points-b-${name})`}
          stroke={p.line}
          strokeWidth="0.8"
        />
      ) : (
        <Path
          d="M32 24.4C35.8 26.6 37.8 29.3 37.8 32.1C37.8 35.3 35.4 37.8 32 37.8C28.6 37.8 26.2 35.3 26.2 32.1C26.2 29.3 28.2 26.6 32 24.4Z"
          fill={`url(#points-b-${name})`}
        />
      )}
      <Path
        d="M27.4 41.6L24.6 47L31.2 44.2"
        fill={`url(#points-a-${name})`}
        stroke={p.line}
        strokeWidth="0.8"
      />
      <Path
        d="M36.6 41.6L39.4 47L32.8 44.2"
        fill={`url(#points-a-${name})`}
        stroke={p.line}
        strokeWidth="0.8"
      />
    </>
  );
}

function Receipt({ name }: { name: ClassicPointsIllustrationName }) {
  const p = PALETTE[name];
  return (
    <>
      <Path
        d="M22 18.8H42V43.8L38.6 41.9L35.2 43.8L31.8 41.9L28.4 43.8L25 41.9L22 43.6Z"
        fill="#FFFFFF"
        stroke={p.line}
        strokeWidth="1"
      />
      <Path
        d="M27.5 26H36.5M27.5 31H37.8M27.5 36H34.5"
        stroke={`url(#points-b-${name})`}
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      <Circle cx="39.5" cy="39" r="3.8" fill={`url(#points-a-${name})`} opacity="0.85" />
    </>
  );
}

function Icon({ name }: { name: ClassicPointsIllustrationName }) {
  const p = PALETTE[name];
  switch (name) {
    case "bell":
      return (
        <>
          <Path
            d="M24.5 37.8H39.5C37.2 35.7 37.2 32.7 37.2 28.6C37.2 25.3 35 22.2 32 22.2C29 22.2 26.8 25.3 26.8 28.6C26.8 32.7 26.8 35.7 24.5 37.8Z"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
          <Path
            d="M29.4 40.2C30 42 31 42.9 32 42.9C33 42.9 34 42 34.6 40.2Z"
            fill={`url(#points-b-${name})`}
            stroke={p.line}
            strokeWidth="0.8"
          />
          <Path d="M32 20.1V18.4" stroke={p.line} strokeWidth="1.5" strokeLinecap="round" />
        </>
      );
    case "wishlist":
      return (
        <>
          <Path
            d="M32 42.5C25.8 37.5 22 33.9 22 29.3C22 25.8 24.6 23.4 27.8 23.4C29.7 23.4 31.1 24.3 32 25.7C32.9 24.3 34.3 23.4 36.2 23.4C39.4 23.4 42 25.8 42 29.3C42 33.9 38.2 37.5 32 42.5Z"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
          <Path d="M27 32.8H37" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round" />
        </>
      );
    case "points":
      return <Badge name={name} />;
    case "history":
      return <Receipt name={name} />;
    case "center":
      return (
        <>
          <Circle
            cx="32"
            cy="27.5"
            r="6"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
          <Path
            d="M21.5 43.5C23.2 37.8 26.9 34.7 32 34.7C37.1 34.7 40.8 37.8 42.5 43.5Z"
            fill={`url(#points-b-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
        </>
      );
    case "notice":
      return (
        <>
          <Path
            d="M22 32.3L38.8 23.6V40.4L22 35.3Z"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
          <Rect
            x="19.5"
            y="30"
            width="5.8"
            height="7.4"
            rx="2"
            fill="#F8F8F8"
            stroke={p.line}
            strokeWidth="0.8"
          />
          <Path
            d="M27.8 36.5L30.4 43"
            stroke={`url(#points-b-${name})`}
            strokeWidth="2"
            strokeLinecap="round"
          />
        </>
      );
    case "tasks":
      return <Receipt name={name} />;
    case "rewards":
    case "gifts":
    case "box":
      return <GiftBox name={name} />;
    case "vip":
    case "exclusive":
    case "premium":
      return <Badge name={name} crown />;
    case "flash":
    case "hot":
    case "trending":
      return (
        <>
          <Path
            d="M34.2 18.5L23.8 33H31L28.9 45.5L40.8 29.6H33.2Z"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
            strokeLinejoin="round"
          />
          <Circle cx="42.5" cy="24" r="2.4" fill={`url(#points-b-${name})`} />
        </>
      );
    case "electronics":
      return (
        <>
          <Rect
            x="22"
            y="20"
            width="20"
            height="23"
            rx="4.4"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
          <Rect x="25.4" y="24" width="13.2" height="13" rx="2" fill="#FFFFFF" />
          <Path d="M29 40H35" stroke={p.line} strokeWidth="1.4" strokeLinecap="round" />
        </>
      );
    case "travel":
      return (
        <>
          <Path
            d="M21 36.5L43.2 21L37.9 43.7L32.1 36.8Z"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
            strokeLinejoin="round"
          />
          <Path d="M32.1 36.8L43.2 21" stroke="#F8F8F8" strokeWidth="1.2" />
          <Circle cx="42" cy="42" r="2.4" fill={`url(#points-b-${name})`} />
        </>
      );
    case "food":
      return (
        <>
          <Path
            d="M24 27C24 22.8 27.6 19.8 32 19.8C36.4 19.8 40 22.8 40 27V31H24Z"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
          <Rect
            x="21"
            y="31"
            width="22"
            height="11"
            rx="4"
            fill={`url(#points-b-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
          <Path d="M25 30.5H39" stroke="#FFFFFF" strokeWidth="1.3" strokeLinecap="round" />
        </>
      );
    case "gaming":
      return (
        <>
          <Path
            d="M22 29.5C22.5 25.9 25 24 28.1 24H36C39.1 24 41.5 25.9 42 29.5L43.2 38.2C43.6 41 40.5 42.8 38.4 40.8L35.7 38.2H28.3L25.6 40.8C23.5 42.8 20.4 41 20.8 38.2Z"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
          <Path d="M27 31H31M29 29V33" stroke="#F8F8F8" strokeWidth="1.2" strokeLinecap="round" />
          <Circle cx="36.5" cy="31" r="1.4" fill="#F8F8F8" />
        </>
      );
    case "books":
      return (
        <>
          <Path
            d="M20.8 24.5C25.3 22 29.2 22.4 32 25.3V43.3C29.1 40.7 25.3 40.1 20.8 42.2Z"
            fill="#FFFFFF"
            stroke={p.line}
            strokeWidth="1"
          />
          <Path
            d="M43.2 24.5C38.7 22 34.8 22.4 32 25.3V43.3C34.9 40.7 38.7 40.1 43.2 42.2Z"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
          <Path
            d="M24.5 29H29.5M34.8 29H39.5M24.5 34H29.2M34.8 34H39"
            stroke={p.line}
            strokeOpacity="0.55"
            strokeWidth="1"
            strokeLinecap="round"
          />
        </>
      );
    case "beauty":
      return (
        <>
          <Rect
            x="28.8"
            y="20"
            width="6.4"
            height="7"
            rx="1.7"
            fill={`url(#points-b-${name})`}
            stroke={p.line}
            strokeWidth="0.8"
          />
          <Path
            d="M25.5 27H38.5V39.2C38.5 41.8 36.4 43.8 33.8 43.8H30.2C27.6 43.8 25.5 41.8 25.5 39.2Z"
            fill={`url(#points-a-${name})`}
            stroke={p.line}
            strokeWidth="1"
          />
          <Path d="M29.4 31H34.6" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round" />
        </>
      );
    default:
      return <Badge name="points" star />;
  }
}

export default function ClassicPointsIllustration({ name, size = 48 }: Props) {
  return (
    <View style={{ width: size, height: size }}>
      <Tile name={name}>
        <Icon name={name} />
      </Tile>
    </View>
  );
}
