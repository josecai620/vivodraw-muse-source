import React from "react";
import { ActivityIndicator, FlatList, Image, Pressable, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { Eye, Package, Trash2 } from "lucide-react-native";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getVisitList, deleteVisit } from "@/lib/api/visit";
import { normalizeImageUrl } from "@/lib/utils";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

function formatDate(str: string | number): string {
  if (!str) return "";
  const d = new Date(str);
  return isNaN(d.getTime()) ? String(str) : d.toLocaleDateString();
}

export default function VisitHistoryScreen() {
  const router = useRouter();
  const queryClient = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["visitList"],
    queryFn: getVisitList,
  });

  const deleteMutation = useMutation({
    mutationFn: (ids: number[]) => deleteVisit(ids),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["visitList"] }),
  });

  const raw = (data as any)?.data ?? data ?? {};
  const list = raw?.list ?? (Array.isArray(raw) ? raw : []);

  const renderItem = ({ item }: { item: any }) => {
    const productId = item.product_id ?? item.id ?? 0;
    const name = item.store_name ?? "Product";
    const image = item.image ?? "";
    const price = item.price ?? item.product_price ?? "0";

    return (
      <Pressable
        onPress={() => productId && router.push(`/product/${productId}`)}
        className="flex-row bg-white mb-2 rounded-xl p-3 border border-gray-100"
      >
        {image ? (
          <Image source={{ uri: normalizeImageUrl(image) }} className="w-20 h-20 rounded-lg" resizeMode="cover" />
        ) : (
          <View className="w-20 h-20 rounded-lg bg-gray-100 items-center justify-center">
            <Package size={s(26)} color={Colors.neutral[400]} strokeWidth={1.8} />
          </View>
        )}
        <View className="flex-1 ml-3 justify-center">
          <Text className="font-medium text-sm" style={{ color: Colors.neutral[800] }} numberOfLines={2}>
            {name}
          </Text>
          {price ? (
            <Text className="text-sm font-semibold mt-0.5" style={{ color: Colors.brand.red }}>
              ${price}
            </Text>
          ) : null}
          <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }}>
            {formatDate(item.add_time)}
          </Text>
        </View>
        <Pressable
          onPress={() => productId && deleteMutation.mutate([productId])}
          className="p-2 self-center"
        >
          <Trash2 size={s(20)} color={Colors.neutral[400]} />
        </Pressable>
      </Pressable>
    );
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Browse History" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <View className="flex-1 px-4 pt-4">
          <FlatList
            data={Array.isArray(list) ? list : []}
            renderItem={renderItem}
            keyExtractor={(item) => String(item.product_id ?? item.id ?? item)}
            contentContainerStyle={{ paddingBottom: s(80) }}
            ListEmptyComponent={
              <View className="py-12 items-center">
                <Eye size={s(48)} color={Colors.neutral[300]} />
                <Text className="mt-3" style={{ color: Colors.neutral[500] }}>
                  No browse history
                </Text>
              </View>
            }
          />
        </View>
      )}
    </View>
  );
}
