#!/usr/bin/env node
/**
 * 包体积分析脚本 - 在 expo export -p web 之后运行
 * 用法: node scripts/analyze-bundle.js
 * 或: npm run analyze (需在 package.json 添加 script)
 */
const fs = require("fs");
const path = require("path");

const DIST = path.join(__dirname, "..", "dist");
const STATIC = path.join(DIST, "_expo", "static");

function getSize(filePath) {
  try {
    return fs.statSync(filePath).size;
  } catch {
    return 0;
  }
}

function formatSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function walk(dir, base = "") {
  const items = [];
  if (!fs.existsSync(dir)) return items;
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    const rel = path.join(base, name);
    if (fs.statSync(full).isDirectory()) {
      items.push(...walk(full, rel));
    } else {
      items.push({ path: rel, size: getSize(full) });
    }
  }
  return items;
}

const files = walk(DIST);
const total = files.reduce((s, f) => s + f.size, 0);

// 按体积降序
files.sort((a, b) => b.size - a.size);

console.log("\n=== 包体积分析 (dist/) ===\n");
console.log("文件体积 TOP 15:");
files.slice(0, 15).forEach((f, i) => {
  console.log(`  ${(i + 1).toString().padStart(2)}. ${formatSize(f.size).padStart(10)}  ${f.path}`);
});
console.log("\n---");
console.log(`总大小: ${formatSize(total)} (${files.length} 个文件)`);
console.log("\n建议: JS 单文件超过 1MB 可考虑代码分割/懒加载。");
console.log("");
