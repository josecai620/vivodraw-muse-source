import { Colors, Fonts, Shadows, s } from "@/constants/theme";
import { usePointsBalance } from "@/hooks/usePoints";
import { useAuthStore } from "@/store/auth";
import { type Href, useRouter } from "expo-router";
import { Gift, Trophy } from "lucide-react-native";
import React from "react";
import { useTranslation } from "react-i18next";
import { Pressable, Text, View } from "react-native";
import { pickLang } from "./utils";

type HomeLayoutValue = string | number | boolean | Record<string, unknown> | null | undefined;

type PointsBalanceResponse = {
  data?: {
    integral?: number | string | null;
  };
  integral?: number | string | null;
};

export interface HlPointsBalanceProps {
  props: Record<string, HomeLayoutValue>;
  lang: string;
}

export default function HlPointsBalance({ props, lang }: HlPointsBalanceProps) {
  const { t } = useTranslation();
  const router = useRouter();
  const isLoggedIn = useAuthStore((st) => st.isLoggedIn);
  const { data: balanceData } = usePointsBalance(isLoggedIn);
  const balancePayload = balanceData as PointsBalanceResponse | undefined;
  const realBalance = balancePayload?.data?.integral ?? balancePayload?.integral;
  const displayBalance = isLoggedIn ? Number(realBalance ?? 0).toLocaleString() : "*";

  const balanceTitle = pickLang(props.balance_title, lang) || t("shop.myPointsBalance");
  const earnLabel = pickLang(props.earn, lang) || t("shop.earnMore");
  const redeemLabel = pickLang(props.redeem, lang) || t("shop.redeem");
  const pointsLink =
    typeof props.points_link === "string" && props.points_link
      ? props.points_link
      : "/(tabs)/points";
  const tasksLink =
    typeof props.tasks_link === "string" && props.tasks_link ? props.tasks_link : "/points/tasks";
  const pushLink = (link: string) => router.push(link as Href);

  return (
    <View
      style={{
        marginHorizontal: s(16),
        marginTop: s(14),
        borderRadius: s(22),
        padding: s(18),
        overflow: "hidden",
        backgroundColor: "#ECFBFB",
        borderWidth: 1,
        borderColor: Colors.home.border,
        ...Shadows.warmCard,
      }}
    >
      <View className="flex-row items-center justify-between mb-4">
        <View>
          <Text
            style={{
              color: Colors.accent.orange,
              fontFamily: Fonts.display,
              fontSize: s(27),
              lineHeight: s(32),
              fontWeight: "400",
            }}
          >
            {balanceTitle}
          </Text>
          <View className="flex-row items-center gap-3">
            <Trophy size={s(24)} color={Colors.primary.DEFAULT} />
            <Text style={{ color: Colors.home.text, fontSize: s(30), fontWeight: "900" }}>
              {displayBalance}
            </Text>
          </View>
        </View>
        <Pressable
          className="w-12 h-12 rounded-xl items-center justify-center"
          style={{ backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: Colors.home.border }}
          onPress={() => pushLink(pointsLink)}
        >
          <Gift size={s(22)} color={Colors.accent.orange} />
        </Pressable>
      </View>
      <View className="flex-row gap-3">
        <Pressable
          className="flex-1 h-10 rounded-xl items-center justify-center"
          style={{ backgroundColor: "#FFFFFF", borderWidth: 1, borderColor: Colors.home.border }}
          onPress={() => pushLink(tasksLink)}
        >
          <Text style={{ color: Colors.home.text, fontSize: s(13), fontWeight: "800" }}>
            {earnLabel}
          </Text>
        </Pressable>
        <Pressable
          className="flex-1 h-10 rounded-xl items-center justify-center"
          style={{ backgroundColor: Colors.accent.orange }}
          onPress={() => pushLink(pointsLink)}
        >
          <Text style={{ color: Colors.white, fontSize: s(13), fontWeight: "800" }}>
            {redeemLabel}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}
