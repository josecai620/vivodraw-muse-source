import React, { useEffect, useRef, useState } from "react";
import { Animated, Easing, Text, View, type StyleProp, type TextStyle } from "react-native";
import { formatRevealMsClock } from "@/lib/points/cloudBuyParse";
import { Colors } from "@/constants/theme";

const TEAL = Colors.primary.DEFAULT;
/** 参考实现 IndexFun setInterval(..., 41) */
const TICK_MS = 41;

export function RevealMsClock({
  deadlineAt,
  style,
  onZero,
}: {
  deadlineAt: number;
  style?: StyleProp<TextStyle>;
  onZero?: () => void;
}) {
  const [left, setLeft] = useState(() => Math.max(0, deadlineAt - Date.now()));
  const zeroOnce = useRef(false);

  useEffect(() => {
    zeroOnce.current = false;
    const tick = () => {
      const next = Math.max(0, deadlineAt - Date.now());
      setLeft(next);
      if (next <= 0 && !zeroOnce.current) {
        zeroOnce.current = true;
        onZero?.();
      }
    };
    tick();
    if (deadlineAt <= Date.now()) return;
    const id = setInterval(tick, TICK_MS);
    return () => clearInterval(id);
  }, [deadlineAt, onZero]);

  return (
    <Text style={[{ fontVariant: ["tabular-nums"] }, style]}>{formatRevealMsClock(left)}</Text>
  );
}

export function RevealSlideIn({
  index,
  children,
  from = -72,
}: {
  index: number;
  children: React.ReactNode;
  from?: number;
}) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    v.setValue(0);
    Animated.timing(v, {
      toValue: 1,
      duration: 520,
      delay: index * 140,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    }).start();
  }, [index, v]);

  return (
    <Animated.View
      style={{
        opacity: v,
        transform: [
          {
            translateX: v.interpolate({
              inputRange: [0, 1],
              outputRange: [from, 0],
            }),
          },
        ],
      }}
    >
      {children}
    </Animated.View>
  );
}

export function RevealingSideTag({ label }: { label: string }) {
  return (
    <View
      pointerEvents="none"
      style={{
        position: "absolute",
        left: 0,
        top: 10,
        zIndex: 2,
        backgroundColor: TEAL,
        paddingVertical: 5,
        paddingHorizontal: 4,
        borderTopRightRadius: 4,
        borderBottomRightRadius: 4,
      }}
    >
      <Text style={{ color: "#fff", fontSize: 9, fontWeight: "800", lineHeight: 12 }}>{label}</Text>
    </View>
  );
}

export function RevealCountdownBar({
  label,
  deadlineAt,
  onZero,
}: {
  label: string;
  deadlineAt: number;
  onZero?: () => void;
}) {
  return (
    <View
      style={{
        marginTop: 8,
        alignSelf: "flex-start",
        backgroundColor: TEAL,
        borderRadius: 4,
        paddingVertical: 6,
        paddingHorizontal: 10,
        flexDirection: "row",
        alignItems: "center",
      }}
    >
      <Text style={{ color: "#fff", fontSize: 12, fontWeight: "800" }}>{label}</Text>
      <RevealMsClock
        deadlineAt={deadlineAt}
        onZero={onZero}
        style={{ color: "#fff", fontSize: 13, fontWeight: "900", marginLeft: 8 }}
      />
    </View>
  );
}
