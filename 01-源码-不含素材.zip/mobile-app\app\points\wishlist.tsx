import React, { useState } from "react";
import { Alert, Image, Pressable, ScrollView, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Trash2,
  Plus,
  Minus,
  ShoppingCart,
  Heart,
  Trophy,
  Check,
} from "lucide-react-native";
import { useRouter } from "expo-router";
import { TealGradient, Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { usePointsCart, useDelPointsCart, useExchangeAll, useCollectAddAll, useCartAddAll } from "@/hooks";
import { newCloudBuyRequestId } from "@/lib/api/points";
import { USE_DEV_MOCK_DATA } from "@/constants/env";

interface WishlistItem {
  id: number;
  name: string;
  image: string;
  points: number;
  quantity: number;
  stock: number;
}

const MOCK_ITEMS: WishlistItem[] = [
  {
    id: 1,
    name: "Wireless Headphones Pro",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80",
    points: 3500,
    quantity: 1,
    stock: 15,
  },
  {
    id: 2,
    name: "Smart Watch Series 8",
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&q=80",
    points: 5000,
    quantity: 1,
    stock: 8,
  },
  {
    id: 3,
    name: "Bluetooth Speaker",
    image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&q=80",
    points: 2000,
    quantity: 2,
    stock: 20,
  },
];

const RECOMMENDED = [
  {
    name: "Fitness Tracker",
    points: 2800,
    img: "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=300&q=80",
  },
  {
    name: "Power Bank",
    points: 1500,
    img: "https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=300&q=80",
  },
];

export default function PointsWishlistScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { data } = usePointsCart();
  const delPointsCart = useDelPointsCart();
  const batchExchange = useExchangeAll();
  const moveToCollection = useCollectAddAll();
  const realData = (data as any)?.data?.list ?? (data as any)?.list ?? [];
  const initialItems: WishlistItem[] = realData.length > 0 ? realData : USE_DEV_MOCK_DATA ? MOCK_ITEMS : [];
  const [items, setItems] = useState<WishlistItem[]>(initialItems);
  const [selectedIds, setSelectedIds] = useState<number[]>(initialItems.map((i: WishlistItem) => i.id));

  const toggleSelect = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id],
    );
  };

  const toggleSelectAll = () => {
    setSelectedIds((prev) =>
      prev.length === items.length ? [] : items.map((item) => item.id),
    );
  };

  const updateQuantity = (id: number, delta: number) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, quantity: Math.max(1, Math.min(item.stock, item.quantity + delta)) }
          : item,
      ),
    );
  };

  const removeItem = (id: number) => {
    delPointsCart.mutate(id as any);
    setItems((prev) => prev.filter((item) => item.id !== id));
    setSelectedIds((prev) => prev.filter((i) => i !== id));
  };

  const totalPoints = items
    .filter((item) => selectedIds.includes(item.id))
    .reduce((sum, item) => sum + item.points * item.quantity, 0);

  const selectedCount = selectedIds.length;

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="My Wishlist" />

      {items.length === 0 ? (
        <View className="flex-1 items-center justify-center px-8">
          <View className="w-32 h-32 rounded-full bg-brand-red-light items-center justify-center mb-6">
            <Heart size={64} color="#33C6CC" />
          </View>
          <Text className="text-xl font-bold text-gray-900 mb-2">Your Wishlist is Empty</Text>
          <Text className="text-gray-500 text-center mb-8 text-sm leading-5">
            Browse the points mall and add items you'd like to redeem to your wishlist
          </Text>
          <Pressable onPress={() => router.push("/(tabs)/points")}>
            <LinearGradient
              colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
              className="px-6 py-3 rounded-xl"
              style={{
                shadowColor: Colors.brand.red,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.3,
                shadowRadius: 8,
                elevation: 4,
              }}
            >
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
              <Text className="text-white font-bold">Browse Points Mall</Text>
            </LinearGradient>
          </Pressable>
        </View>
      ) : (
        <ScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 160 }}
        >
          {/* 心愿单列表 */}
          <View className="px-4 pt-4 gap-3">
            {items.map((item) => (
              <View
                key={item.id}
                className="bg-white rounded-2xl overflow-hidden border border-gray-100"
                style={{
                  shadowColor: "#0C1F1F",
                  shadowOpacity: 0.04,
                  shadowRadius: 2,
                  shadowOffset: { width: 0, height: 1 },
                  elevation: 1,
                }}
              >
                <View className="p-4">
                  <View className="flex-row gap-3">
                    {/* 选择框 */}
                    <Pressable onPress={() => toggleSelect(item.id)} className="mt-1">
                      <View
                        className="w-5 h-5 rounded items-center justify-center"
                        style={{
                          borderWidth: 2,
                          borderColor: selectedIds.includes(item.id)
                            ? Colors.brand.red
                            : "#d1d5db",
                          backgroundColor: selectedIds.includes(item.id)
                            ? Colors.brand.red
                            : "#fff",
                        }}
                      >
                        {selectedIds.includes(item.id) && (
                          <Check size={12} color="#fff" strokeWidth={3} />
                        )}
                      </View>
                    </Pressable>

                    {/* 商品图片 */}
                    <Image
                      source={{ uri: item.image }}
                      className="w-24 h-24 rounded-xl bg-gray-100"
                      resizeMode="cover"
                    />

                    {/* 商品信息 */}
                    <View className="flex-1">
                      <Text
                        className="text-sm font-bold text-gray-900 mb-1"
                        numberOfLines={2}
                      >
                        {item.name}
                      </Text>
                      <View className="flex-row items-center gap-1.5 mb-2">
                        <Trophy size={14} color="#171A1A" />
                        <Text
                          className="text-lg font-bold"
                          style={{ color: Colors.brand.red }}
                        >
                          {item.points.toLocaleString()}
                        </Text>
                        <Text className="text-xs text-gray-500">pts</Text>
                      </View>
                      <Text className="text-xs text-gray-500">
                        Stock:{" "}
                        <Text className="font-medium text-gray-700">{item.stock}</Text>
                      </Text>
                    </View>

                    {/* 删除按钮 */}
                    <Pressable
                      onPress={() => removeItem(item.id)}
                      className="w-8 h-8 rounded-lg bg-gray-50 items-center justify-center"
                    >
                      <Trash2 size={16} color="#919290" />
                    </Pressable>
                  </View>

                  {/* 数量调节器 */}
                  <View className="mt-3 flex-row items-center justify-between pt-3 border-t border-gray-100">
                    <Text className="text-xs text-gray-500">Quantity</Text>
                    <View className="flex-row items-center gap-3">
                      <Pressable
                        onPress={() => updateQuantity(item.id, -1)}
                        disabled={item.quantity <= 1}
                        className="w-8 h-8 rounded-lg bg-gray-100 items-center justify-center"
                        style={{ opacity: item.quantity <= 1 ? 0.4 : 1 }}
                      >
                        <Minus size={16} color="#5E5F5E" />
                      </Pressable>
                      <Text
                        className="text-base font-bold text-gray-900 text-center"
                        style={{ minWidth: 32 }}
                      >
                        {item.quantity}
                      </Text>
                      <Pressable
                        onPress={() => updateQuantity(item.id, 1)}
                        disabled={item.quantity >= item.stock}
                        className="w-8 h-8 rounded-lg bg-gray-100 items-center justify-center"
                        style={{ opacity: item.quantity >= item.stock ? 0.4 : 1 }}
                      >
                        <Plus size={16} color="#5E5F5E" />
                      </Pressable>
                    </View>
                  </View>
                </View>
              </View>
            ))}
          </View>

          {/* 推荐商品 */}
          <View className="px-4 mt-6">
            <View className="bg-neutral-50 rounded-2xl p-4 border border-neutral-200">
              <View className="flex-row items-center justify-between mb-3">
                <Text className="text-sm font-bold text-gray-900">You May Also Like</Text>
                <Pressable onPress={() => router.push("/(tabs)/points")}>
                  <Text className="text-xs font-medium" style={{ color: Colors.brand.red }}>
                    View All
                  </Text>
                </Pressable>
              </View>
              <View className="flex-row gap-3">
                {RECOMMENDED.map((product, i) => (
                  <View
                    key={i}
                    className="flex-1 bg-white rounded-xl p-3"
                    style={{
                      shadowColor: "#0C1F1F",
                      shadowOpacity: 0.04,
                      shadowRadius: 2,
                      shadowOffset: { width: 0, height: 1 },
                      elevation: 1,
                    }}
                  >
                    <Image
                      source={{ uri: product.img }}
                      className="w-full aspect-square bg-gray-100 rounded-lg mb-2"
                      resizeMode="cover"
                    />
                    <Text className="text-xs font-medium text-gray-900 mb-1" numberOfLines={2}>
                      {product.name}
                    </Text>
                    <View className="flex-row items-center gap-1 mb-2">
                      <Trophy size={12} color="#171A1A" />
                      <Text className="text-sm font-bold" style={{ color: Colors.brand.red }}>
                        {product.points}
                      </Text>
                    </View>
                    <Pressable className="w-full h-7 bg-gray-100 rounded-lg items-center justify-center">
                      <Text className="text-xs font-medium text-gray-700">Add to Wishlist</Text>
                    </Pressable>
                  </View>
                ))}
              </View>
            </View>
          </View>
        </ScrollView>
      )}

      {/* 底部操作栏 */}
      {items.length > 0 && (
        <View
          className="bg-white border-t border-gray-200 px-4 pt-3"
          style={{
            paddingBottom: Math.max(12, insets.bottom),
            shadowColor: "#0C1F1F",
            shadowOffset: { width: 0, height: -2 },
            shadowOpacity: 0.08,
            shadowRadius: 8,
            elevation: 8,
          }}
        >
          <View className="flex-row items-center justify-between mb-3">
            <Pressable onPress={toggleSelectAll} className="flex-row items-center gap-2">
              <View
                className="w-5 h-5 rounded items-center justify-center"
                style={{
                  borderWidth: 2,
                  borderColor:
                    selectedIds.length === items.length ? Colors.brand.red : "#d1d5db",
                  backgroundColor:
                    selectedIds.length === items.length ? Colors.brand.red : "#fff",
                }}
              >
                {selectedIds.length === items.length && (
                  <Check size={12} color="#fff" strokeWidth={3} />
                )}
              </View>
              <Text className="text-sm font-medium text-gray-700">
                All ({items.length})
              </Text>
            </Pressable>

            <View className="items-end">
              <Text className="text-xs text-gray-500 mb-0.5">
                Total ({selectedCount} items)
              </Text>
              <View className="flex-row items-center gap-1.5">
                <Trophy size={16} color="#171A1A" />
                <Text className="text-xl font-bold" style={{ color: Colors.brand.red }}>
                  {totalPoints.toLocaleString()}
                </Text>
                <Text className="text-xs text-gray-500">pts</Text>
              </View>
            </View>
          </View>

          <View className="flex-row gap-2">
            <Pressable
              disabled={selectedCount === 0}
              style={{ flex: 1, opacity: selectedCount === 0 ? 0.5 : 1 }}
              onPress={() => Alert.alert("Move to Collection", "Move selected items to your collection?", [
                { text: "Cancel", style: "cancel" },
                { text: "Confirm", onPress: () => {
                  moveToCollection.mutate(selectedIds);
                  setItems((prev) => prev.filter((item) => !selectedIds.includes(item.id)));
                  setSelectedIds([]);
                }},
              ])}
            >
              <View className="h-12 rounded-xl bg-gray-100 flex-row items-center justify-center gap-1.5">
                <Heart size={18} color={Colors.brand.red} />
                <Text className="font-bold text-sm text-gray-700">Collect ({selectedCount})</Text>
              </View>
            </Pressable>

            <Pressable
              disabled={selectedCount === 0}
              style={{ flex: 2, opacity: selectedCount === 0 ? 0.5 : 1 }}
              onPress={() => Alert.alert("Redeem", "Redeem all selected items?", [
                { text: "Cancel", style: "cancel" },
                { text: "Confirm", onPress: () => batchExchange.mutate({ ids: selectedIds.join(","), zidong: 1, client_request_id: newCloudBuyRequestId("wish") }) },
              ])}
            >
              <LinearGradient
                colors={selectedCount > 0 ? [TealGradient.light, TealGradient.base, TealGradient.dark] : ["#d1d5db", "#d1d5db"]}
                start={{ x: 0, y: 0.5 }}
                end={{ x: 1, y: 0.5 }}
                className="rounded-xl flex-row items-center justify-center gap-2"
                style={[
                  { height: 48 },
                  selectedCount > 0 && { shadowColor: Colors.brand.red, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 6, elevation: 4 },
                ]}
              >
                <ShoppingCart size={20} color="#fff"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
                <Text className="text-white font-bold">Redeem ({selectedCount})</Text>
              </LinearGradient>
            </Pressable>
          </View>
        </View>
      )}
    </View>
  );
}
