import React, { useState } from "react";
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { useTranslation } from "react-i18next";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Gift, Ticket } from "lucide-react-native";
import {
  drawMemberCard,
  getMemberCardIndex,
  getUserLevelInfo,
} from "@/lib/api/userLevel";
import { TealGradient, Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";
import { 会员头像框 } from "@/components/member/会员头像框";
import { 会员卡片框 } from "@/components/member/会员卡片框";
import { 会员方案奖励卡 } from "@/components/member/会员方案奖励卡";
import {
  FREE_TRIAL_HINT,
  MEMBER_FRAME_TIERS,
  displayMemberTier,
  parseUserLevelPayload,
  resolveMemberFrame,
  PLAN_REWARDS,
  shopGiftPoints,
  type MemberFrameLevel,
} from "@/lib/会员等级";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import { formatPrice, normalizeImageUrl } from "@/lib/utils";

type Plan = {
  id: number;
  type: string;
  title: string;
  vip_day: number;
  price: string;
  pre_price: string;
};

type Right = {
  right_type: string;
  title: string;
  pic?: string;
  image?: string;
  right?: string;
  explain?: string;
  number?: number;
};

type Coupon = {
  id?: number;
  coupon_title?: string;
  title?: string;
  coupon_price?: string | number;
  use_min_price?: string | number;
  start_time?: string | number;
  end_time?: string | number;
};

const PLAN_KEY_BY_TYPE: Record<string, string> = {
  month: "membership.planMonth",
  quarter: "membership.planQuarter",
  year: "membership.planYear",
  ever: "membership.planEver",
  free: "membership.planFree",
};

const LEVELS: MemberFrameLevel[] = [0, 1, 2, 3, 4, 5, 6];

export default function MemberCardScreen() {
  const { t, i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const [code, setCode] = useState("");
  const [pwd, setPwd] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const showToast = useAppStore((s) => s.showToast);
  const queryClient = useQueryClient();
  const authUser = useAuthStore((s) => s.user);
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);

  const { data: indexData, isLoading: indexLoading } = useQuery({
    queryKey: ["memberCardIndex"],
    queryFn: getMemberCardIndex,
  });
  const { data: levelData } = useQuery({
    queryKey: ["userLevelInfo"],
    queryFn: getUserLevelInfo,
    enabled: isLoggedIn,
  });

  const info = (indexData as any)?.data ?? indexData ?? {};
  const parsed = parseUserLevelPayload(levelData);
  const userInfo = parsed.user ?? {};

  const plans: Plan[] = (info?.member_type ?? []).filter(
    (p: Plan) => p.type !== "free",
  );
  const rights: Right[] = info?.member_rights ?? [];
  const coupons: Coupon[] = info?.member_coupons ?? [];
  const freeCfg = info?.is_get_free;
  const isGetFree =
    typeof freeCfg === "object" && freeCfg
      ? Number((freeCfg as { is_record?: number }).is_record ?? 0) !== 1
      : !!freeCfg;

  const isLifetime = Number(userInfo?.is_ever_level ?? 0) === 1;
  const overdueTs = Number(userInfo?.overdue_time ?? 0);
  const moneyOn = Number(userInfo?.is_money_level ?? 0) > 0;
  const isMember =
    isLifetime || (moneyOn && (overdueTs <= 0 || overdueTs * 1000 > Date.now()));
  const overdueDate =
    overdueTs > 0 ? new Date(overdueTs * 1000).toLocaleDateString() : "";

  const frameState = resolveMemberFrame({
    isLoggedIn,
    isMoneyLevel: userInfo?.is_money_level,
    isEverLevel: userInfo?.is_ever_level,
    overdueTime: userInfo?.overdue_time,
    memberType: userInfo?.member_type,
    spendUsd: userInfo?.spend_usd ?? userInfo?.pay_price,
  });
  const frameLevel = frameState.level;
  const frameTier = displayMemberTier(frameState);
  const nextExp = parsed.nextExp;
  const remain = Math.max(0, nextExp - parsed.exp);
  const progressPct = nextExp > 0 ? Math.min(100, (parsed.exp / nextExp) * 100) : parsed.exp > 0 ? 100 : 0;

  const statusLabel = isLifetime
    ? t("membership.lifetimeMember")
    : isMember && overdueDate
      ? t("membership.expiresOn", { date: overdueDate })
      : t("membership.statusInactive");

  const handleRedeem = async () => {
    const card = code.trim() || FREE_TRIAL_HINT.code;
    const pass = pwd.trim() || FREE_TRIAL_HINT.pwd;
    try {
      setSubmitting(true);
      await drawMemberCard({
        member_card_code: card,
        member_card_pwd: pass,
      });
      showToast(t("membership.redeemSuccess"), "success");
      setCode("");
      setPwd("");
      queryClient.invalidateQueries({ queryKey: ["userLevelInfo"] });
      queryClient.invalidateQueries({ queryKey: ["memberCardIndex"] });
    } catch (e: any) {
      showToast(e?.message ?? t("membership.redeemFail"), "error");
    } finally {
      setSubmitting(false);
    }
  };

  const handleBuy = (_plan: Plan) => {
    showToast(t("membership.paymentComingSoon"), "info");
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("membership.title")} />
      {indexLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView
          className="flex-1"
          contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
          showsVerticalScrollIndicator={false}
        >
          <会员卡片框 level={frameLevel} trial={frameState.trialActive} motion={frameState.motion}>
            <View className="flex-row items-center gap-3 py-1">
              <会员头像框
                uri={authUser?.avatar ?? userInfo?.avatar}
                uid={authUser?.uid ?? userInfo?.uid}
                level={frameLevel}
                size={72}
                zh={zh}
                trial={frameState.trialActive}
                motion={frameState.motion}
                frameId={authUser?.avatar_frame}
              />
              <View className="flex-1">
                <Text className="text-base font-extrabold" style={{ color: "#111827" }}>
                  {zh ? frameTier.nameZh : `${frameTier.nameEn} Member`}
                </Text>
                <Text className="text-sm mt-1 font-bold" style={{ color: frameTier.ring }}>
                  {frameState.trialActive
                    ? t("membership.trialActive")
                    : `LV${frameLevel} · ${isMember ? t("membership.statusActive") : t("membership.statusInactive")}`}
                </Text>
                <Text className="text-xs mt-1" style={{ color: "#6B7280" }}>
                  {statusLabel}
                </Text>
              </View>
            </View>
          </会员卡片框>

          <View className="bg-white rounded-2xl p-4 border border-gray-100 mt-4 mb-4">
            <Text className="text-base font-bold" style={{ color: Colors.neutral[800] }}>
              {t("membership.pointsBalance", {
                points: Number(authUser?.integral ?? userInfo?.integral ?? 0),
              })}
            </Text>
            <Text className="text-base font-bold mt-4" style={{ color: Colors.neutral[800] }}>
              {t("membership.rulesHeading")}
            </Text>
            {[
              t("membership.rulesShop"),
              t("membership.rulesDaily"),
              t("membership.rulesStack"),
              t("membership.rulesCoupon"),
              t("membership.rulesStop"),
            ].map((line) => (
              <Text key={line.slice(0, 24)} className="text-xs leading-5 mt-2" style={{ color: "#4B5563" }}>
                {line}
              </Text>
            ))}
            <View className="mt-3 rounded-xl overflow-hidden" style={{ borderWidth: 1, borderColor: "#E5E7EB" }}>
              <View className="flex-row px-3 py-2" style={{ backgroundColor: "#F3F4F6" }}>
                <Text className="flex-1 text-[11px] font-bold" style={{ color: "#374151" }}>
                  {zh ? "實付" : "Pay"}
                </Text>
                <Text className="w-16 text-[11px] font-bold" style={{ color: "#374151" }}>
                  {zh ? "普通 1.0" : "Regular"}
                </Text>
                <Text className="w-16 text-[11px] font-bold" style={{ color: "#374151" }}>
                  {zh ? "黃金 1.2" : "Gold 1.2x"}
                </Text>
              </View>
              {[100, 200, 500].map((pay) => (
                <View key={pay} className="flex-row px-3 py-2 border-t border-gray-100">
                  <Text className="flex-1 text-[11px]" style={{ color: "#4B5563" }}>
                    ${pay}
                  </Text>
                  <Text className="w-16 text-[11px]" style={{ color: "#111827" }}>
                    {shopGiftPoints(pay, 0)} {zh ? "分" : "pts"}
                  </Text>
                  <Text className="w-16 text-[11px]" style={{ color: "#111827" }}>
                    {shopGiftPoints(pay, 2)} {zh ? "分" : "pts"}
                  </Text>
                </View>
              ))}
            </View>
          </View>

          <View className="bg-white rounded-2xl p-4 border border-gray-100 mt-4 mb-4">
            <Text className="text-base font-bold" style={{ color: Colors.neutral[800] }}>
              {t("membership.growthHeading")}
            </Text>
            <Text className="text-2xl font-extrabold mt-2" style={{ color: Colors.brand.red }}>
              {parsed.exp}
            </Text>
            <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }}>
              {t("membership.growthNow", { exp: parsed.exp })}
              {nextExp > 0
                ? `  ·  ${t("membership.growthNext", { remain })}`
                : `  ·  ${t("membership.growthMax")}`}
            </Text>
            <View className="mt-3 h-2 rounded-full overflow-hidden" style={{ backgroundColor: "#E5E7EB" }}>
              <View
                style={{
                  width: `${progressPct}%`,
                  height: "100%",
                  backgroundColor: frameTier.ring,
                  borderRadius: 999,
                }}
              />
            </View>
            <Text className="text-xs mt-2" style={{ color: Colors.neutral[500] }}>
              {t("membership.todayExp", { exp: parsed.todayExp })}
            </Text>
          </View>

          <View className="mb-4">
            <Text className="text-base font-bold mb-3" style={{ color: Colors.neutral[800] }}>
              {t("membership.levelsHeading")}
            </Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 10 }}>
              {LEVELS.map((lv) => {
                const tier = MEMBER_FRAME_TIERS[lv];
                return (
                  <View key={lv} style={{ width: 168 }}>
                    <会员卡片框 level={lv}>
                      <View className="items-center">
                        <会员头像框
                          uri={authUser?.avatar}
                          uid={authUser?.uid}
                          level={lv}
                          size={56}
                          zh={zh}
                        />
                        <Text className="mt-2 text-sm font-extrabold" style={{ color: "#111827" }}>
                          {zh ? tier.nameZh : tier.nameEn}
                        </Text>
                        <Text className="text-[11px] mt-0.5" style={{ color: tier.ring }}>
                          LV{lv} · {tier.bonus}
                        </Text>
                      </View>
                    </会员卡片框>
                  </View>
                );
              })}
            </ScrollView>
          </View>

          {plans.length > 0 && (
            <View className="mb-4">
              <Text className="text-base font-bold mb-3" style={{ color: Colors.neutral[800] }}>
                {t("membership.plansHeading")}
              </Text>
              <View className="gap-3">
                {plans.map((plan) => {
                  const titleKey = PLAN_KEY_BY_TYPE[plan.type];
                  const label = titleKey ? t(titleKey) : plan.title;
                  const locked = PLAN_REWARDS[plan.type];
                  const salePrice = locked?.price ?? Number(plan.pre_price);
                  const listPrice = locked?.listPrice ?? Number(plan.price);
                  const showOriginal = listPrice > salePrice;
                  return (
                    <View
                      key={plan.id}
                      className="bg-white rounded-2xl p-4 border border-gray-100"
                    >
                      <View className="flex-row items-center">
                        <View className="flex-1">
                          <Text className="text-base font-bold" style={{ color: Colors.neutral[800] }}>
                            {label}
                          </Text>
                          <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }}>
                            {plan.type === "ever"
                              ? t("membership.daysLifetime")
                              : t("membership.days", { count: plan.vip_day })}
                          </Text>
                        </View>
                        <View className="items-end mr-3">
                          <Text className="text-lg font-bold" style={{ color: Colors.brand.red }}>
                            {formatPrice(salePrice)}
                          </Text>
                          {showOriginal && (
                            <Text
                              className="text-xs mt-0.5"
                              style={{
                                color: Colors.neutral[400],
                                textDecorationLine: "line-through",
                              }}
                            >
                              {t("membership.originalPrice", {
                                price: formatPrice(listPrice),
                              })}
                            </Text>
                          )}
                        </View>
                        <Pressable
                          onPress={() => handleBuy(plan)}
                          className="h-10 px-4 rounded-full items-center justify-center"
                        >
                          <LinearGradient
                            pointerEvents="none"
                            colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                            start={{ x: 0.5, y: 0 }}
                            end={{ x: 0.5, y: 1 }}
                            style={{
                              position: "absolute",
                              top: 0,
                              left: 0,
                              right: 0,
                              bottom: 0,
                              borderRadius: 999,
                            }}
                          />
                          <Text className="text-white text-sm font-semibold">
                            {t("membership.buy")}
                          </Text>
                        </Pressable>
                      </View>
                      <会员方案奖励卡
                        planType={plan.type}
                        currentExp={parsed.exp}
                        uid={authUser?.uid}
                        avatar={authUser?.avatar}
                      />
                    </View>
                  );
                })}
              </View>
            </View>
          )}

          {rights.length > 0 && (
            <View className="mb-4">
              <Text className="text-base font-bold mb-3" style={{ color: Colors.neutral[800] }}>
                {t("membership.benefitsHeading")}
              </Text>
              <View className="bg-white rounded-2xl p-4 border border-gray-100 gap-4">
                {rights.map((r, idx) => {
                  const img = r.pic ?? r.image;
                  return (
                    <View key={`${r.right_type}-${idx}`} className="flex-row items-center gap-3">
                      {img ? (
                        <Image
                          source={{ uri: normalizeImageUrl(img) }}
                          style={{ width: s(36), height: s(36) }}
                          resizeMode="contain"
                        />
                      ) : (
                        <View
                          className="w-9 h-9 rounded-full items-center justify-center"
                          style={{ backgroundColor: `${Colors.brand.red}15` }}
                        >
                          <Gift size={s(18)} color={Colors.brand.red} />
                        </View>
                      )}
                      <View className="flex-1">
                        <Text className="text-sm font-semibold" style={{ color: Colors.neutral[800] }}>
                          {r.title}
                        </Text>
                        {!!(r.right ?? r.explain) && (
                          <Text className="text-xs mt-0.5" style={{ color: Colors.neutral[500] }}>
                            {r.right ?? r.explain}
                          </Text>
                        )}
                      </View>
                    </View>
                  );
                })}
              </View>
            </View>
          )}

          {isMember && (
            <View className="mb-4">
              <Text className="text-base font-bold mb-3" style={{ color: Colors.neutral[800] }}>
                {t("membership.monthlyCouponsHeading")}
              </Text>
              <View className="bg-white rounded-2xl p-4 border border-gray-100">
                {coupons.length > 0 ? (
                  <View className="gap-3">
                    {coupons.map((c, i) => (
                      <View key={`${c.id ?? i}`} className="flex-row items-center gap-3">
                        <Ticket size={s(20)} color={Colors.brand.red} />
                        <View className="flex-1">
                          <Text className="text-sm font-semibold" style={{ color: Colors.neutral[800] }}>
                            {c.coupon_title ?? c.title ?? "Coupon"}
                          </Text>
                          {!!c.use_min_price && (
                            <Text className="text-xs mt-0.5" style={{ color: Colors.neutral[500] }}>
                              Min. {formatPrice(c.use_min_price)}
                            </Text>
                          )}
                        </View>
                        <Text className="text-base font-bold" style={{ color: Colors.brand.red }}>
                          {formatPrice(c.coupon_price ?? 0)}
                        </Text>
                      </View>
                    ))}
                  </View>
                ) : (
                  <Text className="text-sm" style={{ color: Colors.neutral[500] }}>
                    {t("membership.noCoupons")}
                  </Text>
                )}
              </View>
            </View>
          )}

          <View className="bg-white rounded-2xl p-5 border border-gray-100">
            <View className="flex-row items-start gap-3">
              <View className="flex-1">
                <Text className="text-base font-bold" style={{ color: Colors.neutral[800] }}>
                  {t("membership.trialHeading")}
                </Text>
                <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }}>
                  {t("membership.trialDesc")}
                </Text>
                <Text
                  className="text-xs mt-2"
                  style={{
                    color: isGetFree ? Colors.success : Colors.neutral[400],
                  }}
                >
                  {isGetFree ? t("membership.trialAvailable") : t("membership.trialUsed")}
                </Text>
              </View>
              <会员头像框
                uri={authUser?.avatar}
                uid={authUser?.uid}
                level={0}
                size={58}
                zh={zh}
                trial
                motion
                frameId="回归梦境"
                showBadge={false}
              />
            </View>
            <View className="mt-3">
              <会员卡片框 level={0}>
                <Text className="text-[10px] font-extrabold" style={{ color: MEMBER_FRAME_TIERS[0].ring }}>
                  {zh ? "免費" : "FREE"}
                </Text>
                <Text className="text-sm font-extrabold mt-0.5" style={{ color: "#111827" }}>
                  {zh ? MEMBER_FRAME_TIERS[0].nameZh : "Free Member"}
                </Text>
                <Text className="text-[11px] mt-1" style={{ color: "#6B7280" }}>
                  {t("membership.rewardFrameOnly")}
                </Text>
              </会员卡片框>
            </View>
            <Text className="text-xs mt-3 mb-2" style={{ color: Colors.neutral[500] }}>
              {t("membership.trialHint")}
            </Text>
            <TextInput
              className="border border-gray-200 rounded-xl px-4 py-3 text-base mb-3"
              placeholder={FREE_TRIAL_HINT.code}
              placeholderTextColor="#C5CDD4"
              value={code}
              onChangeText={setCode}
              autoCapitalize="characters"
              autoCorrect={false}
              editable={isGetFree}
            />
            <TextInput
              className="border border-gray-200 rounded-xl px-4 py-3 text-base"
              placeholder={FREE_TRIAL_HINT.pwd}
              placeholderTextColor="#C5CDD4"
              value={pwd}
              onChangeText={setPwd}
              autoCapitalize="none"
              autoCorrect={false}
              editable={isGetFree}
            />
            <Pressable
              onPress={handleRedeem}
              disabled={!isGetFree || submitting}
              className="mt-4 h-12 rounded-xl items-center justify-center"
              style={{
                backgroundColor: !isGetFree || submitting ? Colors.neutral[300] : "transparent",
                shadowColor: "#04A8AE",
                shadowOffset: { width: 0, height: 6 },
                shadowOpacity: !isGetFree || submitting ? 0 : 0.3,
                shadowRadius: 12,
                elevation: !isGetFree || submitting ? 0 : 6,
              }}
            >
              {isGetFree && !submitting && (
                <>
                  <LinearGradient
                    pointerEvents="none"
                    colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                    start={{ x: 0, y: 0.5 }}
                    end={{ x: 1, y: 0.5 }}
                    style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }}
                  />
                  <LinearGradient
                    pointerEvents="none"
                    colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]}
                    start={{ x: 0.5, y: 0 }}
                    end={{ x: 0.5, y: 1 }}
                    style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }}
                  />
                </>
              )}
              <Text className="text-white font-semibold">
                {submitting ? t("membership.redeeming") : t("membership.redeem")}
              </Text>
            </Pressable>
          </View>
        </ScrollView>
      )}
    </View>
  );
}
