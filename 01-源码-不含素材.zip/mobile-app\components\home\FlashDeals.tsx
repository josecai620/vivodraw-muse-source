
// components/home/FlashDeals.tsx
// 限时抢购横向滚动

import React from 'react';
import { View, Text, Pressable, ScrollView, Image } from 'react-native';
import { Clock, ArrowRight, Star, Zap } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import TealSurface from '@/components/ui/TealSurface';

interface FlashProduct {
  id: number;
  name: string;
  image: string;
  currentPrice: string;
  originalPrice: string;
  discount: string;
  rating: string;
  reviews: string;
  soldPercentage: number;
}

export default function FlashDeals() {
  const flashProducts: FlashProduct[] = [
    {
      id: 1,
      name: 'Wireless Earbuds Pro',
      image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&q=80',
      currentPrice: '$59',
      originalPrice: '$129',
      discount: '-54%',
      rating: '4.8',
      reviews: '2.1k',
      soldPercentage: 75,
    },
    {
      id: 2,
      name: 'Smart Fitness Tracker',
      image: 'https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=400&q=80',
      currentPrice: '$39',
      originalPrice: '$89',
      discount: '-56%',
      rating: '4.6',
      reviews: '1.8k',
      soldPercentage: 60,
    },
    {
      id: 3,
      name: 'Portable Speaker',
      image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&q=80',
      currentPrice: '$45',
      originalPrice: '$99',
      discount: '-55%',
      rating: '4.7',
      reviews: '3.2k',
      soldPercentage: 85,
    },
    {
      id: 4,
      name: 'HD Webcam 1080p',
      image: 'https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?w=400&q=80',
      currentPrice: '$29',
      originalPrice: '$69',
      discount: '-58%',
      rating: '4.5',
      reviews: '956',
      soldPercentage: 45,
    },
  ];

  return (
    <LinearGradient
      colors={['#FFFFFF', '#F7F8F8']}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      className="py-16 px-6 rounded-3xl mx-6"
    >
      {/* 标题区域 */}
      <View className="flex-row items-center justify-between mb-8">
        <View className="flex-row items-center gap-6">
          <View className="flex-row items-center gap-2">
            <Zap size={28} color="#04A8AE" strokeWidth={2.2} fill="#D6F4F5" />
            <Text className="text-4xl font-bold text-gray-700">Flash Deals</Text>
          </View>
          <View className="bg-brand-red px-4 py-2 rounded-lg flex-row items-center gap-2">
            <Clock size={18} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
            <Text className="text-white text-base font-bold">Ends in 02:45:30</Text>
          </View>
        </View>
        <Pressable className="border-2 border-brand-red h-10 px-6 rounded-lg flex-row items-center gap-2 active:bg-brand-red">
          <Text className="text-brand-red text-base font-bold">View All</Text>
          <ArrowRight size={16} color="#04A8AE" />
        </Pressable>
      </View>
      
      {/* 商品横向滚动 */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} className="gap-6">
        {flashProducts.map((product) => (
          <Pressable
            key={product.id}
            className="bg-white rounded-2xl overflow-hidden border border-gray-100 w-64 active:scale-95"
          >
            {/* 商品图片 */}
            <View className="relative">
              <Image
                source={{ uri: product.image }}
                className="w-full h-60"
                resizeMode="cover"
              />
              {/* 折扣标签 */}
              <View className="absolute top-3 left-3 bg-brand-red px-3 py-1.5 rounded-md">
                <Text className="text-white text-sm font-bold">{product.discount}</Text>
              </View>
              {/* 库存进度条 */}
              <View className="absolute bottom-3 left-3 right-3">
                <View className="bg-white/50 h-1.5 rounded-full overflow-hidden mb-1">
                  <View 
                    className="bg-brand-red h-full rounded-full"
                    style={{ width: `${product.soldPercentage}%` }}
                  />
                </View>
                <Text className="text-white text-xs font-bold">
                  {product.soldPercentage}% Claimed
                </Text>
              </View>
            </View>
            
            {/* 商品信息 */}
            <View className="p-4">
              <Text className="text-base font-bold text-gray-700 mb-2" numberOfLines={2}>
                {product.name}
              </Text>
              
              {/* 评分 */}
              <View className="flex-row items-center gap-1 mb-3">
                <Star size={14} color="#171A1A" fill="#171A1A" />
                <Text className="text-sm font-semibold text-gray-700">{product.rating}</Text>
                <Text className="text-sm text-gray-400">({product.reviews})</Text>
              </View>
              
              {/* 价格 */}
              <View className="flex-row items-baseline gap-2 mb-3">
                <Text className="text-2xl font-bold text-brand-red">{product.currentPrice}</Text>
                <Text className="text-base text-gray-400 line-through">{product.originalPrice}</Text>
              </View>
              
              {/* 按钮 */}
              <Pressable className="h-10" style={({ pressed }) => ({ transform: [{ scale: pressed ? 0.97 : 1 }] })}>
                <TealSurface direction="lr" radius={8} style={{ height: 40 }} contentStyle={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
                <Text className="text-white text-base font-bold">Grab Now</Text>
              </TealSurface>
              </Pressable>
            </View>
          </Pressable>
        ))}
      </ScrollView>
    </LinearGradient>
  );
}
