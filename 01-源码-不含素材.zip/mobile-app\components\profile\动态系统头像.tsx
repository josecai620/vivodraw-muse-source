import React, { useEffect, useRef } from "react";
import { Animated, Easing, Image, View, type ImageSourcePropType } from "react-native";

export function 动态系统头像({
  source,
  size,
  motion = true,
}: {
  source: ImageSourcePropType;
  size: number;
  motion?: boolean;
}) {
  const bob = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!motion) {
      bob.setValue(0);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(bob, {
          toValue: 1,
          duration: 1800,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(bob, {
          toValue: 0,
          duration: 1800,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [bob, motion]);

  const translateY = bob.interpolate({ inputRange: [0, 1], outputRange: [0, -2] });
  const scale = bob.interpolate({ inputRange: [0, 1], outputRange: [1, 1.035] });

  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, overflow: "hidden" }}>
      <Animated.View
        style={{
          width: size,
          height: size,
          transform: [{ translateY }, { scale }],
        }}
      >
        <Image source={source} style={{ width: size, height: size }} resizeMode="cover" />
      </Animated.View>
    </View>
  );
}
