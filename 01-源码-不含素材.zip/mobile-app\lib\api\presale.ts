import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

export function getPresaleList(params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.presale.list, { params });
}
