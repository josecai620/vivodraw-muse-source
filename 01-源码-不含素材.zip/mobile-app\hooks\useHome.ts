import { useQuery } from "@tanstack/react-query";
import { getHomeIndex, getGroomList, getHomeLayout } from "@/lib/api/home";

export function useHomeLayout() {
  return useQuery({
    queryKey: ["homeLayout"],
    queryFn: getHomeLayout,
    staleTime: 1000 * 60 * 5,
    gcTime: 1000 * 60 * 30,
  });
}

export function useHomeIndex(enabled = true) {
  return useQuery({
    queryKey: ["homeIndex"],
    queryFn: getHomeIndex,
    staleTime: 1000 * 60 * 5,
    enabled,
  });
}

export function useGroomList(type: number) {
  return useQuery({
    queryKey: ["groom", type],
    queryFn: () => getGroomList(type, { page: 1, limit: 10 }),
    staleTime: 1000 * 60 * 5,
  });
}
