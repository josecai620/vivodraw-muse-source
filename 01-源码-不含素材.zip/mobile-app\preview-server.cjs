const http = require("http");
const fs = require("fs");
const path = require("path");

const ROOT = path.join(__dirname, "dist");
const PORT = 8090;
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".ttf": "font/ttf",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ico": "image/x-icon",
};

function tryFile(p) {
  try {
    const st = fs.statSync(p);
    if (st.isFile()) return p;
    const idx = path.join(p, "index.html");
    if (fs.statSync(idx).isFile()) return idx;
  } catch {}
  return null;
}

const server = http.createServer((req, res) => {
  let urlPath = decodeURIComponent(req.url.split("?")[0]);
  let target = path.join(ROOT, urlPath);
  let found = tryFile(target);
  if (!found && !path.extname(urlPath)) {
    found = tryFile(target + ".html");
  }
  if (!found) found = tryFile(path.join(ROOT, "index.html"));
  if (!found) {
    res.writeHead(404);
    return res.end("not found");
  }
  const ext = path.extname(found).toLowerCase();
  res.writeHead(200, { "Content-Type": MIME[ext] || "application/octet-stream" });
  fs.createReadStream(found).pipe(res);
});

server.listen(PORT, "127.0.0.1", () => console.log("static server on http://127.0.0.1:" + PORT));
