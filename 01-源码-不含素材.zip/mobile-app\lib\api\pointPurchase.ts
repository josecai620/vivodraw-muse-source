import { fetchAuthGet, fetchAuthPost, type ApiWriteResult } from "@/lib/api/legacyHttp";
import { isGameWalletGame, type GameWalletGame } from "@/lib/api/gameWallet";

export type PointPurchaseState = {
  account_id: number;
  game: GameWalletGame;
  money_balance_minor: number;
  point_balance: number;
  price_per_point_minor: number;
  currency: "USD";
  quote_version: string;
  max_points_per_purchase: number;
  min_recharge_minor: number;
  recharge_available: boolean;
};
export type PointPurchaseRequest = { request_id: string; account_id: number; game: GameWalletGame; points: number; quote_version: string };
export type PointPurchaseReceipt = PointPurchaseRequest & {
  account_id: number;
  currency: "USD";
  price_per_point_minor: number;
  money_spent_minor: number;
  money_delta_minor: number;
  point_delta: number;
  money_bill_id: number;
  point_bill_id: number;
  created_at: number;
};
export type PointPurchaseResult = { accepted: boolean; duplicate: boolean; reason_code?: string; receipt: PointPurchaseReceipt | null; state: PointPurchaseState };

function numberValue(value: unknown, integer = true) {
  if (typeof value !== "number" || !Number.isFinite(value) || Math.abs(value) > Number.MAX_SAFE_INTEGER || (integer && !Number.isSafeInteger(value))) throw new Error("Invalid number");
  return value;
}
function quoteVersion(value: unknown) {
  if (typeof value !== "string" || !value.trim() || value.length > 256) throw new Error("Invalid quote");
  return value;
}
function normalizeState(value: unknown): PointPurchaseState {
  if (!value || typeof value !== "object") throw new Error("Missing purchase state");
  const raw = value as Record<string, unknown>;
  if (!isGameWalletGame(raw.game) || raw.currency !== "USD" || typeof raw.recharge_available !== "boolean") throw new Error("Invalid purchase currency");
  const state: PointPurchaseState = {
    account_id: numberValue(raw.account_id), game: raw.game, currency: "USD",
    money_balance_minor: numberValue(raw.money_balance_minor), point_balance: numberValue(raw.point_balance, false),
    price_per_point_minor: numberValue(raw.price_per_point_minor), quote_version: quoteVersion(raw.quote_version),
    max_points_per_purchase: numberValue(raw.max_points_per_purchase), min_recharge_minor: numberValue(raw.min_recharge_minor),
    recharge_available: raw.recharge_available,
  };
  if (state.account_id <= 0 || state.money_balance_minor < 0 || state.point_balance < 0 || state.price_per_point_minor !== 100
    || state.max_points_per_purchase <= 0 || state.min_recharge_minor < 0) throw new Error("Invalid purchase state");
  return state;
}
function normalizeReceipt(value: unknown): PointPurchaseReceipt | null {
  if (value === null) return null;
  if (!value || typeof value !== "object") throw new Error("Missing receipt");
  const raw = value as Record<string, unknown>;
  if (!isGameWalletGame(raw.game) || raw.currency !== "USD" || typeof raw.request_id !== "string"
    || typeof raw.created_at !== "number" || !Number.isSafeInteger(raw.created_at) || raw.created_at <= 0) throw new Error("Invalid receipt");
  return {
    request_id: raw.request_id, account_id: numberValue(raw.account_id), game: raw.game, currency: "USD",
    points: numberValue(raw.points), quote_version: quoteVersion(raw.quote_version), price_per_point_minor: numberValue(raw.price_per_point_minor),
    money_spent_minor: numberValue(raw.money_spent_minor), money_delta_minor: numberValue(raw.money_delta_minor), point_delta: numberValue(raw.point_delta),
    money_bill_id: numberValue(raw.money_bill_id), point_bill_id: numberValue(raw.point_bill_id), created_at: raw.created_at,
  };
}
export async function getPointPurchaseState(game: GameWalletGame): Promise<ApiWriteResult<PointPurchaseState>> {
  try {
    const response = await fetchAuthGet<unknown>(`/api/point_purchase/state?game=${game}`);
    if (!response.ok) return { ...response, data: undefined };
    const data = normalizeState(response.data);
    if (data.game !== game) throw new Error("Wrong purchase game");
    return { ...response, data };
  } catch { return { ok: false, message: "Purchase balance could not be confirmed." }; }
}
export async function buyPlatformPoints(request: PointPurchaseRequest): Promise<ApiWriteResult<PointPurchaseResult>> {
  try {
    const response = await fetchAuthPost<Record<string, unknown>>("/api/point_purchase/buy", {
      request_id: request.request_id, account_id: request.account_id, game: request.game, points: request.points, quote_version: request.quote_version,
    });
    if (!response.ok || !response.data) return { ...response, data: undefined };
    const raw = response.data;
    if (typeof raw.accepted !== "boolean" || typeof raw.duplicate !== "boolean" || (raw.duplicate && !raw.accepted)) throw new Error("Invalid purchase result");
    return { ...response, data: {
      accepted: raw.accepted, duplicate: raw.duplicate, reason_code: typeof raw.reason_code === "string" ? raw.reason_code : undefined,
      state: normalizeState(raw.state), receipt: normalizeReceipt(raw.receipt),
    } };
  } catch { return { ok: false, message: "Purchase result could not be confirmed." }; }
}
