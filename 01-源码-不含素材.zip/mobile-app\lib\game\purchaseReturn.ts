import { gameReturnPaths, isGameWalletGame } from "@/lib/api/gameWallet";

/** 只允许恢复明确的购买、兑换及充值页面；不接收任意站内或外部跳转。 */
export function safePurchaseReturnTo(value: unknown): string | null {
  if (typeof value !== "string" || value.length > 512 || !value.startsWith("/")
    || /[\\\s#\u0000-\u001f\u007f]/.test(value)) return null;
  const split = value.indexOf("?");
  if (split < 0) return null;
  const pathname = value.slice(0, split), query = new URLSearchParams(value.slice(split + 1));
  const keys = [...query.keys()];
  if (new Set(keys).size !== keys.length) return null;
  const only = (...allowed: string[]) => keys.length === allowed.length && keys.every((key) => allowed.includes(key));
  const game = query.get("game");
  if (pathname === "/point-purchase" && only("game") && isGameWalletGame(game)) return `/point-purchase?game=${game}`;
  if (pathname === "/game-wallet" && only("game", "returnTo") && isGameWalletGame(game)
    && query.get("returnTo") === gameReturnPaths[game]) return `/game-wallet?game=${game}&returnTo=${encodeURIComponent(gameReturnPaths[game])}`;
  if (pathname === "/wallet" && only("game", "pointPurchase") && isGameWalletGame(game)
    && query.get("pointPurchase") === "1") return `/wallet?game=${game}&pointPurchase=1`;
  const order = query.get("order_id"), status = query.get("recharge");
  if (pathname === "/wallet" && only("provider", "recharge", "order_id") && query.get("provider") === "stripe"
    && (status === "success" || status === "cancelled") && order && /^[A-Za-z0-9_-]{1,80}$/.test(order)) {
    return `/wallet?provider=stripe&recharge=${status}&order_id=${order}`;
  }
  return null;
}

export function purchaseAuthHref(returnTo: unknown, mode: "login" | "register" | "recover" = "login") {
  const route = { login: "/auth", register: "/auth/register", recover: "/auth/forgot-password" }[mode];
  const destination = safePurchaseReturnTo(returnTo);
  return destination ? `${route}?returnTo=${encodeURIComponent(destination)}` : route;
}
