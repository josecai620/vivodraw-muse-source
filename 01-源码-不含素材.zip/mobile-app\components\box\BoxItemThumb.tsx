/**
 * BoxItemThumb — 方向 C 统一商品缩略图
 * 远程图片/本地 require 正常渲染；空值或旧版 emoji 兜底字符串统一显示
 * 中性内凹底 + teal Package 线图标，杜绝彩色 emoji。
 */
import React from "react";
import { View, type ImageSourcePropType, type StyleProp, type ViewStyle } from "react-native";
import { Image } from "expo-image";
import { Package } from "lucide-react-native";
import { BoxSurfaces, BoxBorders, BoxAccent, BoxRadius, bs } from "@/lib/boxTheme";

export function isRemoteItemImage(value: unknown): value is string {
  return typeof value === "string" && /^https?:\/\//i.test(value.trim());
}

interface BoxItemThumbProps {
  source?: string | ImageSourcePropType | null;
  size?: number;
  iconSize?: number;
  radius?: number;
  style?: StyleProp<ViewStyle>;
}

export function BoxItemThumb({
  source,
  size = bs(48),
  iconSize,
  radius,
  style,
}: BoxItemThumbProps) {
  const isRemote = isRemoteItemImage(source);
  const isLocal = !!source && typeof source !== "string";
  const corner = radius ?? Math.max(8, size * 0.22);

  const base: ViewStyle = {
    width: size,
    height: size,
    borderRadius: corner,
    overflow: "hidden",
    backgroundColor: BoxSurfaces.elevated,
    borderWidth: 1,
    borderColor: BoxBorders.default,
    alignItems: "center",
    justifyContent: "center",
  };

  if (isRemote || isLocal) {
    return (
      <View style={[base, style]}>
        <Image
          source={isRemote ? { uri: source as string } : (source as ImageSourcePropType)}
          style={{ width: "100%", height: "100%" }}
          contentFit="cover"
          transition={150}
        />
      </View>
    );
  }

  return (
    <View style={[base, style]}>
      <Package size={iconSize ?? size * 0.46} color={BoxAccent.gold} strokeWidth={1.6} />
    </View>
  );
}
