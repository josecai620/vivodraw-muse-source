import { unwrapApiPagedList } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";

export function toNum(v: unknown, fb = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fb;
}

export function collectImageUrls(...vals: unknown[]): string[] {
  const out: string[] = [];
  const push = (raw: string) => {
    const next = normalizeImageUrl(String(raw).trim());
    if (next && !out.includes(next)) out.push(next);
  };
  const walk = (v: unknown) => {
    if (!v) return;
    if (Array.isArray(v)) {
      v.forEach(walk);
      return;
    }
    if (typeof v !== "string") return;
    const t = v.trim();
    if (!t) return;
    if (t.startsWith("[")) {
      try {
        walk(JSON.parse(t));
        return;
      } catch {
        /* fall through */
      }
    }
    const imgRe = /<img[^>]+src=["']([^"']+)["']/gi;
    let m: RegExpExecArray | null;
    let found = false;
    while ((m = imgRe.exec(t))) {
      found = true;
      push(m[1]);
    }
    if (!found) push(t);
  };
  vals.forEach(walk);
  return out;
}

export function toRecordList(data: unknown): any[] {
  return unwrapApiPagedList<any>(data);
}

/** 参考实现 IndexFun：分:秒:毫秒前两位，例如 00:25:50。 */
export function formatRevealMsClock(ms: number): string {
  const time = Math.max(0, Math.floor(ms));
  const minute = Math.floor(time / 1000 / 60);
  const second = Math.floor((time / 1000) % 60);
  let cs = Number(String(Math.floor(time % 1000)).slice(0, 2));
  if (!Number.isFinite(cs)) cs = 0;
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(minute)}:${pad(second)}:${pad(cs)}`;
}

/** @deprecated 用 formatRevealMsClock；保留别名避免旧引用。 */
export function formatRevealClock(ms: number): string {
  return formatRevealMsClock(ms);
}

export function luckyPos(code: unknown): number {
  const n = toNum(code);
  if (n >= 10000001) return n - 10000000;
  return n;
}

export type CloudBuyPeriod = {
  bianhao: string;
  productId: number;
  kaijiangId: number;
  uid: number;
  nickname: string;
  avatar: string;
  unique: string;
  shares: number;
  revealAt: string;
  buyAt: string;
};

export function mapKaijiangRow(row: any, fallbackProductId: number): CloudBuyPeriod | null {
  const bianhao = String(row?.bianhao ?? row?.qh ?? row?.period ?? "").trim();
  if (!bianhao) return null;
  return {
    bianhao,
    productId: toNum(row?.product_id ?? fallbackProductId) || fallbackProductId,
    kaijiangId: toNum(row?.id ?? row?.kaijiang_id),
    uid: toNum(row?.uid),
    nickname: String(row?.nickname ?? row?.username ?? row?.user ?? ""),
    avatar: normalizeImageUrl(String(row?.avatar ?? row?.uphoto ?? "")),
    unique: String(row?.unique ?? row?.user_code ?? row?.lucky_code ?? ""),
    shares: toNum(row?.huanqu_num ?? row?.gonumber ?? row?.total_num),
    revealAt: String(row?.kaijiang_time ?? row?.end_time ?? ""),
    buyAt: String(row?.add_time ?? row?.zhongjiang_time ?? row?.buy_time ?? ""),
  };
}

export type CloudBuyCard = {
  id: number;
  name: string;
  image: string;
  points: number;
  total: number;
  sold: number;
  remain: number;
  addTime: number;
};

/**
 * 云购人次：总人次=price/zongrenshu，已售=exchange_num。
 * stock 在现役库是最大期数，绝不能当剩余人次。
 */
export function cloudBuyShares(item: any): { total: number; sold: number; remain: number } {
  const total = Math.max(toNum(item?.zongrenshu, 0), toNum(item?.price, 0), 1);
  const progress = Math.max(0, Math.min(100, toNum(item?.jindu_bili ?? item?.jindu, 0)));
  const sold = Math.max(
    0,
    Math.min(
      total,
      Math.max(
        toNum(item?.canyurenshu, 0),
        toNum(item?.exchange_num, 0),
        progress > 0 ? Math.round((progress / 100) * total) : 0,
      ),
    ),
  );
  const hinted = item?.remainingShares ?? item?.shenyurenshu;
  const remain =
    hinted == null || hinted === ""
      ? Math.max(0, total - sold)
      : Math.max(0, Math.min(total, toNum(hinted, total - sold)));
  return { total, sold, remain };
}

export function mapCloudProduct(item: any): CloudBuyCard | null {
  const id = toNum(item?.id);
  if (id <= 0) return null;
  const { total, sold, remain } = cloudBuyShares(item);
  return {
    id,
    name: String(item?.store_name ?? item?.title ?? item?.name ?? item?.goods_name ?? ""),
    image: normalizeImageUrl(String(item?.image ?? item?.img ?? item?.thumb ?? "")),
    points: Math.max(toNum(item?.price ?? item?.integral ?? item?.points, 1), 1),
    total,
    sold,
    remain,
    addTime: toNum(item?.add_time ?? item?.addtime),
  };
}

/** 人气保持接口货架序（is_hot/sort），不要按已售比例重排，否则刚买的会跳到最前。 */
export function sortCloudBuyCards(
  list: CloudBuyCard[],
  sort: "hot" | "new" | "value" | "soon" | "price",
): CloudBuyCard[] {
  if (sort === "hot") return list;
  const sorted = [...list];
  if (sort === "new") sorted.sort((a, b) => b.addTime - a.addTime);
  else if (sort === "value" || sort === "price") sorted.sort((a, b) => b.points - a.points);
  else if (sort === "soon") sorted.sort((a, b) => a.remain - b.remain);
  return sorted;
}

/** 清单空态推荐：先排已买过一半、再排更接近揭晓（剩余比例低）。 */
export function pickSoonToReveal(cards: CloudBuyCard[], take = 8): CloudBuyCard[] {
  const open = cards.filter((p) => p.remain > 0 && p.total > 0);
  const ratio = (p: CloudBuyCard) => p.sold / p.total;
  const bySoon = (a: CloudBuyCard, b: CloudBuyCard) => {
    const diff = ratio(b) - ratio(a);
    if (Math.abs(diff) > 0.0001) return diff;
    return a.remain - b.remain;
  };
  const half = open.filter((p) => ratio(p) >= 0.5).sort(bySoon);
  const rest = open.filter((p) => ratio(p) < 0.5).sort(bySoon);
  return [...half, ...rest].slice(0, take);
}

export function pickPrevWinner(list: CloudBuyPeriod[], activeBianhao: string): CloudBuyPeriod | null {
  const idx = list.findIndex((row) => row.bianhao === activeBianhao);
  if (idx >= 0) return list[idx + 1] ?? null;
  return list[0] ?? null;
}
