import { fetchAuthGet, fetchAuthPost, type ApiWriteResult } from "@/lib/api/legacyHttp";

export type GameExchangeDirection = "points_to_coins" | "coins_to_points";
export type GameWalletGame = "mine" | "pearl" | "farm";
export type GameCurrencyCode = "mine_coin" | "pearl_coin" | "reward_coin";
export const gameCurrencyCodes: Record<GameWalletGame, GameCurrencyCode> = { mine: "mine_coin", pearl: "pearl_coin", farm: "reward_coin" };
export const gameReturnPaths: Record<GameWalletGame, "/mine/mobile" | "/pearl" | "/farm"> = { mine: "/mine/mobile", pearl: "/pearl", farm: "/farm" };
export function isGameWalletGame(value: unknown): value is GameWalletGame { return value === "mine" || value === "pearl" || value === "farm"; }
export type GameWalletState = {
  game: GameWalletGame; currency_code: GameCurrencyCode; currency_name: string;
  account_id: number; point_balance: number; coin_balance: number;
  points_to_coins_rate: number; coins_to_points_rate: number;
  coins_to_points_enabled: boolean;
  quote_version: string; max_points_per_exchange: number;
};
export type GameExchangeRequest = {
  request_id: string; game: GameWalletGame; direction: GameExchangeDirection; amount: number; quote_version: string;
};
export type GameExchangeReceipt = GameExchangeRequest & {
  currency_code: GameCurrencyCode; currency_name: string;
  source_unit: "points" | GameCurrencyCode; source_amount: number;
  target_unit: "points" | GameCurrencyCode; target_amount: number;
  point_delta: number; coin_delta: number; point_bill_id: number; coin_bill_id: number;
  created_at: string | number;
};
export type GameExchangeResult = {
  accepted: boolean; duplicate: boolean; reason_code?: string;
  receipt: GameExchangeReceipt | null; state: GameWalletState;
};

function numberValue(value: unknown, integer = false): number {
  if (typeof value !== "number" && (typeof value !== "string" || !value.trim())) throw new Error("Invalid number");
  const result = Number(value);
  if (!Number.isFinite(result) || Math.abs(result) > Number.MAX_SAFE_INTEGER || (integer && !Number.isSafeInteger(result))) throw new Error("Invalid number");
  return result;
}

function normalizeState(value: unknown): GameWalletState {
  if (!value || typeof value !== "object") throw new Error("Missing wallet");
  const raw = value as Record<string, unknown>;
  if (!isGameWalletGame(raw.game) || raw.currency_code !== gameCurrencyCodes[raw.game]
    || typeof raw.currency_name !== "string" || !raw.currency_name.trim()) throw new Error("Invalid game currency");
  const state: GameWalletState = {
    game: raw.game, currency_code: raw.currency_code as GameCurrencyCode, currency_name: raw.currency_name,
    account_id: numberValue(raw.account_id, true), point_balance: numberValue(raw.point_balance), coin_balance: numberValue(raw.coin_balance, true),
    points_to_coins_rate: numberValue(raw.points_to_coins_rate, true), coins_to_points_rate: numberValue(raw.coins_to_points_rate, true),
    coins_to_points_enabled: typeof raw.coins_to_points_enabled === "boolean" ? raw.coins_to_points_enabled : raw.game !== "pearl",
    quote_version: typeof raw.quote_version === "string" ? raw.quote_version : "",
    max_points_per_exchange: numberValue(raw.max_points_per_exchange, true),
  };
  if (state.account_id <= 0 || state.point_balance < 0 || state.coin_balance < 0 || state.points_to_coins_rate !== 10
    || state.coins_to_points_rate < 10 || state.max_points_per_exchange <= 0 || !state.quote_version.includes(`:${state.game}:`) || state.quote_version.length > 256) throw new Error("Invalid wallet");
  return state;
}

function normalizeReceipt(value: unknown): GameExchangeReceipt | null {
  if (value === null) return null;
  if (!value || typeof value !== "object") throw new Error("Missing receipt");
  const raw = value as Record<string, unknown>;
  if (!isGameWalletGame(raw.game) || raw.currency_code !== gameCurrencyCodes[raw.game]
    || typeof raw.currency_name !== "string" || !raw.currency_name.trim()
    || typeof raw.request_id !== "string" || typeof raw.quote_version !== "string"
    || !["points_to_coins", "coins_to_points"].includes(String(raw.direction))
    || !["points", raw.currency_code].includes(String(raw.source_unit)) || !["points", raw.currency_code].includes(String(raw.target_unit))
    || !["string", "number"].includes(typeof raw.created_at)) throw new Error("Invalid receipt");
  return {
    game: raw.game, currency_code: raw.currency_code as GameCurrencyCode, currency_name: raw.currency_name,
    request_id: raw.request_id, direction: raw.direction as GameExchangeDirection,
    // 源数量以实际扣除回执为准；服务端回执不要求额外包含amount。
    amount: numberValue(raw.source_amount, true), quote_version: raw.quote_version,
    source_unit: raw.source_unit as "points" | GameCurrencyCode, source_amount: numberValue(raw.source_amount, true),
    target_unit: raw.target_unit as "points" | GameCurrencyCode, target_amount: numberValue(raw.target_amount, true),
    point_delta: numberValue(raw.point_delta, true), coin_delta: numberValue(raw.coin_delta, true),
    point_bill_id: numberValue(raw.point_bill_id, true), coin_bill_id: numberValue(raw.coin_bill_id, true),
    created_at: raw.created_at as string | number,
  };
}

export async function getGameWalletState(game: GameWalletGame): Promise<ApiWriteResult<GameWalletState>> {
  try {
    const response = await fetchAuthGet<unknown>(`/api/game_wallet/state?game=${game}`);
    if (!response.ok) return { ...response, data: undefined };
    const data = normalizeState(response.data);
    if (data.game !== game) throw new Error("Wrong game wallet");
    return { ...response, data };
  } catch { return { ok: false, message: "Wallet state could not be confirmed." }; }
}

export async function exchangeGameWallet(request: GameExchangeRequest): Promise<ApiWriteResult<GameExchangeResult>> {
  try {
    const response = await fetchAuthPost<Record<string, unknown>>("/api/game_wallet/exchange", {
      request_id: request.request_id, game: request.game, direction: request.direction, amount: request.amount, quote_version: request.quote_version,
    });
    if (!response.ok || !response.data) return { ...response, data: undefined };
    if (typeof response.data.accepted !== "boolean" || typeof response.data.duplicate !== "boolean") throw new Error("Invalid result");
    return { ...response, data: {
      accepted: response.data.accepted, duplicate: response.data.duplicate,
      reason_code: typeof response.data.reason_code === "string" ? response.data.reason_code : undefined,
      state: normalizeState(response.data.state), receipt: normalizeReceipt(response.data.receipt),
    } };
  } catch { return { ok: false, message: "Exchange result could not be confirmed." }; }
}
