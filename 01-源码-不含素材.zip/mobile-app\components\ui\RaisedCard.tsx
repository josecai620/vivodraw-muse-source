import React, { type PropsWithChildren } from "react";
import { Pressable, View, type ViewStyle, type StyleProp } from "react-native";
import { Colors, Shadows, s } from "@/constants/theme";

type Elevation = "sm" | "md" | "lg";

const SHADOW: Record<Elevation, ViewStyle> = {
  sm: Shadows.raisedSm,
  md: Shadows.raised,
  lg: Shadows.raisedLg,
};

interface RaisedCardProps {
  /** 浮起高度：sm 小入口 / md 标准卡（默认）/ lg 大卡或浮条 */
  elevation?: Elevation;
  /** 大圆角，默认 20（响应式缩放） */
  radius?: number;
  /** 传入则渲染为可按压卡片，带轻微下凹反馈 */
  onPress?: () => void;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
  contentStyle?: StyleProp<ViewStyle>;
  /** 是否用内壳裁剪内容（如顶部铺图）；阴影仍留在外层不会被切掉 */
  clip?: boolean;
}

/**
 * 全站统一的轻立体「白浮卡」（设计方向 C）。
 * 纯白硬块 + 极细收口边 + 柔和下沉阴影，浮在 Colors.screen.bg 浅灰页面底上。
 */
export default function RaisedCard({
  children,
  elevation = "md",
  radius = s(20),
  onPress,
  disabled = false,
  style,
  contentStyle,
  clip = false,
}: PropsWithChildren<RaisedCardProps>) {
  const cardBase: ViewStyle = {
    backgroundColor: Colors.screen.card,
    borderWidth: 1,
    borderColor: Colors.screen.hairline,
    borderRadius: radius,
    ...SHADOW[elevation],
  };

  const body = clip ? (
    <View style={[{ borderRadius: radius, overflow: "hidden", flex: 1 }, contentStyle]}>
      {children}
    </View>
  ) : (
    children
  );

  if (onPress) {
    return (
      <Pressable
        onPress={onPress}
        disabled={disabled}
        style={({ pressed }) => [
          cardBase,
          { transform: [{ scale: pressed ? 0.975 : 1 }] },
          style,
        ]}
      >
        {body}
      </Pressable>
    );
  }

  return <View style={[cardBase, style]}>{body}</View>;
}
