export function getLiveList() {
  return Promise.resolve({ data: { list: [] } });
}

export function getLivePlaybacks(_id: number) {
  return Promise.resolve({ data: { list: [] } });
}
