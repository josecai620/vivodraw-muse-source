import { memo, useEffect, useMemo, useRef, useState } from "react";
import {
  Image,
  Platform,
  StyleSheet,
  View,
  type ImageSourcePropType,
  type StyleProp,
  type ViewStyle,
} from "react-native";

export type SpriteSheetPlayerProps = {
  source: ImageSourcePropType;
  frameWidth?: number;
  frameHeight?: number;
  frames: number;
  fps?: number;
  loop?: boolean;
  paused?: boolean;
  displayScale?: number;
  sourceFrames?: number;
  startFrame?: number;
  style?: StyleProp<ViewStyle>;
  onComplete?: () => void;
};

function SpriteSheetPlayerComponent({
  source,
  frameWidth = 96,
  frameHeight = 96,
  frames,
  fps = 8,
  loop = true,
  paused = false,
  displayScale = 1,
  sourceFrames,
  startFrame = 0,
  style,
  onComplete,
}: SpriteSheetPlayerProps) {
  const [frameIndex, setFrameIndex] = useState(0);
  const rafRef = useRef<number | null>(null);
  const frameRef = useRef(0);
  const elapsedRef = useRef(0);
  const lastTimeRef = useRef<number | null>(null);
  const completedRef = useRef(false);
  const safeFrames = Math.max(1, Math.floor(frames));
  const safeSourceFrames = Math.max(safeFrames, Math.floor(sourceFrames ?? frames));
  const safeStartFrame = Math.min(Math.max(0, Math.floor(startFrame)), safeSourceFrames - safeFrames);
  const safeFps = Math.max(1, Math.min(12, fps));
  const safeDisplayScale = Math.max(1, Math.round(displayScale));
  const displayWidth = frameWidth * safeDisplayScale;
  const displayHeight = frameHeight * safeDisplayScale;

  useEffect(() => {
    frameRef.current = 0;
    elapsedRef.current = 0;
    lastTimeRef.current = null;
    completedRef.current = false;
    setFrameIndex(0);
  }, [source, safeFrames, safeFps, safeSourceFrames, safeStartFrame, loop]);

  useEffect(() => {
    if (paused || safeFrames <= 1) {
      return undefined;
    }

    const frameMs = 1000 / safeFps;

    function tick(time: number) {
      if (lastTimeRef.current === null) {
        lastTimeRef.current = time;
      }

      elapsedRef.current += time - lastTimeRef.current;
      lastTimeRef.current = time;

      if (elapsedRef.current >= frameMs) {
        elapsedRef.current %= frameMs;
        const next = frameRef.current + 1;

        if (next >= safeFrames) {
          if (loop) {
            frameRef.current = 0;
            setFrameIndex(0);
          } else {
            frameRef.current = safeFrames - 1;
            setFrameIndex(safeFrames - 1);
            if (!completedRef.current) {
              completedRef.current = true;
              onComplete?.();
            }
          }
        } else {
          frameRef.current = next;
          setFrameIndex(next);
        }
      }

      if (loop || frameRef.current < safeFrames - 1) {
        rafRef.current = requestAnimationFrame(tick);
      }
    }

    rafRef.current = requestAnimationFrame(tick);

    return () => {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    };
  }, [loop, onComplete, paused, safeFps, safeFrames]);

  const imageStyle = useMemo(
    () => [
      styles.sheet,
      {
        width: displayWidth * safeSourceFrames,
        height: displayHeight,
        transform: [{ translateX: -(safeStartFrame + frameIndex) * displayWidth }],
      },
      Platform.OS === "web" ? ({ imageRendering: "pixelated" } as never) : null,
    ],
    [displayHeight, displayWidth, frameIndex, safeSourceFrames, safeStartFrame],
  );

  if (Platform.OS === "web") {
    const resolvedUri =
      typeof source === "object" && source !== null && "uri" in source && typeof source.uri === "string" ? source.uri : undefined;

    if (!resolvedUri) {
      return (
        <View style={[styles.viewport, { width: displayWidth, height: displayHeight }, style]}>
          <Image accessibilityIgnoresInvertColors resizeMethod="resize" resizeMode="stretch" source={source} style={imageStyle} />
        </View>
      );
    }

    const webSheetStyle = [
      styles.webSheet,
      {
        width: displayWidth * safeSourceFrames,
        height: displayHeight,
        transform: [{ translateX: -(safeStartFrame + frameIndex) * displayWidth }],
        backgroundImage: `url("${resolvedUri}")`,
        backgroundSize: `${displayWidth * safeSourceFrames}px ${displayHeight}px`,
      },
    ] as StyleProp<ViewStyle>;

    return (
      <View style={[styles.viewport, { width: displayWidth, height: displayHeight }, style]}>
        <View pointerEvents="none" style={webSheetStyle} />
      </View>
    );
  }

  return (
    <View style={[styles.viewport, { width: displayWidth, height: displayHeight }, style]}>
      <Image accessibilityIgnoresInvertColors resizeMethod="resize" resizeMode="stretch" source={source} style={imageStyle} />
    </View>
  );
}

export const SpriteSheetPlayer = memo(SpriteSheetPlayerComponent);

const styles = StyleSheet.create({
  viewport: {
    overflow: "hidden",
  },
  sheet: {
    flexShrink: 0,
  },
  webSheet: {
    backgroundRepeat: "no-repeat",
    flexShrink: 0,
    imageRendering: "pixelated",
  } as ViewStyle,
});
