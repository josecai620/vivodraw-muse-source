import { API_ENDPOINTS } from "@/constants/api";
import { http } from "@/lib/http";

export type MessageTab = "all" | "credit" | "notice" | "news" | "feed" | "mail";

export interface MessageItem {
  id?: number;
  message_id?: number;
  title?: string;
  content?: string;
  mark?: string;
  tab?: MessageTab | string;
  is_read?: boolean | number | string;
  look?: boolean | number | string;
  read?: boolean | number | string;
  add_time?: string;
  create_time?: string;
}

export interface MessageListData {
  list?: MessageItem[];
  count?: number;
  service_num?: number;
}

export function getMessageList(params?: { page?: number; limit?: number; mark?: string }) {
  return http.get<MessageListData>(API_ENDPOINTS.user.messageSystem.list, { params });
}

export function getMessageDetail(id: number) {
  return http.get(API_ENDPOINTS.user.messageSystem.detail(id));
}

export function messageTabOf(item: MessageItem): MessageTab {
  const tab = String(item.tab ?? "");
  if (tab === "credit" || tab === "notice" || tab === "news" || tab === "feed" || tab === "mail") {
    return tab;
  }
  const mark = String(item.mark ?? "");
  if (mark === "member_daily" || mark === "shop_gift" || mark === "member_coupon") return "credit";
  if (mark === "news") return "news";
  if (mark === "notice") return "notice";
  if (mark === "feed") return "feed";
  return "mail";
}
