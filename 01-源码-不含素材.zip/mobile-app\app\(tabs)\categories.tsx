import { PageHeader, ProductCard } from "@/components/shared";
import LuxeIcon, { categorySketchGlyph } from "@/components/shared/LuxeIcon";
import { ProductCardSkeleton } from "@/components/ui/Skeleton";
import { Colors, s } from "@/constants/theme";
import { useAddToCart, useCategories, useProductList } from "@/hooks";
import type { Category, Product } from "@/lib/api/product";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import { useQueryClient } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  View,
  useWindowDimensions,
} from "react-native";

const PRODUCT_SKELETON_KEYS = [
  "category-product-skeleton-1",
  "category-product-skeleton-2",
  "category-product-skeleton-3",
  "category-product-skeleton-4",
];

function asRecord(value: unknown): Record<string, unknown> | null {
  return typeof value === "object" && value !== null ? (value as Record<string, unknown>) : null;
}

function readCategories(payload: unknown): Category[] {
  if (Array.isArray(payload)) return payload as Category[];
  const data = asRecord(payload)?.data;
  return Array.isArray(data) ? (data as Category[]) : [];
}

function readProducts(payload: unknown): Product[] {
  if (Array.isArray(payload)) return payload as Product[];

  const topLevel = asRecord(payload);
  const data = asRecord(topLevel?.data);
  const nestedList = data?.list;
  const topLevelList = topLevel?.list;

  if (Array.isArray(nestedList)) return nestedList as Product[];
  if (Array.isArray(topLevelList)) return topLevelList as Product[];
  return [];
}

function readCategoryId(value: unknown): number | null {
  const raw = Array.isArray(value) ? value[0] : value;
  const id = Number(raw);
  return Number.isInteger(id) && id > 0 ? id : null;
}

export default function CategoriesScreen() {
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const { width: windowWidth } = useWindowDimensions();
  const params = useLocalSearchParams<{ cid?: string | string[] }>();
  const isLoggedIn = useAuthStore((st) => st.isLoggedIn);
  const addToCart = useAddToCart();
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  const queryClient = useQueryClient();
  const columns = useAppStore((st) => st.categoryColumns);
  const cycleCategoryColumns = useAppStore((st) => st.cycleCategoryColumns);
  const compact = columns >= 3;
  const colWidth = `${100 / columns}%` as `${number}%`;
  const colPad = columns === 1 ? 0 : 4;
  const [refreshing, setRefreshing] = useState(false);
  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["categories"] }),
      queryClient.invalidateQueries({ queryKey: ["products"] }),
    ]);
    setRefreshing(false);
  };

  const sidebarWidth = s(92);
  const sidebarItemHeight = s(86);

  const { data: categoriesRaw, isLoading: catLoading } = useCategories();
  const categories = readCategories(categoriesRaw);
  const routeCategoryId = readCategoryId(params.cid);

  useEffect(() => {
    if (categories.length === 0) return;

    const routeCategory = routeCategoryId
      ? categories.find((category) => Number(category.id) === routeCategoryId)
      : null;
    const currentCategory = selectedCategoryId
      ? categories.find((category) => Number(category.id) === selectedCategoryId)
      : null;

    if (routeCategory && selectedCategoryId !== Number(routeCategory.id)) {
      setSelectedCategoryId(Number(routeCategory.id));
      return;
    }

    if (!currentCategory) {
      setSelectedCategoryId(Number(categories[0].id));
    }
  }, [categories, routeCategoryId, selectedCategoryId]);

  const { data: productsRaw, isLoading: prodLoading } = useProductList(
    {
      cid: selectedCategoryId ?? undefined,
      page: 1,
      limit: 20,
    },
    {
      enabled: selectedCategoryId !== null,
    },
  );
  const products = readProducts(productsRaw);

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader
        title={t("shopCategories.title")}
        showBack
        rightElement={
          <Pressable onPress={() => router.push("/search")}>
            <LuxeIcon glyph="search" tone="neutral" variant="soft" size={38} iconSize={23} />
          </Pressable>
        }
      />

      <View className="flex-1 flex-row">
        {/* Left Sidebar */}
        <View
          style={{
            width: sidebarWidth,
            backgroundColor: Colors.luxe.surface,
            borderRightWidth: 1,
            borderRightColor: Colors.luxe.hairline,
          }}
        >
          {catLoading ? (
            <View className="flex-1 items-center justify-center">
              <ActivityIndicator size="small" color={Colors.brand.red} />
            </View>
          ) : (
            <ScrollView showsVerticalScrollIndicator={false}>
              {categories.map((category, index) => {
                const isActive = selectedCategoryId === Number(category.id);
                const categoryName =
                  i18n.language.startsWith("en") && category.cate_name_en
                    ? category.cate_name_en
                    : t(`categories.${category.cate_name}`, { defaultValue: category.cate_name });
                const glyph = categorySketchGlyph(categoryName, index);
                return (
                  <Pressable
                    key={category.id}
                    onPress={() => {
                      if (isActive) {
                        cycleCategoryColumns(windowWidth);
                        return;
                      }
                      setSelectedCategoryId(Number(category.id));
                    }}
                    style={{ height: sidebarItemHeight }}
                    className="items-center justify-center"
                  >
                    {isActive && (
                      <View
                        className="absolute left-0 top-3 bottom-3 w-[3px] rounded-r-full"
                        style={{ backgroundColor: Colors.brand.red }}
                      />
                    )}
                    <LuxeIcon
                      glyph={glyph}
                      tone={isActive ? "brand" : "neutral"}
                      variant={isActive ? "badge" : "plain"}
                      active={isActive}
                      size={42}
                      iconSize={isActive ? 30 : 29}
                      color={isActive ? Colors.luxe.ink : Colors.neutral[600]}
                    />
                    <Text
                      style={{
                        marginTop: s(5),
                        paddingHorizontal: s(5),
                        fontSize: s(11),
                        lineHeight: s(14),
                        fontWeight: isActive ? "800" : "600",
                        color: isActive ? Colors.brand.red : Colors.neutral[500],
                        textAlign: "center",
                      }}
                      numberOfLines={2}
                    >
                      {categoryName}
                    </Text>
                  </Pressable>
                );
              })}
            </ScrollView>
          )}
        </View>

        {/* Right Content */}
        <View style={{ flexBasis: 0, flexGrow: 1, flexShrink: 1, width: 0, minWidth: 0, overflow: "hidden" }}>
          <ScrollView
            style={{ flexBasis: 0, flexGrow: 1, flexShrink: 1, width: "100%", minWidth: 0 }}
            contentContainerStyle={{ padding: s(8), paddingBottom: s(96), flexGrow: 1 }}
            showsVerticalScrollIndicator={false}
            bounces={false}
            overScrollMode="never"
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#04A8AE" />
            }
          >
            {prodLoading ? (
              <View className="flex-row flex-wrap">
                {PRODUCT_SKELETON_KEYS.map((key) => (
                  <View key={key} style={{ width: colWidth, paddingHorizontal: colPad, marginBottom: 8 }}>
                    <ProductCardSkeleton />
                  </View>
                ))}
              </View>
            ) : products.length === 0 ? (
              <View
                className="items-center justify-center py-12"
                style={{ alignSelf: "stretch", paddingHorizontal: s(12) }}
              >
                <Text
                  className="text-lg mb-2"
                  style={{ color: Colors.neutral[300], textAlign: "center", maxWidth: "100%" }}
                  numberOfLines={2}
                >
                  {t("shopCategories.noProducts")}
                </Text>
                <Text
                  className="text-sm"
                  style={{ color: Colors.neutral[400], textAlign: "center", maxWidth: "100%" }}
                  numberOfLines={2}
                >
                  {t("shopCategories.tryOtherCategory")}
                </Text>
              </View>
            ) : (
              <View className="flex-row flex-wrap">
                {products.map((item) => (
                  <View
                    key={item.id}
                    style={{ width: colWidth, paddingHorizontal: colPad, marginBottom: 8 }}
                  >
                    <ProductCard
                      id={item.id}
                      image={item.image}
                      name={item.store_name}
                      price={item.price}
                      originalPrice={item.ot_price}
                      sales={item.sales}
                      giveIntegral={Number(item.give_integral) || 0}
                      isHot={item.is_hot === 1}
                      isNew={item.is_new === 1}
                      layout="grid"
                      compact={compact}
                      onAddToCart={() => {
                        if (!isLoggedIn) {
                          router.push("/auth");
                          return;
                        }
                        addToCart.mutate({ productId: item.id, cartNum: 1, uniqueId: "" });
                      }}
                    />
                  </View>
                ))}
              </View>
            )}
            <View className="h-8" />
          </ScrollView>
        </View>
      </View>
    </View>
  );
}
