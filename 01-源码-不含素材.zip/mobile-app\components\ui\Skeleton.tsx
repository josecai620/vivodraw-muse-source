import React, { useEffect } from "react";
import { View } from "react-native";
import { Colors, Shadows, s } from "@/constants/theme";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
} from "react-native-reanimated";

interface SkeletonProps {
  width?: number | string;
  height?: number;
  borderRadius?: number;
  className?: string;
}

export default function Skeleton({
  width = "100%",
  height = 16,
  borderRadius = 8,
  className = "",
}: SkeletonProps) {
  const opacity = useSharedValue(0.3);

  useEffect(() => {
    opacity.value = withRepeat(withTiming(0.7, { duration: 800 }), -1, true);
  }, [opacity]);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));

  return (
    <Animated.View
      style={[
        {
          width: typeof width === "number" ? width : undefined,
          height,
          borderRadius,
          backgroundColor: "#EDF0F0",
        },
        animatedStyle,
      ]}
      className={`${typeof width === "string" ? "w-full" : ""} ${className}`}
    />
  );
}

export function ProductCardSkeleton() {
  return (
    <View
      className="overflow-hidden p-3"
      style={{
        backgroundColor: Colors.screen.card,
        borderRadius: s(18),
        borderWidth: 1,
        borderColor: Colors.screen.hairline,
        ...Shadows.raisedSm,
      }}
    >
      <Skeleton height={180} borderRadius={12} />
      <View className="mt-3 gap-2">
        <Skeleton height={14} width="80%" />
        <Skeleton height={12} width="50%" />
        <View className="flex-row justify-between items-center mt-1">
          <Skeleton height={20} width={60} />
          <Skeleton height={32} width={32} borderRadius={16} />
        </View>
      </View>
    </View>
  );
}

export function ListItemSkeleton() {
  return (
    <View className="flex-row items-center p-4 gap-3">
      <Skeleton width={48} height={48} borderRadius={24} />
      <View className="flex-1 gap-2">
        <Skeleton height={14} width="60%" />
        <Skeleton height={12} width="40%" />
      </View>
    </View>
  );
}
