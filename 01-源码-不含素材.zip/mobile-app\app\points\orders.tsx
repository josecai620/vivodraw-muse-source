import { PageHeader } from "@/components/shared";
import { NextStepGuide } from "@/components/onboarding/PlayGuides";
import { USE_DEV_MOCK_DATA } from "@/constants/env";
import { TealGradient, Colors, s } from "@/constants/theme";
import { useDeleteIntegralOrder, usePointsOrderList } from "@/hooks";
import { unwrapApiListField } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import {
  CheckCircle,
  ChevronRight,
  Clock,
  Package,
  Trash2,
  Trophy,
  XCircle,
} from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Alert, Image, Pressable, RefreshControl, ScrollView, Text, View } from "react-native";

type OrderStatus = "processing" | "shipping" | "delivered" | "cancelled";
type TabId = "all" | OrderStatus;

type Order = {
  id: string;
  date: string;
  status: OrderStatus;
  points: number;
  product: { name: string; image: string };
};

type ApiOrderProduct = {
  store_name?: unknown;
  image?: unknown;
};

type ApiOrderCartItem = {
  productInfo?: ApiOrderProduct;
};

type ApiPointsOrder = {
  id?: unknown;
  order_id?: unknown;
  add_time?: unknown;
  _add_time?: unknown;
  status?: unknown;
  _status?: unknown;
  total_price?: unknown;
  pay_price?: unknown;
  store_name?: unknown;
  image?: unknown;
  cartInfo?: ApiOrderCartItem[];
};

type StatusConfig = {
  icon: typeof Clock;
  text: string;
  color: string;
  bgClass: string;
};

const MOCK_ORDERS: Order[] = [
  {
    id: "PTS-2024-001",
    date: "2024-03-05",
    status: "delivered",
    points: 5000,
    product: {
      name: "Wireless Headphones",
      image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200",
    },
  },
  {
    id: "PTS-2024-002",
    date: "2024-03-04",
    status: "shipping",
    points: 3000,
    product: {
      name: "Smart Watch",
      image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200",
    },
  },
  {
    id: "PTS-2024-003",
    date: "2024-03-03",
    status: "processing",
    points: 2000,
    product: {
      name: "Bluetooth Speaker",
      image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=200",
    },
  },
  {
    id: "PTS-2024-004",
    date: "2024-03-01",
    status: "cancelled",
    points: 1500,
    product: {
      name: "Phone Holder",
      image: "https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?w=200",
    },
  },
];

const TAB_TYPE_MAP: Record<TabId, number> = {
  all: -1,
  processing: 0,
  shipping: 1,
  delivered: 2,
  cancelled: -1,
};

function toText(value: unknown, fallback = "") {
  if (value == null) return fallback;
  return String(value);
}

function firstProduct(order: ApiPointsOrder): ApiOrderProduct {
  if (!Array.isArray(order.cartInfo)) return {};
  return order.cartInfo[0]?.productInfo ?? {};
}

function mapOrderStatus(order: ApiPointsOrder): OrderStatus {
  const status = Number(order.status ?? order._status ?? -1);
  if (status === 0) return "processing";
  if (status === 1) return "shipping";
  if (status === 2 || status === 3) return "delivered";
  if (status === -1 || status === -2) return "cancelled";
  return "processing";
}

function buildOrder(order: ApiPointsOrder, fallbackProductName: string): Order {
  const product = firstProduct(order);
  return {
    id: toText(order.order_id ?? order.id),
    date: toText(order.add_time ?? order._add_time),
    status: mapOrderStatus(order),
    points: Number(order.total_price ?? order.pay_price ?? 0),
    product: {
      name: toText(order.store_name ?? product.store_name, fallbackProductName),
      image: normalizeImageUrl(toText(order.image ?? product.image)),
    },
  };
}

function getTabCount(tabId: TabId, orders: Order[]) {
  if (tabId === "all") return orders.length;
  return orders.filter((order) => order.status === tabId).length;
}

function formatOrderDate(date: string) {
  const parsed = new Date(date);
  if (Number.isNaN(parsed.getTime())) return date || "-";
  return parsed.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

export default function PointsOrdersScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<TabId>("all");
  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);
  const deleteOrder = useDeleteIntegralOrder();

  const statusConfig = useMemo<Record<OrderStatus, StatusConfig>>(
    () => ({
      processing: {
        icon: Clock,
        text: t("pointsOrders.status.processing"),
        color: "#04A8AE",
        bgClass: "bg-neutral-50",
      },
      shipping: {
        icon: Package,
        text: t("pointsOrders.status.shipping"),
        color: Colors.brand.red,
        bgClass: "bg-brand-red-light",
      },
      delivered: {
        icon: CheckCircle,
        text: t("pointsOrders.status.delivered"),
        color: "#04A8AE",
        bgClass: "bg-teal-50",
      },
      cancelled: {
        icon: XCircle,
        text: t("pointsOrders.status.cancelled"),
        color: "#FF3B30",
        bgClass: "bg-brand-red-light",
      },
    }),
    [t],
  );

  const tabs = useMemo<Array<{ id: TabId; label: string }>>(
    () => [
      { id: "all", label: t("pointsOrders.tabs.all") },
      { id: "processing", label: t("pointsOrders.tabs.processing") },
      { id: "shipping", label: t("pointsOrders.tabs.shipping") },
      { id: "delivered", label: t("pointsOrders.tabs.delivered") },
    ],
    [t],
  );

  const { data: ordersData } = usePointsOrderList(TAB_TYPE_MAP[activeTab] ?? -1);
  const apiOrders = unwrapApiListField<ApiPointsOrder>(ordersData).map((order) =>
    buildOrder(order, t("pointsMall.pointsProduct")),
  );
  const displayOrders = apiOrders.length > 0 ? apiOrders : USE_DEV_MOCK_DATA ? MOCK_ORDERS : [];
  const filteredOrders =
    activeTab === "all"
      ? displayOrders
      : displayOrders.filter((order) => order.status === activeTab);

  const totalPointsUsed = filteredOrders.reduce((sum, order) => sum + order.points, 0);
  const deliveredCount = filteredOrders.filter((order) => order.status === "delivered").length;
  const inProgressCount = filteredOrders.filter(
    (order) => order.status === "processing" || order.status === "shipping",
  ).length;

  const onRefresh = async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries();
    setRefreshing(false);
  };

  const handleDelete = (orderId: string) => {
    Alert.alert(t("pointsOrders.deleteOrder"), t("pointsOrders.deleteOrderMessage"), [
      { text: t("common.cancel"), style: "cancel" },
      {
        text: t("pointsOrders.delete"),
        style: "destructive",
        onPress: () => deleteOrder.mutate(orderId),
      },
    ]);
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("pointsOrders.title")} />

      <LinearGradient
        colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }}
      >
          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
        <View className="flex-row border-b border-white/20">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            const count = getTabCount(tab.id, displayOrders);
            return (
              <Pressable
                key={tab.id}
                className="flex-1 py-3 items-center relative"
                onPress={() => setActiveTab(tab.id)}
              >
                <View className="flex-row items-center">
                  <Text
                    className={`text-sm font-medium ${isActive ? "text-white" : "text-white/60"}`}
                  >
                    {tab.label}
                  </Text>
                  {count > 0 && (
                    <View
                      className="ml-1 px-1.5 py-0.5 rounded-full"
                      style={{
                        backgroundColor: isActive ? "#ffffff" : "rgba(255,255,255,0.2)",
                      }}
                    >
                      <Text
                        className="text-xs font-medium"
                        style={{ color: isActive ? Colors.brand.red : "#ffffff" }}
                      >
                        {count}
                      </Text>
                    </View>
                  )}
                </View>
                {isActive && <View className="absolute bottom-0 left-0 right-0 h-0.5 bg-white" />}
              </Pressable>
            );
          })}
        </View>
      </LinearGradient>

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#04A8AE" />
        }
      >
        <View className="bg-brand-red mx-4 mt-4 rounded-2xl p-5">
          <View className="flex-row">
            <View className="flex-1 items-center">
              <Text className="text-2xl font-bold text-white">{deliveredCount}</Text>
              <Text className="text-xs text-white/70 mt-1">
                {t("pointsOrders.status.delivered")}
              </Text>
            </View>
            <View className="flex-1 items-center border-l border-r border-white/20">
              <Text className="text-2xl font-bold" style={{ color: "#FFFFFF" }}>
                {totalPointsUsed.toLocaleString()}
              </Text>
              <Text className="text-xs text-white/70 mt-1">
                {t("pointsOrders.totalPointsUsed")}
              </Text>
            </View>
            <View className="flex-1 items-center">
              <Text className="text-2xl font-bold text-white">{inProgressCount}</Text>
              <Text className="text-xs text-white/70 mt-1">{t("pointsOrders.inProgress")}</Text>
            </View>
          </View>
        </View>

        <NextStepGuide kind="pointsOrders" />

        {filteredOrders.length === 0 ? (
          <View className="items-center justify-center px-4 py-20">
            <View className="w-32 h-32 bg-gray-100 rounded-full items-center justify-center mb-4">
              <Trophy size={48} color={Colors.neutral[300]} />
            </View>
            <Text className="text-xl font-bold text-gray-900 mb-2">
              {t("pointsOrders.noOrders")}
            </Text>
            <Text className="text-sm text-gray-500 text-center mb-6">
              {t("pointsOrders.noOrdersDesc")}
            </Text>
            <LinearGradient
              colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
              start={{ x: 1, y: 0.5 }}
              end={{ x: 0, y: 0.5 }}
              style={{ borderRadius: 12, overflow: "hidden" }}
            >
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
              <Pressable
                className="px-6 h-11 items-center justify-center"
                onPress={() => router.push("/(tabs)/points")}
              >
                <Text className="text-white font-semibold">
                  {t("pointsOrders.browsePointsMall")}
                </Text>
              </Pressable>
            </LinearGradient>
          </View>
        ) : (
          <View className="px-4 py-4 gap-3">
            {filteredOrders.map((order) => {
              const config = statusConfig[order.status];
              const StatusIcon = config.icon;

              return (
                <View
                  key={order.id}
                  className="bg-white rounded-2xl overflow-hidden border border-gray-100"
                >
                  <View
                    className="p-4 border-b border-gray-100"
                    style={{ backgroundColor: `${Colors.brand.red}05` }}
                  >
                    <View className="flex-row items-center justify-between mb-2">
                      <View className="flex-row items-center gap-2">
                        <Text className="font-semibold text-sm text-gray-900">{order.id}</Text>
                        <View
                          className={`flex-row items-center gap-1 px-2 py-1 rounded-full ${config.bgClass}`}
                        >
                          <StatusIcon size={12} color={config.color} />
                          <Text className="text-xs font-medium" style={{ color: config.color }}>
                            {config.text}
                          </Text>
                        </View>
                      </View>
                    </View>
                    <Text className="text-xs text-gray-500">{formatOrderDate(order.date)}</Text>
                  </View>

                  <View className="p-4">
                    <View className="flex-row gap-3 mb-3">
                      <View className="w-20 h-20 bg-gray-100 rounded-xl overflow-hidden">
                        <Image
                          source={{ uri: order.product.image }}
                          className="w-full h-full"
                          resizeMode="cover"
                        />
                      </View>
                      <View className="flex-1">
                        <Text className="text-sm font-medium text-gray-900 mb-2" numberOfLines={2}>
                          {order.product.name}
                        </Text>
                        <View className="flex-row items-center gap-1">
                          <Trophy size={s(14)} color={Colors.brand.red} />
                          <Text
                            className="text-base font-bold"
                            style={{ color: Colors.brand.redDark }}
                          >
                            {order.points}
                          </Text>
                          <Text className="text-xs text-gray-500">{t("pointsOrders.points")}</Text>
                        </View>
                      </View>
                    </View>

                    <View className="flex-row gap-2">
                      <Pressable
                        className="flex-1 flex-row items-center justify-center gap-1 h-9 rounded-lg"
                        style={{ backgroundColor: `${Colors.brand.red}10` }}
                        onPress={() =>
                          router.push({
                            pathname: "/points/order-detail",
                            params: { id: order.id },
                          })
                        }
                      >
                        <Text className="font-semibold text-sm" style={{ color: Colors.brand.red }}>
                          {t("pointsOrders.viewDetails")}
                        </Text>
                        <ChevronRight size={16} color={Colors.brand.red} />
                      </Pressable>
                      {(order.status === "delivered" || order.status === "cancelled") && (
                        <Pressable
                          className="h-9 w-9 rounded-lg items-center justify-center border border-gray-200"
                          onPress={() => handleDelete(order.id)}
                        >
                          <Trash2 size={16} color={Colors.neutral[400]} />
                        </Pressable>
                      )}
                    </View>
                  </View>

                  {order.status === "delivered" && (
                    <View className="px-4 pb-4 flex-row gap-2">
                      <Pressable
                        className="flex-1 h-9 border border-gray-300 rounded-lg items-center justify-center"
                        onPress={() => router.push("/(tabs)/points")}
                      >
                        <Text className="font-medium text-sm text-gray-700">
                          {t("pointsOrders.redeemAgain")}
                        </Text>
                      </Pressable>
                      <Pressable
                        className="flex-1 h-9 border border-gray-300 rounded-lg items-center justify-center"
                        onPress={() => router.push("/points/reviews")}
                      >
                        <Text className="font-medium text-sm text-gray-700">
                          {t("pointsOrders.leaveReview")}
                        </Text>
                      </Pressable>
                    </View>
                  )}

                  {order.status === "shipping" && (
                    <View className="px-4 pb-4">
                      <LinearGradient
                        colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                        start={{ x: 0, y: 0.5 }}
                        end={{ x: 1, y: 0.5 }}
                        style={{ borderRadius: 8, overflow: "hidden" }}
                      >
                          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                        <Pressable
                          className="w-full h-9 items-center justify-center"
                          onPress={() =>
                            router.push({
                              pathname: "/points/tracking",
                              params: { id: order.id },
                            })
                          }
                        >
                          <Text className="text-white font-semibold text-sm">
                            {t("pointsOrders.trackOrder")}
                          </Text>
                        </Pressable>
                      </LinearGradient>
                    </View>
                  )}
                </View>
              );
            })}
          </View>
        )}

        <View className="h-8" />
      </ScrollView>
    </View>
  );
}
