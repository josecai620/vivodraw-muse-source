import { PageHeader, PriceDisplay } from "@/components/shared";
import { Colors, s, Shadows } from "@/constants/theme";
import TealSurface from "@/components/ui/TealSurface";
import { useCartList } from "@/hooks";
import { getDefaultAddress } from "@/lib/api/address";
import type { Address } from "@/lib/api/address";
import type { CartItem } from "@/lib/api/cart";
import { confirmOrder, createOrder } from "@/lib/api/order";
import type { OrderConfirmData } from "@/lib/api/order";
import { isApiRecord, unwrapApiData } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Check, ChevronRight, MapPin, Shield, Tag, Truck } from "lucide-react-native";
import React, { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

function getErrorMessage(error: unknown, fallback: string): string {
  return error instanceof Error ? error.message : fallback;
}

function normalizeDefaultAddress(value: unknown): Address | null {
  const data = unwrapApiData<unknown>(value, null);
  if (!data || Array.isArray(data) || typeof data !== "object") return null;
  const address = data as Address;
  return address.id ? address : null;
}

/**
 * 立即购买（is_new=1）时后端 confirm 返回的 cartInfo 并非购物车表记录，
 * 这里归一化成结算页展示用的 CartItem 形状。
 */
function normalizeDirectBuyItems(cartInfo: unknown): CartItem[] {
  if (!Array.isArray(cartInfo)) return [];
  return cartInfo.map((raw, index) => {
    const item = (isApiRecord(raw) ? raw : {}) as Record<string, unknown>;
    const productInfo = (isApiRecord(item.productInfo) ? item.productInfo : {}) as Record<string, unknown>;
    const attrInfo = (
      isApiRecord(item.attrInfo)
        ? item.attrInfo
        : isApiRecord(productInfo.attrInfo)
          ? productInfo.attrInfo
          : {}
    ) as Record<string, unknown>;
    const price = String(attrInfo.price ?? productInfo.price ?? "0");
    const image = String(attrInfo.image ?? productInfo.image ?? "");
    return {
      id: Number(item.id) || index + 1,
      product_id: Number(item.product_id ?? productInfo.id) || 0,
      product_attr_unique: String(item.product_attr_unique ?? attrInfo.unique ?? ""),
      cart_num: Number(item.cart_num) || 1,
      productInfo: {
        id: Number(productInfo.id) || 0,
        image,
        store_name: String(productInfo.store_name ?? "Product"),
        price,
        ot_price: String(productInfo.ot_price ?? "0"),
        attrInfo: {
          suk: String(attrInfo.suk ?? ""),
          image,
          price,
        },
      },
      is_pay: 0,
      is_del: 0,
      is_new: 1,
      status: 1,
    } as CartItem;
  });
}

export default function CheckoutScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { cartId, new: newParam } = useLocalSearchParams<{ cartId?: string; new?: string }>();
  /** 立即购买直达结算：new=1，cartId 为后端直接下单缓存 key，而非购物车 id */
  const isDirectBuy = newParam === "1" || newParam === "true";
  const isLoggedIn = useAuthStore((st) => st.isLoggedIn);
  const showToast = useAppStore((s) => s.showToast);
  const queryClient = useQueryClient();

  const { data: addressRaw } = useQuery({
    queryKey: ["defaultAddress"],
    queryFn: getDefaultAddress,
    enabled: isLoggedIn,
  });
  const address = normalizeDefaultAddress(addressRaw);

  const [promoCode, setPromoCode] = useState("");
  const [payType, setPayType] = useState<"yue" | "offline">("offline");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: cartRaw, isLoading: isCartLoading } = useCartList();
  const cartData = cartRaw ?? { valid: [] };
  const allValid = cartData.valid;
  const validItems = isDirectBuy
    ? []
    : cartId
      ? allValid.filter((item) => String(item.id) === cartId)
      : allValid;

  // 立即购买：先 confirm 预览，拿到商品信息用于渲染（购物车表里没有这条记录）
  const directBuyQuery = useQuery({
    queryKey: ["directBuyOrder", cartId, address?.id ?? 0],
    queryFn: () =>
      confirmOrder({ cartId: String(cartId), new: true, addressId: address?.id ?? 0 }),
    enabled: isLoggedIn && isDirectBuy && !!cartId,
    retry: false,
  });
  const directBuyData = unwrapApiData<OrderConfirmData | null>(directBuyQuery.data ?? null, null);
  const directItems = useMemo(
    () => normalizeDirectBuyItems(directBuyData?.cartInfo),
    [directBuyData],
  );

  const displayItems: CartItem[] = isDirectBuy
    ? directItems
    : validItems.length > 0
      ? validItems
      : [];
  const isLoading = isDirectBuy ? directBuyQuery.isLoading : isCartLoading;

  useEffect(() => {
    if (!isLoggedIn) {
      showToast("Please sign in to checkout", "info");
      router.replace("/auth");
    }
  }, [isLoggedIn, router, showToast]);

  if (!isLoggedIn) {
    return null;
  }

  if (isLoading) {
    return (
      <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
        <PageHeader title="Checkout" />
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      </View>
    );
  }

  if (displayItems.length === 0) {
    return (
      <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
        <PageHeader title="Checkout" />
        <View className="flex-1 items-center justify-center px-6">
          <Text className="text-lg font-semibold mb-2" style={{ color: Colors.neutral[900] }}>
            Cart is empty
          </Text>
          <Text className="text-sm text-center mb-6" style={{ color: Colors.neutral[500] }}>
            {isDirectBuy
              ? "This purchase session has expired, please go back and try again"
              : cartId
                ? "This item is no longer available for checkout"
                : "Add items to your cart before checkout"}
          </Text>
          <Pressable
            onPress={() => router.replace("/(tabs)/cart")}
            style={({ pressed }) => [Shadows.teal, { transform: [{ scale: pressed ? 0.97 : 1 }] }]}
          >
            <TealSurface direction="rl" radius={12} style={{ alignSelf: "center" }} contentStyle={{ height: 44, paddingHorizontal: 24, alignItems: "center", justifyContent: "center" }}>
              <Text className="text-white font-semibold" style={{ backgroundColor: "transparent" }}>Back to Cart</Text>
            </TealSurface>
          </Pressable>
        </View>
      </View>
    );
  }

  const subtotal = displayItems.reduce((sum, item) => {
    const price = Number(item.productInfo?.attrInfo?.price ?? item.productInfo?.price ?? 0);
    return sum + price * (item.cart_num ?? 1);
  }, 0);
  const shipping = 0;
  const total = subtotal + shipping;

  const handlePlaceOrder = async () => {
    if (isSubmitting) return;
    if (!address) {
      showToast("Please select a shipping address", "error");
      return;
    }
    if (displayItems.length === 0) {
      showToast("Your cart is empty", "error");
      return;
    }
    const cartIds = cartId ? cartId : validItems.map((item) => item.id).join(",");
    if (!cartIds) {
      showToast("No checkout items selected", "error");
      return;
    }

    setIsSubmitting(true);
    try {
      // new=false 走购物车表 id；new=true 走立即购买缓存 key。
      // 此前写死 new:true，导致购物车结算时后端按缓存 key 找不到商品而失败。
      const confirmRes = await confirmOrder({
        cartId: cartIds,
        new: isDirectBuy,
        addressId: address?.id ?? 0,
      });
      const confirmData = unwrapApiData<OrderConfirmData | null>(confirmRes, null);
      const orderKey = confirmData?.orderKey;
      if (!orderKey) {
        showToast("Order confirm failed", "error");
        return;
      }
      await createOrder(orderKey, {
        addressId: address?.id ?? 0,
        payType,
      });
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["cart"] }),
        queryClient.invalidateQueries({ queryKey: ["cartCount"] }),
        queryClient.invalidateQueries({ queryKey: ["orderList"] }),
      ]);
      showToast("Order placed successfully!", "success");
      router.replace("/orders");
    } catch (err: unknown) {
      showToast(getErrorMessage(err, "Failed to place order"), "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleApplyPromo = () => {
    if (!promoCode.trim()) {
      showToast("Enter a promo code first", "info");
      return;
    }
    showToast("Promo codes are not connected yet", "info");
  };

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title="Checkout" />

      {/* Progress */}
      <View
        className="px-4 py-4 border-b"
        style={{ backgroundColor: Colors.neutral[0], borderBottomColor: Colors.neutral[200] }}
      >
        <View className="flex-row items-center justify-between">
          {["Cart", "Checkout", "Payment"].map((step, i) => (
            <View key={step} className="items-center">
              <View
                className="w-8 h-8 rounded-full items-center justify-center"
                style={{ backgroundColor: i <= 1 ? Colors.brand.red : Colors.neutral[200] }}
              >
                {i < 1 ? (
                  <Check size={15} color={Colors.neutral[0]} strokeWidth={2.6} />
                ) : (
                  <Text
                    className="text-xs font-bold"
                    style={{ color: i <= 1 ? Colors.neutral[0] : Colors.neutral[500] }}
                  >
                    {i + 1}
                  </Text>
                )}
              </View>
              <Text className="text-xs mt-1.5 font-medium" style={{ color: Colors.neutral[600] }}>
                {step}
              </Text>
            </View>
          ))}
        </View>
      </View>

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Address */}
        <Pressable
          className="mx-4 mt-4 rounded-2xl p-4 flex-row items-center gap-3"
          style={[
            {
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: Colors.screen.hairline,
            },
            Shadows.raisedSm,
          ]}
          onPress={() => router.push("/profile/address")}
        >
          <View
            className="w-10 h-10 rounded-xl items-center justify-center"
            style={{ backgroundColor: `${Colors.brand.red}15` }}
          >
            <MapPin size={s(20)} color={Colors.brand.red} />
          </View>
          <View className="flex-1">
            {address ? (
              <>
                <Text className="text-sm font-semibold" style={{ color: Colors.neutral[900] }}>
                  {address.real_name} {address.phone}
                </Text>
                <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }}>
                  {[address.province, address.city, address.district, address.detail]
                    .filter(Boolean)
                    .join(" ")}
                </Text>
              </>
            ) : (
              <Text className="text-sm font-semibold" style={{ color: Colors.neutral[900] }}>
                Select shipping address
              </Text>
            )}
          </View>
          <ChevronRight size={s(18)} color={Colors.neutral[400]} />
        </Pressable>

        {/* Items */}
        <View
          className="mx-4 mt-4 rounded-2xl overflow-hidden"
          style={[
            {
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: Colors.screen.hairline,
            },
            Shadows.raisedSm,
          ]}
        >
          <View className="px-4 py-3 border-b" style={{ borderBottomColor: Colors.neutral[100] }}>
            <Text className="text-sm font-semibold" style={{ color: Colors.neutral[900] }}>
              Order Items ({displayItems.length})
            </Text>
          </View>
          {displayItems.map((item, i) => {
            const info = item.productInfo ?? {};
            const img = info.attrInfo?.image ?? info.image ?? "";
            const name = info.store_name ?? "Product";
            const price = Number(info.attrInfo?.price ?? info.price ?? 0);
            const qty = item.cart_num ?? 1;
            return (
              <View
                key={item.id}
                className={`px-4 py-3 flex-row items-center gap-3 ${i > 0 ? "border-t" : ""}`}
                style={i > 0 ? { borderTopColor: Colors.neutral[50] } : undefined}
              >
                <Image
                  source={{ uri: normalizeImageUrl(img) }}
                  className="w-14 h-14 rounded-xl bg-gray-100"
                  resizeMode="cover"
                />
                <View className="flex-1">
                  <Text
                    className="text-sm font-medium"
                    style={{ color: Colors.neutral[900] }}
                    numberOfLines={1}
                  >
                    {name}
                  </Text>
                  <Text className="text-xs" style={{ color: Colors.neutral[500] }}>
                    Qty: {qty}
                  </Text>
                </View>
                <PriceDisplay price={price * qty} size="sm" showDiscount={false} />
              </View>
            );
          })}
        </View>

        {/* Shipping */}
        <View
          className="mx-4 mt-4 rounded-2xl p-4 flex-row items-center gap-3"
          style={[
            {
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: Colors.screen.hairline,
            },
            Shadows.raisedSm,
          ]}
        >
          <View
            className="w-10 h-10 rounded-xl items-center justify-center"
            style={{ backgroundColor: `${Colors.ios.green}15` }}
          >
            <Truck size={s(20)} color={Colors.ios.green} />
          </View>
          <View className="flex-1">
            <Text className="text-sm font-semibold" style={{ color: Colors.neutral[900] }}>
              Free Shipping
            </Text>
            <Text className="text-xs mt-0.5" style={{ color: Colors.neutral[500] }}>
              Estimated delivery: 3-5 business days
            </Text>
          </View>
          <Text className="text-sm font-bold" style={{ color: Colors.success }}>
            FREE
          </Text>
        </View>

        {/* Promo */}
        <View
          className="mx-4 mt-4 rounded-2xl p-4"
          style={[
            {
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: Colors.screen.hairline,
            },
            Shadows.raisedSm,
          ]}
        >
          <View className="flex-row items-center gap-3 mb-3">
            <View
              className="w-10 h-10 rounded-xl items-center justify-center"
              style={{ backgroundColor: `${Colors.brand.red}15` }}
            >
              <Tag size={s(20)} color={Colors.brand.red} />
            </View>
            <Text className="text-sm font-semibold" style={{ color: Colors.neutral[900] }}>
              Promo Code
            </Text>
          </View>
          <View className="flex-row items-center gap-2">
            <TextInput
              className="flex-1 h-10 px-3 rounded-lg text-sm"
              style={{
                backgroundColor: Colors.neutral[50],
                borderWidth: 1,
                borderColor: Colors.neutral[200],
                color: Colors.neutral[900],
              }}
              placeholder="Enter promo code"
              placeholderTextColor={Colors.neutral[400]}
              value={promoCode}
              onChangeText={setPromoCode}
            />
            <Pressable
              onPress={handleApplyPromo}
              style={({ pressed }) => [Shadows.teal, { transform: [{ scale: pressed ? 0.96 : 1 }] }]}
            >
              <TealSurface direction="tb" radius={8} style={{ alignSelf: "center" }} contentStyle={{ height: 40, paddingHorizontal: 16, alignItems: "center", justifyContent: "center" }}>
                <Text className="text-white text-sm font-semibold" style={{ backgroundColor: "transparent" }}>Apply</Text>
              </TealSurface>
            </Pressable>
          </View>
        </View>

        {/* Payment */}
        <View
          className="mx-4 mt-4 rounded-2xl overflow-hidden"
          style={[
            {
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: Colors.screen.hairline,
            },
            Shadows.raisedSm,
          ]}
        >
          <View className="px-4 py-3 border-b" style={{ borderBottomColor: Colors.neutral[100] }}>
            <Text className="text-sm font-semibold" style={{ color: Colors.neutral[900] }}>
              Payment Method
            </Text>
          </View>
          {(["offline", "yue"] as const).map((pt, idx) => {
            const selected = payType === pt;
            const label = pt === "offline" ? t("cart.payOnDelivery") : t("cart.payWithBalance");
            return (
              <Pressable
                key={pt}
                onPress={() => setPayType(pt)}
                className={`px-4 py-3 flex-row items-center gap-3 ${idx > 0 ? "border-t" : ""}`}
                style={idx > 0 ? { borderTopColor: Colors.neutral[100] } : undefined}
              >
                <View
                  className="w-5 h-5 rounded-full border-2 items-center justify-center"
                  style={{ borderColor: selected ? Colors.brand.red : Colors.neutral[300] }}
                >
                  {selected && (
                    <View
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: Colors.brand.red }}
                    />
                  )}
                </View>
                <Text className="flex-1 text-sm font-medium" style={{ color: Colors.neutral[900] }}>
                  {label}
                </Text>
              </Pressable>
            );
          })}
        </View>

        {/* Summary */}
        <View
          className="mx-4 mt-4 mb-4 rounded-2xl p-4"
          style={[
            {
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: Colors.screen.hairline,
            },
            Shadows.raisedSm,
          ]}
        >
          <Text className="text-sm font-semibold mb-3" style={{ color: Colors.neutral[900] }}>
            Order Summary
          </Text>
          <View className="flex-row justify-between py-1.5">
            <Text className="text-sm" style={{ color: Colors.neutral[600] }}>
              Subtotal
            </Text>
            <Text className="text-sm font-medium" style={{ color: Colors.neutral[900] }}>
              ${subtotal.toFixed(2)}
            </Text>
          </View>
          <View className="flex-row justify-between py-1.5">
            <Text className="text-sm" style={{ color: Colors.neutral[600] }}>
              Shipping
            </Text>
            <Text className="text-sm font-medium" style={{ color: Colors.success }}>
              Free
            </Text>
          </View>
          <View
            className="flex-row justify-between pt-3 mt-3 border-t"
            style={{ borderTopColor: Colors.neutral[200] }}
          >
            <Text className="text-base font-bold" style={{ color: Colors.neutral[900] }}>
              Total
            </Text>
            <PriceDisplay price={total} size="lg" showDiscount={false} />
          </View>
        </View>

        <View className="h-28" />
      </ScrollView>

      {/* Bottom */}
      <View
        className="absolute bottom-0 left-0 right-0 px-4 py-3"
        style={{
          backgroundColor: "#FFFFFF",
          borderTopWidth: 1,
          borderTopColor: Colors.screen.hairline,
          paddingBottom: insets.bottom + 12,
          shadowColor: "#0C1F1F",
          shadowOffset: { width: 0, height: -6 },
          shadowOpacity: 0.06,
          shadowRadius: 16,
          elevation: 12,
        }}
      >
        <View className="flex-row items-center justify-between mb-3">
          <Text className="text-sm" style={{ color: Colors.neutral[600] }}>
            Total
          </Text>
          <PriceDisplay price={total} size="lg" showDiscount={false} />
        </View>
        <Pressable
          onPress={handlePlaceOrder}
          disabled={isSubmitting}
          style={({ pressed }) => [Shadows.teal, { opacity: isSubmitting ? 0.7 : 1, transform: [{ scale: pressed ? 0.97 : 1 }] }]}
        >
          <TealSurface direction="lr" radius={12} style={{ height: 48, width: "100%" }} contentStyle={{ height: 48, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <Shield size={s(18)} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
            <Text className="text-white font-semibold" style={{ backgroundColor: "transparent" }}>
              {isSubmitting ? "Placing Order..." : "Place Order"}
            </Text>
          </TealSurface>
        </Pressable>
      </View>
    </View>
  );
}
