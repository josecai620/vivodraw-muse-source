import { useCallback, useEffect, useRef, useState } from "react";
import { useAuthStore } from "@/store/auth";
import { exchangeGameWallet, getGameWalletState, type GameExchangeDirection, type GameExchangeReceipt, type GameWalletGame, type GameWalletState } from "@/lib/api/gameWallet";
import { clearPendingGameExchange, isConfirmedRejection, newGameExchangeId, quoteGameExchange, readPendingGameExchange, receiptConfirmsGameExchange, savePendingGameExchange, type PendingGameExchange } from "@/lib/game/gameWalletRecovery";

// 与通用HTTP层使用同一凭证优先级；凭证只用于请求归属检查，不写入恢复记录。
function currentToken() {
  try {
    return useAuthStore.getState().token ?? "";
  } catch { return ""; }
}
const loginStatus = (status?: number) => [401, 410000, 410001, 410002].includes(status ?? 0);

export function useGameSupply(game: GameWalletGame | null) {
  const gameRef = useRef(game); gameRef.current = game;
  const [token, setToken] = useState<string | null>(null);
  const [wallet, setWallet] = useState<GameWalletState>();
  const [direction, setDirection] = useState<GameExchangeDirection>("points_to_coins");
  const [amountText, setAmountText] = useState("1");
  const [review, setReview] = useState<PendingGameExchange | null>(null);
  const [pending, setPending] = useState<PendingGameExchange | null>(null);
  const [receipt, setReceipt] = useState<GameExchangeReceipt | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [authExpired, setAuthExpired] = useState(false);
  const [storageBlocked, setStorageBlocked] = useState(false);
  const epoch = useRef(0);
  const busy = useRef<symbol | null>(null);
  const refreshRef = useRef<() => void>(() => {});

  const refresh = useCallback(async () => {
    if (!game || !token || currentToken() !== token || busy.current) return;
    const version = ++epoch.current;
    setLoading(true); setReview(null); setError("");
    const response = await getGameWalletState(game);
    if (version !== epoch.current || currentToken() !== token || gameRef.current !== game) return;
    setLoading(false);
    if (!response.ok || !response.data) {
      if (loginStatus(response.status)) { setAuthExpired(true); setWallet(undefined); }
      setError(loginStatus(response.status) ? "login" : "load_failed");
      return;
    }
    setWallet(response.data); setAuthExpired(false);
    try {
      const saved = readPendingGameExchange(response.data.account_id, game);
      setPending(saved); setStorageBlocked(false);
      if (saved) { setDirection(saved.direction); setAmountText(String(saved.amount)); setError("pending"); }
      else if (response.data.coins_to_points_enabled === false) { setDirection("points_to_coins"); }
    } catch { setStorageBlocked(true); setError("storage"); }
  }, [token, game]);
  refreshRef.current = () => { void refresh(); };

  useEffect(() => {
    const sync = () => { setToken(currentToken()); };
    const focus = () => { sync(); refreshRef.current(); };
    sync();
    if (typeof window === "undefined") return;
    window.addEventListener("storage", sync); const unsubAuth = useAuthStore.subscribe(sync);
   
    window.addEventListener("focus", focus);
    return () => {
      window.removeEventListener("storage", sync); unsubAuth();
     
      window.removeEventListener("focus", focus);
    };
  }, []);

  useEffect(() => {
    ++epoch.current; busy.current = null;
    setWallet(undefined); setPending(null); setReview(null); setReceipt(null); setError("");
    setDirection("points_to_coins"); setAmountText("1");
    setAuthExpired(false); setStorageBlocked(false); setSubmitting(false); setLoading(false);
    if (token && game) void refresh();
    return () => { ++epoch.current; busy.current = null; };
  }, [token, game, refresh]);

  const changeDirection = (value: GameExchangeDirection) => {
    if (busy.current || pending) return;
    if (value === "coins_to_points" && wallet?.coins_to_points_enabled === false) return;
    setDirection(value); setAmountText(value === "coins_to_points" && wallet ? String(wallet.coins_to_points_rate) : "1");
    setReview(null); setReceipt(null); setError("");
  };
  const changeAmount = (value: string) => {
    if (busy.current || pending) return;
    setAmountText(value); setReview(null); setReceipt(null); setError("");
  };
  const prepare = () => {
    if (!game || !wallet || wallet.game !== game || !token || authExpired || busy.current || loading || storageBlocked || pending || currentToken() !== token) return;
    const quote = quoteGameExchange(wallet, direction, amountText);
    if (quote.error) { setError(quote.error); return; }
    try {
      setReview({ request_id: newGameExchangeId(), game, direction, amount: quote.amount, quote_version: wallet.quote_version, expected_target_amount: quote.target });
      setReceipt(null); setError("");
    } catch { setError("storage"); }
  };

  const submit = async () => {
    const candidate = pending ?? review;
    if (!candidate || candidate.game !== game || !wallet || wallet.game !== game || !token || authExpired || busy.current || loading || storageBlocked || currentToken() !== token) return;
    if (!pending && candidate.quote_version !== wallet.quote_version) { setReview(null); setError("quote_changed"); return; }
    const owner = Symbol("exchange");
    busy.current = owner; setSubmitting(true); setError("");
    const version = ++epoch.current, uid = wallet.account_id;
    try {
      const request = savePendingGameExchange(uid, candidate);
      setPending(request); setReview(null);
      // 另一页面已有待确认操作时先呈现原指令，不偷偷替换本次确认内容。
      if (JSON.stringify(request) !== JSON.stringify(candidate)) {
        setDirection(request.direction); setAmountText(String(request.amount)); setError("pending"); return;
      }
      const response = await exchangeGameWallet(request);
      if (version !== epoch.current || currentToken() !== token || gameRef.current !== request.game) return;
      if (!response.ok || !response.data) {
        if (loginStatus(response.status)) { setAuthExpired(true); setWallet(undefined); }
        setError(loginStatus(response.status) ? "login" : "pending"); return;
      }
      const result = response.data;
      if (result.state.account_id !== uid || result.state.game !== request.game) { setWallet(undefined); setError("account_changed"); return; }
      if (result.accepted && !receiptConfirmsGameExchange(request, result.receipt)) { setError("receipt_mismatch"); return; }
      setWallet(result.state);
      const resolved = result.accepted || (!result.receipt && isConfirmedRejection(result.reason_code));
      if (!resolved) { setError(result.reason_code === "request_conflict" ? "request_conflict" : "pending"); return; }
      if (!clearPendingGameExchange(uid, request)) {
        const saved = readPendingGameExchange(uid, request.game); setPending(saved); setError("pending"); return;
      }
      setPending(null);
      if (result.accepted) setReceipt(result.receipt);
      else { setError(result.reason_code ?? "pending"); setReview(null); }
    } catch { if (version === epoch.current && currentToken() === token) { setStorageBlocked(true); setError("storage"); } }
    finally {
      if (busy.current === owner) { busy.current = null; setSubmitting(false); }
    }
  };

  return { ready: token !== null, signedIn: !!token && !authExpired, wallet, direction, amountText, review, pending, receipt, error,
    loading, submitting, storageBlocked, changeDirection, changeAmount, prepare, submit, refresh,
    cancelReview: () => { if (!busy.current) setReview(null); } };
}
