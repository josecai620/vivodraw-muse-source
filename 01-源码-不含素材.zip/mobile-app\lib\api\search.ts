import { API_ENDPOINTS } from "@/constants/api";
import type { Product } from "@/lib/api/product";
import { http } from "@/lib/http";

export function getSearchKeywords() {
  return http.get<string[]>(API_ENDPOINTS.search.keyword);
}

export function searchProducts(keyword: string, params?: { page?: number; limit?: number }) {
  return http.get<{ list: Product[]; total: number }>(API_ENDPOINTS.search.products, {
    params: { ...params, keyword },
  });
}
