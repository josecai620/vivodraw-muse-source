import React, { useMemo, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { ChevronRight, Mail } from "lucide-react-native";
import { useQuery } from "@tanstack/react-query";
import {
  getMessageList,
  messageTabOf,
  type MessageItem,
  type MessageTab,
} from "@/lib/api/message";
import { unwrapApiData, unwrapApiListField } from "@/lib/api/response";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

const TABS: { id: MessageTab; zh: string; en: string }[] = [
  { id: "all", zh: "全部", en: "All" },
  { id: "credit", zh: "入賬", en: "Credits" },
  { id: "notice", zh: "公告", en: "Notice" },
  { id: "news", zh: "新聞", en: "News" },
  { id: "feed", zh: "動態", en: "Feed" },
  { id: "mail", zh: "站內信", en: "Mail" },
];

function formatDate(str: string): string {
  if (!str) return "";
  const d = new Date(str);
  return isNaN(d.getTime()) ? str : d.toLocaleString();
}

function isUnread(item: MessageItem) {
  const read = item.is_read ?? item.look ?? item.read;
  return Number(read ?? 0) !== 1 && read !== true;
}

export default function MessagesScreen() {
  const router = useRouter();
  const { i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const [tab, setTab] = useState<MessageTab>("all");
  const { data, isLoading } = useQuery({
    queryKey: ["messageList"],
    queryFn: () => getMessageList({ page: 1, limit: 80 }),
  });

  const payload = unwrapApiData<Record<string, unknown>>(data, {});
  const list = unwrapApiListField<MessageItem>(payload);
  const filtered = useMemo(() => {
    if (tab === "all") return list;
    return list.filter((item) => messageTabOf(item) === tab);
  }, [list, tab]);

  const renderItem = ({ item }: { item: MessageItem }) => {
    const id = item.id ?? item.message_id;
    const title = item.title ?? item.content?.slice(0, 30) ?? (zh ? "消息" : "Message");
    const unread = isUnread(item);
    const kind = TABS.find((row) => row.id === messageTabOf(item));

    return (
      <Pressable
        onPress={() => id && router.push(`/profile/message/${id}`)}
        className="flex-row items-center bg-white mb-2 rounded-xl p-4 border border-gray-100"
      >
        <View
          className="w-10 h-10 rounded-full items-center justify-center"
          style={{ backgroundColor: unread ? `${Colors.brand.red}20` : "#F3F4F6" }}
        >
          <Mail size={s(20)} color={unread ? Colors.brand.red : Colors.neutral[400]} />
        </View>
        <View className="flex-1 ml-3">
          <Text className="font-medium" style={{ color: Colors.neutral[800] }} numberOfLines={1}>
            {title}
          </Text>
          <Text className="text-xs mt-0.5" style={{ color: Colors.neutral[500] }}>
            {(zh ? kind?.zh : kind?.en) ?? ""} · {formatDate(String(item.create_time ?? item.add_time ?? ""))}
          </Text>
        </View>
        {unread ? <View className="w-2 h-2 rounded-full mr-2" style={{ backgroundColor: Colors.brand.red }} /> : null}
        <ChevronRight size={s(20)} color={Colors.neutral[400]} />
      </Pressable>
    );
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={zh ? "消息" : "Messages"} />
      <View className="flex-row px-3 pt-3 gap-1">
        {TABS.map((row) => {
          const active = tab === row.id;
          return (
            <Pressable
              key={row.id}
              onPress={() => setTab(row.id)}
              className="px-2 py-1.5 rounded-full"
              style={{ backgroundColor: active ? "#04A8AE" : "#FFFFFF" }}
            >
              <Text style={{ color: active ? "#fff" : "#4B5563", fontSize: 11, fontWeight: "700" }}>
                {zh ? row.zh : row.en}
              </Text>
            </Pressable>
          );
        })}
      </View>
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <View className="flex-1 px-4 pt-3">
          <FlatList
            data={filtered}
            renderItem={renderItem}
            keyExtractor={(item, index) => String(item.id ?? item.message_id ?? index)}
            contentContainerStyle={{ paddingBottom: s(80) }}
            ListEmptyComponent={
              <View className="py-12 items-center">
                <Mail size={s(48)} color={Colors.neutral[300]} />
                <Text className="mt-3" style={{ color: Colors.neutral[500] }}>
                  {zh ? "暫無這類消息" : "No messages"}
                </Text>
              </View>
            }
          />
        </View>
      )}
    </View>
  );
}
