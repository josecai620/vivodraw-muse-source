/**
 * 钱包 Stripe 充值（从 v3 lib/api/account 迁移，服务游戏化积分购买流程）
 */
import { fetchAuthPost } from "@/lib/api/legacyHttp";

export const MAX_RECHARGE_MINOR = 99999999;

export type WalletRechargeSession = {
  provider: "stripe";
  mode: "test" | "live";
  order_id: string;
  checkoutSessionId: string;
  checkoutUrl: string;
  kind: "wallet_recharge";
  account_id: number;
  request_id: string;
  amount_minor: number;
  recharge_status: "open" | "paid" | "processing" | "expired" | "recovery_required";
};

type RemoteWalletRechargeSession = Partial<WalletRechargeSession> & {
  orderId?: string;
  order_id?: string;
  checkout_url?: string;
  checkout_session_id?: string;
};

function normalizeWalletRechargeSession(payload: unknown): WalletRechargeSession | undefined {
  if (!payload || typeof payload !== "object") return undefined;
  const record = payload as RemoteWalletRechargeSession;
  const checkoutUrl = String(record.checkoutUrl || record.checkout_url || "").trim();
  if (
    record.provider !== "stripe" ||
    record.kind !== "wallet_recharge" ||
    !["test", "live"].includes(record.mode ?? "") ||
    !Number.isSafeInteger(record.account_id) ||
    Number(record.account_id) <= 0 ||
    typeof record.request_id !== "string" ||
    !Number.isSafeInteger(record.amount_minor) ||
    Number(record.amount_minor) <= 0 ||
    Number(record.amount_minor) > MAX_RECHARGE_MINOR ||
    !["open", "paid", "processing", "expired", "recovery_required"].includes(record.recharge_status ?? "") ||
    typeof record.order_id !== "string" ||
    !/^[A-Za-z0-9_-]{1,80}$/.test(record.order_id) ||
    typeof record.checkoutSessionId !== "string"
  ) {
    return undefined;
  }
  if (record.recharge_status === "open") {
    try {
      const url = new URL(checkoutUrl);
      if (
        url.protocol !== "https:" ||
        url.hostname !== "checkout.stripe.com" ||
        url.username ||
        url.password ||
        url.port ||
        !record.checkoutSessionId
      ) {
        return undefined;
      }
    } catch {
      return undefined;
    }
  } else if (checkoutUrl !== "") {
    return undefined;
  }

  return {
    provider: "stripe",
    mode: record.mode === "test" ? "test" : "live",
    order_id: String(record.order_id || record.orderId || "").trim(),
    checkoutSessionId: String(record.checkoutSessionId || record.checkout_session_id || "").trim(),
    checkoutUrl,
    kind: "wallet_recharge",
    account_id: record.account_id!,
    request_id: record.request_id,
    amount_minor: record.amount_minor!,
    recharge_status: record.recharge_status!,
  };
}

export async function startWalletRecharge(input: {
  amount_minor: number;
  account_id: number;
  request_id: string;
}) {
  if (
    !Number.isSafeInteger(input.amount_minor) ||
    input.amount_minor < 50 ||
    input.amount_minor > MAX_RECHARGE_MINOR ||
    !Number.isSafeInteger(input.account_id) ||
    input.account_id <= 0 ||
    !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(input.request_id)
  ) {
    return { ok: false as const, data: undefined, message: "Recharge amount must be between $0.50 and $999,999.99." };
  }

  const result = await fetchAuthPost<RemoteWalletRechargeSession>("/api/recharge/recharge", {
    price: `${Math.floor(input.amount_minor / 100)}.${String(input.amount_minor % 100).padStart(2, "0")}`,
    request_id: input.request_id,
    account_id: input.account_id,
    rechar_id: 0,
    type: 0,
    from: "stripe",
  });
  const session = normalizeWalletRechargeSession(result.data);

  return result.ok &&
    session &&
    session.account_id === input.account_id &&
    session.request_id === input.request_id &&
    session.amount_minor === input.amount_minor
    ? { ...result, data: session }
    : { ...result, ok: false as const, data: session, message: result.message || "Stripe wallet recharge is not ready." };
}
