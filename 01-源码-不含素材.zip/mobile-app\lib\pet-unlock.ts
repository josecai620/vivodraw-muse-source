import type { PixelDeskPetId } from "@/lib/pets";

export type PetUnlockPathType = "play";

export type PetUnlockProgress = {
  intimacyValue?: number;
  nextPetId?: string;
  nextPetNeed?: number;
  nextPetHave?: number;
  unlockedCount?: number;
};

export type PetUnlockPath = {
  type: PetUnlockPathType | string;
  need: number;
  have: number;
  met: boolean;
  href: string;
};

/** 和解鎖後端排隊一致。一天最多 60 默契（10 次逗寵 +3、3 次零食 +10）。 */
export const PET_UNLOCK_ORDER: PixelDeskPetId[] = [
  "cat_programmer",
  "octopus_wizard",
  "shiba_bone",
  "penguin_sign",
  "axolotl_writer",
  "gray_yarn_cat",
  "blue_sprout_slime",
  "nibble_mouse",
  "dino_sipper",
  "raccoon_reader",
  "honglang",
  "jj-duck",
  "bitboy",
  "wukong",
];

/** 領取這隻要花掉的默契。後面的比前面貴，避免一天刷完。 */
export const PET_UNLOCK_COSTS: Record<PixelDeskPetId, number> = {
  cat_programmer: 0,
  octopus_wizard: 60,
  shiba_bone: 90,
  penguin_sign: 120,
  axolotl_writer: 180,
  gray_yarn_cat: 240,
  blue_sprout_slime: 330,
  nibble_mouse: 420,
  dino_sipper: 540,
  raccoon_reader: 660,
  honglang: 810,
  "jj-duck": 960,
  bitboy: 1140,
  wukong: 1350,
};

/** 最後三隻一口價，存多少默契都不打折。 */
export const PET_UNLOCK_FIXED_USD: Partial<Record<PixelDeskPetId, number>> = {
  "jj-duck": 289.99,
  bitboy: 369.99,
  wukong: 489.99,
};

export type PetUsdQuote = {
  mode: "none" | "topup" | "fixed";
  price: number;
  canPay: boolean;
};

/** 有消費時，這隻每天大概能撿到多少積分（頁面提示用）。 */
export const PET_POINT_GIFT_HINT: Record<PixelDeskPetId, { min: number; max: number; percent: number }> = {
  cat_programmer: { min: 0, max: 3, percent: 40 },
  octopus_wizard: { min: 0, max: 4, percent: 55 },
  shiba_bone: { min: 0, max: 5, percent: 65 },
  penguin_sign: { min: 0, max: 6, percent: 75 },
  axolotl_writer: { min: 0, max: 7, percent: 85 },
  gray_yarn_cat: { min: 0, max: 8, percent: 95 },
  blue_sprout_slime: { min: 0, max: 9, percent: 105 },
  nibble_mouse: { min: 0, max: 10, percent: 115 },
  dino_sipper: { min: 0, max: 12, percent: 130 },
  raccoon_reader: { min: 0, max: 13, percent: 145 },
  honglang: { min: 0, max: 14, percent: 160 },
  "jj-duck": { min: 0, max: 15, percent: 175 },
  bitboy: { min: 0, max: 16, percent: 190 },
  wukong: { min: 0, max: 18, percent: 210 },
};

export function petUnlockCost(petId: PixelDeskPetId): number {
  return PET_UNLOCK_COSTS[petId] ?? 0;
}

export function isPetFixedUsd(petId: PixelDeskPetId): boolean {
  return PET_UNLOCK_FIXED_USD[petId] != null;
}

export function formatUsdPrice(price: number): string {
  return `$${price.toFixed(2)}`;
}

/** 前面幾隻：剩餘天數 × 日封頂 × 1.2。最後三隻永遠固定價。 */
export function petUsdQuote(petId: PixelDeskPetId, have = 0): PetUsdQuote {
  const fixed = PET_UNLOCK_FIXED_USD[petId];
  const cost = petUnlockCost(petId);
  if (fixed != null) {
    return { mode: "fixed", price: fixed, canPay: have < cost };
  }
  if (cost <= 0) return { mode: "none", price: 0, canPay: false };
  const remain = Math.max(0, cost - Math.max(0, have));
  if (remain <= 0) return { mode: "none", price: 0, canPay: false };
  const cap = Math.max(1, PET_POINT_GIFT_HINT[petId]?.max ?? 1);
  const raw = (remain / 60) * cap * 1.2;
  const price = Math.round(Math.max(0.99, Math.floor(raw) + 0.99) * 100) / 100;
  return { mode: "topup", price, canPay: true };
}

export function buildPetUnlockPaths(petId: PixelDeskPetId, progress: PetUnlockProgress): PetUnlockPath[] {
  const need = petUnlockCost(petId);
  const have = progress.intimacyValue || 0;
  return [
    {
      type: "play",
      need,
      have,
      met: have >= need,
      href: "/pet-deck",
    },
  ];
}

export function isPetIdUnlocked(
  petId: PixelDeskPetId,
  _progress: PetUnlockProgress | undefined,
  loggedIn: boolean,
  unlockedIds?: string[],
): boolean {
  if (petId === "cat_programmer") return true;
  if (!loggedIn) return false;
  if (unlockedIds && unlockedIds.length > 0) return unlockedIds.includes(petId);
  return false;
}

export function formatUnlockShortHint(petId: PixelDeskPetId): string {
  const cost = petUnlockCost(petId);
  if (cost <= 0) return "Free starter";
  return `${cost} bond`;
}

export function nextPetUnlockNeed(petId: PixelDeskPetId): number {
  return petUnlockCost(petId);
}
