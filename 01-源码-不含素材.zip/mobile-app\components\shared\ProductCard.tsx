import { useRouter } from "expo-router";
import { Coins, Heart, Plus } from "lucide-react-native";
import React from "react";
import { Pressable, Text, View } from "react-native";
import { Colors, Shadows, s } from "@/constants/theme";
import { shopGiftPoints } from "@/lib/会员等级";
import { normalizeImageUrl } from "@/lib/utils";
import CachedImage from "./CachedImage";

interface ProductCardProps {
  id: number;
  image: string;
  name: string;
  price: number | string;
  originalPrice?: number | string;
  sales?: number;
  giveIntegral?: number;
  isHot?: boolean;
  isNew?: boolean;
  /** grid = 两列对齐网格卡（宽度填满父列）；horizontal = 横向滑动窄卡 */
  layout?: "grid" | "horizontal";
  /** 三/四列时缩小内边距和字号 */
  compact?: boolean;
  /** small = 热门商品专用小尺寸卡片（约为普通横卡的 40%） */
  size?: "default" | "small";
  onAddToCart?: () => void;
}

function formatPrice(value: number | string): string {
  const n = typeof value === "string" ? parseFloat(value) : value;
  if (!isFinite(n)) return "0";
  return Number.isInteger(n) ? String(n) : n.toFixed(2);
}

export default function ProductCard({
  id,
  image,
  name,
  price,
  originalPrice,
  giveIntegral,
  isHot,
  isNew,
  layout = "grid",
  compact = false,
  size = "default",
  onAddToCart,
}: ProductCardProps) {
  const router = useRouter();
  const isGrid = layout === "grid";
  const isSmall = size === "small";
  const padX = isSmall ? s(3) : compact ? s(6) : s(10);
  const padTop = isSmall ? s(2.5) : compact ? s(6) : s(9);
  const padBottom = isSmall ? s(2.5) : compact ? s(7) : s(10);
  const titleSize = isSmall ? s(5.8) : compact ? s(10) : s(12);
  const titleLine = isSmall ? s(6.8) : compact ? s(13) : s(16);
  const titleH = isSmall ? s(12) : compact ? s(26) : s(32);
  const priceSize = isSmall ? s(7.5) : compact ? s(12) : s(14);
  const plusSize = isSmall ? s(13) : compact ? s(22) : s(28);

  const priceNum = Number(price);
  const oldNum = originalPrice === undefined ? NaN : Number(originalPrice);
  const hasOld = isFinite(oldNum) && isFinite(priceNum) && oldNum > priceNum;
  const giftPts =
    Number(giveIntegral) > 0 ? Number(giveIntegral) : shopGiftPoints(priceNum, 0);
  const showMeta = giftPts > 0;

  return (
    <Pressable
      onPress={() => router.push(`/product/${id}`)}
      style={({ pressed }) => ({
        ...(isGrid
          ? { width: "100%" }
          : { width: isSmall ? s(61) : s(152), marginRight: isSmall ? s(5) : s(10) }),
        borderRadius: isSmall ? s(8) : compact ? s(12) : s(18),
        backgroundColor: "#FFFFFF",
        borderWidth: 1,
        borderColor: Colors.screen.hairline,
        overflow: "hidden",
        ...Shadows.raisedSm,
        transform: [{ scale: pressed ? 0.985 : 1 }],
      })}
    >
      <View>
        {/* 正方形主图 1:1 */}
        <CachedImage
          uri={normalizeImageUrl(image)}
          style={{ width: "100%", aspectRatio: 1, backgroundColor: "#F4F6F6" }}
          priority="low"
        />

        {/* 收藏：白色圆形小浮钮，线性空心图标 */}
        <Pressable
          hitSlop={6}
          onPress={(e) => e.stopPropagation?.()}
          style={{
            position: "absolute",
            top: isSmall ? s(3) : s(8),
            right: isSmall ? s(3) : s(8),
            width: isSmall ? s(15) : s(26),
            height: isSmall ? s(15) : s(26),
            borderRadius: isSmall ? s(7.5) : s(13),
            backgroundColor: "#FFFFFF",
            alignItems: "center",
            justifyContent: "center",
            ...Shadows.raisedSm,
          }}
        >
          <Heart size={isSmall ? s(7.5) : s(13)} color="#5E5F5E" strokeWidth={1.9} fill="none" />
        </Pressable>

        {isHot && (
          <View
            style={{
              position: "absolute",
              top: isSmall ? s(3) : s(8),
              left: isSmall ? s(3) : s(8),
              paddingHorizontal: isSmall ? s(3) : s(7),
              paddingVertical: isSmall ? s(1.5) : s(3),
              borderRadius: isSmall ? s(4) : s(8),
              backgroundColor: Colors.primary.DEFAULT,
            }}
          >
            <Text style={{ color: "#FFFFFF", fontSize: isSmall ? s(5.5) : s(9), fontWeight: "800", letterSpacing: 0.3 }}>
              HOT
            </Text>
          </View>
        )}
        {isNew && !isHot && (
          <View
            style={{
              position: "absolute",
              top: isSmall ? s(3) : s(8),
              left: isSmall ? s(3) : s(8),
              paddingHorizontal: isSmall ? s(3) : s(7),
              paddingVertical: isSmall ? s(1.5) : s(3),
              borderRadius: isSmall ? s(4) : s(8),
              backgroundColor: "#171A1A",
            }}
          >
            <Text style={{ color: "#FFFFFF", fontSize: isSmall ? s(5.5) : s(9), fontWeight: "800", letterSpacing: 0.3 }}>
              NEW
            </Text>
          </View>
        )}
      </View>

      <View style={{ paddingHorizontal: padX, paddingTop: padTop, paddingBottom: padBottom }}>
        {/* 标题固定两行高，保证两列严格等高对齐 */}
        <Text
          numberOfLines={2}
          style={{
            color: "#171A1A",
            fontSize: titleSize,
            lineHeight: titleLine,
            fontWeight: "600",
            height: titleH,
          }}
        >
          {name}
        </Text>

        {/* 积分行固定高度占位，避免有的卡有积分、有的没有导致高低不齐 */}
        <View style={{ height: isSmall ? s(7) : compact ? s(12) : s(16), marginTop: isSmall ? s(1) : s(4), flexDirection: "row", alignItems: "center" }}>
          {showMeta && (
            <View style={{ flexDirection: "row", alignItems: "center", gap: s(3) }}>
              <Coins size={isSmall ? s(5.5) : compact ? s(8) : s(10)} color={Colors.primary.DEFAULT} strokeWidth={2} />
              <Text style={{ fontSize: isSmall ? s(6) : compact ? s(9) : s(10.5), color: Colors.primary.DEFAULT, fontWeight: "700" }}>
                +{giftPts} pts
              </Text>
            </View>
          )}
        </View>

        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            marginTop: isSmall ? s(1) : s(4),
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "baseline", gap: s(5), flexShrink: 1 }}>
            <Text
              numberOfLines={1}
              style={{ color: Colors.primary.DEFAULT, fontSize: priceSize, fontWeight: "800" }}
            >
              ${formatPrice(price)}
            </Text>
            {hasOld && (
              <Text style={{ color: "#B2B7B6", fontSize: isSmall ? s(5.5) : compact ? s(8) : s(10), textDecorationLine: "line-through" }}>
                ${formatPrice(originalPrice as number | string)}
              </Text>
            )}
          </View>

          {/* 简洁加购：白底圆钮 + 青色线性 +，仅一圈柔影浮起（扁平、不堆砌渐变） */}
          <Pressable
            hitSlop={6}
            onPress={(e) => {
              e.stopPropagation?.();
              onAddToCart?.();
            }}
            style={{
              marginLeft: isSmall ? s(1) : s(6),
              width: plusSize,
              height: plusSize,
              borderRadius: plusSize / 2,
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: "rgba(12,31,31,0.08)",
              alignItems: "center",
              justifyContent: "center",
              shadowColor: "#0C1F1F",
              shadowOffset: { width: 0, height: 3 },
              shadowOpacity: 0.1,
              shadowRadius: 7,
              elevation: 3,
            }}
          >
            <Plus size={isSmall ? s(8) : compact ? s(13) : s(16)} color={Colors.primary.DEFAULT} strokeWidth={2.3} />
          </Pressable>
        </View>
      </View>
    </Pressable>
  );
}
