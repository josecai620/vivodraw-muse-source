import React, { useCallback, useEffect, useRef, useState } from "react";
import { Platform, Pressable, Text, View, useWindowDimensions } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { usePathname } from "expo-router";
import { useLanguage } from "@/hooks/useLanguage";
import { Colors, Shadows, s } from "@/constants/theme";

const SIZE = 44;
const POS_KEY = "cloudBuyLangFabPosV4";

function readPos(): { x: number; y: number } | null {
  if (Platform.OS !== "web" || typeof sessionStorage === "undefined") return null;
  try {
    const raw = sessionStorage.getItem(POS_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { x?: number; y?: number };
    if (typeof parsed.x !== "number" || typeof parsed.y !== "number") return null;
    return { x: parsed.x, y: parsed.y };
  } catch {
    return null;
  }
}

function savePos(x: number, y: number) {
  if (Platform.OS !== "web" || typeof sessionStorage === "undefined") return;
  try {
    sessionStorage.setItem(POS_KEY, JSON.stringify({ x, y }));
  } catch {}
}

function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(n, max));
}

export default function CloudBuyLangFab() {
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const pathname = usePathname();
  const { currentLanguage, toggleLanguage } = useLanguage();
  const savedRef = useRef(readPos());
  const hasCustomPosition = useRef(Boolean(savedRef.current));
  const saved = savedRef.current;
  const onHome = pathname === "/" || pathname === "/(tabs)" || pathname === "/(tabs)/index";
  const onPointsHome = pathname === "/points" || pathname === "/(tabs)/points";
  const onProfile = (pathname || "").includes("profile");
  const minX = 8;
  const maxX = Math.max(minX, width - SIZE - 8);
  const minY = Math.max(insets.top, 8);
  const maxY = Math.max(minY, height - SIZE - insets.bottom - 8);
  const shellWidth = Math.min(width, 430);
  const shellLeft = Math.max(0, (width - shellWidth) / 2);
  const routeDefaultX = onHome
    ? shellLeft + shellWidth - s(16) - s(40) - s(10) - s(40) - s(10) - SIZE
    : Math.max(8, width - SIZE - 12);
  const routeDefaultY = onHome
    ? Math.max(insets.top + s(10) + (s(42) - SIZE) / 2, 8)
    : onProfile
      ? Math.max(insets.top + 8, 52)
      : onPointsHome
        ? Math.max(insets.top + 8, 72)
        : Math.max(insets.top + 6, 8);
  const defaultX = saved?.x ?? routeDefaultX;
  const defaultY = saved?.y ?? routeDefaultY;

  const [pos, setPos] = useState({
    x: clamp(defaultX, minX, maxX),
    y: clamp(defaultY, minY, maxY),
  });
  const posRef = useRef(pos);
  const drag = useRef({
    active: false,
    moved: false,
    startX: 0,
    startY: 0,
    originX: 0,
    originY: 0,
  });

  useEffect(() => {
    setPos((prev) => {
      const next = {
        x: clamp(prev.x, minX, maxX),
        y: clamp(prev.y, minY, maxY),
      };
      posRef.current = next;
      return next;
    });
  }, [maxX, minY, maxY]);

  useEffect(() => {
    if (hasCustomPosition.current) return;
    const next = {
      x: clamp(routeDefaultX, minX, maxX),
      y: clamp(routeDefaultY, minY, maxY),
    };
    posRef.current = next;
    setPos(next);
  }, [maxX, minY, maxY, routeDefaultX, routeDefaultY]);

  const onToggle = useCallback(() => {
    void toggleLanguage();
  }, [toggleLanguage]);

  const onStart = (pageX: number, pageY: number) => {
    drag.current = {
      active: true,
      moved: false,
      startX: pageX,
      startY: pageY,
      originX: posRef.current.x,
      originY: posRef.current.y,
    };
  };

  const onMove = (pageX: number, pageY: number) => {
    if (!drag.current.active) return;
    const dx = pageX - drag.current.startX;
    const dy = pageY - drag.current.startY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) drag.current.moved = true;
    const next = {
      x: clamp(drag.current.originX + dx, minX, maxX),
      y: clamp(drag.current.originY + dy, minY, maxY),
    };
    posRef.current = next;
    setPos(next);
  };

  const onEnd = () => {
    if (!drag.current.active) return;
    drag.current.active = false;
    if (drag.current.moved) hasCustomPosition.current = true;
    savePos(posRef.current.x, posRef.current.y);
  };

  const pageXY = (e: { nativeEvent?: { pageX?: number; pageY?: number }; pageX?: number; pageY?: number }) => {
    const ne = e?.nativeEvent ?? e;
    return {
      x: Number(ne?.pageX ?? 0),
      y: Number(ne?.pageY ?? 0),
    };
  };

  const onPress = () => {
    if (drag.current.moved) return;
    onToggle();
  };

  const isZh = !String(currentLanguage || "").toLowerCase().startsWith("en");

  return (
    <View
      pointerEvents="box-none"
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 100000,
        elevation: 100000,
        ...(Platform.OS === "web" ? ({ position: "fixed" } as Record<string, string>) : null),
      }}
    >
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={isZh ? "Switch to English" : "切換到中文"}
        hitSlop={6}
        onPress={onPress}
        onPressIn={(e) => {
          const { x, y } = pageXY(e);
          onStart(x, y);
        }}
        onTouchMove={(e) => {
          const { x, y } = pageXY(e);
          onMove(x, y);
        }}
        onPressOut={onEnd}
        {...(Platform.OS === "web"
          ? {
              onPointerDown: (e: { nativeEvent?: { pageX?: number; pageY?: number }; pageX?: number; pageY?: number }) => {
                const { x, y } = pageXY(e);
                onStart(x, y);
              },
              onPointerMove: (e: { nativeEvent?: { pageX?: number; pageY?: number }; pageX?: number; pageY?: number }) => {
                const { x, y } = pageXY(e);
                onMove(x, y);
              },
              onPointerUp: onEnd,
            }
          : {})}
        style={{
          position: "absolute",
          left: pos.x,
          top: pos.y,
          width: SIZE,
          height: SIZE,
          borderRadius: SIZE / 2,
          backgroundColor: "#fff",
          borderWidth: 1,
          borderColor: Colors.screen.hairline,
          alignItems: "center",
          justifyContent: "center",
          zIndex: 100001,
          ...Shadows.floatingTab,
        }}
      >
        <Text style={{ color: Colors.primary.DEFAULT, fontSize: 13, fontWeight: "800" }}>
          {isZh ? "EN" : "中"}
        </Text>
      </Pressable>
    </View>
  );
}
