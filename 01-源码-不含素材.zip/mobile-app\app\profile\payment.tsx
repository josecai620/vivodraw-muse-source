import React, { useState } from "react";
import {
  Alert,
  Modal,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Plus, CreditCard, Lock, Trash2, Check, X } from "lucide-react-native";
import { PageHeader } from "@/components/shared";
import { TealGradient, Colors, s } from "@/constants/theme";
import { USE_DEV_MOCK_DATA } from "@/constants/env";

interface PaymentMethod {
  id: number;
  type: "visa" | "mastercard" | "apple-pay";
  last4: string;
  expiryDate: string;
  holderName: string;
  isDefault: boolean;
}

// 方向 C：卡面不使用彩色 emoji，统一白色线性 CreditCard 图标 + 品牌文字
const CARD_STYLES: Record<string, { name: string; colors: [string, string] }> = {
  visa: { name: "Visa", colors: [Colors.brand.red, Colors.brand.redDark] },
  mastercard: { name: "Mastercard", colors: [Colors.accent.orange, Colors.brand.red] },
  "apple-pay": { name: "Apple Pay", colors: [Colors.home.muted, Colors.home.text] },
};

const DEFAULT_CARD_STYLE = { name: "Card", colors: [Colors.home.muted, Colors.home.text] as [string, string] };

const DEV_PAYMENT_METHODS: PaymentMethod[] = [
  { id: 1, type: "visa", last4: "4532", expiryDate: "12/26", holderName: "John Doe", isDefault: true },
  { id: 2, type: "mastercard", last4: "8901", expiryDate: "09/27", holderName: "John Doe", isDefault: false },
  { id: 3, type: "apple-pay", last4: "6789", expiryDate: "03/28", holderName: "John Doe", isDefault: false },
];

export default function PaymentMethodsScreen() {
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(
    USE_DEV_MOCK_DATA ? DEV_PAYMENT_METHODS : [],
  );

  const [showAddModal, setShowAddModal] = useState(false);
  const [newCard, setNewCard] = useState({
    cardNumber: "",
    expiryDate: "",
    cvv: "",
    holderName: "",
  });

  const getCardInfo = (type: string) => CARD_STYLES[type] ?? DEFAULT_CARD_STYLE;

  const deletePaymentMethod = (id: number) => {
    Alert.alert("Delete Card", "Are you sure you want to remove this payment method?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: () => setPaymentMethods((prev) => prev.filter((pm) => pm.id !== id)),
      },
    ]);
  };

  const setDefaultPaymentMethod = (id: number) => {
    setPaymentMethods((prev) => prev.map((pm) => ({ ...pm, isDefault: pm.id === id })));
  };

  const handleAddCard = () => {
    if (!newCard.cardNumber || !newCard.expiryDate || !newCard.cvv || !newCard.holderName) return;
    const last4 = newCard.cardNumber.replace(/\s/g, "").slice(-4);
    setPaymentMethods((prev) => [
      ...prev,
      {
        id: Date.now(),
        type: "visa",
        last4,
        expiryDate: newCard.expiryDate,
        holderName: newCard.holderName,
        isDefault: prev.length === 0,
      },
    ]);
    setNewCard({ cardNumber: "", expiryDate: "", cvv: "", holderName: "" });
    setShowAddModal(false);
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader
        title="Payment Methods"
        rightElement={
          <Pressable className="p-2 -mr-2" onPress={() => setShowAddModal(true)}>
            <Plus size={s(22)} color={Colors.neutral[800]} />
          </Pressable>
        }
      />

      {paymentMethods.length === 0 ? (
        <View className="flex-1 items-center justify-center px-8">
          <View className="w-32 h-32 rounded-full bg-gray-100 items-center justify-center mb-6">
            <CreditCard size={s(64)} color={Colors.neutral[300]} />
          </View>
          <Text className="text-xl font-bold text-gray-900 mb-2">No Payment Methods Yet</Text>
          <Text className="text-gray-500 text-center text-sm mb-8">
            Add a payment method to make checkout faster and easier
          </Text>
          <Pressable
            onPress={() => setShowAddModal(true)}
            className="h-12 rounded-xl overflow-hidden"
          >
            <LinearGradient
              colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
              start={{ x: 1, y: 0.5 }}
              end={{ x: 0, y: 0.5 }}
              className="flex-1 px-6 items-center justify-center"
              style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }}
            >
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
              <Text className="font-bold text-white">Add Payment Method</Text>
            </LinearGradient>
          </Pressable>
        </View>
      ) : (
        <ScrollView className="flex-1 px-4 pt-4 pb-6" showsVerticalScrollIndicator={false}>
          {paymentMethods.map((method) => {
            const cardInfo = getCardInfo(method.type);
            return (
              <View
                key={method.id}
                className="bg-white rounded-2xl overflow-hidden mb-3"
                style={{
                  shadowColor: "#0C1F1F",
                  shadowOffset: { width: 0, height: 1 },
                  shadowOpacity: 0.05,
                  shadowRadius: 2,
                  elevation: 1,
                }}
              >
                {/* 卡片展示 */}
                <View className="h-44 overflow-hidden">
                  <LinearGradient
                    colors={cardInfo.colors as [string, string]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    className="flex-1 p-5"
                  >
                    {/* 装饰圆圈 */}
                    <View
                      className="absolute -top-4 -right-4 w-32 h-32 rounded-full"
                      style={{ backgroundColor: "rgba(255,255,255,0.1)" }}
                    />

                    <View className="flex-row items-center justify-between mb-6">
                      <CreditCard size={26} color="#FFFFFF" strokeWidth={2} />
                      <Text className="text-sm font-bold text-white opacity-90">
                        {cardInfo.name}
                      </Text>
                    </View>

                    <Text className="text-2xl font-bold text-white tracking-wider mb-4">
                      •••• •••• •••• {method.last4}
                    </Text>

                    <View className="flex-row items-center justify-between">
                      <View>
                        <Text className="text-xs text-white opacity-70 mb-1">Card Holder</Text>
                        <Text className="text-sm font-semibold text-white">
                          {method.holderName}
                        </Text>
                      </View>
                      <View>
                        <Text className="text-xs text-white opacity-70 mb-1">Expires</Text>
                        <Text className="text-sm font-semibold text-white">
                          {method.expiryDate}
                        </Text>
                      </View>
                    </View>
                  </LinearGradient>
                </View>

                {/* 操作按钮 */}
                <View className="p-4 flex-row gap-2">
                  {method.isDefault ? (
                    <View className="flex-1 h-10 bg-teal-50 rounded-lg flex-row items-center justify-center gap-2">
                      <Check size={s(16)} color={Colors.success} />
                      <Text className="font-bold text-sm text-teal-700">Default</Text>
                    </View>
                  ) : (
                    <Pressable
                      onPress={() => setDefaultPaymentMethod(method.id)}
                      className="flex-1 h-10 border-2 border-gray-300 rounded-lg items-center justify-center"
                    >
                      <Text className="font-bold text-sm text-gray-700">Set as Default</Text>
                    </Pressable>
                  )}
                  <Pressable
                    onPress={() => deletePaymentMethod(method.id)}
                    className="w-10 h-10 bg-brand-red-light rounded-lg items-center justify-center"
                  >
                    <Trash2 size={s(18)} color={Colors.error} />
                  </Pressable>
                </View>
              </View>
            );
          })}

          {/* 添加新卡片按钮 */}
          <Pressable
            onPress={() => setShowAddModal(true)}
            className="w-full h-16 border-2 border-dashed border-gray-300 rounded-2xl flex-row items-center justify-center gap-2 mb-6"
          >
            <Plus size={s(20)} color={Colors.neutral[500]} />
            <Text className="font-medium text-gray-600">Add New Payment Method</Text>
          </Pressable>
        </ScrollView>
      )}

      {/* 添加卡片弹窗 */}
      <Modal
        visible={showAddModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowAddModal(false)}
      >
        <View className="flex-1 justify-end" style={{ backgroundColor: "rgba(0,0,0,0.6)" }}>
          <View className="bg-white rounded-t-3xl max-h-[90%]">
            {/* Header */}
            <View className="border-b border-gray-200 px-4 py-4 flex-row items-center justify-between">
              <Text className="text-lg font-bold text-gray-900">Add Payment Method</Text>
              <Pressable className="p-2 -mr-2" onPress={() => setShowAddModal(false)}>
                <X size={s(22)} color={Colors.neutral[600]} />
              </Pressable>
            </View>

            <ScrollView className="px-4 pt-4" keyboardShouldPersistTaps="handled">
              <View className="gap-4">
                <View>
                  <Text className="text-sm font-bold text-gray-900 mb-2">Card Number</Text>
                  <TextInput
                    placeholder="1234 5678 9012 3456"
                    placeholderTextColor={Colors.neutral[400]}
                    maxLength={19}
                    keyboardType="number-pad"
                    value={newCard.cardNumber}
                    onChangeText={(v) => setNewCard({ ...newCard, cardNumber: v })}
                    className="w-full h-12 px-4 border-2 border-gray-200 rounded-xl text-sm"
                  />
                </View>

                <View className="flex-row gap-3">
                  <View className="flex-1">
                    <Text className="text-sm font-bold text-gray-900 mb-2">Expiry Date</Text>
                    <TextInput
                      placeholder="MM/YY"
                      placeholderTextColor={Colors.neutral[400]}
                      maxLength={5}
                      value={newCard.expiryDate}
                      onChangeText={(v) => setNewCard({ ...newCard, expiryDate: v })}
                      className="w-full h-12 px-4 border-2 border-gray-200 rounded-xl text-sm"
                    />
                  </View>
                  <View className="flex-1">
                    <Text className="text-sm font-bold text-gray-900 mb-2">CVV</Text>
                    <TextInput
                      placeholder="123"
                      placeholderTextColor={Colors.neutral[400]}
                      maxLength={3}
                      keyboardType="number-pad"
                      secureTextEntry
                      value={newCard.cvv}
                      onChangeText={(v) => setNewCard({ ...newCard, cvv: v })}
                      className="w-full h-12 px-4 border-2 border-gray-200 rounded-xl text-sm"
                    />
                  </View>
                </View>

                <View>
                  <Text className="text-sm font-bold text-gray-900 mb-2">Cardholder Name</Text>
                  <TextInput
                    placeholder="John Doe"
                    placeholderTextColor={Colors.neutral[400]}
                    value={newCard.holderName}
                    onChangeText={(v) => setNewCard({ ...newCard, holderName: v })}
                    className="w-full h-12 px-4 border-2 border-gray-200 rounded-xl text-sm"
                  />
                </View>

                <Pressable
                  onPress={handleAddCard}
                  className="w-full h-12 rounded-xl overflow-hidden mt-2"
                >
                  <LinearGradient
                    colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                    start={{ x: 0, y: 0.5 }}
                    end={{ x: 1, y: 0.5 }}
                    className="flex-1 items-center justify-center"
                    style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }}
                  >
                      <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                    <Text className="font-bold text-white">Add Card</Text>
                  </LinearGradient>
                </Pressable>
              </View>

              {/* 安全提示 */}
              <View className="bg-brand-red-light rounded-xl p-4 border border-brand-red-light mt-4 mb-8">
                <View className="flex-row items-start gap-3">
                  <Lock size={22} color="#04A8AE" strokeWidth={1.9} />
                  <View className="flex-1">
                    <Text className="text-sm font-bold text-gray-900 mb-1">Secure Payment</Text>
                    <Text className="text-xs text-gray-700 leading-relaxed">
                      Your payment information is encrypted and stored securely. We never share
                      your details with third parties.
                    </Text>
                  </View>
                </View>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}
