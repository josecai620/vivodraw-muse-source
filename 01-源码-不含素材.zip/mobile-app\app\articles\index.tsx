import React from "react";
import { ActivityIndicator, FlatList, Image, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { getArticleCategoryList, getArticleList, getArticleHotList } from "@/lib/api/article";
import { normalizeImageUrl } from "@/lib/utils";
import { FileText } from "lucide-react-native";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

export default function ArticlesScreen() {
  const router = useRouter();
  const { data: catData, isLoading: catLoading } = useQuery({
    queryKey: ["articleCategories"],
    queryFn: getArticleCategoryList,
  });
  const categories = (catData as any)?.data ?? (catData as any)?.list ?? catData ?? [];
  const firstCid = Array.isArray(categories) && categories[0] ? (categories[0].id ?? categories[0].cid) : 0;

  const { data: listData, isLoading: listLoading } = useQuery({
    queryKey: ["articleList", firstCid],
    queryFn: () => (firstCid ? getArticleList(firstCid) : getArticleHotList()),
    enabled: !!firstCid || firstCid === 0,
  });

  const { data: hotData } = useQuery({
    queryKey: ["articleHot"],
    queryFn: () => getArticleHotList({ limit: 5 }),
  });

  const list = (listData as any)?.data ?? (listData as any)?.list ?? listData ?? [];
  const hotList = (hotData as any)?.data ?? (hotData as any)?.list ?? hotData ?? [];
  const isLoading = catLoading || listLoading;

  const renderItem = ({ item }: { item: any }) => {
    const id = item.id ?? item.aid;
    const title = item.title ?? item.title_zh ?? "";
    const image = item.image_input?.[0] ?? item.image ?? item.cover;
    const summary = item.synopsis ?? item.summary ?? "";

    return (
      <Pressable
        onPress={() => router.push(`/articles/${id}`)}
        className="flex-row bg-white mb-3 rounded-xl overflow-hidden border border-gray-100"
      >
        {image ? (
          <Image source={{ uri: normalizeImageUrl(image) }} className="w-24 h-24" resizeMode="cover" />
        ) : (
          <View className="w-24 h-24 bg-gray-100 items-center justify-center">
            <FileText size={s(26)} color={Colors.neutral[400]} strokeWidth={1.8} />
          </View>
        )}
        <View className="flex-1 p-3 justify-center">
          <Text className="font-semibold text-sm" style={{ color: Colors.neutral[800] }} numberOfLines={2}>
            {title}
          </Text>
          {summary ? (
            <Text className="text-xs mt-1" style={{ color: Colors.neutral[500] }} numberOfLines={2}>
              {summary}
            </Text>
          ) : null}
        </View>
      </Pressable>
    );
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="News & Articles" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <View className="flex-1 px-4 pt-4">
          {Array.isArray(hotList) && hotList.length > 0 && (
            <View className="mb-4">
              <Text className="font-semibold mb-2" style={{ color: Colors.neutral[700] }}>
                Hot
              </Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} className="-mx-4 px-4">
                {hotList.slice(0, 5).map((item: any) => {
                  const id = item.id ?? item.aid;
                  return (
                    <Pressable
                      key={id}
                      onPress={() => router.push(`/articles/${id}`)}
                      className="w-36 mr-3 bg-white rounded-xl overflow-hidden border border-gray-100"
                    >
                      {item.image_input?.[0] || item.image ? (
                        <Image
                          source={{ uri: normalizeImageUrl(item.image_input?.[0] ?? item.image) }}
                          className="w-full h-20"
                          resizeMode="cover"
                        />
                      ) : (
                        <View className="w-full h-20 bg-gray-100 items-center justify-center">
                          <FileText size={s(24)} color={Colors.neutral[400]} strokeWidth={1.8} />
                        </View>
                      )}
                      <Text className="p-2 text-xs font-medium" style={{ color: Colors.neutral[800] }} numberOfLines={2}>
                        {item.title ?? item.title_zh}
                      </Text>
                    </Pressable>
                  );
                })}
              </ScrollView>
            </View>
          )}
          <Text className="font-semibold mb-2" style={{ color: Colors.neutral[700] }}>
            Articles
          </Text>
          <FlatList
            data={Array.isArray(list) ? list : []}
            renderItem={renderItem}
            keyExtractor={(item) => String(item.id ?? item.aid ?? item)}
            contentContainerStyle={{ paddingBottom: s(80) }}
            ListEmptyComponent={
              <View className="py-12 items-center">
                <Text style={{ color: Colors.neutral[500] }}>No articles yet</Text>
              </View>
            }
          />
        </View>
      )}
    </View>
  );
}
