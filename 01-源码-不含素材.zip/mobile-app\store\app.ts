import { create } from "zustand";

/** 分类页商品列数：手机最多 3 列，较宽屏 4 列 */
export function categoryDenseColumns(windowWidth: number): 3 | 4 {
  return windowWidth >= 520 ? 4 : 3;
}

interface AppState {
  isReady: boolean;
  toastMessage: string | null;
  toastType: "success" | "error" | "info" | null;
  categoryColumns: number;

  setReady: () => void;
  showToast: (message: string, type?: "success" | "error" | "info") => void;
  hideToast: () => void;
  cycleCategoryColumns: (windowWidth: number) => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  isReady: false,
  toastMessage: null,
  toastType: null,
  categoryColumns: 2,

  setReady: () => set({ isReady: true }),

  showToast: (message, type = "info") => {
    set({ toastMessage: message, toastType: type });
    setTimeout(() => set({ toastMessage: null, toastType: null }), 2500);
  },

  hideToast: () => set({ toastMessage: null, toastType: null }),

  cycleCategoryColumns: (windowWidth) => {
    const dense = categoryDenseColumns(windowWidth);
    const current = get().categoryColumns;
    if (current === 2) set({ categoryColumns: 1 });
    else if (current === 1) set({ categoryColumns: dense });
    else set({ categoryColumns: 2 });
  },
}));
