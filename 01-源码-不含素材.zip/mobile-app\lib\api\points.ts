import { API_ENDPOINTS } from "@/constants/api";
import { http } from "@/lib/http";

export interface PointsProduct {
  id?: number | string;
  image?: string;
  title?: string;
  store_name?: string;
  name?: string;
  img?: string;
  price?: number | string;
  integral?: number | string;
  points?: number | string;
  sales?: number | string;
  stock?: number | string;
  badge?: string;
}

export interface PointsCategory {
  id?: number | string;
  value?: number | string;
  cate_name?: string;
  name?: string;
  pic?: string;
}

export interface PointsProfile {
  integral?: number | string;
  uid?: number | string;
  id?: number | string;
}

export interface PointsCartCount {
  count?: number | string;
}

export interface PointsNotice {
  id?: number | string;
  head?: string;
  name?: string;
  text?: string;
  time?: string;
}

export interface PointsNotificationSummary {
  huangou?: unknown;
  wuliu?: unknown;
  shaidan?: unknown;
  zhongjiang?: unknown;
}

export interface PointsPopup {
  id?: number | string;
  product_id?: number | string;
  prompt?: string;
}

export interface RevealIndexItem {
  id?: number | string;
  pid?: number | string;
  djs?: number | string;
  nickname?: string;
  user_nickname?: string;
  zhongjiang_name?: string;
  luck_name?: string;
  store_name?: string;
  title?: string;
  image?: string;
}

export interface RevealIndexData {
  zuixin_list?: RevealIndexItem[];
}

export interface PointsLog {
  id: number;
  title: string;
  number: number;
  balance: number;
  mark: string;
  add_time: string;
  pm: number;
}

export interface LotteryInfo {
  id: number;
  name: string;
  image: string;
  prize: Array<{ id: number; type: number; name: string; image: string }>;
  lottery_num: number;
  factor: number;
}

export function getPointsBalance() {
  return http.get(API_ENDPOINTS.user.profile);
}

export function getPointsLog(params?: { page?: number; limit?: number; kind?: "points" | "bond" }) {
  return http.get(API_ENDPOINTS.points.log, { params });
}

export function getPointsIndex() {
  return http.get(API_ENDPOINTS.points.index);
}

export function getPointsProducts(params?: { page?: number; limit?: number }) {
  // store_integral/list is empty on prod; integral/lists has real catalog + preview images
  return http.get(API_ENDPOINTS.points.categoryProducts, { params });
}

export function getPointsProductDetail(id: number) {
  return http.get(API_ENDPOINTS.points.productDetail(id));
}

export function getPointsCategories() {
  return http.get(API_ENDPOINTS.points.category);
}

export function getPointsCategoryProducts(params?: {
  cid?: number;
  page?: number;
  limit?: number;
}) {
  return http.get(API_ENDPOINTS.points.categoryProducts, { params });
}

export function getPointsOrderList(params?: { type?: number; page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.points.orderList, { params });
}

export function getPointsOrderDetail(id: string) {
  return http.get(API_ENDPOINTS.points.orderDetail(id));
}

export function getPointsOrderExpress(id: string) {
  return http.get(API_ENDPOINTS.points.orderExpress(id));
}

/** 积分订单确认收货（body: order_id） */
export function takeIntegralOrder(orderId: string) {
  return http.post(API_ENDPOINTS.points.orderTake, { order_id: orderId });
}

/** 积分订单取消（body: order_id） */
export function cancelIntegralOrder(orderId: string) {
  return http.post(API_ENDPOINTS.points.orderCancel, { order_id: orderId });
}

/**
 * 云购结算幂等键：服务端要求 8–64 位、字母数字 . _ : -；每次点击生成一个新的，重试时复用同一个。
 * 只是请求标识，份数、单价、期号、幸运码全部由服务器决定。
 */
export function newCloudBuyRequestId(prefix: "join" | "cart" | "wish" = "join"): string {
  if (typeof globalThis.crypto?.randomUUID === "function") {
    return `${prefix}_${globalThis.crypto.randomUUID()}`;
  }
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 12)}`;
}

/** 单商品立即参与。后端读 pid / num / client_request_id（也兼容旧的 productId）。 */
export function exchangePoints(data: { productId: number; num?: number; uniqueId?: string; client_request_id?: string }) {
  return http.post(API_ENDPOINTS.points.exchange, {
    pid: data.productId,
    productId: data.productId,
    num: data.num ?? 1,
    client_request_id: data.client_request_id ?? newCloudBuyRequestId("join"),
  });
}

export function integralOrderConfirm(data: { unique: string; num: number }) {
  return http.post(API_ENDPOINTS.points.orderConfirm, data);
}

export function createIntegralOrder(data: {
  addressId: number;
  unique: string;
  num: number;
  mark: string;
  custom_form: Record<string, unknown>[];
}) {
  return http.post(API_ENDPOINTS.points.orderCreate, data);
}

export function deleteIntegralOrder(orderId: string) {
  return http.post(API_ENDPOINTS.points.orderDel, { order_id: orderId });
}

export function getPointsCartList() {
  return http.get(API_ENDPOINTS.points.cart.list);
}

/** 积分购物车商品数 */
export function getPointsCartCount() {
  return http.get(API_ENDPOINTS.points.cart.count);
}

export function addPointsCart(data: { productId: number; cartNum: number }) {
  return http.post(API_ENDPOINTS.points.cart.add, {
    pid: data.productId,
    productId: data.productId,
    cart_num: data.cartNum,
    cartNum: data.cartNum,
  });
}

export function delPointsCart(ids: number[]) {
  return http.post(API_ENDPOINTS.points.cart.del, { ids });
}

export function updatePointsCartNum(data: { id: number; number: number }) {
  return http.post(API_ENDPOINTS.points.cart.num, data);
}

export function getPointsCollectList(params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.points.collect.list, { params });
}

export function addPointsCollect(data: { id: number }) {
  return http.post(API_ENDPOINTS.points.collect.add, data);
}

export function delPointsCollect(data: { id: number }) {
  return http.post(API_ENDPOINTS.points.collect.del, data);
}

export function getSignConfig() {
  return http.get(API_ENDPOINTS.points.sign.config);
}

export function getSignUser(data?: { sign?: number; integral?: number; all?: number }) {
  return http.post(API_ENDPOINTS.points.sign.user, {
    sign: 1,
    integral: 0,
    all: 0,
    ...data,
  });
}

export function getSignList(params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.points.sign.list, { params });
}

export function doSign() {
  return http.post(API_ENDPOINTS.points.sign.integral);
}

export function getPointsTasks() {
  return http.post(API_ENDPOINTS.points.sign.pointsTasks, {});
}

export function claimPointsTask(params: { task_id: number }) {
  return http.post(API_ENDPOINTS.points.sign.pointsTaskClaim, params);
}

export function trackPointsTaskEvent(params: { event: string; ref?: string }) {
  return http.post(API_ENDPOINTS.points.sign.pointsTaskEvent, params);
}

export function getLotteryInfo(factor?: string) {
  return http.get(`${API_ENDPOINTS.points.lottery}/${factor ?? ""}`);
}

export function drawLottery() {
  return http.post(API_ENDPOINTS.points.lotteryDraw);
}

export function getLotteryRecord(params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.points.lotteryRecord, { params });
}

export function getPointsNotifications(params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.points.notifications, { params });
}

export function getShaidanList(params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.points.shaidan, { params });
}

export function getRedemptionList(params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.points.redemptions, { params });
}

export function getShaidanDetail(shaidanId: number) {
  return http.get(API_ENDPOINTS.points.shaidanDetail, { params: { shaidan_id: shaidanId } });
}

export function getShaidanDetailComments(shaidanId: number, page = 1, limit = 10) {
  return http.get(API_ENDPOINTS.points.shaidanDetailComments, {
    params: { shaidan_id: shaidanId, page, limit },
  });
}

export function addShaidanComment(data: { shaidan_id: number; content: string }) {
  return http.post(API_ENDPOINTS.points.shaidanAddComment, data);
}

export function shaidanLike(data: { id: number }) {
  return http.post(API_ENDPOINTS.points.shaidanLike, data);
}

export function postShaidan(data: {
  shaidan_id?: number;
  id?: number;
  title: string;
  content: string;
  images: string[];
}) {
  return http.post(API_ENDPOINTS.points.shaidanEdit, data);
}

export function getUserShaidanList(params?: {
  uid?: number;
  is_jiqiren?: number;
  page?: number;
  limit?: number;
}) {
  return http.get(API_ENDPOINTS.points.userShaidanList, { params });
}

export function getPointsHelpList(cid = 1) {
  return http.get(API_ENDPOINTS.points.help, { params: { cid } });
}

export function getPointsHelpDetail(nid: number) {
  return http.get(API_ENDPOINTS.points.helpDetail, { params: { nid } });
}

export function getFanxianList(params?: {
  status?: number;
  type?: string;
  page?: number;
  limit?: number;
}) {
  return http.get(API_ENDPOINTS.points.fanxianList, { params });
}

export function getHuandeInfo(id: number) {
  return http.get(API_ENDPOINTS.points.huandeInfo, { params: { id } });
}

export function confirmHuandeAddress(id: number, addressId: number) {
  return http.post(API_ENDPOINTS.points.huandeInfoAddress, { id, address_id: addressId });
}

export function recycleItem(id: number) {
  return http.post(API_ENDPOINTS.points.huishou, { id });
}

// ─── 批量兑换 / 互转 / 弹窗 ────────────────────────────────────────────────

/** 清单结算。zidong=1 对应 bn 语义：清单里的期已满员时改买当前期。 */
export function exchangeAll(data: {
  ids: string;
  zidong: number;
  client_request_id?: string;
  use_lucky?: number;
  coupon_id?: number;
}) {
  return http.post(API_ENDPOINTS.points.exchangeAll, {
    ...data,
    client_request_id: data.client_request_id ?? newCloudBuyRequestId("cart"),
  });
}

export function getLuckyShop() {
  return http.get(API_ENDPOINTS.points.luckyShop);
}

export function redeemLuckyShop(data: { product_id: number; client_request_id?: string }) {
  return http.post(API_ENDPOINTS.points.luckyRedeem, {
    ...data,
    client_request_id: data.client_request_id ?? newCloudBuyRequestId("lucky"),
  });
}

export function pointsTransfer(data: { type: number; mobile: string; num: number }) {
  return http.post(API_ENDPOINTS.points.huzuan, data);
}

export function getTanchuang(userId?: number) {
  return http.post(API_ENDPOINTS.points.tanchuang, { user_id: userId ?? 0 });
}

// ─── 换取记录体系 ──────────────────────────────────────────────────────────

export function getHqjlLists(params?: { status?: number; page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.points.hqjlLists, { params });
}

export function getHqjlInfo(id: number) {
  return http.get(API_ENDPOINTS.points.hqjlInfo, { params: { id } });
}

export function getUserHqjlLists(params?: { status?: number; page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.points.userHqjlLists, { params });
}

// ─── 商品维度换取记录 / 历史换取者 ──────────────────────────────────────────

export function getDetailHqjl(id: number, bianhao: string, page = 1, limit = 20) {
  return http.get(API_ENDPOINTS.points.detailHqjl, { params: { id, bianhao, page, limit } });
}

export function getDetailLshqz(id: number, page = 1, limit = 50) {
  return http.get(API_ENDPOINTS.points.detailLshqz, { params: { id, page, limit } });
}

// ─── 揭晓算法详情 ──────────────────────────────────────────────────────────

export function getDetailJsxq(id: number) {
  return http.get(API_ENDPOINTS.points.detailJsxq, { params: { id } });
}

export function getDetailJsxqLists(id: number, bianhao: string, page = 1, limit = 99) {
  return http.get(API_ENDPOINTS.points.detailJsxqLists, { params: { id, bianhao, page, limit } });
}

// ─── 商品维度晒单列表 ──────────────────────────────────────────────────────

export function getProductShaidanList(productId: number, page = 1, limit = 10) {
  return http.get(API_ENDPOINTS.points.detailShaidanList(productId), { params: { page, limit } });
}

// ─── 商品评价 ───────────────────────────────────────────────────────────────

export function getProductReplyList(
  productId: number,
  params?: { type?: number; page?: number; limit?: number },
) {
  return http.get(API_ENDPOINTS.points.replyList(productId), { params });
}

export function getProductReplyConfig(productId: number) {
  return http.get(API_ENDPOINTS.points.replyConfig(productId));
}

// ─── 新版积分列表 / 分类 ────────────────────────────────────────────────────

export function getNewIntegralList(params?: {
  page?: number;
  cate?: number;
  order?: number;
  keyword?: string;
  is_xinping?: number;
}) {
  return http.get(API_ENDPOINTS.points.newlist, { params });
}

export function getNewIntegralCategory(type = 1) {
  return http.get(API_ENDPOINTS.points.newcategory, { params: { type } });
}

// ─── 签到月历 ───────────────────────────────────────────────────────────────

export function getSignMonth() {
  return http.get(API_ENDPOINTS.points.sign.month);
}

// ─── 揭晓 API (integral 揭晓模块) ─────────────────────────────────────────

/** 积分揭晓首页：zuixin_list(最新揭晓)、jijiang_list(即将揭晓) */
export function getRevealIndex() {
  return http.get(API_ENDPOINTS.points.reveal.index);
}

/** 揭晓列表（历史/最新揭晓） */
export function getRevealLists(params?: { cid?: number; page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.points.reveal.jiexiaoLists, { params });
}

/** 揭晓商品详情（id=kaijiang_log.id） */
export function getRevealDetail(id: number, pid?: number) {
  return http.get(API_ENDPOINTS.points.reveal.jiexiaoDetail, {
    params: { id, pid: pid ?? id },
  });
}

/** 我的揭晓/换取记录 */
export function getRevealMyRecords(params?: { page?: number; limit?: number; status?: number }) {
  return http.get(API_ENDPOINTS.points.reveal.huandeLists, { params });
}

/** 揭晓记录详情 */
export function getRevealRecordInfo(params: { id?: number; uni?: string }) {
  return http.get(API_ENDPOINTS.points.reveal.huandeInfo, { params });
}

// ─── T10 可验算揭晓（只读开奖快照） ────────────────────────────────────────

/** 定位一期：period_id="{productId}-{bianhao}"，或 product_id+bianhao，或 kaijiang_id */
export interface RevealPeriodLocator {
  periodId?: string;
  productId?: number;
  bianhao?: number | string;
  kaijiangId?: number;
}

function revealLocatorParams(loc: RevealPeriodLocator) {
  const params: Record<string, string | number> = {};
  if (loc.periodId) params.period_id = loc.periodId;
  if (loc.productId && loc.bianhao) {
    params.product_id = loc.productId;
    params.bianhao = Number(loc.bianhao);
  }
  if (loc.kaijiangId) params.kaijiang_id = loc.kaijiangId;
  return params;
}

/** 验算页数据（RevealView）：公式步骤、快照输入、合计/余数/幸运码、中奖人码段；登录时附 my.codes */
export function getRevealView(loc: RevealPeriodLocator) {
  return http.get(API_ENDPOINTS.points.reveal.view, { params: revealLocatorParams(loc) });
}

/** 服务端复算报告（VerifyReport） */
export function getRevealVerify(loc: RevealPeriodLocator) {
  return http.get(API_ENDPOINTS.points.reveal.verify, { params: revealLocatorParams(loc) });
}

/** 商品富文本描述 */
export function getDetailDesc(id: number) {
  return http.get(API_ENDPOINTS.points.detailDesc(id));
}

/** 积分商城公告 */
export function getNotice() {
  return http.get(API_ENDPOINTS.points.getnotice);
}

/** 通知分类概览（未读数） */
export function getTongzhi() {
  return http.get(API_ENDPOINTS.points.tongzhi);
}

/** 删除通知 */
export function deleteTongzhi(params: { type?: string; id?: number }) {
  return http.delete(API_ENDPOINTS.points.tongzhiDel, { params });
}

/** 晒单统计数 */
export function getShaidanNum(pid: number) {
  return http.get(API_ENDPOINTS.points.shaidanNum(pid));
}

/** 换取记录唯一号详情 */
export function getDetailHqjlUnique(hid: number, page = 1, limit = 100) {
  return http.get(API_ENDPOINTS.points.detailHqjlUnique, { params: { hid, page, limit } });
}

/** 批量加入购物车 */
export function cartAddAll(pids: number[], cartNum = 1) {
  return http.post(API_ENDPOINTS.points.cartAddAll, { pids, cart_num: cartNum });
}

/** 批量添加收藏 */
export function collectAll(ids: number[]) {
  return http.post(API_ENDPOINTS.points.collectAll, { id: ids.join(",") });
}

/** 从心愿单批量转收藏 */
export function collectAddAll(ids: number[]) {
  return http.post(API_ENDPOINTS.points.collectAddAll, { ids });
}

/** 批量取消收藏 */
export function collectAllDel(ids: number[]) {
  return http.post(API_ENDPOINTS.points.collectAllDel, { ids: ids.join(",") });
}
