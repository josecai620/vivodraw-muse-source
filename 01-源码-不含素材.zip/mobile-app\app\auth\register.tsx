import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { useTranslation } from "react-i18next";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { ArrowLeft, Check } from "lucide-react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Colors, TealGradient } from "@/constants/theme";
import TealSurface from "@/components/ui/TealSurface";
import LuxeIcon from "@/components/shared/LuxeIcon";
import { getUserProfile, register, sendEmailVerifyCode } from "@/lib/api/user";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import {
  captureReferralAttribution,
  clearReferralAttribution,
  getReferralAttribution,
} from "@/lib/获客归因";

function normalizeEmail(value: string) {
  return value.trim().toLowerCase();
}

function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizeEmail(value));
}

export default function RegisterScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const showToast = useAppStore((state) => state.showToast);
  const setToken = useAuthStore((state) => state.setToken);
  const setUser = useAuthStore((state) => state.setUser);

  const [email, setEmail] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [codeSentTo, setCodeSentTo] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [sendingCode, setSendingCode] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    captureReferralAttribution();
  }, []);

  useEffect(() => {
    if (countdown <= 0) return;
    const timer = setTimeout(() => setCountdown((current) => Math.max(0, current - 1)), 1000);
    return () => clearTimeout(timer);
  }, [countdown]);

  const handleEmailChange = (value: string) => {
    const nextEmail = normalizeEmail(value);
    if (codeSentTo && nextEmail !== codeSentTo) {
      setCodeSentTo("");
      setVerificationCode("");
      setCountdown(0);
    }
    setEmail(value);
    setErrorMessage("");
  };

  const handleSendCode = async () => {
    setErrorMessage("");
    if (!isValidEmail(email)) {
      setErrorMessage(email.trim() ? t("auth.invalidEmail") : t("auth.emailRequired"));
      return;
    }

    const normalizedEmail = normalizeEmail(email);
    setSendingCode(true);
    try {
      const expiresInSeconds = await sendEmailVerifyCode(normalizedEmail, "register");
      setCodeSentTo(normalizedEmail);
      setCountdown(expiresInSeconds);
      showToast(t("auth.emailCodeSent"), "success");
    } catch (error: any) {
      const message = error?.message || t("auth.failedSendEmailCode");
      const existingCodeWait = Number(message.match(/(\d+)\s+minutes?\s+valid/i)?.[1] || 0);
      if (existingCodeWait > 0) {
        setCodeSentTo(normalizedEmail);
        setCountdown(existingCodeWait * 60);
      }
      showToast(message, "error");
    } finally {
      setSendingCode(false);
    }
  };

  const handleRegister = async () => {
    setErrorMessage("");
    const normalizedEmail = normalizeEmail(email);

    if (!isValidEmail(email)) {
      setErrorMessage(email.trim() ? t("auth.invalidEmail") : t("auth.emailRequired"));
      return;
    }
    if (codeSentTo !== normalizedEmail) {
      setErrorMessage(t("auth.sendEmailCodeFirst"));
      return;
    }
    if (!/^\d{6}$/.test(verificationCode)) {
      setErrorMessage(t("auth.enterSixDigitCode"));
      return;
    }
    if (password.length < 6 || password.length > 16) {
      setErrorMessage(t("auth.passwordHint"));
      return;
    }
    if (password === "123456") {
      setErrorMessage(t("auth.passwordTooSimple"));
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage(t("auth.passwordsDontMatch"));
      return;
    }
    if (!agreed) {
      setErrorMessage(t("auth.agreeSignupTerms"));
      return;
    }

    setSubmitting(true);
    try {
      const response: any = await register({
        account: normalizedEmail,
        captcha: verificationCode,
        password,
        spread: getReferralAttribution() || undefined,
      });
      const result = response?.data ?? response;
      const token = result?.token ?? response?.token;
      if (typeof token !== "string" || !token) {
        throw new Error(t("auth.loginFailedNoToken"));
      }

      setToken(token);
      clearReferralAttribution();
      try {
        const profileResponse: any = await getUserProfile();
        const profile = profileResponse?.data ?? profileResponse;
        if (profile?.uid) setUser(profile);
      } catch {
        // The account and token are already created; profile hydration retries in the app shell.
      }

      showToast(t("auth.registrationSuccessful"), "success");
      router.replace("/(tabs)");
    } catch (error: any) {
      setErrorMessage(error?.message || t("common.failed"));
    } finally {
      setSubmitting(false);
    }
  };

  const inputClassName = "w-full h-12 px-4 bg-white border border-gray-200 rounded-2xl text-sm";
  const normalizedEmail = normalizeEmail(email);

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-gray-50"
    >
      <View
        className="border-b"
        style={{ paddingTop: insets.top, backgroundColor: "#FFFFFF", borderBottomColor: Colors.screen.hairline }}
      >
        <View className="h-14 px-4 flex-row items-center">
          <Pressable
            className="-ml-1"
            onPress={() => router.replace("/auth")}
            accessibilityRole="button"
            accessibilityLabel={t("auth.backToSignIn")}
          >
            <LuxeIcon Icon={ArrowLeft} tone="neutral" variant="soft" size={36} iconSize={18} />
          </Pressable>
        </View>
      </View>

      <ScrollView
        className="flex-1 px-4 py-8"
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View className="mb-8">
          <Text className="text-3xl font-bold text-gray-900 mb-2">
            {t("auth.createAccount")}
          </Text>
          <Text className="text-gray-600">{t("auth.signUpToStart")}</Text>
        </View>

        <Text className="text-sm font-medium text-gray-700 mb-2">{t("auth.emailAddress")}</Text>
        <TextInput
          value={email}
          onChangeText={handleEmailChange}
          placeholder={t("auth.enterEmail")}
          placeholderTextColor={Colors.neutral[400]}
          keyboardType="email-address"
          autoComplete="email"
          autoCapitalize="none"
          autoCorrect={false}
          textContentType="emailAddress"
          returnKeyType="next"
          className={`${inputClassName} mb-5`}
          style={{ color: Colors.luxe.ink, fontWeight: "500" }}
        />

        <Text className="text-sm font-medium text-gray-700 mb-2">{t("auth.verificationCode")}</Text>
        <View className="flex-row gap-2 mb-2">
          <TextInput
            value={verificationCode}
            onChangeText={(value) => {
              if (/^\d{0,6}$/.test(value)) setVerificationCode(value);
              setErrorMessage("");
            }}
            placeholder={t("auth.enterVerificationCode")}
            placeholderTextColor={Colors.neutral[400]}
            keyboardType="number-pad"
            autoComplete="one-time-code"
            textContentType="oneTimeCode"
            maxLength={6}
            className={`${inputClassName} flex-1`}
            style={{ color: Colors.luxe.ink, fontWeight: "500" }}
          />
          <Pressable
            onPress={handleSendCode}
            disabled={!isValidEmail(email) || countdown > 0 || sendingCode || submitting}
            accessibilityRole="button"
            accessibilityState={{ disabled: !isValidEmail(email) || countdown > 0 || sendingCode || submitting }}
            className="h-12 px-4 rounded-2xl items-center justify-center overflow-hidden"
            style={{ minWidth: 124, opacity: !isValidEmail(email) || countdown > 0 || submitting ? 0.55 : 1 }}
          >
            <LinearGradient
              colors={countdown > 0 ? [Colors.neutral[300], Colors.neutral[300]] : [TealGradient.light, TealGradient.base, TealGradient.dark]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}
            />
            {sendingCode ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text className="text-xs font-semibold text-white">
                {countdown > 0 ? t("auth.resendIn", { countdown }) : t("auth.sendCode")}
              </Text>
            )}
          </Pressable>
        </View>
        {codeSentTo === normalizedEmail && codeSentTo ? (
          <Text className="text-xs text-gray-500 mb-5">{t("auth.codeSentTo")} {codeSentTo}</Text>
        ) : (
          <View className="mb-5" />
        )}

        <Text className="text-sm font-medium text-gray-700 mb-2">{t("auth.password")}</Text>
        <TextInput
          value={password}
          onChangeText={(value) => { setPassword(value); setErrorMessage(""); }}
          placeholder={t("auth.setPassword")}
          placeholderTextColor={Colors.neutral[400]}
          secureTextEntry
          autoComplete="new-password"
          textContentType="newPassword"
          returnKeyType="next"
          className={`${inputClassName} mb-2`}
          style={{ color: Colors.luxe.ink, fontWeight: "500" }}
        />
        <Text className="text-xs text-gray-500 mb-5">{t("auth.passwordHint")}</Text>

        <Text className="text-sm font-medium text-gray-700 mb-2">{t("auth.confirmPassword")}</Text>
        <TextInput
          value={confirmPassword}
          onChangeText={(value) => { setConfirmPassword(value); setErrorMessage(""); }}
          placeholder={t("auth.reenterPassword")}
          placeholderTextColor={Colors.neutral[400]}
          secureTextEntry
          autoComplete="new-password"
          textContentType="newPassword"
          returnKeyType="done"
          onSubmitEditing={handleRegister}
          className={`${inputClassName} mb-6`}
          style={{ color: Colors.luxe.ink, fontWeight: "500" }}
        />

        <View className="flex-row flex-wrap gap-2 mb-4">
          <Pressable onPress={() => router.push("/agreement/user_agreement")}>
            <Text className="text-sm" style={{ color: Colors.brand.red }}>{t("auth.termsOfService")}</Text>
          </Pressable>
          <Text className="text-gray-500">·</Text>
          <Pressable onPress={() => router.push("/agreement/privacy_agreement")}>
            <Text className="text-sm" style={{ color: Colors.brand.red }}>{t("auth.privacyPolicy")}</Text>
          </Pressable>
        </View>

        <Pressable
          onPress={() => { setAgreed((current) => !current); setErrorMessage(""); }}
          accessibilityRole="checkbox"
          accessibilityState={{ checked: agreed }}
          className="flex-row items-start mb-5"
        >
          <View
            className="w-5 h-5 rounded mr-2 items-center justify-center"
            style={{
              borderWidth: 1.5,
              borderColor: agreed ? Colors.brand.red : Colors.neutral[400],
              backgroundColor: agreed ? Colors.brand.red : "transparent",
            }}
          >
            {agreed ? <Check size={14} color="#fff" /> : null}
          </View>
          <Text className="flex-1 text-sm text-gray-600">{t("auth.signupConsent")}</Text>
        </Pressable>

        {errorMessage ? (
          <Text accessibilityRole="alert" className="text-sm text-red-600 mb-4">
            {errorMessage}
          </Text>
        ) : null}

        <Pressable
          onPress={handleRegister}
          disabled={submitting || sendingCode}
          accessibilityRole="button"
          className="w-full mb-6"
          style={({ pressed }) => ({ transform: [{ scale: pressed ? 0.985 : 1 }], opacity: submitting ? 0.75 : 1 })}
        >
          <TealSurface direction="lr" radius={12} style={{ height: 48 }} contentStyle={{ alignItems: "center", justifyContent: "center" }}>
            {submitting ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text className="text-white font-semibold" style={{ backgroundColor: "transparent" }}>
                {t("auth.createAccount")}
              </Text>
            )}
          </TealSurface>
        </Pressable>

        <View className="flex-row justify-center mb-8">
          <Text className="text-sm text-gray-600">{t("auth.alreadyHaveAccount")}</Text>
          <Pressable onPress={() => router.replace("/auth")}>
            <Text className="text-sm font-semibold" style={{ color: Colors.brand.red }}>{t("auth.signIn")}</Text>
          </Pressable>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
