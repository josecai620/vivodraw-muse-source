import type { PointPurchaseReceipt, PointPurchaseRequest, PointPurchaseState } from "@/lib/api/pointPurchase";
import { gameReturnPaths, isGameWalletGame, type GameWalletGame } from "@/lib/api/gameWallet";

/** 只保存购买指令与用户已确认的价格，不保存美元余额、积分余额或登录凭证。 */
export type PendingPointPurchase = PointPurchaseRequest & { account_id: number; currency: "USD"; price_per_point_minor: number; expected_money_minor: number };
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const zeroDebitReasons = new Set(["invalid_request", "invalid_points", "quote_changed", "purchase_limit", "insufficient_balance", "balance_limit"]);
export const isConfirmedPurchaseRejection = (reason?: string) => zeroDebitReasons.has(reason ?? "");
export const pointPurchaseHref = (game: GameWalletGame) => `/point-purchase?game=${game}`;
export const pointPurchaseExchangeHref = (game: GameWalletGame) => `/game-wallet?game=${game}&returnTo=${encodeURIComponent(gameReturnPaths[game])}`;
export const pointPurchaseRechargeHref = (game: GameWalletGame) => `/wallet?game=${game}&pointPurchase=1`;
export function quotePointPurchase(state: PointPurchaseState, text: string) {
  if (!/^[1-9]\d*$/.test(text)) return { error: "invalid_points" as const };
  const points = Number(text), money = points * state.price_per_point_minor;
  if (!Number.isSafeInteger(points) || !Number.isSafeInteger(money) || money <= 0) return { error: "invalid_points" as const };
  if (points > state.max_points_per_purchase) return { error: "purchase_limit" as const };
  return { points, money, error: money > state.money_balance_minor ? "insufficient_balance" as const : undefined };
}
export function newPointPurchaseId() {
  if (typeof globalThis.crypto?.randomUUID === "function") return globalThis.crypto.randomUUID();
  const bytes = new Uint8Array(16); globalThis.crypto.getRandomValues(bytes);
  bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
  const hex = [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function validate(value: unknown): PendingPointPurchase {
  if (!value || typeof value !== "object") throw new Error("Invalid recovery record");
  const r = value as PendingPointPurchase;
  if (Object.keys(r).length !== 8 || !uuid.test(r.request_id) || !Number.isSafeInteger(r.account_id) || r.account_id <= 0
    || !isGameWalletGame(r.game) || r.currency !== "USD" || !Number.isSafeInteger(r.points) || r.points <= 0
    || !Number.isSafeInteger(r.price_per_point_minor) || r.price_per_point_minor <= 0
    || !Number.isSafeInteger(r.expected_money_minor) || r.expected_money_minor !== r.points * r.price_per_point_minor
    || typeof r.quote_version !== "string" || !r.quote_version.trim() || r.quote_version.length > 256) throw new Error("Invalid recovery record");
  return { request_id: r.request_id, account_id: r.account_id, game: r.game, points: r.points, quote_version: r.quote_version,
    currency: "USD", price_per_point_minor: r.price_per_point_minor, expected_money_minor: r.expected_money_minor };
}
function storage(accountId: number, game: GameWalletGame) {
  if (!Number.isSafeInteger(accountId) || accountId <= 0 || !isGameWalletGame(game) || typeof localStorage === "undefined") throw new Error("Recovery unavailable");
  return { store: localStorage, key: `vivodraw:point-purchase:pending:v1:${accountId}:${game}` };
}
export function readPendingPointPurchase(accountId: number, game: GameWalletGame): PendingPointPurchase | null {
  const { store, key } = storage(accountId, game), raw = store.getItem(key);
  if (raw === null) return null;
  if (raw.length > 2048) throw new Error("Invalid recovery record");
  const value = validate(JSON.parse(raw));
  if (value.account_id !== accountId || value.game !== game) throw new Error("Wrong recovery owner");
  return value;
}
export function savePendingPointPurchase(request: PendingPointPurchase) {
  const value = validate(request), existing = readPendingPointPurchase(value.account_id, value.game);
  if (existing) return existing;
  const { store, key } = storage(value.account_id, value.game), raw = JSON.stringify(value);
  store.setItem(key, raw);
  if (store.getItem(key) !== raw) throw new Error("Recovery write failed");
  return value;
}
export function clearPendingPointPurchase(request: PendingPointPurchase) {
  const pending = readPendingPointPurchase(request.account_id, request.game);
  if (pending === null) return true;
  if (JSON.stringify(pending) !== JSON.stringify(validate(request))) return false;
  const { store, key } = storage(request.account_id, request.game); store.removeItem(key);
  if (store.getItem(key) !== null) throw new Error("Recovery clear failed");
  return true;
}
export function receiptConfirmsPointPurchase(request: PendingPointPurchase, receipt: PointPurchaseReceipt | null) {
  return !!receipt && receipt.account_id === request.account_id && receipt.game === request.game && receipt.request_id === request.request_id
    && receipt.currency === "USD" && receipt.quote_version === request.quote_version && receipt.points === request.points
    && receipt.price_per_point_minor === request.price_per_point_minor && receipt.money_spent_minor === request.expected_money_minor
    && receipt.money_delta_minor === -request.expected_money_minor && receipt.point_delta === request.points
    && Number.isSafeInteger(receipt.money_bill_id) && receipt.money_bill_id > 0 && Number.isSafeInteger(receipt.point_bill_id) && receipt.point_bill_id > 0;
}
