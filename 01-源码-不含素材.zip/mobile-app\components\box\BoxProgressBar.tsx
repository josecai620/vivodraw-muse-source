import React, { useEffect } from "react";
import { View, type ViewStyle } from "react-native";
import Animated, {
  useSharedValue, useAnimatedStyle, withTiming, withDelay,
  Easing,
} from "react-native-reanimated";
import { BoxSurfaces, BoxRadius, BoxShadows, getRarityTier, bs } from "@/lib/boxTheme";

interface BoxProgressBarProps {
  progress: number;
  color?: string;
  tier?: string;
  size?: "compact" | "standard" | "prominent";
  glow?: boolean;
  delay?: number;
  style?: ViewStyle;
}

const SIZE_MAP = { compact: 4, standard: 8, prominent: 12 };

export function BoxProgressBar({
  progress,
  color,
  tier,
  size = "standard",
  glow = false,
  delay = 0,
  style,
}: BoxProgressBarProps) {
  const fillWidth = useSharedValue(0);
  const rarity = tier ? getRarityTier(tier) : null;
  const barColor = color ?? rarity?.color ?? "#04A8AE";
  const h = SIZE_MAP[size];

  useEffect(() => {
    fillWidth.value = withDelay(
      delay,
      withTiming(Math.min(Math.max(progress, 0), 100), {
        duration: 600,
        easing: Easing.out(Easing.cubic),
      })
    );
  }, [progress, delay]);

  const fillStyle = useAnimatedStyle(() => ({
    width: `${fillWidth.value}%`,
  }));

  return (
    <View style={[{
      height: h,
      borderRadius: h,
      backgroundColor: BoxSurfaces.elevated,
      overflow: "hidden",
    }, style]}>
      <Animated.View
        style={[
          {
            height: "100%",
            borderRadius: h,
            backgroundColor: barColor,
            ...(glow ? BoxShadows.glow(barColor) : {}),
          },
          fillStyle,
        ]}
      />
    </View>
  );
}
