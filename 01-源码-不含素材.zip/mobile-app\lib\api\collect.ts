import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

export function getCollectList(params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.collect.list, { params });
}

export function addCollect(data: { id: number; category?: string }) {
  return http.post(API_ENDPOINTS.collect.add, data);
}

export function delCollect(data: { id: number; category?: string }) {
  return http.post(API_ENDPOINTS.collect.del, data);
}
