// One-off checker: find root-absolute resource refs missing the /v4 base prefix.
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, 'dist-v4');
let bad = [];
let v4Count = 0;
let files = 0;

function walk(d) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, e.name);
    if (e.isDirectory()) {
      walk(p);
    } else if (/\.(html|js|css)$/.test(e.name)) {
      files++;
      const c = fs.readFileSync(p, 'utf8');
      const re = /(?<!\/v4)(["'(])(\/_expo|\/assets)\//g;
      let m;
      while ((m = re.exec(c))) {
        if (bad.length < 40) {
          bad.push(p.replace(root, '') + '  ->  ' + m[0]);
        }
      }
      v4Count += (c.match(/\/v4\/_expo\//g) || []).length;
    }
  }
}

walk(root);
console.log('scanned files:', files);
console.log('prefixed /v4/_expo/ refs:', v4Count);
console.log('suspect bare-root refs:', bad.length);
bad.forEach((b) => console.log('  ' + b));
