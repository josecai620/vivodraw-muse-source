import { PageHeader } from "@/components/shared";
import { USE_DEV_MOCK_DATA } from "@/constants/env";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import { getOrderList } from "@/lib/api/order";
import type { OrderItem } from "@/lib/api/order";
import { unwrapApiPagedList } from "@/lib/api/response";
import { formatPrice, normalizeImageUrl } from "@/lib/utils";
import { useAuthStore } from "@/store/auth";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { ChevronRight, Package } from "lucide-react-native";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Image,
  Pressable,
  RefreshControl,
  ScrollView,
  Text,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

const MOCK_ORDERS: OrderItem[] = [
  {
    order_id: "ORD-2026-001",
    total_num: 1,
    total_price: "449.98",
    pay_price: "449.98",
    paid: 1,
    status: 3,
    refund_status: 0,
    create_time: "2026-03-05",
    _status: { _type: 3, _title: "Delivered", _msg: "" },
    cartInfo: [
      {
        productInfo: {
          image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200",
          store_name: "Wireless Headphones",
          price: "449.98",
        },
        cart_num: 1,
      },
    ],
  },
  {
    order_id: "ORD-2026-002",
    total_num: 1,
    total_price: "299.99",
    pay_price: "299.99",
    paid: 1,
    status: 1,
    refund_status: 0,
    create_time: "2026-03-04",
    _status: { _type: 1, _title: "Shipping", _msg: "" },
    cartInfo: [
      {
        productInfo: {
          image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200",
          store_name: "Smart Watch",
          price: "299.99",
        },
        cart_num: 1,
      },
    ],
  },
  {
    order_id: "ORD-2026-003",
    total_num: 2,
    total_price: "99.98",
    pay_price: "99.98",
    paid: 0,
    status: 0,
    refund_status: 0,
    create_time: "2026-03-03",
    _status: { _type: 0, _title: "Pending", _msg: "" },
    cartInfo: [
      {
        productInfo: {
          image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=200",
          store_name: "Laptop Bag",
          price: "49.99",
        },
        cart_num: 2,
      },
    ],
  },
];

function getStatusColor(type: number): string {
  if (type === 0) return Colors.accent.orange;
  if (type === 1) return Colors.info;
  if (type === 2) return Colors.ios.green;
  if (type === 3) return Colors.success;
  if (type < 0) return Colors.error;
  return Colors.neutral[500];
}

export default function OrdersScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const { isLoggedIn, isHydrated } = useAuthStore();
  const TABS = [
    { id: "all", label: t("shopOrders.all"), type: -1 },
    { id: "pending", label: t("shopOrders.pending"), type: 0 },
    { id: "shipped", label: t("shopOrders.shipped"), type: 1 },
    { id: "received", label: t("shopOrders.received"), type: 2 },
    { id: "reviewed", label: t("shopOrders.reviewed"), type: 3 },
  ] as const;
  const [activeTab, setActiveTab] = useState<(typeof TABS)[number]["id"]>("all");

  const type = TABS.find((tab) => tab.id === activeTab)?.type ?? -1;
  const shouldFetch = isLoggedIn && isHydrated;

  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);
  const onRefresh = async () => {
    setRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ["orderList", type] });
    setRefreshing(false);
  };

  const { data, isLoading } = useQuery({
    queryKey: ["orderList", type],
    queryFn: () => getOrderList({ type, page: 1, limit: 20 }),
    enabled: shouldFetch,
  });

  const list = unwrapApiPagedList<OrderItem>(data);
  const mockOrders =
    type === -1 ? MOCK_ORDERS : MOCK_ORDERS.filter((order) => order._status?._type === type);
  const displayOrders = list.length > 0 ? list : USE_DEV_MOCK_DATA ? mockOrders : [];

  if (isHydrated && !isLoggedIn) {
    return (
      <View style={{ flex: 1, backgroundColor: Colors.neutral[50] }}>
        <PageHeader title={t("shopOrders.title")} />
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: s(24) }}>
          <Package size={s(48)} color={Colors.neutral[300]} />
          <Text
            style={{
              fontSize: s(18),
              fontWeight: "700",
              color: Colors.neutral[900],
              marginTop: s(16),
            }}
          >
            {t("cart.pleaseSignIn")}
          </Text>
          <Text
            style={{
              fontSize: s(14),
              color: Colors.neutral[500],
              marginTop: s(8),
              textAlign: "center",
            }}
          >
            {t("cart.signInToView")}
          </Text>
          <Pressable
            onPress={() => router.push("/auth")}
            style={{
              marginTop: s(20),
              height: s(44),
              paddingHorizontal: s(24),
              borderRadius: s(12),
              alignItems: "center",
              justifyContent: "center",
              }}
          >
            <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
            <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
            <Text style={{ color: Colors.neutral[0], fontWeight: "700" }}>{t("cart.signIn")}</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: Colors.neutral[50] }}>
      <PageHeader title={t("shopOrders.title")} />
      <View
        style={{
          backgroundColor: Colors.neutral[0],
          borderBottomWidth: 1,
          borderBottomColor: Colors.neutral[200],
        }}
      >
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: s(16), paddingBottom: s(12) }}
        >
          {TABS.map((tab) => (
            <Pressable
              key={tab.id}
              onPress={() => setActiveTab(tab.id)}
              style={{
                marginRight: s(8),
                paddingHorizontal: s(16),
                height: s(32),
                borderRadius: s(16),
                backgroundColor: activeTab === tab.id ? Colors.brand.red : Colors.neutral[100],
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  fontSize: s(14),
                  fontWeight: "500",
                  color: activeTab === tab.id ? Colors.neutral[0] : Colors.neutral[600],
                }}
              >
                {tab.label}
              </Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: s(16), paddingBottom: s(32) }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#04A8AE" />
        }
      >
        {isLoading ? (
          <View style={{ paddingVertical: s(48), alignItems: "center" }}>
            <ActivityIndicator size="large" color={Colors.brand.red} />
          </View>
        ) : displayOrders.length === 0 ? (
          <View style={{ alignItems: "center", paddingVertical: s(48) }}>
            <Package size={s(48)} color={Colors.neutral[300]} />
            <Text
              style={{
                fontSize: s(18),
                fontWeight: "700",
                color: Colors.neutral[900],
                marginTop: s(16),
              }}
            >
              {t("shopOrders.noOrders")}
            </Text>
          </View>
        ) : (
          displayOrders.map((order) => {
            const statusColor = getStatusColor(order._status?._type ?? 0);
            const statusTitle = order._status?._title ?? "Unknown";
            const images =
              order.cartInfo
                ?.map((c) => normalizeImageUrl(c?.productInfo?.image))
                .filter(Boolean) ?? [];

            return (
              <Pressable
                key={order.order_id}
                onPress={() => router.push(`/orders/detail?id=${order.order_id}`)}
                style={{
                  backgroundColor: Colors.neutral[0],
                  borderRadius: s(16),
                  borderWidth: 1,
                  borderColor: Colors.neutral[100],
                  marginBottom: s(12),
                  overflow: "hidden",
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    paddingHorizontal: s(16),
                    paddingVertical: s(12),
                    borderBottomWidth: 1,
                    borderBottomColor: Colors.neutral[100],
                  }}
                >
                  <View>
                    <Text
                      style={{ fontSize: s(14), fontWeight: "600", color: Colors.neutral[900] }}
                    >
                      {order.order_id}
                    </Text>
                    <Text style={{ fontSize: s(12), color: Colors.neutral[500], marginTop: 2 }}>
                      {order.create_time}
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      paddingHorizontal: s(10),
                      paddingVertical: s(4),
                      borderRadius: s(16),
                      backgroundColor: `${statusColor}20`,
                    }}
                  >
                    <Text style={{ fontSize: s(12), fontWeight: "600", color: statusColor }}>
                      {statusTitle}
                    </Text>
                  </View>
                </View>

                <View
                  style={{ flexDirection: "row", alignItems: "center", padding: s(16), gap: s(8) }}
                >
                  {images.slice(0, 4).map((uri, i) => (
                    <Image
                      key={`${order.order_id}-${uri}-${i}`}
                      source={{ uri }}
                      style={{ width: s(56), height: s(56), borderRadius: s(12) }}
                      resizeMode="cover"
                    />
                  ))}
                </View>

                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    paddingHorizontal: s(16),
                    paddingVertical: s(12),
                    borderTopWidth: 1,
                    borderTopColor: Colors.neutral[100],
                  }}
                >
                  <View>
                    <Text style={{ fontSize: s(12), color: Colors.neutral[500] }}>
                      {t("shopOrders.total")}
                    </Text>
                    <Text
                      style={{ fontSize: s(18), fontWeight: "700", color: Colors.neutral[900] }}
                    >
                      {formatPrice(order.pay_price)}
                    </Text>
                  </View>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
                    <Text style={{ fontSize: s(14), color: Colors.brand.red, fontWeight: "500" }}>
                      {t("shopOrders.details")}
                    </Text>
                    <ChevronRight size={s(16)} color={Colors.brand.red} />
                  </View>
                </View>
              </Pressable>
            );
          })
        )}
      </ScrollView>
    </View>
  );
}
