import { HtmlContent, PageHeader, PriceDisplay } from "@/components/shared";
import { Colors, s, Shadows } from "@/constants/theme";
import TealSurface from "@/components/ui/TealSurface";
import { useAddToCart, useAddToCartAndCheckout, useProductDetail } from "@/hooks";
import { type DiscountProduct, getDiscountsList } from "@/lib/api/discounts";
import type {
  ProductAttr,
  ProductDetail,
  ProductDetailPayload,
  ProductSku,
  ProductSkuMap,
} from "@/lib/api/product";
import { isApiRecord, unwrapApiData, unwrapApiListField } from "@/lib/api/response";
import { useTranslation } from "react-i18next";
import { normalizeImageUrl } from "@/lib/utils";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import { useQuery } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import {
  Gift,
  Heart,
  Image as ImageIcon,
  Minus,
  Plus,
  RotateCcw,
  Share2,
  Shield,
  ShoppingCart,
  Star,
  Truck,
  Zap,
} from "lucide-react-native";
import React, { useCallback, useRef, useState } from "react";
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  Image,
  Pressable,
  ScrollView,
  Share,
  Text,
  View,
  type ViewToken,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const features = [
  { Icon: Shield, text: "Warranty" },
  { Icon: Truck, text: "Free Ship" },
  { Icon: RotateCcw, text: "30-Day Return" },
];

function normalizeProductValue(value: ProductDetail["productValue"]): ProductSkuMap {
  if (!value) return {};
  if (!Array.isArray(value)) return value;

  return value.reduce<ProductSkuMap>((result, sku) => {
    const key = sku.suk ?? sku.unique;
    if (key) result[String(key)] = sku;
    return result;
  }, {});
}

function normalizeProductDetail(value: unknown): ProductDetail | null {
  const payload = unwrapApiData<ProductDetailPayload | ProductDetail | null>(value, null);
  if (!payload || !isApiRecord(payload)) return null;
  const detailPayload = payload as ProductDetailPayload;

  if (isApiRecord(detailPayload.storeInfo)) {
    const storeInfo = detailPayload.storeInfo as unknown as ProductDetail;
    return {
      ...storeInfo,
      productAttr: storeInfo.productAttr ?? detailPayload.productAttr ?? [],
      productValue: normalizeProductValue(storeInfo.productValue ?? detailPayload.productValue),
    };
  }

  const product = payload as unknown as ProductDetail;
  return {
    ...product,
    productAttr: product.productAttr ?? [],
    productValue: normalizeProductValue(product.productValue),
  };
}

function getAttrValues(attr: ProductAttr): string[] {
  const raw = attr.attr_values ?? attr.attr_value ?? [];
  const values = Array.isArray(raw) ? raw : String(raw).split(",");
  return values.map((value) => value.trim()).filter(Boolean);
}

function numberValue(value: unknown, fallback = 0): number {
  const next = Number(value);
  return Number.isFinite(next) ? next : fallback;
}

export default function ProductDetailScreen() {
  const { t } = useTranslation();
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const productId = Number(id) || 0;

  const isLoggedIn = useAuthStore((st) => st.isLoggedIn);
  const showToast = useAppStore((s) => s.showToast);
  const addToCart = useAddToCart();
  const buyNow = useAddToCartAndCheckout();

  const { data: productRaw, isLoading, isError } = useProductDetail(productId);
  const { data: discountsData } = useQuery({
    queryKey: ["discounts", productId],
    queryFn: () => getDiscountsList(productId),
    enabled: productId > 0,
  });
  const product = normalizeProductDetail(productRaw);

  const screenWidth = Dimensions.get("window").width;
  const [quantity, setQuantity] = useState(1);
  const [isFavorite, setIsFavorite] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [selectedAttrs, setSelectedAttrs] = useState<Record<string, string>>({});
  const flatListRef = useRef<FlatList>(null);

  const onViewableItemsChanged = useCallback(
    ({ viewableItems }: { viewableItems: ViewToken[] }) => {
      if (viewableItems.length > 0 && viewableItems[0].index != null) {
        setCurrentImageIndex(viewableItems[0].index);
      }
    },
    [],
  );
  const viewabilityConfig = useRef({ viewAreaCoveragePercentThreshold: 50 }).current;

  const sliderImages: string[] = product?.slider_image ?? product?.images ?? [];
  const mainImage = product?.image ?? "";
  const allImages = sliderImages.length > 0 ? sliderImages : mainImage ? [mainImage] : [];

  if (isLoading) {
    return (
      <View className="flex-1 items-center justify-center" style={{ backgroundColor: Colors.screen.bg }}>
        <ActivityIndicator size="large" color={Colors.brand.red} />
        <Text className="text-sm text-gray-400 mt-3">Loading product...</Text>
      </View>
    );
  }

  if (isError || !product) {
    return (
      <View className="flex-1 items-center justify-center px-6" style={{ backgroundColor: Colors.screen.bg }}>
        <Text className="text-lg font-semibold text-gray-700 mb-2">Product not found</Text>
        <Text className="text-sm text-gray-400 mb-6 text-center">
          This product may have been removed or is temporarily unavailable.
        </Text>
        <Pressable
          onPress={() => router.back()}
          style={({ pressed }) => [Shadows.teal, { transform: [{ scale: pressed ? 0.97 : 1 }] }]}
        >
          <TealSurface direction="tb" radius={12} style={{ alignSelf: "center" }} contentStyle={{ height: 44, paddingHorizontal: 24, alignItems: "center", justifyContent: "center" }}>
            <Text className="text-white font-semibold" style={{ backgroundColor: "transparent" }}>Go Back</Text>
          </TealSurface>
        </Pressable>
      </View>
    );
  }

  const attrs = product.productAttr ?? [];
  const attrValues = normalizeProductValue(product.productValue);

  const skuKey =
    attrs.length > 0 ? attrs.map((attr) => selectedAttrs[attr.attr_name] ?? "").join(",") : "";
  const selectedSku = skuKey && attrValues[skuKey] ? attrValues[skuKey] : null;
  const selectedUniqueId = selectedSku?.unique ?? "";
  const missingSkuSelection = attrs.length > 0 && (!skuKey || !selectedSku);
  const availableStock = numberValue(selectedSku?.stock ?? product.stock);

  const handleAddToCart = () => {
    if (!isLoggedIn) {
      router.push("/auth");
      return;
    }
    if (missingSkuSelection) {
      showToast("Please select product options", "error");
      return;
    }
    if (availableStock <= 0) {
      showToast("This product is out of stock", "error");
      return;
    }
    addToCart.mutate({
      productId,
      cartNum: quantity,
      uniqueId: selectedUniqueId || undefined,
    });
  };

  // 立即购买：is_new=1 走后端「直接下单」缓存，不写购物车表，随后直达结算
  const handleBuyNow = () => {
    if (!isLoggedIn) {
      router.push("/auth");
      return;
    }
    if (missingSkuSelection) {
      showToast("Please select product options", "error");
      return;
    }
    if (availableStock <= 0) {
      showToast("This product is out of stock", "error");
      return;
    }
    buyNow.mutate({
      productId,
      cartNum: quantity,
      uniqueId: selectedUniqueId || undefined,
      is_new: 1,
    });
  };

  const price = selectedSku ? numberValue(selectedSku.price) : numberValue(product.price);
  const otPrice = selectedSku
    ? numberValue(selectedSku.ot_price, numberValue(product.ot_price))
    : numberValue(product.ot_price);
  const giftPts = numberValue(selectedSku?.give_integral ?? product.give_integral);
  const discountProducts = unwrapApiListField<DiscountProduct>(discountsData);

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader
        title="Product Detail"
        rightElement={
          <View className="flex-row items-center gap-1">
            <Pressable
              className="p-2"
              onPress={() => {
                Share.share({
                  message: `Check out ${product.store_name} - $${price}!`,
                  url: `https://shop.example.com/product/${productId}`,
                }).catch(() => {});
              }}
            >
              <Share2 size={s(20)} color={Colors.neutral[700]} />
            </Pressable>
            <Pressable className="p-2" onPress={() => router.push("/(tabs)/cart")}>
              <ShoppingCart size={s(20)} color={Colors.neutral[700]} />
            </Pressable>
          </View>
        }
      />

      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Image Gallery — swipeable */}
        <View className="relative" style={{ width: screenWidth, height: screenWidth }}>
          {allImages.length > 0 ? (
            <FlatList
              ref={flatListRef}
              data={allImages}
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              keyExtractor={(item, index) => `${item}-${index}`}
              onViewableItemsChanged={onViewableItemsChanged}
              viewabilityConfig={viewabilityConfig}
              getItemLayout={(_, index) => ({
                length: screenWidth,
                offset: screenWidth * index,
                index,
              })}
              renderItem={({ item }) => (
                <Image
                  source={{ uri: normalizeImageUrl(item) }}
                  style={{ width: screenWidth, height: screenWidth }}
                  resizeMode="cover"
                />
              )}
            />
          ) : (
            <View className="w-full h-full items-center justify-center bg-gray-100">
              <ImageIcon size={44} color={Colors.neutral[300]} strokeWidth={1.6} />
            </View>
          )}

          <Pressable
            onPress={() => setIsFavorite(!isFavorite)}
            className="absolute top-4 right-4 w-10 h-10 bg-white/90 rounded-full items-center justify-center"
          >
            <Heart
              size={20}
              color={isFavorite ? Colors.brand.red : Colors.neutral[700]}
              fill={isFavorite ? Colors.brand.red : "none"}
            />
          </Pressable>

          {allImages.length > 1 && (
            <View
              className="absolute bottom-4 right-4 rounded-full px-3 py-1"
              style={{ backgroundColor: "rgba(0,0,0,0.45)" }}
            >
              <Text className="text-white font-semibold" style={{ fontSize: 12 }}>
                {currentImageIndex + 1} / {allImages.length}
              </Text>
            </View>
          )}

          {product.is_hot === 1 && (
            <View
              className="absolute top-4 left-4 px-3 py-1.5 rounded-full"
              style={{ backgroundColor: Colors.brand.red }}
            >
              <Text className="text-white text-xs font-bold">HOT SALE</Text>
            </View>
          )}
        </View>

        {/* Product Info */}
        <View
          className="mx-4 mt-4 px-4 py-5 rounded-3xl"
          style={[
            {
              backgroundColor: Colors.screen.card,
              borderWidth: 1,
              borderColor: Colors.screen.hairline,
            },
            Shadows.raisedSm,
          ]}
        >
          <Text className="text-xl font-bold text-gray-900 mb-2">{product.store_name}</Text>

          {product.store_info ? (
            <Text className="text-sm text-gray-500 mb-3">{product.store_info}</Text>
          ) : null}

          <View className="flex-row items-center gap-2 mb-3">
            <Star size={14} fill={Colors.primary.DEFAULT} color={Colors.primary.DEFAULT} />
            <Text className="text-sm font-semibold text-gray-900">4.8</Text>
            <Text className="text-sm text-gray-500">({product.sales ?? 0} sold)</Text>
          </View>

          <View className="mb-5">
            <PriceDisplay price={price} originalPrice={otPrice} size="lg" />
          </View>

          {giftPts > 0 && (
            <View
              className="mb-4 px-3 py-2.5 rounded-xl"
              style={{ backgroundColor: "#ECFBFB", borderWidth: 1, borderColor: "rgba(4,168,174,0.2)" }}
            >
              <View className="flex-row items-center">
                <Gift size={18} color="#04A8AE" />
                <Text className="ml-2 font-semibold" style={{ color: "#171A1A", fontSize: 14 }}>
                  {t("productGift.amount", { points: giftPts })}
                </Text>
              </View>
              <Text className="mt-1" style={{ color: "#4B5563", fontSize: 12 }}>
                {t("productGift.description")}
              </Text>
            </View>
          )}

          {attrs.length > 0 && (
            <View className="mb-5">
              {attrs.map((attr) => {
                const values = getAttrValues(attr);
                return (
                  <View key={attr.attr_name} className="mb-3">
                    <Text className="text-sm font-semibold text-gray-900 mb-2">
                      {attr.attr_name}
                    </Text>
                    <View className="flex-row flex-wrap gap-2">
                      {values.map((trimmed) => {
                        const isSelected = selectedAttrs[attr.attr_name] === trimmed;
                        return (
                          <Pressable
                            key={trimmed}
                            className="px-4 py-2 rounded-lg"
                            style={{
                              backgroundColor: isSelected
                                ? `${Colors.brand.red}10`
                                : Colors.neutral[50],
                              borderWidth: 1.5,
                              borderColor: isSelected ? Colors.brand.red : Colors.neutral[200],
                            }}
                            onPress={() =>
                              setSelectedAttrs((prev) => ({ ...prev, [attr.attr_name]: trimmed }))
                            }
                          >
                            <Text
                              className="text-sm"
                              style={{ color: isSelected ? Colors.brand.red : Colors.neutral[700] }}
                            >
                              {trimmed}
                            </Text>
                          </Pressable>
                        );
                      })}
                    </View>
                  </View>
                );
              })}
            </View>
          )}

          <View className="flex-row gap-2 mb-6">
            {features.map((item) => (
              <View
                key={item.text}
                className="flex-1 flex-row items-center gap-2 px-3 py-2 bg-gray-50 rounded-lg"
              >
                <item.Icon size={16} color={Colors.neutral[600]} />
                <Text className="text-xs text-gray-700">{item.text}</Text>
              </View>
            ))}
          </View>

          {/* Stock & Unit */}
          <View className="flex-row items-center gap-4 mb-4 px-3 py-2 bg-gray-50 rounded-lg">
            <Text className="text-sm text-gray-600">
              Stock: <Text className="font-semibold text-gray-900">{availableStock}</Text>
            </Text>
            {product.unit_name && (
              <Text className="text-sm text-gray-600">
                Unit: <Text className="font-semibold text-gray-900">{product.unit_name}</Text>
              </Text>
            )}
          </View>

          {discountProducts.length > 0 && (
            <View className="mb-5">
              <Text className="text-base font-semibold text-gray-900 mb-3">Bundle Deals</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} className="-mx-4 px-4">
                {discountProducts.slice(0, 5).map((combo) => {
                  const pid = combo.product_id ?? combo.id ?? 0;
                  const img = combo.image ?? combo.pic ?? "";
                  const name = combo.store_name ?? combo.title ?? "";
                  const comboPrice = combo.price ?? combo.discount_price ?? "0";
                  return (
                    <Pressable
                      key={pid}
                      onPress={() => pid && router.push(`/product/${pid}`)}
                      className="w-28 mr-3"
                    >
                      <View className="bg-gray-50 rounded-xl overflow-hidden">
                        {img ? (
                          <Image
                            source={{ uri: normalizeImageUrl(img) }}
                            className="w-full h-24"
                            resizeMode="cover"
                          />
                        ) : (
                          <View className="w-full h-24 bg-gray-200 items-center justify-center">
                            <ImageIcon size={26} color={Colors.neutral[400]} strokeWidth={1.8} />
                          </View>
                        )}
                      </View>
                      <Text
                        className="text-xs mt-1 font-medium"
                        style={{ color: Colors.neutral[800] }}
                        numberOfLines={2}
                      >
                        {name}
                      </Text>
                      <Text className="text-sm font-bold" style={{ color: Colors.brand.red }}>
                        ${comboPrice}
                      </Text>
                    </Pressable>
                  );
                })}
              </ScrollView>
            </View>
          )}

          {/* Description */}
          <Text className="text-base font-semibold text-gray-900 mb-3">Description</Text>
          {(() => {
            const desc = product.description || product.store_info || "";
            const isHtml = /<[a-z][\s\S]*>/i.test(desc);
            if (isHtml) {
              return <HtmlContent html={desc} />;
            }
            return (
              <Text className="text-sm text-gray-600 leading-relaxed">
                {desc || "No description available."}
              </Text>
            );
          })()}
        </View>

        <View className="h-24" />
      </ScrollView>

      {/* Bottom Bar */}
      <View
        className="absolute bottom-0 left-0 right-0 px-4 py-3"
        style={{
          paddingBottom: insets.bottom + 12,
          backgroundColor: "#FFFFFF",
          borderTopWidth: 1,
          borderTopColor: Colors.screen.hairline,
          shadowColor: "#0C1F1F",
          shadowOffset: { width: 0, height: -6 },
          shadowOpacity: 0.06,
          shadowRadius: 16,
          elevation: 12,
        }}
      >
        <View className="flex-row items-center gap-2">
          <View className="flex-row items-center gap-1.5 px-2.5 py-2 bg-gray-100 rounded-lg">
            <Pressable onPress={() => setQuantity(Math.max(1, quantity - 1))}>
              <Minus size={16} color={Colors.neutral[700]} />
            </Pressable>
            <Text className="w-6 text-center font-semibold text-sm">{quantity}</Text>
            <Pressable
              onPress={() => setQuantity(Math.min(quantity + 1, Math.max(1, availableStock)))}
            >
              <Plus size={16} color={Colors.neutral[700]} />
            </Pressable>
          </View>

          {/* 加入购物车：次要按钮，白底描边 */}
          <Pressable
            onPress={handleAddToCart}
            accessibilityRole="button"
            accessibilityLabel="Add to Cart"
            disabled={addToCart.isPending || buyNow.isPending || availableStock <= 0}
            style={({ pressed }) => [{ width: 76, height: 48, flexShrink: 0, opacity: addToCart.isPending || availableStock <= 0 ? 0.7 : 1, transform: [{ scale: pressed ? 0.97 : 1 }] }]}
          >
            <View
              style={{
                height: 48,
                borderRadius: 12,
                borderWidth: 1.5,
                borderColor: Colors.primary.DEFAULT,
                backgroundColor: "#FFFFFF",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                gap: 2,
              }}
            >
              <ShoppingCart size={s(17)} color={Colors.primary.DEFAULT} />
              <Text numberOfLines={1} style={{ color: Colors.primary.DEFAULT, fontWeight: "600", fontSize: 10 }}>
                {addToCart.isPending ? "Adding..." : "Add to Cart"}
              </Text>
            </View>
          </Pressable>

          {/* 立即购买：主按钮，直连结算下单 */}
          <Pressable
            onPress={handleBuyNow}
            accessibilityRole="button"
            accessibilityLabel="Buy Now"
            disabled={buyNow.isPending || addToCart.isPending || availableStock <= 0}
            style={({ pressed }) => [Shadows.teal, { flex: 1, height: 48, borderRadius: 12, opacity: buyNow.isPending || availableStock <= 0 ? 0.7 : 1, transform: [{ scale: pressed ? 0.97 : 1 }] }]}
          >
            <TealSurface direction="lr" radius={12} style={{ height: 48 }} contentStyle={{ height: 48, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 }}>
              <Zap size={s(17)} color="#FFFFFF" />
              <Text numberOfLines={1} className="text-white font-semibold" style={{ backgroundColor: "transparent", fontSize: 15 }}>
                {buyNow.isPending ? "Processing..." : "Buy Now"}
              </Text>
            </TealSurface>
          </Pressable>
        </View>
      </View>
    </View>
  );
}
