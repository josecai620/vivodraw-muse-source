import { oreCommonPreset } from './ore.common';
import { oreEpicPreset } from './ore.epic';
import { oreFirePreset } from './ore.fire';
import { oreLegendaryPreset } from './ore.legendary';
import { oreRarePreset } from './ore.rare';
import type { VFXPresetConfig, VFXRarity } from '../core/VFXConfig';

export const oreVFXPresets: Record<VFXRarity, VFXPresetConfig> = { // oreVFXPresets：矿石特效预设表
  common: oreCommonPreset,
  rare: oreRarePreset,
  epic: oreEpicPreset,
  legendary: oreLegendaryPreset,
  fire: oreFirePreset,
};

export const oreVFXPresetList = Object.values(oreVFXPresets); // oreVFXPresetList：预设列表
