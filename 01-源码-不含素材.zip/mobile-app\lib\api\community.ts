import { fetchAuthFormData, fetchAuthPost, fetchReadApi, normalizeRemoteImage, type ApiWriteResult } from "@/lib/api/legacyHttp";

export type CommunityPost = {
  id: string;
  title: string;
  content: string;
  image: string;
  images: string[];
  author: string;
  avatar?: string;
  productId?: string;
  productName: string;
  createdAt: string;
  likes: number;
  comments: number;
  views: number;
  isLiked: boolean;
  status?: number;
  statusLabel?: string;
  share?: CommunitySharePayload;
};

export type CommunitySharePayload = {
  title: string;
  text: string;
  description?: string;
  url: string;
  image?: string;
  images?: string[];
  platforms?: {
    facebook?: string;
    whatsapp?: string;
    instagram?: { direct?: boolean; fallback?: string; note?: string } | string;
    copy?: { method?: string; url?: string } | string;
    other?: Record<string, unknown>;
  };
};

export type CommunityShareTrackResult = {
  rewardPoints?: number | string;
  reward_points?: number | string;
};

export type CommunityComment = {
  id: string;
  author: string;
  avatar?: string;
  content: string;
  createdAt: string;
};

export type CommunityDraftTarget = {
  id: string;
  productName: string;
  image: string;
  openedAt: string;
  canPost: boolean;
};

export type CommunityFeedModel = {
  source: "api" | "fallback";
  posts: CommunityPost[];
  notice?: string;
};

export type CommunityDetailModel = {
  source: "api" | "fallback";
  post?: CommunityPost;
  comments: CommunityComment[];
  notice?: string;
};

export type CommunityComposerModel = {
  source: "api" | "fallback";
  targets: CommunityDraftTarget[];
  existingPosts: CommunityPost[];
  notice?: string;
};

export type CommunityImageUpload = {
  name?: string;
  url?: string;
};

type RemotePost = Record<string, unknown>;
type RemoteComment = Record<string, unknown>;
type RemoteTarget = Record<string, unknown>;

export async function fetchCommunityFeed(): Promise<CommunityFeedModel> {
  const payload = await fetchReadApi<unknown>("/api/community/posts?page=1&limit=20");
  if (payload !== undefined) {
    const posts = toList(payload).map(normalizePost).filter(Boolean) as CommunityPost[];

    return {
      source: "api",
      posts,
      notice: posts.length ? "Community posts are loaded." : "No community posts yet.",
    };
  }

  const legacyPayload = await fetchReadApi<unknown>("/api/integral/shaidan_lists?page=1&limit=20");
  const posts = toList(legacyPayload).map(normalizePost).filter(Boolean) as CommunityPost[];

  if (legacyPayload !== undefined) {
    return {
      source: "api",
      posts,
      notice: posts.length ? "Community posts are loaded." : "No community posts yet.",
    };
  }

  return {
    source: "fallback",
    posts: [],
    notice: "Sign in or refresh to load community posts.",
  };
}

export async function fetchCommunitySharePayload(id: string): Promise<CommunitySharePayload | undefined> {
  const payload = await fetchReadApi<unknown>(`/api/community/posts/${encodeURIComponent(id)}/share`);
  return normalizeSharePayload(payload);
}

export async function trackCommunityShare(postId: string, platform: string) {
  return fetchAuthPost<CommunityShareTrackResult>("/api/community/share/track", { postId, platform });
}

export async function fetchCommunityDetail(id: string): Promise<CommunityDetailModel> {
  const safeId = encodeURIComponent(id);
  const [detailPayload, commentsPayload] = await Promise.all([
    fetchReadApi<unknown>(`/api/community/posts/${safeId}`),
    fetchReadApi<unknown>(`/api/community/posts/${safeId}/comments?page=1&limit=30`),
  ]);
  const detailRecord = unwrapRecord(detailPayload);
  const post = detailRecord ? normalizePost(detailRecord, 0) : undefined;
  const comments = toList(commentsPayload).map(normalizeComment).filter(Boolean) as CommunityComment[];
  const hasPayload = detailPayload !== undefined || commentsPayload !== undefined;

  if (hasPayload) {
    return {
      source: "api",
      post,
      comments,
      notice: "Conversation and comments are loaded.",
    };
  }

  return fetchLegacyCommunityDetail(safeId);
}

async function fetchLegacyCommunityDetail(safeId: string): Promise<CommunityDetailModel> {
  const [detailPayload, commentsPayload] = await Promise.all([
    fetchReadApi<unknown>(`/api/integral/shaidan_detail?shaidan_id=${safeId}`),
    fetchReadApi<unknown>(`/api/integral/shaidan_detail_pinglun?shaidan_id=${safeId}&page=1&limit=30`),
  ]);
  const detailRecord = unwrapRecord(detailPayload);
  const post = detailRecord ? normalizePost(detailRecord, 0) : undefined;
  const comments = toList(commentsPayload).map(normalizeComment).filter(Boolean) as CommunityComment[];
  const hasPayload = detailPayload !== undefined || commentsPayload !== undefined;

  return {
    source: hasPayload ? "api" : "fallback",
    post,
    comments,
    notice: hasPayload ? "Conversation and comments are loaded." : "Community detail is not available yet.",
  };
}

export async function fetchCommunityComposer(): Promise<CommunityComposerModel> {
  const payload = await fetchReadApi<unknown>("/api/community/composer");
  if (payload !== undefined) {
    return normalizeComposerModel(payload);
  }

  const legacyPayload = await fetchReadApi<unknown>("/api/integral/user_shaidan_lists?page=1&limit=20");
  if (legacyPayload !== undefined) {
    return normalizeComposerModel(legacyPayload);
  }

  return {
    source: "fallback",
    targets: [],
    existingPosts: [],
    notice: "Sign in to share your reward photo.",
  };
}

function normalizeComposerModel(payload: unknown): CommunityComposerModel {
  const record = payload && typeof payload === "object" ? (payload as Record<string, unknown>) : {};
  const targets = readNamedList(record, ["targets", "huande_lists", "awards", "wait_lists"])
    .map(normalizeTarget)
    .filter(Boolean) as CommunityDraftTarget[];
  const existingPosts = readNamedList(record, ["lists", "list", "posts", "data"])
    .map(normalizePost)
    .filter(Boolean) as CommunityPost[];

  return {
    source: "api",
    targets,
    existingPosts,
    notice: targets.length ? "Choose a reward record to post." : "No eligible reward record is ready for sharing.",
  };
}

export async function toggleCommunityLike(id: string, productId?: string) {
  const result = await fetchAuthPost<unknown>(`/api/community/posts/${encodeURIComponent(id)}/like`, { productId });
  if (result.ok || result.status) {
    return result;
  }

  const path = `/api/integral/shaidan_dianzhan?id=${encodeURIComponent(id)}${productId ? `&pid=${encodeURIComponent(productId)}` : ""}`;
  return fetchAuthPost<unknown>(path, {});
}

export async function addCommunityComment(id: string, content: string) {
  const result = await fetchAuthPost<unknown>(`/api/community/posts/${encodeURIComponent(id)}/comments`, { content });
  if (result.ok || result.status) {
    return result;
  }

  return fetchAuthPost<unknown>(
    `/api/integral/shaidan_add_pinglun?shaidan_id=${encodeURIComponent(id)}&content=${encodeURIComponent(content)}`,
    { content },
  );
}

export async function submitCommunityPost(input: {
  targetId: string;
  title: string;
  content: string;
  images: string[];
  postId?: string;
}): Promise<ApiWriteResult<unknown>> {
  const result = await fetchAuthPost<unknown>("/api/community/posts", input);
  if (result.ok || result.status) {
    return result;
  }

  const query = new URLSearchParams({
    id: input.targetId,
  });

  if (input.postId) {
    query.set("shaidan_id", input.postId);
  }

  return fetchAuthPost<unknown>(`/api/integral/shaidan_edit?${query.toString()}`, {
    title: input.title,
    content: input.content,
    images: input.images,
  });
}

export async function uploadCommunityImage(file: Blob & { name?: string }) {
  const formData = new FormData();
  formData.append("filename", file, file.name || `community-screenshot-${Date.now()}.png`);
  return fetchAuthFormData<CommunityImageUpload>("/api/upload/image", formData);
}

function normalizePost(item: unknown, index = 0): CommunityPost | undefined {
  if (!item || typeof item !== "object") return undefined;

  const record = item as RemotePost;
  const id = readString(record, ["id", "shaidan_id", "sid"], `post-${index}`);
  const images = normalizeImages(record);
  const productName = readString(record, ["productName", "store_name", "product_name", "title_name", "productTitle"], "Reward product");
  const status = readNumber(record, ["status"]);

  return {
    id,
    title: readString(record, ["title", "name"], productName),
    content: readString(record, ["content", "comment", "remark", "desc"], ""),
    image: images[0] || "",
    images,
    author: readString(record, ["nickname", "user_name", "author", "uid"], "Member"),
    avatar: normalizeRemoteImage(readString(record, ["avatar", "headimgurl"], "")),
    productId: readString(record, ["productId", "product_id", "pid", "store_product_id"], ""),
    productName,
    createdAt: formatTime(readFirst(record, ["createdAt", "add_time", "_add_time", "create_time", "created_at"])),
    likes: readNumber(record, ["dianzhan_num", "likes", "like_num", "praise"], 0),
    comments: readNumber(record, ["pinglun_num", "comments", "comment_num"], 0),
    views: readNumber(record, ["views", "views_num", "look", "visit"], 0),
    isLiked: Boolean(readFirst(record, ["isLiked", "is_dianzhan", "is_like", "liked"])),
    status,
    statusLabel: readString(record, ["statusLabel"], status === undefined ? "" : statusLabel(status)) || undefined,
    share: normalizeSharePayload(readFirst(record, ["share"])),
  };
}

function normalizeComment(item: unknown, index = 0): CommunityComment | undefined {
  if (!item || typeof item !== "object") return undefined;

  const record = item as RemoteComment;
  const content = readString(record, ["content", "comment", "message", "reply"], "");
  if (!content) return undefined;

  return {
    id: readString(record, ["id", "comment_id"], `comment-${index}`),
    author: readString(record, ["nickname", "user_name", "author", "uid"], "Member"),
    avatar: normalizeRemoteImage(readString(record, ["avatar", "headimgurl"], "")),
    content,
    createdAt: formatTime(readFirst(record, ["add_time", "_add_time", "create_time", "created_at"])),
  };
}

function normalizeTarget(item: unknown, index = 0): CommunityDraftTarget | undefined {
  if (!item || typeof item !== "object") return undefined;

  const record = item as RemoteTarget;
  const id = readString(record, ["id", "kaijiang_id", "log_id", "order_id"], "");
  if (!id) return undefined;

  return {
    id,
    productName: readString(record, ["store_name", "product_name", "title", "name"], `Reward record ${index + 1}`),
    image: normalizeRemoteImage(readString(record, ["image", "product_image", "pic", "cover"], "")),
    openedAt: formatTime(readFirst(record, ["zhongjiang_time", "add_time", "_add_time", "create_time"])),
    canPost: readFirst(record, ["can_post", "can_shaidan"]) !== false,
  };
}

function normalizeImages(record: RemotePost) {
  const raw = readFirst(record, ["shaidan_images", "images", "pics", "pic", "image", "product_image"]);
  const values = parseImageList(raw);
  const firstImage = readString(record, ["shaidan_image", "image", "pic"], "");
  const withFirst = firstImage ? [firstImage, ...values] : values;

  return Array.from(new Set(withFirst.map((image) => normalizeRemoteImage(image)).filter(Boolean)));
}

function normalizeSharePayload(payload: unknown): CommunitySharePayload | undefined {
  if (!payload || typeof payload !== "object") return undefined;

  const record = payload as Record<string, unknown>;
  const title = readString(record, ["title"], "");
  const text = readString(record, ["text", "description"], "");
  const url = readString(record, ["url"], "");
  if (!title && !text && !url) return undefined;

  return {
    title,
    text,
    description: readString(record, ["description"], ""),
    url,
    image: normalizeRemoteImage(readString(record, ["image"], "")),
    images: parseImageList(readFirst(record, ["images"])).map((image) => normalizeRemoteImage(image)).filter(Boolean),
    platforms: typeof record.platforms === "object" && record.platforms ? record.platforms as CommunitySharePayload["platforms"] : undefined,
  };
}

function parseImageList(raw: unknown): string[] {
  if (Array.isArray(raw)) {
    return raw.map((value) => String(value || "").trim()).filter(Boolean);
  }

  if (typeof raw !== "string") {
    return [];
  }

  const value = raw.trim();
  if (!value) return [];

  try {
    const parsed = JSON.parse(value) as unknown;
    if (Array.isArray(parsed)) {
      return parsed.map((image) => String(image || "").trim()).filter(Boolean);
    }
  } catch {
    // Legacy APIs also return comma separated image strings.
  }

  return value.split(",").map((image) => image.trim()).filter(Boolean);
}

function unwrapRecord(payload: unknown): Record<string, unknown> | undefined {
  if (!payload || typeof payload !== "object") return undefined;
  const record = payload as Record<string, unknown>;
  const candidates = [record.detail, record.info, record.data, record];
  return candidates.find((item) => item && typeof item === "object" && !Array.isArray(item)) as Record<string, unknown> | undefined;
}

function toList(payload: unknown): unknown[] {
  if (Array.isArray(payload)) return payload;
  if (!payload || typeof payload !== "object") return [];
  return readNamedList(payload as Record<string, unknown>, ["lists", "list", "data", "result", "rows", "items"]);
}

function readNamedList(record: Record<string, unknown>, keys: string[]): unknown[] {
  for (const key of keys) {
    const value = record[key];
    if (Array.isArray(value)) return value;
    if (value && typeof value === "object") {
      const nested: unknown[] = readNamedList(value as Record<string, unknown>, ["lists", "list", "data", "items"]);
      if (nested.length) return nested;
    }
  }
  return [];
}

function readFirst(record: Record<string, unknown>, keys: string[]) {
  for (const key of keys) {
    const value = record[key];
    if (value !== undefined && value !== null && value !== "") return value;
  }
  return undefined;
}

function readString(record: Record<string, unknown>, keys: string[], fallback = "") {
  const value = readFirst(record, keys);
  return value === undefined ? fallback : String(value).trim() || fallback;
}

function readNumber(record: Record<string, unknown>, keys: string[]): number | undefined;
function readNumber(record: Record<string, unknown>, keys: string[], fallback: number): number;
function readNumber(record: Record<string, unknown>, keys: string[], fallback?: number) {
  const value = readFirst(record, keys);
  const numeric = Number(value);
  return Number.isFinite(numeric) ? numeric : fallback;
}

function statusLabel(status: number) {
  if (status === 1) return "Published";
  if (status === 2) return "Needs edit";
  return "Pending review";
}

function formatTime(value: unknown) {
  const numeric = Number(value);
  if (Number.isFinite(numeric) && numeric > 0) {
    return new Date(numeric > 100000000000 ? numeric : numeric * 1000).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
  }

  const parsed = Date.parse(String(value || ""));
  if (Number.isFinite(parsed)) {
    return new Date(parsed).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
  }

  return "Recent";
}
