import React from "react";
import { View, Text, Pressable, type ImageSourcePropType, type ViewStyle } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { ChevronRight, Package } from "lucide-react-native";
import { RarityBadge } from "./RarityBadge";
import { BoxChestSafe } from "./BoxChestSafe";
import {
  BoxSurfaces, BoxBorders, BoxText, BoxAccent,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  BoxLayout, getRarityTier, bs,
} from "@/lib/boxTheme";

interface BoxItemCardProps {
  name: string;
  image?: string | ImageSourcePropType;
  tier?: string;
  price?: number | string;
  openedCount?: number;
  onPress?: () => void;
  style?: ViewStyle;
}

export function BoxItemCard({
  name, image, tier, price, openedCount, onPress, style,
}: BoxItemCardProps) {
  const rarity = getRarityTier(tier);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        {
          backgroundColor: BoxSurfaces.card,
          borderRadius: BoxRadius["2xl"],
          borderWidth: 1,
          borderColor: BoxBorders.default,
          overflow: "hidden",
          transform: [{ scale: pressed ? 0.97 : 1 }],
          ...BoxShadows.card,
        },
        style,
      ]}
    >
      {/* Image area — always animated chest VFX (never flat product cover) */}
      <View style={{
        height: bs(188),
        overflow: "hidden",
      }}>
        {image ? (
            <LinearGradient
              colors={[rarity.bgSubtle, BoxSurfaces.deep]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                flex: 1,
                alignItems: "center",
                justifyContent: "center",
                paddingHorizontal: bs(2),
                paddingTop: bs(10),
                paddingBottom: 0,
              }}
            >
              <BoxChestSafe
                image={typeof image === "string" ? { uri: image } : image}
                tier={tier}
                size={168}
                density="compact"
              />
            </LinearGradient>
        ) : (
          <LinearGradient
            colors={[rarity.bgSubtle, BoxSurfaces.deep]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{
              flex: 1,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <View style={{
              width: bs(56), height: bs(56), borderRadius: bs(28),
              backgroundColor: rarity.bgSubtle,
              borderWidth: 1,
              borderColor: rarity.borderColor,
              alignItems: "center", justifyContent: "center",
              ...BoxShadows.glow(rarity.color),
            }}>
              <Package size={bs(28)} color={rarity.color} />
            </View>
          </LinearGradient>
        )}
        {/* Gradient overlay at bottom for blending */}
        <LinearGradient
          colors={["transparent", BoxSurfaces.card]}
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            height: bs(32),
          }}
        />
      </View>

      <View style={{ padding: BoxSpacing.md, gap: BoxSpacing.xs }}>
        <Text
          numberOfLines={1}
          style={[BoxTypography.bodyBold, { color: BoxText.primary }]}
        >
          {name}
        </Text>

        <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm }}>
          <RarityBadge tier={tier} size="sm" />
          {openedCount !== undefined && (
            <Text style={[BoxTypography.micro, { color: BoxText.tertiary, marginLeft: "auto" }]}>
              x{openedCount.toLocaleString()}
            </Text>
          )}
        </View>

        {price !== undefined && (
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: BoxSpacing.xs }}>
            <Text style={[BoxTypography.price, { color: BoxAccent.gold }]}>
              {typeof price === "number" ? price.toLocaleString() : price}
              <Text style={[BoxTypography.caption, { color: BoxAccent.gold }]}> pts</Text>
            </Text>
            <View style={{
              width: bs(26), height: bs(26), borderRadius: bs(13),
              backgroundColor: BoxAccent.goldDim,
              alignItems: "center", justifyContent: "center",
            }}>
              <ChevronRight size={bs(14)} color={BoxAccent.gold} />
            </View>
          </View>
        )}
      </View>
    </Pressable>
  );
}
