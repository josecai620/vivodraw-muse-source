import { s } from "@/constants/theme";
import React, { useEffect, useRef, useState } from "react";
import {
  AccessibilityInfo,
  Animated,
  Easing,
  Image,
  StyleSheet,
  View,
} from "react-native";

const WORDMARK = require("../../assets/brand/vivodraw-wordmark.webp");
/** 字标图 480×85，按高度锁定宽度，裁切才不会切到字中间。 */
const WORDMARK_RATIO = 480 / 85;
/** 每个字结束位置（含 i 上圆点；末字带 ®） */
const CHAR_ENDS = [0.145, 0.218, 0.338, 0.452, 0.608, 0.682, 0.795, 1];
const CHAR_MS = 380;
const HOLD_MS = 5000;
const FIRST_HOLD_MS = 800;
const RESTART_GAP_MS = 220;

/**
 * 首页顶栏 VivoDraw 字标：
 * 第一次打开先完整静态展示；等页面 ready 后再从左到右逐字播放，
 * 播完停在完整 logo，过一会儿再播。
 */
export default function 首页品牌标({ ready }: { ready: boolean }) {
  const logoH = s(28);
  const logoW = Math.round(logoH * WORDMARK_RATIO);
  const clip = useRef(new Animated.Value(1)).current;
  const [reduceMotion, setReduceMotion] = useState(false);

  useEffect(() => {
    let alive = true;
    AccessibilityInfo.isReduceMotionEnabled().then((value) => {
      if (alive) setReduceMotion(Boolean(value));
    });
    const sub = AccessibilityInfo.addEventListener("reduceMotionChanged", (value) => {
      setReduceMotion(Boolean(value));
    });
    return () => {
      alive = false;
      sub.remove();
    };
  }, []);

  useEffect(() => {
    if (!ready || reduceMotion) return;

    let cancelled = false;
    const playCycle = () => {
      if (cancelled) return;
      clip.setValue(0);
      Animated.sequence([
        Animated.delay(RESTART_GAP_MS),
        ...CHAR_ENDS.map((end) =>
          Animated.timing(clip, {
            toValue: end,
            duration: CHAR_MS,
            easing: Easing.out(Easing.quad),
            useNativeDriver: false,
            isInteraction: false,
          }),
        ),
        Animated.delay(HOLD_MS),
      ]).start(({ finished }) => {
        if (finished && !cancelled) playCycle();
      });
    };

    const start = setTimeout(playCycle, FIRST_HOLD_MS);
    return () => {
      cancelled = true;
      clearTimeout(start);
      clip.stopAnimation();
      clip.setValue(1);
    };
  }, [ready, reduceMotion, clip]);

  const clipWidth = clip.interpolate({
    inputRange: [0, 1],
    outputRange: [0, logoW],
  });

  return (
    <View style={[styles.box, { width: logoW, height: logoH }]} accessibilityLabel="VivoDraw">
      <Animated.View
        collapsable={false}
        style={[styles.clip, { width: clipWidth, height: logoH }]}
      >
        <Image
          source={WORDMARK}
          style={{ width: logoW, height: logoH }}
          resizeMode="contain"
          accessibilityElementsHidden
          importantForAccessibility="no"
        />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    justifyContent: "center",
    overflow: "hidden",
  },
  clip: {
    overflow: "hidden",
  },
});
