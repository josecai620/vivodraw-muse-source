import type { ImageSourcePropType } from "react-native";
import { MEMBER_SPEND_USD, type MemberFrameLevel } from "@/lib/会员等级";

export type AvatarFrameId =
  | "1718萌"
  | "4696麦位框"
  | "4691声波"
  | "4690声波"
  | "1272骑目鱼"
  | "1273以爱之名"
  | "三生三世"
  | "伯爵"
  | "侯爵"
  | "公主"
  | "公爵"
  | "冰羽"
  | "回归梦境"
  | "国王"
  | "彩虹"
  | "神兽朱雀"
  | "神兽白虎"
  | "神兽青龙"
  | "荣誉"
  | "蝴蝶纷飞红"
  | "郡公"
  | "郡王"
  | "金色愿望"
  | "金龙"
  | "钻石LV5";

export type MemberAvatarFrame = {
  id: AvatarFrameId;
  nameZh: string;
  nameEn: string;
  /** 脸直径 / 完整素材画布。只用来把镂空贴住头像外围，不拿来裁画。 */
  holeRatio: number;
  bytes: number;
  svga?: number;
  png: ImageSourcePropType;
  heavy?: boolean;
  /** 额外缩放，小于 1 用于转动会超出裁切的框（如彩虹）。 */
  fitScale?: number;
  /** 素材镂空不是透明而是实心底，播放时才抠脸洞。 */
  opaqueHole?: boolean;
};

const frames: MemberAvatarFrame[] = [
  {
    id: "1718萌",
    nameZh: "萌",
    nameEn: "Cute",
    holeRatio: 0.62,
    bytes: 48206,
    svga: require("../assets/member/1718头像框萌400-320.svga"),
    png: require("../assets/member/1718_萌-头像框.png"),
  },
  {
    id: "4696麦位框",
    nameZh: "麦位框",
    nameEn: "Mic Frame",
    holeRatio: 0.67,
    bytes: 142980,
    svga: require("../assets/member/4696_麦位框.svga"),
    png: require("../assets/member/4696_麦位框.png"),
  },
  {
    id: "4691声波",
    nameZh: "声波",
    nameEn: "Sonic Wave",
    holeRatio: 0.64,
    bytes: 138676,
    svga: require("../assets/member/4691声波2 400-320.svga"),
    png: require("../assets/member/4691_声波.png"),
  },
  {
    id: "4690声波",
    nameZh: "声波静帧",
    nameEn: "Sonic Still",
    holeRatio: 0.64,
    bytes: 318073,
    png: require("../assets/member/4690_声波.png"),
  },
  {
    id: "1272骑目鱼",
    nameZh: "骑目鱼",
    nameEn: "Riding Fish",
    holeRatio: 0.61,
    bytes: 713311,
    svga: require("../assets/member/1272-骑目鱼.svga"),
    png: require("../assets/member/1272-骑目鱼.png"),
  },
  {
    id: "1273以爱之名",
    nameZh: "以爱之名",
    nameEn: "In Love's Name",
    holeRatio: 0.63,
    bytes: 2857273,
    svga: require("../assets/member/1273-以爱之名.svga"),
    png: require("../assets/member/1273-以爱之名.png"),
    heavy: true,
  },
  {
    id: "三生三世",
    nameZh: "三生三世",
    nameEn: "Three Lifetimes",
    holeRatio: 0.64,
    bytes: 2030152,
    svga: require("../assets/member/三生三世.svga"),
    png: require("../assets/member/三生三世.png"),
    heavy: true,
  },
  {
    id: "伯爵",
    nameZh: "伯爵",
    nameEn: "Earl",
    holeRatio: 0.64,
    bytes: 443495,
    svga: require("../assets/member/伯爵.svga"),
    png: require("../assets/member/伯爵.png"),
  },
  {
    id: "侯爵",
    nameZh: "侯爵",
    nameEn: "Marquis",
    holeRatio: 0.64,
    bytes: 678619,
    svga: require("../assets/member/侯爵.svga"),
    png: require("../assets/member/侯爵.png"),
  },
  {
    id: "公主",
    nameZh: "公主",
    nameEn: "Princess",
    holeRatio: 0.68,
    bytes: 39285,
    svga: require("../assets/member/公主.svga"),
    png: require("../assets/member/公主.png"),
  },
  {
    id: "公爵",
    nameZh: "公爵",
    nameEn: "Duke",
    holeRatio: 0.64,
    bytes: 568390,
    svga: require("../assets/member/公爵.svga"),
    png: require("../assets/member/公爵.png"),
  },
  {
    id: "冰羽",
    nameZh: "冰羽",
    nameEn: "Ice Feathers",
    holeRatio: 0.5,
    bytes: 632215,
    svga: require("../assets/member/冰羽.svga"),
    png: require("../assets/member/冰羽.png"),
  },
  {
    id: "回归梦境",
    nameZh: "回归梦境",
    nameEn: "Dream Return",
    holeRatio: 0.55,
    bytes: 1242643,
    svga: require("../assets/member/回归梦境.svga"),
    png: require("../assets/member/回归梦境.png"),
    heavy: true,
  },
  {
    id: "国王",
    nameZh: "国王",
    nameEn: "King",
    holeRatio: 0.63,
    bytes: 695260,
    svga: require("../assets/member/国王.svga"),
    png: require("../assets/member/国王.png"),
  },
  {
    id: "彩虹",
    nameZh: "彩虹",
    nameEn: "Rainbow",
    holeRatio: 0.66,
    bytes: 322188,
    svga: require("../assets/member/彩虹.svga"),
    png: require("../assets/member/彩虹.png"),
    fitScale: 0.84,
  },
  {
    id: "神兽朱雀",
    nameZh: "神兽-朱雀",
    nameEn: "Vermilion Bird",
    holeRatio: 0.71,
    opaqueHole: true,
    bytes: 425223,
    svga: require("../assets/member/神兽-朱雀.svga"),
    png: require("../assets/member/神兽-朱雀.png"),
  },
  {
    id: "神兽白虎",
    nameZh: "神兽-白虎",
    nameEn: "White Tiger",
    holeRatio: 0.71,
    bytes: 457848,
    svga: require("../assets/member/神兽-白虎.svga"),
    png: require("../assets/member/神兽-白虎.png"),
  },
  {
    id: "神兽青龙",
    nameZh: "神兽-青龙",
    nameEn: "Azure Dragon",
    holeRatio: 0.71,
    bytes: 441280,
    svga: require("../assets/member/神兽-青龙.svga"),
    png: require("../assets/member/神兽-青龙.png"),
  },
  {
    id: "荣誉",
    nameZh: "荣誉",
    nameEn: "Honor",
    holeRatio: 0.66,
    bytes: 18987,
    svga: require("../assets/member/荣誉.svga"),
    png: require("../assets/member/荣誉.png"),
  },
  {
    id: "蝴蝶纷飞红",
    nameZh: "蝴蝶纷飞(红)",
    nameEn: "Red Butterflies",
    holeRatio: 0.64,
    bytes: 46542,
    svga: require("../assets/member/蝴蝶纷飞(红).svga"),
    png: require("../assets/member/蝴蝶纷飞(红).png"),
  },
  {
    id: "郡公",
    nameZh: "郡公",
    nameEn: "Commandery Duke",
    holeRatio: 0.63,
    bytes: 735989,
    svga: require("../assets/member/郡公.svga"),
    png: require("../assets/member/郡公.png"),
  },
  {
    id: "郡王",
    nameZh: "郡王",
    nameEn: "Commandery Prince",
    holeRatio: 0.63,
    bytes: 604448,
    svga: require("../assets/member/郡王.svga"),
    png: require("../assets/member/郡王.png"),
  },
  {
    id: "金色愿望",
    nameZh: "金色愿望",
    nameEn: "Golden Wish",
    holeRatio: 0.62,
    bytes: 783373,
    svga: require("../assets/member/金色愿望.svga"),
    png: require("../assets/member/金色愿望.png"),
  },
  {
    id: "金龙",
    nameZh: "金龙",
    nameEn: "Golden Dragon",
    holeRatio: 0.5,
    bytes: 758448,
    svga: require("../assets/member/金龙.svga"),
    png: require("../assets/member/金龙.png"),
  },
  {
    id: "钻石LV5",
    nameZh: "钻石LV5",
    nameEn: "Diamond LV5",
    holeRatio: 0.58,
    bytes: 830000,
    png: require("../assets/member/头像框-LV5-钻石.webp"),
  },
];

export const MEMBER_AVATAR_FRAMES: MemberAvatarFrame[] = frames;

const FRAME_BY_ID = Object.fromEntries(frames.map((row) => [row.id, row])) as Record<
  AvatarFrameId,
  MemberAvatarFrame
>;

/** 已选定的默认框。LV0 普通走静态，不在此表。 */
export const DEFAULT_FRAME_BY_LEVEL: Record<Exclude<MemberFrameLevel, 0>, AvatarFrameId> = {
  1: "4696麦位框",
  2: "1272骑目鱼",
  3: "三生三世",
  4: "4691声波",
  5: "冰羽",
  6: "金龙",
};

export const DEFAULT_TRIAL_FRAME: AvatarFrameId = "回归梦境";
export const DEFAULT_WINNER_FRAME: AvatarFrameId = "荣誉";

export function getAvatarFrame(id: AvatarFrameId): MemberAvatarFrame {
  return FRAME_BY_ID[id];
}

/** @deprecated 完整展示请用 avatarFrameArtSize */
export const AVATAR_FRAME_OUTER_RATIO = 1.86;

/** 各档外框同一规格，不按镂空比例把某一档单独放大。 */
export function avatarFrameArtSize(face: number, _holeRatio: number) {
  return Math.max(face, Math.round(face * AVATAR_FRAME_OUTER_RATIO));
}

export function avatarFrameOverlaySize(face: number, holeRatio = 0.62) {
  return avatarFrameArtSize(face, holeRatio);
}

export function avatarFrameDrawScale(holeRatio: number, fitScale = 1) {
  return fitScale;
}

export function formatFrameBytes(bytes: number) {
  if (bytes >= 1048576) return `${(bytes / 1048576).toFixed(1)}MB`;
  if (bytes >= 1024) return `${Math.round(bytes / 1024)}KB`;
  return `${bytes}B`;
}

export const FRAME_UNLOCK: Record<AvatarFrameId, { minLevel: MemberFrameLevel; minSpend?: number; trial?: boolean }> = {
  "4690声波": { minLevel: 0, minSpend: 30 },
  公主: { minLevel: 0, minSpend: 99 },
  "1718萌": { minLevel: 0, minSpend: 199 },
  伯爵: { minLevel: 0, minSpend: 299 },
  侯爵: { minLevel: 0, minSpend: 399 },
  彩虹: { minLevel: 0, minSpend: 499 },
  蝴蝶纷飞红: { minLevel: 0, minSpend: 599 },
  神兽朱雀: { minLevel: 0, minSpend: 699 },
  公爵: { minLevel: 0, minSpend: 799 },
  神兽白虎: { minLevel: 0, minSpend: 999 },
  神兽青龙: { minLevel: 0, minSpend: 1299 },
  郡公: { minLevel: 0, minSpend: 1599 },
  金色愿望: { minLevel: 0, minSpend: 1999 },
  钻石LV5: { minLevel: 0, minSpend: 2499 },
  "1273以爱之名": { minLevel: 0, minSpend: 2999 },
  国王: { minLevel: 0, minSpend: 3999 },
  郡王: { minLevel: 0, minSpend: 4999 },
  "4696麦位框": { minLevel: 1 },
  "1272骑目鱼": { minLevel: 2 },
  三生三世: { minLevel: 3 },
  "4691声波": { minLevel: 4 },
  冰羽: { minLevel: 5 },
  金龙: { minLevel: 6 },
  荣誉: { minLevel: 1 },
  回归梦境: { minLevel: 0, trial: true },
};

function spendCaption(amount: number, zh = true) {
  const n = amount.toLocaleString("en-US");
  return zh ? `累计实付满 $${n}` : `Spend $${n} total`;
}

export function frameUnlockSortKey(id: AvatarFrameId): number {
  const rule = FRAME_UNLOCK[id];
  if (!rule) return 99999;
  if (rule.trial) return 0;
  if (id === DEFAULT_WINNER_FRAME) return 1;
  if (rule.minSpend && rule.minSpend > 0) return rule.minSpend;
  const tierLv = membershipLevelForFrame(id);
  if (tierLv && tierLv > 0) return MEMBER_SPEND_USD[tierLv] + 0.5;
  return 99999;
}

export function sortAvatarFrames<T extends { id: AvatarFrameId; nameZh?: string }>(rows: T[]): T[] {
  return [...rows].sort((a, b) => {
    const d = frameUnlockSortKey(a.id) - frameUnlockSortKey(b.id);
    if (d !== 0) return d;
    return String(a.nameZh || a.id).localeCompare(String(b.nameZh || b.id), "zh");
  });
}

export function ownsTrialAvatarFrame(input: {
  trialActive?: boolean;
  claimedFreeTrial?: boolean | number | string | null;
}): boolean {
  if (input.trialActive) return true;
  const v = input.claimedFreeTrial;
  return v === true || v === 1 || v === "1";
}

export function membershipLevelForFrame(id: AvatarFrameId): MemberFrameLevel | null {
  const found = (Object.entries(DEFAULT_FRAME_BY_LEVEL) as [string, AvatarFrameId][]).find(
    ([, frameId]) => frameId === id,
  );
  if (!found) return null;
  return Number(found[0]) as MemberFrameLevel;
}

export function isMembershipDefaultFrame(id: AvatarFrameId) {
  return membershipLevelForFrame(id) != null;
}

const TIER_LOCK_NAME: Record<Exclude<MemberFrameLevel, 0>, { zh: string; en: string }> = {
  1: { zh: "新星会员", en: "Nova" },
  2: { zh: "黄金会员", en: "Gold" },
  3: { zh: "白金会员", en: "Platinum" },
  4: { zh: "翡翠会员", en: "Jade" },
  5: { zh: "钻石会员", en: "Diamond" },
  6: { zh: "黑金会员", en: "Onyx" },
};

export function isFrameOwned(id: AvatarFrameId, level: MemberFrameLevel = 0, trial = false, spendUsd = 0) {
  const rule = FRAME_UNLOCK[id];
  if (!rule) return false;
  if (rule.trial) return trial;
  if (isMembershipDefaultFrame(id)) return level >= rule.minLevel;
  if (rule.minSpend && rule.minSpend > 0) return Number(spendUsd) >= rule.minSpend;
  return level >= rule.minLevel;
}

export function frameHowYouGet(id: AvatarFrameId, zh = true) {
  const rule = FRAME_UNLOCK[id];
  if (!rule) return "";
  if (rule.trial) {
    return zh ? "试用会员赠送，领取后一直留在账户里" : "Gifted with the membership trial, yours after claiming";
  }
  if (id === DEFAULT_WINNER_FRAME) {
    return zh ? "揭晓中奖后可穿戴" : "Available after a draw win";
  }
  const tierLv = membershipLevelForFrame(id);
  if (tierLv && tierLv > 0) {
    const name = TIER_LOCK_NAME[tierLv];
    return zh ? `${name.zh}专属头像框` : `${name.en} member exclusive`;
  }
  if (rule.minSpend && rule.minSpend > 0) return spendCaption(rule.minSpend, zh);
  return "";
}

export function frameUnlockHint(id: AvatarFrameId, zh = true) {
  const rule = FRAME_UNLOCK[id];
  if (!rule) return "";
  if (rule.trial) return zh ? "去会员页免费领一次试用，就能穿上" : "Claim a free trial on the membership page first";
  const tierLv = membershipLevelForFrame(id);
  if (tierLv && tierLv > 0) {
    const name = TIER_LOCK_NAME[tierLv];
    return zh ? `要先成为${name.zh}才行` : `Become a ${name.en} member first`;
  }
  if (rule.minSpend && rule.minSpend > 0) {
    return zh ? `${spendCaption(rule.minSpend, true)}之后就能用` : spendCaption(rule.minSpend, false);
  }
  return "";
}

export function wearFailToast(error: unknown, zh = true, _frameId?: AvatarFrameId | "" | null) {
  const raw = (error instanceof Error ? error.message : String(error || "")).trim();
  if (raw && !/500|sql|exception|undefined|please try again|请稍后再试/i.test(raw)) {
    return raw;
  }
  return zh ? "不是你的会员不够，是这一下没记下。请再点一次穿戴。" : "It didn't save this time. Tap Wear again.";
}

export function ownedFrameIds(level: MemberFrameLevel, trial = false, spendUsd = 0) {
  return MEMBER_AVATAR_FRAMES.filter((row) => isFrameOwned(row.id, level, trial, spendUsd)).map((row) => row.id);
}

export function resolveWornFrameId(input: {
  level?: MemberFrameLevel;
  trial?: boolean;
  spendUsd?: number;
  frameId?: AvatarFrameId | string | null;
}): AvatarFrameId | null {
  const level = input.level ?? 0;
  const trial = !!input.trial;
  const spendUsd = Number(input.spendUsd ?? 0);
  const raw = String(input.frameId ?? "").trim() as AvatarFrameId;
  if (raw && FRAME_BY_ID[raw] && isFrameOwned(raw, level, trial, spendUsd)) return raw;
  if (trial) return DEFAULT_TRIAL_FRAME;
  if (level <= 0) return null;
  return DEFAULT_FRAME_BY_LEVEL[level as Exclude<MemberFrameLevel, 0>] ?? null;
}

export function frameDisplayName(frame: MemberAvatarFrame | null | undefined, zh = true) {
  if (!frame) return zh ? "普通圈" : "Plain ring";
  return zh ? frame.nameZh : frame.nameEn;
}

export function frameUsedLabels(id: AvatarFrameId, zh = true): string[] {
  const labels: string[] = [];
  const zhNames = { 1: "新星", 2: "黄金", 3: "白金", 4: "翡翠", 5: "钻石", 6: "黑金" } as Record<string, string>;
  const enNames = { 1: "Nova", 2: "Gold", 3: "Platinum", 4: "Jade", 5: "Diamond", 6: "Onyx" } as Record<string, string>;
  (Object.entries(DEFAULT_FRAME_BY_LEVEL) as [string, AvatarFrameId][]).forEach(([lv, frameId]) => {
    if (frameId === id) {
      labels.push(zh ? `${zhNames[lv]} LV${lv}` : `${enNames[lv]} LV${lv}`);
    }
  });
  if (id === DEFAULT_TRIAL_FRAME) labels.push(zh ? "试用" : "Trial");
  if (id === DEFAULT_WINNER_FRAME) labels.push(zh ? "揭晓" : "Winner");
  return labels;
}

export function resolveAvatarFrame(input: {
  level?: MemberFrameLevel;
  trial?: boolean;
  frameId?: AvatarFrameId | string | null;
}): MemberAvatarFrame | null {
  const raw = String(input.frameId ?? "").trim() as AvatarFrameId;
  if (raw && FRAME_BY_ID[raw]) return FRAME_BY_ID[raw];
  if (input.trial) return FRAME_BY_ID[DEFAULT_TRIAL_FRAME];
  const level = input.level ?? 0;
  if (level <= 0) return null;
  return FRAME_BY_ID[DEFAULT_FRAME_BY_LEVEL[level as Exclude<MemberFrameLevel, 0>]] ?? null;
}
