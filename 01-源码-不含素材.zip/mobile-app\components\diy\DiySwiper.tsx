// [已废弃] 改由 @/components/home-layout/HlBanner 替代
export default function DiySwiperDeprecated(): null { return null; }
