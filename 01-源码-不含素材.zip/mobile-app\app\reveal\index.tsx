import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { RevealCountdownBar, RevealSlideIn, RevealingSideTag } from "@/components/points/RevealMotion";
import { Colors } from "@/constants/theme";
import { useRevealIndex } from "@/hooks/usePoints";
import { unwrapApiData } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";
import { useRouter } from "expo-router";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Image, Pressable, RefreshControl, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const TEAL = Colors.primary.DEFAULT;

type Row = {
  id: number;
  productId: number;
  name: string;
  image: string;
  period: string;
  value: number;
  shares: number;
  winner: string;
  avatar: string;
  luckyCode: string;
  revealAt: string;
  djsMs: number;
};

function toList(raw: unknown): any[] {
  if (Array.isArray(raw)) return raw;
  if (raw && typeof raw === "object") {
    const o = raw as any;
    if (Array.isArray(o.list)) return o.list;
    if (Array.isArray(o.data)) return o.data;
  }
  return [];
}

function mapRow(p: any): Row | null {
  const id = Number(p?.id ?? p?.kaijiang_id ?? 0);
  if (!id) return null;
  return {
    id,
    productId: Number(p?.product_id ?? p?.sid ?? p?.pid ?? 0),
    name: String(p?.store_name ?? p?.title ?? p?.goods_name ?? ""),
    image: normalizeImageUrl(String(p?.image ?? p?.img ?? p?.thumb ?? "")),
    period: String(p?.bianhao ?? p?.qishu ?? ""),
    value: Number(p?.price ?? p?.ot_price ?? p?.exchange_num ?? 0) || 0,
    shares: Number(p?.huanqu_num ?? p?.canyurenshu ?? p?.gonumber ?? 0) || 0,
    winner: String(p?.nickname ?? p?.username ?? ""),
    avatar: normalizeImageUrl(String(p?.avatar ?? p?.uphoto ?? "")),
    luckyCode: String(p?.unique ?? p?.user_code ?? p?.lucky_code ?? ""),
    revealAt: String(p?.zhongjiang_time ?? p?.kaijiang_time ?? p?.end_time ?? ""),
    djsMs: Number(p?.djs ?? 0) || 0,
  };
}

function RevealListRow({
  row,
  index,
  fetchedAt,
  onOpen,
  onZero,
}: {
  row: Row;
  index: number;
  fetchedAt: number;
  onOpen: (id: number) => void;
  onZero: () => void;
}) {
  const { t } = useTranslation();
  const [ended, setEnded] = useState(row.djsMs <= 0);
  const deadlineAt = fetchedAt + row.djsMs;
  const revealing = !ended && row.djsMs > 0 && deadlineAt > Date.now();

  useEffect(() => {
    setEnded(row.djsMs <= 0);
  }, [row.id, row.djsMs, fetchedAt]);

  const markEnded = useCallback(() => {
    setEnded(true);
    onZero();
  }, [onZero]);

  return (
    <RevealSlideIn index={Math.min(index, 6)} from={-96}>
      <Pressable
        className="flex-row bg-white px-3 py-3 border-b border-gray-100"
        style={[{ position: "relative" }, revealing ? { backgroundColor: "#F0FBFC" } : undefined]}
        onPress={() => onOpen(row.id)}
      >
        {revealing ? <RevealingSideTag label={t("pointsMall.revealingNow")} /> : null}
        <View className="w-20 h-20 mr-3" style={{ position: "relative", overflow: "visible" }}>
          <View className="w-20 h-20 bg-gray-50 rounded overflow-hidden items-center justify-center">
            {row.image ? (
              <Image source={{ uri: row.image }} className="w-full h-full" resizeMode="contain" />
            ) : null}
          </View>
          {row.period ? (
            <View
              pointerEvents="none"
              style={{
                position: "absolute",
                left: 0,
                bottom: 0,
                backgroundColor: "rgba(0,0,0,0.55)",
                paddingHorizontal: 4,
                paddingVertical: 1,
                borderBottomLeftRadius: 4,
              }}
            >
              <Text style={{ color: "#fff", fontSize: 9 }}>{t("pointsMall.periodN", { n: row.period })}</Text>
            </View>
          ) : null}
        </View>
        <View className="flex-1">
          <Text className="text-sm text-gray-900" numberOfLines={2}>
            {row.name}
          </Text>
          {revealing ? (
            <View>
              <Text className="text-xs text-gray-500 mt-1">
                {t("pointsMall.valueLabel")}: {row.value || "-"}
              </Text>
              <RevealCountdownBar
                label={t("pointsMall.revealCountdown")}
                deadlineAt={deadlineAt}
                onZero={markEnded}
              />
            </View>
          ) : (
            <View className="mt-1.5">
              <Text className="text-xs text-gray-700" numberOfLines={1}>
                {t("pointsMall.winnerLabel")}: {row.winner || t("pointsMall.anonymous")}
              </Text>
              <Text className="text-xs text-gray-500 mt-0.5">
                {t("pointsMall.periodShares")}: {row.shares || "-"}
              </Text>
              <Text className="text-xs mt-0.5" style={{ color: Colors.primary.dark }}>
                {t("pointsMall.luckyCode")} {row.luckyCode || "-"}
              </Text>
            </View>
          )}
        </View>
      </Pressable>
    </RevealSlideIn>
  );
}

export default function MobileRevealMallPage() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t } = useTranslation();
  const [fetchedAt, setFetchedAt] = useState(() => Date.now());
  const [refreshing, setRefreshing] = useState(false);
  const { data: indexData, refetch } = useRevealIndex(8000);

  useEffect(() => {
    setFetchedAt(Date.now());
  }, [indexData]);

  const payload = unwrapApiData<any>(indexData, {});
  const rows = useMemo(() => {
    const zuixin = toList(payload?.zuixin_list).map(mapRow).filter(Boolean) as Row[];
    const jijiang = (toList(payload?.jijiang_list).map(mapRow).filter(Boolean) as Row[]).filter((r) => r.djsMs > 0);
    const seen = new Set<number>();
    const out: Row[] = [];
    for (const row of [...zuixin, ...jijiang]) {
      if (seen.has(row.id)) continue;
      seen.add(row.id);
      out.push(row);
    }
    out.sort((a, b) => Number(b.djsMs > 0) - Number(a.djsMs > 0));
    return out;
  }, [payload]);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      await refetch();
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg, overflow: "hidden" }}>
      <View className="bg-white px-4 pb-3" style={{ paddingTop: Math.max(insets.top, 10) }}>
        <Text className="text-lg font-black text-gray-900">{t("pointsMall.latestReveal")}</Text>
      </View>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={TEAL} />}
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}
      >
        {rows.length === 0 ? (
          <Text className="text-center text-sm text-gray-400 py-16">{t("pointsMall.noRevealsYet")}</Text>
        ) : (
          rows.map((row, index) => (
            <RevealListRow
              key={row.id}
              row={row}
              index={index}
              fetchedAt={fetchedAt}
              onOpen={(id) => router.push(`/reveal/${id}` as never)}
              onZero={() => void refetch()}
            />
          ))
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
