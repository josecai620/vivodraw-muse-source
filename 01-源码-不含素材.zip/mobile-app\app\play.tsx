import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import {
  Coins,
  Flower2,
  Gamepad2,
  Gem,
  Gift,
  Images,
  Pickaxe,
  Sparkles,
  Sprout,
  Wallet,
} from "lucide-react-native";
import React from "react";
import { useTranslation } from "react-i18next";
import { Platform, Pressable, ScrollView, Text, View } from "react-native";

type Entry = {
  key: string;
  title: string;
  titleEn: string;
  desc: string;
  descEn: string;
  icon: React.ComponentType<{ size?: number; color?: string }>;
  route?: string;
  external?: string;
  badge?: string;
  badgeEn?: string;
};

const ENTRIES: Entry[] = [
  {
    key: "pearl",
    title: "海底尋珠",
    titleEn: "Pearl Lagoon",
    desc: "開蚌尋珠，珍珠返還遊戲幣",
    descEn: "Pick shells, pearls return coins",
    icon: Gem,
    route: "/pearl",
  },
  {
    key: "pet",
    title: "桌寵世界",
    titleEn: "Pet deck",
    desc: "像素桌寵、每日禮物與親密度",
    descEn: "Pixel pets, daily gift and bond",
    icon: Sparkles,
    route: "/pet-deck",
  },
  {
    key: "mine",
    title: "礦洞挖礦",
    titleEn: "Mine",
    desc: "挖礦賺取礦幣",
    descEn: "Mine for coins",
    icon: Pickaxe,
    external: "/mine/mobile",
  },
  {
    key: "farm",
    title: "開心農場",
    titleEn: "Farm",
    desc: "種植收成賺金幣",
    descEn: "Grow crops for coins",
    icon: Flower2,
    external: "/farm",
  },
  {
    key: "coin",
    title: "金幣兌換",
    titleEn: "Coin exchange",
    desc: "遊戲金幣與平台積分互換",
    descEn: "Exchange coins and points",
    icon: Coins,
    route: "/coin-exchange",
  },
  {
    key: "wallet",
    title: "遊戲補幣",
    titleEn: "Game wallet",
    desc: "為各遊戲雙向補幣",
    descEn: "Two-way game coin supply",
    icon: Wallet,
    route: "/game-wallet",
  },
  {
    key: "point",
    title: "積分購買",
    titleEn: "Buy points",
    desc: "用美元餘額購買平台積分",
    descEn: "Buy platform points with USD",
    icon: Coins,
    route: "/point-purchase",
  },
  {
    key: "community",
    title: "社區廣場",
    titleEn: "Community",
    desc: "會員晒單與中獎故事",
    descEn: "Buyer photos and stories",
    icon: Images,
    route: "/community",
  },
  {
    key: "prize",
    title: "每日選獎",
    titleEn: "Pick your prize",
    desc: "概念試玩，無需登入",
    descEn: "Concept demo, no login",
    icon: Gift,
    route: "/pick-your-prize",
    badge: "試玩",
    badgeEn: "Demo",
  },
  {
    key: "farm1",
    title: "試玩農場",
    titleEn: "Farm demo",
    desc: "本地試玩原型，積分不記帳",
    descEn: "Local prototype, no ledger",
    icon: Sprout,
    route: "/farm1",
    badge: "試玩",
    badgeEn: "Demo",
  },
];

export default function PlayHubScreen() {
  const router = useRouter();
  const { i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");

  const open = (entry: Entry) => {
    if (entry.external) {
      if (Platform.OS === "web" && typeof window !== "undefined") {
        window.location.assign(entry.external);
        return;
      }
    }
    if (entry.route) router.push(entry.route);
  };

  return (
    <View className="flex-1 bg-neutral-50">
      <PageHeader title={zh ? "互動樂園" : "Play & rewards"} />
      <ScrollView
        contentContainerStyle={{ padding: 16, gap: 12, paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient
          colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          className="rounded-3xl p-5"
        >
          <View className="flex-row items-center">
            <Gamepad2 size={22} color="#fff" />
            <Text className="text-white text-lg font-bold ml-2">
              {zh ? "玩遊戲、賺積分" : "Play games, earn points"}
            </Text>
          </View>
          <Text className="text-white/85 text-sm mt-2 leading-5">
            {zh
              ? "海底尋珠、桌宠、挖礦與農場的金幣，都可在金幣兌換裡換成平台積分。"
              : "Coins from Pearl Lagoon, pets, mine and farm can all become platform points in Coin exchange."}
          </Text>
        </LinearGradient>

        {ENTRIES.map((entry) => {
          const Icon = entry.icon;
          return (
            <Pressable
              key={entry.key}
              onPress={() => open(entry)}
              className="bg-white rounded-2xl p-4 flex-row items-center active:opacity-80"
            >
              <View
                className="w-12 h-12 rounded-xl items-center justify-center"
                style={{ backgroundColor: "#ECFBFB" }}
              >
                <Icon size={22} color={Colors.brand.red} />
              </View>
              <View className="flex-1 ml-3">
                <View className="flex-row items-center gap-2">
                  <Text className="text-base font-bold text-neutral-900">
                    {zh ? entry.title : entry.titleEn}
                  </Text>
                  {entry.badge ? (
                    <View className="rounded-full px-2 py-0.5" style={{ backgroundColor: "#F7F9F9" }}>
                      <Text className="text-[10px] font-bold" style={{ color: Colors.brand.redDark }}>
                        {zh ? entry.badge : entry.badgeEn}
                      </Text>
                    </View>
                  ) : null}
                </View>
                <Text className="text-xs text-neutral-500 mt-0.5" numberOfLines={1}>
                  {zh ? entry.desc : entry.descEn}
                </Text>
              </View>
            </Pressable>
          );
        })}
      </ScrollView>
    </View>
  );
}
