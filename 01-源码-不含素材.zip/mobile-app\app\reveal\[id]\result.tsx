import React, { useEffect, useMemo, useState } from "react";
import { Image, Pressable, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useRevealDetail } from "@/hooks";
import { normalizeImageUrl } from "@/lib/utils";
import { resolveUserAvatarSource } from "@/lib/userAvatar";
import { useAuthStore } from "@/store/auth";

const TEAL = Colors.primary.DEFAULT;

function pad(n: number) {
  return String(Math.max(0, n)).padStart(2, "0");
}

export default function RevealResultScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const revealId = Number(id ?? 0);
  const uid = Number(useAuthStore((s) => s.user?.uid ?? s.user?.id) ?? 0);
  const { data } = useRevealDetail(revealId);
  const [left, setLeft] = useState(0);

  const raw = (data as any)?.data ?? {};
  const detail = raw?.detail ?? {};
  const product = raw?.product ?? {};
  const kaijiang = raw?.kaijiang ?? {};
  const name = String(product.store_name ?? detail.store_name ?? "");
  const image = normalizeImageUrl(String(product.image ?? detail.image ?? ""));
  const period = String(detail.bianhao ?? product.bianhao ?? "");
  const productId = Number(product.id ?? detail.product_id ?? 0);
  const luckyCode = String(detail.zj_unique ?? kaijiang.unique ?? "");
  const winner = String(kaijiang.nickname ?? detail.nickname ?? "");
  const winnerUid = Number(kaijiang.uid ?? detail.uid ?? 0);
  const avatar = normalizeImageUrl(String(kaijiang.avatar ?? detail.avatar ?? ""));
  const shares = Number(detail.huanqu_num ?? kaijiang.huanqu_num ?? 0);
  const revealAt = String(detail.zhongjiang_time ?? kaijiang.kaijiang_time ?? "");
  const huandeId = Number(detail.huande_id ?? kaijiang.huande_id ?? detail.id ?? 0);
  const djs = Number(detail.djs ?? 0);
  const myCodes = useMemo(() => {
    const list = raw?.my_hqjl ?? raw?.my_numbers ?? detail?.my_hqjl ?? [];
    return (Array.isArray(list) ? list : [])
      .map((item: any) => String(item?.hao ?? item?.unique ?? item ?? ""))
      .filter(Boolean);
  }, [raw, detail]);
  const won = Boolean(luckyCode && (winnerUid === uid || myCodes.includes(luckyCode)));

  useEffect(() => {
    setLeft(Math.max(0, Math.ceil(djs / 1000)));
  }, [djs]);
  useEffect(() => {
    if (left <= 0) return;
    const tmr = setTimeout(() => setLeft((s) => s - 1), 1000);
    return () => clearTimeout(tmr);
  }, [left]);

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={left > 0 ? t("pointsMall.revealingNow") : t("pointsMall.tabReveal")} />
      <ScrollView contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 16 }}>
        <View className="bg-white px-3 py-3 flex-row">
          <View className="w-16 h-16 bg-gray-50 rounded overflow-hidden mr-3">
            {image ? <Image source={{ uri: image }} className="w-full h-full" resizeMode="contain" /> : null}
          </View>
          <View className="flex-1">
            <Text className="text-[11px]" style={{ color: TEAL }}>
              {t("pointsMall.periodN", { n: period || "-" })}
            </Text>
            <Text className="text-sm font-bold text-gray-900 mt-0.5" numberOfLines={2}>
              {name || t("pointsMall.pointsProduct")}
            </Text>
          </View>
        </View>

        {left > 0 ? (
          <View className="bg-white mt-2 mx-3 rounded-xl p-4 items-center">
            <Text className="text-sm text-gray-500 mb-2">{t("pointsMall.revealingNow")}</Text>
            <Text className="text-4xl font-black" style={{ color: TEAL }}>
              {pad(Math.floor(left / 60))}:{pad(left % 60)}
            </Text>
          </View>
        ) : (
          <View className="bg-white mt-2 mx-3 rounded-xl p-4">
            <Text className="text-sm font-bold text-gray-900 mb-3">
              {won ? t("pointsMall.youWon") : t("pointsMall.notThisTime")}
            </Text>
            <View className="flex-row items-center">
              <Image source={resolveUserAvatarSource(avatar, winnerUid)} className="w-12 h-12 rounded-full bg-gray-100" />
              <View className="ml-3 flex-1">
                <Text className="text-xs text-gray-500">{t("pointsMall.winnerLabel")}</Text>
                <Text className="text-base font-bold" style={{ color: TEAL }}>
                  {winner || t("pointsMall.anonymous")}
                </Text>
                <Text className="text-xs text-gray-500 mt-1">
                  {t("pointsMall.periodShares")}：{shares || "-"}
                </Text>
                <Text className="text-xs text-gray-500">
                  {t("pointsMall.revealTime")}：{revealAt || "-"}
                </Text>
              </View>
            </View>
            <Text className="text-sm mt-3">
              {t("pointsMall.luckyCode")}：
              <Text className="font-black" style={{ color: TEAL }}>
                {luckyCode || "-"}
              </Text>
            </Text>
            {myCodes.length > 0 ? (
              <View className="flex-row flex-wrap mt-3" style={{ gap: 6 }}>
                {myCodes.map((code) => {
                  const hit = code === luckyCode;
                  return (
                    <View
                      key={code}
                      className="px-2 py-1 rounded"
                      style={{
                        backgroundColor: hit ? Colors.primary.light : "#F3F4F6",
                        borderWidth: 1,
                        borderColor: hit ? TEAL : "#E5E7EB",
                      }}
                    >
                      <Text className="text-xs font-mono" style={{ color: hit ? TEAL : "#374151", fontWeight: hit ? "800" : "500" }}>
                        {code}
                      </Text>
                    </View>
                  );
                })}
              </View>
            ) : null}
          </View>
        )}

        {left <= 0 ? (
          <>
            {won && huandeId > 0 ? (
              <Pressable
                className="mx-3 mt-3 h-11 rounded items-center justify-center"
                style={{ backgroundColor: TEAL }}
                onPress={() =>
                  router.push({ pathname: "/points/redemption-info", params: { id: String(huandeId) } })
                }
              >
                <Text className="text-white font-bold">{t("pointsMall.fillAddress")}</Text>
              </Pressable>
            ) : null}
            <Pressable
              className="mx-3 mt-3 h-11 rounded items-center justify-center"
              style={{ borderWidth: 1, borderColor: TEAL }}
              onPress={() =>
                router.push({
                  pathname: "/reveal/algorithm",
                  params: { id: String(revealId), productId: String(productId), bianhao: period },
                } as never)
              }
            >
              <Text className="font-bold" style={{ color: TEAL }}>
                {t("pointsMall.viewCalc")}
              </Text>
            </Pressable>
            {productId > 0 ? (
              <Pressable
                className="mx-3 mt-3 h-11 rounded items-center justify-center bg-white"
                onPress={() => router.push({ pathname: "/points/product", params: { id: String(productId) } })}
              >
                <Text className="text-sm font-bold text-gray-800">{t("pointsMall.keepTrying")}</Text>
              </Pressable>
            ) : (
              <Pressable
                className="mx-3 mt-3 h-11 rounded items-center justify-center bg-white"
                onPress={() => router.replace("/reveal")}
              >
                <Text className="text-sm font-bold text-gray-800">{t("pointsMall.browseOther")}</Text>
              </Pressable>
            )}
          </>
        ) : null}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
