import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import {
  gameReturnPaths,
  isGameWalletGame,
  type GameWalletGame,
} from "@/lib/api/gameWallet";
import { quoteGameExchange } from "@/lib/game/gameWalletRecovery";
import { useGameSupply } from "@/hooks/useGameSupply";
import { useAuthStore } from "@/store/auth";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ArrowLeftRight, Coins, RefreshCw, Star } from "lucide-react-native";
import React, { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";

const GAMES: GameWalletGame[] = ["mine", "pearl", "farm"];

export default function GameWalletScreen() {
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const { game: routeGame, returnTo } = useLocalSearchParams<{
    game?: string | string[];
    returnTo?: string | string[];
  }>();
  const [game, setGame] = useState<GameWalletGame | null>(null);
  useEffect(() => {
    setGame(isGameWalletGame(routeGame) ? routeGame : null);
  }, [routeGame]);

  const supply = useGameSupply(game);
  const { wallet, pending, review, receipt, direction } = supply;

  const zh = i18n.language?.startsWith("zh");
  const gameNames: Record<GameWalletGame, string> = {
    mine: zh ? "礦洞" : "Mine",
    pearl: zh ? "尋珠" : "Pearl Lagoon",
    farm: zh ? "農場" : "Farm",
  };
  const fallbackCoin: Record<GameWalletGame, string> = {
    mine: zh ? "礦幣" : "mine coins",
    pearl: zh ? "貝殼幣" : "shell coins",
    farm: zh ? "農場金幣" : "farm coins",
  };
  const coinName = game
    ? wallet?.game === game
      ? wallet.currency_name
      : fallbackCoin[game]
    : zh
      ? "遊戲幣"
      : "game coins";

  const forward = direction === "points_to_coins";
  const sourceUnit = forward ? t("gameWallet.pointsUnit") : coinName;
  const targetUnit = forward ? coinName : t("gameWallet.pointsUnit");
  const quote = wallet ? quoteGameExchange(wallet, direction, supply.amountText) : undefined;
  const intent = pending ?? review;
  const editable = !!supply.signedIn && !!wallet && !pending && !supply.submitting && !supply.loading;
  const rate = wallet ? (forward ? wallet.points_to_coins_rate : wallet.coins_to_points_rate) : null;

  const errors: Record<string, string> = useMemo(
    () => ({
      login: t("gameWallet.errLogin"),
      load_failed: t("gameWallet.errLoad"),
      invalid_amount: t("gameWallet.errInvalidAmount"),
      invalid_request: t("gameWallet.errInvalidRequest"),
      invalid_multiple: t("gameWallet.errInvalidMultiple", { rate: rate ?? "—", coin: coinName }),
      exchange_limit: t("gameWallet.errLimit", { max: wallet?.max_points_per_exchange ?? "—" }),
      insufficient_balance: forward
        ? t("gameWallet.errPointsLow")
        : t("gameWallet.errCoinsLow", { coin: coinName }),
      balance_limit: t("gameWallet.errBalanceLimit"),
      quote_changed: t("gameWallet.errQuoteChanged"),
      cashout_disabled: t("gameWallet.errCashoutDisabled"),
      pending: t("gameWallet.errPending"),
      request_conflict: t("gameWallet.errConflict"),
      receipt_mismatch: t("gameWallet.errReceipt"),
      account_changed: t("gameWallet.errAccount"),
      storage: t("gameWallet.errStorage"),
    }),
    [t, rate, coinName, wallet, forward],
  );

  const chooseGame = (value: GameWalletGame) => {
    setGame(value);
    router.setParams({ game: value, returnTo: gameReturnPaths[value] });
  };

  const openGame = () => {
    const dest = game ? gameReturnPaths[game] : "/";
    if (dest === "/mine/mobile" || dest === "/farm") {
      if (Platform.OS === "web" && typeof window !== "undefined") window.location.assign(dest);
      return;
    }
    router.replace(dest);
  };

  const shownError = supply.error || (!intent && !receipt && quote?.error ? quote.error : "");
  const quoteError = !intent && !receipt && quote?.error ? errors[quote.error] : "";

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-neutral-50"
    >
      <PageHeader title={t("gameWallet.title")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 120 }}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* 游戏选择 */}
        <View className="flex-row gap-2">
          {GAMES.map((g) => {
            const active = game === g;
            return (
              <Pressable
                key={g}
                onPress={() => chooseGame(g)}
                className="flex-1 h-12 rounded-xl items-center justify-center border"
                style={{
                  backgroundColor: active ? Colors.brand.red : "#fff",
                  borderColor: active ? Colors.brand.red : "rgba(12,31,31,0.08)",
                }}
              >
                <Text className="text-sm font-bold" style={{ color: active ? "#fff" : Colors.neutral[600] }}>
                  {gameNames[g]}
                </Text>
              </Pressable>
            );
          })}
        </View>

        {/* 双余额卡 */}
        <LinearGradient
          colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          className="rounded-3xl p-5 flex-row"
        >
          <View className="flex-1">
            <Text className="text-white/80 text-xs font-semibold mb-1">{t("gameWallet.pointsBalance")}</Text>
            <Text className="text-white text-3xl font-bold">
              {wallet ? wallet.point_balance.toLocaleString() : "—"}
            </Text>
          </View>
          <View className="flex-1">
            <Text className="text-white/80 text-xs font-semibold mb-1">
              {coinName} · {t("gameWallet.balance")}
            </Text>
            <Text className="text-white text-3xl font-bold">
              {wallet ? wallet.coin_balance.toLocaleString() : "—"}
            </Text>
          </View>
        </LinearGradient>

        {game ? (
          <Pressable
            className="h-11 rounded-xl items-center justify-center bg-white border border-neutral-200"
            onPress={() => router.push(`/point-purchase?game=${game}`)}
          >
            <Text className="font-semibold text-sm" style={{ color: Colors.brand.redDark }}>
              {t("gameWallet.buyPoints")}
            </Text>
          </Pressable>
        ) : null}

        {!supply.ready ? (
          <View className="bg-white rounded-2xl p-5 items-center">
            <ActivityIndicator color={Colors.brand.red} />
          </View>
        ) : !supply.signedIn || !isLoggedIn ? (
          <View className="bg-white rounded-2xl p-5 gap-4">
            <Text className="text-sm text-neutral-600 leading-5">{t("gameWallet.signInHint")}</Text>
            <Pressable
              className="h-12 rounded-xl items-center justify-center"
              style={{ backgroundColor: Colors.brand.red }}
              onPress={() => router.push("/auth")}
            >
              <Text className="text-white font-bold">{t("gameWallet.signIn")}</Text>
            </Pressable>
          </View>
        ) : !game ? (
          <Text className="text-sm text-neutral-500">{t("gameWallet.chooseGame")}</Text>
        ) : (
          <View className="bg-white rounded-2xl p-5 gap-4">
            <Text className="text-base font-bold text-neutral-900">{t("gameWallet.chooseDirection")}</Text>
            <View className="flex-row gap-2">
              {(["points_to_coins", "coins_to_points"] as const)
                .filter((value) => value === "points_to_coins" || wallet?.coins_to_points_enabled !== false || pending?.direction === "coins_to_points")
                .map((value) => {
                const active = direction === value;
                const label = value === "points_to_coins"
                  ? t("gameWallet.pointsToCoin", { coin: coinName })
                  : t("gameWallet.coinToPoints", { coin: coinName });
                return (
                  <Pressable
                    key={value}
                    disabled={!editable}
                    onPress={() => supply.changeDirection(value)}
                    className="flex-1 min-h-12 px-2 rounded-xl items-center justify-center border"
                    style={{
                      backgroundColor: active ? "#ECFBFB" : "#F7F9F9",
                      borderColor: active ? Colors.brand.red : "rgba(12,31,31,0.08)",
                      opacity: editable ? 1 : 0.5,
                    }}
                  >
                    <Text
                      className="text-xs font-bold text-center"
                      style={{ color: active ? Colors.brand.redDark : Colors.neutral[600] }}
                    >
                      {label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>

            <Text className="text-sm text-neutral-600">
              {rate === null
                ? t("gameWallet.loadingQuote")
                : forward
                  ? t("gameWallet.rateForward", { rate, coin: coinName })
                  : t("gameWallet.rateBackward", { rate, coin: coinName })}
            </Text>
            {game === "pearl" && wallet ? (
              <Text className="text-xs text-neutral-500 leading-5">{t("gameWallet.pearlSpreadHint")}</Text>
            ) : null}

            <Text className="text-xs font-bold text-neutral-500">
              {t("gameWallet.amountLabel")} · {sourceUnit}
            </Text>
            <TextInput
              value={supply.amountText}
              onChangeText={supply.changeAmount}
              editable={editable}
              keyboardType="number-pad"
              maxLength={12}
              placeholder="0"
              placeholderTextColor={Colors.neutral[400]}
              className="w-full h-14 bg-neutral-50 border border-neutral-200 rounded-xl px-4 text-2xl font-bold text-neutral-900"
            />

            {!intent && quote?.target ? (
              <View className="rounded-xl p-4" style={{ backgroundColor: "#F7F9F9" }}>
                <Text className="text-sm text-neutral-600">
                  {t("gameWallet.spend")} {quote.amount} {sourceUnit}
                </Text>
                <Text className="text-lg font-bold mt-1" style={{ color: Colors.brand.redDark }}>
                  {t("gameWallet.receive")} {quote.target} {targetUnit}
                </Text>
              </View>
            ) : null}

            {intent ? (
              <View className="rounded-xl p-4 gap-3" style={{ backgroundColor: "#ECFBFB" }}>
                <Text className="text-base font-bold text-neutral-900">
                  {pending ? t("gameWallet.reviewPrevious") : t("gameWallet.confirmTitle")}
                </Text>
                <Text className="text-sm text-neutral-700">
                  {t("gameWallet.spend")} {intent.amount}{" "}
                  {intent.direction === "points_to_coins" ? t("gameWallet.pointsUnit") : coinName}
                </Text>
                <Text className="text-lg font-bold" style={{ color: Colors.brand.redDark }}>
                  {t("gameWallet.receive")} {intent.expected_target_amount}{" "}
                  {intent.direction === "points_to_coins" ? coinName : t("gameWallet.pointsUnit")}
                </Text>
                <Pressable disabled={supply.submitting || supply.loading || supply.storageBlocked} onPress={() => void supply.submit()}>
                  <LinearGradient
                    colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                    start={{ x: 0, y: 0.5 }}
                    end={{ x: 1, y: 0.5 }}
                    className="h-12 rounded-xl items-center justify-center"
                  >
                    {supply.submitting ? (
                      <ActivityIndicator color="#fff" size="small" />
                    ) : (
                      <Text className="text-white font-bold">
                        {pending ? t("gameWallet.retrySame") : t("gameWallet.confirmBtn")}
                      </Text>
                    )}
                  </LinearGradient>
                </Pressable>
                {!pending ? (
                  <Pressable onPress={supply.cancelReview} className="h-10 items-center justify-center">
                    <Text className="text-sm text-neutral-500">{t("gameWallet.editAmount")}</Text>
                  </Pressable>
                ) : null}
              </View>
            ) : (
              <Pressable
                disabled={!editable || supply.storageBlocked || !!quote?.error}
                onPress={supply.prepare}
              >
                <LinearGradient
                  colors={
                    editable && !quote?.error
                      ? [TealGradient.light, TealGradient.base, TealGradient.dark]
                      : [Colors.neutral[300], Colors.neutral[300]]
                  }
                  start={{ x: 0, y: 0.5 }}
                  end={{ x: 1, y: 0.5 }}
                  className="h-12 rounded-xl items-center justify-center"
                >
                  <Text className="text-white font-bold">{t("gameWallet.reviewBtn")}</Text>
                </LinearGradient>
              </Pressable>
            )}

            <Text className="text-xs text-neutral-400 leading-4">{t("gameWallet.safeHint")}</Text>
            <Pressable
              className="h-10 flex-row items-center justify-center"
              disabled={supply.loading || supply.submitting}
              onPress={() => void supply.refresh()}
            >
              <RefreshCw size={14} color={Colors.neutral[500]} />
              <Text className="text-sm text-neutral-500 ml-2">
                {supply.loading ? t("gameWallet.loading") : t("gameWallet.reload")}
              </Text>
            </Pressable>
          </View>
        )}

        {shownError ? (
          <Text className="text-sm leading-5" style={{ color: Colors.error }}>
            {errors[supply.error] || quoteError || errors.pending}
          </Text>
        ) : null}

        {receipt ? (
          <View className="rounded-2xl p-5 gap-2" style={{ backgroundColor: "#ECFBFB" }}>
            <View className="flex-row items-center">
              <Star size={18} color={Colors.brand.redDark} />
              <Text className="text-base font-bold ml-2" style={{ color: Colors.brand.redDark }}>
                {t("gameWallet.exchangeDone")}
              </Text>
            </View>
            <Text className="text-sm text-neutral-700">
              {t("gameWallet.actualSpend")} {receipt.source_amount}{" "}
              {receipt.source_unit === "points" ? t("gameWallet.pointsUnit") : receipt.currency_name}
            </Text>
            <Text className="text-base font-bold" style={{ color: Colors.brand.redDark }}>
              {t("gameWallet.actualReceive")} {receipt.target_amount}{" "}
              {receipt.target_unit === "points" ? t("gameWallet.pointsUnit") : receipt.currency_name}
            </Text>
          </View>
        ) : null}

        {game ? (
          <Pressable
            className="h-12 rounded-xl bg-white border border-neutral-200 items-center justify-center flex-row"
            onPress={openGame}
          >
            <ArrowLeftRight size={16} color={Colors.neutral[600]} />
            <Text className="ml-2 font-semibold text-neutral-700">{t("gameWallet.backToGame")}</Text>
          </Pressable>
        ) : null}

        {!game ? (
          <View className="bg-white rounded-2xl p-5 gap-3">
            <Text className="text-base font-bold text-neutral-900">{t("gameWallet.freeRewards")}</Text>
            <Pressable
              className="h-11 rounded-xl border border-neutral-200 items-center justify-center"
              onPress={() => router.push("/points/checkin")}
            >
              <Text className="text-sm font-semibold text-neutral-700">{t("gameWallet.freeCheckin")}</Text>
            </Pressable>
            <Pressable
              className="h-11 rounded-xl border border-neutral-200 items-center justify-center"
              onPress={() => router.push("/pet-deck")}
            >
              <Text className="text-sm font-semibold text-neutral-700">{t("gameWallet.petGift")}</Text>
            </Pressable>
          </View>
        ) : null}
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
