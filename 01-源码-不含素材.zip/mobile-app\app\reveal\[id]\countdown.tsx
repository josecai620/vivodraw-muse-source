import { useEffect } from "react";
import { ActivityIndicator, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Colors } from "@/constants/theme";

/** 倒计时与已揭晓都落在参考实现同款 dataserver 页 /reveal/[id] */
export default function RevealCountdownScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();

  useEffect(() => {
    router.replace(`/reveal/${id || "0"}` as never);
  }, [id, router]);

  return (
    <View className="flex-1 items-center justify-center" style={{ backgroundColor: Colors.screen.bg }}>
      <ActivityIndicator color={Colors.primary.DEFAULT} />
    </View>
  );
}
