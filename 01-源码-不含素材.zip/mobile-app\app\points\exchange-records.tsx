import React, { useMemo, useState } from "react";
import { Image, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useAddPointsCart, useUserHqjlLists } from "@/hooks";
import { openCloudBuyCartList } from "@/lib/points/openCloudBuyCart";
import { normalizeImageUrl } from "@/lib/utils";
import { useAuthStore } from "@/store/auth";

const TEAL = Colors.primary.DEFAULT;

export default function ExchangeRecordsScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const addCart = useAddPointsCart();
  const [activeTab, setActiveTab] = useState<"ing" | "done">("ing");
  const { data, isLoading } = useUserHqjlLists({ status: activeTab === "ing" ? 0 : 1, page: 1 });
  const records = useMemo(() => {
    const list = (data as any)?.data?.lists ?? (data as any)?.lists ?? [];
    return Array.isArray(list) ? list : [];
  }, [data]);

  const tabs = [
    { key: "ing" as const, label: t("pointsMall.inProgressTab") },
    { key: "done" as const, label: t("pointsMall.revealedTab") },
  ];

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.buyRecords")} />
      <View className="flex-row bg-white px-3" style={{ gap: 8 }}>
        {tabs.map((tab) => {
          const on = activeTab === tab.key;
          return (
            <Pressable key={tab.key} className="px-2 py-2.5" onPress={() => setActiveTab(tab.key)}>
              <Text
                className="text-sm font-bold"
                style={{
                  color: on ? TEAL : "#6B7280",
                  borderBottomWidth: on ? 2 : 0,
                  borderBottomColor: TEAL,
                  paddingBottom: 3,
                }}
              >
                {tab.label}
              </Text>
            </Pressable>
          );
        })}
      </View>
      <ScrollView
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}
        showsVerticalScrollIndicator={false}
      >
        {isLoading ? (
          <Text className="text-center text-gray-400 py-16">{t("common.loading")}</Text>
        ) : records.length === 0 ? (
          <Text className="text-center text-gray-400 py-16">{t("pointsMall.noJoinRecords")}</Text>
        ) : (
          records.map((item: any, idx: number) => {
            const productId = Number(item.product_id ?? item.pid ?? 0);
            const hid = Number(item.id ?? 0);
            return (
              <View key={hid || idx} className="flex-row bg-white px-3 py-3 border-b border-gray-100">
                <Pressable
                  className="flex-1 flex-row"
                  onPress={() =>
                    router.push({ pathname: "/points/exchange-record-detail", params: { id: String(hid) } })
                  }
                >
                  <View className="w-16 h-16 bg-gray-50 rounded overflow-hidden mr-3">
                    <Image
                      source={{ uri: normalizeImageUrl(String(item.image ?? "")) }}
                      className="w-full h-full"
                      resizeMode="contain"
                    />
                  </View>
                  <View className="flex-1">
                    <Text className="text-[11px]" style={{ color: TEAL }}>
                      {t("pointsMall.periodN", { n: item.bianhao ?? item.hbianhao ?? "-" })}
                    </Text>
                    <Text className="text-sm text-gray-900 mt-0.5" numberOfLines={2}>
                      {item.store_name ?? t("pointsMall.pointsProduct")}
                    </Text>
                    <Text className="text-xs text-gray-500 mt-1">
                      {t("pointsMall.joinedShares", { n: item.exchange_num ?? item.huanqu_num ?? 1 })}
                    </Text>
                  </View>
                </Pressable>
                {productId > 0 ? (
                  <Pressable
                    className="self-center h-8 px-2 rounded items-center justify-center"
                    style={{ backgroundColor: TEAL }}
                    onPress={() => {
                      if (!isLoggedIn) {
                        router.push("/auth");
                        return;
                      }
                      addCart.mutate(
                        { productId, cartNum: 1 } as any,
                        { onSettled: () => openCloudBuyCartList(router) },
                      );
                    }}
                  >
                    <Text className="text-white text-xs font-bold">{t("pointsMall.appendBuy")}</Text>
                  </Pressable>
                ) : null}
              </View>
            );
          })
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
