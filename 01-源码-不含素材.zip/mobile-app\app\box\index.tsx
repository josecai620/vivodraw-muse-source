/**
 * 盲盒大厅 — Premium Dark Gaming UI
 */
import React, { useState, useEffect, useCallback } from "react";
import {
  Modal, Pressable, ScrollView, Text, View,
  ActivityIndicator, Dimensions, Platform, type ImageSourcePropType,
} from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import {
  ShoppingBag, Zap, Sparkles, ChevronRight, Gift,
  FileText, Layers, Truck, Award, Star, Calendar,
  Trophy, Repeat2, Heart, Shield, BarChart3, X,
  Clock, Play, Users, PartyPopper, Package, User, Rocket,
} from "lucide-react-native";
import { useTranslation } from "react-i18next";
import { useRevealColorScheme } from "@/contexts/RevealColorSchemeContext";
import {
  useBoxTuijian, useLuckyNotices, useBoxTongzhi,
  useActivityList, useNewbieCheck,
} from "@/hooks";
import { useLanguage } from "@/hooks/useLanguage";
import { usePointsBalance } from "@/hooks/usePoints";
import { useAuthStore } from "@/store/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { LogIn } from "lucide-react-native";

import {
  BoxHeader, QuickActionGrid, MarqueeBanner,
  ActivityBanner, GiftRewardCard, BoxItemCard,
  RarityBadge, RarityBar, BoxEmptyState, BoxActionButton, BoxChestVFX,
} from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  getRarityTier, bs,
} from "@/lib/boxTheme";

const { width: SCREEN_WIDTH } = Dimensions.get("window");

const BOX_CATEGORY_CHEST_IMAGES: Record<string, ImageSourcePropType> = {
  "starter box": require("../../assets/box-category-chests/home-living.png"),
  "elite box": require("../../assets/box-category-chests/electronics.png"),
  "ultimate box": require("../../assets/box-category-chests/apple-products.png"),
  "汽车用品": require("../../assets/box-category-chests/auto-accessories.png"),
  "auto accessories": require("../../assets/box-category-chests/auto-accessories.png"),
  "服饰鞋包": require("../../assets/box-category-chests/fashion-shoes.png"),
  "fashion & shoes": require("../../assets/box-category-chests/fashion-shoes.png"),
  "3c数码": require("../../assets/box-category-chests/electronics.png"),
  electronics: require("../../assets/box-category-chests/electronics.png"),
  "美妆护肤": require("../../assets/box-category-chests/beauty-skincare.png"),
  "beauty & skincare": require("../../assets/box-category-chests/beauty-skincare.png"),
  "户外运动": require("../../assets/box-category-chests/outdoor-sports.png"),
  "outdoor & sports": require("../../assets/box-category-chests/outdoor-sports.png"),
  "家居百货": require("../../assets/box-category-chests/home-living.png"),
  "home & living": require("../../assets/box-category-chests/home-living.png"),
  "珠宝首饰": require("../../assets/box-category-chests/jewelry.png"),
  jewelry: require("../../assets/box-category-chests/jewelry.png"),
  "苹果系列": require("../../assets/box-category-chests/apple-products.png"),
  "apple products": require("../../assets/box-category-chests/apple-products.png"),
  "signature vault": require("../../assets/box-category-chests/signature-chest.png"),
  "black label vault": require("../../assets/box-category-chests/signature-chest.png"),
  "premium vault": require("../../assets/box-category-chests/signature-chest.png"),
  "starter vault": require("../../assets/box-category-chests/home-living.png"),
  "elite vault": require("../../assets/box-category-chests/electronics.png"),
  "ultimate vault": require("../../assets/box-category-chests/signature-chest.png"),
};

const FALLBACK_CHEST_IMAGES: ImageSourcePropType[] = [
  require("../../assets/box-category-chests/signature-chest.png"),
  require("../../assets/box-category-chests/signature-chest.png"),
  require("../../assets/box-category-chests/signature-chest.png"),
  require("../../assets/box-category-chests/auto-accessories.png"),
  require("../../assets/box-category-chests/electronics.png"),
  require("../../assets/box-category-chests/jewelry.png"),
  require("../../assets/box-category-chests/apple-products.png"),
  require("../../assets/box-category-chests/home-living.png"),
];

/** Same ID map as box/[id].tsx so hall matches detail art. */
const FALLBACK_CHEST_BY_CATEGORY_ID: Record<number, ImageSourcePropType> = {
  310: require("../../assets/box-category-chests/home-living.png"),
  311: require("../../assets/box-category-chests/electronics.png"),
  312: require("../../assets/box-category-chests/apple-products.png"),
  95: require("../../assets/box-category-chests/auto-accessories.png"),
  94: require("../../assets/box-category-chests/fashion-shoes.png"),
  92: require("../../assets/box-category-chests/electronics.png"),
  91: require("../../assets/box-category-chests/beauty-skincare.png"),
  90: require("../../assets/box-category-chests/outdoor-sports.png"),
  89: require("../../assets/box-category-chests/home-living.png"),
  88: require("../../assets/box-category-chests/jewelry.png"),
  87: require("../../assets/box-category-chests/apple-products.png"),
};

function getBoxCategoryChestImage(name?: string): ImageSourcePropType | undefined {
  if (!name) return undefined;
  return BOX_CATEGORY_CHEST_IMAGES[name.trim().toLowerCase()] ?? BOX_CATEGORY_CHEST_IMAGES[name.trim()];
}

function getFallbackChestImage(boxId: number): ImageSourcePropType {
  if (FALLBACK_CHEST_BY_CATEGORY_ID[boxId]) return FALLBACK_CHEST_BY_CATEGORY_ID[boxId];
  return FALLBACK_CHEST_IMAGES[Math.abs(boxId || 0) % FALLBACK_CHEST_IMAGES.length];
}


/** Hall image: category art / remote pic / same ID fallback as detail — never empty Package. */
/**
 * Hall cards must show the animated BoxChestVFX chest — never remote product/reward stills.
 * Prefer name map, then ID map, then stable ID modulo fallback (same assets as detail).
 */
function resolveHallBoxImage(box: { id?: number; name?: string; image?: string }): ImageSourcePropType {
  const boxId = Number(box.id) || 0;
  const byName = getBoxCategoryChestImage(box.name);
  if (byName) return byName;
  return getFallbackChestImage(boxId);
}

const QUICK_ACTIONS_CONFIG = [
  { key: "backpack", Icon: ShoppingBag, route: "/box/backpack", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "checkin", Icon: Calendar, route: "/box/checkin", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "orders", Icon: FileText, route: "/box/orders", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "draws", Icon: Award, route: "/box/draws", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "leaderboard", Icon: Trophy, route: "/box/leaderboard", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "exchange", Icon: Repeat2, route: "/box/exchange", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "synthesis", Icon: Sparkles, route: "/box/synthesis", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "wishlist", Icon: Heart, route: "/box/wishlist", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "pity", Icon: Shield, route: "/box/pity", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "probability", Icon: BarChart3, route: "/box/probability", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "brands", Icon: Layers, route: "/box/brands", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "collection", Icon: Gift, route: "/box/collection", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "shipping", Icon: Truck, route: "/box/shipping", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "activity", Icon: Clock, route: "/box/activity", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "replay", Icon: Play, route: "/box/replay", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "friends", Icon: Users, route: "/box/friends", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "newbie", Icon: PartyPopper, route: "/box/newbie", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
  { key: "free-draw", Icon: Gift, route: "/box/free-draw", color: "#04A8AE", bg: "rgba(4,168,174,0.12)" },
  { key: "invite", Icon: Users, route: "/box/invite", color: "#04A8AE", bg: "rgba(4,168,174,0.10)" },
] as const;

const GUIDE_KEY = "box_guide_shown";

const FALLBACK_WINS = [
  { user: "Alex", item: "AirPods Pro", rarity: "epic" },
  { user: "Mia", item: "Nintendo Switch", rarity: "legendary" },
  { user: "Leo", item: "Mystery Figure", rarity: "rare" },
  { user: "Zoe", item: "Premium Sneakers", rarity: "epic" },
];

function HotWinsShowcase({ notices, t }: { notices: any[]; t: (k: string, o?: any) => string }) {
  const wins = notices.length >= 2
    ? notices.slice(0, 4).map((n: any, i: number) => ({
        user: (n.userNickname || `User${i}`).slice(0, 8),
        item: (n.itemName || "Mystery Item").slice(0, 14),
        rarity: n.rarity || "common",
      }))
    : FALLBACK_WINS;

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ gap: BoxSpacing.md }}
    >
      {wins.map((w, i) => {
        const rarity = getRarityTier(w.rarity);
        return (
          <View
            key={i}
            style={{
              width: bs(130),
              borderRadius: BoxRadius.xl,
              padding: BoxSpacing.md,
              backgroundColor: BoxSurfaces.card,
              borderWidth: 1,
              borderColor: BoxBorders.default,
              ...BoxShadows.raisedSm,
            }}
          >
            <View style={{
              width: bs(34), height: bs(34), borderRadius: bs(17),
              marginBottom: BoxSpacing.xs,
              backgroundColor: BoxAccent.goldMuted,
              alignItems: "center", justifyContent: "center",
            }}>
              <Package size={bs(16)} color={BoxAccent.gold} />
            </View>
            <Text numberOfLines={1} style={[BoxTypography.caption, { color: BoxText.primary, fontWeight: "800" }]}>
              {w.item}
            </Text>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: BoxSpacing.xs }}>
              <User size={bs(11)} color={BoxText.tertiary} />
              <Text numberOfLines={1} style={[BoxTypography.micro, { color: BoxText.tertiary }]}>
                {w.user}
              </Text>
            </View>
            <View style={{
              position: "absolute", top: BoxSpacing.sm, right: BoxSpacing.sm,
              paddingHorizontal: 6, paddingVertical: 2,
              borderRadius: BoxRadius.sm,
              backgroundColor: rarity.bgSubtle,
            }}>
              <Text style={{ fontSize: bs(8), fontWeight: "700", color: rarity.color }}>
                {rarity.label}
              </Text>
            </View>
          </View>
        );
      })}
    </ScrollView>
  );
}

export default function BoxMallPage() {
  const { t } = useTranslation();
  const { toggleLanguage, currentLanguage } = useLanguage();
  const { colors } = useRevealColorScheme();
  const router = useRouter();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const [showGuide, setShowGuide] = useState(false);
  const [guideStep, setGuideStep] = useState(0);

  const { data: balanceData } = usePointsBalance();
  const userPoints =
    (balanceData as any)?.data?.integral ?? (balanceData as any)?.integral ?? 0;

  const { data: boxesData, isLoading: isLoadingBoxes, error: errorBoxes } = useBoxTuijian();
  const { data: luckyNotices } = useLuckyNotices();
  const { data: tongzhi } = useBoxTongzhi();
  const { data: activities = [] } = useActivityList();
  const { data: newbieData } = useNewbieCheck();

  useEffect(() => {
    AsyncStorage.getItem(GUIDE_KEY).then((val) => {
      if (!val) setShowGuide(true);
    });
  }, []);

  const dismissGuide = () => {
    setShowGuide(false);
    AsyncStorage.setItem(GUIDE_KEY, "1");
  };

  const GUIDE_STEPS = [
    { title: t("guide.step1Title"), desc: t("guide.step1Desc"), Icon: Sparkles },
    { title: t("guide.step2Title"), desc: t("guide.step2Desc"), Icon: Package },
    { title: t("guide.step3Title"), desc: t("guide.step3Desc"), Icon: ShoppingBag },
    { title: t("guide.step4Title"), desc: t("guide.step4Desc"), Icon: Rocket },
    { title: t("guide.step5Title"), desc: t("guide.step5Desc"), Icon: Gift },
  ];

  const recentDrops = (luckyNotices || []).map(
    (notice: any, index: number) => ({
      username: notice.userNickname || t("hall.userFallback", { index }),
      itemName: notice.itemName || t("opening.fallbackItem"),
      tier: notice.rarity || "common",
    })
  );

  const boxes = boxesData || [];
  const hotBoxCandidate = boxes.length > 0 ? boxes[0] : null;
  const hotBox =
    hotBoxCandidate && hotBoxCandidate.price > 0 && hotBoxCandidate.name
      ? hotBoxCandidate
      : null;
  const hotBoxImage = hotBox ? resolveHallBoxImage(hotBox) : undefined;
  const hotProgress =
    hotBox && (hotBox as any).sales > 0
      ? Math.min(((hotBox as any).sales || 0) / 100, 100)
      : 50;
  const seriesBoxes = hotBox ? boxes.filter((b) => b.id !== hotBox.id) : boxes;

  const quickActions = QUICK_ACTIONS_CONFIG.map((a) => ({
    key: a.key,
    label: t(`quick.${a.key}`),
    icon: (
      <a.Icon
        size={bs(a.key === "backpack" ? 28 : 23)}
        strokeWidth={a.key === "backpack" ? 2.7 : 2.4}
        color={a.color}
      />
    ),
    color: a.color,
    bgColor: a.bg,
    onPress: () => router.push(a.route as any),
  }));

  const langToggle = (
    <Pressable
      onPress={toggleLanguage}
      hitSlop={8}
      style={{
        paddingHorizontal: 8, paddingVertical: 4,
        borderRadius: 6, backgroundColor: BoxAccent.goldDim,
      }}
    >
      <Text style={{ color: BoxAccent.gold, fontSize: 11, fontWeight: "700" }}>
        {currentLanguage === "en" ? "繁中" : "EN"}
      </Text>
    </Pressable>
  );

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <LinearGradient colors={BoxGradients.void} style={{ flex: 1 }}>
        {/* Header */}
        <BoxHeader
          title={t("hall.title")}
          points={userPoints}
          rightElement={langToggle}
        />

        {/* Login Banner */}
        {!isLoggedIn && (
          <Pressable
            onPress={() => router.push("/auth")}
            style={({ pressed }) => ({
              marginHorizontal: BoxSpacing.lg, marginTop: BoxSpacing.sm,
              flexDirection: "row", alignItems: "center", gap: BoxSpacing.md,
              padding: BoxSpacing.md, borderRadius: BoxRadius.xl,
              backgroundColor: BoxAccent.goldDim,
              borderWidth: 1, borderColor: BoxAccent.goldBorder,
              transform: [{ scale: pressed ? 0.98 : 1 }],
            })}
          >
            <View style={{
              width: bs(36), height: bs(36), borderRadius: bs(18),
              backgroundColor: BoxAccent.goldMuted,
              alignItems: "center", justifyContent: "center",
            }}>
              <LogIn size={bs(18)} color={BoxAccent.gold} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[BoxTypography.bodyBold, { color: BoxAccent.gold }]}>
                {t("auth.loginRequired") || "Sign in for full access"}
              </Text>
              <Text style={[BoxTypography.micro, { color: BoxText.tertiary, marginTop: 2 }]}>
                {t("auth.loginHint") || "Unboxing, check-in, backpack and more require sign-in"}
              </Text>
            </View>
            <ChevronRight size={bs(18)} color={BoxAccent.gold} />
          </Pressable>
        )}

        {/* Quick Actions */}
        <QuickActionGrid actions={quickActions} />

        {/* Marquee */}
        {recentDrops.length > 0 && <MarqueeBanner items={recentDrops} />}

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: bs(32) }}
        >
          <View style={{ padding: BoxSpacing.lg, gap: BoxSpacing.md }}>
            {/* Compact notice strip */}
            {tongzhi?.content ? (
              <View style={{
                flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm,
                paddingHorizontal: BoxSpacing.md, paddingVertical: BoxSpacing.sm,
                borderRadius: BoxRadius.full,
                backgroundColor: BoxAccent.goldDim,
              }}>
                <View style={{
                  width: bs(20), height: bs(20), borderRadius: bs(10),
                  backgroundColor: BoxAccent.goldMuted,
                  alignItems: "center", justifyContent: "center",
                }}>
                  <Star size={bs(10)} color={BoxAccent.gold} />
                </View>
                <Text numberOfLines={1} style={[BoxTypography.micro, { color: BoxAccent.gold, flex: 1 }]}>
                  {tongzhi.content.slice(0, 50)}…
                </Text>
              </View>
            ) : null}

            {/* Hot Wins Showcase — visual cards from lucky notices or fallback */}
            <HotWinsShowcase notices={luckyNotices || []} t={t} />

            {/* Activity Banner */}
            {activities.length > 0 && (
              <ActivityBanner
                title={activities[0].title}
                description={activities[0].description}
                onPress={() => router.push("/box/activity")}
              />
            )}

            {/* Newbie Gift Banner */}
            {newbieData && newbieData.eligible && !newbieData.claimed && (
              <GiftRewardCard
                title={t("hall.newbieBanner")}
                description={newbieData.rewardPreview?.description || t("hall.newbieBannerDefault")}
                buttonLabel={t("hall.newbieClaim")}
                onPress={() => router.push("/box/newbie")}
              />
            )}

            {/* Error State */}
            {errorBoxes ? (
              <BoxEmptyState
                icon={<X size={bs(48)} color={BoxText.tertiary} />}
                title={t("hall.loadFailed")}
              />
            ) : null}

            {/* Loading State */}
            {!errorBoxes && isLoadingBoxes ? (
              <View style={{ alignItems: "center", paddingVertical: bs(48) }}>
                <ActivityIndicator size="large" color={BoxAccent.gold} />
                <Text style={[BoxTypography.caption, { color: BoxText.secondary, marginTop: BoxSpacing.md }]}>
                  {t("common.loading")}
                </Text>
              </View>
            ) : (
              <>
                {/* Hot Box Hero */}
                {hotBox && (
                  <Pressable
                    onPress={() => router.push(`/box/${hotBox.id}`)}
                    style={({ pressed }) => ({
                      borderRadius: BoxRadius["3xl"],
                      overflow: "hidden",
                      transform: [{ scale: pressed ? 0.98 : 1 }],
                      ...BoxShadows.glow(BoxAccent.gold),
                    })}
                  >
                    <LinearGradient
                      colors={BoxGradients.hotPick}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={{
                        padding: BoxSpacing.xl,
                        borderRadius: BoxRadius["3xl"],
                        borderWidth: 1,
                        borderColor: BoxAccent.goldBorder,
                      }}
                    >
                      {/* HOT PICK badge */}
                      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: BoxSpacing.lg }}>
                        <LinearGradient
                          colors={BoxGradients.goldCta}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 1, y: 0 }}
                          style={{
                            flexDirection: "row", alignItems: "center", gap: 6,
                            paddingHorizontal: BoxSpacing.md, paddingVertical: BoxSpacing.xs,
                            borderRadius: BoxRadius.full,
                          }}
                        >
                          <Zap size={bs(14)} color="#fff" />
                          <Text style={[BoxTypography.micro, { color: "#fff" }]}>{t("hall.hotPick")}</Text>
                        </LinearGradient>
                        {hotBox.rarityDistribution && Object.keys(hotBox.rarityDistribution).length > 0 && (
                          <View style={{
                            paddingHorizontal: BoxSpacing.md, paddingVertical: BoxSpacing.xs,
                            borderRadius: BoxRadius.full,
                            backgroundColor: BoxAccent.goldMuted,
                          }}>
                            <Text style={[BoxTypography.micro, { color: BoxAccent.gold }]}>{t("hall.legendaryUp")}</Text>
                          </View>
                        )}
                      </View>

                      <View style={{ flexDirection: "row", gap: BoxSpacing.lg, alignItems: "center" }}>
                        {/* Box image */}
                        <View style={{
                          width: bs(116), height: bs(116),
                          alignItems: "center", justifyContent: "center",
                          ...BoxShadows.glow(BoxAccent.gold),
                        }}>
                          {hotBoxImage ? (
                            <BoxChestVFX image={hotBoxImage} tier="legendary" size={124} />
                          ) : (
                            <View
                              style={{
                                flex: 1, alignItems: "center", justifyContent: "center",
                                borderWidth: 1, borderColor: BoxBorders.default,
                                backgroundColor: BoxSurfaces.elevated,
                                borderRadius: BoxRadius["2xl"],
                              }}
                            >
                              <Package size={bs(44)} color={BoxAccent.gold} strokeWidth={1.5} />
                            </View>
                          )}
                        </View>

                        <View style={{ flex: 1 }}>
                          <Text style={[BoxTypography.h1, { color: BoxText.primary }]} numberOfLines={2}>
                            {hotBox.name || t("hall.hotDefault")}
                          </Text>
                          <Text style={[BoxTypography.body, { color: BoxText.secondary, marginTop: 2 }]} numberOfLines={1}>
                            {hotBox.description || t("hall.hotDefaultDesc")}
                          </Text>

                          {/* Progress */}
                          <View style={{ marginTop: BoxSpacing.md }}>
                            <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 4 }}>
                              <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
                                {t("hall.opened")} {(hotBox.opened || 0).toLocaleString()}
                              </Text>
                              <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
                                {t("hall.limited")} {(hotBox.total || 0).toLocaleString()}
                              </Text>
                            </View>
                            <View style={{ height: 6, borderRadius: 3, backgroundColor: BoxSurfaces.elevated, overflow: "hidden" }}>
                              <View style={{ height: "100%", width: `${hotProgress}%`, borderRadius: 3, backgroundColor: BoxAccent.gold }} />
                            </View>
                          </View>

                          {/* Price */}
                          <View style={{ flexDirection: "row", alignItems: "baseline", marginTop: BoxSpacing.md }}>
                            <Text style={[BoxTypography.priceHero, { color: BoxAccent.gold }]}>
                              {hotBox.price || 0}
                            </Text>
                            <Text style={[BoxTypography.caption, { color: BoxAccent.gold, marginLeft: 4 }]}>
                              {t("common.pts")}
                            </Text>
                          </View>
                        </View>
                      </View>

                      {/* Open Now button */}
                      <BoxActionButton
                        title={t("hall.openNow")}
                        icon={<Zap size={bs(18)} color={BoxText.onGold} />}
                        style={{ marginTop: BoxSpacing.lg }}
                      />

                      {/* Rarity bar */}
                      <RarityBar
                        items={Object.entries(hotBox.rarityDistribution || {}).map(([tier, pct]) => ({
                          tier, probability: Number(pct) || 0,
                        }))}
                        height={5}
                        style={{ marginTop: BoxSpacing.lg, opacity: 0.8 }}
                      />
                    </LinearGradient>
                  </Pressable>
                )}

                {/* All Series */}
                <View
                  style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: BoxSpacing.xl }}
                >
                  <Text style={[BoxTypography.h2, { color: BoxText.primary }]}>{t("hall.allSeries")}</Text>
                  <Pressable style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
                    <Text style={[BoxTypography.bodyBold, { color: BoxAccent.gold }]}>{t("hall.viewAll")}</Text>
                    <ChevronRight size={bs(16)} color={BoxAccent.gold} />
                  </Pressable>
                </View>

                {seriesBoxes.length === 0 ? (
                  <BoxEmptyState
                    icon={<Package size={bs(48)} color={BoxText.tertiary} />}
                    title={t("hall.noSeries")}
                  />
                ) : (
                  <View style={{ flexDirection: "row", flexWrap: "wrap", gap: BoxSpacing.md, marginTop: BoxSpacing.md }}>
                    {seriesBoxes.map((box) => (
                      <BoxItemCard
                        key={box.id}
                        name={box.name || t("hall.unnamed")}
                        image={resolveHallBoxImage(box)}
                        tier={Object.keys((box as any).rarityDistribution || {})[0]}
                        price={box.price || 0}
                        openedCount={box.opened}
                        onPress={() => router.push(`/box/${box.id}`)}
                        style={{ width: (SCREEN_WIDTH - BoxSpacing.lg * 2 - BoxSpacing.md) / 2 - 1 }}
                      />
                    ))}
                  </View>
                )}
              </>
            )}
          </View>
        </ScrollView>
      </LinearGradient>

      {/* New User Guide Modal */}
      <Modal visible={showGuide} transparent animationType="fade">
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: BoxSpacing["2xl"], backgroundColor: "rgba(12,31,31,0.45)" }}>
          <View style={{ width: "100%", maxWidth: 360, borderRadius: BoxRadius["3xl"], overflow: "hidden", backgroundColor: BoxSurfaces.card }}>
            <LinearGradient
              colors={BoxGradients.purpleDeep}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{ padding: BoxSpacing["2xl"], alignItems: "center" }}
            >
              <Pressable onPress={dismissGuide} style={{ position: "absolute", top: BoxSpacing.lg, right: BoxSpacing.lg, padding: 4 }}>
                <X size={bs(20)} color="rgba(255,255,255,0.7)" />
              </Pressable>
              <View style={{
                width: bs(72), height: bs(72), borderRadius: bs(36),
                backgroundColor: "rgba(255,255,255,0.18)",
                alignItems: "center", justifyContent: "center", marginBottom: BoxSpacing.md,
              }}>
                {(() => {
                  const StepIcon = GUIDE_STEPS[guideStep]?.Icon;
                  return StepIcon ? <StepIcon size={bs(34)} color="#fff" /> : null;
                })()}
              </View>
              <Text style={[BoxTypography.h2, { color: "#fff", textAlign: "center", marginBottom: BoxSpacing.sm }]}>
                {GUIDE_STEPS[guideStep]?.title}
              </Text>
              <Text style={[BoxTypography.body, { color: "rgba(255,255,255,0.8)", textAlign: "center" }]}>
                {GUIDE_STEPS[guideStep]?.desc}
              </Text>
            </LinearGradient>

            <View style={{ padding: BoxSpacing.xl }}>
              {/* Dot indicators */}
              <View style={{ flexDirection: "row", justifyContent: "center", gap: BoxSpacing.sm, marginBottom: BoxSpacing.lg }}>
                {GUIDE_STEPS.map((_, idx) => (
                  <View key={idx} style={{
                    height: 5, borderRadius: 3,
                    width: idx === guideStep ? 24 : 8,
                    backgroundColor: idx === guideStep ? BoxAccent.gold : BoxBorders.default,
                  }} />
                ))}
              </View>

              <View style={{ flexDirection: "row", gap: BoxSpacing.md }}>
                {guideStep > 0 && (
                  <BoxActionButton
                    title={t("guide.prev")}
                    variant="secondary"
                    compact
                    onPress={() => setGuideStep(guideStep - 1)}
                    style={{ flex: 1 }}
                  />
                )}
                <BoxActionButton
                  title={guideStep < GUIDE_STEPS.length - 1 ? t("guide.next") : t("guide.start")}
                  compact
                  onPress={() => {
                    if (guideStep < GUIDE_STEPS.length - 1) setGuideStep(guideStep + 1);
                    else dismissGuide();
                  }}
                  style={{ flex: 1 }}
                />
              </View>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}
