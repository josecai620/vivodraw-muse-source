import { PageHeader } from "@/components/shared";
import CloudBuyProgress from "@/components/points/CloudBuyProgress";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { Colors } from "@/constants/theme";
import { useAddPointsCart, useNewIntegralList, usePointsProducts } from "@/hooks";
import { unwrapApiPagedList } from "@/lib/api/response";
import { mapCloudProduct } from "@/lib/points/cloudBuyParse";
import { useAuthStore } from "@/store/auth";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Search, ShoppingCart } from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Image, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const TEAL = Colors.primary.DEFAULT;

export default function CloudBuySearchScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ q?: string }>();
  const [keyword, setKeyword] = useState(String(params.q ?? ""));
  const [committed, setCommitted] = useState(String(params.q ?? "").trim());
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const addCart = useAddPointsCart();

  const { data: listData } = usePointsProducts();
  const { data: searchData } = useNewIntegralList({
    keyword: committed,
    page: 1,
    enabled: committed.length > 0,
  });

  const products = useMemo(() => {
    const q = committed.toLowerCase();
    const fromSearch = unwrapApiPagedList<any>(searchData).map(mapCloudProduct).filter(Boolean);
    if (fromSearch.length) return fromSearch as NonNullable<ReturnType<typeof mapCloudProduct>>[];
    const all = unwrapApiPagedList<any>(listData).map(mapCloudProduct).filter(Boolean) as NonNullable<
      ReturnType<typeof mapCloudProduct>
    >[];
    if (!q) return all;
    return all.filter((x) => x.name.toLowerCase().includes(q));
  }, [searchData, listData, committed]);

  const submit = () => setCommitted(keyword.trim());

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.search")} />
      <View className="px-3 py-2 bg-white flex-row items-center" style={{ gap: 8 }}>
        <View className="flex-1 h-9 flex-row items-center rounded-full px-3" style={{ backgroundColor: "#F3F4F6" }}>
          <Search size={14} color="#9CA3AF" />
          <TextInput
            value={keyword}
            onChangeText={setKeyword}
            placeholder={t("pointsMall.searchPlaceholder")}
            placeholderTextColor="#9CA3AF"
            className="flex-1 ml-2 text-sm"
            returnKeyType="search"
            onSubmitEditing={submit}
            autoFocus
          />
        </View>
        <Pressable className="h-9 px-3 rounded-full items-center justify-center" style={{ backgroundColor: TEAL }} onPress={submit}>
          <Text className="text-white text-xs font-bold">{t("pointsMall.search")}</Text>
        </Pressable>
      </View>

      <ScrollView
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}
        showsVerticalScrollIndicator={false}
      >
        {products.length === 0 ? (
          <Text className="text-center text-sm text-gray-400 py-16">{t("pointsMall.noProductsFound")}</Text>
        ) : (
          products.map((item) => (
            <Pressable
              key={item.id}
              className="flex-row px-3 py-3 bg-white border-b border-gray-100"
              onPress={() => router.push({ pathname: "/points/product", params: { id: String(item.id) } })}
            >
              <View className="w-20 h-20 bg-gray-50 rounded overflow-hidden items-center justify-center mr-3">
                {item.image ? (
                  <Image source={{ uri: item.image }} className="w-full h-full" resizeMode="contain" />
                ) : null}
              </View>
              <View className="flex-1 pr-2">
                <Text className="text-sm text-gray-900 mb-1" numberOfLines={2}>
                  {item.name}
                </Text>
                <Text className="text-xs text-gray-500 mb-1.5">
                  {t("pointsMall.valueLabel")}: {item.points}
                </Text>
                <CloudBuyProgress
                  joined={item.sold}
                  total={item.total}
                  remain={item.remain}
                  joinedLabel={t("pointsMall.joined")}
                  totalLabel={t("pointsMall.totalNeed")}
                  remainLabel={t("pointsMall.remain")}
                />
              </View>
              <Pressable
                className="self-center w-9 h-9 rounded-full items-center justify-center"
                style={{ backgroundColor: TEAL }}
                onPress={() => {
                  if (!isLoggedIn) {
                    router.push("/auth");
                    return;
                  }
                  addCart.mutate({ productId: item.id, cartNum: 1 } as any);
                }}
              >
                <ShoppingCart size={16} color="#fff" />
              </Pressable>
            </Pressable>
          ))
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
