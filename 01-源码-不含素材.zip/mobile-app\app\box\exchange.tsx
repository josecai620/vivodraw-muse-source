/**
 * Exchange Market — Enhanced with 3 tabs: Market | My Listings | Offers
 */
import React, { useState } from "react";
import { Pressable, ScrollView, Text, View, ActivityIndicator, TextInput, Alert } from "react-native";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { Repeat2, Plus, Search, List, Bell, X, Check, Package, User, HelpCircle, Gift } from "lucide-react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { BoxHeader, RarityBadge, BoxActionButton, BoxEmptyState, BoxTabBar } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  getRarityTier, bs,
} from "@/lib/boxTheme";
import {
  useBoxList, useExchangeList, useCreateExchangeListing, useApplyExchange,
  useExchangeMyList, useCancelExchangeListing, useConfirmExchange, useExchangeOffers,
} from "@/hooks";
import { useAppStore } from "@/store/app";

type TabKey = "market" | "my" | "offers";
type FilterRarity = "all" | "uncommon" | "rare" | "epic" | "legendary" | "secret";

const TABS: { key: TabKey; labelKey: string }[] = [
  { key: "market", labelKey: "exchange.tabMarket" },
  { key: "my", labelKey: "exchange.tabMy" },
  { key: "offers", labelKey: "exchange.tabOffers" },
];

const RARITY_FILTERS: { key: FilterRarity; labelKey: string }[] = [
  { key: "all", labelKey: "exchange.filterAll" },
  { key: "uncommon", labelKey: "rarity.uncommon" },
  { key: "rare", labelKey: "rarity.rare" },
  { key: "epic", labelKey: "rarity.epic" },
  { key: "legendary", labelKey: "rarity.legendary" },
  { key: "secret", labelKey: "rarity.secret" },
];

export default function ExchangePage() {
  const { t } = useTranslation();
  const router = useRouter();
  const showToast = useAppStore((s) => s.showToast);
  const [activeTab, setActiveTab] = useState<TabKey>("market");
  const [showCreate, setShowCreate] = useState(false);
  const [selectedItem, setSelectedItem] = useState<number | null>(null);
  const [wantDesc, setWantDesc] = useState("");
  const [wantRarity, setWantRarity] = useState<string>("rare");
  const [filterRarity, setFilterRarity] = useState<FilterRarity>("all");
  const [searchText, setSearchText] = useState("");
  const [page] = useState(1);

  const { data: myItems, isLoading: loadingItems } = useBoxList();
  const { data: exchangeData, isLoading: loadingList } = useExchangeList({
    page, rarity: filterRarity === "all" ? "" : filterRarity, search: searchText,
  });
  const { data: myListingsData } = useExchangeMyList();
  const { data: offersData } = useExchangeOffers();
  const createMutation = useCreateExchangeListing();
  const applyMutation = useApplyExchange();
  const cancelMutation = useCancelExchangeListing();
  const confirmMutation = useConfirmExchange();

  const listings: any[] = (exchangeData as any)?.list ?? [];
  const myListings: any[] = (myListingsData as any) ?? [];
  const offers: any[] = (offersData as any) ?? [];

  const handleCreate = () => {
    if (!selectedItem || !wantDesc.trim()) return;
    createMutation.mutate(
      { user_box_id: selectedItem, want_desc: wantDesc.trim(), want_rarity: wantRarity },
      {
        onSuccess: () => { setShowCreate(false); setSelectedItem(null); setWantDesc(""); },
      },
    );
  };

  const handleCancel = (listingId: number) => {
    Alert.alert(t("exchange.cancelConfirm"), "", [
      { text: t("common.no"), style: "cancel" },
      { text: t("common.yes"), style: "destructive", onPress: () => cancelMutation.mutate(listingId) },
    ]);
  };

  const handleConfirm = (listingId: number) => {
    Alert.alert(t("exchange.confirmTitle"), t("exchange.confirmMsg"), [
      { text: t("common.cancel"), style: "cancel" },
      {
        text: t("common.confirm"),
        onPress: () => {
          const offer = offers.find((o: any) => o.id === listingId);
          if (offer) confirmMutation.mutate({ listingId, applicantBoxId: 0 });
        },
      },
    ]);
  };

  const statusLabel = (s: number) => {
    if (s === 0) return { text: t("exchange.statusActive"), color: BoxAccent.gold };
    if (s === 1) return { text: t("exchange.statusPending"), color: "#04A8AE" };
    if (s === 2) return { text: t("exchange.statusDone"), color: "#04A8AE" };
    return { text: t("exchange.statusCancelled"), color: BoxText.tertiary };
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader
        title={t("exchange.title")}
        showThemeToggle={false}
        rightElement={
          <Pressable onPress={() => { setShowCreate(true); setActiveTab("market"); }} style={{ padding: BoxSpacing.xs }}>
            <Plus size={bs(22)} color={BoxAccent.gold} />
          </Pressable>
        }
      />

      {/* Tab Bar */}
      <View style={{
        flexDirection: "row",
        paddingHorizontal: BoxSpacing.lg,
        paddingVertical: BoxSpacing.sm,
        backgroundColor: BoxSurfaces.deep,
        borderBottomWidth: 1,
        borderBottomColor: BoxBorders.subtle,
      }}>
        {TABS.map((tab) => {
          const isActive = activeTab === tab.key;
          return (
            <Pressable
              key={tab.key}
              onPress={() => setActiveTab(tab.key)}
              style={{
                flex: 1, height: bs(36), borderRadius: BoxRadius.lg,
                alignItems: "center", justifyContent: "center",
                backgroundColor: isActive ? BoxAccent.goldMuted : "transparent",
                marginHorizontal: 2,
              }}
            >
              <Text style={[BoxTypography.caption, {
                color: isActive ? BoxAccent.gold : BoxText.secondary,
                fontWeight: isActive ? "700" : "500",
              }]}>
                {t(tab.labelKey)}
                {tab.key === "offers" && offers.length > 0 && ` (${offers.length})`}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(96) }}>

          {/* ======== MARKET TAB ======== */}
          {activeTab === "market" && (
            <>
              {/* Search + Filter */}
              <View style={{ marginBottom: BoxSpacing.lg }}>
                <View style={{
                  flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm,
                  paddingHorizontal: BoxSpacing.md, height: bs(40), borderRadius: BoxRadius.lg,
                  backgroundColor: BoxSurfaces.card, borderWidth: 1, borderColor: BoxBorders.default,
                  marginBottom: BoxSpacing.md,
                }}>
                  <Search size={bs(16)} color={BoxText.tertiary} />
                  <TextInput
                    value={searchText} onChangeText={setSearchText}
                    placeholder={t("exchange.searchPlaceholder")} placeholderTextColor={BoxText.disabled}
                    style={[BoxTypography.body, { flex: 1, color: BoxText.primary, padding: 0 }]}
                  />
                </View>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  {RARITY_FILTERS.map((f) => {
                    const isActive = filterRarity === f.key;
                    const rc = f.key !== "all" ? getRarityTier(f.key) : null;
                    const pillColor = rc?.color ?? BoxAccent.gold;
                    return (
                      <Pressable key={f.key} onPress={() => setFilterRarity(f.key)} style={{
                        paddingHorizontal: BoxSpacing.md, paddingVertical: BoxSpacing.sm,
                        borderRadius: BoxRadius.full, marginRight: BoxSpacing.sm,
                        backgroundColor: isActive ? (rc?.bgSubtle ?? BoxAccent.goldMuted) : BoxSurfaces.card,
                        borderWidth: 1, borderColor: isActive ? pillColor : BoxBorders.default,
                      }}>
                        <Text style={[BoxTypography.micro, { color: isActive ? pillColor : BoxText.secondary }]}>
                          {t(f.labelKey)}
                        </Text>
                      </Pressable>
                    );
                  })}
                </ScrollView>
              </View>

              {/* Create Listing Modal */}
              {showCreate && (
                <View style={{
                  borderRadius: BoxRadius.xl, padding: BoxSpacing.xl, marginBottom: BoxSpacing["2xl"],
                  backgroundColor: BoxSurfaces.card, borderWidth: 2, borderColor: BoxAccent.gold,
                  ...BoxShadows.glow(BoxAccent.gold),
                }}>
                  <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: BoxSpacing.md }}>
                    <Text style={[BoxTypography.h3, { color: BoxText.primary }]}>{t("exchange.createTitle")}</Text>
                    <Pressable onPress={() => setShowCreate(false)}>
                      <X size={bs(20)} color={BoxText.tertiary} />
                    </Pressable>
                  </View>
                  <Text style={[BoxTypography.caption, { color: BoxText.secondary, marginBottom: BoxSpacing.sm }]}>
                    {t("exchange.selectItem")}
                  </Text>
                  {loadingItems ? (
                    <ActivityIndicator color={BoxAccent.gold} />
                  ) : (
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: BoxSpacing.lg }}>
                      {(myItems || []).map((item: any) => {
                        const isSelected = selectedItem === item.id;
                        const rc = getRarityTier(item.rarity);
                        return (
                          <Pressable key={item.id} onPress={() => setSelectedItem(item.id)} style={{
                            width: bs(64), height: bs(80), borderRadius: BoxRadius.lg,
                            alignItems: "center", justifyContent: "center", marginRight: BoxSpacing.sm,
                            backgroundColor: isSelected ? rc.bgSubtle : BoxSurfaces.deep,
                            borderWidth: 2, borderColor: isSelected ? rc.color : BoxBorders.default,
                          }}>
                            <Package size={bs(20)} color={isSelected ? rc.color : BoxAccent.gold} strokeWidth={1.6} />
                            <Text numberOfLines={1} style={[BoxTypography.micro, { color: BoxText.primary, marginTop: 2 }]}>
                              {item.name}
                            </Text>
                          </Pressable>
                        );
                      })}
                    </ScrollView>
                  )}
                  <TextInput
                    value={wantDesc} onChangeText={setWantDesc}
                    placeholder={t("exchange.wantPlaceholder")} placeholderTextColor={BoxText.disabled}
                    style={[BoxTypography.body, {
                      height: bs(40), paddingHorizontal: BoxSpacing.md, borderRadius: BoxRadius.lg,
                      marginBottom: BoxSpacing.lg, backgroundColor: BoxSurfaces.deep,
                      borderWidth: 1, borderColor: BoxBorders.default, color: BoxText.primary,
                    }]}
                  />
                  <View style={{ flexDirection: "row", gap: BoxSpacing.sm }}>
                    <BoxActionButton title={t("exchange.cancel")} variant="secondary" compact
                      onPress={() => setShowCreate(false)} style={{ flex: 1 }} />
                    <BoxActionButton title={createMutation.isPending ? "..." : t("exchange.publish")}
                      variant="primary" compact disabled={!selectedItem || !wantDesc.trim()}
                      loading={createMutation.isPending} onPress={handleCreate} style={{ flex: 1 }} />
                  </View>
                </View>
              )}

              {/* Market Listings */}
              {loadingList ? (
                <View style={{ paddingVertical: BoxSpacing["4xl"], alignItems: "center" }}>
                  <ActivityIndicator size="large" color={BoxAccent.gold} />
                </View>
              ) : listings.length === 0 ? (
                <BoxEmptyState icon={<Repeat2 size={bs(48)} color={BoxText.tertiary} />}
                  title={t("exchange.empty")} actionLabel={t("exchange.publishFirst")}
                  onAction={() => setShowCreate(true)} />
              ) : (
                listings.map((listing: any) => {
                  const rc = getRarityTier(listing.item_rarity);
                  const wantRc = getRarityTier(listing.want_rarity);
                  return (
                    <View key={listing.id} style={{
                      borderRadius: BoxRadius.xl, padding: BoxSpacing.lg, marginBottom: BoxSpacing.md,
                      backgroundColor: BoxSurfaces.card, borderWidth: 1, borderColor: BoxBorders.default,
                      ...BoxShadows.subtle,
                    }}>
                      <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: BoxSpacing.md }}>
                        <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm }}>
                          <View style={{ width: bs(28), height: bs(28), borderRadius: bs(14),
                            alignItems: "center", justifyContent: "center", backgroundColor: BoxSurfaces.elevated }}>
                            <User size={bs(14)} color={BoxText.tertiary} strokeWidth={1.6} />
                          </View>
                          <Text style={[BoxTypography.caption, { color: BoxText.primary, fontWeight: "700" }]}>
                            {listing.nickname || "Anonymous"}
                          </Text>
                        </View>
                      </View>
                      <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.md }}>
                        <View style={{ flex: 1, alignItems: "center" }}>
                          <View style={{ width: bs(64), height: bs(64), borderRadius: BoxRadius.xl,
                            alignItems: "center", justifyContent: "center", marginBottom: BoxSpacing.sm,
                            backgroundColor: rc.bgSubtle, borderWidth: 1, borderColor: rc.borderColor }}>
                            <Gift size={bs(24)} color={BoxAccent.gold} strokeWidth={1.6} />
                          </View>
                          <Text numberOfLines={1} style={[BoxTypography.caption, { color: BoxText.primary }]}>
                            {listing.item_name}
                          </Text>
                          <RarityBadge tier={listing.item_rarity} size="sm" style={{ marginTop: BoxSpacing.xs }} />
                        </View>
                        <Repeat2 size={bs(24)} color={BoxAccent.gold} />
                        <View style={{ flex: 1, alignItems: "center" }}>
                          <View style={{ width: bs(64), height: bs(64), borderRadius: BoxRadius.xl,
                            alignItems: "center", justifyContent: "center", marginBottom: BoxSpacing.sm,
                            backgroundColor: wantRc.bgSubtle, borderWidth: 1, borderColor: wantRc.borderColor, borderStyle: "dashed" }}>
                            <HelpCircle size={bs(24)} color={BoxText.tertiary} strokeWidth={1.6} />
                          </View>
                          <Text numberOfLines={2} style={[BoxTypography.caption, { color: BoxText.secondary }]}>
                            {listing.want_desc}
                          </Text>
                        </View>
                      </View>
                      <Pressable onPress={() => applyMutation.mutate({ listing_id: listing.id })}
                        disabled={applyMutation.isPending} style={{
                          marginTop: BoxSpacing.md, height: bs(36), borderRadius: BoxRadius.lg,
                          alignItems: "center", justifyContent: "center",
                          backgroundColor: BoxAccent.goldMuted, borderWidth: 1, borderColor: BoxAccent.goldBorder,
                        }}>
                        <Text style={[BoxTypography.buttonSmall, { color: BoxAccent.gold }]}>
                          {applyMutation.isPending ? "..." : t("exchange.apply")}
                        </Text>
                      </Pressable>
                    </View>
                  );
                })
              )}
            </>
          )}

          {/* ======== MY LISTINGS TAB ======== */}
          {activeTab === "my" && (
            myListings.length === 0 ? (
              <BoxEmptyState icon={<List size={bs(48)} color={BoxText.tertiary} />}
                title={t("exchange.noMyListings")} actionLabel={t("exchange.createFirst")}
                onAction={() => { setShowCreate(true); setActiveTab("market"); }} />
            ) : (
              myListings.map((listing: any) => {
                const st = statusLabel(listing.status);
                return (
                  <View key={listing.id} style={{
                    borderRadius: BoxRadius.xl, padding: BoxSpacing.lg, marginBottom: BoxSpacing.md,
                    backgroundColor: BoxSurfaces.card, borderWidth: 1, borderColor: BoxBorders.default,
                  }}>
                    <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: BoxSpacing.sm }}>
                      <View style={{ flex: 1, flexDirection: "row", alignItems: "center", gap: 6 }}>
                        <Gift size={bs(15)} color={BoxAccent.gold} />
                        <Text numberOfLines={1} style={[BoxTypography.body, { color: BoxText.primary, flex: 1 }]}>
                          {listing.item_name}
                        </Text>
                      </View>
                      <View style={{ paddingHorizontal: BoxSpacing.sm, paddingVertical: 2,
                        borderRadius: BoxRadius.sm, backgroundColor: st.color + "20" }}>
                        <Text style={[BoxTypography.micro, { color: st.color }]}>{st.text}</Text>
                      </View>
                    </View>
                    <Text style={[BoxTypography.caption, { color: BoxText.secondary }]}>
                      {t("exchange.want")}: {listing.want_desc || t("exchange.unlimited")}
                    </Text>
                    {listing.status === 0 && (
                      <Pressable onPress={() => handleCancel(listing.id)} style={{
                        marginTop: BoxSpacing.md, height: bs(32), borderRadius: BoxRadius.lg,
                        alignItems: "center", justifyContent: "center",
                        backgroundColor: "rgba(239,68,68,0.1)", borderWidth: 1, borderColor: "#EF444440",
                      }}>
                        <Text style={[BoxTypography.micro, { color: "#EF4444" }]}>{t("exchange.cancel")}</Text>
                      </Pressable>
                    )}
                  </View>
                );
              })
            )
          )}

          {/* ======== OFFERS TAB ======== */}
          {activeTab === "offers" && (
            offers.length === 0 ? (
              <BoxEmptyState icon={<Bell size={bs(48)} color={BoxText.tertiary} />}
                title={t("exchange.noOffers")} />
            ) : (
              offers.map((offer: any) => (
                <View key={offer.id} style={{
                  borderRadius: BoxRadius.xl, padding: BoxSpacing.lg, marginBottom: BoxSpacing.md,
                  backgroundColor: BoxSurfaces.card, borderWidth: 1, borderColor: BoxBorders.default,
                  ...BoxShadows.subtle,
                }}>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm, marginBottom: BoxSpacing.md }}>
                    <View style={{ width: bs(32), height: bs(32), borderRadius: bs(16),
                      alignItems: "center", justifyContent: "center", backgroundColor: BoxSurfaces.elevated }}>
                      <User size={bs(16)} color={BoxText.tertiary} strokeWidth={1.6} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={[BoxTypography.caption, { color: BoxText.primary, fontWeight: "700" }]}>
                        {offer.applicant_name || "User"}
                      </Text>
                      <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
                        {t("exchange.wantsToSwap")}: {offer.item_name}
                      </Text>
                    </View>
                  </View>
                  <View style={{ flexDirection: "row", gap: BoxSpacing.sm }}>
                    <Pressable onPress={() => handleConfirm(offer.id)} style={{
                      flex: 1, height: bs(36), borderRadius: BoxRadius.lg,
                      alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 4,
                      backgroundColor: BoxAccent.goldMuted, borderWidth: 1, borderColor: BoxAccent.goldBorder,
                    }}>
                      <Check size={bs(14)} color={BoxAccent.gold} />
                      <Text style={[BoxTypography.buttonSmall, { color: BoxAccent.gold }]}>
                        {t("exchange.accept")}
                      </Text>
                    </Pressable>
                    <Pressable onPress={() => handleCancel(offer.id)} style={{
                      flex: 1, height: bs(36), borderRadius: BoxRadius.lg,
                      alignItems: "center", justifyContent: "center",
                      backgroundColor: "rgba(239,68,68,0.1)", borderWidth: 1, borderColor: "#EF444440",
                    }}>
                      <Text style={[BoxTypography.micro, { color: "#EF4444" }]}>{t("exchange.decline")}</Text>
                    </Pressable>
                  </View>
                </View>
              ))
            )
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
