import React from "react";
import { Pressable, Text, View } from "react-native";
import { Colors, s } from "@/constants/theme";

interface SectionHeaderProps {
  title: string;
  icon?: React.ReactNode;
  actionText?: string;
  onAction?: () => void;
}

export default function SectionHeader({
  title,
  icon,
  actionText = "See All",
  onAction,
}: SectionHeaderProps) {
  return (
    <View className="flex-row items-center justify-between mb-4">
      <View className="flex-row items-center gap-2">
        {icon}
        <Text style={{ color: "#171A1A", fontSize: s(17), fontWeight: "800" }}>{title}</Text>
      </View>
      {onAction && (
        <Pressable onPress={onAction} hitSlop={8}>
          <Text style={{ color: Colors.primary.DEFAULT, fontSize: s(12.5), fontWeight: "700" }}>
            {actionText}
          </Text>
        </Pressable>
      )}
    </View>
  );
}
