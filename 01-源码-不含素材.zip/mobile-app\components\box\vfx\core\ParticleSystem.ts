import type { SparkEffectConfig } from './VFXConfig';

export class SparkEffect { // SparkEffect：粒子效果配置组件
  constructor(public config: SparkEffectConfig) {} // config：粒子配置

  setConfig(config: Partial<SparkEffectConfig>) {
    this.config = { ...this.config, ...config }; // config：合并后的粒子配置
  }
}

export class ParticleSystem { // ParticleSystem：粒子系统
  readonly sparkEffect: SparkEffect; // sparkEffect：火星与光屑组件

  constructor(spark: SparkEffectConfig) {
    this.sparkEffect = new SparkEffect(spark);
  }
}
