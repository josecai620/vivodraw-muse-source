import React, { useEffect, useRef } from "react";
import { Animated, Easing, View, type ImageSourcePropType, type ViewStyle } from "react-native";
import { Image } from "expo-image";
import { Package } from "lucide-react-native";
import { BoxAccent, BoxSurfaces, BoxBorders, bs } from "@/lib/boxTheme";

type Props = {
  image?: ImageSourcePropType | { uri: string } | string;
  tier?: string;
  size?: number;
  density?: "hero" | "compact";
  style?: ViewStyle;
};

/**
 * Lightweight animated chest for hall cards.
 * Avoids WebGL/Three.js VFX which can crash mobile Safari ("Something went wrong").
 */
export function BoxChestSafe({ image, size = 150, style }: Props) {
  const stage = bs(size);
  const bob = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(bob, { toValue: 1, duration: 1600, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(bob, { toValue: 0, duration: 1600, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [bob]);

  const translateY = bob.interpolate({ inputRange: [0, 1], outputRange: [0, -4] });
  const source = typeof image === "string" ? { uri: image } : image;

  return (
    <View
      pointerEvents="none"
      style={[
        {
          width: stage,
          height: stage,
          alignItems: "center",
          justifyContent: "center",
          overflow: "visible",
        },
        style,
      ]}
    >
      <Animated.View style={{ width: stage * 0.92, height: stage * 0.92, transform: [{ translateY }] }}>
        {source ? (
          <Image
            source={source as ImageSourcePropType}
            style={{ width: "100%", height: "100%" }}
            contentFit="contain"
            transition={120}
          />
        ) : (
          <View
            style={{
              flex: 1,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: BoxSurfaces.elevated,
              borderRadius: stage * 0.2,
              borderWidth: 1,
              borderColor: BoxBorders.default,
            }}
          >
            <Package size={stage * 0.34} color={BoxAccent.gold} />
          </View>
        )}
      </Animated.View>
    </View>
  );
}
