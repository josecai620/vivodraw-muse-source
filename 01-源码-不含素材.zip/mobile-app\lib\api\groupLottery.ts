import { http } from "../http";
import { API_ENDPOINTS } from "../../constants/api";

type ApiEnvelope<T> = { status: number; msg: string; data: T };

export interface GroupLotteryItem {
  id: number;
  title: string;
  image: string;
  price: number;
  price_type: number; // 1=积分 2=美元
  people_options: string; // "3,5,10"
  bonus_rate: number;
  sales: number;
  info: string;
}

export interface GroupLotteryDetail extends GroupLotteryItem {
  images: string;
  cost_price: number;
  recycle_price: number;
  robot_wait_minutes: number;
  effective_hours: number;
  description: string;
}

export interface PinkMember {
  id: number;
  uid: number;
  nickname: string;
  avatar: string;
  is_leader: number;
  is_robot: number;
  status: number;
  paid_amount: number;
  join_time: number;
  cancel_reason: string;
  delivery_id?: string;
  delivery_name?: string;
}

export interface PinkInfo {
  id: number;
  lottery_id: number;
  uid: number;
  is_admin: number;
  people_count: number;
  current_count: number;
  price: number;
  price_type: number;
  status: number; // 1=进行中 2=已开奖 3=超时 4=已取消
  winner_uid: number;
  winner_choice: number;
  draw_time: number;
  draw_seed: string;
  draw_hash: string;
  stop_time: number;
  add_time: number;
  members: PinkMember[];
  remain: number;
  remain_seconds: number;
  is_joined: boolean;
  lottery: GroupLotteryDetail;
  cancel_status: number;
}

export interface MyRecord {
  id: number;
  pink_id: number;
  lottery_id: number;
  uid: number;
  status: number;
  paid_amount: number;
  refund_amount: number;
  join_time: number;
  pink: PinkInfo;
  lottery: GroupLotteryDetail;
}

export function getGroupLotteryList(params?: { page?: number; limit?: number }) {
  return http.get<unknown, ApiEnvelope<{ list: GroupLotteryItem[] }>>(
    API_ENDPOINTS.groupLottery.list,
    { params },
  );
}

export function getGroupLotteryDetail(id: number) {
  return http.get<unknown, ApiEnvelope<{ info: GroupLotteryDetail; active_pinks: PinkInfo[] }>>(
    API_ENDPOINTS.groupLottery.detail(id),
  );
}

export function createPink(data: { lottery_id: number; people_count: number }) {
  return http.post<unknown, ApiEnvelope<{ pink_id: number }>>(
    API_ENDPOINTS.groupLottery.createPink,
    data,
  );
}

export function getPinkDetail(id: number) {
  return http.get<unknown, ApiEnvelope<PinkInfo>>(API_ENDPOINTS.groupLottery.pinkDetail(id));
}

export function joinPink(data: { pink_id: number }) {
  return http.post<unknown, ApiEnvelope<unknown>>(API_ENDPOINTS.groupLottery.join, data);
}

export function cancelApply(data: { pink_id: number; reason?: string }) {
  return http.post<unknown, ApiEnvelope<unknown>>(API_ENDPOINTS.groupLottery.cancelApply, data);
}

export function reviewCancel(data: { member_id: number; approve: number }) {
  return http.post<unknown, ApiEnvelope<unknown>>(API_ENDPOINTS.groupLottery.reviewCancel, data);
}

export function leaderCancel(data: { pink_id: number }) {
  return http.post<unknown, ApiEnvelope<unknown>>(API_ENDPOINTS.groupLottery.leaderCancel, data);
}

export function winnerChoice(data: {
  pink_id: number;
  choice: number; // 1=发货 2=回收
  name?: string;
  phone?: string;
  address?: string;
}) {
  return http.post<unknown, ApiEnvelope<unknown>>(API_ENDPOINTS.groupLottery.winnerChoice, data);
}

export function getMyRecords(params?: { page?: number; limit?: number }) {
  return http.get<unknown, ApiEnvelope<{ list: MyRecord[] }>>(
    API_ENDPOINTS.groupLottery.myRecord,
    { params },
  );
}

export function getVerifyInfo(pinkId: number) {
  return http.get<unknown, ApiEnvelope<unknown>>(API_ENDPOINTS.groupLottery.verify(pinkId));
}
