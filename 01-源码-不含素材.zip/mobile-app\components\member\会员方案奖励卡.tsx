import React from "react";
import { Text, View } from "react-native";
import { useTranslation } from "react-i18next";
import { 会员头像框 } from "@/components/member/会员头像框";
import { 会员卡片框 } from "@/components/member/会员卡片框";
import {
  MEMBER_FRAME_TIERS,
  MEMBER_TRIAL_SKIN,
  PLAN_REWARDS,
  type MemberFrameLevel,
} from "@/lib/会员等级";

export function 会员方案奖励卡({
  planType,
  currentExp = 0,
  uid,
  avatar,
}: {
  planType: string;
  currentExp?: number;
  uid?: number | null;
  avatar?: string | null;
}) {
  const { t, i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const reward = PLAN_REWARDS[planType] ?? PLAN_REWARDS.month;
  const level = reward.level as MemberFrameLevel;
  const isFree = planType === "free";
  const tier = isFree ? MEMBER_TRIAL_SKIN : MEMBER_FRAME_TIERS[level];
  const bits = [
    t("membership.rewardLevel", { name: zh ? tier.nameZh : tier.nameEn, level: isFree ? "FREE" : level }),
    t("membership.rewardFrame"),
    t("membership.rewardCard"),
  ];
  if (!isFree && reward.growth > 0) bits.splice(1, 0, t("membership.rewardGrowth", { growth: reward.growth }));
  if (!isFree && reward.daily > 0) {
    bits.push(t("membership.rewardDailyPoints", { daily: reward.daily, total: reward.points }));
  }
  if (!isFree && reward.coupon) {
    bits.push(
      t("membership.rewardMonthlyCoupon", {
        times: reward.couponTimes,
        coupon: reward.coupon,
        min: reward.couponMin,
      }),
    );
  }

  return (
    <View className="mt-3 gap-2">
      <View className="flex-row items-center gap-3">
        <会员头像框 uri={avatar} uid={uid} level={level} size={52} zh={zh} trial={isFree} />
        <View className="flex-1">
          <会员卡片框 level={level} trial={isFree}>
            <Text className="text-[10px] font-extrabold" style={{ color: tier.ring }}>
              {isFree ? (zh ? "試用" : "TRIAL") : `LV${level}`}
            </Text>
            <Text className="text-sm font-extrabold" style={{ color: "#111827" }}>
              {zh ? tier.nameZh : `${tier.nameEn} Member`}
            </Text>
            <Text className="text-[11px] mt-0.5" style={{ color: "#6B7280" }}>
              {isFree
                ? t("membership.rewardFrameOnly")
                : t("membership.rewardDailyHint", { daily: reward.daily, days: reward.days || "∞" })}
            </Text>
          </会员卡片框>
        </View>
      </View>
      <Text className="text-xs leading-5" style={{ color: "#4B5563" }}>
        {bits.join("  ·  ")}
      </Text>
    </View>
  );
}
