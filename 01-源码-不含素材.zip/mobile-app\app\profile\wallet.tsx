import PageHeader from "@/components/shared/PageHeader";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import { useAuthStore } from "@/store/auth";
import { useRouter } from "expo-router";
import { ArrowRightCircle, DollarSign, Wallet } from "lucide-react-native";
import React from "react";
import { useTranslation } from "react-i18next";
import { Pressable, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

export default function WalletScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const user = useAuthStore((s) => s.user);
  const balance = user?.now_money ?? "0.00";

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("wallet.title")} />
      <View className="mx-4 mt-4">
        <View className="rounded-2xl p-6 mb-4" style={{ }}>
          <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 16, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 16 }} />
          <View className="flex-row items-center gap-2 mb-2">
            <Wallet size={s(20)} color="#FFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
            <Text className="text-white/90 text-sm">{t("wallet.balance")}</Text>
          </View>
          <Text className="text-white text-3xl font-bold">${balance}</Text>
        </View>

        <Pressable
          onPress={() => router.push("/profile/wallet/recharge")}
          className="bg-white rounded-2xl p-4 mb-3 flex-row items-center justify-between border border-gray-100"
        >
          <View className="flex-row items-center gap-3">
            <View
              className="w-10 h-10 rounded-xl items-center justify-center"
              style={{ backgroundColor: `${Colors.brand.red}15` }}
            >
              <DollarSign size={s(22)} color={Colors.brand.red} />
            </View>
            <View>
              <Text className="font-semibold" style={{ color: Colors.neutral[800] }}>
                {t("wallet.recharge.title")}
              </Text>
              <Text className="text-sm" style={{ color: Colors.neutral[500] }}>
                {t("wallet.recharge.desc")}
              </Text>
            </View>
          </View>
          <ArrowRightCircle size={s(22)} color={Colors.neutral[400]} />
        </Pressable>

        <Pressable
          onPress={() => router.push("/profile/wallet/withdraw")}
          className="bg-white rounded-2xl p-4 mb-3 flex-row items-center justify-between border border-gray-100"
        >
          <View className="flex-row items-center gap-3">
            <View
              className="w-10 h-10 rounded-xl items-center justify-center"
              style={{ backgroundColor: `${Colors.accent.orange}20` }}
            >
              <ArrowRightCircle size={s(22)} color={Colors.accent.orange} />
            </View>
            <View>
              <Text className="font-semibold" style={{ color: Colors.neutral[800] }}>
                {t("wallet.withdraw.title")}
              </Text>
              <Text className="text-sm" style={{ color: Colors.neutral[500] }}>
                {t("wallet.withdraw.desc")}
              </Text>
            </View>
          </View>
          <ArrowRightCircle size={s(22)} color={Colors.neutral[400]} />
        </Pressable>
      </View>
    </View>
  );
}
