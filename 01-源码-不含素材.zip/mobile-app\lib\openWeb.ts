/**
 * openWeb — 在混合 app 内用 WebView 打开 H5 页面的便捷函数
 *
 * 使用：
 *   import { openWeb } from '@/lib/openWeb';
 *   openWeb(router, '/pages/news/detail', { title: '资讯详情', query: { id: 12 } });
 *
 * 相当于 router.push('/web/pages/news/detail?q=id%3D12&title=...')
 */
import type { Router } from "expo-router";

export type OpenWebOptions = {
  /** 顶部导航栏标题（H5 内部也可以通过 postMessage({type:'title'}) 覆盖） */
  title?: string;
  /** 额外 query 参数 */
  query?: Record<string, string | number | boolean | undefined | null>;
};

function buildQueryString(q: OpenWebOptions["query"] | undefined): string | undefined {
  if (!q) return undefined;
  const parts: string[] = [];
  for (const [k, v] of Object.entries(q)) {
    if (v === undefined || v === null) continue;
    parts.push(`${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`);
  }
  return parts.length ? parts.join("&") : undefined;
}

export function openWeb(router: Router, path: string, options: OpenWebOptions = {}): void {
  // 去掉前导斜杠，拆成 slug 数组
  const cleaned = path.replace(/^\/+/, "");
  const slug = cleaned.split("/").filter(Boolean);

  const q = buildQueryString(options.query);

  router.push({
    pathname: "/web/[...slug]",
    params: {
      slug,
      ...(options.title ? { title: options.title } : {}),
      ...(q ? { q } : {}),
    },
  });
}
