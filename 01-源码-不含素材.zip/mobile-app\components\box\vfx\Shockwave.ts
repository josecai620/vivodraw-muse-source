import { Container, Sprite, Texture } from 'pixi.js';

interface Ripple {
  sprite: Sprite; // sprite：柔性能量波纹纹理
  age: number; // age：波纹年龄
  speed: number; // speed：扩散速度
  maxScale: number; // maxScale：最大缩放
  rotateSpeed: number; // rotateSpeed：旋转速度
}

interface ShockwaveRhythm {
  burst: number; // burst：爆闪强度
  afterglow: number; // afterglow：余辉强度
}

export class Shockwave { // Shockwave：点击冲击波与爆闪
  private flash: Ripple | null = null; // flash：当前爆闪状态
  private ripples: Ripple[] = []; // ripples：柔性能量波纹列表
  private readonly layer: Container; // layer：冲击波图层
  private readonly centerX: number; // centerX：冲击中心 X
  private readonly centerY: number; // centerY：冲击中心 Y
  private readonly ringTexture: Texture; // ringTexture：柔性能量环纹理
  private readonly flashTexture: Texture; // flashTexture：软爆闪纹理

  constructor(layer: Container, centerX: number, centerY: number) {
    this.layer = layer; // layer：保存图层引用
    this.centerX = centerX; // centerX：保存中心 X
    this.centerY = centerY; // centerY：保存中心 Y
    this.ringTexture = this.createSoftShockRingTexture(0x7fd8dc, 3.4); // ringTexture：创建柔性环纹理（teal）
    this.flashTexture = this.createSoftFlashTexture(); // flashTexture：创建软爆闪纹理
  }

  burst() {
    const flashSprite = new Sprite(this.flashTexture); // flashSprite：点击软爆闪
    flashSprite.anchor.set(0.5);
    flashSprite.x = this.centerX;
    flashSprite.y = this.centerY;
    flashSprite.width = 248;
    flashSprite.height = 248;
    flashSprite.blendMode = 'add';
    this.layer.addChild(flashSprite);

    for (let index = 0; index < 3; index += 1) { // index：冲击波层序号
      const sprite = new Sprite(this.ringTexture); // sprite：柔性能量波纹
      sprite.anchor.set(0.5);
      sprite.x = this.centerX;
      sprite.y = this.centerY;
      sprite.width = 210;
      sprite.height = 210;
      sprite.alpha = 0;
      sprite.blendMode = 'add';
      this.ripples.push({
        sprite,
        age: -index * 0.14,
        speed: 0.72 + index * 0.18,
        maxScale: 2.25 + index * 0.42,
        rotateSpeed: (index % 2 === 0 ? 1 : -1) * (0.018 + index * 0.006),
      });
      this.layer.addChild(sprite);
    }

    this.flash = { sprite: flashSprite, age: 0, speed: 1, maxScale: 1.36, rotateSpeed: 0.04 };
  }

  update(delta: number, rippleColor: number, rhythm: ShockwaveRhythm, energyWaveSize = 1, explosionStrength = 1) {
    this.updateFlash(delta, rhythm, explosionStrength);
    this.updateRipples(delta, rippleColor, rhythm, energyWaveSize);
  }

  private updateFlash(delta: number, rhythm: ShockwaveRhythm, explosionStrength: number) {
    if (!this.flash) return;
    this.flash.age += delta * 5.2; // age：爆闪年龄
    const alpha = Math.max(0, 1 - this.flash.age); // alpha：爆闪透明度
    this.flash.sprite.alpha = alpha * (0.2 + rhythm.burst * 0.18) * explosionStrength;
    this.flash.sprite.rotation += this.flash.rotateSpeed;
    this.flash.sprite.scale.set(1 + this.flash.age * 0.32);
    if (alpha <= 0) {
      this.flash.sprite.destroy();
      this.flash = null;
    }
  }

  private updateRipples(delta: number, rippleColor: number, rhythm: ShockwaveRhythm, energyWaveSize: number) {
    this.ripples = this.ripples.filter((rippleItem) => {
      rippleItem.age += delta * rippleItem.speed; // age：波纹年龄
      if (rippleItem.age < 0) return true;
      const alpha = Math.max(0, 1 - rippleItem.age); // alpha：波纹透明度
      const breathe = 0.86 + Math.sin(rippleItem.age * 16) * 0.06; // breathe：波纹呼吸
      rippleItem.sprite.tint = rippleColor;
      rippleItem.sprite.alpha = alpha * (0.28 + rhythm.afterglow * 0.18);
      rippleItem.sprite.rotation += rippleItem.rotateSpeed;
      rippleItem.sprite.scale.set((1 + rippleItem.age * rippleItem.maxScale * energyWaveSize) * breathe);
      if (alpha <= 0) {
        rippleItem.sprite.destroy();
        return false;
      }
      return true;
    });
  }

  private createSoftShockRingTexture(color: number, seed: number) {
    const size = 256; // size：纹理尺寸
    const canvas = document.createElement('canvas'); // canvas：离屏纹理画布
    canvas.width = size;
    canvas.height = size;
    const context = canvas.getContext('2d'); // context：画布上下文
    if (!context) return Texture.EMPTY;
    const image = context.createImageData(size, size); // image：像素数据
    const data = image.data; // data：RGBA 像素数组
    const red = (color >> 16) & 255; // red：红色通道
    const green = (color >> 8) & 255; // green：绿色通道
    const blue = color & 255; // blue：蓝色通道
    const center = size / 2; // center：纹理中心

    for (let y = 0; y < size; y += 1) { // y：像素 Y
      for (let x = 0; x < size; x += 1) { // x：像素 X
        const dx = x - center; // dx：中心偏移 X
        const dy = y - center; // dy：中心偏移 Y
        const distance = Math.sqrt(dx * dx + dy * dy); // distance：到中心距离
        const angle = Math.atan2(dy, dx); // angle：角度
        const ring = Math.exp(-Math.pow((distance - 82) / 17, 2)); // ring：柔环强度
        const bloom = Math.exp(-Math.pow((distance - 82) / 40, 2)) * 0.26; // bloom：扩散模糊
        const breakNoise = Math.sin(angle * 9 + seed) + Math.sin(angle * 17 - seed * 0.8); // breakNoise：局部断裂噪声
        const fragment = breakNoise > 1.08 ? 0.18 : 1; // fragment：断裂片段强度
        const edgeNoise = 0.76 + Math.sin(dx * 0.08 + seed) * Math.cos(dy * 0.05 - seed) * 0.24; // edgeNoise：边缘噪声
        const alpha = Math.max(0, Math.min(1, (ring + bloom) * fragment * edgeNoise)); // alpha：最终透明度
        const offset = (y * size + x) * 4; // offset：像素偏移
        data[offset] = red;
        data[offset + 1] = green;
        data[offset + 2] = blue;
        data[offset + 3] = Math.floor(alpha * 190);
      }
    }

    context.putImageData(image, 0, 0);
    return Texture.from(canvas);
  }

  private createSoftFlashTexture() {
    const size = 256; // size：纹理尺寸
    const canvas = document.createElement('canvas'); // canvas：离屏爆闪画布
    canvas.width = size;
    canvas.height = size;
    const context = canvas.getContext('2d'); // context：画布上下文
    if (!context) return Texture.EMPTY;
    const gradient = context.createRadialGradient(128, 128, 8, 128, 128, 128); // gradient：爆闪径向渐变
    gradient.addColorStop(0, 'rgba(234, 251, 251, 0.34)');
    gradient.addColorStop(0.18, 'rgba(127, 216, 220, 0.18)');
    gradient.addColorStop(0.52, 'rgba(159, 228, 230, 0.12)');
    gradient.addColorStop(1, 'rgba(159, 228, 230, 0)');
    context.fillStyle = gradient;
    context.fillRect(0, 0, size, size);

    for (let index = 0; index < 14; index += 1) { // index：柔性爆闪射线序号
      const angle = (index / 14) * Math.PI * 2; // angle：射线角度
      const length = 62 + (index % 3) * 20; // length：射线长度
      const width = 3 + (index % 2) * 2; // width：射线宽度
      context.save();
      context.translate(128, 128);
      context.rotate(angle);
      const ray = context.createLinearGradient(0, 0, length, 0); // ray：射线渐变
      ray.addColorStop(0, 'rgba(234, 251, 251, 0.28)');
      ray.addColorStop(1, 'rgba(234, 251, 251, 0)');
      context.fillStyle = ray;
      context.beginPath();
      context.moveTo(18, -width);
      context.quadraticCurveTo(length * 0.55, -width * 0.6, length, 0);
      context.quadraticCurveTo(length * 0.55, width * 0.6, 18, width);
      context.closePath();
      context.fill();
      context.restore();
    }
    return Texture.from(canvas);
  }
}
