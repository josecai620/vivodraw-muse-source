import { useEffect, useMemo, useState } from "react";

import { fetchCommunityComposer, type CommunityComposerModel } from "@/lib/api/community";

export function useCommunityComposer() {
  const [model, setModel] = useState<CommunityComposerModel>({ source: "fallback", targets: [], existingPosts: [] });
  const [isLoading, setIsLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setIsLoading(true);

    fetchCommunityComposer()
      .then((nextModel) => {
        if (!cancelled) {
          setModel(nextModel);
        }
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [refreshKey]);

  return useMemo(
    () => ({
      ...model,
      isLoading,
      isFallback: model.source === "fallback",
      refresh: () => setRefreshKey((key) => key + 1),
    }),
    [isLoading, model],
  );
}
