import { gameCurrencyCodes, gameReturnPaths, isGameWalletGame, type GameExchangeReceipt, type GameExchangeRequest, type GameWalletGame, type GameWalletState } from "@/lib/api/gameWallet";

/** 只保存已确认的兑换指令及原到账报价，不保存令牌、余额或奖励。 */
export type PendingGameExchange = GameExchangeRequest & { expected_target_amount: number };
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const terminalReasons = new Set(["invalid_request", "invalid_amount", "quote_changed", "exchange_limit", "invalid_multiple", "insufficient_balance", "balance_limit", "cashout_disabled"]);

export function isConfirmedRejection(reason?: string) { return terminalReasons.has(reason ?? ""); }
export function safeGameReturnTo(value: unknown, game: GameWalletGame | null): "/mine/mobile" | "/pearl" | "/farm" | "/" {
  return game && value === gameReturnPaths[game] ? gameReturnPaths[game] : "/";
}
export function quoteGameExchange(state: GameWalletState, direction: GameExchangeRequest["direction"], text: string) {
  if (direction === "coins_to_points" && state.coins_to_points_enabled === false) return { error: "cashout_disabled" as const };
  if (!/^[1-9]\d*$/.test(text)) return { error: "invalid_amount" as const };
  const amount = Number(text);
  if (!Number.isSafeInteger(amount)) return { error: "invalid_amount" as const };
  if (direction === "coins_to_points" && amount % state.coins_to_points_rate !== 0) return { error: "invalid_multiple" as const };
  const target = direction === "points_to_coins" ? amount * state.points_to_coins_rate : amount / state.coins_to_points_rate;
  if (!Number.isSafeInteger(target) || target <= 0) return { error: "invalid_amount" as const };
  if ((direction === "points_to_coins" ? amount : target) > state.max_points_per_exchange) return { error: "exchange_limit" as const };
  if (amount > (direction === "points_to_coins" ? state.point_balance : state.coin_balance)) return { error: "insufficient_balance" as const };
  return { amount, target };
}

export function newGameExchangeId(): string {
  if (typeof globalThis.crypto?.randomUUID === "function") return globalThis.crypto.randomUUID();
  const bytes = new Uint8Array(16);
  globalThis.crypto.getRandomValues(bytes);
  bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function storage(uid: number, game: GameWalletGame) {
  if (!Number.isSafeInteger(uid) || uid <= 0 || !isGameWalletGame(game) || typeof localStorage === "undefined") throw new Error("Recovery unavailable");
  return { store: localStorage, key: `vivodraw:game-wallet:pending:v2:${uid}:${game}` };
}
function validate(value: unknown): PendingGameExchange {
  if (!value || typeof value !== "object") throw new Error("Invalid recovery record");
  const r = value as PendingGameExchange;
  if (Object.keys(r).length !== 6 || !isGameWalletGame(r.game) || !uuid.test(r.request_id) || !["points_to_coins", "coins_to_points"].includes(r.direction)
    || !Number.isSafeInteger(r.amount) || r.amount <= 0 || !Number.isSafeInteger(r.expected_target_amount) || r.expected_target_amount <= 0
    || typeof r.quote_version !== "string" || !r.quote_version.includes(`:${r.game}:`) || r.quote_version.length > 256) throw new Error("Invalid recovery record");
  return { request_id: r.request_id, game: r.game, direction: r.direction, amount: r.amount, quote_version: r.quote_version, expected_target_amount: r.expected_target_amount };
}
export function readPendingGameExchange(uid: number, game: GameWalletGame): PendingGameExchange | null {
  const { store, key } = storage(uid, game);
  const raw = store.getItem(key);
  if (raw === null) return null;
  if (raw.length > 1024) throw new Error("Invalid recovery record");
  const value = validate(JSON.parse(raw));
  if (value.game !== game) throw new Error("Wrong game recovery");
  return value;
}
export function savePendingGameExchange(uid: number, request: PendingGameExchange): PendingGameExchange {
  const existing = readPendingGameExchange(uid, request.game);
  if (existing) return existing;
  const value = validate(request), raw = JSON.stringify(value), { store, key } = storage(uid, request.game);
  store.setItem(key, raw);
  if (store.getItem(key) !== raw) throw new Error("Recovery write failed");
  return value;
}
export function clearPendingGameExchange(uid: number, request: PendingGameExchange): boolean {
  if (JSON.stringify(readPendingGameExchange(uid, request.game)) !== JSON.stringify(validate(request))) return false;
  const { store, key } = storage(uid, request.game);
  store.removeItem(key);
  if (store.getItem(key) !== null) throw new Error("Recovery clear failed");
  return true;
}
export function receiptConfirmsGameExchange(request: PendingGameExchange, receipt: GameExchangeReceipt | null): boolean {
  if (!receipt || receipt.game !== request.game || receipt.currency_code !== gameCurrencyCodes[request.game]
    || receipt.request_id !== request.request_id || receipt.direction !== request.direction
    || receipt.quote_version !== request.quote_version || receipt.source_amount !== request.amount
    || receipt.target_amount !== request.expected_target_amount || receipt.point_bill_id <= 0 || receipt.coin_bill_id <= 0) return false;
  const forward = request.direction === "points_to_coins";
  return receipt.source_unit === (forward ? "points" : gameCurrencyCodes[request.game]) && receipt.target_unit === (forward ? gameCurrencyCodes[request.game] : "points")
    && receipt.point_delta === (forward ? -request.amount : request.expected_target_amount)
    && receipt.coin_delta === (forward ? request.expected_target_amount : -request.amount);
}
