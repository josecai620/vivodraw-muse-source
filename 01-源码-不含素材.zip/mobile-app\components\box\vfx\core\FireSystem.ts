import type { FireEffectConfig } from './VFXConfig';

export class FireEffect { // FireEffect：火焰效果配置组件
  constructor(public config: FireEffectConfig) {} // config：火焰配置

  setConfig(config: Partial<FireEffectConfig>) {
    this.config = { ...this.config, ...config }; // config：合并后的火焰配置
  }
}

export class FireSystem { // FireSystem：火焰系统
  readonly fireEffect: FireEffect; // fireEffect：火焰组件

  constructor(fire: FireEffectConfig) {
    this.fireEffect = new FireEffect(fire);
  }
}
