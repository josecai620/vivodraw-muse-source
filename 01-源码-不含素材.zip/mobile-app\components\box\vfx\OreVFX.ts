import { Application, Container, Sprite, Texture } from 'pixi.js';
import { FireFilter } from './FireFilter';
import { FlowFilter } from './FlowFilter';
import { GlowFilter } from './GlowFilter';
import { LightStyleSystem, type LightStyleId } from './LightStyleSystem';
import { Shockwave } from './Shockwave';
import { SparkEmitter } from './SparkEmitter';
import type { VFXState } from './core/VFXConfig';

export interface OreVFXConfig {
  glowIntensity: number; // glowIntensity：呼吸发光强度
  glowSpeed: number; // glowSpeed：呼吸发光速度
  glowColor: number; // glowColor：发光颜色
  flowColor: number; // flowColor：流光颜色
  particleColor: number; // particleColor：粒子颜色
  particleSize: number; // particleSize：粒子大小
  fireSpeed: number; // fireSpeed：火焰速度
  energyWaveSize: number; // energyWaveSize：能量波尺寸
  explosionStrength: number; // explosionStrength：爆闪强度
  edgeSpeed: number; // edgeSpeed：边缘流光速度
  edgeCount: number; // edgeCount：边缘流光节点数量
  sweepSpeed: number; // sweepSpeed：扫光速度
  sparkCount: number; // sparkCount：火星粒子数量
  flamePower: number; // flamePower：火焰强度
  rippleColor: number; // rippleColor：点击能量波纹颜色
}

export interface OreVFXOptions {
  mount: HTMLElement; // mount：画布挂载节点
  oreUrl: string; // oreUrl：矿石资源路径
  width?: number; // width：画布宽度
  height?: number; // height：画布高度
  assetSize?: number; // assetSize：主体显示尺寸
  assetOffsetY?: number; // assetOffsetY：主体垂直偏移
  config?: Partial<OreVFXConfig>; // config：可覆盖特效参数
}

export interface VFXRhythm {
  charge: number; // charge：聚能强度
  burst: number; // burst：爆闪强度
  afterglow: number; // afterglow：余辉强度
  scatter: number; // scatter：粒子散落强度
  brightness: number; // brightness：整体亮度节奏
}

const defaultConfig: OreVFXConfig = { // defaultConfig：组件默认特效参数
  glowIntensity: 1,
  glowSpeed: 1.2,
  glowColor: 0x04a8ae,
  flowColor: 0x33c6cc,
  particleColor: 0x9fe4e6,
  particleSize: 1,
  fireSpeed: 1,
  energyWaveSize: 1,
  explosionStrength: 1,
  edgeSpeed: 1,
  edgeCount: 18,
  sweepSpeed: 1,
  sparkCount: 34,
  flamePower: 1,
  rippleColor: 0x7fd8dc,
};

export class OreVFX { // OreVFX：可接入深渊矿洞的矿石特效组件
  private readonly mount: HTMLElement; // mount：画布挂载节点
  private readonly oreUrl: string; // oreUrl：矿石资源路径
  private readonly width: number; // width：画布宽度
  private readonly height: number; // height：画布高度
  private readonly centerX: number; // centerX：矿石中心 X
  private readonly centerY: number; // centerY：矿石中心 Y
  private readonly assetSize: number; // assetSize：主体显示尺寸
  private readonly oreLayer = new Container(); // oreLayer：矿石与贴身光效层
  private readonly styleBackLayer = new Container(); // styleBackLayer：风格化后层光效
  private readonly fireLayer = new Container(); // fireLayer：底部火焰层
  private readonly styleFrontLayer = new Container(); // styleFrontLayer：风格化前层光效
  private readonly particleLayer = new Container(); // particleLayer：前景粒子层
  private readonly shockwaveLayer = new Container(); // shockwaveLayer：点击冲击波层
  private config: OreVFXConfig; // config：运行时特效配置
  private app: Application | null = null; // app：Pixi 应用实例
  private glowFilter: GlowFilter | null = null; // glowFilter：发光滤镜实例
  private flowFilter: FlowFilter | null = null; // flowFilter：流光滤镜实例
  private fireFilter: FireFilter | null = null; // fireFilter：火焰滤镜实例
  private lightStyleSystem: LightStyleSystem | null = null; // lightStyleSystem：多风格光效系统
  private sparkEmitter: SparkEmitter | null = null; // sparkEmitter：火星粒子发射器
  private shockwave: Shockwave | null = null; // shockwave：点击冲击波实例
  private oreSprite: Sprite | null = null; // oreSprite：主体原图
  private fireLightSprite: Sprite | null = null; // fireLightSprite：火焰映亮矿石层
  private oreDetailSprite: Sprite | null = null; // oreDetailSprite：矿石细节恢复层
  private colorBoostSprite: Sprite | null = null; // colorBoostSprite：主体保色提亮层
  private time = 0; // time：动画累计时间
  private clickBurst = 0; // clickBurst：点击触发爆闪余量
  private state: VFXState = 'idle'; // state：当前特效状态
  private stateTime = 0; // stateTime：当前状态持续时间
  private paused = false; // paused：是否暂停

  constructor(options: OreVFXOptions) {
    this.mount = options.mount; // mount：保存挂载节点
    this.oreUrl = options.oreUrl; // oreUrl：保存资源路径
    this.width = options.width ?? 640; // width：设置画布宽度
    this.height = options.height ?? 640; // height：设置画布高度
    this.centerX = this.width / 2; // centerX：计算中心 X
    this.centerY = this.height / 2 + (options.assetOffsetY ?? 18); // centerY：计算中心 Y
    this.assetSize = options.assetSize ?? 310; // assetSize：设置主体尺寸
    this.config = { ...defaultConfig, ...options.config }; // config：合并默认参数
  }

  async init() {
    const app = new Application(); // app：Pixi WebGL 应用
    await app.init({
      width: this.width,
      height: this.height,
      antialias: true,
      backgroundAlpha: 0,
      preference: 'webgl',
      resolution: Math.min(window.devicePixelRatio || 1, 2),
      autoDensity: true,
    });

    this.app = app;
    app.canvas.style.width = '100%';
    app.canvas.style.height = '100%';
    app.canvas.style.display = 'block';
    this.mount.appendChild(app.canvas);
    app.stage.addChild(this.shockwaveLayer, this.styleBackLayer, this.fireLayer, this.oreLayer, this.styleFrontLayer, this.particleLayer);
    await this.createOre();
    app.ticker.add((ticker) => this.update(ticker.deltaTime / 60));
  }

  setConfig(nextConfig: Partial<OreVFXConfig>) {
    this.config = { ...this.config, ...nextConfig }; // config：合并后的特效配置
  }

  setState(state: VFXState) {
    this.state = state; // state：切换当前特效状态
    this.stateTime = 0;
    if (state === 'trigger') this.clickBurst = Math.max(this.clickBurst, 0.55);
    if (state === 'explode') this.clickBurst = 1;
  }

  setLightStyle(style: LightStyleId) {
    this.lightStyleSystem?.setStyle(style); // lightStyleSystem：切换光效形态
  }

  play() {
    this.paused = false; // paused：恢复播放
    this.rootVisible(true);
  }

  pause() {
    this.paused = true; // paused：暂停播放
  }

  stop() {
    this.paused = true; // paused：停止播放
    this.rootVisible(false);
  }

  burst() {
    this.clickBurst = 1; // clickBurst：重置点击爆闪节奏
    this.setState('explode');
    this.shockwave?.burst();
  }

  destroy() {
    this.app?.destroy(true); // app：销毁 Pixi 应用
    this.app = null;
  }

  private async createOre() {
    const texture = await this.loadTexture(this.oreUrl); // texture：主体纹理
    const oreSprite = new Sprite(texture); // oreSprite：矿石主体
    oreSprite.anchor.set(0.5);
    oreSprite.x = this.centerX;
    oreSprite.y = this.centerY;
    oreSprite.width = this.assetSize;
    oreSprite.height = this.assetSize;
    oreSprite.eventMode = 'static';
    oreSprite.cursor = 'pointer';
    oreSprite.on('pointerdown', () => this.burst());
    this.oreSprite = oreSprite;

    this.fireLightSprite = new Sprite(texture); // fireLightSprite：火焰映亮矿石贴图
    this.fireLightSprite.anchor.set(0.5);
    this.fireLightSprite.x = this.centerX;
    this.fireLightSprite.y = this.centerY + 18;
    this.fireLightSprite.width = this.assetSize;
    this.fireLightSprite.height = this.assetSize;
    this.fireLightSprite.tint = 0x07858c;
    this.fireLightSprite.blendMode = 'add';
    this.fireLightSprite.alpha = 0.06;

    this.glowFilter = new GlowFilter(texture, this.centerX, this.centerY, this.assetSize);
    this.oreLayer.addChild(this.glowFilter.auraLayer, this.glowFilter.backGlow, oreSprite, this.fireLightSprite, this.glowFilter.frontGlow);
    this.flowFilter = new FlowFilter(this.oreLayer, oreSprite, this.centerX, this.centerY, this.config.edgeCount);
    this.oreDetailSprite = new Sprite(texture); // oreDetailSprite：恢复矿石细节贴图
    this.oreDetailSprite.anchor.set(0.5);
    this.oreDetailSprite.x = this.centerX;
    this.oreDetailSprite.y = this.centerY;
    this.oreDetailSprite.width = this.assetSize;
    this.oreDetailSprite.height = this.assetSize;
    this.oreDetailSprite.alpha = 0.32;
    this.oreLayer.addChild(this.oreDetailSprite);
    this.colorBoostSprite = new Sprite(texture); // colorBoostSprite：用原贴图加色，避免特效把主体压灰
    this.colorBoostSprite.anchor.set(0.5);
    this.colorBoostSprite.x = this.centerX;
    this.colorBoostSprite.y = this.centerY;
    this.colorBoostSprite.width = this.assetSize;
    this.colorBoostSprite.height = this.assetSize;
    this.colorBoostSprite.tint = 0xffffff;
    this.colorBoostSprite.blendMode = 'add';
    this.colorBoostSprite.alpha = 0.14;
    this.oreLayer.addChild(this.colorBoostSprite);
    this.fireFilter = new FireFilter(this.fireLayer, this.centerX, this.centerY + 156);
    this.lightStyleSystem = new LightStyleSystem(this.styleBackLayer, this.styleFrontLayer, this.centerX, this.centerY);
    this.sparkEmitter = new SparkEmitter(this.particleLayer, this.centerX, this.centerY + 160);
    this.shockwave = new Shockwave(this.shockwaveLayer, this.centerX, this.centerY);
  }

  private async loadTexture(url: string) {
    const image = new window.Image(); // image：使用浏览器原生解码，兼容 Expo Web 的 /assets/?unstable_path
    image.src = url;
    await image.decode();
    return Texture.from(image);
  }

  private update(delta: number) {
    if (this.paused) return;
    this.time += delta; // time：累加动画时间
    this.stateTime += delta;
    this.clickBurst *= Math.pow(0.91, delta * 60); // clickBurst：点击爆闪指数衰减
    this.updateStateMachine();
    const rhythm = this.getRhythm(); // rhythm：当前 SSR 节奏状态
    this.glowFilter?.update(this.time, this.config, rhythm);
    this.flowFilter?.update(this.time, delta, this.config, rhythm);
    this.fireFilter?.update(this.time, this.config, rhythm);
    this.lightStyleSystem?.update(this.time, this.config, rhythm);
    this.sparkEmitter?.update(this.time, delta, this.config, rhythm);
    this.shockwave?.update(delta, this.config.rippleColor, rhythm, this.config.energyWaveSize, this.config.explosionStrength);
    this.updateSubjectWobble(rhythm);
    if (this.fireLightSprite) {
      const firePulse = 0.034 + Math.sin(this.time * 2.4) * 0.014 + rhythm.afterglow * 0.025; // firePulse：火光照亮呼吸
      this.fireLightSprite.alpha = firePulse * Math.min(this.config.flamePower, 1.4);
      this.fireLightSprite.scale.set(1.01 + Math.sin(this.time * 1.8) * 0.012);
    }
    if (this.oreDetailSprite) {
      this.oreDetailSprite.alpha = 0.78 + Math.sin(this.time * 1.6) * 0.035 + rhythm.afterglow * 0.05; // oreDetailSprite：随呼吸恢复主体清晰度
    }
    if (this.colorBoostSprite) {
      this.colorBoostSprite.alpha = 0.16 + rhythm.charge * 0.08 + rhythm.burst * 0.2 + rhythm.afterglow * 0.08; // colorBoostSprite：爆闪时提亮原色
    }
  }

  private updateSubjectWobble(rhythm: VFXRhythm) {
    const wobblePower = 1.1 + rhythm.charge * 1.2 + rhythm.burst * 2.2 + rhythm.afterglow * 0.7; // wobblePower：主体轻微晃动强度
    const offsetX = Math.sin(this.time * 8.2) * wobblePower;
    const offsetY = Math.cos(this.time * 6.6) * wobblePower * 0.42;
    const rotation = Math.sin(this.time * 5.4) * 0.006 * (1 + rhythm.burst * 1.2);
    [this.oreSprite, this.oreDetailSprite, this.colorBoostSprite].forEach((sprite) => {
      if (!sprite) return;
      sprite.x = this.centerX + offsetX;
      sprite.y = this.centerY + offsetY;
      sprite.rotation = rotation;
    });
    if (this.fireLightSprite) {
      this.fireLightSprite.x = this.centerX + offsetX;
      this.fireLightSprite.y = this.centerY + 18 + offsetY;
      this.fireLightSprite.rotation = rotation;
    }
  }

  private updateStateMachine() {
    if (this.state === 'trigger' && this.stateTime > 0.42) this.setState('explode');
    if (this.state === 'explode' && this.stateTime > 0.72) this.setState('cooldown');
    if (this.state === 'cooldown' && this.stateTime > 1.35) this.setState('idle');
  }

  private getRhythm(): VFXRhythm {
    const cycleLength = 5.2; // cycleLength：SSR 节奏周期秒数
    const cycle = (this.time % cycleLength) / cycleLength; // cycle：当前周期进度
    const chargeBase = this.smoothstep(0.08, 0.46, cycle) * (1 - this.smoothstep(0.46, 0.56, cycle)); // chargeBase：周期聚能
    const burstBase = Math.exp(-Math.pow((cycle - 0.54) / 0.045, 2)); // burstBase：周期爆闪峰值
    const afterglowBase = this.smoothstep(0.56, 0.64, cycle) * (1 - this.smoothstep(0.64, 0.9, cycle)); // afterglowBase：周期余辉
    const scatterBase = this.smoothstep(0.58, 0.68, cycle) * (1 - this.smoothstep(0.68, 0.98, cycle)); // scatterBase：周期散落
    const burst = Math.min(1, Math.max(burstBase, this.clickBurst)); // burst：合成爆闪
    const scatter = Math.min(1, Math.max(scatterBase, this.clickBurst * 0.9)); // scatter：合成散落
    const stateCharge = this.state === 'trigger' ? 0.55 : 0; // stateCharge：状态聚能加成
    const stateAfterglow = this.state === 'cooldown' ? 0.5 : 0; // stateAfterglow：状态余辉加成
    return {
      charge: Math.min(1, chargeBase + stateCharge),
      burst,
      afterglow: Math.min(1, Math.max(afterglowBase, this.clickBurst * 0.42, stateAfterglow)),
      scatter,
      brightness: 0.56 + chargeBase * 0.16 + burst * 0.3 + afterglowBase * 0.13,
    };
  }

  private rootVisible(visible: boolean) {
    this.oreLayer.visible = visible;
    this.styleBackLayer.visible = visible;
    this.fireLayer.visible = visible;
    this.styleFrontLayer.visible = visible;
    this.particleLayer.visible = visible;
    this.shockwaveLayer.visible = visible;
  }

  private smoothstep(edge0: number, edge1: number, value: number) {
    const x = Math.min(1, Math.max(0, (value - edge0) / (edge1 - edge0))); // x：归一化进度
    return x * x * (3 - 2 * x);
  }
}
