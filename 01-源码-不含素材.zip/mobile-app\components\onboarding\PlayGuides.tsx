import AsyncStorage from "@react-native-async-storage/async-storage";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import {
  Award,
  CheckCircle,
  ChevronRight,
  Clock,
  Gift,
  Package,
  Search,
  ShoppingBag,
  Trophy,
  Truck,
  Users,
  X,
} from "lucide-react-native";
import React, { useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Pressable, Text, View } from "react-native";
import { TealGradient,  Colors, Shadows, s  } from "@/constants/theme";
import LuxeIcon from "@/components/shared/LuxeIcon";

type IconComponent = React.ComponentType<{
  color?: string;
  size?: number;
  strokeWidth?: number;
}>;

type GuideKind = "points" | "box" | "groupLottery";
type NextStepKind =
  | "pointsOrders"
  | "boxBackpack"
  | "boxOrders"
  | "boxDraws"
  | "groupRecords";

type GuideVariant = "light" | "dark";

type EntryItem = {
  key: GuideKind;
  icon: IconComponent;
  route: string;
  color: string;
  bg: string;
};

const ENTRY_ITEMS: EntryItem[] = [
  {
    key: "points",
    icon: Trophy,
    route: "/(tabs)/points",
    color: Colors.accent.gold,
    bg: "#F7F8F8",
  },
  {
    key: "box",
    icon: Gift,
    route: "/box",
    color: "#04A8AE",
    bg: "#F7F8F8",
  },
  {
    key: "groupLottery",
    icon: Users,
    route: "/group-lottery",
    color: "#04A8AE",
    bg: "#F7F8F8",
  },
];

const ENTRY_COPY = {
  zh: {
    sectionTitle: "玩法入口",
    close: "关闭",
    points: {
      title: "积分抽奖",
      desc: "用积分参与，开奖后查结果",
      bubble: "用积分也能抽商品，点这里开始",
    },
    box: {
      title: "盲盒商城",
      desc: "支付开盒，惊喜进背包",
      bubble: "想开随机惊喜？这里进入盲盒",
    },
    groupLottery: {
      title: "拼购抽奖",
      desc: "低价拼机会，满团后揭晓",
      bubble: "想低价拼机会？从这里参与",
    },
  },
  en: {
    sectionTitle: "Play entries",
    close: "Close",
    points: {
      title: "Points Draw",
      desc: "Spend points, then check reveal results",
      bubble: "Use points to draw products. Start here",
    },
    box: {
      title: "Blind Box",
      desc: "Open boxes and manage items",
      bubble: "Want a surprise? Enter blind boxes here",
    },
    groupLottery: {
      title: "Group Draw",
      desc: "Join a group, reveal when full",
      bubble: "Join low-price group draws from here",
    },
  },
};

const MODE_GUIDES = {
  zh: {
    points: {
      title: "积分商城购买指引",
      desc: "先看积分余额，再选择商品参与抽奖/兑换，开奖后到揭晓和订单里处理。",
      steps: [
        { title: "选商品", desc: "看清所需积分和揭晓时间" },
        { title: "用积分参与", desc: "确认后消耗积分参与" },
        { title: "查结果", desc: "中奖去订单/兑换，未中看记录" },
      ],
      primary: "看三步指引",
      actions: [
        { label: "查订单", route: "/points/orders", icon: Package },
        { label: "看揭晓", route: "/reveal", icon: Award },
      ],
    },
    box: {
      title: "盲盒商城购买指引",
      desc: "选择盲盒后支付开盒，开出的商品会进入背包，可发货、回收或查订单。",
      steps: [
        { title: "选盲盒", desc: "查看商品和概率" },
        { title: "支付开盒", desc: "选择数量后立即/按规则开盒" },
        { title: "处理奖品", desc: "去背包发货、回收或看记录" },
      ],
      primary: "看三步指引",
      actions: [
        { label: "我的背包", route: "/box/backpack", icon: ShoppingBag },
        { label: "开盒记录", route: "/box/draws", icon: Award },
      ],
    },
    groupLottery: {
      title: "拼购抽奖购买指引",
      desc: "选择活动后开团或参团，人数满了自动揭晓，中奖后到我的拼购处理。",
      steps: [
        { title: "选活动", desc: "看价格、人数和退款规则" },
        { title: "开团/参团", desc: "等待满团自动揭晓" },
        { title: "处理结果", desc: "中奖发货/回收，未中看返还" },
      ],
      primary: "看三步指引",
      actions: [
        { label: "我的拼购", route: "/group-lottery/my", icon: Search },
        { label: "继续参与", route: "/group-lottery", icon: Users },
      ],
    },
  },
  en: {
    points: {
      title: "Points Store Guide",
      desc: "Check your balance, pick a product, then view reveal and order results.",
      steps: [
        { title: "Pick", desc: "Check points cost and reveal time" },
        { title: "Join", desc: "Confirm and spend points" },
        { title: "Result", desc: "Handle wins in orders or records" },
      ],
      primary: "Start guide",
      actions: [
        { label: "Orders", route: "/points/orders", icon: Package },
        { label: "Reveals", route: "/reveal", icon: Award },
      ],
    },
    box: {
      title: "Blind Box Guide",
      desc: "Choose a box, pay to open, then ship, recycle, or review your items.",
      steps: [
        { title: "Choose", desc: "View items and odds" },
        { title: "Open", desc: "Pay and open by rules" },
        { title: "Handle", desc: "Use backpack, shipping, or records" },
      ],
      primary: "Start guide",
      actions: [
        { label: "Backpack", route: "/box/backpack", icon: ShoppingBag },
        { label: "Records", route: "/box/draws", icon: Award },
      ],
    },
    groupLottery: {
      title: "Group Draw Guide",
      desc: "Create or join a group, wait for reveal, then handle your result.",
      steps: [
        { title: "Pick", desc: "Check price, group size, and refund rules" },
        { title: "Join", desc: "Wait for the group to fill" },
        { title: "Result", desc: "Ship/recycle wins or check refunds" },
      ],
      primary: "Start guide",
      actions: [
        { label: "My Groups", route: "/group-lottery/my", icon: Search },
        { label: "Join More", route: "/group-lottery", icon: Users },
      ],
    },
  },
};

const NEXT_GUIDES = {
  zh: {
    pointsOrders: {
      title: "中奖/兑换后看这里",
      desc: "积分商品中奖或兑换后，订单会按处理中、发货中、已完成展示。",
      steps: ["处理中：等待商家处理", "发货中：可查物流", "已完成：可再次兑换或晒单"],
      actions: [
        { label: "看揭晓", route: "/reveal", icon: Award },
        { label: "继续兑换", route: "/(tabs)/points", icon: Trophy },
      ],
    },
    boxBackpack: {
      title: "开中商品下一步",
      desc: "背包里的商品可以选择发货、回收，或继续查看开盒记录。",
      steps: ["待处理：选择发货或回收", "已发货：去订单查物流", "可回收：确认后返还积分"],
      actions: [
        { label: "去发货", route: "/box/shipping", icon: Truck },
        { label: "去回收", route: "/box/recycle", icon: CheckCircle },
      ],
    },
    boxOrders: {
      title: "盲盒订单查询指引",
      desc: "盲盒发货订单会显示待支付、待发货、已发货和已完成状态。",
      steps: ["待支付：及时支付运费", "待发货：等待仓库处理", "已发货：进入订单详情查物流"],
      actions: [
        { label: "我的背包", route: "/box/backpack", icon: ShoppingBag },
        { label: "开盒记录", route: "/box/draws", icon: Award },
      ],
    },
    boxDraws: {
      title: "揭晓中奖指引",
      desc: "这里可以查看每次开盒/抽奖记录，点记录可看揭晓详情和中奖用户。",
      steps: ["待揭晓：等系统开奖", "已揭晓：查看中奖结果", "中奖后：去背包处理商品"],
      actions: [
        { label: "我的背包", route: "/box/backpack", icon: ShoppingBag },
        { label: "订单查询", route: "/box/orders", icon: Package },
      ],
    },
    groupRecords: {
      title: "拼购结果处理指引",
      desc: "我的拼购里能看到进行中、中奖、退款、发货和回收状态。",
      steps: ["进行中：等待满团", "已中奖：进入团详情处理", "未中奖/取消：查看返还状态"],
      actions: [
        { label: "继续拼购", route: "/group-lottery", icon: Users },
        { label: "查看全部", route: "/group-lottery/my", icon: Search },
      ],
    },
  },
  en: {
    pointsOrders: {
      title: "After Winning or Redeeming",
      desc: "Points orders show processing, shipping, and completed states.",
      steps: ["Processing: waiting for handling", "Shipping: track delivery", "Completed: redeem again or review"],
      actions: [
        { label: "Reveals", route: "/reveal", icon: Award },
        { label: "Redeem More", route: "/(tabs)/points", icon: Trophy },
      ],
    },
    boxBackpack: {
      title: "Next Step for Box Items",
      desc: "Items in your backpack can be shipped, recycled, or checked in records.",
      steps: ["Pending: ship or recycle", "Shipped: check orders", "Recyclable: confirm points return"],
      actions: [
        { label: "Ship", route: "/box/shipping", icon: Truck },
        { label: "Recycle", route: "/box/recycle", icon: CheckCircle },
      ],
    },
    boxOrders: {
      title: "Box Order Guide",
      desc: "Shipping orders show pending payment, waiting, shipped, and completed.",
      steps: ["Pending: pay freight", "Waiting: warehouse handling", "Shipped: open details for tracking"],
      actions: [
        { label: "Backpack", route: "/box/backpack", icon: ShoppingBag },
        { label: "Records", route: "/box/draws", icon: Award },
      ],
    },
    boxDraws: {
      title: "Reveal Result Guide",
      desc: "Tap a draw record to see reveal details and winner information.",
      steps: ["Waiting: system reveal pending", "Revealed: check result", "Won: handle item in backpack"],
      actions: [
        { label: "Backpack", route: "/box/backpack", icon: ShoppingBag },
        { label: "Orders", route: "/box/orders", icon: Package },
      ],
    },
    groupRecords: {
      title: "Group Draw Result Guide",
      desc: "My groups shows in-progress, won, refunded, shipped, and recycled states.",
      steps: ["In progress: wait for full group", "Won: handle in group detail", "Lost/canceled: check refund"],
      actions: [
        { label: "Join More", route: "/group-lottery", icon: Users },
        { label: "View All", route: "/group-lottery/my", icon: Search },
      ],
    },
  },
};

function getLangKey(language?: string): "zh" | "en" {
  return language?.startsWith("en") ? "en" : "zh";
}

function getDayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
    d.getDate(),
  ).padStart(2, "0")}`;
}

function useDailyVisibility(storageKey: string, delayMs = 0) {
  const [visible, setVisible] = useState(false);
  const dayKey = useMemo(getDayKey, []);

  useEffect(() => {
    let mounted = true;
    let timer: ReturnType<typeof setTimeout> | undefined;
    AsyncStorage.getItem(storageKey)
      .then((storedDay) => {
        if (!mounted || storedDay === dayKey) return;
        timer = setTimeout(() => {
          if (!mounted) return;
          setVisible(true);
          AsyncStorage.setItem(storageKey, dayKey).catch(() => {});
        }, delayMs);
      })
      .catch(() => {
        timer = setTimeout(() => mounted && setVisible(true), delayMs);
      });

    return () => {
      mounted = false;
      if (timer) clearTimeout(timer);
    };
  }, [dayKey, delayMs, storageKey]);

  const dismiss = () => {
    setVisible(false);
    AsyncStorage.setItem(storageKey, dayKey).catch(() => {});
  };

  return { visible, dismiss };
}

function getTheme(variant: GuideVariant) {
  const dark = variant === "dark";
  return {
    cardBg: dark ? "rgba(23,26,26,0.92)" : Colors.white,
    mutedBg: dark ? "rgba(255,255,255,0.08)" : Colors.neutral[50],
    border: dark ? "rgba(255,255,255,0.12)" : Colors.neutral[100],
    title: dark ? Colors.white : Colors.neutral[900],
    text: dark ? "rgba(255,255,255,0.76)" : Colors.neutral[600],
    faint: dark ? "rgba(255,255,255,0.56)" : Colors.neutral[500],
  };
}

export function PlayEntryDock({
  source,
  compact = false,
  delayMs = 9000,
}: {
  source: "home" | "categories";
  compact?: boolean;
  delayMs?: number;
}) {
  const router = useRouter();
  const { i18n } = useTranslation();
  const lang = getLangKey(i18n.language);
  const copy = ENTRY_COPY[lang];
  const { visible, dismiss } = useDailyVisibility(`play_entry_bubble:${source}`, delayMs);
  const visibleEntryItems = ENTRY_ITEMS.filter((item) => item.key !== "groupLottery");
  const activeIndex = new Date().getDate() % visibleEntryItems.length;

  return (
    <View
      style={{
        marginHorizontal: compact ? 0 : s(16),
        marginTop: compact ? s(4) : s(12),
        marginBottom: compact ? s(10) : s(12),
        paddingTop: visible ? s(42) : 0,
      }}
    >
      <Text
        style={{
          color: Colors.neutral[700],
          fontSize: s(13),
          fontWeight: "700",
          marginBottom: s(8),
        }}
      >
        {copy.sectionTitle}
      </Text>
      <View style={{ flexDirection: compact ? "column" : "row", gap: s(8), width: "100%" }}>
        {visibleEntryItems.map((item, index) => {
          const Icon = item.icon;
          const itemCopy = copy[item.key];
          const showBubble = visible && index === activeIndex;
          const showHeaderBubble = showBubble && source === "home";
          return (
            <Pressable
              key={item.key}
              onPress={() => router.push(item.route as any)}
              style={({ pressed }) => ({
                flex: compact ? undefined : 1,
                minWidth: 0,
                width: compact ? "100%" : undefined,
                minHeight: compact ? s(70) : s(76),
                padding: s(9),
                borderRadius: s(8),
                borderWidth: 1,
                borderColor: `${item.color}28`,
                backgroundColor: Colors.white,
                transform: [{ scale: pressed ? 0.98 : 1 }],
                ...Shadows.sm,
              })}
            >
              {showBubble ? (
                <View
                  style={{
                    position: "absolute",
                    top: showHeaderBubble ? -s(510) : -s(40),
                    left: showHeaderBubble
                      ? undefined
                      : index === visibleEntryItems.length - 1
                        ? undefined
                        : 0,
                    right: showHeaderBubble
                      ? s(8)
                      : index === visibleEntryItems.length - 1
                        ? 0
                        : undefined,
                    width: s(150),
                    paddingHorizontal: s(10),
                    paddingVertical: s(7),
                    borderRadius: s(8),
                    backgroundColor: Colors.neutral[900],
                    zIndex: 20,
                    ...Shadows.md,
                  }}
                >
                  <View style={{ flexDirection: "row", alignItems: "center", gap: s(6) }}>
                    <Text
                      numberOfLines={2}
                      style={{ flex: 1, color: Colors.white, fontSize: s(11), lineHeight: s(15) }}
                    >
                      {itemCopy.bubble}
                    </Text>
                    <Pressable onPress={dismiss} hitSlop={8} accessibilityLabel={copy.close}>
                      <X size={s(13)} color="rgba(255,255,255,0.78)" />
                    </Pressable>
                  </View>
                </View>
              ) : null}
              <View
                style={{
                  width: s(30),
                  height: s(30),
                  borderRadius: s(8),
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: item.bg,
                  marginBottom: s(7),
                }}
              >
                <LuxeIcon
                  Icon={Icon}
                  tone="neutral"
                  variant="plain"
                  size={30}
                  iconSize={22}
                  color={Colors.luxe.ink}
                  accentColor={item.color}
                />
              </View>
              <Text
                numberOfLines={1}
                style={{ color: Colors.neutral[900], fontSize: s(12), fontWeight: "800" }}
              >
                {itemCopy.title}
              </Text>
              <Text
                numberOfLines={2}
                style={{
                  color: Colors.neutral[500],
                  fontSize: s(10),
                  lineHeight: s(14),
                  marginTop: s(3),
                }}
              >
                {itemCopy.desc}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

export function ModeGuideCard({
  kind,
  variant = "light",
  onStartTour,
}: {
  kind: GuideKind;
  variant?: GuideVariant;
  onStartTour?: () => void;
}) {
  const router = useRouter();
  const { i18n } = useTranslation();
  const lang = getLangKey(i18n.language);
  const guide = MODE_GUIDES[lang][kind];
  const { visible, dismiss } = useDailyVisibility(`play_mode_guide:${kind}`, 0);
  const theme = getTheme(variant);

  if (!visible) return null;

  return (
    <View
      style={{
        marginHorizontal: s(16),
        marginTop: s(12),
        marginBottom: s(10),
        borderRadius: s(8),
        borderWidth: 1,
        borderColor: theme.border,
        backgroundColor: theme.cardBg,
        overflow: "hidden",
        ...Shadows.sm,
      }}
    >
      <LinearGradient
        colors={
          variant === "dark"
            ? ["rgba(4,168,174,0.18)", "rgba(4,168,174,0.12)"]
            : ["#FFFFFF", "#FFFFFF"]
        }
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={{ padding: s(14) }}
      >
        <View style={{ flexDirection: "row", alignItems: "flex-start", gap: s(10) }}>
          <View
            style={{
              width: s(34),
              height: s(34),
              borderRadius: s(8),
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: variant === "dark" ? "rgba(4,168,174,0.16)" : "#F7F8F8",
            }}
          >
            <Clock size={s(18)} color={Colors.accent.gold} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: theme.title, fontSize: s(15), fontWeight: "800" }}>
              {guide.title}
            </Text>
            <Text style={{ color: theme.text, fontSize: s(12), lineHeight: s(18), marginTop: s(4) }}>
              {guide.desc}
            </Text>
          </View>
          <Pressable onPress={dismiss} hitSlop={10}>
            <X size={s(17)} color={theme.faint} />
          </Pressable>
        </View>

        <View style={{ flexDirection: "row", gap: s(8), marginTop: s(12) }}>
          {guide.steps.map((step, index) => (
            <View
              key={step.title}
              style={{
                flex: 1,
                padding: s(8),
                borderRadius: s(8),
                backgroundColor: theme.mutedBg,
                borderWidth: 1,
                borderColor: theme.border,
              }}
            >
              <Text style={{ color: Colors.brand.red, fontSize: s(11), fontWeight: "800" }}>
                {index + 1}. {step.title}
              </Text>
              <Text
                numberOfLines={2}
                style={{ color: theme.text, fontSize: s(10), lineHeight: s(14), marginTop: s(3) }}
              >
                {step.desc}
              </Text>
            </View>
          ))}
        </View>

        <View style={{ flexDirection: "row", alignItems: "center", gap: s(8), marginTop: s(12) }}>
          {onStartTour ? (
            <Pressable
              onPress={onStartTour}
              style={({ pressed }) => ({
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: s(4),
                paddingHorizontal: s(12),
                height: s(34),
                borderRadius: s(8),
                transform: [{ scale: pressed ? 0.98 : 1 }],
              })}
            >
              <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 8, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
              <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 8 }} />
              <Text style={{ color: Colors.white, fontSize: s(12), fontWeight: "800" }}>
                {guide.primary}
              </Text>
              <ChevronRight size={s(14)} color={Colors.white} />
            </Pressable>
          ) : null}
          {guide.actions.map((action) => {
            const Icon = action.icon;
            return (
              <Pressable
                key={action.route}
                onPress={() => router.push(action.route as any)}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: s(4),
                  paddingHorizontal: s(10),
                  height: s(34),
                  borderRadius: s(8),
                  borderWidth: 1,
                  borderColor: theme.border,
                  backgroundColor: theme.mutedBg,
                }}
              >
                <Icon size={s(13)} color={variant === "dark" ? Colors.accent.gold : Colors.brand.red} />
                <Text style={{ color: theme.title, fontSize: s(11), fontWeight: "700" }}>
                  {action.label}
                </Text>
              </Pressable>
            );
          })}
        </View>
      </LinearGradient>
    </View>
  );
}

export function NextStepGuide({
  kind,
  variant = "light",
}: {
  kind: NextStepKind;
  variant?: GuideVariant;
}) {
  const router = useRouter();
  const { i18n } = useTranslation();
  const lang = getLangKey(i18n.language);
  const guide = NEXT_GUIDES[lang][kind];
  const theme = getTheme(variant);

  return (
    <View
      style={{
        marginHorizontal: s(16),
        marginTop: s(12),
        marginBottom: s(10),
        padding: s(13),
        borderRadius: s(8),
        borderWidth: 1,
        borderColor: theme.border,
        backgroundColor: theme.cardBg,
        ...Shadows.sm,
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "flex-start", gap: s(10) }}>
        <View
          style={{
            width: s(32),
            height: s(32),
            borderRadius: s(8),
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: variant === "dark" ? "rgba(4,168,174,0.16)" : "#F7F8F8",
          }}
        >
          <Search size={s(17)} color={Colors.accent.gold} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: theme.title, fontSize: s(14), fontWeight: "800" }}>
            {guide.title}
          </Text>
          <Text style={{ color: theme.text, fontSize: s(12), lineHeight: s(18), marginTop: s(3) }}>
            {guide.desc}
          </Text>
        </View>
      </View>

      <View style={{ marginTop: s(10), gap: s(6) }}>
        {guide.steps.map((step) => (
          <View key={step} style={{ flexDirection: "row", alignItems: "center", gap: s(7) }}>
            <View
              style={{
                width: s(5),
                height: s(5),
                borderRadius: s(3),
                backgroundColor: Colors.brand.red,
              }}
            />
            <Text style={{ flex: 1, color: theme.text, fontSize: s(11), lineHeight: s(16) }}>
              {step}
            </Text>
          </View>
        ))}
      </View>

      <View style={{ flexDirection: "row", gap: s(8), marginTop: s(12) }}>
        {guide.actions.map((action) => {
          const Icon = action.icon;
          return (
            <Pressable
              key={action.route}
              onPress={() => router.push(action.route as any)}
              style={({ pressed }) => ({
                flex: 1,
                height: s(34),
                borderRadius: s(8),
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                gap: s(5),
                borderWidth: 1,
                borderColor: theme.border,
                backgroundColor: theme.mutedBg,
                transform: [{ scale: pressed ? 0.98 : 1 }],
              })}
            >
              <Icon size={s(14)} color={variant === "dark" ? Colors.accent.gold : Colors.brand.red} />
              <Text style={{ color: theme.title, fontSize: s(12), fontWeight: "700" }}>
                {action.label}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
