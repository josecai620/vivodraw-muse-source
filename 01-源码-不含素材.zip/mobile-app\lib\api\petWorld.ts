import { fetchAuthPost, fetchReadApi } from "@/lib/api/legacyHttp";

type RemotePetDailyGift = {
  enabled?: boolean | number | string;
  title?: string;
  message?: string;
  amount?: number | string;
  min_amount?: number | string;
  max_amount?: number | string;
  common_min_amount?: number | string;
  common_max_amount?: number | string;
  common_weight_percent?: number | string;
  reward_points?: number | string;
  reward_coins?: number | string;
  reward_unit?: string;
  claimed_today?: boolean | number | string;
  can_claim?: boolean | number | string;
  accepted?: boolean | number | string;
  integral?: number | string;
  reward_coin_balance?: number | string;
  coin_balance?: number | string;
  exchange_rate?: number | string;
  convertible_points?: number | string;
  remaining_coins?: number | string;
  coins_spent?: number | string;
  points?: number | string;
  point_balance?: number | string;
  next_claim_at?: string;
  gift_tier?: number | string;
  desk_pet_id?: string;
  unlocked?: boolean | number | string;
  unlock?: RemotePetUnlockStatus;
};

type RemotePetUnlockPath = {
  type?: string;
  need?: number | string;
  have?: number | string;
  met?: boolean | number | string;
  href?: string;
};

type RemotePetUnlockPet = {
  desk_pet_id?: string;
  tier?: number | string;
  unlocked?: boolean | number | string;
  reason?: string;
  unlock_cost?: number | string;
  gift_percent?: number | string;
  gift_hint_min?: number | string;
  gift_hint_max?: number | string;
  usd_price?: number | string;
  usd_mode?: string;
  can_pay_usd?: boolean | number | string;
  paths?: RemotePetUnlockPath[];
};

type RemotePetUnlockStatus = {
  progress?: {
    checkin_days?: number | string;
    pay_count?: number | string;
    invite_count?: number | string;
    intimacy_value?: number | string;
    unlock_step?: number | string;
    next_pet_id?: string;
    next_pet_need?: number | string;
    next_pet_have?: number | string;
    unlocked_count?: number | string;
  };
  requirements?: Record<string, {
    checkin_days?: number | string;
    pay_count?: number | string;
    invite_count?: number | string;
  }>;
  pets?: Record<string, RemotePetUnlockPet>;
  unlocked_ids?: string[];
  default_pet_id?: string;
  next_pet_id?: string;
  wallet_intimacy?: number | string;
  now_money?: number | string;
  accepted?: boolean | number | string;
  message?: string;
  unlock_cost?: number | string;
  usd_paid?: number | string;
};

export type PetDailyGiftStatus = {
  enabled: boolean;
  title: string;
  message: string;
  amount: number;
  minAmount: number;
  maxAmount: number;
  commonMinAmount: number;
  commonMaxAmount: number;
  commonWeightPercent: number;
  rewardPoints: number;
  rewardCoins: number;
  rewardUnit: "coin" | "point";
  claimedToday: boolean;
  canClaim: boolean;
  accepted: boolean;
  balance?: number;
  coinBalance?: number;
  exchangeRate?: number;
  convertiblePoints?: number;
  remainingCoins?: number;
  nextClaimAt?: string;
  giftTier: number;
  deskPetId: string;
  unlocked: boolean;
  unlock?: PetUnlockStatus;
};

export type PetUnlockPath = {
  type: "checkin" | "spend" | "invite" | string;
  need: number;
  have: number;
  met: boolean;
  href: string;
};

export type PetUnlockStatus = {
  progress: {
    checkinDays: number;
    payCount: number;
    inviteCount: number;
    intimacyValue: number;
    unlockStep: number;
    nextPetId: string;
    nextPetNeed: number;
    nextPetHave: number;
    unlockedCount: number;
  };
  pets: Record<string, {
    deskPetId: string;
    tier: number;
    unlocked: boolean;
    reason: string;
    unlockCost?: number;
    giftPercent?: number;
    giftHintMin?: number;
    giftHintMax?: number;
    usdPrice?: number;
    usdMode?: "none" | "topup" | "fixed" | string;
    canPayUsd?: boolean;
    paths: PetUnlockPath[];
  }>;
  unlockedIds: string[];
  defaultPetId: string;
  nowMoney?: number;
};

const DEFAULT_PET_GIFT: PetDailyGiftStatus = {
  enabled: true,
  title: "Pet figure gift",
  message: "Your pet brings coins daily. Higher-tier pets bring more. 10 coins can convert to 1 point.",
  amount: 10,
  minAmount: 10,
  maxAmount: 60,
  commonMinAmount: 10,
  commonMaxAmount: 36,
  commonWeightPercent: 80,
  rewardPoints: 0,
  rewardCoins: 10,
  rewardUnit: "coin",
  claimedToday: false,
  canClaim: true,
  accepted: false,
  giftTier: 1,
  deskPetId: "cat_programmer",
  unlocked: true,
};

export async function fetchPetDailyGiftStatus(deskPetId = ""): Promise<PetDailyGiftStatus | undefined> {
  const query = deskPetId ? `?desk_pet_id=${encodeURIComponent(deskPetId)}` : "";
  const payload = await fetchReadApi<RemotePetDailyGift>(`/api/user/pet-world/daily-gift${query}`);
  return payload ? normalizePetDailyGift(payload) : undefined;
}

export async function fetchPetUnlockStatus(): Promise<PetUnlockStatus | undefined> {
  const payload = await fetchReadApi<RemotePetUnlockStatus>("/api/user/pet-world/unlocks");
  return payload ? normalizePetUnlockStatus(payload) : undefined;
}

export async function claimPetUnlock(deskPetId: string, requestId = "", payMode: "bond" | "usd" = "bond"): Promise<{
  ok: boolean;
  unlock?: PetUnlockStatus;
  message: string;
  accepted: boolean;
}> {
  const result = await fetchAuthPost<RemotePetUnlockStatus>("/api/user/pet-world/unlocks", {
    desk_pet_id: deskPetId,
    request_id: requestId || `desk_unlock:${Date.now()}`,
    pay_mode: payMode,
  });
  return {
    ok: result.ok,
    unlock: result.data ? normalizePetUnlockStatus(result.data) : undefined,
    message: String(result.data?.message || result.message || (result.ok ? "Pet unlocked." : "Unlock failed.")),
    accepted: toBoolean(result.data?.accepted),
  };
}

export async function claimPetDailyGift(deskPetId = ""): Promise<{ ok: boolean; gift?: PetDailyGiftStatus; points: number; coins: number; message: string; status?: number }> {
  const result = await fetchAuthPost<RemotePetDailyGift>("/api/user/pet-world/daily-gift", deskPetId ? { desk_pet_id: deskPetId } : {});
  const gift = result.data ? normalizePetDailyGift(result.data) : undefined;

  return {
    ok: result.ok,
    gift,
    points: gift?.rewardPoints ?? 0,
    coins: gift?.rewardCoins ?? 0,
    message: result.message || gift?.message || (result.ok ? "Gift claimed." : "Pet gift failed. Try again later."),
    status: result.status,
  };
}

export async function exchangeRewardCoins(coins = 0): Promise<{ ok: boolean; gift?: PetDailyGiftStatus; points: number; coinsSpent: number; message: string; status?: number }> {
  const result = await fetchAuthPost<RemotePetDailyGift>("/api/reward_coin/exchange", { coins });
  const gift = result.data ? normalizePetDailyGift(result.data) : undefined;

  return {
    ok: result.ok,
    gift,
    points: toNumber(result.data?.points),
    coinsSpent: toNumber(result.data?.coins_spent),
    message: result.message || (result.ok ? "Coins converted." : "Coin conversion failed. Try again later."),
    status: result.status,
  };
}

function normalizePetDailyGift(payload: RemotePetDailyGift): PetDailyGiftStatus {
  const minAmount = toNumber(payload.min_amount) || DEFAULT_PET_GIFT.minAmount;
  const maxAmount = toNumber(payload.max_amount) || DEFAULT_PET_GIFT.maxAmount;
  const commonMinAmount = toNumber(payload.common_min_amount) || minAmount;
  const commonMaxAmount = toNumber(payload.common_max_amount) || Math.min(30, maxAmount);
  const commonWeightPercent = toNumber(payload.common_weight_percent) || DEFAULT_PET_GIFT.commonWeightPercent;
  const amount = toNumber(payload.amount) || minAmount;
  const rewardUnit = String(payload.reward_unit || DEFAULT_PET_GIFT.rewardUnit) === "point" ? "point" : "coin";
  const rewardCoins = toNumber(payload.reward_coins) || (rewardUnit === "coin" ? amount : 0);
  const rewardPoints = toNumber(payload.reward_points) || (rewardUnit === "point" ? amount : 0);
  const claimedToday = toBoolean(payload.claimed_today);
  const enabled = payload.enabled === undefined ? true : toBoolean(payload.enabled);
  const unlocked = payload.unlocked === undefined ? true : toBoolean(payload.unlocked);
  const canClaim = enabled && !claimedToday && unlocked && (payload.can_claim === undefined ? true : toBoolean(payload.can_claim));

  return {
    enabled,
    title: String(payload.title || DEFAULT_PET_GIFT.title),
    message: String(payload.message || (claimedToday ? "Today's gift is claimed. Come back tomorrow." : DEFAULT_PET_GIFT.message)),
    amount,
    minAmount,
    maxAmount,
    commonMinAmount,
    commonMaxAmount,
    commonWeightPercent,
    rewardPoints,
    rewardCoins,
    rewardUnit,
    claimedToday,
    canClaim,
    accepted: toBoolean(payload.accepted),
    balance: payload.integral === undefined && payload.point_balance === undefined ? undefined : toNumber(payload.point_balance ?? payload.integral),
    coinBalance: payload.reward_coin_balance === undefined && payload.coin_balance === undefined ? undefined : toNumber(payload.reward_coin_balance ?? payload.coin_balance),
    exchangeRate: payload.exchange_rate === undefined ? undefined : toNumber(payload.exchange_rate),
    convertiblePoints: payload.convertible_points === undefined ? undefined : toNumber(payload.convertible_points),
    remainingCoins: payload.remaining_coins === undefined ? undefined : toNumber(payload.remaining_coins),
    nextClaimAt: payload.next_claim_at,
    giftTier: toNumber(payload.gift_tier) || DEFAULT_PET_GIFT.giftTier,
    deskPetId: String(payload.desk_pet_id || DEFAULT_PET_GIFT.deskPetId),
    unlocked: payload.unlocked === undefined ? true : toBoolean(payload.unlocked),
    unlock: payload.unlock ? normalizePetUnlockStatus(payload.unlock) : undefined,
  };
}

function normalizePetUnlockStatus(payload: RemotePetUnlockStatus): PetUnlockStatus {
  const progress = payload.progress || {};
  const petsRaw = payload.pets || {};
  const pets: PetUnlockStatus["pets"] = {};
  for (const [id, pet] of Object.entries(petsRaw)) {
    pets[id] = {
      deskPetId: String(pet.desk_pet_id || id),
      tier: toNumber(pet.tier) || 1,
      unlocked: toBoolean(pet.unlocked),
      reason: String(pet.reason || ""),
      unlockCost: toNumber(pet.unlock_cost),
      giftPercent: toNumber(pet.gift_percent),
      giftHintMin: toNumber(pet.gift_hint_min),
      giftHintMax: toNumber(pet.gift_hint_max),
      usdPrice: toNumber(pet.usd_price),
      usdMode: String(pet.usd_mode || ""),
      canPayUsd: toBoolean(pet.can_pay_usd),
      paths: (pet.paths || []).map((path) => ({
        type: String(path.type || ""),
        need: toNumber(path.need),
        have: toNumber(path.have),
        met: toBoolean(path.met),
        href: String(path.href || ""),
      })),
    };
  }
  return {
    progress: {
      checkinDays: toNumber(progress.checkin_days),
      payCount: toNumber(progress.pay_count),
      inviteCount: toNumber(progress.invite_count),
      intimacyValue: toNumber(progress.intimacy_value ?? payload.wallet_intimacy),
      unlockStep: toNumber(progress.unlock_step),
      nextPetId: String(progress.next_pet_id || payload.next_pet_id || ""),
      nextPetNeed: toNumber(progress.next_pet_need),
      nextPetHave: toNumber(progress.next_pet_have ?? progress.intimacy_value),
      unlockedCount: toNumber(progress.unlocked_count),
    },
    pets,
    unlockedIds: Array.isArray(payload.unlocked_ids) ? payload.unlocked_ids.map(String) : Object.keys(pets).filter((id) => pets[id]?.unlocked),
    defaultPetId: String(payload.default_pet_id || "cat_programmer"),
    nowMoney: payload.now_money === undefined ? undefined : toNumber(payload.now_money),
  };
}


export type PetDeskBondExpression = {
  id: string;
  label: string;
  minLevel: number;
  unlocked: boolean;
};

export type PetDeskBondStatus = {
  deskPetId: string;
  intimacyValue: number;
  intimacyLevel: number;
  playsToday: number;
  playLimit: number;
  playsLeft: number;
  canPlay: boolean;
  playGain: number;
  snacksToday: number;
  snackLimit: number;
  snacksLeft: number;
  canSnack: boolean;
  snackGain: number;
  snackCost: number;
  coinBalance: number;
  nextLevelAt: number;
  hint: string;
  expressions: PetDeskBondExpression[];
  accepted?: boolean;
  action?: string;
  gain?: number;
  levelUp?: boolean;
  previewAction?: string;
  message?: string;
  dialogue?: PetDeskDialogue;
};

export type PetDeskDialogue = {
  title: string;
  message: string;
  ctaLabel: string;
  route: string;
  rewardHint: string;
  mood: string;
  source?: string;
  foundPoints?: number;
  foundPointsNew?: boolean;
};

export async function fetchPetDeskBond(deskPetId = ""): Promise<PetDeskBondStatus | undefined> {
  const query = deskPetId ? `?desk_pet_id=${encodeURIComponent(deskPetId)}` : "";
  const payload = await fetchReadApi<Record<string, unknown>>(`/api/user/pet-world/desk-bond${query}`);
  return payload ? normalizePetDeskBond(payload) : undefined;
}

export async function playPetDeskBond(deskPetId = "", action: "play" | "snack" = "play"): Promise<{ ok: boolean; bond?: PetDeskBondStatus; message: string; status?: number }> {
  const requestId = `desk_bond_${action}_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
  const result = await fetchAuthPost<Record<string, unknown>>("/api/user/pet-world/desk-bond/play", {
    desk_pet_id: deskPetId || undefined,
    request_id: requestId,
    action,
  });
  const bond = result.data ? normalizePetDeskBond(result.data) : undefined;
  return {
    ok: result.ok,
    bond,
    message: result.message || bond?.message || (result.ok ? "Bond updated." : "Play failed."),
    status: result.status,
  };
}

export async function fetchPetDeskDialogue(input: {
  deskPetId?: string;
  trigger?: string;
  userMessage?: string;
  route?: string;
  locale?: string;
}): Promise<PetDeskDialogue | undefined> {
  const result = await fetchAuthPost<Record<string, unknown>>("/api/user/pet-world/desk-dialogue", {
    trigger: input.trigger || "idle",
    user_message: input.userMessage || "",
    desk_pet_id: input.deskPetId || "",
    client_context: {
      route: input.route || "/pet-deck",
      desk_pet_id: input.deskPetId || "",
      locale: input.locale || "",
    },
  });
  if (!result.ok || !result.data) return undefined;
  return normalizePetDeskDialogue(result.data);
}

export function dialogueMatchesLocale(dialogue: { title?: string; message?: string } | null | undefined, lang: string) {
  if (!dialogue) return false;
  const sample = `${dialogue.title || ""} ${dialogue.message || ""}`;
  if (!sample.trim()) return false;
  const hasHan = /[\u4e00-\u9fff]/.test(sample);
  return String(lang || "").toLowerCase().startsWith("zh") ? hasHan : !hasHan;
}

function normalizePetDeskBond(payload: Record<string, unknown>): PetDeskBondStatus {
  const dialogueRaw = payload.dialogue;
  const expressionsRaw = Array.isArray(payload.expressions) ? payload.expressions : [];
  return {
    deskPetId: String(payload.desk_pet_id || "cat_programmer"),
    intimacyValue: toNumber(payload.intimacy_value),
    intimacyLevel: toNumber(payload.intimacy_level) || 1,
    playsToday: toNumber(payload.plays_today),
    playLimit: toNumber(payload.play_limit) || 5,
    playsLeft: toNumber(payload.plays_left),
    canPlay: payload.can_play === undefined ? true : toBoolean(payload.can_play),
    playGain: toNumber(payload.play_gain) || 3,
    snacksToday: toNumber(payload.snacks_today),
    snackLimit: toNumber(payload.snack_limit) || 3,
    snacksLeft: toNumber(payload.snacks_left),
    canSnack: payload.can_snack === undefined ? false : toBoolean(payload.can_snack),
    snackGain: toNumber(payload.snack_gain) || 10,
    snackCost: toNumber(payload.snack_cost) || 10,
    coinBalance: toNumber(payload.coin_balance),
    nextLevelAt: toNumber(payload.next_level_at),
    hint: String(payload.hint || ""),
    expressions: expressionsRaw.map((item) => {
      const row = (item && typeof item === "object" ? item : {}) as Record<string, unknown>;
      return {
        id: String(row.id || ""),
        label: String(row.label || row.id || ""),
        minLevel: toNumber(row.min_level) || 1,
        unlocked: toBoolean(row.unlocked),
      };
    }).filter((item) => item.id),
    accepted: payload.accepted === undefined ? undefined : toBoolean(payload.accepted),
    action: payload.action === undefined ? undefined : String(payload.action),
    gain: payload.gain === undefined ? undefined : toNumber(payload.gain),
    levelUp: payload.level_up === undefined ? undefined : toBoolean(payload.level_up),
    previewAction: payload.preview_action === undefined ? undefined : String(payload.preview_action),
    message: payload.message === undefined ? undefined : String(payload.message),
    dialogue: dialogueRaw && typeof dialogueRaw === "object" ? normalizePetDeskDialogue(dialogueRaw as Record<string, unknown>) : undefined,
  };
}

function normalizePetDeskDialogue(payload: Record<string, unknown>): PetDeskDialogue {
  return {
    title: String(payload.title || "Pet tip"),
    message: String(payload.message || ""),
    ctaLabel: String(payload.cta_label || "Open"),
    route: String(payload.route || "/pet-deck"),
    rewardHint: String(payload.reward_hint || ""),
    mood: String(payload.mood || "guide"),
    source: payload.source === undefined ? undefined : String(payload.source),
    foundPoints: payload.found_points === undefined ? undefined : toNumber(payload.found_points),
    foundPointsNew: payload.found_points_new === undefined ? undefined : toBoolean(payload.found_points_new),
  };
}

function toNumber(value: unknown) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function toBoolean(value: unknown) {
  if (typeof value === "boolean") return value;
  if (typeof value === "number") return value > 0;
  if (typeof value === "string") return ["1", "true", "yes"].includes(value.trim().toLowerCase());
  return false;
}
