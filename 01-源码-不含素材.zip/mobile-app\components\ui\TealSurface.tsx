import React from "react";
import { View, type StyleProp, type ViewStyle } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Shadows, TealGradient } from "@/constants/theme";

/**
 * TealSurface —— 全站统一的「teal 立体表面」
 * 组合三层质感：
 *   1) 同色系三段渐变（受光面→主色→背光面），方向可选
 *   2) 顶部一道白色内光泽（玻璃受光，避免一片死青）
 *   3) 外层同色 teal 柔光投影（微微浮起）
 * 用于实心 teal 的主按钮、统计横幅、徽标、图标底等。
 */
export type TealDirection = "lr" | "rl" | "tb" | "bt";

const DIR: Record<
  TealDirection,
  { start: { x: number; y: number }; end: { x: number; y: number }; order: [number, number, number] }
> = {
  lr: { start: { x: 0, y: 0.5 }, end: { x: 1, y: 0.5 }, order: [2, 1, 0] },
  rl: { start: { x: 1, y: 0.5 }, end: { x: 0, y: 0.5 }, order: [0, 1, 2] },
  tb: { start: { x: 0.5, y: 0 }, end: { x: 0.5, y: 1 }, order: [0, 1, 2] },
  bt: { start: { x: 0.5, y: 1 }, end: { x: 0.5, y: 0 }, order: [2, 1, 0] },
};

interface TealSurfaceProps {
  children?: React.ReactNode;
  style?: StyleProp<ViewStyle>;
  contentStyle?: StyleProp<ViewStyle>;
  radius?: number;
  direction?: TealDirection;
  /** 同色柔光投影，默认开启 */
  glow?: boolean;
  /** 顶部白色内光泽，默认开启 */
  gloss?: boolean;
  /** 自定义渐变（如 danger 红），默认 teal 三段 */
  colors?: [string, string, string];
}

export default function TealSurface({
  children,
  style,
  contentStyle,
  radius = 16,
  direction = "tb",
  glow = true,
  gloss = true,
  colors,
}: TealSurfaceProps) {
  const d = DIR[direction];
  const seq: [string, string, string] = colors ?? [
    TealGradient.light,
    TealGradient.base,
    TealGradient.dark,
  ];
  const gradient: [string, string, string] = [seq[d.order[0]], seq[d.order[1]], seq[d.order[2]]];

  return (
    <View style={[{ borderRadius: radius }, glow ? Shadows.tealBlock : null, style]}>
      <LinearGradient
        colors={gradient}
        start={d.start}
        end={d.end}
        style={[{ flex: 1, borderRadius: radius, overflow: "hidden" }, contentStyle]}
      >
        {gloss ? (
          <LinearGradient
            pointerEvents="none"
            colors={["rgba(255,255,255,0.34)", "rgba(255,255,255,0)"]}
            start={{ x: 0.5, y: 0 }}
            end={{ x: 0.5, y: 1 }}
            style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}
          />
        ) : null}
        {children}
      </LinearGradient>
    </View>
  );
}
