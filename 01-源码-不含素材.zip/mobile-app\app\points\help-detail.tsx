import React from "react";
import { ScrollView, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { PageHeader } from "@/components/shared";
import { usePointsHelpDetail } from "@/hooks";

export default function PointsHelpDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const detailId = Number(id ?? 0);
  const { data } = usePointsHelpDetail(detailId);
  const detail = (data as any)?.data?.data ?? (data as any)?.data ?? {};
  const content = String(detail?.content ?? detail?.value ?? "No content");

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Help Detail" />
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="p-4">
          <View className="bg-white border border-gray-100 rounded-xl p-4">
            <Text className="text-lg font-bold text-gray-900 mb-3">{detail?.title ?? "Article"}</Text>
            <Text className="text-sm text-gray-700 leading-6">{content.replace(/<[^>]+>/g, "")}</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
