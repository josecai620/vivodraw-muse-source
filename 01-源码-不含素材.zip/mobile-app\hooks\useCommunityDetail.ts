import { useEffect, useMemo, useState } from "react";

import { fetchCommunityDetail, type CommunityDetailModel } from "@/lib/api/community";

export function useCommunityDetail(id: string) {
  const [model, setModel] = useState<CommunityDetailModel>({ source: "fallback", comments: [] });
  const [isLoading, setIsLoading] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    if (!id) {
      setModel({ source: "fallback", comments: [], notice: "Community detail is not available yet." });
      setIsLoading(false);
      return;
    }

    let cancelled = false;
    setIsLoading(true);

    fetchCommunityDetail(id)
      .then((nextModel) => {
        if (!cancelled) {
          setModel(nextModel);
        }
      })
      .finally(() => {
        if (!cancelled) {
          setIsLoading(false);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [id, refreshKey]);

  return useMemo(
    () => ({
      ...model,
      isLoading,
      isFallback: model.source === "fallback",
      refresh: () => setRefreshKey((key) => key + 1),
    }),
    [isLoading, model],
  );
}
