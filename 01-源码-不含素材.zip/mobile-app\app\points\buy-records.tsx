import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, FlatList, Text, View } from "react-native";
import { Image } from "expo-image";
import { useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useDetailHqjl } from "@/hooks";
import { unwrapApiPagedList } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";
import { toNum } from "@/lib/points/cloudBuyParse";
import { resolveUserAvatarSource } from "@/lib/userAvatar";
import { Colors } from "@/constants/theme";

const JOIN_TEAL = Colors.primary.DEFAULT;
const PAGE_SIZE = 20;

type JoinRow = {
  id: string;
  uid: number;
  nickname: string;
  avatar: string;
  shares: number;
  time: string;
};

export default function CloudBuyRecordsScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const { id, bianhao } = useLocalSearchParams<{ id: string; bianhao?: string }>();
  const productId = toNum(id);
  const period = String(bianhao ?? "");
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState<JoinRow[]>([]);
  const [hasMore, setHasMore] = useState(true);

  const { data, isFetching, isLoading } = useDetailHqjl(productId, period, page, PAGE_SIZE);

  useEffect(() => {
    setPage(1);
    setRows([]);
    setHasMore(true);
  }, [productId, period]);

  useEffect(() => {
    const list = unwrapApiPagedList<any>(data).map((row, idx) => ({
      id: String(row?.id ?? `${page}-${idx}`),
      uid: toNum(row?.uid),
      nickname: String(row?.nickname ?? row?.username ?? ""),
      avatar: normalizeImageUrl(String(row?.avatar ?? "")),
      shares: toNum(row?.total_num ?? row?.huanqu_num ?? row?.gonumber),
      time: String(row?.add_time ?? row?.time ?? ""),
    }));
    if (!data) return;
    setRows((prev) => {
      if (page === 1) return list;
      const seen = new Set(prev.map((r) => r.id));
      return [...prev, ...list.filter((r) => !seen.has(r.id))];
    });
    setHasMore(list.length >= PAGE_SIZE);
  }, [data, page]);

  const title = useMemo(
    () => `${t("pointsMall.allJoinRecords")}${period ? ` · ${t("pointsMall.periodN", { n: period })}` : ""}`,
    [t, period],
  );

  return (
    <View className="flex-1" style={{ backgroundColor: "#fff" }}>
      <PageHeader title={title} />
      <FlatList
        data={rows}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{
          paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 16,
          paddingLeft: 18,
        }}
        onEndReached={() => {
          if (!isFetching && hasMore && rows.length > 0) setPage((p) => p + 1);
        }}
        onEndReachedThreshold={0.35}
        ListEmptyComponent={
          isLoading ? (
            <ActivityIndicator style={{ marginTop: 40 }} color={JOIN_TEAL} />
          ) : (
            <Text className="text-center text-gray-400 mt-10">{t("pointsMall.noJoinRecords")}</Text>
          )
        }
        ListFooterComponent={
          rows.length === 0 ? null : hasMore ? (
            <ActivityIndicator style={{ marginVertical: 16 }} color={JOIN_TEAL} />
          ) : (
            <Text className="text-center text-gray-400 py-4 text-xs">{t("pointsMall.noMoreRecords")}</Text>
          )
        }
        renderItem={({ item }) => (
          <View
            style={{
              borderLeftWidth: 1,
              borderLeftColor: "#efefef",
              paddingVertical: 14,
              paddingRight: 16,
              position: "relative",
            }}
          >
            <View
              style={{
                position: "absolute",
                left: -21,
                top: 16,
                width: 40,
                height: 40,
                borderRadius: 20,
                overflow: "hidden",
                backgroundColor: "#eee",
              }}
            >
              <Image source={resolveUserAvatarSource(item.avatar, item.uid)} style={{ width: 40, height: 40 }} contentFit="cover" />
            </View>
            <View style={{ marginLeft: 28 }}>
              <Text className="text-sm font-semibold" style={{ color: Colors.primary.DEFAULT }}>
                {item.nickname || t("pointsMall.anonymous")}
              </Text>
              <Text className="text-xs text-gray-500 mt-0.5">
                {t("pointsMall.joinedShares", { n: item.shares || 0 })}
              </Text>
              <Text className="text-[11px] text-gray-400 mt-0.5">{item.time}</Text>
            </View>
          </View>
        )}
      />
      <PointsMallTabBar />
    </View>
  );
}
