import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { ChevronRight, ShoppingCart } from "lucide-react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import CloudBuyImageSlider from "@/components/points/CloudBuyImageSlider";
import CloudBuyPrevWinner from "@/components/points/CloudBuyPrevWinner";
import { ProductImageRevealStamp, WinnerAvatar } from "@/components/reveal/WinnerBadges";
import {
  useAddPointsCart,
  useAddPointsCollect,
  usePointsBalance,
  usePointsCartCount,
  usePointsProductDetail,
  useDetailLshqz,
  useTrackPointsTaskEvent,
} from "@/hooks";
import { useAuthStore } from "@/store/auth";
import { unwrapApiData } from "@/lib/api/response";
import type { PointsCartCount } from "@/lib/api/points";
import { openCloudBuyCartList, rememberPendingCartItem } from "@/lib/points/openCloudBuyCart";
import {
  cloudBuyShares,
  collectImageUrls,
  mapKaijiangRow,
  pickPrevWinner,
  toNum,
  toRecordList,
  type CloudBuyPeriod,
} from "@/lib/points/cloudBuyParse";

const JOIN_TEAL = Colors.primary.DEFAULT;
const CART_TEAL = Colors.primary.dark;
const COLLECT_TEAL = Colors.primary.DEFAULT;

export default function PointsProductScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id, bianhao: bianhaoParam, kaijiang: kaijiangParam } = useLocalSearchParams<{
    id: string;
    bianhao?: string;
    kaijiang?: string;
  }>();
  const productId = toNum(id);
  const isLoggedIn = useAuthStore((st) => st.isLoggedIn);

  const { data: detailData, isLoading } = usePointsProductDetail(productId);
  const { data: balanceData } = usePointsBalance();
  const { data: lshqzData } = useDetailLshqz(productId, 1, 50);
  const { data: cartCountData } = usePointsCartCount();
  const addToCart = useAddPointsCart();
  const addCollect = useAddPointsCollect();
  const trackTask = useTrackPointsTaskEvent();

  useEffect(() => {
    if (productId > 0) {
      trackTask.mutate({ event: "browse", ref: String(productId) });
    }
    // 同一商品详情只记一次浏览
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [productId]);

  const detail = (detailData as any)?.data?.detail ?? (detailData as any)?.data ?? (detailData as any) ?? {};
  const storeInfo = detail?.storeInfo ?? detail;
  const payload = (detailData as any)?.data ?? detailData ?? {};

  const defaultBianhao = String(storeInfo?.bianhao ?? detail?.bianhao ?? "1");
  const queryBianhao = String(bianhaoParam ?? "").trim();
  const activeBianhao = queryBianhao || defaultBianhao;
  const kaijiangId = toNum(kaijiangParam);
  const revealed = kaijiangId > 0;
  const [shareQty, setShareQty] = useState(1);

  const name = String(storeInfo?.store_name ?? storeInfo?.title ?? "");
  const points = Math.max(toNum(storeInfo?.price ?? storeInfo?.integral ?? storeInfo?.points, 1), 1);
  const valueLabel = toNum(storeInfo?.ot_price ?? storeInfo?.cost, 0) || points;

  const { total: totalNeed, sold: joined, remain } = cloudBuyShares({
    ...storeInfo,
    price: points,
  });
  const barPct = totalNeed > 0 ? Math.max(2, Math.min(100, (joined / totalNeed) * 100)) : 0;

  const images: string[] = collectImageUrls(
    storeInfo?.slider_image,
    storeInfo?.gallery,
    storeInfo?.images,
    storeInfo?.image,
    detail?.slider_image,
    payload?.slider_image,
  );

  const history = useMemo(() => {
    const rows = toRecordList(lshqzData)
      .map((row) => mapKaijiangRow(row, productId))
      .filter(Boolean) as CloudBuyPeriod[];
    const seen = new Set<string>();
    const uniq: CloudBuyPeriod[] = [];
    for (const row of rows) {
      if (seen.has(row.bianhao)) continue;
      seen.add(row.bianhao);
      uniq.push(row);
    }
    if (!uniq.some((c) => c.bianhao === defaultBianhao)) {
      uniq.unshift({
        bianhao: defaultBianhao,
        productId,
        kaijiangId: 0,
        nickname: "",
        avatar: "",
        unique: "",
        shares: 0,
        revealAt: "",
        buyAt: "",
      });
    }
    return uniq.slice(0, 80);
  }, [lshqzData, defaultBianhao, productId]);

  const revealedRow = history.find((p) => p.kaijiangId === kaijiangId && kaijiangId > 0);
  const prevWinner = pickPrevWinner(
    history.filter((p) => p.kaijiangId > 0),
    activeBianhao,
  );

  const cartCount =
    Number(unwrapApiData<PointsCartCount>(cartCountData, {}).count ?? 0) || 0;
  const realBalance =
    (balanceData as any)?.data?.integral ?? (balanceData as any)?.integral;
  const displayBalance = isLoggedIn ? Number(realBalance ?? 0).toLocaleString() : "0";

  const requireLogin = () => {
    if (isLoggedIn) return true;
    router.push("/auth");
    return false;
  };

  const goPeriod = (p: { bianhao: string; kaijiangId: number }) => {
    if (p.kaijiangId > 0) {
      router.replace({
        pathname: "/points/product",
        params: { id: String(productId), bianhao: p.bianhao, kaijiang: String(p.kaijiangId) },
      } as never);
      return;
    }
    router.replace({ pathname: "/points/product", params: { id: String(productId) } } as never);
  };

  const onJoin = () => {
    if (!requireLogin()) return;
    if (remain <= 0) return;
    const qty = Math.max(1, Math.min(remain, shareQty));
    rememberPendingCartItem({
      id: 0,
      productId,
      name,
      image: images[0] ?? "",
      num: qty,
      bianhao: activeBianhao,
      remain,
      totalNeed,
    });
    addToCart.mutate(
      { productId, cartNum: qty },
      { onSettled: () => openCloudBuyCartList(router) },
    );
  };

  const onAddCart = (qty = shareQty) => {
    if (!requireLogin()) return;
    addToCart.mutate(
      { productId, cartNum: qty },
      {
        onSuccess: () => Alert.alert(t("pointsMall.addedToCart"), t("pointsMall.addedToCartDesc")),
        onError: (e: any) => Alert.alert(t("common.error"), e?.message ?? "Failed"),
      },
    );
  };

  const onCollect = () => {
    if (!requireLogin()) return;
    addCollect.mutate(
      { id: productId } as any,
      {
        onSuccess: () => Alert.alert(t("pointsMall.collected"), t("pointsMall.collectedDesc")),
        onError: (e: any) => Alert.alert(t("common.error"), e?.message ?? "Failed"),
      },
    );
  };

  if (isLoading) {
    return (
      <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
        <PageHeader title={t("pointsMall.productDetail")} />
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={JOIN_TEAL} />
        </View>
      </View>
    );
  }

  const menuRows = [
    {
      key: "trend",
      label: t("pointsMall.trendChart"),
      hint: "",
      onPress: () =>
        router.push({ pathname: "/points/trend", params: { id: String(productId) } } as never),
    },
    {
      key: "records",
      label: t("pointsMall.allJoinRecords"),
      hint: "",
      onPress: () =>
        router.push({
          pathname: "/points/buy-records",
          params: { id: String(productId), bianhao: activeBianhao },
        } as never),
    },
    {
      key: "desc",
      label: t("pointsMall.richDetail"),
      hint: t("pointsMall.wifiHint"),
      onPress: () =>
        router.push({ pathname: "/points/goods-desc", params: { id: String(productId) } } as never),
    },
  ];

  return (
    <View className="flex-1" style={{ backgroundColor: "#f4f4f4" }}>
      <PageHeader
        title={t("pointsMall.productDetail")}
        rightElement={
          <Pressable className="p-2 relative" onPress={() => openCloudBuyCartList(router)}>
            <ShoppingCart size={20} color="#171A1A" />
            {cartCount > 0 ? (
              <View
                className="absolute top-1 right-0 min-w-[16px] h-4 px-1 rounded-full items-center justify-center"
                style={{ backgroundColor: JOIN_TEAL }}
              >
                <Text className="text-[9px] font-bold text-white">
                  {cartCount > 99 ? "99+" : cartCount}
                </Text>
              </View>
            ) : null}
          </Pressable>
        }
      />

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        className="bg-white border-b border-gray-100"
        style={{ flexGrow: 0 }}
        contentContainerStyle={{ paddingHorizontal: 8, paddingVertical: 8 }}
      >
        {history.map((p) => {
          const active = p.bianhao === activeBianhao;
          return (
            <Pressable
              key={`${p.productId}-${p.bianhao}-${p.kaijiangId}`}
              onPress={() => goPeriod(p)}
              style={{ paddingHorizontal: 10, paddingVertical: 6 }}
            >
              <Text
                className="text-sm pb-1"
                style={{
                  color: active ? JOIN_TEAL : "#666",
                  fontWeight: active ? "700" : "400",
                  borderBottomWidth: active ? 2 : 0,
                  borderBottomColor: JOIN_TEAL,
                }}
              >
                {t("pointsMall.periodN", { n: p.bianhao })}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 8 }}
      >
        {revealed && revealedRow ? (
          <View className="bg-white px-3 py-3 mb-px" style={{ position: "relative", overflow: "visible" }}>
            <View className="flex-row">
              <View style={{ marginRight: 12 }}>
                <WinnerAvatar
                  uri={revealedRow.avatar || undefined}
                  uid={revealedRow.uid || undefined}
                  seed={revealedRow.nickname || revealedRow.bianhao}
                  size={80}
                  variant="winner"
                  rounded="square"
                />
              </View>
              <View className="flex-1">
                <Text className="text-xs text-gray-500">
                  {t("pointsMall.prevTotalShares")}{" "}
                  <Text className="font-bold" style={{ color: Colors.primary.dark }}>
                    {revealedRow.shares}
                  </Text>{" "}
                  {t("pointsMall.shareUnit")}
                </Text>
                <Text className="text-xs text-gray-500 mt-0.5">
                  {t("pointsMall.revealTime")} {revealedRow.revealAt || "-"}
                </Text>
                <Text className="text-xs text-gray-500 mt-0.5">
                  {t("pointsMall.joinTime")} {revealedRow.buyAt || "-"}
                </Text>
              </View>
            </View>
            <View className="flex-row items-center justify-between mt-2">
              <Text className="text-xs text-gray-700">
                {t("pointsMall.luckyCode")}：
                <Text className="font-bold" style={{ color: Colors.primary.dark }}>
                  {revealedRow.unique || "-"}
                </Text>
              </Text>
              <Pressable
                onPress={() =>
                  router.push({
                    pathname: "/reveal/algorithm",
                    params: {
                      id: String(kaijiangId),
                      productId: String(productId),
                      bianhao: activeBianhao,
                    },
                  } as never)
                }
              >
                <Text className="text-xs" style={{ color: COLLECT_TEAL }}>
                  {t("pointsMall.viewCalc")}
                </Text>
              </Pressable>
            </View>
          </View>
        ) : null}

        <View style={{ position: "relative" }}>
          <CloudBuyImageSlider images={images} height={280} />
          {revealed ? <ProductImageRevealStamp imageHeight={280} /> : null}
        </View>

        <View className="bg-white px-3 py-3 mb-1">
          <Text className="text-[15px] font-bold text-gray-900 mb-1">
            ({t("pointsMall.periodN", { n: activeBianhao })}){name}
          </Text>
          <Text className="text-sm text-gray-500 mb-2">
            {t("pointsMall.valueLabel")}：<Text className="text-gray-600">{valueLabel}</Text>
          </Text>

          {revealed ? (
            <>
              <View className="h-9 items-center justify-center mb-2" style={{ backgroundColor: "#aaa" }}>
                <Text className="text-white font-bold">{t("pointsMall.periodRevealed")}</Text>
              </View>
              <Pressable
                className="h-9 flex-row items-center justify-between px-3"
                style={{ backgroundColor: Colors.primary.softer, borderWidth: 1, borderColor: Colors.primary.light }}
                onPress={() =>
                  router.replace({ pathname: "/points/product", params: { id: String(productId) } } as never)
                }
              >
                <Text className="text-sm text-gray-800">
                  {t("pointsMall.periodN", { n: defaultBianhao })} {t("pointsMall.ongoingNow")}
                </Text>
                <Text className="text-sm" style={{ color: JOIN_TEAL }}>
                  {t("pointsMall.viewDetail")}
                </Text>
              </Pressable>
            </>
          ) : (
            <>
              <View className="h-2 rounded-full bg-gray-100 overflow-hidden mb-1.5">
                <View className="h-full rounded-full" style={{ width: `${barPct}%`, backgroundColor: JOIN_TEAL }} />
              </View>
              <View className="flex-row justify-between mb-3">
                <Text className="text-xs font-semibold" style={{ color: JOIN_TEAL }}>
                  {joined} {t("pointsMall.joined")}
                </Text>
                <Text className="text-xs text-gray-500">
                  {totalNeed} {t("pointsMall.totalNeed")}
                </Text>
                <Text className="text-xs font-semibold" style={{ color: Colors.primary.dark }}>
                  {remain} {t("pointsMall.remain")}
                </Text>
              </View>

              <View className="flex-row items-center justify-between mb-3">
                <Text className="text-sm text-gray-700">{t("pointsMall.shareQty")}</Text>
                <View className="flex-row items-center">
                  <Pressable
                    className="w-8 h-8 rounded border border-gray-200 items-center justify-center"
                    onPress={() => setShareQty((q) => Math.max(1, q - 1))}
                  >
                    <Text className="text-base font-bold text-gray-600">-</Text>
                  </Pressable>
                  <Text className="mx-4 text-base font-bold">{shareQty}</Text>
                  <Pressable
                    className="w-8 h-8 rounded border border-gray-200 items-center justify-center"
                    onPress={() => setShareQty((q) => Math.min(Math.max(remain, 1), q + 1))}
                  >
                    <Text className="text-base font-bold text-gray-600">+</Text>
                  </Pressable>
                </View>
              </View>

              <View className="flex-row mb-2" style={{ gap: 6 }}>
                <Pressable
                  className="h-10 items-center justify-center"
                  style={{ flex: 1.4, backgroundColor: JOIN_TEAL, borderRadius: 3 }}
                  onPress={onJoin}
                >
                  <Text className="text-white font-bold text-[15px]">{t("pointsMall.joinNow")}</Text>
                </Pressable>
                <Pressable
                  className="h-10 items-center justify-center"
                  style={{ flex: 1, backgroundColor: CART_TEAL, borderRadius: 3 }}
                  onPress={() => onAddCart()}
                >
                  <Text className="text-white font-bold text-[15px]">{t("pointsMall.addToCart")}</Text>
                </Pressable>
                <Pressable
                  className="h-10 items-center justify-center"
                  style={{ width: 72, backgroundColor: COLLECT_TEAL, borderRadius: 3 }}
                  onPress={onCollect}
                >
                  <Text className="text-white font-bold text-[15px]">{t("pointsMall.collect")}</Text>
                </Pressable>
              </View>
              <Text className="text-[11px] text-gray-400">
                {t("pointsMall.balance")}: {displayBalance}
              </Text>
            </>
          )}
        </View>

        {menuRows.map((row) => (
          <Pressable
            key={row.key}
            className="bg-white mx-2 mt-2 px-3.5 h-[38px] flex-row items-center"
            style={{
              borderWidth: 1,
              borderColor: "#dcdcdc",
              borderRadius: 5,
            }}
            onPress={row.onPress}
          >
            <Text className="flex-1 text-sm text-gray-700">
              {row.label}
              {row.hint ? <Text className="text-[10px] text-gray-400">{row.hint}</Text> : null}
            </Text>
            <ChevronRight size={14} color="#9CA3AF" />
          </Pressable>
        ))}

        {prevWinner ? (
          <CloudBuyPrevWinner winner={prevWinner} onPress={() => goPeriod(prevWinner)} />
        ) : null}
      </ScrollView>

      <PointsMallTabBar />
    </View>
  );
}
