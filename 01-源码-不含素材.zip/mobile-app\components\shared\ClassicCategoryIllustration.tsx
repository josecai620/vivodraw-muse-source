import type React from "react";
import { View } from "react-native";
import Svg, { Circle, Defs, Ellipse, G, LinearGradient, Path, Rect, Stop } from "react-native-svg";

export type ClassicCategoryIllustrationName =
  | "auto"
  | "fashion"
  | "electronics"
  | "beauty"
  | "outdoor"
  | "home"
  | "jewelry"
  | "apple";

const PALETTES: Record<
  ClassicCategoryIllustrationName,
  {
    primaryA: string;
    primaryB: string;
    secondaryA: string;
    secondaryB: string;
    accentA: string;
    accentB: string;
    shadow: string;
    stitch: string;
    line: string;
  }
> = {
  auto: {
    primaryA: "#787878",
    primaryB: "#787878",
    secondaryA: "#C0C0C0",
    secondaryB: "#C0C0C0",
    accentA: "#787878",
    accentB: "#787878",
    shadow: "#787878",
    stitch: "#C0C0C0",
    line: "#787878",
  },
  fashion: {
    primaryA: "#787878",
    primaryB: "#787878",
    secondaryA: "#C0C0C0",
    secondaryB: "#787878",
    accentA: "#787878",
    accentB: "#787878",
    shadow: "#C0C0C0",
    stitch: "#C0C0C0",
    line: "#787878",
  },
  electronics: {
    primaryA: "#787878",
    primaryB: "#787878",
    secondaryA: "#C0C0C0",
    secondaryB: "#C0C0C0",
    accentA: "#787878",
    accentB: "#787878",
    shadow: "#C0C0C0",
    stitch: "#C0C0C0",
    line: "#787878",
  },
  beauty: {
    primaryA: "#D5D5D5",
    primaryB: "#B4B4B4",
    secondaryA: "#F8F8F8",
    secondaryB: "#CACACA",
    accentA: "#787878",
    accentB: "#787878",
    shadow: "#D7D7D7",
    stitch: "#F8F8F8",
    line: "#808080",
  },
  outdoor: {
    primaryA: "#DBDBDB",
    primaryB: "#B6B6B6",
    secondaryA: "#787878",
    secondaryB: "#787878",
    accentA: "#C2C2C2",
    accentB: "#989898",
    shadow: "#D5D5D5",
    stitch: "#F8F8F8",
    line: "#858585",
  },
  home: {
    primaryA: "#E4E4E4",
    primaryB: "#C0C0C0",
    secondaryA: "#787878",
    secondaryB: "#787878",
    accentA: "#CFCFCF",
    accentB: "#A3A3A3",
    shadow: "#DCDCDC",
    stitch: "#E4E4E4",
    line: "#7A7A7A",
  },
  jewelry: {
    primaryA: "#DADADA",
    primaryB: "#ACACAC",
    secondaryA: "#F8F8F8",
    secondaryB: "#CCCCCC",
    accentA: "#CFCFCF",
    accentB: "#8F8F8F",
    shadow: "#F8F8F8",
    stitch: "#F8F8F8",
    line: "#6F6F6F",
  },
  apple: {
    primaryA: "#787878",
    primaryB: "#787878",
    secondaryA: "#C0C0C0",
    secondaryB: "#B7B7B7",
    accentA: "#787878",
    accentB: "#787878",
    shadow: "#C0C0C0",
    stitch: "#F8F8F8",
    line: "#787878",
  },
};

type Props = {
  name: ClassicCategoryIllustrationName;
  size?: number;
};

function Tile({
  name,
  children,
}: {
  name: ClassicCategoryIllustrationName;
  children: React.ReactNode;
}) {
  const palette = PALETTES[name];

  return (
    <Svg width="100%" height="100%" viewBox="0 0 64 64">
      <Defs>
        <LinearGradient id={`tile-${name}`} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor="#FFFFFF" />
          <Stop offset="0.55" stopColor="#FFFFFF" />
          <Stop offset="1" stopColor="#F8F8F8" />
        </LinearGradient>
        <LinearGradient id={`inner-${name}`} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor="#FFFFFF" stopOpacity="0.95" />
          <Stop offset="1" stopColor="#F8F8F8" stopOpacity="0.38" />
        </LinearGradient>
        <LinearGradient id={`primary-${name}`} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={palette.primaryA} />
          <Stop offset="1" stopColor={palette.primaryB} />
        </LinearGradient>
        <LinearGradient id={`secondary-${name}`} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={palette.secondaryA} />
          <Stop offset="1" stopColor={palette.secondaryB} />
        </LinearGradient>
        <LinearGradient id={`accent-${name}`} x1="0" y1="0" x2="1" y2="1">
          <Stop offset="0" stopColor={palette.accentA} />
          <Stop offset="1" stopColor={palette.accentB} />
        </LinearGradient>
      </Defs>

      <Ellipse cx="32" cy="48" rx="14" ry="5.5" fill={palette.shadow} opacity="0.18" />
      <Rect x="6" y="6.8" width="52" height="52" rx="16" fill="#C0C0C0" opacity="0.4" />
      <Rect
        x="5"
        y="5"
        width="54"
        height="54"
        rx="16"
        fill={`url(#tile-${name})`}
        stroke="#C0C0C0"
        strokeWidth="1.2"
      />
      <Rect
        x="9"
        y="9"
        width="46"
        height="46"
        rx="13.5"
        fill="none"
        stroke={palette.stitch}
        strokeWidth="1.05"
        strokeDasharray="2.2 2"
        opacity="0.94"
      />
      <Rect x="12" y="12" width="40" height="40" rx="11.5" fill={`url(#inner-${name})`} />
      <Path
        d="M15 13H49"
        stroke="#FFFFFF"
        strokeOpacity="0.82"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      {children}
    </Svg>
  );
}

function AutoIcon() {
  const p = PALETTES.auto;
  return (
    <>
      <Ellipse cx="32" cy="40.5" rx="15" ry="6.2" fill="#F8F8F8" opacity="0.95" />
      <Path
        d="M19.3 36.3L22.3 29.8C23 28.2 24.7 27.1 26.5 27.1H37.5C39.3 27.1 41 28.2 41.7 29.8L44.7 36.3"
        fill="url(#secondary-auto)"
      />
      <Path
        d="M18.8 35.8H45.2V39.8C45.2 41.4 43.9 42.7 42.3 42.7H21.7C20.1 42.7 18.8 41.4 18.8 39.8V35.8Z"
        fill="url(#primary-auto)"
        stroke={p.line}
        strokeWidth="1"
      />
      <Path d="M24.6 32H39.4" stroke="#FFFFFF" strokeWidth="1.3" strokeLinecap="round" />
      <Rect x="25.6" y="28.4" width="12.8" height="4.4" rx="2" fill="#FFFFFF" opacity="0.78" />
      <Circle cx="24.6" cy="42.8" r="3" fill="#787878" />
      <Circle cx="39.4" cy="42.8" r="3" fill="#787878" />
    </>
  );
}

function FashionIcon() {
  const p = PALETTES.fashion;
  return (
    <>
      <Ellipse cx="32" cy="41.5" rx="14" ry="5.4" fill="#F8F8F8" opacity="0.96" />
      <Path
        d="M22.3 37.8C25.3 33.1 30.9 30.4 38.4 30.7C40.1 30.8 41.9 31.4 43.7 32.4L41 35.8C39.4 35.2 37.8 34.8 36.4 34.8C32.2 34.8 29.1 37.2 27 41.2H21.8C21.4 40.2 21.5 38.9 22.3 37.8Z"
        fill="url(#primary-fashion)"
        stroke={p.line}
        strokeWidth="1"
      />
      <Path
        d="M31.9 28.1C33.8 25.9 35.7 24.8 37.5 24.8C39.2 24.8 40.6 25.5 41.8 26.8L40.2 29.4C39.5 28.5 38.7 28 37.8 28C36.9 28 35.7 28.6 34.3 29.9Z"
        fill="url(#secondary-fashion)"
        stroke={p.line}
        strokeWidth="0.8"
      />
      <Circle cx="39.9" cy="39.8" r="3.1" fill="#787878" />
      <Path
        d="M24.5 40.8H38.2"
        stroke="#FFFFFF"
        strokeWidth="1.2"
        strokeLinecap="round"
        opacity="0.84"
      />
    </>
  );
}

function ElectronicsIcon() {
  const p = PALETTES.electronics;
  return (
    <>
      <Ellipse cx="32" cy="41.5" rx="14.5" ry="5.8" fill="#F8F8F8" opacity="0.94" />
      <Rect
        x="21.8"
        y="19.8"
        width="20.4"
        height="22.2"
        rx="4.8"
        fill="url(#secondary-electronics)"
      />
      <Rect
        x="23.8"
        y="22"
        width="16.4"
        height="15.5"
        rx="2.5"
        fill="#FFFFFF"
        stroke="#C0C0C0"
        strokeWidth="0.8"
      />
      <Path d="M29 40H35" stroke="#787878" strokeWidth="1.4" strokeLinecap="round" />
      <Rect x="28" y="26.6" width="8" height="2.2" rx="1.1" fill="url(#primary-electronics)" />
      <Rect x="26.2" y="31" width="11.6" height="1.8" rx="0.9" fill="#C0C0C0" />
      <Path
        d="M25.4 43H38.6"
        stroke={p.line}
        strokeWidth="1"
        strokeLinecap="round"
        opacity="0.58"
      />
    </>
  );
}

function BeautyIcon() {
  const p = PALETTES.beauty;
  return (
    <>
      <Ellipse cx="32" cy="42" rx="14.5" ry="5.9" fill="#F8F8F8" opacity="0.95" />
      <Rect x="28.8" y="20.2" width="6.4" height="7.2" rx="1.8" fill="url(#secondary-beauty)" />
      <Path
        d="M25.2 27.1H38.8V39.1C38.8 41.7 36.7 43.8 34.1 43.8H29.9C27.3 43.8 25.2 41.7 25.2 39.1V27.1Z"
        fill="url(#primary-beauty)"
        stroke={p.line}
        strokeWidth="1"
      />
      <Path d="M28.9 31.1H35.1" stroke="#FFFFFF" strokeWidth="1.2" strokeLinecap="round" />
      <Rect x="27.3" y="28.5" width="9.4" height="1.5" rx="0.75" fill="#FFFFFF" opacity="0.72" />
      <Circle cx="32" cy="38.7" r="1.9" fill="url(#accent-beauty)" opacity="0.8" />
    </>
  );
}

function OutdoorIcon() {
  const p = PALETTES.outdoor;
  return (
    <>
      <Ellipse cx="32" cy="42.3" rx="14.3" ry="5.8" fill="#F1F1F1" opacity="0.94" />
      <Path
        d="M32 19.7C26.3 23.8 22.8 29.3 22.8 35.9C22.8 40.6 26.7 43.8 32 43.8C37.3 43.8 41.2 40.6 41.2 35.9C41.2 29.3 37.7 23.8 32 19.7Z"
        fill="url(#secondary-outdoor)"
        stroke={p.line}
        strokeWidth="1"
      />
      <Path d="M32 22.6V42.8" stroke="#F9F9F9" strokeWidth="1.2" strokeLinecap="round" />
      <Path
        d="M32 29.3L25.6 33"
        stroke="url(#accent-outdoor)"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <Path
        d="M32 34L38.6 30.1"
        stroke="url(#accent-outdoor)"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <Circle cx="32" cy="35.4" r="1.8" fill="#F9F9F9" />
    </>
  );
}

function HomeIcon() {
  const p = PALETTES.home;
  return (
    <>
      <Ellipse cx="32" cy="42" rx="14.8" ry="5.8" fill="#F1F1F1" opacity="0.94" />
      <Path
        d="M20.6 30.4L32 21.4L43.4 30.4"
        fill="url(#secondary-home)"
        stroke={p.line}
        strokeWidth="1"
      />
      <Path
        d="M23.6 29.9H40.4V43.4H23.6Z"
        fill="url(#primary-home)"
        stroke={p.line}
        strokeWidth="1"
      />
      <Rect x="29.2" y="35" width="5.6" height="8.4" rx="1.3" fill="#FFFFFF" />
      <Rect x="26.1" y="32" width="3.5" height="3.5" rx="0.8" fill="#FAFAFA" />
      <Rect x="34.4" y="32" width="3.5" height="3.5" rx="0.8" fill="#FAFAFA" />
    </>
  );
}

function JewelryIcon() {
  const p = PALETTES.jewelry;
  return (
    <>
      <Ellipse cx="32" cy="41.8" rx="14.1" ry="5.4" fill="#FFFFFF" opacity="0.96" />
      <Path
        d="M25.3 23.5H38.7L43.8 30.4L32 42.8L20.2 30.4Z"
        fill="url(#primary-jewelry)"
        stroke={p.line}
        strokeWidth="1"
        strokeLinejoin="round"
      />
      <Path d="M25.3 23.5L32 30.4L38.7 23.5" fill="none" stroke="#FFFFFF" strokeWidth="1.2" />
      <Path d="M32 30.4V42.3" fill="none" stroke="#FFFFFF" strokeWidth="1.2" />
      <Path
        d="M20.2 30.4H43.8"
        fill="none"
        stroke="url(#secondary-jewelry)"
        strokeWidth="1"
        opacity="0.72"
      />
      <Circle cx="32" cy="18.8" r="1.6" fill="url(#secondary-jewelry)" />
    </>
  );
}

function AppleIcon() {
  const p = PALETTES.apple;
  return (
    <>
      <Ellipse cx="32" cy="42" rx="14.5" ry="5.8" fill="#F8F8F8" opacity="0.95" />
      <Path
        d="M31.4 26.1C28.1 22.8 22.9 24.7 22.9 31C22.9 38 27 43.2 32 43.2C37.1 43.2 41.2 38.2 41.2 31.2C41.2 25.1 35.3 22.8 31.4 26.1Z"
        fill="url(#primary-apple)"
        stroke={p.line}
        strokeWidth="1"
      />
      <Path
        d="M33.3 22.6C34.2 20.7 35.8 19.6 37.7 19.6"
        fill="none"
        stroke={p.line}
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      <Path
        d="M33.7 22.9C32.1 23.1 30.8 24.1 30 25.5"
        fill="none"
        stroke="#FFFFFF"
        strokeWidth="1.1"
        strokeLinecap="round"
      />
      <Path
        d="M35.4 18.8C36.2 18.4 37 18.5 37.7 19.2"
        fill="none"
        stroke="url(#secondary-apple)"
        strokeWidth="1.2"
        strokeLinecap="round"
      />
      <Ellipse cx="32.2" cy="31.8" rx="3.8" ry="6" fill="#FFFFFF" opacity="0.13" />
    </>
  );
}

function IconByName({ name }: { name: ClassicCategoryIllustrationName }) {
  switch (name) {
    case "auto":
      return <AutoIcon />;
    case "fashion":
      return <FashionIcon />;
    case "electronics":
      return <ElectronicsIcon />;
    case "beauty":
      return <BeautyIcon />;
    case "outdoor":
      return <OutdoorIcon />;
    case "home":
      return <HomeIcon />;
    case "jewelry":
      return <JewelryIcon />;
    case "apple":
      return <AppleIcon />;
    default:
      return null;
  }
}

export default function ClassicCategoryIllustration({ name, size = 58 }: Props) {
  return (
    <View style={{ width: size, height: size }}>
      <Tile name={name}>
        <G>
          <IconByName name={name} />
        </G>
      </Tile>
    </View>
  );
}
