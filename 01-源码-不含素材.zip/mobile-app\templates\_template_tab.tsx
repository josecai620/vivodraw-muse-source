/**
 * 模板：Tab 页面（无返回按钮，在底部 Tab 中显示）
 * 使用方法：复制到 app/(tabs)/xxx.tsx，改函数名和标题
 * 注意：Tab 页放在 (tabs) 目录下，还需要在 (tabs)/_layout.tsx 中注册
 */
import React from "react";
import {
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { useRouter } from "expo-router";
import { Search } from "lucide-react-native";
import { Colors, s } from "@/constants/theme";
import { PageHeader, SectionHeader } from "@/components/shared";

export default function TemplateTabScreen() {
  const router = useRouter();

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader
        title="Tab Title"
        showBack={false}
        rightElement={
          <Pressable className="p-2" onPress={() => router.push("/search")}>
            <Search size={s(20)} color={Colors.neutral[700]} />
          </Pressable>
        }
      />

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 40 }}
      >
        {/* Section 1 */}
        <View className="px-4 py-5 bg-white">
          <SectionHeader
            title="Section Title"
            onAction={() => {}}
          />
          <Text className="text-sm" style={{ color: Colors.neutral[500] }}>
            Content goes here...
          </Text>
        </View>

        {/* Section 2 */}
        <View className="px-4 py-5">
          <SectionHeader title="Another Section" />
          <View className="bg-white rounded-2xl p-4">
            <Text className="text-sm" style={{ color: Colors.neutral[600] }}>
              More content...
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
