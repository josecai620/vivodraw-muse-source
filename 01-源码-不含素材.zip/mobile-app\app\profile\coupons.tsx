import React, { useMemo, useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";
import { useQuery } from "@tanstack/react-query";
import { LinearGradient } from "expo-linear-gradient";
import { useTranslation } from "react-i18next";
import { TealGradient } from "@/constants/theme";
import { USE_DEV_MOCK_DATA } from "@/constants/env";
import { getMyCoupons, type Coupon } from "@/lib/api/coupon";
import { unwrapApiList } from "@/lib/api/response";
import { Tag, Clock } from "lucide-react-native";
import PageHeader from "@/components/shared/PageHeader";
import { useAuthStore } from "@/store/auth";
import { useRouter } from "expo-router";

type CouponTab = "available" | "used";

type DisplayCoupon = {
  id: number;
  title: string;
  minSpend: string;
  code: string;
  expires: string;
  used: boolean;
};

function formatCouponDate(value: string) {
  const numeric = Number(value);
  if (Number.isFinite(numeric) && numeric > 0) {
    const ms = numeric < 1e12 ? numeric * 1000 : numeric;
    const date = new Date(ms);
    if (!Number.isNaN(date.getTime())) {
      return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    }
  }
  return value || "";
}

export default function CouponsScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const { isLoggedIn, isHydrated } = useAuthStore();
  const [activeTab, setActiveTab] = useState<CouponTab>("available");
  const types = activeTab === "available" ? 1 : 2;

  const { data } = useQuery({
    queryKey: ["myCoupons", types],
    queryFn: () => getMyCoupons(types),
    enabled: isHydrated && isLoggedIn,
  });

  const apiCoupons: DisplayCoupon[] = unwrapApiList<Coupon>(data).map((coupon) => ({
    id: coupon.id,
    title: coupon.coupon_title || t("profileCoupons.offAmount", { amount: `$${coupon.coupon_price}` }),
    minSpend: Number(coupon.use_min_price) > 0
      ? t("profileCoupons.minSpend", { amount: `$${coupon.use_min_price}` })
      : t("profileCoupons.anyOrder"),
    code: String(coupon.id),
    expires: formatCouponDate(coupon.end_time),
    used: Number(coupon.is_use) === 1 || activeTab === "used",
  }));

  const mockCoupons: DisplayCoupon[] = useMemo(
    () => [
      { id: 1, title: t("profileCoupons.mockOff20"), minSpend: t("profileCoupons.mockOff20Min"), code: "SAVE20", expires: "2026-03-15", used: false },
      { id: 2, title: t("profileCoupons.mockOff15"), minSpend: t("profileCoupons.mockOff15Min"), code: "ELEC15", expires: "2026-03-20", used: false },
      { id: 3, title: t("profileCoupons.mockFreeShip"), minSpend: t("profileCoupons.mockFreeShipMin"), code: "FREESHIP", expires: "2026-03-31", used: false },
      { id: 4, title: t("profileCoupons.mockOff10"), minSpend: t("profileCoupons.mockOff10Min"), code: "SPRING10", expires: "2026-02-28", used: true },
    ],
    [t],
  );

  const filteredMock = mockCoupons.filter((c) => (activeTab === "available" ? !c.used : c.used));
  const coupons = apiCoupons.length > 0 ? apiCoupons : USE_DEV_MOCK_DATA ? filteredMock : [];

  return (
    <View className="flex-1 bg-gray-50">
      <View className="bg-white border-b border-gray-200">
        <PageHeader title={t("profileCoupons.title")} transparent onBackPress={() => router.replace("/profile")} />
        <View className="flex-row px-4 pb-3 gap-2">
          {(["available", "used"] as const).map((tab) => (
            <Pressable
              key={tab}
              onPress={() => setActiveTab(tab)}
              className={`flex-1 h-9 rounded-xl items-center justify-center ${activeTab === tab ? "bg-[#04A8AE]" : "bg-gray-100"}`}
            >
              <Text className={`text-sm font-medium ${activeTab === tab ? "text-white" : "text-gray-600"}`}>
                {tab === "available" ? t("profileCoupons.available") : t("profileCoupons.used")}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <ScrollView className="flex-1 px-4 pt-4" showsVerticalScrollIndicator={false}>
        {coupons.length === 0 ? (
          <View className="items-center justify-center py-20">
            <Text className="text-gray-500 text-sm">{t("profileCoupons.empty")}</Text>
          </View>
        ) : (
          coupons.map((coupon) => (
            <View
              key={coupon.id}
              className={`bg-white rounded-2xl border border-gray-100 mb-3 overflow-hidden ${coupon.used ? "opacity-50" : ""}`}
            >
              <View className="flex-row">
                <View className="w-24 items-center justify-center p-3">
                  <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 0 }} />
                  <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 0 }} />
                  <Text className="text-white text-lg font-bold text-center">{coupon.title}</Text>
                </View>
                <View className="flex-1 p-3">
                  <Text className="text-sm font-semibold text-gray-900 mb-1">{coupon.minSpend}</Text>
                  <View className="flex-row items-center gap-1 mb-2">
                    <Clock size={12} color="#AAAAA8" />
                    <Text className="text-xs text-gray-500">{t("profileCoupons.expires", { date: coupon.expires })}</Text>
                  </View>
                  <View className="flex-row items-center justify-between">
                    <View className="flex-row items-center gap-1 px-2 py-1 bg-gray-50 rounded">
                      <Tag size={12} color="#04A8AE" />
                      <Text className="text-xs font-mono font-semibold text-gray-700">{coupon.code}</Text>
                    </View>
                    {!coupon.used && (
                      <Pressable className="px-3 h-7 rounded-lg items-center justify-center">
                        <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 8, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
                        <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 8 }} />
                        <Text className="text-white text-xs font-semibold">{t("profileCoupons.useNow")}</Text>
                      </Pressable>
                    )}
                  </View>
                </View>
              </View>
            </View>
          ))
        )}
        <View className="h-8" />
      </ScrollView>
    </View>
  );
}
