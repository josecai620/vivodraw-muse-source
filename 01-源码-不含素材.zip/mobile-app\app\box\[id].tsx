/**
 * 盲盒详情页 — Premium Dark Gaming UI
 */
import React, { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Pressable, ScrollView, Text, View, ActivityIndicator, type ImageSourcePropType } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { Zap, Package, Sparkles } from "lucide-react-native";
import { useRevealColorScheme } from "@/contexts/RevealColorSchemeContext";
import { useAddBox, useBoxDetail, useBoxLog, useCreateBoxOrder, useTrackBoxTaskEvent, useYuanqiConfig } from "@/hooks";
import { usePointsBalance } from "@/hooks/usePoints";
import { useAppStore } from "@/store/app";

import { BoxHeader, RarityBadge, RarityBar, BoxActionButton, BoxEmptyState, BoxChestVFX } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  getRarityTier, bs,
} from "@/lib/boxTheme";

type PayMethod = "points" | "balance";
const OPEN_OPTIONS = [1, 3, 5, 10];

const FALLBACK_CHEST_IMAGES: ImageSourcePropType[] = [
  require("../../assets/box-category-chests/signature-chest.png"),
  require("../../assets/box-category-chests/auto-accessories.png"),
  require("../../assets/box-category-chests/fashion-shoes.png"),
  require("../../assets/box-category-chests/electronics.png"),
  require("../../assets/box-category-chests/beauty-skincare.png"),
  require("../../assets/box-category-chests/outdoor-sports.png"),
  require("../../assets/box-category-chests/home-living.png"),
  require("../../assets/box-category-chests/jewelry.png"),
  require("../../assets/box-category-chests/apple-products.png"),
];

const FALLBACK_CHEST_BY_CATEGORY_ID: Record<number, ImageSourcePropType> = {
  326: require("../../assets/box-category-chests/signature-chest.png"),
  310: require("../../assets/box-category-chests/home-living.png"),
  311: require("../../assets/box-category-chests/electronics.png"),
  312: require("../../assets/box-category-chests/apple-products.png"),
  95: require("../../assets/box-category-chests/auto-accessories.png"),
  94: require("../../assets/box-category-chests/fashion-shoes.png"),
  92: require("../../assets/box-category-chests/electronics.png"),
  91: require("../../assets/box-category-chests/beauty-skincare.png"),
  90: require("../../assets/box-category-chests/outdoor-sports.png"),
  89: require("../../assets/box-category-chests/home-living.png"),
  88: require("../../assets/box-category-chests/jewelry.png"),
  87: require("../../assets/box-category-chests/apple-products.png"),
};

function isRemoteImage(value?: string) {
  return !!value && /^https?:\/\//i.test(value);
}

function normalizeRarity(raw: unknown): string {
  const map: Record<string, string> = {
    "1": "common", "2": "uncommon", "3": "rare",
    "4": "epic", "5": "legendary", "6": "secret",
    common: "common", uncommon: "uncommon", rare: "rare",
    epic: "epic", legendary: "legendary", secret: "secret",
  };
  return map[String(raw ?? "common")] || "common";
}

function getFallbackChestImage(boxId: number) {
  if (FALLBACK_CHEST_BY_CATEGORY_ID[boxId]) return FALLBACK_CHEST_BY_CATEGORY_ID[boxId];
  const index = Math.abs(boxId || 0) % FALLBACK_CHEST_IMAGES.length;
  return FALLBACK_CHEST_IMAGES[index];
}

export default function BoxDetailScreen() {
  const { t } = useTranslation();
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { colors } = useRevealColorScheme();
  const [openCount, setOpenCount] = useState(1);
  const [payMethod, setPayMethod] = useState<PayMethod>("points");
  const showToast = useAppStore((s) => s.showToast);
  const boxId = Number(id) || 0;
  const { mutateAsync: openBox, isPending: opening } = useAddBox();
  const { mutateAsync: createOrder } = useCreateBoxOrder();

  const { data: balanceData } = usePointsBalance();
  const userPoints = (balanceData as any)?.data?.integral ?? (balanceData as any)?.integral ?? 0;
  const userBalance = Number((balanceData as any)?.data?.now_money ?? (balanceData as any)?.now_money ?? 0);

  const { data: boxDetail, isLoading: isLoadingBox } = useBoxDetail(boxId);
  const { data: recentOpenings, isLoading: isLoadingRecent } = useBoxLog({ cid: boxId, page: 1, limit: 10 });
  const { data: yuanqiConfig } = useYuanqiConfig();
  const trackTask = useTrackBoxTaskEvent();

  useEffect(() => {
    if (boxId > 0) {
      trackTask.mutate({ event: "browse", ref: String(boxId), cate_id: boxId });
    }
    // 同一详情只记一次浏览
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [boxId]);

  const box = {
    id: boxDetail?.id || boxId,
    name: boxDetail?.name || t("detail.unnamed"),
    description: boxDetail?.description || t("detail.defaultDesc"),
    image: boxDetail?.image || "",
    price: boxDetail?.price || 0,
    maxValue: boxDetail?.maxValue || 0,
    opened: boxDetail?.opened || 0,
    rarityDistribution: boxDetail?.rarityDistribution || {},
  };
  const fallbackChestImage = getFallbackChestImage(box.id);
  const preferFallbackChestImage = Boolean(FALLBACK_CHEST_BY_CATEGORY_ID[box.id]);

  const items = boxDetail?.items || [];
  const recent = (recentOpenings || []).map((o: any, i: number) => ({
    id: Number(o.id || i),
    username: String(o.userNickname || o.nickname || `User${i + 1}`),
    itemName: String(o.itemName || t("opening.fallbackItem")),
    rarity: normalizeRarity(o.rarity),
    time: String(o.openTime || o.time || t("history.fallbackTime")),
  }));

  const totalCost = box.price * openCount;
  const canAfford = payMethod === "points" ? userPoints >= totalCost : userBalance >= totalCost;

  const handleOpenBox = async () => {
    if (opening) return;
    if (!canAfford) {
      showToast(t("detail.insufficientBalance"), "error");
      return;
    }
    try {
      const orderRes = await createOrder({ id: boxId, num: openCount });
      const orderId = (orderRes as any)?.data?.order_id;
      const res = await openBox({ id: orderId || boxId, num: openCount });
      const rawData = (res as any)?.data ?? res;
      const rawItem = Array.isArray(rawData)
        ? rawData[0]
        : Array.isArray(rawData?.list) ? rawData.list[0] : rawData;
      const openingResult = {
        id: Number(rawItem?.id || rawItem?.item_id || 0),
        name: String(rawItem?.name || rawItem?.item_name || t("opening.fallbackItem")),
        image: String(rawItem?.image || rawItem?.item_image || ""),
        rarity: normalizeRarity(rawItem?.rarity || rawItem?.level),
        openedCount: openCount,
      };
      router.push({
        pathname: "/box/[id]/opening",
        params: { id: String(boxId), num: String(openCount), result: encodeURIComponent(JSON.stringify(openingResult)) },
      });
    } catch (err: any) {
      showToast(err?.message || t("detail.openFailed"), "error");
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("detail.title")} />

      {isLoadingBox ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <ActivityIndicator size="large" color={BoxAccent.gold} />
          <Text style={[BoxTypography.caption, { color: BoxText.secondary, marginTop: BoxSpacing.md }]}>
            {t("common.loading")}
          </Text>
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(120), gap: BoxSpacing.xl }}>
            {/* Box Info Hero */}
            <LinearGradient
              colors={[BoxSurfaces.elevated, BoxSurfaces.deep]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                borderRadius: BoxRadius["2xl"], padding: BoxSpacing.xl,
                alignItems: "center",
                borderWidth: 1, borderColor: BoxBorders.default,
                ...BoxShadows.elevated,
              }}
            >
              <View style={{
                width: bs(224), height: bs(208), borderRadius: BoxRadius.xl,
                alignItems: "center", justifyContent: "center",
                marginBottom: BoxSpacing.lg,
                ...BoxShadows.glow(BoxAccent.gold),
              }}>
                <LinearGradient
                  colors={["rgba(4,168,174,0.10)", "rgba(4,168,174,0.03)"]}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                  style={{ width: bs(216), height: bs(196), borderRadius: BoxRadius.lg, alignItems: "center", justifyContent: "center", overflow: "visible" }}
                >
                  <BoxChestVFX
                    image={
                      !preferFallbackChestImage && isRemoteImage(box.image)
                        ? { uri: box.image }
                        : fallbackChestImage
                    }
                    tier="legendary"
                    size={216}
                  />
                </LinearGradient>
              </View>
              <Text style={[BoxTypography.h1, { color: BoxText.primary, textAlign: "center" }]}>{box.name}</Text>
              <Text style={[BoxTypography.body, { color: BoxText.secondary, textAlign: "center", marginTop: BoxSpacing.xs }]}>{box.description}</Text>

              <RarityBar
                items={Object.entries(box.rarityDistribution).map(([tier, pct]) => ({ tier, probability: Number(pct) || 0 }))}
                height={7}
                style={{ width: "100%", marginTop: BoxSpacing.xl }}
              />

              <View style={{ flexDirection: "row", justifyContent: "space-between", width: "100%", marginTop: BoxSpacing.md }}>
                <Text style={[BoxTypography.caption, { color: BoxText.secondary }]}>
                  {t("detail.openedTimes", { count: box.opened })}
                </Text>
                <Text style={[BoxTypography.caption, { color: BoxAccent.gold }]}>
                  {t("detail.maxValue", { value: box.maxValue.toLocaleString() })}
                </Text>
              </View>
            </LinearGradient>

            {/* Open Options */}
            <View style={{
              backgroundColor: BoxSurfaces.card, borderRadius: BoxRadius["2xl"],
              padding: BoxSpacing.xl, borderWidth: 1, borderColor: BoxBorders.default,
            }}>
              <Text style={[BoxTypography.h3, { color: BoxText.primary, marginBottom: BoxSpacing.lg }]}>
                {t("detail.openOptions")}
              </Text>

              {/* Count selector */}
              {/* Quick Pity Progress */}
              <View style={{
                borderRadius: BoxRadius.lg, padding: BoxSpacing.md,
                marginBottom: BoxSpacing.lg, backgroundColor: BoxSurfaces.deep,
                borderWidth: 1, borderColor: BoxBorders.default,
              }}>
                <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 4 }}>
                  <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
                    {t("detail.pityProgress")}
                  </Text>
                  <Text style={[BoxTypography.micro, { color: BoxAccent.gold }]}>
                    Rare in 10 opens
                  </Text>
                </View>
                <View style={{ height: bs(6), borderRadius: bs(3), backgroundColor: BoxSurfaces.void, overflow: "hidden" }}>
                  <View style={{
                    height: "100%", width: "30%", borderRadius: bs(3),
                    backgroundColor: BoxAccent.gold,
                  }} />
                </View>
              </View>

              <View style={{ flexDirection: "row", gap: BoxSpacing.sm, marginBottom: BoxSpacing.xl }}>
                {OPEN_OPTIONS.map((count) => {
                  const active = openCount === count;
                  return active ? (
                    <LinearGradient
                      key={count}
                      colors={[BoxAccent.gold, "#04A8AE"]}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 0 }}
                      style={{
                        flex: 1, height: bs(44), borderRadius: BoxRadius.full,
                        alignItems: "center", justifyContent: "center",
                        ...BoxShadows.glow(BoxAccent.gold),
                      }}
                    >
                      <Text style={[BoxTypography.bodyBold, { color: BoxText.onGold }]}>{count}x</Text>
                    </LinearGradient>
                  ) : (
                    <Pressable
                      key={count}
                      onPress={() => setOpenCount(count)}
                      style={{
                        flex: 1, height: bs(44), borderRadius: BoxRadius.full,
                        alignItems: "center", justifyContent: "center",
                        backgroundColor: BoxSurfaces.deep,
                        borderWidth: 1, borderColor: BoxBorders.default,
                      }}
                    >
                      <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>{count}x</Text>
                    </Pressable>
                  );
                })}
              </View>

              {/* Total cost */}
              <View style={{
                backgroundColor: BoxSurfaces.deep, borderRadius: BoxRadius.xl,
                padding: BoxSpacing.lg, flexDirection: "row",
                alignItems: "center", justifyContent: "space-between",
                marginBottom: BoxSpacing.lg,
              }}>
                <Text style={[BoxTypography.body, { color: BoxText.secondary }]}>{t("detail.totalCost")}</Text>
                <Text style={[BoxTypography.h1, { color: BoxAccent.gold }]}>
                  {payMethod === "points"
                    ? `${totalCost.toLocaleString()} ${t("common.pts")}`
                    : `¥${totalCost.toFixed(2)}`}
                  {openCount > 1 && (
                    <Text style={[BoxTypography.micro, { color: "#04A8AE" }]}>
                      {" "}{payMethod === "points"
                        ? `${Math.round(totalCost / openCount).toLocaleString()} ${t("common.pts")}/${t("detail.each")}`
                        : `¥${(totalCost / openCount).toFixed(2)}/${t("detail.each")}`}
                    </Text>
                  )}
                </Text>
              </View>

              {/* Payment method */}
              <View style={{ flexDirection: "row", gap: BoxSpacing.md }}>
                {([
                  { key: "points" as PayMethod, label: t("detail.points"), value: `${userPoints.toLocaleString()} ${t("common.pts")}` },
                  { key: "balance" as PayMethod, label: t("detail.balance"), value: `¥${userBalance.toFixed(2)}` },
                ] as const).map((m) => {
                  const active = payMethod === m.key;
                  return (
                    <Pressable
                      key={m.key}
                      onPress={() => setPayMethod(m.key)}
                      style={{
                        flex: 1, padding: BoxSpacing.md, borderRadius: BoxRadius.xl,
                        alignItems: "center",
                        backgroundColor: active ? BoxAccent.goldDim : BoxSurfaces.deep,
                        borderWidth: 1,
                        borderColor: active ? BoxAccent.goldBorder : BoxBorders.default,
                      }}
                    >
                      <Text style={[BoxTypography.caption, { color: BoxText.secondary }]}>{m.label}</Text>
                      <Text style={[BoxTypography.bodyBold, { color: active ? BoxAccent.gold : BoxText.primary, marginTop: 4 }]}>{m.value}</Text>
                    </Pressable>
                  );
                })}
              </View>

              {/* Yuanqi Discount */}
              {yuanqiConfig?.discount && Number(yuanqiConfig.discount) < 100 && (
                <View style={{
                  flexDirection: "row", alignItems: "center", justifyContent: "space-between",
                  padding: BoxSpacing.md, borderRadius: BoxRadius.xl, marginTop: BoxSpacing.lg,
                  backgroundColor: BoxAccent.goldDim,
                }}>
                  <Text style={[BoxTypography.body, { color: BoxAccent.gold }]}>{t("detail.yuanqiDiscount")}</Text>
                  <Text style={[BoxTypography.bodyBold, { color: BoxAccent.gold }]}>{yuanqiConfig.discount}%</Text>
                </View>
              )}
            </View>

            {/* Possible Items */}
            <View>
              <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm, marginBottom: BoxSpacing.md }}>
                <Package size={bs(20)} color={BoxAccent.gold} />
                <Text style={[BoxTypography.h2, { color: BoxText.primary }]}>{t("detail.possibleDrops")}</Text>
              </View>
              <View style={{
                backgroundColor: BoxSurfaces.card, borderRadius: BoxRadius["2xl"],
                borderWidth: 1, borderColor: BoxBorders.default, overflow: "hidden",
              }}>
                {items.length === 0 ? (
                  <BoxEmptyState
                    icon={<Package size={bs(36)} color={BoxText.tertiary} />}
                    title={t("detail.noItems")}
                  />
                ) : (
                  items.map((item: any, i: number) => {
                    const rarity = getRarityTier(item.rarity);
                    return (
                      <View key={item.id || i} style={{
                        flexDirection: "row", alignItems: "center", padding: BoxSpacing.lg,
                        borderBottomWidth: i < items.length - 1 ? 1 : 0,
                        borderBottomColor: BoxBorders.subtle,
                      }}>
                        <View style={{
                          width: bs(48), height: bs(48), borderRadius: BoxRadius.lg,
                          backgroundColor: rarity.bgSubtle, alignItems: "center", justifyContent: "center",
                          borderWidth: 1, borderColor: rarity.borderColor,
                        }}>
                          {isRemoteImage(item.image) ? (
                            <Image source={{ uri: item.image }} style={{ width: bs(40), height: bs(40), borderRadius: BoxRadius.md }} contentFit="cover" />
                          ) : (
                            <Package size={bs(22)} color={rarity.color} />
                          )}
                        </View>
                        <View style={{ flex: 1, marginLeft: BoxSpacing.md }}>
                          <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]} numberOfLines={1}>{item.name}</Text>
                          <RarityBadge tier={item.rarity} size="sm" style={{ marginTop: 4 }} />
                        </View>
                        <Text style={[BoxTypography.bodyBold, { color: BoxText.secondary }]}>{item.probability}%</Text>
                      </View>
                    );
                  })
                )}
              </View>
            </View>

            {/* Recent Openings */}
            <View>
              <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm, marginBottom: BoxSpacing.md }}>
                <Sparkles size={bs(20)} color={BoxAccent.gold} />
                <Text style={[BoxTypography.h2, { color: BoxText.primary }]}>{t("detail.recentOpenings")}</Text>
              </View>
              <View style={{
                backgroundColor: BoxSurfaces.card, borderRadius: BoxRadius["2xl"],
                borderWidth: 1, borderColor: BoxBorders.default, overflow: "hidden",
              }}>
                {isLoadingRecent ? (
                  <View style={{ padding: BoxSpacing["2xl"], alignItems: "center" }}>
                    <ActivityIndicator size="small" color={BoxAccent.gold} />
                  </View>
                ) : recent.length === 0 ? (
                  <BoxEmptyState
                    icon={<Sparkles size={bs(36)} color={BoxText.tertiary} />}
                    title={t("detail.noOpenings")}
                  />
                ) : (
                  recent.map((r: any, i: number) => {
                    const avatarColors = ["#171A1A", "#5E5F5E", "#787976", "#919290", "#AAAAA8", "#C0C0BE"];
                    const avatarBg = avatarColors[i % avatarColors.length];
                    return (
                      <View key={r.id} style={{
                        flexDirection: "row", alignItems: "center", padding: BoxSpacing.lg,
                        borderBottomWidth: i < recent.length - 1 ? 1 : 0,
                        borderBottomColor: BoxBorders.subtle,
                      }}>
                        <View style={{
                          width: bs(36), height: bs(36), borderRadius: bs(18),
                          backgroundColor: avatarBg,
                          alignItems: "center", justifyContent: "center",
                        }}>
                          <Text style={{ fontSize: bs(14), fontWeight: "700", color: "#fff" }}>
                            {r.username?.[0]?.toUpperCase() || "U"}
                          </Text>
                        </View>
                        <View style={{ flex: 1, marginLeft: BoxSpacing.md }}>
                          <Text style={[BoxTypography.body, { color: BoxText.secondary }]}>
                            <Text style={{ color: BoxText.primary, fontWeight: "700" }}>{r.username}</Text> {t("hall.drew")}
                          </Text>
                          <RarityBadge tier={r.rarity} size="sm" style={{ marginTop: 4 }} />
                        </View>
                        <Text style={[BoxTypography.micro, { color: BoxText.tertiary }]}>{r.time}</Text>
                      </View>
                    );
                  })
                )}
              </View>
            </View>
          </View>
        </ScrollView>
      )}

      {/* Sticky Bottom Bar */}
      {!isLoadingBox && (
        <View style={{
          position: "absolute", bottom: 0, left: 0, right: 0,
          backgroundColor: BoxSurfaces.card, borderTopWidth: 1, borderTopColor: BoxBorders.default,
          paddingHorizontal: BoxSpacing.lg, paddingTop: BoxSpacing.md, paddingBottom: bs(28),
          flexDirection: "row", alignItems: "center", gap: BoxSpacing.md,
          ...BoxShadows.elevated,
        }}>
          <View style={{ flex: 0.4 }}>
            <Text style={[BoxTypography.caption, { color: BoxText.secondary }]}>
              {openCount}x {t("detail.openLabel")}
            </Text>
            <Text style={[BoxTypography.h2, { color: BoxAccent.gold }]}>
              {payMethod === "points" ? `${totalCost.toLocaleString()} ${t("common.pts")}` : `¥${totalCost.toFixed(2)}`}
            </Text>
          </View>
          <BoxActionButton
            title={opening ? t("detail.opening") : t("detail.openNow")}
            icon={<Zap size={bs(18)} color={canAfford && !opening ? BoxText.onGold : BoxText.disabled} />}
            loading={opening}
            disabled={opening}
            onPress={handleOpenBox}
            style={{ flex: 0.6 }}
          />
        </View>
      )}
    </View>
  );
}
