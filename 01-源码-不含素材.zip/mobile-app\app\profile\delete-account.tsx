import PageHeader from "@/components/shared/PageHeader";
import { Colors } from "@/constants/theme";
import { cancelAccount } from "@/lib/api/user";
import { useAuthStore } from "@/store/auth";
import { useAppStore } from "@/store/app";
import { useRouter } from "expo-router";
import { AlertTriangle, ChevronRight, Headset, Info, LogIn } from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";

const CONFIRM_WORD = "DELETE";

export default function DeleteAccountScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const showToast = useAppStore((s) => s.showToast);
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const storeLogout = useAuthStore((s) => s.logout);

  const [confirmText, setConfirmText] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const notes = useMemo(
    () => [
      t("deleteAccount.note1"),
      t("deleteAccount.note2"),
      t("deleteAccount.note3"),
    ],
    [t],
  );

  const canSubmit = isLoggedIn && confirmText.trim() === CONFIRM_WORD && !submitting;

  const confirmAndSubmit = () => {
    if (!canSubmit) return;
    Alert.alert(t("deleteAccount.finalAlertTitle"), t("deleteAccount.finalAlertBody"), [
      { text: t("deleteAccount.keepAccount"), style: "cancel" },
      {
        text: t("deleteAccount.confirmDelete"),
        style: "destructive",
        onPress: async () => {
          setSubmitting(true);
          try {
            await cancelAccount(CONFIRM_WORD);
            showToast(t("deleteAccount.deleted"), "success");
            storeLogout();
            router.replace("/auth");
          } catch (err) {
            showToast(err instanceof Error ? err.message : t("deleteAccount.failed"), "error");
          } finally {
            setSubmitting(false);
          }
        },
      },
    ]);
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-neutral-50"
    >
      <PageHeader title={t("deleteAccount.title")} />

      <ScrollView
        className="flex-1 px-4 pt-6"
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* 说明主卡 */}
        <View className="bg-white rounded-2xl p-5 mb-4">
          <View
            className="w-11 h-11 rounded-2xl items-center justify-center mb-4"
            style={{ backgroundColor: "rgba(4,168,174,0.12)" }}
          >
            <Info size={22} color={Colors.brand.red} />
          </View>
          <Text className="text-xl font-bold text-neutral-900 mb-2">
            {isLoggedIn ? t("deleteAccount.heroSignedIn") : t("deleteAccount.heroSignInRequired")}
          </Text>
          <Text className="text-sm text-neutral-500 leading-5 mb-5">
            {t("deleteAccount.heroBody")}
          </Text>

          {!isLoggedIn ? (
            <Pressable
              className="h-12 rounded-xl flex-row items-center justify-center mb-3"
              style={{ backgroundColor: Colors.brand.red }}
              onPress={() => router.push("/auth")}
            >
              <LogIn size={18} color="#fff" />
              <Text className="text-white font-bold text-base ml-2">{t("deleteAccount.signIn")}</Text>
            </Pressable>
          ) : null}

          <Pressable
            className="h-12 rounded-xl flex-row items-center justify-center bg-white border border-neutral-200 active:bg-neutral-50"
            onPress={() => router.push("/profile/service")}
          >
            <Headset size={18} color={Colors.neutral[500]} />
            <Text className="font-semibold text-base ml-2 text-neutral-700">
              {t("deleteAccount.contactSupport")}
            </Text>
          </Pressable>
        </View>

        {/* 注销前须知 */}
        <View className="bg-white rounded-2xl p-5 mb-4">
          <Text className="text-base font-bold text-neutral-900 mb-3">
            {t("deleteAccount.beforeTitle")}
          </Text>
          <View className="gap-3">
            {notes.map((note) => (
              <View key={note} className="flex-row items-start">
                <View className="mt-0.5 mr-3">
                  <ChevronRight size={16} color={Colors.brand.red} />
                </View>
                <Text className="flex-1 text-sm text-neutral-500 leading-5">{note}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* 确认操作 */}
        <View className="bg-white rounded-2xl p-5 mb-4">
          <Text className="text-base font-bold text-neutral-900 mb-2">
            {t("deleteAccount.confirmTitle")}
          </Text>
          <Text className="text-sm text-neutral-500 leading-5 mb-4">
            {t("deleteAccount.confirmHint")}
          </Text>
          <TextInput
            accessibilityLabel="Type DELETE to confirm"
            value={confirmText}
            onChangeText={setConfirmText}
            autoCapitalize="characters"
            autoCorrect={false}
            placeholder="DELETE"
            placeholderTextColor={Colors.neutral[400]}
            className="w-full h-12 bg-neutral-50 border border-neutral-200 rounded-xl px-4 text-base font-bold tracking-widest text-neutral-900 mb-4"
          />
          <Pressable
            disabled={!canSubmit}
            onPress={confirmAndSubmit}
            className="h-12 rounded-xl flex-row items-center justify-center"
            style={{ backgroundColor: canSubmit ? Colors.error : Colors.neutral[300] }}
          >
            {submitting ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <>
                <AlertTriangle size={18} color="#fff" />
                <Text className="text-white font-bold text-base ml-2">
                  {t("deleteAccount.deleteBtn")}
                </Text>
              </>
            )}
          </Pressable>
        </View>

        <Pressable
          className="items-center py-3 mb-8"
          onPress={() => router.push("/agreement/privacy_agreement")}
        >
          <Text className="text-sm font-semibold" style={{ color: Colors.brand.red }}>
            {t("deleteAccount.readPrivacy")}
          </Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
