import React, { useState } from "react";
import { Alert, Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { ArrowRightLeft, Coins, Phone, Send, Wallet } from "lucide-react-native";
import { TealGradient, Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { usePointsTransfer, usePointsBalance } from "@/hooks";
import { useAuthStore } from "@/store/auth";

const TRANSFER_TYPES = [
  { type: 0, label: "Transfer Balance", desc: "Transfer balance to another user", icon: Send },
  { type: 1, label: "Balance → Points", desc: "Convert your balance to points", icon: Coins },
  { type: 2, label: "Transfer Points", desc: "Transfer points to another user", icon: ArrowRightLeft },
] as const;

export default function PointsTransferScreen() {
  const [selectedType, setSelectedType] = useState(0);
  const [mobile, setMobile] = useState("");
  const [amount, setAmount] = useState("");
  const transfer = usePointsTransfer();
  const { data: balanceData } = usePointsBalance();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);

  const profile = (balanceData as any)?.data ?? (balanceData as any) ?? {};
  const currentBalance = Number(profile?.now_money ?? 0);
  const currentPoints = Number(profile?.integral ?? 0);

  const needsMobile = selectedType !== 1;

  const handleTransfer = () => {
    if (!isLoggedIn) { Alert.alert("Error", "Please login first"); return; }
    const num = Number(amount);
    if (!num || num <= 0) { Alert.alert("Error", "Please enter a valid amount"); return; }
    if (needsMobile && !mobile.trim()) { Alert.alert("Error", "Please enter recipient phone number"); return; }
    if (selectedType === 0 && num > currentBalance) { Alert.alert("Error", "Insufficient balance"); return; }
    if (selectedType === 1 && num > currentBalance) { Alert.alert("Error", "Insufficient balance"); return; }
    if (selectedType === 2 && num > currentPoints) { Alert.alert("Error", "Insufficient points"); return; }

    Alert.alert("Confirm", `Transfer ${num} to ${needsMobile ? mobile : "points"}?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Confirm",
        onPress: () => {
          transfer.mutate({ type: selectedType, mobile: mobile.trim(), num });
          setAmount("");
          setMobile("");
        },
      },
    ]);
  };

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Points Transfer" />
      <ScrollView className="flex-1 px-4 pt-4" showsVerticalScrollIndicator={false}>
        {/* Balance Card */}
        <LinearGradient
          colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
          className="p-5 mb-4"
          style={{ borderRadius: 20, overflow: "hidden" }}
        >
            <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
          <View className="flex-row justify-between">
            <View>
              <View className="flex-row items-center gap-1.5 mb-1">
                <Wallet size={14} color="#171A1A" />
                <Text className="text-white/70 text-xs">Balance</Text>
              </View>
              <Text className="text-white text-2xl font-bold">${currentBalance.toFixed(2)}</Text>
            </View>
            <View className="items-end">
              <View className="flex-row items-center gap-1.5 mb-1">
                <Coins size={14} color="#171A1A" />
                <Text className="text-white/70 text-xs">Points</Text>
              </View>
              <Text className="text-white text-2xl font-bold">{currentPoints.toLocaleString()}</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Transfer Type */}
        <Text className="text-sm font-bold text-gray-900 mb-2">Transfer Type</Text>
        <View className="gap-2 mb-4">
          {TRANSFER_TYPES.map((t) => {
            const Icon = t.icon;
            const active = selectedType === t.type;
            return (
              <Pressable
                key={t.type}
                onPress={() => setSelectedType(t.type)}
                className="bg-white rounded-xl p-4 flex-row items-center gap-3"
                style={{
                  borderWidth: 2,
                  borderColor: active ? Colors.brand.red : "#f3f4f6",
                }}
              >
                <View
                  className="w-10 h-10 rounded-full items-center justify-center"
                  style={{ backgroundColor: active ? `${Colors.brand.red}15` : "#f9fafb" }}
                >
                  <Icon size={20} color={active ? Colors.brand.red : "#919290"} />
                </View>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-gray-900">{t.label}</Text>
                  <Text className="text-xs text-gray-500">{t.desc}</Text>
                </View>
              </Pressable>
            );
          })}
        </View>

        {/* Mobile Input */}
        {needsMobile && (
          <View className="mb-4">
            <Text className="text-sm font-bold text-gray-900 mb-2">Recipient Phone</Text>
            <View className="bg-white rounded-xl p-3 flex-row items-center gap-2 border border-gray-200">
              <Phone size={18} color="#919290" />
              <TextInput
                className="flex-1 text-sm text-gray-900"
                placeholder="Enter phone number"
                value={mobile}
                onChangeText={setMobile}
                keyboardType="phone-pad"
              />
            </View>
          </View>
        )}

        {/* Amount Input */}
        <View className="mb-6">
          <Text className="text-sm font-bold text-gray-900 mb-2">Amount</Text>
          <View className="bg-white rounded-xl p-3 flex-row items-center gap-2 border border-gray-200">
            <Coins size={18} color="#919290" />
            <TextInput
              className="flex-1 text-sm text-gray-900"
              placeholder="Enter amount"
              value={amount}
              onChangeText={setAmount}
              keyboardType="numeric"
            />
          </View>
          <Text className="text-xs text-gray-400 mt-1">
            Available: {selectedType === 2 ? `${currentPoints} points` : `$${currentBalance.toFixed(2)}`}
          </Text>
        </View>

        {/* Submit Button */}
        <Pressable onPress={handleTransfer} disabled={transfer.isPending}>
          <LinearGradient
            colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            className="h-12 rounded-xl items-center justify-center"
            style={{ overflow: "hidden" }}
          >
              <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
            <Text className="text-white font-bold text-base">
              {transfer.isPending ? "Processing..." : "Confirm Transfer"}
            </Text>
          </LinearGradient>
        </Pressable>

        {/* Tips */}
        <View className="mt-4 bg-neutral-50 rounded-xl p-4 border border-neutral-200 mb-8">
          <Text className="text-xs font-bold text-neutral-800 mb-1">Tips</Text>
          <Text className="text-xs text-neutral-700 leading-5">
            • Balance transfer requires recipient phone number{"\n"}
            • Points conversion from balance is instant{"\n"}
            • Transfers cannot be reversed once confirmed
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
