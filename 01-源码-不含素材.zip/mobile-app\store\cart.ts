import { create } from "zustand";

export interface CartProduct {
  id: number;
  product_id: number;
  cart_num: number;
  productInfo: {
    id: number;
    image: string;
    store_name: string;
    price: string;
    ot_price: string;
    attrInfo?: {
      suk: string;
      image: string;
      price: string;
    };
  };
}

interface CartState {
  items: CartProduct[];
  count: number;
  selectedIds: Set<number>;

  setItems: (items: CartProduct[]) => void;
  setCount: (count: number) => void;
  toggleSelect: (id: number) => void;
  selectAll: () => void;
  deselectAll: () => void;
  isSelected: (id: number) => boolean;
  selectedTotal: () => number;
}

export const useCartStore = create<CartState>((set, get) => ({
  items: [],
  count: 0,
  selectedIds: new Set(),

  setItems: (items) => set({ items, count: items.length }),
  setCount: (count) => set({ count }),

  toggleSelect: (id) => {
    const next = new Set(get().selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    set({ selectedIds: next });
  },

  selectAll: () => {
    set({ selectedIds: new Set(get().items.map((i) => i.id)) });
  },

  deselectAll: () => {
    set({ selectedIds: new Set() });
  },

  isSelected: (id) => get().selectedIds.has(id),

  selectedTotal: () => {
    const { items, selectedIds } = get();
    return items
      .filter((i) => selectedIds.has(i.id))
      .reduce((sum, i) => {
        const price = i.productInfo.attrInfo?.price ?? i.productInfo.price;
        return sum + Number(price) * i.cart_num;
      }, 0);
  },
}));
