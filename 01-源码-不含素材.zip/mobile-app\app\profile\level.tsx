import React from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { ChevronRight, Crown, Star } from "lucide-react-native";
import { useQuery } from "@tanstack/react-query";
import { getUserLevelGrade, getUserLevelInfo } from "@/lib/api/userLevel";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

export default function LevelScreen() {
  const router = useRouter();
  const { data: gradeData, isLoading: gradeLoading } = useQuery({
    queryKey: ["userLevelGrade"],
    queryFn: getUserLevelGrade,
  });
  const { data: infoData, isLoading: infoLoading } = useQuery({
    queryKey: ["userLevelInfo"],
    queryFn: getUserLevelInfo,
  });

  const grades = (gradeData as any)?.data ?? gradeData ?? [];
  const info = (infoData as any)?.data ?? infoData ?? {};
  const currentLevel = info?.level ?? info?.grade ?? 0;
  const exp = info?.exp ?? info?.experience ?? 0;
  const nextExp = info?.next_exp ?? info?.nextExp ?? 0;
  const isLoading = gradeLoading || infoLoading;

  const currentGrade = Array.isArray(grades) ? grades.find((g: any) => (g.grade ?? g.id) === currentLevel) ?? grades[0] : null;

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Member Level" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }} showsVerticalScrollIndicator={false}>
          <View className="bg-white rounded-2xl p-6 mb-4 border border-gray-100">
            <View className="flex-row items-center gap-3 mb-4">
              <View className="w-14 h-14 rounded-full items-center justify-center" style={{ backgroundColor: `${Colors.brand.red}20` }}>
                <Crown size={s(28)} color={Colors.brand.red} />
              </View>
              <View className="flex-1">
                <Text className="text-lg font-bold" style={{ color: Colors.neutral[800] }}>
                  {currentGrade?.name ?? currentGrade?.level_name ?? `Level ${currentLevel}`}
                </Text>
                <Text className="text-sm" style={{ color: Colors.neutral[500] }}>
                  Exp: {exp}{nextExp > 0 ? ` / ${nextExp}` : ""}
                </Text>
              </View>
            </View>
            {nextExp > 0 && (
              <View className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <View
                  className="h-full rounded-full"
                  style={{
                    width: `${Math.min(100, (exp / nextExp) * 100)}%`,
                    backgroundColor: Colors.brand.red,
                  }}
                />
              </View>
            )}
          </View>

          {Array.isArray(grades) && grades.length > 0 && (
            <View className="bg-white rounded-2xl overflow-hidden border border-gray-100">
              <View className="px-4 py-3 border-b border-gray-100">
                <Text className="font-semibold" style={{ color: Colors.neutral[800] }}>
                  Level List
                </Text>
              </View>
              {grades.map((g: any, i: number) => {
                const grade = g.grade ?? g.id ?? i;
                const isCurrent = grade === currentLevel;
                return (
                  <View key={grade} className={`flex-row items-center px-4 py-3 ${i > 0 ? "border-t border-gray-50" : ""}`}>
                    <Star size={s(18)} color={isCurrent ? Colors.brand.red : Colors.neutral[300]} fill={isCurrent ? Colors.brand.red : "transparent"} />
                    <View className="flex-1 ml-3">
                      <Text className="font-medium" style={{ color: isCurrent ? Colors.brand.red : Colors.neutral[700] }}>
                        {g.name ?? g.level_name ?? `Level ${grade}`}
                      </Text>
                      <Text className="text-xs" style={{ color: Colors.neutral[500] }}>
                        {g.experience ?? g.exp ?? 0} exp
                      </Text>
                    </View>
                    {isCurrent && (
                      <View className="px-2 py-0.5 rounded-full" style={{ backgroundColor: `${Colors.brand.red}20` }}>
                        <Text className="text-xs font-semibold" style={{ color: Colors.brand.red }}>
                          Current
                        </Text>
                      </View>
                    )}
                  </View>
                );
              })}
            </View>
          )}

          <Pressable
            onPress={() => router.push("/profile/member-card")}
            className="mt-4 bg-white rounded-2xl p-4 flex-row items-center justify-between border border-gray-100"
          >
            <View className="flex-row items-center gap-3">
              <View className="w-10 h-10 rounded-xl items-center justify-center" style={{ backgroundColor: "#04A8AE15" }}>
                <Crown size={s(22)} color="#04A8AE" />
              </View>
              <View>
                <Text className="font-semibold" style={{ color: Colors.neutral[800] }}>
                  Membership
                </Text>
                <Text className="text-sm" style={{ color: Colors.neutral[500] }}>
                  Plans, benefits & trial redemption
                </Text>
              </View>
            </View>
            <ChevronRight size={s(22)} color={Colors.neutral[400]} />
          </Pressable>
        </ScrollView>
      )}
    </View>
  );
}
