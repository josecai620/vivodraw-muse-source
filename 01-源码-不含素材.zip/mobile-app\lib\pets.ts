export type PixelDeskPetId =
  | "cat_programmer"
  | "octopus_wizard"
  | "dino_sipper"
  | "shiba_bone"
  | "penguin_sign"
  | "axolotl_writer"
  | "gray_yarn_cat"
  | "raccoon_reader"
  | "blue_sprout_slime"
  | "honglang"
  | "jj-duck"
  | "bitboy"
  | "wukong"
  | "nibble_mouse";
export type PixelDeskPetAnimationName =
  | "idle"
  | "showcase"
  | "hatTrick"
  | "lookOwner"
  | "standIdleFront"
  | "pawGreetFront"
  | "headTiltFront"
  | "frontBobIdle"
  | "frontHappyWave"
  | "frontJoyBounce"
  | "frontReadIdle"
  | "frontPageFlip"
  | "frontHappyLookup"
  | "wander"
  | "react"
  | "rest"
  | "drag"
  | "blink"
  | "happy"
  | "stage"
  | "grab"
  | "land"
  | "sleep"
  | "message"
  | "talk"
  | "hideLaptop"
  | "disappear";

export type PixelDeskPetAnimation = {
  fps: number;
  frames: number[];
  loop?: boolean;
};

export type PixelDeskPet = {
  id: PixelDeskPetId;
  name: string;
  role: string;
  status: string;
  quote: string;
  primaryLabel: string;
  primaryHref: string;
  secondaryLabel: string;
  secondaryHref: string;
  accent: string;
  source: number;
  animations: Partial<Record<PixelDeskPetAnimationName, PixelDeskPetAnimation>>;
};

export const pixelDeskPetIds: PixelDeskPetId[] = [
  "cat_programmer",
  "octopus_wizard",
  "dino_sipper",
  "shiba_bone",
  "penguin_sign",
  "axolotl_writer",
  "gray_yarn_cat",
  "raccoon_reader",
  "blue_sprout_slime",
  "honglang",
  "jj-duck",
  "bitboy",
  "wukong",
  "nibble_mouse",
];

export const pixelDeskPets: Record<PixelDeskPetId, PixelDeskPet> = {
  cat_programmer: {
    id: "cat_programmer",
    name: "Trumpy",
    role: "Mimic pet challenger",
    status: "Ready to help",
    quote: "Tap me for today's gift, or open the pet deck to play and bond.",
    primaryLabel: "Claim free points",
    primaryHref: "/points/checkin",
    secondaryLabel: "Browse loot shelf",
    secondaryHref: "/browse",
    accent: "#ffbf55",
    source: require("../assets/pets/trumpy_clean.png"),
    animations: {},
  },
  octopus_wizard: {
    id: "octopus_wizard",
    name: "Signal Sprout",
    role: "Compact dashboard helper",
    status: "Signal scan",
    quote: "Signals are clean. I can inspect the next route.",
    primaryLabel: "Check blind box odds",
    primaryHref: "/box",
    secondaryLabel: "Open reward hub",
    secondaryHref: "/activity",
    accent: "#55d7ff",
    source: require("../assets/pets/signal_sprout_clean.png"),
    animations: {},
  },
  dino_sipper: {
    id: "dino_sipper",
    name: "Ranni",
    role: "Moonlit mimic witch",
    status: "Moon signal",
    quote: "A quiet spell is ready. I will inspect the next route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#8cb7ff",
    source: require("../assets/pets/ranni_clean.png"),
    animations: {},
  },
  shiba_bone: {
    id: "shiba_bone",
    name: "EVE",
    role: "Magic companion robot",
    status: "Scan ready",
    quote: "Blue light online. I will inspect the next reward path.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#50d8ff",
    source: require("../assets/pets/eve_clean.png"),
    animations: {},
  },
  penguin_sign: {
    id: "penguin_sign",
    name: "Bee Teemo",
    role: "Tiny honey scout",
    status: "Buzz ready",
    quote: "Honey signal ready. I can inspect the next reward route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#f6c94d",
    source: require("../assets/pets/bee_teemo_clean.png"),
    animations: {},
  },
  axolotl_writer: {
    id: "axolotl_writer",
    name: "manba",
    role: "Boxy iced tea mimic",
    status: "Tea stance",
    quote: "Iced tea signal ready. I can inspect the next reward route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#f5a623",
    source: require("../assets/pets/manba_clean.png"),
    animations: {},
  },
  gray_yarn_cat: {
    id: "gray_yarn_cat",
    name: "Sabo",
    role: "Masked commit stalker",
    status: "Commit watch",
    quote: "Commit signal ready. I can inspect the next reward route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#2f5167",
    source: require("../assets/pets/commit_crab_clean.png"),
    animations: {},
  },
  raccoon_reader: {
    id: "raccoon_reader",
    name: "Triple T",
    role: "Focused bat coder",
    status: "Laptop stance",
    quote: "Laptop signal ready. I can inspect the next reward route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#d98a24",
    source: require("../assets/pets/triple_t_clean.png"),
    animations: {},
  },
  blue_sprout_slime: {
    id: "blue_sprout_slime",
    name: "Homie",
    role: "Patriotic cape scout",
    status: "Cape stance",
    quote: "Cape signal ready. I can inspect the next reward route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#2d83d4",
    source: require("../assets/pets/homie_clean.png"),
    animations: {},
  },
  honglang: {
    id: "honglang",
    name: "honglang",
    role: "Skull mask tactician",
    status: "Rose ready",
    quote: "Gold signal ready. I can inspect the next reward route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#d7a437",
    source: require("../assets/pets/honglang_clean.png"),
    animations: {},
  },
  "jj-duck": {
    id: "jj-duck",
    name: "JJ_duck",
    role: "Starry duck sidekick",
    status: "Fake-cool stance",
    quote: "Duck signal ready. I can inspect the next reward route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#8d5cff",
    source: require("../assets/pets/jj_duck_clean.png"),
    animations: {},
  },
  bitboy: {
    id: "bitboy",
    name: "BitBoy",
    role: "Pocket console buddy",
    status: "Pixel boot",
    quote: "Button signal ready. I can inspect the next reward route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#78c46a",
    source: require("../assets/pets/bitboy_clean.png"),
    animations: {},
  },
  wukong: {
    id: "wukong",
    name: "WuKong",
    role: "Golden-eyed guardian",
    status: "Staff ready",
    quote: "Golden eyes online. I can inspect the next reward route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#c99238",
    source: require("../assets/pets/wukong_clean.png"),
    animations: {},
  },
  nibble_mouse: {
    id: "nibble_mouse",
    name: "Nibble",
    role: "Tiny gray mouse scout",
    status: "Nibble ready",
    quote: "Tiny paws online. I can sniff the next reward route.",
    primaryLabel: "Open pet deck",
    primaryHref: "/pet-deck",
    secondaryLabel: "Earn points",
    secondaryHref: "/activity",
    accent: "#9b8c86",
    source: require("../assets/pets/nibble_clean.png"),
    animations: {},
  },
};

export function getPixelDeskPet(id: PixelDeskPetId) {
  return pixelDeskPets[id];
}
