import TealSurface from "@/components/ui/TealSurface";
import { Colors, Shadows, s } from "@/constants/theme";
import { Coins, Gift, LayoutGrid, ShoppingBag, Ticket, Users } from "lucide-react-native";
import React from "react";
import { type ImageSourcePropType, Pressable, Text, View } from "react-native";
import { pickLang } from "./utils";

interface QuickItem {
  icon?: string;
  img?: string;
  image?: string;
  localImage?: ImageSourcePropType;
  label?: { en?: string; zh?: string } | string;
  link?: string;
}

interface HlQuickGridProps {
  props: {
    columns?: number;
    items?: QuickItem[];
  };
  lang: string;
  onLink: (link: string) => void;
}

const POINTS_ENTRY: QuickItem = {
  label: { zh: "積分商城", en: "Points Mall" },
  link: "/(tabs)/points",
};

const BOX_ENTRY: QuickItem = {
  label: { zh: "盲盒商城", en: "Blind Box" },
  link: "/box",
};

const GROUP_ENTRY: QuickItem = {
  label: { zh: "拼團", en: "Group Buy" },
  link: "/group-lottery",
};

const DEFAULT_ITEMS: QuickItem[] = [POINTS_ENTRY, BOX_ENTRY, GROUP_ENTRY];

type LineIcon = React.ComponentType<{ size?: number; color?: string; strokeWidth?: number }>;
type TealDir = "lr" | "rl" | "tb" | "bt";
const ICON_DIRS: TealDir[] = ["lr", "tb", "bt"];

function labelSearchText(item: QuickItem): string {
  if (typeof item.label === "string") return item.label.toLowerCase();
  if (item.label && typeof item.label === "object") {
    return Object.values(item.label).join(" ").toLowerCase();
  }
  return "";
}

function isPointsEntry(item: QuickItem): boolean {
  const text = labelSearchText(item);
  return Boolean(
    item.link?.includes("points") ||
      text.includes("point") ||
      text.includes("积分") ||
      text.includes("積分"),
  );
}

function isBoxEntry(item: QuickItem): boolean {
  const text = labelSearchText(item);
  return Boolean(item.link?.startsWith("/box") || text.includes("box") || text.includes("盲盒"));
}

function isGroupEntry(item: QuickItem): boolean {
  const text = labelSearchText(item);
  return Boolean(
    item.link?.startsWith("/group-lottery") ||
      text.includes("group") ||
      text.includes("拼团") ||
      text.includes("拼團"),
  );
}

function normalizeQuickItems(configuredItems: QuickItem[]): QuickItem[] {
  const source = configuredItems.length ? configuredItems : DEFAULT_ITEMS;
  const groupEntry = source.find(isGroupEntry) ?? GROUP_ENTRY;

  return [source.find(isPointsEntry) ?? POINTS_ENTRY, source.find(isBoxEntry) ?? BOX_ENTRY, groupEntry];
}

function getQuickIcon(label: string, index: number): LineIcon {
  const text = label.toLowerCase();
  if (text.includes("point") || label.includes("积分") || label.includes("積分")) return Coins;
  if (
    text.includes("blind") ||
    text.includes("mystery") ||
    text.includes("box") ||
    label.includes("盲盒")
  )
    return Gift;
  if (text.includes("group") || label.includes("拼团") || label.includes("拼團")) return Users;
  if (text.includes("coupon") || label.includes("券")) return Ticket;
  if (
    text.includes("all") ||
    text.includes("browse") ||
    label.includes("分类") ||
    label.includes("分類")
  )
    return LayoutGrid;
  if (text.includes("shop") || label.includes("购物") || label.includes("購物")) return ShoppingBag;
  return [Coins, Gift, Users][index % 3];
}

export default function HlQuickGrid({ props, lang, onLink }: HlQuickGridProps) {
  const configuredItems = props.items ?? [];
  const items = normalizeQuickItems(configuredItems);
  if (items.length === 0) return null;

  const columns = Math.max(1, Math.min(5, props.columns ?? items.length ?? 1));
  const widthPct = `${100 / columns}%` as `${number}%`;

  return (
    <View
      style={{
        marginHorizontal: s(16),
        marginTop: s(12),
        paddingVertical: s(16),
        paddingHorizontal: s(10),
        borderRadius: s(24),
        backgroundColor: "#FFFFFF",
        borderWidth: 1,
        borderColor: Colors.screen.hairline,
        ...Shadows.raised,
      }}
    >
      <View style={{ flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
        {items.map((item, index) => {
          const label = pickLang(item.label, lang);
          const Icon = getQuickIcon(label, index);

          return (
            <Pressable
              key={`${item.link ?? label}-${label}`}
              onPress={() => item.link && onLink(item.link)}
              style={({ pressed }) => ({
                width: widthPct,
                alignItems: "center",
                justifyContent: "flex-start",
                minHeight: s(88),
                paddingVertical: s(4),
                transform: [{ scale: pressed ? 0.95 : 1 }],
              })}
            >
              <TealSurface
                radius={s(18)}
                direction={ICON_DIRS[index % ICON_DIRS.length]}
                style={{ width: s(54), height: s(54) }}
                contentStyle={{ alignItems: "center", justifyContent: "center" }}
              >
                <Icon size={s(26)} color="#FFFFFF" strokeWidth={2.1} />
              </TealSurface>
              <Text
                numberOfLines={1}
                style={{
                  color: "#171A1A",
                  fontSize: s(11.5),
                  lineHeight: s(15),
                  fontWeight: "700",
                  marginTop: s(9),
                  maxWidth: s(78),
                  textAlign: "center",
                }}
              >
                {label}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
