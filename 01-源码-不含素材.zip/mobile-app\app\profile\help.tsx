import React, { useState } from "react";
import { Alert, Linking, View, Text, ScrollView, Pressable, TextInput } from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import {
  Search,
  ChevronDown,
  ChevronUp,
  MessageCircle,
  Mail,
  ThumbsUp,
  ThumbsDown,
  Package,
  CreditCard,
  Truck,
  RotateCcw,
  Shield,
  Trophy,
  type LucideIcon,
} from "lucide-react-native";
import { TealGradient, Colors, s, Shadows } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { useLanguage } from "@/hooks/useLanguage";

interface FAQ {
  question: string;
  answer: string;
}

interface Category {
  id: string;
  name: string;
  Icon: LucideIcon;
  faqs: FAQ[];
}

const CATEGORIES: Category[] = [
  {
    id: "orders",
    name: "Order Issues",
    Icon: Package,
    faqs: [
      {
        question: "How can I track my order?",
        answer:
          'You can track your order by going to "My Orders" page and clicking on the order you want to track. You\'ll see real-time updates on your shipment status.',
      },
      {
        question: "Can I cancel my order?",
        answer:
          "Cancellation depends on the order's current status. Open order details or message Support from the Help Center.",
      },
      {
        question: "What if I receive the wrong item?",
        answer:
          "Message Support with your order number and photos of the item received. The team will review the details and follow up.",
      },
    ],
  },
  {
    id: "payment",
    name: "Payment Issues",
    Icon: CreditCard,
    faqs: [
      {
        question: "What payment methods do you accept?",
        answer:
          "Available payment options are shown at checkout before you place the order.",
      },
      {
        question: "Why was my payment declined?",
        answer:
          "Check your payment details or contact your payment provider. Contact Support if the issue continues.",
      },
      {
        question: "How do I get a refund?",
        answer:
          "Refund eligibility and status depend on the order. Open order details and contact Support for help.",
      },
    ],
  },
  {
    id: "shipping",
    name: "Shipping Issues",
    Icon: Truck,
    faqs: [
      {
        question: "How long does shipping take?",
        answer:
          "The available shipping method and estimated delivery window are shown at checkout when available.",
      },
      {
        question: "Do you ship internationally?",
        answer:
          "Shipping options depend on the address. Enter your destination at checkout to see current availability and costs.",
      },
      {
        question: "What if my package is lost?",
        answer:
          "Review the tracking information in order details, then contact Support if you need help.",
      },
    ],
  },
  {
    id: "returns",
    name: "Returns & Exchanges",
    Icon: RotateCcw,
    faqs: [
      {
        question: "What is your return policy?",
        answer:
          "Return eligibility depends on the product and order. Review the applicable policy before purchasing or contact Support.",
      },
      {
        question: "How do I initiate a return?",
        answer:
          "Open order details and contact Support with the item and reason. The team will confirm the available next steps.",
      },
      {
        question: "Can I exchange an item?",
        answer:
          "Exchange availability depends on the product. Contact Support to review the options for your order.",
      },
    ],
  },
  {
    id: "account",
    name: "Account Security",
    Icon: Shield,
    faqs: [
      {
        question: "How do I reset my password?",
        answer:
          "Choose Forgot Password from Sign In and follow the account recovery steps. Contact Support if you cannot access your account.",
      },
      {
        question: "Is my data secure?",
        answer:
          "Read our Privacy Policy for details about account information and service providers. Contact Support with privacy questions.",
      },
      {
        question: "How do I delete my account?",
        answer:
          "Go to Profile > Settings > Delete Account. Note that this action is permanent and all your data will be erased.",
      },
    ],
  },
  {
    id: "points",
    name: "Points Issues",
    Icon: Trophy,
    faqs: [
      {
        question: "How do I earn points?",
        answer:
          "See the current earning activities and terms in the Points section of your account.",
      },
      {
        question: "When do my points expire?",
        answer:
          "Review the current points rules in the Points section for any applicable expiration details.",
      },
      {
        question: "Can I transfer points to another account?",
        answer:
          "No, points are non-transferable and can only be used by the account holder.",
      },
    ],
  },
];

const ZH_CONTENT: Record<string, { name: string; faqs: FAQ[] }> = {
  orders: {
    name: "訂單問題",
    faqs: [
      { question: "如何追蹤我的訂單？", answer: "前往「我的訂單」查看訂單目前狀態與可用的物流資訊。" },
      { question: "我可以取消訂單嗎？", answer: "取消資格依訂單目前狀態而定。請查看訂單詳情，或透過幫助中心聯絡客服。" },
      { question: "如果收到錯誤商品怎麼辦？", answer: "請透過幫助中心聯絡客服，並提供訂單編號及商品照片；客服團隊會確認後續處理方式。" },
    ],
  },
  payment: {
    name: "付款問題",
    faqs: [
      { question: "支援哪些付款方式？", answer: "可使用的付款方式會在下單前顯示於結帳頁面。" },
      { question: "為什麼付款被拒絕？", answer: "請確認付款資料，或聯絡您的付款服務商；若問題持續，請透過幫助中心聯絡客服。" },
      { question: "如何取得退款？", answer: "退款資格與狀態依訂單而定。請查看訂單詳情，或聯絡客服取得協助。" },
    ],
  },
  shipping: {
    name: "配送問題",
    faqs: [
      { question: "配送需要多久？", answer: "若有配送估時，結帳頁面會顯示可選配送方式及預計送達時間。" },
      { question: "有提供國際配送嗎？", answer: "配送方式依收件地址而定。請在結帳時輸入目的地，查看目前可配送範圍與費用。" },
      { question: "如果包裹遺失怎麼辦？", answer: "請先查看訂單詳情中的物流資訊；如需協助，請透過幫助中心聯絡客服。" },
    ],
  },
  returns: {
    name: "退貨與換貨",
    faqs: [
      { question: "退貨政策是什麼？", answer: "退貨資格依商品與訂單而定。購買前請查看適用政策，或聯絡客服確認。" },
      { question: "如何申請退貨？", answer: "請從訂單詳情聯絡客服，提供商品與原因；客服團隊會告知可行的後續步驟。" },
      { question: "可以換貨嗎？", answer: "是否可換貨依商品而定。請聯絡客服確認您的訂單可選方式。" },
    ],
  },
  account: {
    name: "帳戶安全",
    faqs: [
      { question: "如何重設密碼？", answer: "在登入頁選擇「忘記密碼」並依照帳戶復原步驟操作。如無法登入，請聯絡客服。" },
      { question: "我的資料安全嗎？", answer: "請閱讀隱私政策，了解帳戶資料與服務供應商的使用方式；如有疑問，請聯絡客服。" },
      { question: "如何刪除帳戶？", answer: "如需刪除帳戶，請透過幫助中心聯絡客服，確認身分與後續處理方式。" },
    ],
  },
  points: {
    name: "積分問題",
    faqs: [
      { question: "如何獲得積分？", answer: "請前往帳戶中的積分專區查看目前可參加的累積活動與相關條款。" },
      { question: "積分何時到期？", answer: "請查看積分專區的現行規則，確認適用的到期資訊。" },
      { question: "可以把積分轉給其他帳戶嗎？", answer: "不可以。積分不可轉讓，僅限帳戶持有人使用。" },
    ],
  },
};

export default function HelpCenterScreen() {
  const router = useRouter();
  const { currentLanguage } = useLanguage();
  const zh = currentLanguage === "zh-TW";
  const categories = zh
    ? CATEGORIES.map((category) => ({
        ...category,
        name: ZH_CONTENT[category.id].name,
        faqs: ZH_CONTENT[category.id].faqs,
      }))
    : CATEGORIES;
  const copy = zh
    ? {
        title: "幫助中心",
        search: "搜尋協助內容…",
        browse: "依類別瀏覽",
        faq: "常見問題",
        stillNeedHelp: "還需要協助嗎？",
        liveChat: "站內訊息聯絡客服",
        availability: "可透過站內訊息詢問訂單、配送、付款或帳戶問題。",
        email: "電子郵件客服",
        helpful: "這些內容有幫助嗎？",
        improve: "告訴我們如何持續改善",
        yes: "有",
        no: "沒有",
        thanksTitle: "謝謝您！",
        thanksBody: "很高興能協助您。",
        feedbackTitle: "意見回饋",
        feedbackBody: "感謝告訴我們，我們會持續改善。",
      }
    : {
        title: "Help Center",
        search: "Search for help...",
        browse: "Browse by Category",
        faq: "Frequently Asked Questions",
        stillNeedHelp: "Still Need Help?",
        liveChat: "Message Support",
        availability: "Contact us about an order, delivery, payment, or account issue.",
        email: "Email Support",
        helpful: "Was this helpful?",
        improve: "Let us know how we can improve",
        yes: "Yes",
        no: "No",
        thanksTitle: "Thank you!",
        thanksBody: "Glad we could help.",
        feedbackTitle: "Feedback",
        feedbackBody: "We'll improve! Thanks for letting us know.",
      };
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedCategory, setExpandedCategory] = useState<string | null>(
    null
  );
  const [expandedFAQ, setExpandedFAQ] = useState<string | null>(null);

  const toggleCategory = (categoryId: string) => {
    setExpandedCategory(expandedCategory === categoryId ? null : categoryId);
    setExpandedFAQ(null);
  };

  const toggleFAQ = (categoryId: string, faqIndex: number) => {
    const key = `${categoryId}-${faqIndex}`;
    setExpandedFAQ(expandedFAQ === key ? null : key);
  };

  const activeFaqs = categories.find(
    (c) => c.id === expandedCategory
  )?.faqs;

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={copy.title} />

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Search */}
        <View className="bg-white px-4 py-4 border-b border-gray-200">
          <View className="flex-row items-center bg-gray-50 border border-gray-200 rounded-xl px-3"
            style={{ height: s(44) }}
          >
            <Search size={s(18)} color={Colors.neutral[400]} />
            <TextInput
              placeholder={copy.search}
              value={searchQuery}
              onChangeText={setSearchQuery}
              className="flex-1 ml-2 text-sm"
              placeholderTextColor={Colors.neutral[400]}
              style={{ color: Colors.neutral[900] }}
            />
          </View>
        </View>

        {/* Category Cards */}
        <View className="px-4 pt-4">
          <Text className="text-sm font-bold text-gray-900 mb-3">
            {copy.browse}
          </Text>
          <View className="flex-row flex-wrap justify-between mb-6">
            {categories.map((category) => {
              const isSelected = expandedCategory === category.id;
              return (
                <View
                  key={category.id}
                  style={{ width: "48%", marginBottom: s(12) }}
                >
                  {isSelected ? (
                    <Pressable onPress={() => toggleCategory(category.id)}>
                      <LinearGradient
                        colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                        start={{ x: 0, y: 0.5 }}
                        end={{ x: 1, y: 0.5 }}
                        style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6, 
                          height: s(80),
                          borderRadius: s(16),
                          alignItems: "center",
                          justifyContent: "center",
                          gap: s(8),
                        }}
                      >
                          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                        <category.Icon size={s(24)} color="#FFFFFF" strokeWidth={1.9} />
                        <Text className="text-xs font-bold text-white text-center px-2">
                          {category.name}
                        </Text>
                      </LinearGradient>
                    </Pressable>
                  ) : (
                    <Pressable
                      onPress={() => toggleCategory(category.id)}
                      className="bg-white items-center justify-center"
                      style={{
                        height: s(80),
                        borderRadius: s(16),
                        gap: s(8),
                        ...Shadows.sm,
                      }}
                    >
                      <category.Icon size={s(24)} color="#04A8AE" strokeWidth={1.9} />
                      <Text className="text-xs font-bold text-gray-700 text-center px-2">
                        {category.name}
                      </Text>
                    </Pressable>
                  )}
                </View>
              );
            })}
          </View>
        </View>

        {/* FAQ Accordion */}
        {expandedCategory && activeFaqs && (
          <View className="px-4 mb-6">
            <Text className="text-sm font-bold text-gray-900 mb-3">
              {copy.faq}
            </Text>
            <View
              className="bg-white rounded-2xl overflow-hidden"
              style={Shadows.sm}
            >
              {activeFaqs.map((faq, index) => {
                const key = `${expandedCategory}-${index}`;
                const isExpanded = expandedFAQ === key;
                return (
                  <View key={index}>
                    <Pressable
                      onPress={() => toggleFAQ(expandedCategory, index)}
                      className="px-4 py-4 flex-row items-center justify-between"
                    >
                      <Text className="text-sm font-bold text-gray-900 flex-1 pr-4">
                        {faq.question}
                      </Text>
                      {isExpanded ? (
                        <ChevronUp size={s(20)} color={Colors.brand.red} />
                      ) : (
                        <ChevronDown
                          size={s(20)}
                          color={Colors.neutral[400]}
                        />
                      )}
                    </Pressable>
                    {isExpanded && (
                      <View className="px-4 pb-4 border-t border-gray-100">
                        <Text className="text-sm text-gray-700 leading-relaxed mt-3">
                          {faq.answer}
                        </Text>
                      </View>
                    )}
                    {index < activeFaqs.length - 1 && (
                      <View className="border-t border-gray-100" />
                    )}
                  </View>
                );
              })}
            </View>
          </View>
        )}

        {/* Contact Methods */}
        <View className="px-4 mb-6">
          <Text className="text-sm font-bold text-gray-900 mb-3">
            {copy.stillNeedHelp}
          </Text>
          <View style={{ gap: s(12) }}>
            <Pressable
              className="bg-white rounded-2xl p-4 flex-row items-center gap-4"
              style={Shadows.sm}
              onPress={() => router.push("/profile/service")}
            >
              <View
                className="w-12 h-12 rounded-full items-center justify-center"
                style={{ backgroundColor: Colors.info }}
              >
                <MessageCircle size={s(24)} color="#fff"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-bold text-gray-900 mb-0.5">
                  {copy.liveChat}
                </Text>
                <Text className="text-xs text-gray-600">
                  {copy.availability}
                </Text>
              </View>
            </Pressable>

            <Pressable
              className="bg-white rounded-2xl p-4 flex-row items-center gap-4"
              style={Shadows.sm}
              onPress={() => Linking.openURL("mailto:support@vivodraw.com")}
            >
              <View
                className="w-12 h-12 rounded-full items-center justify-center"
                style={{ backgroundColor: Colors.ios.purple }}
              >
                <Mail size={s(24)} color="#fff"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-bold text-gray-900 mb-0.5">
                  {copy.email}
                </Text>
                <Text className="text-xs text-gray-600">
                  support@vivodraw.com
                </Text>
              </View>
            </Pressable>
          </View>
        </View>

        {/* Feedback */}
        <View className="px-4 mb-8">
          <View
            className="rounded-2xl p-5 border border-neutral-200"
            style={{ backgroundColor: "#F7F8F8" }}
          >
            <View className="items-center mb-4">
              <Text className="text-sm font-bold text-gray-900 mb-1">
                {copy.helpful}
              </Text>
              <Text className="text-xs text-gray-600">
                {copy.improve}
              </Text>
            </View>
            <View className="flex-row gap-3">
              <Pressable
                className="flex-1 h-11 bg-white border-2 border-gray-200 rounded-xl flex-row items-center justify-center gap-2"
                onPress={() => Alert.alert(copy.thanksTitle, copy.thanksBody)}
              >
                <ThumbsUp size={s(18)} color={Colors.neutral[700]} />
                <Text className="font-bold text-sm text-gray-700">{copy.yes}</Text>
              </Pressable>
              <Pressable
                className="flex-1 h-11 bg-white border-2 border-gray-200 rounded-xl flex-row items-center justify-center gap-2"
                onPress={() => Alert.alert(copy.feedbackTitle, copy.feedbackBody)}
              >
                <ThumbsDown size={s(18)} color={Colors.neutral[700]} />
                <Text className="font-bold text-sm text-gray-700">{copy.no}</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
