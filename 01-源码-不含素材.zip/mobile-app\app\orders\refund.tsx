import PageHeader from "@/components/shared/PageHeader";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import { applyRefund, getRefundCartInfo, getRefundReasons } from "@/lib/api/order";
import { type ApiRecord, isApiRecord, unwrapApiData } from "@/lib/api/response";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

type RefundCartItem = ApiRecord & {
  id?: number | string;
  cart_id?: number | string;
  cart_num?: number | string;
  surplus_num?: number | string;
};

function getReasonList(value: unknown): string[] {
  const data = unwrapApiData<unknown>(value, []);
  if (!Array.isArray(data)) return [];
  return data.filter((item): item is string => typeof item === "string" && item.trim().length > 0);
}

function getRefundCartList(value: unknown): RefundCartItem[] {
  const data = unwrapApiData<unknown>(value, []);
  if (Array.isArray(data)) return data as RefundCartItem[];
  if (isApiRecord(data) && Array.isArray(data.cart_info)) {
    return data.cart_info as RefundCartItem[];
  }
  return [];
}

function getErrorMessage(err: unknown, fallback: string): string {
  return err instanceof Error ? err.message : fallback;
}

function numberValue(value: unknown, fallback = 0): number {
  const next = Number(value);
  return Number.isFinite(next) ? next : fallback;
}

export default function OrderRefundScreen() {
  const { t } = useTranslation();
  const { orderId, id } = useLocalSearchParams<{ orderId: string; id: string }>();
  const router = useRouter();
  const queryClient = useQueryClient();
  const orderIdNum = Number.parseInt(id || "0", 10);

  const [refundType, setRefundType] = useState<1 | 2>(1);
  const [reason, setReason] = useState("");
  const [explain, setExplain] = useState("");

  const { data: reasonsData } = useQuery({
    queryKey: ["refundReasons"],
    queryFn: getRefundReasons,
  });

  const { data: cartData } = useQuery({
    queryKey: ["refundCartInfo", orderIdNum],
    queryFn: () => getRefundCartInfo(orderIdNum),
    enabled: orderIdNum > 0,
  });

  const applyMutation = useMutation({
    mutationFn: (data: Parameters<typeof applyRefund>[1]) => applyRefund(orderIdNum, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["orderDetail", orderId] });
      queryClient.invalidateQueries({ queryKey: ["orderList"] });
      Alert.alert(t("common.success"), t("shopOrderRefund.submitted"), [
        { text: t("common.ok"), onPress: () => router.back() },
      ]);
    },
    onError: (err: unknown) => {
      Alert.alert(t("common.failed"), getErrorMessage(err, t("shopOrderRefund.submitFailed")));
    },
  });

  const reasons = getReasonList(reasonsData);
  const cartList = getRefundCartList(cartData);
  const cartIds = cartList
    .map((c) => ({
      cart_id: numberValue(c.id ?? c.cart_id),
      cart_num: Math.max(1, numberValue(c.cart_num ?? c.surplus_num, 1)),
    }))
    .filter((item) => item.cart_id > 0);

  const handleSubmit = () => {
    if (!reason.trim()) {
      Alert.alert(t("common.notice"), t("shopOrderRefund.selectReason"));
      return;
    }
    if (cartIds.length === 0) {
      applyMutation.mutate({
        text: reason,
        refund_type: refundType,
        refund_reason_wap_explain: explain,
        refund_price: 0,
      });
    } else {
      applyMutation.mutate({
        text: reason,
        refund_type: refundType,
        refund_reason_wap_explain: explain,
        cart_ids: cartIds,
      });
    }
  };

  if (!orderId || !id) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("shopOrderRefund.title")} />
        <View className="flex-1 items-center justify-center">
          <Text style={{ color: Colors.neutral[500] }}>{t("shopOrderRefund.missingParams")}</Text>
        </View>
      </View>
    );
  }

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("shopOrderRefund.title")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
        showsVerticalScrollIndicator={false}
      >
        <View className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
          <Text className="font-semibold mb-3" style={{ color: Colors.neutral[800] }}>
            {t("shopOrderRefund.refundType")}
          </Text>
          <View className="flex-row gap-3">
            <Pressable
              onPress={() => setRefundType(1)}
              style={{
                flex: 1,
                paddingVertical: s(12),
                borderRadius: s(12),
                backgroundColor: refundType === 1 ? `${Colors.brand.red}15` : Colors.neutral[50],
                borderWidth: 1,
                borderColor: refundType === 1 ? Colors.brand.red : Colors.neutral[200],
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  fontWeight: "600",
                  color: refundType === 1 ? Colors.brand.red : Colors.neutral[600],
                }}
              >
                {t("shopOrderRefund.refundOnly")}
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setRefundType(2)}
              style={{
                flex: 1,
                paddingVertical: s(12),
                borderRadius: s(12),
                backgroundColor: refundType === 2 ? `${Colors.brand.red}15` : Colors.neutral[50],
                borderWidth: 1,
                borderColor: refundType === 2 ? Colors.brand.red : Colors.neutral[200],
                alignItems: "center",
              }}
            >
              <Text
                style={{
                  fontWeight: "600",
                  color: refundType === 2 ? Colors.brand.red : Colors.neutral[600],
                }}
              >
                {t("shopOrderRefund.returnRefund")}
              </Text>
            </Pressable>
          </View>
        </View>

        <View className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
          <Text className="font-semibold mb-3" style={{ color: Colors.neutral[800] }}>
            {t("shopOrderRefund.refundReason")} *
          </Text>
          {reasons.length > 0 ? (
            <View className="flex-row flex-wrap gap-2">
              {reasons.map((r) => (
                <Pressable
                  key={r}
                  onPress={() => setReason(r)}
                  style={{
                    paddingHorizontal: s(14),
                    paddingVertical: s(8),
                    borderRadius: s(20),
                    backgroundColor: reason === r ? `${Colors.brand.red}15` : Colors.neutral[50],
                    borderWidth: 1,
                    borderColor: reason === r ? Colors.brand.red : Colors.neutral[200],
                  }}
                >
                  <Text
                    style={{
                      fontSize: s(13),
                      color: reason === r ? Colors.brand.red : Colors.neutral[600],
                    }}
                  >
                    {r}
                  </Text>
                </Pressable>
              ))}
            </View>
          ) : (
            <TextInput
              value={reason}
              onChangeText={setReason}
              placeholder={t("shopOrderRefund.reasonPlaceholder")}
              placeholderTextColor={Colors.neutral[400]}
              style={{
                padding: s(12),
                borderRadius: s(12),
                backgroundColor: Colors.neutral[50],
                borderWidth: 1,
                borderColor: Colors.neutral[200],
                color: Colors.neutral[800],
                fontSize: s(14),
              }}
            />
          )}
        </View>

        <View className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
          <Text className="font-semibold mb-3" style={{ color: Colors.neutral[800] }}>
            {t("shopOrderRefund.additionalNote")}
          </Text>
          <TextInput
            value={explain}
            onChangeText={setExplain}
            placeholder={t("shopOrderRefund.notePlaceholder")}
            placeholderTextColor={Colors.neutral[400]}
            multiline
            numberOfLines={3}
            style={{
              padding: s(12),
              borderRadius: s(12),
              backgroundColor: Colors.neutral[50],
              borderWidth: 1,
              borderColor: Colors.neutral[200],
              color: Colors.neutral[800],
              fontSize: s(14),
              minHeight: s(80),
            }}
          />
        </View>

        <Pressable
          onPress={handleSubmit}
          disabled={applyMutation.isPending}
          style={{
            paddingVertical: s(14),
            borderRadius: s(12),
            alignItems: "center",
          }}
        >
          <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
          {applyMutation.isPending ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <Text className="font-semibold" style={{ color: "#FFF", fontSize: s(16) }}>
              {t("shopOrderRefund.submit")}
            </Text>
          )}
        </Pressable>
      </ScrollView>
    </View>
  );
}
