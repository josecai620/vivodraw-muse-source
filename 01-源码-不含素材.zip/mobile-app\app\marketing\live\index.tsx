import React from "react";
import { ActivityIndicator, Image, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { getLiveList } from "@/lib/api/live";
import { normalizeImageUrl } from "@/lib/utils";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";
import { Video } from "lucide-react-native";

export default function LiveScreen() {
  const router = useRouter();
  const { data, isLoading } = useQuery({
    queryKey: ["liveList"],
    queryFn: getLiveList,
  });

  const raw = (data as any)?.data ?? data ?? {};
  const list = raw?.list ?? (Array.isArray(raw) ? raw : []);

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Live" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }} showsVerticalScrollIndicator={false}>
          {Array.isArray(list) && list.length > 0 ? (
            list.map((item: any, i: number) => {
              const id = item.id ?? item.room_id ?? i;
              const cover = item.cover ?? item.coverImg ?? item.cover_url ?? "";
              const name = item.name ?? item.roomName ?? item.title ?? "Live";
              const status = item.liveStatus ?? item.status ?? 0;
              const isLive = status === 101;

              return (
                <Pressable
                  key={id}
                  onPress={() => router.push(`/marketing/live/${id}`)}
                  className="bg-white rounded-2xl mb-3 overflow-hidden border border-gray-100"
                >
                  <View className="relative">
                    {cover ? (
                      <Image source={{ uri: normalizeImageUrl(cover) }} className="w-full h-40" resizeMode="cover" />
                    ) : (
                      <View className="w-full h-40 bg-gray-200 items-center justify-center">
                        <Video size={s(48)} color={Colors.neutral[400]} />
                      </View>
                    )}
                    {isLive && (
                      <View className="absolute top-2 left-2 px-2 py-0.5 rounded bg-brand-red-light0">
                        <Text className="text-white text-xs font-bold">LIVE</Text>
                      </View>
                    )}
                  </View>
                  <View className="p-3">
                    <Text className="font-semibold" style={{ color: Colors.neutral[800] }} numberOfLines={2}>
                      {name}
                    </Text>
                  </View>
                </Pressable>
              );
            })
          ) : (
            <View className="py-12 items-center">
              <Video size={s(48)} color={Colors.neutral[300]} />
              <Text className="mt-3" style={{ color: Colors.neutral[500] }}>
                No live rooms
              </Text>
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}
