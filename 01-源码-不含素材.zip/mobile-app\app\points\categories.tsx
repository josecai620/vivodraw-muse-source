import React, { useMemo, useState } from "react";
import { Image, Pressable, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { ShoppingCart } from "lucide-react-native";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import CloudBuyProgress from "@/components/points/CloudBuyProgress";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useAddPointsCart, usePointsCategories, usePointsCategoryProducts, usePointsProducts } from "@/hooks";
import { unwrapApiPagedList } from "@/lib/api/response";
import { mapCloudProduct } from "@/lib/points/cloudBuyParse";
import { useAuthStore } from "@/store/auth";

const TEAL = Colors.primary.DEFAULT;

export default function PointsCategoriesScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ cate?: string }>();
  const initial = Number(params.cate ?? 0);
  const [cate, setCate] = useState(Number.isFinite(initial) && initial > 0 ? initial : 0);
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const addCart = useAddPointsCart();
  const { data: catData } = usePointsCategories();
  const { data: catProdData } = usePointsCategoryProducts(cate);
  const { data: allData } = usePointsProducts();

  const categories = useMemo(() => {
    const list = unwrapApiPagedList<any>(catData)
      .map((c) => ({
        id: Number(c.value ?? c.id ?? 0),
        name: String(c.cate_name ?? c.name ?? ""),
      }))
      .filter((c) => c.id > 0 && c.name);
    return [{ id: 0, name: t("pointsMall.tabAllPeriods") }, ...list];
  }, [catData, t]);

  const products = useMemo(() => {
    const raw = cate > 0 ? unwrapApiPagedList<any>(catProdData) : unwrapApiPagedList<any>(allData);
    const mapped = raw.map(mapCloudProduct).filter(Boolean) as NonNullable<ReturnType<typeof mapCloudProduct>>[];
    if (mapped.length > 0) return mapped;
    return unwrapApiPagedList<any>(allData)
      .filter((item) => cate <= 0 || Number(item.cate_id ?? item.cid ?? item.category_id) === cate)
      .map(mapCloudProduct)
      .filter(Boolean) as NonNullable<ReturnType<typeof mapCloudProduct>>[];
  }, [allData, catProdData, cate]);

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.categories")} />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} className="bg-white" style={{ flexGrow: 0 }}>
        {categories.map((c) => {
          const on = cate === c.id;
          return (
            <Pressable key={c.id} className="px-3 py-2.5" onPress={() => setCate(c.id)}>
              <Text
                className="text-sm font-bold"
                style={{
                  color: on ? TEAL : "#6B7280",
                  borderBottomWidth: on ? 2 : 0,
                  borderBottomColor: TEAL,
                  paddingBottom: 3,
                }}
              >
                {c.name}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>
      <ScrollView
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}
        showsVerticalScrollIndicator={false}
      >
        {products.length === 0 ? (
          <Text className="text-center text-gray-400 py-16">{t("pointsMall.noProductsFound")}</Text>
        ) : (
          products.map((item) => (
            <Pressable
              key={item.id}
              className="flex-row px-3 py-3 bg-white border-b border-gray-100"
              onPress={() => router.push({ pathname: "/points/product", params: { id: String(item.id) } })}
            >
              <View className="w-20 h-20 bg-gray-50 rounded overflow-hidden items-center justify-center mr-3">
                {item.image ? (
                  <Image source={{ uri: item.image }} className="w-full h-full" resizeMode="contain" />
                ) : null}
              </View>
              <View className="flex-1 pr-2">
                <Text className="text-sm text-gray-900 mb-1" numberOfLines={2}>
                  {item.name}
                </Text>
                <Text className="text-xs text-gray-500 mb-1.5">
                  {t("pointsMall.valueLabel")}: {item.points}
                </Text>
                <CloudBuyProgress
                  joined={item.sold}
                  total={item.total}
                  remain={item.remain}
                  joinedLabel={t("pointsMall.joined")}
                  totalLabel={t("pointsMall.totalNeed")}
                  remainLabel={t("pointsMall.remain")}
                />
              </View>
              <Pressable
                className="self-center w-10 h-10 rounded-full items-center justify-center"
                style={{ backgroundColor: TEAL }}
                onPress={() => {
                  if (!isLoggedIn) {
                    router.push("/auth");
                    return;
                  }
                  addCart.mutate({ productId: item.id, cartNum: 1 });
                }}
              >
                <ShoppingCart size={18} color="#fff" />
              </Pressable>
            </Pressable>
          ))
        )}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
