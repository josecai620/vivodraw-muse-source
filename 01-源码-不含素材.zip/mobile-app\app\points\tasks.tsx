import React from "react";
import { Pressable, ScrollView, Text, View, ActivityIndicator } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import {
  Trophy,
  CheckCircle,
  ChevronRight,
  Gift,
  ShoppingBag,
  Share2,
  MessageCircle,
  Users,
} from "lucide-react-native";
import { useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { TealGradient, Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { usePointsTasks, useClaimPointsTask, useTrackPointsTaskEvent } from "@/hooks";
import { unwrapApiData } from "@/lib/api/response";

const TASK_KEYS: Record<number, string> = {
  1: "checkin",
  2: "browse",
  3: "wishlist",
  4: "share",
  5: "purchase",
  6: "reviews",
  7: "invite",
  8: "profile",
  9: "first_purchase",
  10: "refer5",
  11: "spend500",
};

const TASK_ROUTES: Record<number, string> = {
  1: "/points/checkin",
  2: "/points",
  3: "/profile/wishlist",
  4: "/points",
  5: "/points",
  6: "/points",
  7: "/profile",
  8: "/profile/edit",
  9: "/points",
  10: "/profile",
  11: "/points",
};

function TaskCard({
  task,
  onClaim,
  claiming,
}: {
  task: any;
  onClaim: () => void;
  claiming: boolean;
}) {
  const { t } = useTranslation();
  const router = useRouter();
  const track = useTrackPointsTaskEvent();
  const key = TASK_KEYS[task.id] || "checkin";
  const claimed = task.status === "claimed" || task.claimed;
  const available = task.status === "available";
  const progress = task.progress || { current: 0, total: 1 };
  const percent = progress.total ? (progress.current / progress.total) * 100 : 0;

  return (
    <View
      className={`rounded-2xl p-4 border mb-3 ${claimed ? "bg-teal-50/30 border-teal-200" : "bg-white border-gray-100"}`}
    >
      <View className="flex-row items-start gap-3">
        <View className={`w-12 h-12 rounded-xl items-center justify-center ${claimed ? "bg-teal-100" : "bg-gray-50"}`}>
          {claimed ? <CheckCircle size={22} color={Colors.primary.DEFAULT} /> : <Trophy size={22} color="#9CA3AF" />}
        </View>
        <View className="flex-1">
          <Text className="text-gray-900 font-semibold">{t(`pointsTasks.items.${key}.title`)}</Text>
          <Text className="text-xs text-gray-500 mt-1">{t(`pointsTasks.items.${key}.desc`)}</Text>
          {progress.total > 1 ? (
            <View className="mt-2">
              <Text className="text-[10px] text-gray-400 mb-1">
                {t("pointsTasks.progressLabel")} {progress.current}/{progress.total}
              </Text>
              <View className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <View className="h-full bg-teal-500" style={{ width: `${Math.min(100, percent)}%` }} />
              </View>
            </View>
          ) : null}
        </View>
        <Text className="text-teal-700 font-bold">+{task.lucky}</Text>
      </View>
      <View className="mt-3">
        {claimed ? (
          <Text className="text-xs text-teal-700">{t("pointsTasks.completed")}</Text>
        ) : available ? (
          <Pressable
            onPress={onClaim}
            disabled={claiming}
            className="h-10 rounded-full items-center justify-center"
            style={{ backgroundColor: Colors.primary.DEFAULT }}
          >
            {claiming ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text className="text-white font-semibold">{t("pointsTasks.claim")}</Text>
            )}
          </Pressable>
        ) : (
          <Pressable
            onPress={() => {
              if (task.id === 4) track.mutate({ event: "share", ref: "tasks" });
              router.push((TASK_ROUTES[task.id] || "/points") as never);
            }}
            className="h-10 rounded-full items-center justify-center flex-row bg-gray-100"
          >
            <Text className="text-gray-700 font-semibold mr-1">{t("pointsTasks.go")}</Text>
            <ChevronRight size={16} color="#374151" />
          </Pressable>
        )}
      </View>
    </View>
  );
}

export default function PointsTasksScreen() {
  const { t } = useTranslation();
  const { data, isLoading } = usePointsTasks();
  const claim = useClaimPointsTask();
  const payload = unwrapApiData<any>(data, {});
  const list = Array.isArray(payload.list) ? payload.list : [];
  const daily = list.filter((row: any) => row.period === "daily");
  const weekly = list.filter((row: any) => row.period === "weekly");
  const special = list.filter((row: any) => row.period === "once");

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("pointsTasks.title")} />
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <View className="px-4 mt-4 mb-5">
          <LinearGradient
            colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
            className="p-6"
            style={{ borderRadius: 24 }}
          >
            <View className="flex-row justify-between">
              <View>
                <Text className="text-white/80 text-xs">{t("pointsTasks.todayLucky")}</Text>
                <Text className="text-white text-3xl font-bold">+{payload.todayLucky || 0}</Text>
              </View>
              <View>
                <Text className="text-white/80 text-xs">{t("pointsTasks.thisWeek")}</Text>
                <Text className="text-white text-3xl font-bold">+{payload.weeklyLucky || 0}</Text>
              </View>
            </View>
            <Text className="text-white/80 text-xs mt-4">
              {t("pointsTasks.completedCount", { done: payload.completed || 0, total: payload.total || 11 })}
            </Text>
          </LinearGradient>
        </View>

        <View className="px-4 mb-4 flex-row justify-between">
          {[
            { Icon: ShoppingBag, label: t("pointsTasks.shop"), href: "/points" },
            { Icon: Share2, label: t("pointsTasks.share"), href: "/points" },
            { Icon: MessageCircle, label: t("pointsTasks.review"), href: "/points" },
            { Icon: Users, label: t("pointsTasks.invite"), href: "/profile" },
          ].map((item) => (
            <Quick key={item.label} {...item} />
          ))}
        </View>

        {isLoading ? <ActivityIndicator className="my-6" color={Colors.primary.DEFAULT} /> : null}

        <Section title={t("pointsTasks.daily")} hint={t("pointsTasks.dailyHint")}>
          {daily.map((task: any) => (
            <TaskCard key={task.id} task={task} claiming={claim.isPending} onClaim={() => claim.mutate(task.id)} />
          ))}
        </Section>
        <Section title={t("pointsTasks.weekly")} hint={t("pointsTasks.weeklyHint")}>
          {weekly.map((task: any) => (
            <TaskCard key={task.id} task={task} claiming={claim.isPending} onClaim={() => claim.mutate(task.id)} />
          ))}
        </Section>
        <Section title={t("pointsTasks.special")} hint={t("pointsTasks.footerTitle")}>
          {special.map((task: any) => (
            <TaskCard key={task.id} task={task} claiming={claim.isPending} onClaim={() => claim.mutate(task.id)} />
          ))}
        </Section>
        <View className="px-4 mb-10">
          <View className="bg-white rounded-2xl p-4 flex-row">
            <Gift size={18} color={Colors.primary.DEFAULT} />
            <Text className="text-xs text-gray-500 ml-2 flex-1">{t("pointsTasks.footerHint")}</Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

function Quick({ Icon, label, href }: { Icon: typeof ShoppingBag; label: string; href: string }) {
  const router = useRouter();
  const track = useTrackPointsTaskEvent();
  return (
    <Pressable
      onPress={() => {
        if (href === "/points") track.mutate({ event: "browse", ref: "quick" });
        router.push(href as never);
      }}
      className="w-[22%] bg-white rounded-2xl py-3 items-center"
    >
      <Icon size={18} color={Colors.primary.DEFAULT} />
      <Text className="text-[10px] text-gray-600 mt-1">{label}</Text>
    </Pressable>
  );
}

function Section({ title, hint, children }: { title: string; hint: string; children: React.ReactNode }) {
  return (
    <View className="px-4 mb-5">
      <Text className="text-gray-800 font-semibold">{title}</Text>
      <Text className="text-[10px] text-gray-400 mb-3">{hint}</Text>
      {children}
    </View>
  );
}
