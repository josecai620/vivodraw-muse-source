/**
 * 模板：普通页面（有 Header + 滚动内容）
 * 使用方法：复制到 app/xxx/index.tsx，改函数名和标题
 */
import React from "react";
import { ScrollView, Text, View } from "react-native";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";

export default function TemplatePageScreen() {
  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Page Title" />

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
      >
        {/* 在这里放页面内容 */}
        <View className="bg-white rounded-2xl p-4 mb-4">
          <Text className="text-base font-semibold text-gray-900 mb-2">
            Section Title
          </Text>
          <Text className="text-sm text-gray-600">
            Content goes here...
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
