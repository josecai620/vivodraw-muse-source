import 头像裁剪弹窗 from "@/components/profile/头像裁剪弹窗";
import { unwrapApiData } from "@/lib/api/response";
import { updateProfile, uploadImage } from "@/lib/api/user";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";
import * as ImagePicker from "expo-image-picker";
import { createElement, useCallback, useState } from "react";
import { useTranslation } from "react-i18next";
import { ActionSheetIOS, Alert, Platform } from "react-native";

type ReactNativeFormFile = { uri: string; name: string; type: string };

function asFormDataFile(file: ReactNativeFormFile) {
  return file as unknown as Blob;
}

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

function isLikelyImage(file: File) {
  const type = (file.type || "").toLowerCase();
  if (type.startsWith("image/")) return true;
  if (type && type !== "application/octet-stream") return false;
  return /\.(jpe?g|png|gif|webp|heic|heif|bmp)$/i.test(file.name || "") || file.size > 32;
}

let webPicker: HTMLInputElement | null = null;

function getWebPicker() {
  if (typeof document === "undefined") return null;
  if (webPicker && document.body.contains(webPicker)) return webPicker;
  const input = document.createElement("input");
  input.type = "file";
  input.accept = "image/*";
  input.setAttribute("autocomplete", "off");
  input.style.position = "fixed";
  input.style.left = "-100vw";
  input.style.top = "0";
  input.style.width = "1px";
  input.style.height = "1px";
  input.style.opacity = "0";
  document.body.appendChild(input);
  webPicker = input;
  return input;
}

export function useAvatarUpload(options?: { persist?: boolean; onPicked?: (url: string) => void }) {
  const persist = options?.persist ?? true;
  const { t } = useTranslation();
  const showToast = useAppStore((s) => s.showToast);
  const [uploading, setUploading] = useState(false);
  const [cropFile, setCropFile] = useState<File | Blob | null>(null);
  const [cropUri, setCropUri] = useState<string | null>(null);
  const [cropOpen, setCropOpen] = useState(false);

  const finishUrl = useCallback(
    async (avatarUrl: string) => {
      if (persist) {
        await updateProfile({ avatar: avatarUrl });
        const current = useAuthStore.getState().user;
        if (current) useAuthStore.getState().setUser({ ...current, avatar: avatarUrl });
        showToast(t("profile.avatarUpdated"), "success");
      }
      options?.onPicked?.(avatarUrl);
    },
    [options, persist, showToast, t],
  );

  const uploadBlob = useCallback(
    async (blob: Blob, name = "avatar.jpg") => {
      setUploading(true);
      try {
        const file = blob instanceof File ? blob : new File([blob], name, { type: blob.type || "image/jpeg" });
        const formData = new FormData();
        formData.append("filename", file, name);
        const uploadData = unwrapApiData<{ url?: string }>(await uploadImage(formData), {});
        if (!uploadData.url) throw new Error("No URL returned");
        await finishUrl(uploadData.url);
      } catch (error: unknown) {
        showToast(getErrorMessage(error, t("profile.avatarUpdateFailed")), "error");
      } finally {
        setUploading(false);
        setCropOpen(false);
        setCropFile(null);
        setCropUri(null);
      }
    },
    [finishUrl, showToast, t],
  );

  const openCrop = useCallback(
    (file: File) => {
      if (!isLikelyImage(file)) {
        showToast(t("profile.imageOnlyAllowed"), "error");
        return;
      }
      setCropFile(file);
      setCropUri(null);
      setCropOpen(true);
    },
    [showToast, t],
  );

  const openWebPicker = useCallback(() => {
    if (Platform.OS !== "web") return;
    const input = getWebPicker();
    if (!input) return;
    input.value = "";
    input.onchange = () => {
      const file = input.files?.[0];
      input.onchange = null;
      input.value = "";
      if (!file) return;
      openCrop(file);
    };
    input.click();
  }, [openCrop]);

  const pickNative = useCallback(
    async (useCamera: boolean) => {
      const permission = useCamera
        ? await ImagePicker.requestCameraPermissionsAsync()
        : await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) return;
      const result = useCamera
        ? await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [1, 1], quality: 0.9 })
        : await ImagePicker.launchImageLibraryAsync({
            allowsEditing: true,
            aspect: [1, 1],
            quality: 0.9,
            mediaTypes: ["images"],
          });
      if (result.canceled || !result.assets?.[0]) return;
      const asset = result.assets[0];
      const ext = (asset.uri.split(".").pop() || "jpg").toLowerCase();
      if (!["jpg", "jpeg", "png", "gif", "webp", "heic", "heif"].includes(ext)) {
        showToast(t("profile.imageOnlyAllowed"), "error");
        return;
      }
      setUploading(true);
      try {
        const formData = new FormData();
        formData.append(
          "filename",
          asFormDataFile({
            uri: asset.uri,
            name: `avatar.${ext === "heic" || ext === "heif" ? "jpg" : ext}`,
            type: asset.mimeType || `image/${ext === "jpg" || ext === "heic" || ext === "heif" ? "jpeg" : ext}`,
          }),
        );
        const uploadData = unwrapApiData<{ url?: string }>(await uploadImage(formData), {});
        if (!uploadData.url) throw new Error("No URL returned");
        await finishUrl(uploadData.url);
      } catch (error: unknown) {
        showToast(getErrorMessage(error, t("profile.avatarUpdateFailed")), "error");
      } finally {
        setUploading(false);
      }
    },
    [finishUrl, showToast, t],
  );

  const startUpload = useCallback(() => {
    if (Platform.OS === "web") {
      openWebPicker();
      return;
    }
    if (Platform.OS === "ios") {
      ActionSheetIOS.showActionSheetWithOptions(
        {
          options: [t("profile.cancel"), t("profile.takePhoto"), t("profile.chooseFromLibrary")],
          cancelButtonIndex: 0,
        },
        (idx) => {
          if (idx === 1) pickNative(true);
          else if (idx === 2) pickNative(false);
        },
      );
      return;
    }
    Alert.alert(t("profile.changeAvatar"), "", [
      { text: t("profile.takePhoto"), onPress: () => pickNative(true) },
      { text: t("profile.chooseFromLibrary"), onPress: () => pickNative(false) },
      { text: t("profile.cancel"), style: "cancel" },
    ]);
  }, [openWebPicker, pickNative, t]);

  const cropModal = createElement(头像裁剪弹窗, {
    visible: cropOpen,
    file: cropFile,
    uri: cropUri,
    title: t("profile.cropAvatarTitle"),
    hint: t("profile.cropAvatarHint"),
    cancelLabel: t("profile.cancel"),
    confirmLabel: t("profile.cropAvatarConfirm"),
    onCancel: () => {
      setCropOpen(false);
      setCropFile(null);
      setCropUri(null);
    },
    onConfirm: (blob: Blob) => {
      void uploadBlob(blob);
    },
    onError: (message: string) => showToast(message, "error"),
  });

  return { uploading, startUpload, openCrop, cropModal };
}
