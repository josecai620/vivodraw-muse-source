/** 纯客户端试玩收成 —— 不是真实账本写入（not a real ledger write）。 */
export type PracticeHarvestResult = {
  points: number;
  crop: string;
  message: string;
};

type CropRow = {
  crop: string;
  points: number;
  zh: string;
  en: string;
};

const crops: CropRow[] = [
  { crop: "小麥", points: 1, zh: "麥穗輕輕一晃，試玩積分 +1", en: "Wheat sways, demo +1" },
  { crop: "玉米", points: 2, zh: "金玉米落地，試玩積分 +2", en: "Golden corn, demo +2" },
  { crop: "番茄", points: 3, zh: "番茄紅透了，試玩積分 +3", en: "Ripe tomato, demo +3" },
  { crop: "草莓", points: 2, zh: "草莓香甜，試玩積分 +2", en: "Sweet berry, demo +2" },
];

export function rollPracticeHarvest(zh = true): PracticeHarvestResult {
  const pick = crops[Math.floor(Math.random() * crops.length)]!;
  return { crop: pick.crop, points: pick.points, message: zh ? pick.zh : pick.en };
}
