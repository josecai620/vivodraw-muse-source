import React, { useState, useMemo } from "react";
import { View, Text, FlatList, Pressable, ActivityIndicator, Image, ScrollView } from "react-native";
import { useRouter, Stack } from "expo-router";
import { useTranslation } from "react-i18next";
import { ClipboardList } from "lucide-react-native";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";
import { NextStepGuide } from "@/components/onboarding/PlayGuides";
import { useMyGroupLotteryRecords } from "@/hooks/useGroupLottery";

type TabKey = "all" | "progress" | "win" | "refund" | "cancel";

export default function MyGroupLotteryScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const [page] = useState(1);
  const [tab, setTab] = useState<TabKey>("all");
  const { data, isLoading } = useMyGroupLotteryRecords(page);
  const list = data?.data?.list ?? [];

  const STATUS_MAP: Record<number, { text: string; color: string; bg: string }> = {
    1: { text: t("groupLottery.memberJoined"),        color: "#04A8AE", bg: "#F3F5F3" },
    2: { text: t("groupLottery.memberWon"),           color: "#04A8AE", bg: "#F7F8F8" },
    3: { text: t("groupLottery.memberRefundedLost"),  color: "#9E9E9E", bg: "#f5f5f5" },
    4: { text: t("groupLottery.memberRefunded"),      color: "#9E9E9E", bg: "#f5f5f5" },
    5: { text: t("groupLottery.memberCancelPending"), color: "#04A8AE", bg: "#F7F8F8" },
    6: { text: t("groupLottery.memberCancelled"),     color: "#9E9E9E", bg: "#f5f5f5" },
    7: { text: t("groupLottery.memberShipped"),       color: "#04A8AE", bg: "#F7F8F8" },
    8: { text: t("groupLottery.memberRecycled"),      color: "#04A8AE", bg: "#ECFBFB" },
  };

  const TABS: { key: TabKey; label: string; match: (s: number) => boolean }[] = [
    { key: "all",      label: t("groupLottery.tabAll"),      match: () => true },
    { key: "progress", label: t("groupLottery.tabProgress"), match: (s) => s === 1 },
    { key: "win",      label: t("groupLottery.tabWon"),      match: (s) => s === 2 || s === 7 || s === 8 },
    { key: "refund",   label: t("groupLottery.tabRefund"),   match: (s) => s === 3 || s === 4 },
    { key: "cancel",   label: t("groupLottery.tabCancel"),   match: (s) => s === 5 || s === 6 },
  ];

  const filtered = useMemo(() => {
    const matcher = TABS.find((tb) => tb.key === tab)!.match;
    return list.filter((item: any) => matcher(Number(item.status)));
  }, [list, tab, TABS]);

  const pinkStatusLabel = (status: number) => {
    if (status === 2) return t("groupLottery.statusDrawn");
    if (status === 1) return t("groupLottery.statusActive");
    if (status === 3) return t("groupLottery.statusTimeout");
    return t("groupLottery.statusCancelled");
  };

  return (
    <View className="flex-1 bg-gray-50">
      <Stack.Screen options={{ headerShown: false }} />
      <PageHeader title={t("groupLottery.myGroups")} />

      <View style={{ backgroundColor: "#fff", borderBottomWidth: 1, borderBottomColor: "#f0f0f0" }}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: s(8) }}>
          {TABS.map((tb) => {
            const active = tab === tb.key;
            return (
              <Pressable
                key={tb.key}
                onPress={() => setTab(tb.key)}
                style={{ paddingVertical: s(10), paddingHorizontal: s(14), marginRight: s(2) }}
              >
                <Text
                  style={{
                    fontSize: s(13),
                    fontWeight: active ? "700" : "500",
                    color: active ? "#04A8AE" : Colors.neutral[600],
                  }}
                >
                  {tb.label}
                </Text>
                {active && (
                  <View style={{ height: s(2), backgroundColor: "#04A8AE", marginTop: s(4), borderRadius: 1 }} />
                )}
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      <NextStepGuide kind="groupRecords" />

      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color="#04A8AE" />
        </View>
      ) : filtered.length === 0 ? (
        <View className="flex-1 items-center justify-center">
          <ClipboardList size={s(44)} color={Colors.neutral[300]} strokeWidth={1.8} />
          <Text className="mt-3 text-gray-400" style={{ fontSize: s(14) }}>{t("common.noMore")}</Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item: any) => String(item.id)}
          contentContainerStyle={{ padding: s(12) }}
          renderItem={({ item }: { item: any }) => {
            const lottery = item.lottery || {};
            const pink = item.pink || {};
            const st = STATUS_MAP[item.status] || { text: t("common.unknown"), color: "#999", bg: "#f5f5f5" };
            const priceStr = item.price_type === 1
              ? `${item.paid_amount} ${t("common.pts")}`
              : `$${item.paid_amount}`;

            return (
              <Pressable
                onPress={() => router.push(`/group-lottery/pink/${item.pink_id}`)}
                style={{ backgroundColor: "#fff", borderRadius: s(10), marginBottom: s(8), padding: s(12), borderWidth: 1, borderColor: "#f0f0f0" }}
              >
                <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: s(6) }}>
                  <Text style={{ fontSize: s(11), color: Colors.neutral[400] }}>
                    {new Date(item.join_time * 1000).toLocaleDateString()} · {t("groupLottery.nPeopleGroup", { count: pink.people_count })} · {pinkStatusLabel(pink.status)}
                  </Text>
                  <View style={{ backgroundColor: st.bg, paddingHorizontal: s(8), paddingVertical: s(2), borderRadius: s(4) }}>
                    <Text style={{ fontSize: s(11), color: st.color, fontWeight: "600" }}>{st.text}</Text>
                  </View>
                </View>
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <Image source={{ uri: lottery.image }} style={{ width: s(50), height: s(50), borderRadius: s(6) }} />
                  <View style={{ flex: 1, marginLeft: s(10) }}>
                    <Text numberOfLines={1} style={{ fontSize: s(13), fontWeight: "600", color: Colors.neutral[800] }}>
                      {lottery.title || t("common.unknown")}
                    </Text>
                    <Text style={{ fontSize: s(12), color: "#04A8AE", marginTop: s(2) }}>{priceStr}</Text>
                    {item.refund_amount > 0 && (
                      <Text style={{ fontSize: s(11), color: "#04A8AE", marginTop: s(1) }}>
                        {item.price_type === 1
                          ? `${item.refund_amount} ${t("common.pts")}`
                          : `$${item.refund_amount}`}
                      </Text>
                    )}
                    {item.status === 7 && item.delivery_id ? (
                      <Text numberOfLines={1} style={{ fontSize: s(11), color: Colors.neutral[500], marginTop: s(1) }}>
                        🚚 {item.delivery_name} · {item.delivery_id}
                      </Text>
                    ) : null}
                  </View>
                </View>
              </Pressable>
            );
          }}
        />
      )}
    </View>
  );
}
