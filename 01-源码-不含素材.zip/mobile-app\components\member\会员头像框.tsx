import React, { useEffect, useMemo, useState } from "react";
import { Image as RNImage, Text, View } from "react-native";
import { resolveUserAvatarSource } from "@/lib/userAvatar";
import {
  MEMBER_FRAME_TIERS,
  MEMBER_TRIAL_SKIN,
  memberBadgeText,
  type MemberFrameLevel,
} from "@/lib/会员等级";
import {
  avatarFrameArtSize,
  resolveAvatarFrame,
  type AvatarFrameId,
} from "@/lib/会员头像框素材";
import { 会员SVGA播放 } from "@/components/member/会员SVGA播放";

export function 会员头像框({
  uri,
  uid,
  seed,
  level = 0,
  size = 76,
  showBadge = true,
  zh = true,
  trial = false,
  motion,
  frameId,
  faceRadius,
}: {
  uri?: string | null;
  uid?: number | null;
  seed?: string | number | null;
  level?: MemberFrameLevel;
  size?: number;
  showBadge?: boolean;
  zh?: boolean;
  trial?: boolean;
  motion?: boolean;
  frameId?: AvatarFrameId | string | null;
  faceRadius?: number;
}) {
  const tier =
    trial && level === 0
      ? MEMBER_TRIAL_SKIN
      : (MEMBER_FRAME_TIERS[level] ?? MEMBER_FRAME_TIERS[0]);
  const animated = motion ?? tier.motion;
  const frame = resolveAvatarFrame({ level, trial, frameId });
  const fallback = useMemo(() => resolveUserAvatarSource("", uid, seed), [uid, seed]);
  const resolved = useMemo(() => resolveUserAvatarSource(uri, uid, seed), [uri, uid, seed]);
  const [source, setSource] = useState(resolved);

  useEffect(() => {
    setSource(resolved);
  }, [resolved]);

  const face = size;
  const fill = face * 1.92;
  const offset = (face - fill) / 2;
  const radius = faceRadius ?? face / 2;

  const faceImage = (
    <RNImage
      source={source}
      onError={() => setSource(fallback)}
      resizeMode="cover"
      style={{
        position: "absolute",
        width: fill,
        height: fill,
        left: offset,
        top: offset - face * 0.04,
      }}
    />
  );

  const faceClip = (
    <View
      style={{
        width: face,
        height: face,
        borderRadius: radius,
        overflow: "hidden",
        backgroundColor: "#E5E7EB",
      }}
    >
      {faceImage}
    </View>
  );

  if (frame) {
    const art = avatarFrameArtSize(face, frame.holeRatio);
    const hole = face / art;
    return (
      <View
        style={{
          width: art,
          height: art + (showBadge ? 14 : 0),
          alignItems: "center",
          overflow: "visible",
        }}
      >
        <View
          style={{
            width: art,
            height: art,
            alignItems: "center",
            justifyContent: "center",
            overflow: "visible",
          }}
        >
          <View style={{ zIndex: 1 }}>{faceClip}</View>
          <View
            pointerEvents="none"
            style={{
              position: "absolute",
              left: 0,
              top: 0,
              right: 0,
              bottom: 0,
              zIndex: 2,
              overflow: "visible",
              filter: "drop-shadow(0 1px 2px rgba(15,23,42,0.28))" as unknown as undefined,
            }}
          >
            <会员SVGA播放
              source={frame.svga}
              still={frame.png}
              size={art}
              playing={animated}
              cutout={frame.opaqueHole ? hole : 0}
            />
          </View>
        </View>
        {showBadge ? (
          <View
            style={{
              marginTop: -10,
              zIndex: 4,
              paddingHorizontal: 8,
              paddingVertical: 2,
              borderRadius: 999,
              backgroundColor: tier.ring,
              minWidth: 64,
              alignItems: "center",
            }}
          >
            <Text style={{ color: "#fff", fontSize: 10, fontWeight: "800" }}>
              {memberBadgeText(level, zh, trial)}
            </Text>
          </View>
        ) : null}
      </View>
    );
  }

  const pad = Math.round(size * 0.18);
  const box = size + pad * 2;
  const ring = Math.max(3, Math.round(size * 0.045) + 1);

  return (
    <View style={{ width: box, height: box + (showBadge ? 14 : 0), alignItems: "center" }}>
      <View style={{ width: box, height: box, alignItems: "center", justifyContent: "center" }}>
        <View
          style={{
            width: face,
            height: face,
            borderRadius: radius,
            overflow: "hidden",
            borderWidth: ring,
            borderColor: tier.ring,
            backgroundColor: "#E5E7EB",
          }}
        >
          {faceImage}
        </View>
      </View>
      {showBadge ? (
        <View
          style={{
            marginTop: -10,
            zIndex: 4,
            paddingHorizontal: 8,
            paddingVertical: 2,
            borderRadius: 999,
            backgroundColor: tier.ring,
            minWidth: 64,
            alignItems: "center",
          }}
        >
          <Text style={{ color: "#fff", fontSize: 10, fontWeight: "800" }}>
            {memberBadgeText(level, zh, trial)}
          </Text>
        </View>
      ) : null}
    </View>
  );
}
