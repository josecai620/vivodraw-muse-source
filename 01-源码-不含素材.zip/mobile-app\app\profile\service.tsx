import React, { useEffect, useRef, useState } from "react";
import { ActivityIndicator, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { ImagePlus, MessageCircle, Send, X } from "lucide-react-native";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import * as ImagePicker from "expo-image-picker";
import { createSupportRequestId, getServiceRecord, getSupportImageBlob, getSupportSession, requestSupportHandoff, sendServiceMessage, sendSupportMessage, submitServiceFeedback, supportImageSource, SUPPORT_IMAGE_MAX_BYTES, SUPPORT_IMAGE_TYPES, updateSupportMemory, uploadSupportImage, type SupportLanguage, type SupportMessage, type SupportSend } from "@/lib/api/service";
import { SUPPORT_NAVIGATION, supportText } from "@/lib/客服文案";
import { Colors } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";
import { useAppStore } from "@/store/app";
import { useAuthStore } from "@/store/auth";

function PrivateImage({ id, uid, language }: { id: string; uid: number; language: SupportLanguage }) {
  const [source, setSource] = useState<{ uri: string; headers?: Record<string, string> }>();
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    let disposed = false;
    let objectUrl: string | undefined;
    const controller = new AbortController();
    setSource(undefined);
    setFailed(false);
    if (Platform.OS === "web") {
      getSupportImageBlob(id, controller.signal).then((blob) => {
        if (disposed) return;
        objectUrl = URL.createObjectURL(blob);
        setSource({ uri: objectUrl });
      }).catch(() => { if (!disposed) setFailed(true); });
    } else {
      try { setSource(supportImageSource(id)); } catch { setFailed(true); }
    }
    return () => { disposed = true; controller.abort(); if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [id, uid]);
  if (failed) return <Text style={styles.hint}>{supportText[language].imageFailed}</Text>;
  if (!source) return <ActivityIndicator color={Colors.brand.red} />;
  return <Image source={source} accessibilityLabel={supportText[language].imageOnly} style={styles.image} resizeMode="contain" onError={() => setFailed(true)} />;
}

function messageTime(value: string | number, language: SupportLanguage) {
  const numeric = Number(value);
  const date = new Date(Number.isFinite(numeric) && numeric > 0 ? (numeric < 1e12 ? numeric * 1000 : numeric) : value);
  return Number.isNaN(date.getTime()) ? "" : date.toLocaleString(language === "zh" ? "zh-CN" : "en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function ServiceScreen() {
  const { i18n } = useTranslation();
  const language: SupportLanguage = i18n.language.startsWith("zh") ? "zh" : "en";
  const words = supportText[language];
  const router = useRouter();
  const [message, setMessage] = useState("");
  const [attachmentId, setAttachmentId] = useState<string>();
  const [feedbackMode, setFeedbackMode] = useState(false);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [sendError, setSendError] = useState(false);
  const [forgetOpen, setForgetOpen] = useState(false);
  const sendLock = useRef(false);
  const uploadLock = useRef(false);
  const attempt = useRef<SupportSend | undefined>(undefined);
  const handoffId = useRef<string | undefined>(undefined);
  const scrollRef = useRef<ScrollView>(null);
  const nearBottom = useRef(true);
  const showToast = useAppStore((state) => state.showToast);
  const userUid = useAuthStore((state) => state.user?.uid ?? 0);
  const token = useAuthStore((state) => state.token);
  const queryClient = useQueryClient();
  const queryKey = ["supportSession", userUid];
  const session = useQuery({ queryKey, queryFn: getSupportSession, enabled: !!userUid && !!token, refetchInterval: 4000, retry: 1 });
  const enhanced = session.data?.available === true;
  const legacy = useQuery({ queryKey: ["serviceRecord", userUid], queryFn: () => getServiceRecord({ page: 1, limit: 200 }), enabled: !!userUid && !!token && session.data?.available === false, refetchInterval: 4000, retry: 1 });
  const authenticatedUid = useRef(userUid);
  authenticatedUid.current = userUid;

  useEffect(() => {
    setMessage(""); setAttachmentId(undefined); setSendError(false); setFeedbackMode(false); setForgetOpen(false); attempt.current = undefined; handoffId.current = undefined;
    return () => {
      queryClient.removeQueries({ queryKey: ["supportSession", userUid] });
      queryClient.removeQueries({ queryKey: ["serviceRecord", userUid] });
    };
  }, [userUid, queryClient]);

  const records: SupportMessage[] = enhanced ? session.data?.messages || [] : (legacy.data?.serviceList || []).map((record) => ({
    id: record.id, role: Number(record.uid) === Number(userUid) ? "user" : "human", content: record.msn_type === 3 ? words.imageOnly : record.msn, kind: "text", created_at: record._add_time || record.add_time,
  }));
  const error = session.isError || (!enhanced && legacy.isError);
  const loaded = session.data && (enhanced || legacy.data);
  const refresh = () => { session.refetch(); if (!enhanced) legacy.refetch(); };

  const send = async () => {
    if (sendLock.current || uploading || (!message.trim() && !attachmentId) || !loaded) return;
    sendLock.current = true; setBusy(true); setSendError(false);
    const uid = userUid;
    const content = message.trim();
    const kind = attachmentId ? "image" : feedbackMode ? "feedback" : "text";
    const detectedLanguage: SupportLanguage = /[\u3400-\u9fff]/.test(content) ? "zh" : /[a-zA-Z]/.test(content) ? "en" : language;
    if (!attempt.current || attempt.current.content !== content || attempt.current.attachment_id !== attachmentId || attempt.current.kind !== kind) {
      attempt.current = { content, kind, attachment_id: attachmentId, language: detectedLanguage, client_request_id: createSupportRequestId() };
    }
    try {
      if (enhanced) await sendSupportMessage(attempt.current);
      else if (feedbackMode) await submitServiceFeedback({ content });
      else await sendServiceMessage(content);
      if (authenticatedUid.current !== uid) return;
      setMessage(""); setAttachmentId(undefined); attempt.current = undefined;
      if (feedbackMode) showToast(words.feedbackSent, "success");
      nearBottom.current = true;
      await queryClient.invalidateQueries({ queryKey: [enhanced ? "supportSession" : "serviceRecord", uid] });
    } catch {
      if (authenticatedUid.current === uid) setSendError(true);
    } finally { sendLock.current = false; setBusy(false); }
  };

  const handoff = async () => {
    if (sendLock.current || !enhanced) return;
    sendLock.current = true; setBusy(true);
    const uid = userUid;
    try {
      handoffId.current ||= createSupportRequestId();
      await requestSupportHandoff({ client_request_id: handoffId.current, language });
      if (authenticatedUid.current !== uid) return;
      handoffId.current = undefined;
      await queryClient.invalidateQueries({ queryKey });
      showToast(words.handedOff, "success");
    } catch { if (authenticatedUid.current === uid) showToast(words.failed, "error"); }
    finally { sendLock.current = false; setBusy(false); }
  };

  const saveMemory = async (forget = false) => {
    if (sendLock.current || !enhanced) return;
    sendLock.current = true; setBusy(true);
    const uid = userUid;
    try {
      await updateSupportMemory({ enabled: forget ? false : !session.data?.memory?.enabled, language, forget });
      if (authenticatedUid.current !== uid) return;
      await queryClient.invalidateQueries({ queryKey }); setForgetOpen(false); showToast(words.saved, "success");
    } catch { if (authenticatedUid.current === uid) showToast(words.failed, "error"); }
    finally { sendLock.current = false; setBusy(false); }
  };

  const receiveImage = async (file: Blob | { uri: string; name: string; type: string }, name: string, mime: string, bytes?: number) => {
    if (uploadLock.current || !SUPPORT_IMAGE_TYPES.includes(mime) || !bytes || bytes > SUPPORT_IMAGE_MAX_BYTES) { showToast(words.imageInvalid, "error"); return; }
    uploadLock.current = true; setUploading(true);
    const uid = userUid;
    try { const id = await uploadSupportImage(file, name); if (authenticatedUid.current === uid) { setAttachmentId(id); setFeedbackMode(false); } }
    catch { if (authenticatedUid.current === uid) showToast(words.uploadFailed, "error"); }
    finally { uploadLock.current = false; setUploading(false); }
  };
  const pickImage = async () => {
    if (!enhanced || busy || uploading) return;
    if (Platform.OS === "web") {
      const input = document.createElement("input"); input.type = "file"; input.accept = SUPPORT_IMAGE_TYPES.join(","); input.multiple = false;
      input.onchange = () => { const file = input.files?.[0]; if (file) void receiveImage(file, file.name, file.type, file.size); };
      input.click();
    } else {
      try {
        const picked = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ["images"], allowsMultipleSelection: false, allowsEditing: false, quality: 1 });
        const asset = picked.canceled ? undefined : picked.assets[0];
        if (asset) await receiveImage({ uri: asset.uri, name: asset.fileName || "image", type: asset.mimeType || "" }, asset.fileName || "image", asset.mimeType || "", asset.fileSize);
      } catch { showToast(words.uploadFailed, "error"); }
    }
  };

  return <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined}>
    <PageHeader title={words.title} />
    {!userUid || !token ? <View style={styles.empty}><Text>{words.login}</Text><Pressable style={styles.action} onPress={() => router.push("/auth" as never)}><Text>{words.loginButton}</Text></Pressable></View> : <>
      <View style={styles.toolbar}>
        <Text style={styles.status}>{enhanced ? words[session.data?.mode === "pending" ? "pending" : session.data?.mode === "human" ? "humanMode" : "ai"] : words.legacy}</Text>
        {enhanced && session.data?.mode === "ai" && <Pressable style={styles.action} onPress={handoff} disabled={busy}><Text style={styles.link}>{words.handoff}</Text></Pressable>}
        <Pressable style={styles.action} onPress={refresh} disabled={session.isFetching || legacy.isFetching}><Text style={styles.link}>{words.refresh}</Text></Pressable>
      </View>
      {session.data?.available === false && <Text style={styles.notice}>{words.unavailable}</Text>}
      {error && <View style={styles.error}><Text style={styles.errorText}>{words.failed}</Text><Pressable onPress={refresh} style={styles.action}><Text style={styles.link}>{words.retry}</Text></Pressable></View>}
      {!loaded && !error ? <View style={styles.empty}><ActivityIndicator color={Colors.brand.red} accessibilityLabel={words.loading} /></View> : <ScrollView ref={scrollRef} style={styles.history} contentContainerStyle={styles.historyContent} keyboardShouldPersistTaps="handled" onScroll={(event) => { const e = event.nativeEvent; nearBottom.current = e.contentOffset.y + e.layoutMeasurement.height >= e.contentSize.height - 90; }} scrollEventThrottle={100} onContentSizeChange={() => { if (nearBottom.current) scrollRef.current?.scrollToEnd({ animated: false }); }}>
        {records.length === 0 && <View style={styles.empty}><MessageCircle size={32} color={Colors.neutral[500]} /><Text style={styles.emptyTitle}>{words.empty}</Text><Text style={styles.hint}>{words.intro}</Text></View>}
        {records.map((record) => <View key={record.id} style={[styles.bubble, record.role === "user" ? styles.mine : styles.theirs]}>
          <Text style={styles.sender}>{record.role === "user" ? words.me : record.role === "human" ? words.human : words.team}{record.kind === "feedback" ? " · " + words.feedback : ""}</Text>
          {record.kind === "image" && record.attachment_id && <PrivateImage key={userUid + ":" + record.attachment_id} id={record.attachment_id} uid={userUid} language={language} />}
          {!!record.content && <Text selectable style={styles.message}>{record.content}</Text>}
          {(record.navigation || []).filter((nav) => Object.prototype.hasOwnProperty.call(SUPPORT_NAVIGATION, nav.id)).map((nav) => {
            const id = nav.id as keyof typeof SUPPORT_NAVIGATION;
            return <Pressable key={id} style={styles.navButton} onPress={() => router.push(SUPPORT_NAVIGATION[id] as never)}><Text style={styles.link}>{words[id]} →</Text></Pressable>;
          })}
          <Text style={styles.time}>{messageTime(record.created_at, language)}</Text>
        </View>)}
      </ScrollView>}
      <View style={styles.composer}>
        {sendError && <View style={styles.controls}><Text accessibilityRole="alert" style={styles.errorText}>{enhanced ? words.sendFailed : words.legacyFailed}</Text><Pressable style={styles.action} disabled={busy || uploading} onPress={enhanced ? send : refresh}><Text style={styles.link}>{enhanced ? words.retry : words.refresh}</Text></Pressable></View>}
        {enhanced && <View style={styles.controls}>
          <Pressable style={styles.action} disabled={busy || uploading} onPress={pickImage} accessibilityLabel={words.image}><ImagePlus size={20} color={Colors.neutral[700]} /><Text style={styles.link}>{words.image}</Text></Pressable>
          <Pressable style={styles.action} disabled={busy} onPress={() => saveMemory()}><Text style={styles.link}>{session.data?.memory?.enabled ? words.memoryOn : words.memoryOff}</Text></Pressable>
          <Pressable style={styles.action} disabled={busy} onPress={() => setForgetOpen(!forgetOpen)}><Text style={styles.link}>{words.forget}</Text></Pressable>
        </View>}
        {enhanced && <Text style={styles.hint}>{words.imageHint}</Text>}
        {forgetOpen && <View style={styles.confirmBox}><Text>{words.forgetConfirm}</Text><Text style={styles.hint}>{words.forgetNote}</Text><Text style={styles.hint}>{words.memoryHint}</Text><View style={styles.controls}><Pressable style={styles.action} disabled={busy} onPress={() => saveMemory(true)}><Text style={styles.errorText}>{words.confirm}</Text></Pressable><Pressable style={styles.action} disabled={busy} onPress={() => setForgetOpen(false)}><Text>{words.cancel}</Text></Pressable></View></View>}
        {uploading && <Text style={styles.hint}>{words.uploadBusy}</Text>}
        {!!attachmentId && <View style={styles.controls}><Text style={styles.hint}>{words.selectedImage}</Text><Pressable style={styles.action} disabled={busy} onPress={() => setAttachmentId(undefined)} accessibilityLabel={words.removeImage}><X size={18} /></Pressable></View>}
        {feedbackMode && <Text style={styles.notice}>{words.feedbackMode}</Text>}
        <View style={styles.inputRow}>
          <TextInput style={styles.input} placeholder={words.placeholder} placeholderTextColor={Colors.neutral[500]} value={message} onChangeText={(text) => { setMessage(text); setSendError(false); }} editable={!busy && !!loaded} multiline maxLength={1000} accessibilityLabel={words.placeholder} />
          <Pressable style={[styles.send, (!loaded || (!message.trim() && !attachmentId) || busy || uploading) && styles.disabled]} disabled={!loaded || (!message.trim() && !attachmentId) || busy || uploading} accessibilityLabel={sendError ? words.retry : words.send} accessibilityRole="button" onPress={send}>
            {busy ? <ActivityIndicator color="#fff" /> : <Send size={20} color="#fff" />}
          </Pressable>
        </View>
        <Pressable style={styles.action} disabled={busy || !!attachmentId} onPress={() => setFeedbackMode(!feedbackMode)}><Text style={styles.hint}>{feedbackMode ? words.chatMode : words.feedback}</Text></Pressable>
      </View>
    </>}
  </KeyboardAvoidingView>;
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f7f8f8" }, toolbar: { paddingHorizontal: 16, minHeight: 48, flexDirection: "row", alignItems: "center", flexWrap: "wrap", borderBottomWidth: 1, borderBottomColor: "#e5e7eb", backgroundColor: "#fff" }, status: { flex: 1, fontSize: 13, color: "#44505a", minWidth: 110 }, action: { minHeight: 44, paddingHorizontal: 6, paddingVertical: 10, flexDirection: "row", gap: 6, alignItems: "center", justifyContent: "center" }, link: { color: "#006e73", fontSize: 13 }, hint: { color: "#59636c", fontSize: 12, lineHeight: 18 }, notice: { fontSize: 12, color: "#59636c", backgroundColor: "#eef2f2", padding: 10, lineHeight: 18 }, error: { paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, errorText: { fontSize: 13, color: "#ad2929", lineHeight: 19 }, history: { flex: 1 }, historyContent: { padding: 16, paddingBottom: 24 }, empty: { flex: 1, padding: 32, alignItems: "center", justifyContent: "center", gap: 12 }, emptyTitle: { fontSize: 18, fontWeight: "600", color: "#26333d" }, bubble: { maxWidth: "88%", padding: 12, borderRadius: 14, marginBottom: 12 }, mine: { backgroundColor: "#e0f2f1", alignSelf: "flex-end", borderBottomRightRadius: 4 }, theirs: { backgroundColor: "#fff", alignSelf: "flex-start", borderWidth: 1, borderColor: "#e3e8eb", borderBottomLeftRadius: 4 }, sender: { fontSize: 12, color: "#52616b", marginBottom: 5 }, message: { fontSize: 15, lineHeight: 23, color: "#1e2c35" }, time: { color: "#65737c", fontSize: 11, marginTop: 6 }, navButton: { borderWidth: 1, borderColor: "#bed4d4", borderRadius: 8, padding: 10, marginTop: 8, minHeight: 44 }, image: { width: 200, height: 180, maxWidth: "100%" }, composer: { paddingHorizontal: 12, paddingTop: 8, paddingBottom: 8, borderTopWidth: 1, borderTopColor: "#e1e5e8", backgroundColor: "#fff" }, controls: { flexDirection: "row", flexWrap: "wrap", alignItems: "center", gap: 8 }, inputRow: { flexDirection: "row", alignItems: "flex-end", gap: 8, marginTop: 8 }, input: { flex: 1, minHeight: 46, maxHeight: 130, borderWidth: 1, borderColor: "#cbd3d9", borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 15, color: "#1e2c35" }, send: { width: 46, height: 46, borderRadius: 12, alignItems: "center", justifyContent: "center", backgroundColor: "#007c80" }, disabled: { opacity: 0.45 }, confirmBox: { borderLeftWidth: 3, borderLeftColor: "#ad2929", padding: 10, backgroundColor: "#fff7f5", gap: 5 },
});
