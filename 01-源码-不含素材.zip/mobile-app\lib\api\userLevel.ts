import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

export function getUserLevelGrade() {
  return http.get(API_ENDPOINTS.user.level.grade);
}

export function getUserLevelInfo() {
  return http.get(API_ENDPOINTS.user.level.info);
}

export function getUserLevelExpList() {
  return http.get(API_ENDPOINTS.user.level.expList);
}

export function getMemberCardIndex() {
  return http.get(API_ENDPOINTS.user.memberCard.index);
}

export function drawMemberCard(data: {
  member_card_code: string;
  member_card_pwd: string;
  from?: string;
}) {
  return http.post(API_ENDPOINTS.user.memberCard.draw, {
    from: "h5",
    ...data,
  });
}

export function createMemberCardOrder(data: {
  member_type: string;
  vip_day: number;
  pay_type?: string;
  from?: string;
}) {
  return http.post(API_ENDPOINTS.user.memberCard.create, {
    from: "h5",
    pay_type: "balance",
    ...data,
  });
}

export function getMemberCoupons() {
  return http.get(API_ENDPOINTS.user.memberCard.coupons);
}
