import { useCallback, useEffect, useRef, useState } from "react";
import { useAuthStore } from "@/store/auth";
import { useFocusEffect } from "expo-router";
import { Linking } from "react-native";
import { startWalletRecharge } from "@/lib/api/walletRecharge";
import { fetchAuthPost } from "@/lib/api/legacyHttp";
import { getPointPurchaseState, type PointPurchaseState } from "@/lib/api/pointPurchase";
import { isGameWalletGame, type GameWalletGame } from "@/lib/api/gameWallet";
import { newPointPurchaseId } from "@/lib/game/pointPurchaseRecovery";
import { readRechargeContext, rechargeMinor, validRechargeOrder, withRechargeLock, type PendingRecharge, type RechargeRecoveryLock } from "@/lib/game/rechargeRecovery";
export { rechargeMinor } from "@/lib/game/rechargeRecovery";

type Params = { game?: string | string[]; pointPurchase?: string | string[]; order_id?: string | string[]; recharge?: string | string[] };
type Phase = "idle" | "checking" | "unconfirmed" | "open" | "paid" | "processing" | "expired" | "recovery_required";
function currentToken() {
  try {
    return useAuthStore.getState().token ?? "";
  } catch { return ""; }
}

/** success/cancelled 只触发核对；只有当前账号的服务端 paid 才解锁充值后购买。 */
export function useRechargeReturn(params: Params) {
  const requestedGame = params.pointPurchase === "1" && isGameWalletGame(params.game) ? params.game : null;
  const routeOrder = validRechargeOrder(params.order_id) ? params.order_id : null;
  const routeKey = `${requestedGame ?? ""}|${routeOrder ?? ""}|${params.recharge ?? ""}`;
  const routeRef = useRef(routeKey); routeRef.current = routeKey;
  const epoch = useRef(0), active = useRef(true), busy = useRef<symbol | null>(null), tokenRef = useRef<string | null>(null);
  const [token, setToken] = useState<string | null>(null), [authRevision, setAuthRevision] = useState(0);
  const [balance, setBalance] = useState<{ token: string; route: string; state: PointPurchaseState }>();
  // 静态wallet.html无查询参数；首屏与服务端保持一致，挂载后再读取游戏返回上下文。
  const [returnGame, setReturnGame] = useState<GameWalletGame | null>(null);
  const [pending, setPending] = useState<PendingRecharge | null>(null);
  const [loading, setLoading] = useState(false), [starting, setStarting] = useState(false);
  const [phase, setPhase] = useState<Phase>("idle"), [message, setMessage] = useState("");
  const [storageBlocked, setStorageBlocked] = useState(false), [ledgerRevision, setLedgerRevision] = useState(0);
  const latestRequest = useRef<PendingRecharge | null>(null);
  const automaticChecks = useRef(0), refreshRef = useRef<() => void>(() => {}), syncRef = useRef<() => void>(() => {});
  const live = (version: number, ownerToken: string) => active.current && epoch.current === version && routeRef.current === routeKey && currentToken() === ownerToken;

  const recoveryError = (error: unknown) => error instanceof Error && error.message === "request_lock_unavailable" ? "lock_unavailable"
    : error instanceof Error && (error.name === "AbortError" || error.message === "recharge_request_changed") ? "request_changed" : "storage";
  const recover = async (lock: RechargeRecoveryLock, request: PendingRecharge, ownerToken: string, version: number, openCheckout: boolean) => {
    if (!live(version, ownerToken)) return;
    lock.assertCurrent(request);
    const result = await startWalletRecharge(request);
    if (!live(version, ownerToken)) return;
    if (!result.ok || !result.data) { setPhase("unconfirmed"); setMessage("checkout_unconfirmed"); return; }
    const session = result.data;
    const bound = lock.bindOrder(request, session.order_id);
    latestRequest.current = bound;
    setPending(bound); setReturnGame(bound.game);
    if (session.recharge_status === "paid" || session.recharge_status === "expired") {
      if (!lock.clear(bound)) { setPhase("unconfirmed"); setMessage("checkout_unconfirmed"); return; }
      setPending(null);
    }
    if (session.recharge_status === "paid") {
      const updated = await getPointPurchaseState(bound.game ?? requestedGame ?? "mine");
      if (!live(version, ownerToken)) return;
      if (!updated.ok || updated.data?.account_id !== bound.account_id) { setPhase("unconfirmed"); setMessage("balance_unconfirmed"); return; }
      setBalance({ token: ownerToken, route: routeKey, state: updated.data }); setLedgerRevision(value => value + 1);
    }
    setPhase(session.recharge_status); setMessage(session.recharge_status);
    if (session.recharge_status === "open" && openCheckout && live(version, ownerToken)) {
      lock.assertCurrent(bound);
      try { await Linking.openURL(session.checkoutUrl); }
      catch { if (live(version, ownerToken)) setMessage("open_failed"); }
    }
  };

  const refresh = useCallback(async () => {
    if (!token || currentToken() !== token || !active.current || busy.current) return;
    const version = ++epoch.current, owner = Symbol("recharge-check"); busy.current = owner;
    setLoading(true); setMessage(""); setBalance(undefined); setPending(null); setReturnGame(requestedGame); setPhase("checking");
    try {
      const context = latestRequest.current ?? (routeOrder ? readRechargeContext(routeOrder) : null);
      const result = await getPointPurchaseState(context?.game ?? requestedGame ?? "mine");
      if (!live(version, token)) return;
      if (!result.ok || !result.data) { setMessage("load_failed"); setPhase("unconfirmed"); return; }
      const state = result.data;
      setBalance({ token, route: routeKey, state }); setLedgerRevision(value => value + 1); setStorageBlocked(false);
      if (context && context.account_id !== state.account_id) { setMessage("wrong_account"); setPhase("unconfirmed"); return; }
      const handled = await withRechargeLock(state.account_id, async lock => {
        if (!live(version, token)) return true;
        const saved = lock.readPending(), request = saved ?? context;
        if (request) {
          setPending(saved); setReturnGame(request.game);
          await recover(lock, request, token, version, false); return true;
        }
        if (lock.discardedInvalidAmount) { latestRequest.current = null; setPhase("idle"); setMessage("invalid_saved_amount"); return true; }
        return false;
      });
      if (!live(version, token)) return;
      if (handled) return;
      if (routeOrder) {
        // 兼容没有本机恢复指令的历史订单。此只读核对不能创建或再次支付订单。
        const checked = await fetchAuthPost<boolean>("/api/recharge/checkpay", { order_id: routeOrder });
        if (!live(version, token)) return;
        if (checked.ok && checked.data === true) {
          const updated = await getPointPurchaseState(requestedGame ?? "mine");
          if (!live(version, token)) return;
          if (updated.ok && updated.data?.account_id === state.account_id) {
            setBalance({ token, route: routeKey, state: updated.data }); setLedgerRevision(value => value + 1); setPhase("paid"); setMessage("paid");
          } else { setPhase("unconfirmed"); setMessage("balance_unconfirmed"); }
        } else { setPhase("unconfirmed"); setMessage("unconfirmed"); }
      } else setPhase("idle");
    } catch (error) { if (live(version, token)) { setStorageBlocked(true); setMessage(recoveryError(error)); setPhase("unconfirmed"); } }
    finally { if (busy.current === owner) { busy.current = null; setLoading(false); } }
  }, [token, routeKey, requestedGame, routeOrder]);
  refreshRef.current = () => { void refresh(); };

  useEffect(() => {
    const sync = () => {
      const next = currentToken();
      if (tokenRef.current === next) return;
      tokenRef.current = next; ++epoch.current; busy.current = null; latestRequest.current = null;
      setBalance(undefined); setPending(null); setPhase("idle"); setMessage(""); setStarting(false); setReturnGame(null); setLoading(false);
      setToken(next); setAuthRevision(value => value + 1); setLedgerRevision(value => value + 1);
    };
    syncRef.current = sync; sync();
    const focus = () => { sync(); refreshRef.current(); };
    if (typeof window === "undefined") return;
    window.addEventListener("storage", sync); const unsubAuth = useAuthStore.subscribe(sync); window.addEventListener("focus", focus);
    return () => { ++epoch.current; window.removeEventListener("storage", sync); unsubAuth(); window.removeEventListener("focus", focus); };
  }, []);
  useFocusEffect(useCallback(() => {
    active.current = true; syncRef.current(); refreshRef.current();
    return () => { active.current = false; ++epoch.current; busy.current = null; setStarting(false); setLoading(false); };
  }, []));
  useEffect(() => {
    ++epoch.current; busy.current = null; automaticChecks.current = 0; latestRequest.current = null;
    setBalance(undefined); setPending(null); setStarting(false); setLoading(false); setPhase("idle"); setMessage(""); setReturnGame(requestedGame); setStorageBlocked(false);
    if (token && active.current) void refresh();
    return () => { ++epoch.current; };
  }, [token, authRevision, routeKey, refresh]);
  useEffect(() => {
    if ((phase !== "processing" && message !== "unconfirmed") || loading || automaticChecks.current >= 4) return;
    automaticChecks.current += 1;
    const timer = setTimeout(() => { if (active.current) void refresh(); }, 3000);
    return () => clearTimeout(timer);
  }, [phase, message, loading, refresh]);

  const state = balance?.token === token && balance?.route === routeKey && currentToken() === token ? balance.state : undefined;
  const canRecharge = !!state?.recharge_available && !loading && !starting && !storageBlocked
    && message !== "wrong_account" && !["checking", "processing", "recovery_required"].includes(phase)
    && (!!pending || !routeOrder || phase === "paid" || phase === "expired");
  const start = async (amountText: string) => {
    if (!state || !token || !active.current || currentToken() !== token || busy.current || !canRecharge) return;
    const minor = rechargeMinor(amountText);
    if (!pending && (minor === null || minor < Math.max(50, state.min_recharge_minor))) { setMessage("invalid_amount"); return; }
    const owner = Symbol("recharge"), version = ++epoch.current;
    busy.current = owner; setStarting(true); setMessage("");
    try {
      // 在首次网络请求前保存；每个账号同时只恢复一笔未确认充值，跨游戏仍使用原单。
      await withRechargeLock(state.account_id, async lock => {
        if (!live(version, token)) return;
        const candidate = pending ?? { account_id: state.account_id, request_id: newPointPurchaseId(), amount_minor: minor!, game: returnGame, order_id: null };
        const request = lock.save(candidate); setPending(request); setReturnGame(request.game);
        if ((pending && request.request_id !== pending.request_id) || request.amount_minor !== candidate.amount_minor || request.game !== candidate.game) {
          setMessage("request_changed"); setPhase("unconfirmed"); return;
        }
        await recover(lock, request, token, version, true);
      });
    } catch (error) { if (live(version, token)) { setStorageBlocked(true); setMessage(recoveryError(error)); setPhase("unconfirmed"); } }
    finally { if (busy.current === owner) { busy.current = null; setStarting(false); } }
  };
  return { state, signedIn: !!token, ready: token !== null, returnGame, pending, loading, starting, phase, message,
    order: token === null ? null : pending?.order_id ?? latestRequest.current?.order_id ?? routeOrder, ledgerRevision, start, refresh, canRecharge,
    canReturnToPurchase: !loading && !starting && !pending && (phase === "paid" || (phase === "idle" && !routeOrder)) };
}
