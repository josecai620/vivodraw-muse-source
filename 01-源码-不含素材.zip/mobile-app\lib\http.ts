/**
 * HTTP 客户端 — 基于 Axios
 * 统一请求/响应拦截、Token 注入、错误处理
 */

import axios, { type AxiosError, type InternalAxiosRequestConfig } from "axios";
import { API_BASE_URL, API_TIMEOUT } from "@/constants/api";
import { useAuthStore } from "@/store/auth";

export class ApiError extends Error {
  data?: Record<string, unknown>;
  status?: number;
  constructor(msg: string, status?: number, data?: Record<string, unknown>) {
    super(msg);
    this.name = "ApiError";
    this.status = status;
    this.data = data;
  }
}

export const http = axios.create({
  baseURL: API_BASE_URL,
  timeout: API_TIMEOUT,
  headers: {
    "Content-Type": "application/json",
    "X-Client": "mobile-app", // 后端仅允许带此头的新前台访问，阻断旧 Uniapp
  },
});

http.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = useAuthStore.getState().token;
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  if (typeof FormData !== "undefined" && config.data instanceof FormData && config.headers) {
    delete (config.headers as Record<string, unknown>)["Content-Type"];
    delete (config.headers as Record<string, unknown>)["content-type"];
  }
  return config;
});

http.interceptors.response.use(
  (response) => {
    const data = response.data;
    if (data.status === 200) {
      return data;
    }
    const LOGIN_EXPIRED = [410000, 410001, 410002];
    if (LOGIN_EXPIRED.includes(data.status)) {
      useAuthStore.getState().logout();
    }
    const msg = data.msg || data.message || "Request failed";
    return Promise.reject(new ApiError(msg, data.status, data.data));
  },
  (error: AxiosError) => {
    if (error.response?.status === 401) {
      useAuthStore.getState().logout();
    }
    const msg =
      (error.response?.data as { msg?: string })?.msg ||
      error.message ||
      "Network error";
    return Promise.reject(new Error(msg));
  },
);

export type ApiResponse<T = unknown> = {
  status: number;
  msg: string;
  data: T;
};
