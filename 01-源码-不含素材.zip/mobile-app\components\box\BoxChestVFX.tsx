import React, { useEffect, useMemo } from "react";
import { View, type ImageSourcePropType, type ViewStyle } from "react-native";
import { Image } from "expo-image";
import Animated, {
  Easing,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
} from "react-native-reanimated";
import { Package } from "lucide-react-native";
import {
  BoxSurfaces,
  getRarityTier,
  bs,
} from "@/lib/boxTheme";

type ChestVFXDensity = "hero" | "compact";

interface BoxChestVFXProps {
  image?: ImageSourcePropType;
  tier?: string;
  size?: number;
  density?: ChestVFXDensity;
  style?: ViewStyle;
}

const PARTICLE_SEEDS = [
  { x: 13, y: 63, scale: 0.9, rotate: "-18deg" },
  { x: 23, y: 38, scale: 0.56, rotate: "14deg" },
  { x: 38, y: 27, scale: 0.7, rotate: "-8deg" },
  { x: 58, y: 25, scale: 0.5, rotate: "24deg" },
  { x: 74, y: 41, scale: 0.82, rotate: "-24deg" },
  { x: 85, y: 60, scale: 0.62, rotate: "12deg" },
  { x: 32, y: 78, scale: 0.56, rotate: "30deg" },
  { x: 66, y: 76, scale: 0.5, rotate: "-30deg" },
  { x: 20, y: 53, scale: 0.44, rotate: "48deg" },
  { x: 78, y: 72, scale: 0.42, rotate: "-52deg" },
];

export function BoxChestVFX({
  image,
  tier,
  size = 132,
  density = "hero",
  style,
}: BoxChestVFXProps) {
  const rarity = getRarityTier(tier || "legendary");
  const progress = useSharedValue(0);
  const particleCount = density === "hero" ? PARTICLE_SEEDS.length : 4;
  const stageSize = bs(size);
  const chestSize = Math.round(stageSize * (density === "hero" ? 0.82 : 0.9));
  const particles = useMemo(() => PARTICLE_SEEDS.slice(0, particleCount), [particleCount]);

  useEffect(() => {
    progress.value = withRepeat(
      withTiming(1, { duration: density === "hero" ? 2800 : 3400, easing: Easing.inOut(Easing.sin) }),
      -1,
      true
    );
  }, [density, progress]);

  const chestMotion = useAnimatedStyle(() => {
    const phase = progress.value * Math.PI * 2;
    return {
      transform: [
        { translateX: Math.sin(phase) * (density === "hero" ? 2.4 : 1.2) },
        { translateY: Math.cos(phase * 0.88) * (density === "hero" ? 1.2 : 0.6) },
        { rotate: `${Math.sin(phase * 0.74) * (density === "hero" ? 0.55 : 0.28)}deg` },
      ],
    };
  });

  const haloMotion = useAnimatedStyle(() => {
    const pulse = 0.96 + progress.value * 0.04;
    return {
      opacity: 0.42 + progress.value * 0.18,
      transform: [{ scale: pulse }],
    };
  });

  const sweepMotion = useAnimatedStyle(() => ({
    opacity: 0.08 + progress.value * 0.12,
    transform: [
      { translateX: (progress.value - 0.5) * stageSize * 0.82 },
      { rotate: "-18deg" },
    ],
  }));

  return (
    <View
      pointerEvents="none"
      style={[
        {
          width: stageSize,
          height: stageSize,
          alignItems: "center",
          justifyContent: "center",
          overflow: "visible",
        },
        style,
      ]}
    >
      <Animated.View
        style={[
          {
            position: "absolute",
            width: stageSize * 0.92,
            height: stageSize * 0.62,
            borderRadius: stageSize,
            backgroundColor: rarity.glow,
            shadowColor: rarity.color,
            shadowOpacity: density === "hero" ? 0.9 : 0.42,
            shadowRadius: density === "hero" ? 34 : 18,
            shadowOffset: { width: 0, height: 0 },
          },
          haloMotion,
        ]}
      />
      <View
        style={{
          position: "absolute",
          width: stageSize * 0.72,
          height: stageSize * 0.72,
          borderRadius: stageSize,
          borderWidth: 1,
          borderColor: rarity.borderColor,
          opacity: density === "hero" ? 0.46 : 0.24,
          transform: [{ rotate: "-12deg" }],
        }}
      />
      <View
        style={{
          position: "absolute",
          width: stageSize * 0.54,
          height: stageSize * 0.54,
          borderRadius: stageSize,
          borderWidth: 1,
          borderColor: "rgba(12,31,31,0.08)",
          opacity: density === "hero" ? 0.5 : 0.2,
          transform: [{ rotate: "18deg" }],
        }}
      />
      <View
        style={{
          position: "absolute",
          bottom: stageSize * 0.1,
          width: stageSize * 0.66,
          height: Math.max(7, stageSize * 0.09),
          borderRadius: stageSize,
          backgroundColor: "rgba(4,168,174,0.16)",
          opacity: 0.72,
        }}
      />
      {particles.map((particle, index) => (
        <View
          key={`${particle.x}-${index}`}
          style={{
            position: "absolute",
            left: `${particle.x}%`,
            top: `${particle.y}%`,
            width: Math.max(2, stageSize * 0.018 * particle.scale),
            height: Math.max(8, stageSize * 0.09 * particle.scale),
            borderRadius: stageSize,
            backgroundColor: index % 3 === 0 ? rarity.color : "#EBEEEE",
            opacity: density === "hero" ? 0.72 : 0.34,
            transform: [{ rotate: particle.rotate }],
          }}
        />
      ))}
      <Animated.View
        style={[
          {
            position: "absolute",
            width: stageSize * 0.09,
            height: stageSize * 0.62,
            borderRadius: stageSize,
            backgroundColor: "rgba(255,255,255,0.18)",
          },
          sweepMotion,
        ]}
      />
      <Animated.View
        style={[
          {
            width: chestSize,
            height: chestSize,
            alignItems: "center",
            justifyContent: "center",
          },
          chestMotion,
        ]}
      >
        {image ? (
          <Image
            source={image}
            style={{ width: chestSize, height: chestSize }}
            contentFit="contain"
            transition={120}
          />
        ) : (
          <View
            style={{
              width: chestSize * 0.66,
              height: chestSize * 0.66,
              borderRadius: chestSize,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: BoxSurfaces.deep,
              borderWidth: 1,
              borderColor: rarity.borderColor,
            }}
          >
            <Package size={chestSize * 0.34} color={rarity.color} />
          </View>
        )}
      </Animated.View>
    </View>
  );
}
