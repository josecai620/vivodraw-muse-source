// [已废弃] 改由 @/components/home-layout/HlNotice 替代
export default function DiyNewsDeprecated(): null { return null; }
