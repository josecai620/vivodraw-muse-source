/**
 * 积分揭晓主题系统（已并入全站「方向 C 轻立体·soft-UI」）
 * Reveal Color Scheme — unified to global white / teal system
 *
 * 两套方案均为：冷灰页面底 + 纯白浮卡 + 墨黑文字 + 唯一 teal 强调；
 * hero / 选中态 / 进度条使用 teal 渐变，原深色块上的白字依然成立。
 * 使用 SecureStore 持久化用户选择。
 */
import React, { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { getItem, setItem } from "@/lib/secure-storage";

const STORAGE_KEY = "revealColorScheme";

export interface RevealExtendedColors {
  primary: string;
  accent: string;
  accentGlow: string;
  background: string;
  cardBackground: string;
  headerGradient: string;
  cardGradient: string;
  text: string;
  textSecondary: string;
  border: string;
  progressBackground: string;
  gradientFrom: string;
  gradientTo: string;
}

// 标准方案：冷灰底 + 白卡 + teal 渐变强调
const MINIMAL_BLACK: RevealExtendedColors = {
  primary: "#04A8AE",
  accent: "#04A8AE",
  accentGlow: "#04A8AE",
  background: "#F5F7F7",
  cardBackground: "#FFFFFF",
  headerGradient: "linear-gradient(135deg, #0BB6BC, #078E93)",
  cardGradient: "linear-gradient(135deg, #FFFFFF, #F7F9F9)",
  text: "#171A1A",
  textSecondary: "#5E5F5E",
  border: "rgba(12,31,31,0.06)",
  progressBackground: "#EBEEEE",
  gradientFrom: "#0BB6BC",
  gradientTo: "#078E93",
};

// 柔和方案：同为冷灰底 + 白卡 + teal（差异仅在卡片渐变极轻微）
const MINIMAL_CREAM: RevealExtendedColors = {
  primary: "#04A8AE",
  accent: "#04A8AE",
  accentGlow: "#04A8AE",
  background: "#F5F7F7",
  cardBackground: "#FFFFFF",
  headerGradient: "linear-gradient(135deg, #08AEB4, #07858C)",
  cardGradient: "linear-gradient(135deg, #FFFFFF, #F6F8F8)",
  text: "#171A1A",
  textSecondary: "#5E5F5E",
  border: "rgba(12,31,31,0.06)",
  progressBackground: "#EBEEEE",
  gradientFrom: "#08AEB4",
  gradientTo: "#07858C",
};

export const revealColorSchemes: RevealExtendedColors[] = [MINIMAL_BLACK, MINIMAL_CREAM];

interface RevealColorSchemeContextType {
  currentSchemeIndex: number;
  setCurrentSchemeIndex: (index: number) => void;
  colors: RevealExtendedColors;
  isBlackTheme: boolean;
  toggleTheme: () => void;
}

const RevealColorSchemeContext = createContext<RevealColorSchemeContextType | undefined>(undefined);

export function RevealColorSchemeProvider({ children }: { children: ReactNode }) {
  const [currentSchemeIndex, setCurrentSchemeIndex] = useState(0);

  useEffect(() => {
    getItem(STORAGE_KEY).then((saved) => {
      if (saved !== null) {
        const idx = Number.parseInt(saved, 10);
        if (idx === 0 || idx === 1) setCurrentSchemeIndex(idx);
      }
    });
  }, []);

  useEffect(() => {
    setItem(STORAGE_KEY, currentSchemeIndex.toString()).catch(() => {});
  }, [currentSchemeIndex]);

  const colors = revealColorSchemes[currentSchemeIndex];
  const isBlackTheme = currentSchemeIndex === 0;

  const toggleTheme = () => {
    setCurrentSchemeIndex(isBlackTheme ? 1 : 0);
  };

  return (
    <RevealColorSchemeContext.Provider
      value={{
        currentSchemeIndex,
        setCurrentSchemeIndex,
        colors,
        isBlackTheme,
        toggleTheme,
      }}
    >
      {children}
    </RevealColorSchemeContext.Provider>
  );
}

export function useRevealColorScheme() {
  const context = useContext(RevealColorSchemeContext);
  if (context === undefined) {
    throw new Error("useRevealColorScheme must be used within a RevealColorSchemeProvider");
  }
  return context;
}
