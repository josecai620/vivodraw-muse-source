import React from "react";
import { Text, View } from "react-native";
import { Colors } from "@/constants/theme";
import { pickLang } from "./utils";

interface HlRichTextProps {
  props: {
    content?: { en?: string; zh?: string } | string;
    align?: "left" | "center" | "right";
  };
  lang: string;
}

export default function HlRichText({ props, lang }: HlRichTextProps) {
  const content = pickLang(props.content, lang);
  if (!content) return null;
  return (
    <View className="px-4 py-3 bg-white mt-2">
      <Text style={{ color: Colors.neutral[700], fontSize: 13, textAlign: props.align || "left", lineHeight: 20 }}>
        {content}
      </Text>
    </View>
  );
}
