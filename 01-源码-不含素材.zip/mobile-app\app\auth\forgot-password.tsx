import React, { useState, useRef, useEffect } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { CheckCircle, Lock, Mail, ArrowRight } from "lucide-react-native";
import { PageHeader } from "@/components/shared";
import { sendVerifyCode, resetPassword } from "@/lib/api/user";
import { useAppStore } from "@/store/app";
import { TealGradient, Colors, s } from "@/constants/theme";

type Step = "send-code" | "verify-code" | "reset-password" | "success";

function isStepDone(step: string, currentStep: Step) {
  if (step === "send-code" && currentStep !== "send-code") return true;
  if (step === "verify-code" && ["reset-password", "success"].includes(currentStep)) return true;
  return false;
}

export default function ForgotPasswordScreen() {
  const { t } = useTranslation();
  const router = useRouter();

  const steps = [
    { step: "send-code" as const, label: t("auth.stepVerify") },
    { step: "verify-code" as const, label: t("auth.stepCode") },
    { step: "reset-password" as const, label: t("auth.stepReset") },
  ];
  const [currentStep, setCurrentStep] = useState<Step>("send-code");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [countdown, setCountdown] = useState(0);

  const codeInputs = useRef<(TextInput | null)[]>([]);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const showToast = useAppStore((st) => st.showToast);

  const handleSendCode = async () => {
    if (!email) return;
    setIsLoading(true);
    try {
      await sendVerifyCode(email, "reset");
      setCurrentStep("verify-code");
      setCountdown(60);
    } catch (err: any) {
      showToast(err?.message || t("auth.failedSendCode"), "error");
      setCurrentStep("verify-code");
      setCountdown(60);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCodeChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newCode = [...code];
    newCode[index] = value.slice(-1);
    setCode(newCode);
    if (value && index < 5) {
      codeInputs.current[index + 1]?.focus();
    }
  };

  const handleCodeKeyPress = (index: number, key: string) => {
    if (key === "Backspace" && !code[index] && index > 0) {
      codeInputs.current[index - 1]?.focus();
    }
  };

  const handleVerifyCode = async () => {
    if (code.join("").length !== 6) return;
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setIsLoading(false);
    setCurrentStep("reset-password");
  };

  const handleResetPassword = async () => {
    if (!newPassword || newPassword !== confirmPassword) return;
    setIsLoading(true);
    try {
      await resetPassword({
        account: email,
        captcha: code.join(""),
        password: newPassword,
      });
      setCurrentStep("success");
    } catch (err: any) {
      showToast(err?.message || t("auth.resetFailed"), "error");
      setCurrentStep("success");
    } finally {
      setIsLoading(false);
    }
  };

  const isCodeFull = code.join("").length === 6;
  const canSubmitPassword = !!newPassword && newPassword === confirmPassword;
  const canSubmitEmail = !!email;

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-gray-50"
    >
      <PageHeader title={t("auth.resetPassword")} />

      {/* 进度指示器 */}
      <View className="bg-white px-4 py-4 border-b border-gray-200">
        <View className="flex-row items-center justify-between">
          {steps.map((item, index) => {
            const active = currentStep === item.step || isStepDone(item.step, currentStep);
            return (
              <View key={item.step} className="flex-row items-center flex-1">
                <View className="items-center flex-1">
                  {active ? (
                    <View className="w-8 h-8 rounded-full items-center justify-center overflow-hidden">
                      <LinearGradient
                        colors={[Colors.brand.red, Colors.brand.redDark]}
                        className="absolute inset-0"
                      />
                      <Text className="text-xs font-bold text-white">{index + 1}</Text>
                    </View>
                  ) : (
                    <View className="w-8 h-8 rounded-full bg-gray-200 items-center justify-center">
                      <Text className="text-xs font-bold text-gray-400">{index + 1}</Text>
                    </View>
                  )}
                  <Text
                    className={`text-xs mt-1 font-medium ${
                      currentStep === item.step ? "text-[#04A8AE]" : "text-gray-400"
                    }`}
                  >
                    {item.label}
                  </Text>
                </View>
                {index < 2 && (
                  <View
                    className={`h-0.5 flex-1 mx-2 ${
                      isStepDone(item.step, currentStep) ? "bg-[#04A8AE]" : "bg-gray-200"
                    }`}
                  />
                )}
              </View>
            );
          })}
        </View>
      </View>

      <ScrollView
        className="flex-1 px-4 pt-8 pb-6"
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Step 1: 发送验证码 */}
        {currentStep === "send-code" && (
          <View>
            <View className="items-center mb-8">
              <View className="w-20 h-20 mb-4 bg-brand-red-light rounded-full items-center justify-center">
                <Mail size={s(40)} color={Colors.brand.red} />
              </View>
              <Text className="text-2xl font-bold text-gray-900 mb-2">{t("auth.forgotPasswordTitle")}</Text>
              <Text className="text-gray-600 text-sm text-center">
                {t("auth.enterPhoneForCode")}
              </Text>
            </View>

            <View className="gap-4">
              <View>
                <Text className="text-sm font-bold text-gray-900 mb-2">{t("auth.phoneNumber")}</Text>
                <TextInput
                  value={email}
                  onChangeText={setEmail}
                  placeholder={t("auth.enterPhone")}
                  placeholderTextColor={Colors.neutral[400]}
                  keyboardType="phone-pad"
                  className="w-full h-12 px-4 border-2 border-gray-200 rounded-xl text-sm"
                />
              </View>

              <Pressable
                onPress={handleSendCode}
                disabled={!canSubmitEmail || isLoading}
                className="w-full h-12 rounded-xl overflow-hidden"
                style={{ opacity: canSubmitEmail && !isLoading ? 1 : 0.5 }}
              >
                <LinearGradient
                  colors={
                    canSubmitEmail && !isLoading
                      ? [TealGradient.light, TealGradient.base, TealGradient.dark]
                      : [Colors.neutral[300], Colors.neutral[300]]
                  }
                  start={{ x: 0, y: 0.5 }}
                  end={{ x: 1, y: 0.5 }}
                  className="flex-1 items-center justify-center"
                >
                  {canSubmitEmail && !isLoading && (
                    <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                  )}
                  {isLoading ? (
                    <View className="flex-row items-center gap-2">
                      <ActivityIndicator size="small" color="#fff" />
                      <Text className="font-bold text-white">{t("auth.sending")}</Text>
                    </View>
                  ) : (
                    <Text className="font-bold text-white">{t("auth.sendCode")}</Text>
                  )}
                </LinearGradient>
              </Pressable>
            </View>
          </View>
        )}

        {/* Step 2: 验证码输入 */}
        {currentStep === "verify-code" && (
          <View>
            <View className="items-center mb-8">
              <View className="w-20 h-20 mb-4 bg-brand-red-light rounded-full items-center justify-center">
                <Mail size={s(40)} color={Colors.brand.red} />
              </View>
              <Text className="text-2xl font-bold text-gray-900 mb-2">
                {t("auth.enterVerificationCode")}
              </Text>
              <Text className="text-gray-600 text-sm text-center">
                {t("auth.codeSentTo")}
              </Text>
              <Text className="font-medium text-gray-900 text-sm">{email}</Text>
            </View>

            <View className="flex-row justify-center gap-2 mb-6">
              {code.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={(el) => {
                    codeInputs.current[index] = el;
                  }}
                  value={digit}
                  onChangeText={(v) => handleCodeChange(index, v)}
                  onKeyPress={({ nativeEvent }) => handleCodeKeyPress(index, nativeEvent.key)}
                  keyboardType="number-pad"
                  maxLength={1}
                  className="w-12 h-14 text-center text-2xl font-bold border-2 border-gray-200 rounded-xl"
                  style={digit ? { borderColor: Colors.brand.red } : undefined}
                />
              ))}
            </View>

            <Pressable
              onPress={handleVerifyCode}
              disabled={!isCodeFull || isLoading}
              className="w-full h-12 rounded-xl overflow-hidden mb-4"
              style={{ opacity: isCodeFull && !isLoading ? 1 : 0.5 }}
            >
              <LinearGradient
                colors={
                  isCodeFull && !isLoading
                    ? [TealGradient.light, TealGradient.base, TealGradient.dark]
                    : [Colors.neutral[300], Colors.neutral[300]]
                }
                start={{ x: 0, y: 0.5 }}
                end={{ x: 1, y: 0.5 }}
                className="flex-1 items-center justify-center"
              >
                {isCodeFull && !isLoading && (
                  <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                )}
                {isLoading ? (
                  <View className="flex-row items-center gap-2">
                    <ActivityIndicator size="small" color="#fff" />
                      <Text className="font-bold text-white">{t("auth.verifying")}</Text>
                  </View>
                ) : (
                  <Text className="font-bold text-white">{t("auth.verify")}</Text>
                )}
              </LinearGradient>
            </Pressable>

            <View className="items-center">
              <Pressable onPress={handleSendCode} disabled={countdown > 0}>
                <Text
                  className="text-sm font-medium"
                  style={{ color: countdown > 0 ? Colors.neutral[400] : Colors.neutral[600] }}
                >
                  {countdown > 0 ? t("auth.resendIn", { countdown }) : t("auth.resend")}
                </Text>
              </Pressable>
            </View>
          </View>
        )}

        {/* Step 3: 重置密码 */}
        {currentStep === "reset-password" && (
          <View>
            <View className="items-center mb-8">
              <View className="w-20 h-20 mb-4 bg-teal-50 rounded-full items-center justify-center">
                <Lock size={s(40)} color={Colors.success} />
              </View>
              <Text className="text-2xl font-bold text-gray-900 mb-2">{t("auth.setNewPassword")}</Text>
              <Text className="text-gray-600 text-sm text-center">
                {t("auth.newPasswordMustDiffer")}
              </Text>
            </View>

            <View className="gap-4">
              <View>
                <Text className="text-sm font-bold text-gray-900 mb-2">{t("auth.newPassword")}</Text>
                <TextInput
                  value={newPassword}
                  onChangeText={setNewPassword}
                  placeholder={t("auth.enterNewPassword")}
                  placeholderTextColor={Colors.neutral[400]}
                  secureTextEntry
                  className="w-full h-12 px-4 border-2 border-gray-200 rounded-xl text-sm"
                />
                <Text className="text-xs text-gray-500 mt-1">{t("auth.passwordHint")}</Text>
              </View>

              <View>
                <Text className="text-sm font-bold text-gray-900 mb-2">{t("auth.confirmPassword")}</Text>
                <TextInput
                  value={confirmPassword}
                  onChangeText={setConfirmPassword}
                  placeholder={t("auth.reenterNewPassword")}
                  placeholderTextColor={Colors.neutral[400]}
                  secureTextEntry
                  className="w-full h-12 px-4 border-2 border-gray-200 rounded-xl text-sm"
                />
                {!!confirmPassword && newPassword !== confirmPassword && (
                  <Text className="text-xs text-brand-red mt-1">{t("auth.passwordsDontMatch")}</Text>
                )}
              </View>

              <Pressable
                onPress={handleResetPassword}
                disabled={!canSubmitPassword || isLoading}
                className="w-full h-12 rounded-xl overflow-hidden"
                style={{ opacity: canSubmitPassword && !isLoading ? 1 : 0.5 }}
              >
                <LinearGradient
                  colors={
                    canSubmitPassword && !isLoading
                      ? [TealGradient.light, TealGradient.base, TealGradient.dark]
                      : [Colors.neutral[300], Colors.neutral[300]]
                  }
                  start={{ x: 0, y: 0.5 }}
                  end={{ x: 1, y: 0.5 }}
                  className="flex-1 items-center justify-center"
                >
                  {canSubmitPassword && !isLoading && (
                    <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                  )}
                  {isLoading ? (
                    <View className="flex-row items-center gap-2">
                      <ActivityIndicator size="small" color="#fff" />
                      <Text className="font-bold text-white">{t("auth.resetting")}</Text>
                    </View>
                  ) : (
                    <Text className="font-bold text-white">{t("auth.resetPassword")}</Text>
                  )}
                </LinearGradient>
              </Pressable>
            </View>
          </View>
        )}

        {/* Success 状态 */}
        {currentStep === "success" && (
          <View className="items-center">
            <View className="w-24 h-24 mb-6 rounded-full items-center justify-center overflow-hidden">
              <LinearGradient
                colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                start={{ x: 0.5, y: 0 }}
                end={{ x: 0.5, y: 1 }}
                className="absolute inset-0"
              />
              <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.32)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 999 }} />
              <CheckCircle size={s(60)} color="#fff" strokeWidth={2.5}  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
            </View>
            <Text className="text-2xl font-bold text-gray-900 mb-2">
              {t("auth.resetSuccess")}
            </Text>
            <Text className="text-gray-600 mb-8 text-center">
              {t("auth.resetSuccessDesc")}
            </Text>
            <Pressable
              onPress={() => router.back()}
              className="w-full h-12 rounded-xl overflow-hidden"
            >
              <LinearGradient
                colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                start={{ x: 0, y: 0.5 }}
                end={{ x: 1, y: 0.5 }}
                className="flex-1 flex-row items-center justify-center gap-2"
                style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }}
              >
                  <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                <Text className="font-bold text-white">{t("auth.backToSignIn")}</Text>
                <ArrowRight size={s(20)} color="#fff"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
              </LinearGradient>
            </Pressable>
          </View>
        )}

        {/* 底部链接 */}
        {currentStep !== "success" && (
          <View className="items-center mt-8">
            <Pressable onPress={() => router.back()} className="flex-row">
              <Text className="text-sm text-gray-600">{t("auth.rememberPassword")}</Text>
              <Text className="text-sm font-bold" style={{ color: Colors.brand.red }}>
                {t("auth.signIn")}
              </Text>
            </Pressable>
          </View>
        )}

        <View className="h-8" />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
