export type VFXRarity = 'common' | 'rare' | 'epic' | 'legendary' | 'fire';

export type VFXState = 'idle' | 'trigger' | 'explode' | 'cooldown';

export interface GlowEffectConfig {
  enabled: boolean; // enabled：是否启用发光
  glowColor: number; // glowColor：发光颜色
  glowStrength: number; // glowStrength：发光强度
  glowSpeed: number; // glowSpeed：发光速度
}

export interface FlowLightEffectConfig {
  enabled: boolean; // enabled：是否启用流光
  flowColor: number; // flowColor：流光颜色
  flowSpeed: number; // flowSpeed：流光速度
  sweepSpeed: number; // sweepSpeed：扫光速度
}

export interface EnergyWaveEffectConfig {
  enabled: boolean; // enabled：是否启用能量波
  energyColor: number; // energyColor：能量波颜色
  energyWaveSize: number; // energyWaveSize：能量波尺寸
  energyWaveStrength: number; // energyWaveStrength：能量波强度
}

export interface ExplosionEffectConfig {
  enabled: boolean; // enabled：是否启用爆闪
  explosionStrength: number; // explosionStrength：爆闪强度
  explosionDuration: number; // explosionDuration：爆闪持续时间
}

export interface FireEffectConfig {
  enabled: boolean; // enabled：是否启用火焰
  fireIntensity: number; // fireIntensity：火焰强度
  fireSpeed: number; // fireSpeed：火焰速度
}

export interface SparkEffectConfig {
  enabled: boolean; // enabled：是否启用粒子
  particleColor: number; // particleColor：粒子颜色
  particleCount: number; // particleCount：粒子数量
  particleSize: number; // particleSize：粒子大小
}

export interface VFXPresetConfig {
  id: VFXRarity; // id：预设 ID
  label: string; // label：预设显示名
  glow: GlowEffectConfig; // glow：发光配置
  flow: FlowLightEffectConfig; // flow：流光配置
  energy: EnergyWaveEffectConfig; // energy：能量波配置
  explosion: ExplosionEffectConfig; // explosion：爆闪配置
  fire: FireEffectConfig; // fire：火焰配置
  spark: SparkEffectConfig; // spark：粒子配置
}

export interface VFXPresetPatch {
  id?: VFXRarity; // id：可选预设 ID
  label?: string; // label：可选显示名
  glow?: Partial<GlowEffectConfig>; // glow：可选发光补丁
  flow?: Partial<FlowLightEffectConfig>; // flow：可选流光补丁
  energy?: Partial<EnergyWaveEffectConfig>; // energy：可选能量波补丁
  explosion?: Partial<ExplosionEffectConfig>; // explosion：可选爆闪补丁
  fire?: Partial<FireEffectConfig>; // fire：可选火焰补丁
  spark?: Partial<SparkEffectConfig>; // spark：可选粒子补丁
}

export interface RuntimeVFXConfig {
  glowIntensity: number; // glowIntensity：运行时发光强度
  glowSpeed: number; // glowSpeed：运行时发光速度
  glowColor: number; // glowColor：运行时发光颜色
  flowColor: number; // flowColor：运行时流光颜色
  particleColor: number; // particleColor：运行时粒子颜色
  particleSize: number; // particleSize：运行时粒子大小
  fireSpeed: number; // fireSpeed：运行时火焰速度
  energyWaveSize: number; // energyWaveSize：运行时能量波大小
  explosionStrength: number; // explosionStrength：运行时爆闪强度
  edgeSpeed: number; // edgeSpeed：运行时边缘流光速度
  edgeCount: number; // edgeCount：运行时流光数量
  sweepSpeed: number; // sweepSpeed：运行时扫光速度
  sparkCount: number; // sparkCount：运行时粒子数量
  flamePower: number; // flamePower：运行时火焰强度
  rippleColor: number; // rippleColor：运行时能量波颜色
}

export const mergeVFXConfig = (base: VFXPresetConfig, patch: VFXPresetPatch): VFXPresetConfig => ({ // mergeVFXConfig：合并预设配置
  ...base,
  ...patch,
  glow: { ...base.glow, ...patch.glow },
  flow: { ...base.flow, ...patch.flow },
  energy: { ...base.energy, ...patch.energy },
  explosion: { ...base.explosion, ...patch.explosion },
  fire: { ...base.fire, ...patch.fire },
  spark: { ...base.spark, ...patch.spark },
});

export const toRuntimeVFXConfig = (preset: VFXPresetConfig): RuntimeVFXConfig => ({ // toRuntimeVFXConfig：转成当前 OreVFX 运行时参数
  glowIntensity: preset.glow.enabled ? preset.glow.glowStrength : 0,
  glowSpeed: preset.glow.glowSpeed,
  glowColor: preset.glow.glowColor,
  flowColor: preset.flow.flowColor,
  particleColor: preset.spark.particleColor,
  particleSize: preset.spark.particleSize,
  fireSpeed: preset.fire.fireSpeed,
  energyWaveSize: preset.energy.enabled ? preset.energy.energyWaveSize : 0,
  explosionStrength: preset.explosion.enabled ? preset.explosion.explosionStrength : 0,
  edgeSpeed: preset.flow.enabled ? preset.flow.flowSpeed : 0,
  edgeCount: preset.flow.enabled ? Math.max(6, Math.round(10 + preset.energy.energyWaveStrength * 8)) : 0,
  sweepSpeed: preset.flow.enabled ? preset.flow.sweepSpeed : 0,
  sparkCount: preset.spark.enabled ? preset.spark.particleCount : 0,
  flamePower: preset.fire.enabled ? preset.fire.fireIntensity : 0,
  rippleColor: preset.energy.energyColor,
});
