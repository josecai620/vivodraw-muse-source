import React from "react";
import { Text, View } from "react-native";
import { useRouter } from "expo-router";
import { Pressable } from "react-native";
import { Compass, Home } from "lucide-react-native";
import { Colors, s, Shadows } from "@/constants/theme";
import TealSurface from "@/components/ui/TealSurface";
import { useSafeAreaInsets } from "react-native-safe-area-context";

/**
 * 全局未匹配路由兜底页（方向 C 轻立体 soft-UI）
 * 替换 Expo Router 内置的深色 Unmatched Route，保持全站白底 + teal 一致。
 */
export default function NotFoundScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: Colors.screen.bg,
        paddingTop: insets.top,
        paddingBottom: insets.bottom,
        paddingHorizontal: s(24),
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <View
        style={[
          {
            width: "100%",
            backgroundColor: "#FFFFFF",
            borderRadius: s(28),
            borderWidth: 1,
            borderColor: Colors.screen.hairline,
            paddingVertical: s(40),
            paddingHorizontal: s(24),
            alignItems: "center",
          },
          Shadows.raised,
        ]}
      >
        <View
          style={{
            width: s(76),
            height: s(76),
            borderRadius: s(22),
            backgroundColor: Colors.primary.softer,
            alignItems: "center",
            justifyContent: "center",
            marginBottom: s(20),
          }}
        >
          <Compass size={s(34)} color={Colors.primary.DEFAULT} strokeWidth={2} />
        </View>

        <Text
          style={{
            color: Colors.neutral[900],
            fontSize: s(22),
            fontWeight: "800",
            marginBottom: s(8),
            textAlign: "center",
          }}
        >
          Page not found
        </Text>
        <Text
          style={{
            color: Colors.neutral[500],
            fontSize: s(14),
            lineHeight: s(21),
            textAlign: "center",
            marginBottom: s(28),
            paddingHorizontal: s(12),
          }}
        >
          The page you're looking for doesn't exist or has been moved.
        </Text>

        <Pressable
          onPress={() => router.replace("/(tabs)")}
          style={({ pressed }) => [
            Shadows.teal,
            { width: "100%", transform: [{ scale: pressed ? 0.97 : 1 }] },
          ]}
        >
          <TealSurface
            direction="lr"
            radius={14}
            style={{ width: "100%" }}
            contentStyle={{
              height: s(50),
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: s(8),
            }}
          >
            <Home size={s(19)} color="#FFFFFF" />
            <Text style={{ color: "#FFFFFF", fontSize: s(15), fontWeight: "700", backgroundColor: "transparent" }}>
              Back to Home
            </Text>
          </TealSurface>
        </Pressable>
      </View>
    </View>
  );
}
