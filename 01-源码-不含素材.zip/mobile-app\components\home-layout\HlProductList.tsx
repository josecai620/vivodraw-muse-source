import { ChevronRight } from "lucide-react-native";
import React, { useEffect, useRef, useState } from "react";
import { AccessibilityInfo, Platform, ScrollView, Text, View, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { useGroomList } from "@/hooks";
import { ProductCard } from "@/components/shared";
import { Colors, s } from "@/constants/theme";
import { pickLang } from "./utils";

interface HlProductListProps {
  props: {
    title?: { en?: string; zh?: string } | string;
    source?: "hot" | "new" | "recommend" | "manual";
    layout?: "horizontal" | "grid";
    limit?: number;
    productIds?: number[];
  };
  lang: string;
}

// source → backend groom type
// CRMEB groom_list type: 1=精品推荐 2=热门榜单 3=首发新品 4=促销单品
const SOURCE_TO_GROOM: Record<string, number> = {
  recommend: 1,
  hot: 2,
  new: 3,
};

export default function HlProductList({ props, lang }: HlProductListProps) {
  const router = useRouter();
  const type = SOURCE_TO_GROOM[props.source || "hot"] ?? 2;
  const { data } = useGroomList(type);
  const items: any[] = Array.isArray(data)
    ? data
    : (data as any)?.data?.list ?? (data as any)?.list ?? [];

  const limit = Math.max(1, props.limit || 10);
  const title = pickLang(props.title, lang);
  const layout = props.layout || "horizontal";
  const list = items.slice(0, limit);
  const scrollRef = useRef<ScrollView>(null);
  const offsetRef = useRef(0);
  const contentWidthRef = useRef(0);
  const viewportWidthRef = useRef(0);
  const directionRef = useRef(1);
  const autoPositionRef = useRef(0);
  const lastPaintedPixelRef = useRef(-1);
  const interactingRef = useRef(false);
  const dragAxisRef = useRef<"x" | "y" | null>(null);
  const touchStartRef = useRef({ x: 0, y: 0, offset: 0 });
  const pausedUntilRef = useRef(Date.now() + 1400);
  const [reduceMotion, setReduceMotion] = useState(false);
  const shouldAutoScroll = layout === "horizontal" && props.source === "hot" && list.length > 2;

  useEffect(() => {
    let alive = true;
    AccessibilityInfo.isReduceMotionEnabled().then((value) => {
      if (alive) setReduceMotion(Boolean(value));
    });
    const sub = AccessibilityInfo.addEventListener("reduceMotionChanged", (value) => {
      setReduceMotion(Boolean(value));
    });
    return () => {
      alive = false;
      sub.remove();
    };
  }, []);

  useEffect(() => {
    if (!shouldAutoScroll) return;
    const speed = reduceMotion ? 11 : 19;
    let lastFrame = 0;
    let frameId = 0;
    autoPositionRef.current = offsetRef.current;

    const tick = (now: number) => {
      frameId = requestAnimationFrame(tick);
      if (!lastFrame) {
        lastFrame = now;
        return;
      }
      const elapsed = Math.min(80, now - lastFrame);
      lastFrame = now;
      if (interactingRef.current || Date.now() < pausedUntilRef.current) return;
      const maxOffset = Math.max(0, contentWidthRef.current - viewportWidthRef.current);
      if (maxOffset < 4) return;

      let next = autoPositionRef.current + directionRef.current * speed * (elapsed / 1000);
      if (next >= maxOffset) {
        next = maxOffset;
        directionRef.current = -1;
        pausedUntilRef.current = Date.now() + 850;
      } else if (next <= 0) {
        next = 0;
        directionRef.current = 1;
        pausedUntilRef.current = Date.now() + 850;
      }
      autoPositionRef.current = next;
      const pixel = Math.round(next);
      if (pixel !== lastPaintedPixelRef.current) {
        lastPaintedPixelRef.current = pixel;
        scrollRef.current?.scrollTo({ x: pixel, y: 0, animated: false });
      }
    };

    frameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frameId);
  }, [reduceMotion, shouldAutoScroll]);

  useEffect(() => {
    if (Platform.OS !== "web" || !shouldAutoScroll) return;
    const node = (scrollRef.current as any)?.getScrollableNode?.() as HTMLElement | undefined;
    if (!node) return;

    node.style.touchAction = "pan-y pinch-zoom";

    const onTouchStart = (event: TouchEvent) => {
      const touch = event.touches[0];
      if (!touch) return;
      dragAxisRef.current = null;
      touchStartRef.current = {
        x: touch.clientX,
        y: touch.clientY,
        offset: node.scrollLeft,
      };
    };

    const onTouchMove = (event: TouchEvent) => {
      const touch = event.touches[0];
      if (!touch) return;
      const dx = touch.clientX - touchStartRef.current.x;
      const dy = touch.clientY - touchStartRef.current.y;

      if (!dragAxisRef.current && Math.max(Math.abs(dx), Math.abs(dy)) >= 6) {
        dragAxisRef.current = Math.abs(dx) > Math.abs(dy) * 1.08 ? "x" : "y";
      }
      if (dragAxisRef.current !== "x") return;

      event.preventDefault();
      interactingRef.current = true;
      pausedUntilRef.current = Date.now() + 2600;
      const max = Math.max(0, node.scrollWidth - node.clientWidth);
      const next = Math.max(0, Math.min(max, touchStartRef.current.offset - dx));
      autoPositionRef.current = next;
      lastPaintedPixelRef.current = Math.round(next);
      node.scrollLeft = lastPaintedPixelRef.current;
    };

    const onTouchEnd = () => {
      if (dragAxisRef.current === "x") {
        offsetRef.current = node.scrollLeft;
        autoPositionRef.current = node.scrollLeft;
        pausedUntilRef.current = Date.now() + 2200;
      }
      interactingRef.current = false;
      dragAxisRef.current = null;
    };

    node.addEventListener("touchstart", onTouchStart, { passive: true });
    node.addEventListener("touchmove", onTouchMove, { passive: false });
    node.addEventListener("touchend", onTouchEnd, { passive: true });
    node.addEventListener("touchcancel", onTouchEnd, { passive: true });
    return () => {
      node.removeEventListener("touchstart", onTouchStart);
      node.removeEventListener("touchmove", onTouchMove);
      node.removeEventListener("touchend", onTouchEnd);
      node.removeEventListener("touchcancel", onTouchEnd);
    };
  }, [shouldAutoScroll]);

  const beginManualScroll = () => {
    interactingRef.current = true;
    pausedUntilRef.current = Date.now() + 3200;
  };

  const finishManualScroll = () => {
    interactingRef.current = false;
    autoPositionRef.current = offsetRef.current;
    lastPaintedPixelRef.current = Math.round(offsetRef.current);
    pausedUntilRef.current = Date.now() + 2600;
  };

  if (list.length === 0) return null;

  const cardProps = (it: any) => ({
    id: it.id,
    image: it.image,
    name: it.store_name,
    price: it.price,
    originalPrice: it.ot_price,
    sales: it.sales,
    giveIntegral: Number(it.give_integral) || 0,
    isHot: it.is_hot === 1,
    isNew: it.is_new === 1,
  });

  return (
    <View style={{ paddingVertical: s(14), backgroundColor: "transparent" }}>
      {!!title && (
        <View
          style={{
            paddingHorizontal: s(16),
            marginBottom: s(12),
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <Text style={{ color: "#171A1A", fontSize: s(22), lineHeight: s(27), fontWeight: "800" }}>
            {title}
          </Text>
          <Pressable
            hitSlop={8}
            onPress={() => router.push("/search")}
            style={{ flexDirection: "row", alignItems: "center", gap: s(1) }}
          >
            <Text style={{ color: Colors.primary.DEFAULT, fontSize: s(12), fontWeight: "700" }}>
              {lang === "en" ? "See all" : "查看全部"}
            </Text>
            <ChevronRight size={s(14)} color={Colors.primary.DEFAULT} strokeWidth={2.2} />
          </Pressable>
        </View>
      )}

      {layout === "grid" ? (
        // 两列严格对齐：固定两列、等宽、行间统一间距，卡片等高，左右/上下都齐
        <View
          style={{
            flexDirection: "row",
            flexWrap: "wrap",
            justifyContent: "space-between",
            paddingHorizontal: s(16),
            rowGap: s(12),
          }}
        >
          {list.map((it) => (
            <View key={it.id} style={{ width: "48.5%" }}>
              <ProductCard {...cardProps(it)} layout="grid" />
            </View>
          ))}
        </View>
      ) : (
        <ScrollView
          ref={scrollRef}
          horizontal
          disableScrollViewPanResponder={Platform.OS === "web"}
          directionalLockEnabled={false}
          showsHorizontalScrollIndicator={false}
          style={Platform.OS === "web" ? ({ touchAction: "pan-y" } as any) : undefined}
          contentContainerStyle={{ paddingHorizontal: s(16) }}
          scrollEventThrottle={32}
          onLayout={(event) => {
            viewportWidthRef.current = event.nativeEvent.layout.width;
          }}
          onContentSizeChange={(width) => {
            contentWidthRef.current = width;
          }}
          onScroll={(event) => {
            offsetRef.current = event.nativeEvent.contentOffset.x;
          }}
          onScrollBeginDrag={beginManualScroll}
          onScrollEndDrag={finishManualScroll}
          onMomentumScrollEnd={finishManualScroll}
          onTouchStart={Platform.OS === "web" ? undefined : beginManualScroll}
          onTouchEnd={Platform.OS === "web" ? undefined : finishManualScroll}
          onTouchCancel={Platform.OS === "web" ? undefined : finishManualScroll}
        >
          {list.map((it) => (
            <ProductCard
              key={it.id}
              {...cardProps(it)}
              layout="horizontal"
              size={props.source === "hot" ? "small" : "default"}
            />
          ))}
        </ScrollView>
      )}
    </View>
  );
}
