import { API_BASE_URL } from "@/constants/api";

/** 格式化价格：12.5 → "$12.50" */
export function formatPrice(price: string | number, symbol = "$"): string {
  const num = typeof price === "string" ? parseFloat(price) : price;
  if (Number.isNaN(num)) return `${symbol}0.00`;
  return `${symbol}${num.toFixed(2)}`;
}

/** 格式化积分数字：12580 → "12,580" */
export function formatNumber(n: number): string {
  return n.toLocaleString("en-US");
}

/** 补全图片 URL：相对路径 → 绝对路径 */
export function normalizeImageUrl(url?: string | null): string {
  if (!url) return "";
  const base = API_BASE_URL.replace(/\/$/, "");
  let next = String(url).trim();
  if (!next) return "";

  // Dead / legacy absolute hosts → current site origin
  const deadHosts = [
    /^https?:\/\/43\.134\.94\.57(?=\/)/i,
    /^https?:\/\/8\.166\.115\.27(?=\/)/i,
    /^https?:\/\/localhost(?::\d+)?(?=\/)/i,
    /^https?:\/\/127\.0\.0\.1(?::\d+)?(?=\/)/i,
  ];
  for (const hostRe of deadHosts) {
    next = next.replace(hostRe, base);
  }

  if (next.startsWith("http://") || next.startsWith("https://")) {
    return next;
  }
  return `${base}/${next.replace(/^\//, "")}`;
}

/** 截断文本 */
export function truncate(text: string, maxLen: number): string {
  if (text.length <= maxLen) return text;
  return `${text.slice(0, maxLen)}...`;
}

/** 相对时间：几分钟前、几小时前、几天前 */
export function timeAgo(dateStr: string): string {
  const now = Date.now();
  const past = new Date(dateStr).getTime();
  const diff = Math.floor((now - past) / 1000);
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 2592000) return `${Math.floor(diff / 86400)}d ago`;
  return new Date(dateStr).toLocaleDateString();
}

/** 格式化日期：2026-03-06 14:30:00 → "Mar 6, 2026" */
export function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

/** 倒计时格式化：秒 → "02:15:30" */
export function formatCountdown(totalSeconds: number): string {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  return [h, m, s].map((v) => String(v).padStart(2, "0")).join(":");
}

/** 生成唯一 ID */
export function uid(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

/** 延迟 */
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** 防抖 */
export function debounce<T extends (...args: unknown[]) => void>(
  fn: T,
  delay: number,
): T {
  let timer: ReturnType<typeof setTimeout>;
  return ((...args: unknown[]) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  }) as T;
}
