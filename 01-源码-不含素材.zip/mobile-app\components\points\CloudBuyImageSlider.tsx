import React, { useRef, useState } from "react";
import { Platform, ScrollView, View, useWindowDimensions } from "react-native";
import { Image } from "expo-image";
import { Gift } from "lucide-react-native";

/** 对齐参考实现 mobile `#sliderBox.picslider()`：整屏宽、一页一张、手指左右滑。 */
export default function CloudBuyImageSlider({
  images,
  height = 280,
}: {
  images: string[];
  height?: number;
}) {
  const { width: screenWidth } = useWindowDimensions();
  const [boxW, setBoxW] = useState(screenWidth);
  const [idx, setIdx] = useState(0);
  const scrollRef = useRef<ScrollView>(null);
  const webSnap =
    Platform.OS === "web"
      ? ({
          scrollSnapType: "x mandatory",
          WebkitOverflowScrolling: "touch",
          touchAction: "pan-x",
        } as any)
      : null;
  const webSlide =
    Platform.OS === "web"
      ? ({ scrollSnapAlign: "start", scrollSnapStop: "always" } as any)
      : null;

  const syncIndex = (x: number) => {
    const w = boxW || 1;
    const next = Math.max(0, Math.min(images.length - 1, Math.round(x / w)));
    setIdx((cur) => (cur === next ? cur : next));
  };

  return (
    <View
      style={{ width: "100%", height, backgroundColor: "#f4f4f4", overflow: "hidden" }}
      onLayout={(e) => {
        const w = Math.round(e.nativeEvent.layout.width);
        if (w > 0 && w !== boxW) setBoxW(w);
      }}
    >
      {images.length === 0 ? (
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <Gift size={56} color="#D1D5DB" />
        </View>
      ) : (
        <ScrollView
          ref={scrollRef}
          horizontal
          pagingEnabled
          nestedScrollEnabled
          directionalLockEnabled
          decelerationRate="fast"
          showsHorizontalScrollIndicator={false}
          scrollEventThrottle={16}
          style={[{ flexGrow: 0 }, webSnap]}
          onScroll={(e) => syncIndex(e.nativeEvent.contentOffset.x)}
          onMomentumScrollEnd={(e) => syncIndex(e.nativeEvent.contentOffset.x)}
        >
          {images.map((uri, i) => (
            <View
              key={`${uri}-${i}`}
              style={[{ width: boxW, height, alignItems: "center", justifyContent: "center" }, webSlide]}
            >
              <Image source={uri} style={{ width: boxW, height }} contentFit="contain" />
            </View>
          ))}
        </ScrollView>
      )}
      {images.length > 1 ? (
        <View
          pointerEvents="none"
          style={{
            position: "absolute",
            bottom: 10,
            left: 0,
            right: 0,
            flexDirection: "row",
            justifyContent: "center",
            gap: 6,
          }}
        >
          {images.map((_, i) => (
            <View
              key={i}
              style={{
                width: i === idx ? 16 : 6,
                height: 6,
                borderRadius: 3,
                backgroundColor: i === idx ? "#04A8AE" : "rgba(0,0,0,0.28)",
              }}
            />
          ))}
        </View>
      ) : null}
    </View>
  );
}

