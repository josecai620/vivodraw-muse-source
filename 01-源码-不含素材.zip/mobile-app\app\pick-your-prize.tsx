import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { Check, Gift, Info, Sparkles, TrendingUp, Zap } from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { Image, Pressable, ScrollView, Text, View, type ImageSourcePropType } from "react-native";

type PrizeOption = {
  id: string;
  title: string;
  titleZh: string;
  eyebrow: string;
  eyebrowZh: string;
  detail: string;
  detailZh: string;
  source: ImageSourcePropType;
  goal: number;
  current: number;
  dailyPoints: number;
};

type BoostOption = {
  id: string;
  label: string;
  labelZh: string;
  value: string;
  detail: string;
  detailZh: string;
};

const prizeOptions: PrizeOption[] = [
  {
    id: "ps5-bundle",
    title: "PS5 bundle",
    titleZh: "PS5 套裝",
    eyebrow: "Top prize",
    eyebrowZh: "頭獎",
    detail: "Daily progress toward a bigger product reward.",
    detailZh: "每日累積，朝大獎品前進。",
    source: require("../assets/products/ps5-slim-console.jpg"),
    goal: 2400,
    current: 840,
    dailyPoints: 44,
  },
  {
    id: "audio-tech",
    title: "Audio tech bundle",
    titleZh: "音頻科技套裝",
    eyebrow: "Tech reward",
    eyebrowZh: "科技獎勵",
    detail: "A reachable prize for regular check-in users.",
    detailZh: "持續簽到即可達成的獎品。",
    source: require("../assets/products/rgb-gaming-headset.jpg"),
    goal: 1600,
    current: 520,
    dailyPoints: 32,
  },
  {
    id: "gift-vault",
    title: "Gift reward vault",
    titleZh: "禮物寶庫",
    eyebrow: "Simple reward",
    eyebrowZh: "簡單獎勵",
    detail: "Easy first-day target for new members.",
    detailZh: "新會員第一天就能達標。",
    source: require("../assets/products/mystery-prize-box.jpg"),
    goal: 1000,
    current: 360,
    dailyPoints: 24,
  },
];

const boostOptions: BoostOption[] = [
  {
    id: "points-luck",
    label: "Points + giveaway luck",
    labelZh: "積分 + 抽獎運勢",
    value: "+5%",
    detail: "Best when you want faster prize progress.",
    detailZh: "想更快累積獎品進度時選它。",
  },
  {
    id: "coupon-upgrade",
    label: "Gift card / coupon upgrade",
    labelZh: "禮品卡 / 優惠券升級",
    value: "+10%",
    detail: "Best when you want a better deal later.",
    detailZh: "想之後拿到更優惠時選它。",
  },
  {
    id: "vip-boost",
    label: "VIP level boost",
    labelZh: "VIP 等級加速",
    value: "+15%",
    detail: "Best when you want membership perks faster.",
    detailZh: "想更快解鎖會員權益時選它。",
  },
];

export default function PickYourPrizePage() {
  const router = useRouter();
  const { i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const [selectedPrizeId, setSelectedPrizeId] = useState(prizeOptions[0]!.id);
  const [selectedBoostId, setSelectedBoostId] = useState(boostOptions[0]!.id);
  const [previewed, setPreviewed] = useState(false);

  const selectedPrize = useMemo(
    () => prizeOptions.find((item) => item.id === selectedPrizeId) ?? prizeOptions[0]!,
    [selectedPrizeId],
  );
  const selectedBoost = useMemo(
    () => boostOptions.find((item) => item.id === selectedBoostId) ?? boostOptions[0]!,
    [selectedBoostId],
  );
  const nextPoints = Math.min(selectedPrize.goal, selectedPrize.current + selectedPrize.dailyPoints);
  const progress = Math.round((nextPoints / selectedPrize.goal) * 100);

  return (
    <View className="flex-1 bg-neutral-50">
      <PageHeader title={zh ? "每日選獎" : "Daily prize pick"} />
      <ScrollView
        contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
      >
        {/* 说明 */}
        <View className="rounded-2xl p-5 gap-2" style={{ backgroundColor: "#ECFBFB" }}>
          <View className="flex-row items-center">
            <Gift size={18} color={Colors.brand.redDark} />
            <Text className="text-base font-bold ml-2" style={{ color: Colors.brand.redDark }}>
              {zh ? "每天選 1 個獎品、1 個增益" : "1 pick per day"}
            </Text>
          </View>
          <Text className="text-sm text-neutral-600 leading-5">
            {zh
              ? "它掛在每日簽到之下，是輕量的每日獎勵選擇，不是商城購買；以下僅為概念預覽，不寫入任何帳號資料。"
              : "A light daily reward choice under check-in, not a store purchase. Preview only, no account write."}
          </Text>
          <View className="flex-row items-center self-start rounded-full bg-white px-3 py-1.5">
            <Info size={12} color={Colors.brand.redDark} />
            <Text className="text-xs font-bold ml-1.5" style={{ color: Colors.brand.redDark }}>
              {zh ? "僅試玩演示，不產生真實積分" : "Demo only, no real points"}
            </Text>
          </View>
        </View>

        {/* 已选奖品 */}
        <View className="bg-white rounded-2xl overflow-hidden">
          <Image
            accessibilityIgnoresInvertColors
            source={selectedPrize.source}
            resizeMode="contain"
            style={{ width: "100%", height: 190, backgroundColor: "#F7F9F9" }}
          />
          <View className="p-5 gap-3">
            <Text className="text-xs font-bold" style={{ color: Colors.brand.redDark }}>
              {zh ? selectedPrize.eyebrowZh : selectedPrize.eyebrow}
            </Text>
            <Text className="text-2xl font-bold text-neutral-900">
              {zh ? selectedPrize.titleZh : selectedPrize.title}
            </Text>
            <Text className="text-sm text-neutral-500 leading-5">
              {zh ? selectedPrize.detailZh : selectedPrize.detail}
            </Text>
            <View className="flex-row gap-2">
              <View className="flex-1 rounded-xl p-3" style={{ backgroundColor: "#F7F9F9" }}>
                <Text className="text-xs text-neutral-500">{zh ? "今日" : "Today"}</Text>
                <Text className="text-sm font-bold text-neutral-900 mt-0.5">
                  +{selectedPrize.dailyPoints} {zh ? "積分" : "points"}
                </Text>
              </View>
              <View className="flex-1 rounded-xl p-3" style={{ backgroundColor: "#F7F9F9" }}>
                <Text className="text-xs text-neutral-500">{zh ? "增益" : "Boost"}</Text>
                <Text className="text-sm font-bold text-neutral-900 mt-0.5">
                  {selectedBoost.value}
                </Text>
              </View>
            </View>
            <View className="h-2.5 rounded-full overflow-hidden" style={{ backgroundColor: "rgba(12,31,31,0.08)" }}>
              <View
                className="h-full rounded-full"
                style={{ width: `${progress}%`, backgroundColor: Colors.brand.red }}
              />
            </View>
            <Text className="text-xs text-neutral-500">
              {nextPoints}/{selectedPrize.goal} {zh ? "積分" : "points"} · {progress}%
            </Text>
          </View>
        </View>

        {/* Step 1 选奖品 */}
        <View className="gap-3">
          <View>
            <Text className="text-xs font-bold" style={{ color: Colors.brand.redDark }}>
              {zh ? "第一步" : "Step 1"}
            </Text>
            <Text className="text-base font-bold text-neutral-900">
              {zh ? "選擇獎品目標" : "Choose prize target"}
            </Text>
          </View>
          <View className="flex-row gap-2">
            {prizeOptions.map((prize) => {
              const active = prize.id === selectedPrizeId;
              return (
                <Pressable
                  key={prize.id}
                  onPress={() => {
                    setSelectedPrizeId(prize.id);
                    setPreviewed(false);
                  }}
                  className="flex-1 rounded-xl p-2 border"
                  style={{
                    borderColor: active ? Colors.brand.red : "rgba(12,31,31,0.08)",
                    backgroundColor: active ? "#ECFBFB" : "#fff",
                  }}
                >
                  <Image
                    accessibilityIgnoresInvertColors
                    source={prize.source}
                    resizeMode="contain"
                    style={{ width: "100%", height: 68, borderRadius: 8, backgroundColor: "#F7F9F9" }}
                  />
                  <Text numberOfLines={1} className="text-xs font-bold text-neutral-900 mt-1.5">
                    {zh ? prize.titleZh : prize.title}
                  </Text>
                  <Text numberOfLines={1} className="text-[10px] text-neutral-500">
                    {zh ? prize.eyebrowZh : prize.eyebrow}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* Step 2 选增益 */}
        <View className="gap-3">
          <View>
            <Text className="text-xs font-bold" style={{ color: Colors.brand.redDark }}>
              {zh ? "第二步" : "Step 2"}
            </Text>
            <Text className="text-base font-bold text-neutral-900">
              {zh ? "選擇今日增益" : "Choose today's boost"}
            </Text>
          </View>
          <View className="gap-2">
            {boostOptions.map((boost, index) => {
              const active = boost.id === selectedBoostId;
              return (
                <Pressable
                  key={boost.id}
                  onPress={() => {
                    setSelectedBoostId(boost.id);
                    setPreviewed(false);
                  }}
                  className="flex-row items-center gap-3 rounded-xl p-3.5 border bg-white"
                  style={{ borderColor: active ? Colors.brand.red : "rgba(12,31,31,0.08)" }}
                >
                  <View
                    className="w-10 h-10 rounded-full items-center justify-center"
                    style={{ backgroundColor: active ? Colors.brand.red : "#ECFBFB" }}
                  >
                    <Text className="font-bold" style={{ color: active ? "#fff" : Colors.brand.redDark }}>
                      {String.fromCharCode(65 + index)}
                    </Text>
                  </View>
                  <View className="flex-1">
                    <Text className="text-sm font-bold text-neutral-900">
                      {zh ? boost.labelZh : boost.label}
                    </Text>
                    <Text className="text-xs text-neutral-500 mt-0.5">
                      {zh ? boost.detailZh : boost.detail}
                    </Text>
                  </View>
                  <Text className="text-sm font-bold" style={{ color: Colors.brand.redDark }}>
                    {boost.value}
                  </Text>
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* 结果 */}
        <View className="bg-white rounded-2xl p-5 gap-3">
          <View className="flex-row items-center">
            {previewed ? <Check size={18} color={Colors.brand.red} /> : <Sparkles size={18} color={Colors.neutral[400]} />}
            <Text className="text-base font-bold text-neutral-900 ml-2">
              {previewed
                ? zh
                  ? "今日選擇已預覽"
                  : "Daily choice previewed"
                : zh
                  ? "準備預覽"
                  : "Ready to preview"}
            </Text>
          </View>
          <View className="flex-row items-start">
            <Zap size={14} color={Colors.neutral[400]} />
            <Text className="flex-1 ml-1.5 text-sm text-neutral-500 leading-5">
              {previewed
                ? zh
                  ? "預覽只保存在本頁本機，不會改變真實積分、優惠券、禮品卡或 VIP 等級。"
                  : "Preview saved locally for this screen. It does not change real points, coupons, gift cards, or VIP level."
                : zh
                  ? "用戶只選一個獎品和一項增益——全都要就不是經濟系統而是喜劇了。"
                  : "Choose one prize and one benefit. Not all rewards at once, because that would be comedy, not economy."}
            </Text>
          </View>
          <Pressable disabled={previewed} onPress={() => setPreviewed(true)}>
            <LinearGradient
              colors={
                previewed
                  ? [Colors.neutral[300], Colors.neutral[300]]
                  : [TealGradient.light, TealGradient.base, TealGradient.dark]
              }
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              className="h-12 rounded-xl items-center justify-center flex-row"
            >
              <TrendingUp size={16} color="#fff" />
              <Text className="text-white font-bold ml-2">
                {previewed
                  ? zh
                    ? "已預覽"
                    : "Previewed"
                  : zh
                    ? "預覽今日選擇"
                    : "Preview daily choice"}
              </Text>
            </LinearGradient>
          </Pressable>
          <Pressable
            className="h-12 rounded-xl bg-white border border-neutral-200 items-center justify-center"
            onPress={() => router.replace("/play")}
          >
            <Text className="font-bold text-neutral-700">{zh ? "返回互動樂園" : "Back to rewards"}</Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}
