import type { ImageSourcePropType } from "react-native";

import { getPetSpriteSheetSource } from "@/lib/pet-animation-assets";
import type { PixelDeskPetId } from "@/lib/pets";

export type PetActionName =
  | "idle"
  | "showcase"
  | "hatTrick"
  | "lookOwner"
  | "standIdleFront"
  | "pawGreetFront"
  | "headTiltFront"
  | "frontBobIdle"
  | "frontHappyWave"
  | "frontJoyBounce"
  | "frontReadIdle"
  | "frontPageFlip"
  | "frontHappyLookup"
  | "happy"
  | "stage"
  | "sleep"
  | "runRight"
  | "runLeft"
  | "wave"
  | "jump"
  | "fail"
  | "wait"
  | "run"
  | "inspect"
  | "talk"
  | "drag"
  | "hideLaptop"
  | "disappear";
export type PetFXName = "fx_sparkle" | "fx_smoke" | "fx_magic_circle";

export const PET_SPRITE_FRAME_WIDTH = 96;
export const PET_SPRITE_FRAME_HEIGHT = 96;
export const PET_SPRITE_RENDER_SIZE = 96;

export type SpriteSheetDefinition = {
  source: ImageSourcePropType;
  sourceKey: string;
  frameWidth: number;
  frameHeight: number;
  frames: number;
  fps: number;
  loop: boolean;
  sourceFrames: number;
  startFrame: number;
};

type RawSpriteSheetDefinition = Omit<SpriteSheetDefinition, "source" | "loop" | "sourceFrames" | "startFrame"> & {
  loop?: boolean;
  fx?: PetFXName[];
  sourceFrames?: number;
  startFrame?: number;
};

export type PetBehaviorConfig = {
  defaultAction: PetActionName;
  showcaseAction: PetActionName;
  inactiveAction: PetActionName;
  inactiveAfterMs: number;
  randomIdleAfterMs: readonly [number, number];
  clickPool: readonly PetActionName[];
  randomIdlePool: readonly PetActionName[];
  messagePool: readonly PetActionName[];
  dragAction: PetActionName;
  dragEndAction: PetActionName;
  previewActions: readonly PetActionName[];
  stagePreviewActions: readonly PetActionName[];
};

type RawPetBehaviorConfig = Partial<PetBehaviorConfig> & {
  randomIdleAfterMs?: readonly number[];
};

type RawPetAnimationConfig = {
  defaults: {
    frameWidth: number;
    frameHeight: number;
    fps: number;
  };
  pets: Partial<
    Record<
      PixelDeskPetId,
      {
        actions: Partial<Record<PetActionName, RawSpriteSheetDefinition>>;
        behavior?: RawPetBehaviorConfig;
      }
    >
  >;
  fx: Record<PetFXName, RawSpriteSheetDefinition>;
};

const animationConfig = require("../assets/pets/animation-config.json") as RawPetAnimationConfig;

export function getPetActionDefinition(petId: PixelDeskPetId, action: PetActionName): SpriteSheetDefinition | null {
  const raw = animationConfig.pets[petId]?.actions[action];
  return raw ? resolveDefinition(raw) : null;
}

export function getPetBehaviorConfig(petId: PixelDeskPetId): PetBehaviorConfig {
  const raw = animationConfig.pets[petId]?.behavior ?? {};
  const randomIdleAfterMs = normalizeDelayRange(raw.randomIdleAfterMs);

  return {
    defaultAction: firstAvailableAction(petId, [raw.defaultAction, "idle"]),
    showcaseAction: firstAvailableAction(petId, [raw.showcaseAction, "showcase", "idle"]),
    inactiveAction: firstAvailableAction(petId, [raw.inactiveAction, "sleep", "idle"]),
    inactiveAfterMs: normalizeDelay(raw.inactiveAfterMs, 24000),
    randomIdleAfterMs,
    clickPool: availableActions(petId, raw.clickPool ?? ["happy"]),
    randomIdlePool: availableActions(petId, raw.randomIdlePool ?? []),
    messagePool: availableActions(petId, raw.messagePool ?? ["talk"]),
    dragAction: firstAvailableAction(petId, [raw.dragAction, "drag", "idle"]),
    dragEndAction: firstAvailableAction(petId, [raw.dragEndAction, "idle"]),
    previewActions: availableActions(petId, raw.previewActions ?? ["idle", "sleep", "talk", "happy", "drag"]),
    stagePreviewActions: availableActions(petId, raw.stagePreviewActions ?? [raw.showcaseAction ?? "showcase"]),
  };
}

export function getPetPreviewActions(petId: PixelDeskPetId): PetActionName[] {
  return [...getPetBehaviorConfig(petId).previewActions];
}

export function getPetStagePreviewActions(petId: PixelDeskPetId): PetActionName[] {
  return [...getPetBehaviorConfig(petId).stagePreviewActions];
}

export function getPetActionFX(petId: PixelDeskPetId, action: PetActionName): PetFXName[] {
  return animationConfig.pets[petId]?.actions[action]?.fx ?? [];
}

export function getPetFXDefinition(fxName: PetFXName): SpriteSheetDefinition | null {
  const raw = animationConfig.fx[fxName];
  return raw ? resolveDefinition(raw) : null;
}

export function getPetActionDurationMs(petId: PixelDeskPetId, action: PetActionName) {
  const definition = getPetActionDefinition(petId, action);

  if (!definition) {
    return 700;
  }

  return Math.max(1, Math.ceil((definition.frames / Math.max(1, definition.fps)) * 1000));
}

export function pickRandomPetAction(actions: readonly PetActionName[], fallback: PetActionName = "idle"): PetActionName {
  if (actions.length === 0) {
    return fallback;
  }

  return actions[Math.floor(Math.random() * actions.length)] ?? fallback;
}

export function normalizePetAction(action: string): PetActionName {
  if (action === "message") {
    return "talk";
  }

  if (action === "rest" || action === "blink") {
    return "sleep";
  }

  if (action === "wander" || action === "react" || action === "land") {
    return "idle";
  }

  if (action === "grab") {
    return "drag";
  }

  if (
    action === "showcase" ||
    action === "stage" ||
    action === "hideLaptop" ||
    action === "hatTrick" ||
    action === "lookOwner" ||
    action === "standIdleFront" ||
    action === "pawGreetFront" ||
    action === "headTiltFront" ||
    action === "frontBobIdle" ||
    action === "frontHappyWave" ||
    action === "frontJoyBounce" ||
    action === "frontReadIdle" ||
    action === "frontPageFlip" ||
    action === "frontHappyLookup" ||
    action === "happy" ||
    action === "sleep" ||
    action === "runRight" ||
    action === "runLeft" ||
    action === "wave" ||
    action === "jump" ||
    action === "fail" ||
    action === "wait" ||
    action === "run" ||
    action === "inspect" ||
    action === "talk" ||
    action === "drag" ||
    action === "disappear"
  ) {
    return action;
  }

  return "idle";
}

function resolveDefinition(raw: RawSpriteSheetDefinition): SpriteSheetDefinition | null {
  const source = getPetSpriteSheetSource(raw.sourceKey);

  if (!source) {
    return null;
  }

  const frameWidth = raw.frameWidth ?? animationConfig.defaults.frameWidth;
  const frameHeight = raw.frameHeight ?? animationConfig.defaults.frameHeight;

  if (frameWidth !== PET_SPRITE_FRAME_WIDTH || frameHeight !== PET_SPRITE_FRAME_HEIGHT) {
    throw new Error(
      `Pet sprite sheet "${raw.sourceKey}" must use ${PET_SPRITE_FRAME_WIDTH}x${PET_SPRITE_FRAME_HEIGHT} frames; got ${frameWidth}x${frameHeight}.`,
    );
  }

  return {
    source,
    sourceKey: raw.sourceKey,
    frameWidth: PET_SPRITE_FRAME_WIDTH,
    frameHeight: PET_SPRITE_FRAME_HEIGHT,
    frames: raw.frames,
    fps: raw.fps ?? animationConfig.defaults.fps,
    loop: raw.loop ?? true,
    sourceFrames: raw.sourceFrames ?? raw.frames,
    startFrame: raw.startFrame ?? 0,
  };
}

function availableActions(petId: PixelDeskPetId, actions: readonly PetActionName[]): PetActionName[] {
  return actions.filter((action) => Boolean(getPetActionDefinition(petId, action)));
}

function firstAvailableAction(petId: PixelDeskPetId, actions: readonly (PetActionName | undefined)[]): PetActionName {
  return actions.find((action) => action && getPetActionDefinition(petId, action)) ?? "idle";
}

function normalizeDelay(value: number | undefined, fallback: number): number {
  return value !== undefined && Number.isFinite(value) && value > 0 ? value : fallback;
}

function normalizeDelayRange(value: readonly number[] | undefined): [number, number] {
  const min = normalizeDelay(value?.[0], 5200);
  const max = normalizeDelay(value?.[1], 9200);
  return min <= max ? [min, max] : [max, min];
}
