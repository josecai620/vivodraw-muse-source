import { Alert, Platform } from "react-native";

export type AppAlertButton = {
  text?: string;
  onPress?: () => void;
  style?: "default" | "cancel" | "destructive";
};

/**
 * Web：react-native-web 的 Alert 是空实现，用 window 兜底。
 * Native：走系统 Alert。
 */
export function appAlert(
  title: string,
  message?: string,
  buttons?: AppAlertButton[],
): void {
  if (Platform.OS !== "web") {
    Alert.alert(title, message, buttons as any);
    return;
  }

  const msg = [title, message].filter((x) => x != null && String(x).length > 0).join("\n\n");

  if (!buttons || buttons.length === 0) {
    window.alert(msg);
    return;
  }

  if (buttons.length === 1) {
    window.alert(msg);
    queueMicrotask(() => buttons[0].onPress?.());
    return;
  }

  const ok = window.confirm(msg);
  queueMicrotask(() => {
    if (ok) {
      const primary = buttons[buttons.length - 1];
      primary.onPress?.();
    } else {
      const cancel = buttons.find((b) => b.style === "cancel");
      cancel?.onPress?.();
    }
  });
}
