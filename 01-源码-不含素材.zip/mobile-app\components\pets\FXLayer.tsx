import { memo } from "react";
import { StyleSheet, View, type StyleProp, type ViewStyle } from "react-native";

import { SpriteSheetPlayer } from "@/components/pets/SpriteSheetPlayer";
import { getPetActionFX, getPetFXDefinition, type PetActionName } from "@/lib/pet-animations";
import type { PixelDeskPetId } from "@/lib/pets";

type FXLayerProps = {
  petId: PixelDeskPetId;
  action: PetActionName;
  style?: StyleProp<ViewStyle>;
};

function FXLayerComponent({ petId, action, style }: FXLayerProps) {
  const fxNames = getPetActionFX(petId, action);

  if (fxNames.length === 0) {
    return null;
  }

  return (
    <View pointerEvents="none" style={[styles.root, style]}>
      {fxNames.map((fxName) => {
        const fx = getPetFXDefinition(fxName);

        if (!fx) {
          return null;
        }

        return (
          <SpriteSheetPlayer
            key={`${action}-${fxName}-${fx.sourceKey}`}
            displayScale={1}
            fps={fx.fps}
            frameHeight={fx.frameHeight}
            frameWidth={fx.frameWidth}
            frames={fx.frames}
            loop={fx.loop}
            source={fx.source}
            style={styles.fx}
          />
        );
      })}
    </View>
  );
}

export const FXLayer = memo(FXLayerComponent);

const styles = StyleSheet.create({
  root: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
    zIndex: 3,
  },
  fx: {
    position: "absolute",
  },
});
