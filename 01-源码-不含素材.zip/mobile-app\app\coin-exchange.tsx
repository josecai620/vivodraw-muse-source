import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import {
  exchangeRewardCoinsToPoints,
  fetchRewardCoinSummary,
  type RewardCoinSummary,
} from "@/lib/api/rewardCoins";
import { useAuthStore } from "@/store/auth";
import { useAppStore } from "@/store/app";
import { LinearGradient } from "expo-linear-gradient";
import { Platform } from "react-native";
import { useRouter } from "expo-router";
import { Coins, Gem, Sparkles } from "lucide-react-native";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";

type GameCard = {
  titleKey: string;
  metaKey: string;
  href: string;
  external?: boolean;
  mark: string;
  rewardKey: string;
};

const GAME_CARDS: GameCard[] = [
  { titleKey: "coinExchange.gamePearl", metaKey: "coinExchange.gamePearlMeta", href: "/pearl", mark: "01", rewardKey: "coinExchange.rewardPoints" },
  { titleKey: "coinExchange.gameMine", metaKey: "coinExchange.gameMineMeta", href: "/mine/mobile", external: true, mark: "02", rewardKey: "coinExchange.rewardCoins" },
  { titleKey: "coinExchange.gameFarm", metaKey: "coinExchange.gameFarmMeta", href: "/farm", external: true, mark: "03", rewardKey: "coinExchange.rewardCoins" },
  { titleKey: "coinExchange.gamePet", metaKey: "coinExchange.gamePetMeta", href: "/pet-deck", mark: "04", rewardKey: "coinExchange.rewardCoins" },
];

export default function CoinExchangeScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const showToast = useAppStore((s) => s.showToast);
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);

  const [summary, setSummary] = useState<RewardCoinSummary | undefined>();
  const [loading, setLoading] = useState(false);
  const [exchanging, setExchanging] = useState(false);

  const rate = summary?.exchangeRate || 10;
  const coinBalance = summary?.coinBalance || 0;
  const convertiblePoints = summary?.convertiblePoints || 0;
  const remainingCoins = summary?.remainingCoins || 0;
  const maxExchangeCoins = convertiblePoints * rate;

  const refresh = useCallback(async () => {
    if (!isLoggedIn) {
      setSummary(undefined);
      return;
    }
    setLoading(true);
    try {
      const result = await fetchRewardCoinSummary();
      if (result.ok && result.summary) setSummary(result.summary);
    } finally {
      setLoading(false);
    }
  }, [isLoggedIn]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const openPath = (card: GameCard) => {
    if (card.external && Platform.OS === "web" && typeof window !== "undefined") {
      window.location.assign(card.href);
      return;
    }
    if (!card.external) router.push(card.href);
  };

  const exchangeCoins = async (coins: number) => {
    if (!isLoggedIn) {
      router.push("/auth");
      return;
    }
    if (exchanging || coins < rate || coins > coinBalance) return;
    setExchanging(true);
    try {
      const result = await exchangeRewardCoinsToPoints(coins);
      if (result.ok) {
        if (result.summary) setSummary(result.summary);
        else await refresh();
        showToast(
          `${t("coinExchange.converted")} ${result.coinsSpent || coins} ${t("coinExchange.coinsUnit")} → +${result.points} ${t("coinExchange.pointsUnit")}`,
          "success",
        );
      } else if (result.status === 410000 || result.status === 410001) {
        router.push("/auth");
      } else {
        showToast(result.message || t("coinExchange.exchangeFailed"), "error");
      }
    } finally {
      setExchanging(false);
    }
  };

  const quickOptions = useMemo(() => {
    const options = [
      { label: `${rate} → 1`, coins: rate },
      { label: `${rate * 5} → 5`, coins: rate * 5 },
      { label: t("coinExchange.convertAll"), coins: maxExchangeCoins },
    ];
    return options.filter(
      (o, i, list) => o.coins > 0 && list.findIndex((x) => x.coins === o.coins) === i,
    );
  }, [maxExchangeCoins, rate, t]);

  return (
    <View className="flex-1 bg-neutral-50">
      <PageHeader title={t("coinExchange.title")} />
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, paddingBottom: 120, gap: 20 }}>
        <View>
          <Text className="text-2xl font-bold text-neutral-900 mb-1">{t("coinExchange.headline")}</Text>
          <Text className="text-sm text-neutral-500 leading-5">{t("coinExchange.subtitle")}</Text>
        </View>

        {/* 余额与兑换卡 */}
        <View className="bg-white rounded-3xl p-5">
          <View className="flex-row gap-4 mb-4">
            <View className="flex-1 rounded-2xl p-4" style={{ backgroundColor: "#F7F9F9" }}>
              <View className="flex-row items-center mb-1">
                <Coins size={14} color={Colors.brand.red} />
                <Text className="text-xs text-neutral-500 ml-1.5 font-semibold">{t("coinExchange.coinBalance")}</Text>
              </View>
              <Text className="text-3xl font-bold text-neutral-900">
                {loading ? "…" : coinBalance.toLocaleString()}
              </Text>
            </View>
            <View className="flex-1 rounded-2xl p-4" style={{ backgroundColor: "#ECFBFB" }}>
              <View className="flex-row items-center mb-1">
                <Gem size={14} color={Colors.brand.red} />
                <Text className="text-xs font-semibold ml-1.5" style={{ color: Colors.brand.redDark }}>
                  {t("coinExchange.readyPoints")}
                </Text>
              </View>
              <Text className="text-3xl font-bold" style={{ color: Colors.brand.red }}>
                {loading ? "…" : convertiblePoints.toLocaleString()}
              </Text>
            </View>
          </View>

          <Text className="text-xs text-neutral-500 mb-4">
            {t("coinExchange.rateLabel")}: {rate} {t("coinExchange.coinsUnit")} = 1 {t("coinExchange.pointsUnit")}
            {remainingCoins > 0 ? ` · ${remainingCoins} ${t("coinExchange.leftOver")}` : ""}
          </Text>

          {!isLoggedIn ? (
            <Pressable
              className="h-12 rounded-xl items-center justify-center"
              style={{ backgroundColor: Colors.brand.red }}
              onPress={() => router.push("/auth")}
            >
              <Text className="text-white font-bold text-base">{t("coinExchange.signInToExchange")}</Text>
            </Pressable>
          ) : (
            <>
              <View className="flex-row flex-wrap gap-2 mb-4">
                {quickOptions.map((o) => {
                  const disabled = exchanging || o.coins > coinBalance || o.coins < rate;
                  return (
                    <Pressable
                      key={o.label}
                      disabled={disabled}
                      onPress={() => void exchangeCoins(o.coins)}
                      className="px-3.5 py-2 rounded-full border"
                      style={{
                        borderColor: disabled ? Colors.neutral[200] : "rgba(4,168,174,0.35)",
                        backgroundColor: disabled ? "#F7F9F9" : "#ECFBFB",
                        opacity: disabled ? 0.5 : 1,
                      }}
                    >
                      <Text className="text-xs font-bold" style={{ color: disabled ? Colors.neutral[400] : Colors.brand.redDark }}>
                        {o.label}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>

              <Pressable
                disabled={exchanging || convertiblePoints <= 0}
                onPress={() => void exchangeCoins(maxExchangeCoins)}
              >
                <LinearGradient
                  colors={
                    !exchanging && convertiblePoints > 0
                      ? [TealGradient.light, TealGradient.base, TealGradient.dark]
                      : [Colors.neutral[300], Colors.neutral[300]]
                  }
                  start={{ x: 0, y: 0.5 }}
                  end={{ x: 1, y: 0.5 }}
                  className="h-12 rounded-xl items-center justify-center flex-row"
                >
                  {exchanging ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <Text className="text-white font-bold text-base">
                      {convertiblePoints > 0
                        ? `${t("coinExchange.convert")} ${maxExchangeCoins} → ${convertiblePoints}`
                        : t("coinExchange.needMoreCoins")}
                    </Text>
                  )}
                </LinearGradient>
              </Pressable>
            </>
          )}
        </View>

        {/* 赚币入口 */}
        <View>
          <View className="flex-row items-center mb-3">
            <Sparkles size={16} color={Colors.brand.red} />
            <Text className="text-lg font-bold text-neutral-900 ml-2">{t("coinExchange.earnTitle")}</Text>
          </View>
          <View className="gap-2.5">
            {GAME_CARDS.map((g) => (
              <Pressable
                key={g.mark}
                onPress={() => openPath(g)}
                className="bg-white rounded-2xl p-4 flex-row items-center active:bg-neutral-50"
              >
                <Text className="w-7 text-sm font-bold" style={{ color: Colors.brand.red }}>{g.mark}</Text>
                <View className="flex-1">
                  <Text className="text-sm font-bold text-neutral-900">{t(g.titleKey)}</Text>
                  <Text className="text-xs text-neutral-500 mt-0.5">{t(g.metaKey)}</Text>
                </View>
                <Text className="text-xs font-bold" style={{ color: Colors.brand.redDark }}>{t(g.rewardKey)}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
