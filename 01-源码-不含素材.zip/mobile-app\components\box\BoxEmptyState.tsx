import React from "react";
import { View, Text, type ViewStyle } from "react-native";
import { BoxActionButton } from "./BoxActionButton";
import { BoxText, BoxTypography, BoxSpacing, bs } from "@/lib/boxTheme";

interface BoxEmptyStateProps {
  icon: React.ReactNode;
  title: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  style?: ViewStyle;
}

export function BoxEmptyState({
  icon, title, description, actionLabel, onAction, style,
}: BoxEmptyStateProps) {
  return (
    <View style={[{
      alignItems: "center",
      justifyContent: "center",
      paddingVertical: BoxSpacing["4xl"],
      paddingHorizontal: BoxSpacing["2xl"],
    }, style]}>
      <View style={{ marginBottom: BoxSpacing.lg, opacity: 0.5 }}>
        {icon}
      </View>
      <Text style={[BoxTypography.bodyBold, { color: BoxText.secondary, textAlign: "center" }]}>
        {title}
      </Text>
      {description && (
        <Text style={[BoxTypography.caption, { color: BoxText.tertiary, textAlign: "center", marginTop: BoxSpacing.xs }]}>
          {description}
        </Text>
      )}
      {actionLabel && onAction && (
        <BoxActionButton
          title={actionLabel}
          variant="primary"
          compact
          onPress={onAction}
          style={{ marginTop: BoxSpacing.xl, minWidth: bs(140) }}
        />
      )}
    </View>
  );
}
