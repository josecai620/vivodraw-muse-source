import React, { useMemo, useRef, useState } from "react";
import {
  PanResponder,
  Platform,
  Pressable,
  Text,
  View,
  useWindowDimensions,
} from "react-native";
import { useRouter } from "expo-router";
import { useTranslation } from "react-i18next";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { X } from "lucide-react-native";
import { Colors, Shadows } from "@/constants/theme";

const TEAL = Colors.primary.DEFAULT;
const EDGE_GAP = 12;
const DOCK_GAP = 6;
const CLOSE_SIZE = 28;
const ACTION_HEIGHT = 32;
const FALLBACK_WIDTH = CLOSE_SIZE + DOCK_GAP + 150;
const FALLBACK_HEIGHT = ACTION_HEIGHT;

export default function ProfileCloudBuyDock() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { width: viewportWidth, height: viewportHeight } = useWindowDimensions();
  const [visible, setVisible] = useState(true);
  const [dockSize, setDockSize] = useState({ width: FALLBACK_WIDTH, height: FALLBACK_HEIGHT });
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);
  const positionRef = useRef(position);
  const dragOrigin = useRef<{ x: number; y: number; pointerX: number; pointerY: number } | null>(null);
  const webPointerRef = useRef<
    { pointerId: number; x: number; y: number; startX: number; startY: number; moved: boolean } | null
  >(null);

  const clampPosition = (x: number, y: number) => ({
    x: Math.max(EDGE_GAP, Math.min(x, Math.max(EDGE_GAP, viewportWidth - dockSize.width - EDGE_GAP))),
    y: Math.max(insets.top + EDGE_GAP, Math.min(y, Math.max(insets.top + EDGE_GAP, viewportHeight - dockSize.height - EDGE_GAP))),
  });

  const defaultPosition = useMemo(
    () =>
      clampPosition(
        viewportWidth - dockSize.width - EDGE_GAP,
        (viewportHeight - dockSize.height) / 2,
      ),
    [dockSize.height, dockSize.width, insets.top, viewportHeight, viewportWidth],
  );
  const renderedPosition = position ?? defaultPosition;

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => false,
        onMoveShouldSetPanResponder: (_, gesture) =>
          Math.abs(gesture.dx) > 4 || Math.abs(gesture.dy) > 4,
        onMoveShouldSetPanResponderCapture: (_, gesture) =>
          Math.abs(gesture.dx) > 4 || Math.abs(gesture.dy) > 4,
        onPanResponderGrant: (_, gesture) => {
          const current = positionRef.current ?? defaultPosition;
          dragOrigin.current = {
            x: current.x,
            y: current.y,
            pointerX: gesture.x0,
            pointerY: gesture.y0,
          };
        },
        onPanResponderMove: (_, gesture) => {
          const origin = dragOrigin.current;
          if (!origin) return;
          const next = clampPosition(origin.x + gesture.dx, origin.y + gesture.dy);
          positionRef.current = next;
          setPosition(next);
        },
        onPanResponderRelease: () => {
          dragOrigin.current = null;
        },
        onPanResponderTerminate: () => {
          dragOrigin.current = null;
        },
      }),
    [defaultPosition, insets.top, viewportHeight, viewportWidth, dockSize.height, dockSize.width],
  );
  const webDragHandlers =
    Platform.OS === "web"
      ? ({
          onPointerDown: (event: any) => {
            const nativeEvent = event.nativeEvent ?? event;
            const target = event.target ?? nativeEvent.target;
            if (target?.closest?.('[data-testid="profile-cloud-buy-close"]')) return;
            const current = positionRef.current ?? defaultPosition;
            webPointerRef.current = {
              pointerId: nativeEvent.pointerId,
              x: current.x,
              y: current.y,
              startX: nativeEvent.clientX,
              startY: nativeEvent.clientY,
              moved: false,
            };
            event.currentTarget?.setPointerCapture?.(nativeEvent.pointerId);
          },
          onPointerMove: (event: any) => {
            const drag = webPointerRef.current;
            const nativeEvent = event.nativeEvent ?? event;
            if (!drag || drag.pointerId !== nativeEvent.pointerId) return;
            const dx = nativeEvent.clientX - drag.startX;
            const dy = nativeEvent.clientY - drag.startY;
            if (!drag.moved && Math.abs(dx) < 4 && Math.abs(dy) < 4) return;
            drag.moved = true;
            event.preventDefault?.();
            const next = clampPosition(drag.x + dx, drag.y + dy);
            positionRef.current = next;
            setPosition(next);
          },
          onPointerUp: (event: any) => {
            const nativeEvent = event.nativeEvent ?? event;
            if (webPointerRef.current?.pointerId === nativeEvent.pointerId) {
              webPointerRef.current = null;
            }
          },
          onPointerCancel: () => {
            webPointerRef.current = null;
          },
        } as any)
      : {};

  if (!visible) return null;

  return (
    <View
      pointerEvents="auto"
      {...webDragHandlers}
      onLayout={(event) => {
        const { width, height } = event.nativeEvent.layout;
        if (width !== dockSize.width || height !== dockSize.height) {
          setDockSize({ width, height });
        }
      }}
      {...panResponder.panHandlers}
      style={{
        position: Platform.OS === "web" ? "fixed" : "absolute",
        top: renderedPosition.y,
        left: renderedPosition.x,
        zIndex: 40,
        flexDirection: "row",
        alignItems: "center",
        gap: DOCK_GAP,
        cursor: "grab",
        userSelect: "none",
      }}
    >
      <Pressable
        testID="profile-cloud-buy-close"
        hitSlop={8}
        onPress={() => setVisible(false)}
        style={{
          width: 28,
          height: 28,
          borderRadius: 14,
          backgroundColor: "#fff",
          borderWidth: 1,
          borderColor: Colors.screen.hairline,
          alignItems: "center",
          justifyContent: "center",
          ...Shadows.raisedSm,
        }}
      >
        <X size={14} color="#5E5F5E" strokeWidth={2.4} />
      </Pressable>
      <Pressable
        onPress={() => router.push("/(tabs)/points" as never)}
        style={{
          height: 32,
          paddingHorizontal: 12,
          borderRadius: 16,
          backgroundColor: "#fff",
          borderWidth: 1,
          borderColor: "rgba(4,168,174,0.35)",
          alignItems: "center",
          justifyContent: "center",
          ...Shadows.raisedSm,
        }}
      >
        <Text style={{ color: TEAL, fontSize: 12, fontWeight: "800" }}>
          {t("pointsMall.goCloudBuyHome")}
        </Text>
      </Pressable>
    </View>
  );
}
