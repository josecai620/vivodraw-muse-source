import React from "react";
import { ScrollView, Text, View } from "react-native";
import { useTranslation } from "react-i18next";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

export default function CommissionRulesScreen() {
  const { t } = useTranslation();

  const sections = [1, 2, 3, 4, 5, 6].map((i) => ({
    title: t(`commission.rulesPage.section${i}Title`),
    body: t(`commission.rulesPage.section${i}Body`),
  }));

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("commission.rulesPage.title")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
        showsVerticalScrollIndicator={false}
      >
        <View className="bg-white rounded-2xl p-5 mb-4 border border-gray-100">
          <Text
            className="text-sm"
            style={{ color: Colors.neutral[600], lineHeight: s(22) }}
          >
            {t("commission.rulesPage.intro")}
          </Text>
        </View>

        {sections.map((section, i) => (
          <View
            key={i}
            className="bg-white rounded-2xl p-5 mb-3 border border-gray-100"
          >
            <Text
              className="font-semibold mb-2"
              style={{ color: Colors.neutral[800], fontSize: s(15) }}
            >
              {section.title}
            </Text>
            <Text
              className="text-sm"
              style={{ color: Colors.neutral[600], lineHeight: s(22) }}
            >
              {section.body}
            </Text>
          </View>
        ))}

        <Text
          className="text-xs text-center mt-4"
          style={{ color: Colors.neutral[500] }}
        >
          {t("commission.rulesPage.contact")}
        </Text>
      </ScrollView>
    </View>
  );
}
