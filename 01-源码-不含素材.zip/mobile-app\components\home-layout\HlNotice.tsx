import React, { useEffect, useMemo, useRef, useState } from "react";
import { Animated, Easing, Pressable, Text, View } from "react-native";
import { Megaphone } from "lucide-react-native";
import { Colors, Shadows, s } from "@/constants/theme";
import { pickLang } from "./utils";

const NOTICE_HEIGHT = s(18);

interface HlNoticeProps {
  props: {
    icon?: string;
    text?: { en?: string; zh?: string } | string | Array<{ en?: string; zh?: string } | string>;
    items?: Array<{ text?: { en?: string; zh?: string } | string; link?: string } | { en?: string; zh?: string } | string>;
    link?: string;
  };
  lang: string;
  onLink: (link: string) => void;
}

function normalizeNotices(props: HlNoticeProps["props"], lang: string) {
  const source = props.items?.length ? props.items : Array.isArray(props.text) ? props.text : [props.text];
  return source
    .map((item) => {
      if (typeof item === "object" && item && "text" in item) {
        return { text: pickLang(item.text, lang), link: item.link || props.link || "" };
      }
      return { text: pickLang(item as any, lang), link: props.link || "" };
    })
    .filter((item) => !!item.text);
}

export default function HlNotice({ props, lang, onLink }: HlNoticeProps) {
  const notices = useMemo(() => normalizeNotices(props, lang), [props, lang]);
  const [index, setIndex] = useState(0);
  const [tickerWidth, setTickerWidth] = useState(0);
  const [textWidth, setTextWidth] = useState(0);
  const pageY = useRef(new Animated.Value(0)).current;
  const marqueeX = useRef(new Animated.Value(0)).current;

  const current = notices[index % notices.length];
  const next = notices[(index + 1) % notices.length];
  const overflow = Math.max(0, textWidth - tickerWidth);
  const isLong = overflow > s(8);

  useEffect(() => {
    setIndex(0);
  }, [notices.length, lang]);

  useEffect(() => {
    pageY.setValue(0);
    if (notices.length <= 1) return;
    const delay = isLong ? Math.min(Math.max(overflow * 45 + 1600, 5000), 12000) : 3000;
    const timer = setTimeout(() => {
      Animated.timing(pageY, {
        toValue: -NOTICE_HEIGHT,
        duration: 280,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }).start(() => {
        pageY.setValue(0);
        setIndex((prev) => (prev + 1) % notices.length);
      });
    }, delay);
    return () => clearTimeout(timer);
  }, [index, isLong, notices.length, overflow, pageY]);

  useEffect(() => {
    marqueeX.stopAnimation();
    marqueeX.setValue(0);
    if (!isLong) return;
    const animation = Animated.loop(
      Animated.sequence([
        Animated.delay(600),
        Animated.timing(marqueeX, {
          toValue: -overflow,
          duration: Math.min(Math.max(overflow * 45, 4200), 10000),
          easing: Easing.linear,
          useNativeDriver: true,
        }),
        Animated.delay(700),
        Animated.timing(marqueeX, {
          toValue: 0,
          duration: 0,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
      ])
    );
    animation.start();
    return () => animation.stop();
  }, [index, isLong, marqueeX, overflow]);

  if (!current?.text) return null;

  const activeLink = current.link || props.link;
  const Container: any = activeLink ? Pressable : View;
  return (
    <Container
      onPress={() => activeLink && onLink(activeLink)}
      className="flex-row items-center"
      style={{
        marginHorizontal: s(16),
        marginTop: s(10),
        height: s(36),
        paddingHorizontal: s(13),
        borderRadius: s(18),
        backgroundColor: Colors.primary.softer,
        borderWidth: 1,
        borderColor: Colors.screen.hairline,
        gap: s(8),
        ...Shadows.raisedSm,
      }}
    >
      {/* 方向 C：统一黑色线性图标体系，忽略后端下发的彩色 emoji，恒用 teal 线性 Megaphone */}
      <Megaphone size={s(14)} color={Colors.primary.DEFAULT} strokeWidth={2.1} />
      <View
        style={{ flex: 1, height: NOTICE_HEIGHT, overflow: "hidden" }}
        onLayout={(event) => setTickerWidth(event.nativeEvent.layout.width)}
      >
        <Animated.View style={{ transform: [{ translateY: pageY }] }}>
          {[current, next].map((item, itemIndex) => (
            <View key={`${index}-${itemIndex}`} style={{ height: NOTICE_HEIGHT, justifyContent: "center", overflow: "hidden" }}>
              <Animated.Text
                numberOfLines={1}
                onLayout={(event) => itemIndex === 0 && setTextWidth(event.nativeEvent.layout.width)}
                style={{
                  alignSelf: "flex-start",
                  color: "#2C2E2D",
                  fontSize: s(12),
                  fontWeight: "600",
                  lineHeight: NOTICE_HEIGHT,
                  transform: itemIndex === 0 ? [{ translateX: marqueeX }] : undefined,
                }}
              >
                {item?.text}
              </Animated.Text>
            </View>
          ))}
        </Animated.View>
      </View>
    </Container>
  );
}
