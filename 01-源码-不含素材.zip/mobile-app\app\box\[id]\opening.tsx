/**
 * 盲盒开启动画 — Premium 4-stage animation with rarity-scaled VFX
 */
import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { View, Text, Pressable, ActivityIndicator, type ImageSourcePropType } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import Animated, {
  useSharedValue, useAnimatedStyle,
  withSequence, withTiming, withRepeat, withSpring,
  Easing, runOnJS,
} from "react-native-reanimated";
import { ArrowLeft, Package, ShoppingBag, Share2 } from "lucide-react-native";
import { useRevealColorScheme } from "@/contexts/RevealColorSchemeContext";
import { addBox } from "@/lib/api/box";
import { useTrackBoxTaskEvent } from "@/hooks";
import { useAppStore } from "@/store/app";

import { BoxActionButton, RarityBadge, BoxChestVFX } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  getRarityTier, bs, type RarityTier,
} from "@/lib/boxTheme";

type Stage = "shake" | "crack" | "reveal" | "result";
type OpenedItem = { id: number; name: string; image: string; rarity: string };

const FALLBACK_OPENING_CHESTS: ImageSourcePropType[] = [
  require("../../../assets/box-category-chests/auto-accessories.png"),
  require("../../../assets/box-category-chests/fashion-shoes.png"),
  require("../../../assets/box-category-chests/electronics.png"),
  require("../../../assets/box-category-chests/beauty-skincare.png"),
  require("../../../assets/box-category-chests/outdoor-sports.png"),
  require("../../../assets/box-category-chests/home-living.png"),
  require("../../../assets/box-category-chests/jewelry.png"),
  require("../../../assets/box-category-chests/apple-products.png"),
];

const FALLBACK_OPENING_CHEST_BY_ID: Record<number, ImageSourcePropType> = {
  310: require("../../../assets/box-category-chests/home-living.png"),
  311: require("../../../assets/box-category-chests/electronics.png"),
  312: require("../../../assets/box-category-chests/apple-products.png"),
  95: require("../../../assets/box-category-chests/auto-accessories.png"),
  94: require("../../../assets/box-category-chests/fashion-shoes.png"),
  92: require("../../../assets/box-category-chests/electronics.png"),
  91: require("../../../assets/box-category-chests/beauty-skincare.png"),
  90: require("../../../assets/box-category-chests/outdoor-sports.png"),
  89: require("../../../assets/box-category-chests/home-living.png"),
  88: require("../../../assets/box-category-chests/jewelry.png"),
  87: require("../../../assets/box-category-chests/apple-products.png"),
};

function isRemoteImage(value?: string) {
  return !!value && /^https?:\/\//i.test(value);
}

function normalizeRarity(raw: unknown): string {
  const map: Record<string, string> = {
    "1": "common", "2": "uncommon", "3": "rare",
    "4": "epic", "5": "legendary", "6": "secret",
    common: "common", uncommon: "uncommon", rare: "rare",
    epic: "epic", legendary: "legendary", secret: "secret",
  };
  return map[String(raw ?? "common")] || "common";
}

const SHAKE_INTENSITY: Record<string, number> = {
  common: 8, uncommon: 12, rare: 16, epic: 22, legendary: 28, secret: 36,
};

function getOpeningChestImage(boxId: number) {
  if (FALLBACK_OPENING_CHEST_BY_ID[boxId]) return FALLBACK_OPENING_CHEST_BY_ID[boxId];
  return FALLBACK_OPENING_CHESTS[Math.abs(boxId || 0) % FALLBACK_OPENING_CHESTS.length];
}

export default function BoxOpeningScreen() {
  const { t } = useTranslation();
  const { id, num, result } = useLocalSearchParams<{ id?: string; num?: string; result?: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { colors } = useRevealColorScheme();
  const showToast = useAppStore((s) => s.showToast);
  const trackTask = useTrackBoxTaskEvent();

  const [stage, setStage] = useState<Stage>("shake");
  const [showResult, setShowResult] = useState(false);
  const [openedItem, setOpenedItem] = useState<OpenedItem | null>(null);
  const [apiError, setApiError] = useState<string | null>(null);
  const [isResolvingResult, setIsResolvingResult] = useState(false);

  const shakeX = useSharedValue(0);
  const shakeY = useSharedValue(0);
  const boxScale = useSharedValue(1);
  const crackScale = useSharedValue(1);
  const crackOpacity = useSharedValue(1);
  const revealScale = useSharedValue(0.3);
  const revealOpacity = useSharedValue(0);
  const glowScale = useSharedValue(0.5);
  const glowOpacity = useSharedValue(0);
  const resultCardScale = useSharedValue(0.8);
  const resultCardOpacity = useSharedValue(0);

  useEffect(() => {
    const parsedId = Number(id || 0);
    if (parsedId <= 0) { setApiError(t("opening.invalidId")); return; }

    if (result) {
      try {
        const raw = JSON.parse(decodeURIComponent(String(result)));
        setOpenedItem({
          id: Number(raw?.id || 0),
          name: String(raw?.name || t("opening.fallbackItem")),
          image: String(raw?.image || ""),
          rarity: normalizeRarity(raw?.rarity || raw?.level),
        });
        return;
      } catch { /* fall through to API */ }
    }

    let cancelled = false;
    setIsResolvingResult(true);
    addBox({ id: parsedId, num: Number(num || 1) })
      .then((res: any) => {
        if (cancelled) return;
        const data = res?.data ?? res;
        const rawItem = Array.isArray(data) ? data[0] : Array.isArray(data?.list) ? data.list[0] : data;
        setOpenedItem({
          id: Number(rawItem?.id || 0),
          name: String(rawItem?.name || rawItem?.item_name || t("opening.fallbackItem")),
          image: String(rawItem?.image || rawItem?.item_image || ""),
          rarity: normalizeRarity(rawItem?.rarity || rawItem?.level),
        });
      })
      .catch((error: any) => {
        if (cancelled) return;
        setApiError(error?.message || t("opening.failRetry"));
        showToast(error?.message || t("opening.failRetry"), "error");
      })
      .finally(() => { if (!cancelled) setIsResolvingResult(false); });
    return () => { cancelled = true; };
  }, [id, num, result, showToast, t]);

  const item = openedItem || { id: 0, name: t("opening.titleInProgress"), image: "", rarity: "common" };
  const rarity = getRarityTier(item.rarity);
  const intensity = SHAKE_INTENSITY[item.rarity] || 12;
  const openingChestImage = getOpeningChestImage(Number(id || 0));

  // Stage: SHAKE
  useEffect(() => {
    if (stage !== "shake") return;
    boxScale.value = withSpring(1, { damping: 8, stiffness: 200 });
    shakeX.value = withRepeat(
      withSequence(
        withTiming(-intensity, { duration: 60, easing: Easing.linear }),
        withTiming(intensity, { duration: 60, easing: Easing.linear }),
        withTiming(-intensity * 0.7, { duration: 60, easing: Easing.linear }),
        withTiming(intensity * 0.7, { duration: 60, easing: Easing.linear }),
        withTiming(0, { duration: 60, easing: Easing.linear }),
      ), 4, false, () => runOnJS(setStage)("crack")
    );
    shakeY.value = withRepeat(
      withSequence(
        withTiming(-intensity * 0.3, { duration: 70 }),
        withTiming(intensity * 0.3, { duration: 70 }),
        withTiming(0, { duration: 60 }),
      ), 4, false
    );
  }, [stage, intensity]);

  // Stage: CRACK
  useEffect(() => {
    if (stage !== "crack") return;
    shakeX.value = 0;
    shakeY.value = 0;
    crackScale.value = withTiming(1, { duration: 1 });
    crackOpacity.value = withSequence(
      withTiming(1, { duration: 250 }),
      withTiming(0.18, { duration: 360 }, () => {
        runOnJS(setStage)("reveal");
      }),
    );
  }, [stage]);

  // Stage: REVEAL
  useEffect(() => {
    if (stage !== "reveal") return;
    revealOpacity.value = withTiming(1, { duration: 300 });
    revealScale.value = withSequence(
      withSpring(1.15, { damping: 8, stiffness: 120 }),
      withSpring(1, { damping: 12 })
    );
    glowOpacity.value = withTiming(0.6, { duration: 500 });
    glowScale.value = withTiming(1.5, { duration: 800, easing: Easing.out(Easing.ease) });
    const timer = setTimeout(() => {
      setShowResult(true);
      setStage("result");
    }, 920);
    return () => clearTimeout(timer);
  }, [stage]);

  // Stage: RESULT
  useEffect(() => {
    if (stage !== "result") return;
    resultCardScale.value = withSpring(1, { damping: 12, stiffness: 100 });
    resultCardOpacity.value = withTiming(1, { duration: 400 });
  }, [stage]);

  const shakeStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: shakeX.value }, { translateY: shakeY.value }],
  }));
  const crackStyle = useAnimatedStyle(() => ({
    opacity: crackOpacity.value,
  }));
  const revealStyle = useAnimatedStyle(() => ({
    transform: [{ scale: revealScale.value }],
    opacity: revealOpacity.value,
  }));
  const glowStyle = useAnimatedStyle(() => ({
    transform: [{ scale: glowScale.value }],
    opacity: glowOpacity.value,
  }));
  const resultStyle = useAnimatedStyle(() => ({
    transform: [{ scale: resultCardScale.value }],
    opacity: resultCardOpacity.value,
  }));

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      {/* Header */}
      <LinearGradient
        colors={BoxGradients.headerDark}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          paddingTop: insets.top + 12, paddingBottom: 16, paddingHorizontal: BoxSpacing.lg,
          flexDirection: "row", alignItems: "center", justifyContent: "space-between",
          borderBottomWidth: 1, borderBottomColor: BoxBorders.subtle,
        }}
      >
        <Pressable onPress={() => router.back()} hitSlop={12} style={{ padding: BoxSpacing.xs }}>
          <ArrowLeft size={bs(22)} color={BoxText.primary} />
        </Pressable>
        <Text style={[BoxTypography.h3, { color: BoxText.primary }]}>
          {stage === "result" ? t("opening.titleDone") : t("opening.titleInProgress")}
        </Text>
        <View style={{ width: bs(30) }} />
      </LinearGradient>

      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", paddingHorizontal: BoxSpacing["2xl"] }}>
        {!showResult ? (
          <>
            {/* Glow backdrop */}
            <Animated.View style={[{
              position: "absolute", width: bs(220), height: bs(220),
              borderRadius: bs(110), backgroundColor: rarity.glow,
            }, glowStyle]} />

            {/* Shake + Crack stages */}
            {(stage === "shake" || stage === "crack") && (
              <Animated.View style={shakeStyle}>
                <Animated.View style={[{ alignItems: "center", justifyContent: "center" }, crackStyle]}>
                  {stage === "crack" && (
                    <View
                      style={{
                        position: "absolute",
                        width: bs(184),
                        height: bs(184),
                        borderRadius: bs(92),
                        backgroundColor: rarity.glow,
                        opacity: 0.78,
                      }}
                    />
                  )}
                  <BoxChestVFX image={openingChestImage} tier={item.rarity || "legendary"} size={186} />
                  {stage === "crack" && (
                    <LinearGradient
                      colors={["transparent", "rgba(51,198,204,0.55)", "transparent"]}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={{
                        position: "absolute",
                        width: bs(42),
                        height: bs(210),
                        borderRadius: bs(40),
                        transform: [{ rotate: "-18deg" }],
                      }}
                    />
                  )}
                </Animated.View>
              </Animated.View>
            )}

            {/* Reveal stage */}
            {(stage === "reveal" || (stage === "result" && !showResult)) && (
              <Animated.View style={[{ alignItems: "center" }, revealStyle]}>
                <View style={{
                  width: bs(160), height: bs(160), borderRadius: bs(80),
                  alignItems: "center", justifyContent: "center",
                }}>
                  <View style={{
                    position: "absolute", width: bs(160), height: bs(160), borderRadius: bs(80),
                    borderWidth: 3, borderColor: rarity.color, opacity: 0.4,
                  }} />
                  <View style={{
                    position: "absolute", width: bs(160), height: bs(160), borderRadius: bs(80),
                    backgroundColor: rarity.glow, opacity: 0.15,
                  }} />
                  <View style={{
                    width: bs(120), height: bs(120), borderRadius: bs(60),
                    borderWidth: 3, borderColor: rarity.color,
                    backgroundColor: BoxSurfaces.deep,
                    alignItems: "center", justifyContent: "center",
                    ...BoxShadows.neon(rarity.color),
                  }}>
                    {isRemoteImage(item.image) ? (
                      <Image source={{ uri: item.image }} style={{ width: bs(88), height: bs(88), borderRadius: bs(44) }} contentFit="cover" />
                    ) : (
                      <Package size={bs(48)} color={rarity.color} />
                    )}
                  </View>
                </View>
              </Animated.View>
            )}

            {stage !== "result" && !apiError && (
              <Text style={[BoxTypography.h3, { color: BoxText.secondary, marginTop: bs(32) }]}>
                {stage === "shake" && t("opening.stageShake")}
                {stage === "crack" && t("opening.stageCrack")}
                {stage === "reveal" && t("opening.stageReveal")}
              </Text>
            )}

            {isResolvingResult && (
              <View style={{ marginTop: BoxSpacing.lg, alignItems: "center", gap: BoxSpacing.sm }}>
                <ActivityIndicator color={BoxAccent.gold} />
                <Text style={[BoxTypography.caption, { color: BoxText.secondary }]}>{t("opening.fetchingResult")}</Text>
              </View>
            )}

            {!!apiError && (
              <View style={{ marginTop: BoxSpacing.xl, width: "100%", alignItems: "center", gap: BoxSpacing.md }}>
                <Text style={[BoxTypography.body, { color: BoxAccent.red, textAlign: "center" }]}>{apiError}</Text>
                <BoxActionButton
                  title={t("opening.backToBox")}
                  variant="secondary"
                  compact
                  onPress={() => router.replace(`/box/${id}`)}
                  style={{ minWidth: bs(160) }}
                />
              </View>
            )}
          </>
        ) : (
          <Animated.View style={[{ alignItems: "center", width: "100%" }, resultStyle]}>
            {/* Result Card */}
            <View style={{
              width: "100%", padding: BoxSpacing["3xl"], borderRadius: BoxRadius["3xl"],
              backgroundColor: BoxSurfaces.card, borderWidth: 1, borderColor: BoxBorders.default,
              alignItems: "center", marginBottom: BoxSpacing["3xl"],
              ...BoxShadows.elevated,
            }}>
              {/* Outer glow ring — matches Figma's prominent halo */}
              <View style={{
                width: bs(160), height: bs(160), borderRadius: bs(80),
                alignItems: "center", justifyContent: "center",
                marginBottom: BoxSpacing.xl,
              }}>
                <View style={{
                  position: "absolute", width: bs(160), height: bs(160), borderRadius: bs(80),
                  borderWidth: 3, borderColor: rarity.color,
                  opacity: 0.35,
                }} />
                <View style={{
                  position: "absolute", width: bs(150), height: bs(150), borderRadius: bs(75),
                  borderWidth: 2, borderColor: rarity.color,
                  opacity: 0.2,
                }} />
                <View style={{
                  position: "absolute", width: bs(160), height: bs(160), borderRadius: bs(80),
                  backgroundColor: rarity.glow, opacity: 0.15,
                }} />
                <View style={{
                  width: bs(120), height: bs(120), borderRadius: bs(60),
                  borderWidth: 3, borderColor: rarity.color,
                  backgroundColor: BoxSurfaces.deep,
                  alignItems: "center", justifyContent: "center",
                  ...BoxShadows.neon(rarity.color),
                }}>
                  {isRemoteImage(item.image) ? (
                    <Image source={{ uri: item.image }} style={{ width: bs(88), height: bs(88), borderRadius: bs(44) }} contentFit="cover" />
                  ) : (
                    <Package size={bs(48)} color={rarity.color} />
                  )}
                </View>
              </View>
              <Text style={[BoxTypography.h1, { color: BoxText.primary, textAlign: "center", marginBottom: BoxSpacing.md }]}>
                {item.name}
              </Text>
              <RarityBadge tier={item.rarity} size="lg" />
            </View>

            {/* Action buttons */}
            <View style={{ width: "100%", gap: BoxSpacing.md }}>
              <Pressable
                onPress={() => {
                  const text = t("opening.shareText", { item: item.name, rarity: rarity.label });
                  trackTask.mutate({ event: "share", ref: String(id || item.id || "") });
                  try {
                    if (typeof navigator !== "undefined" && navigator.share) {
                      navigator.share({ title: t("opening.shareTitle"), text });
                    } else if (typeof navigator !== "undefined" && navigator.clipboard) {
                      navigator.clipboard.writeText(text);
                      showToast(t("opening.shareCopied"), "success");
                    }
                  } catch { showToast(t("opening.shareCopied"), "success"); }
                }}
                style={({ pressed }) => ({
                  height: bs(52), borderRadius: BoxRadius.xl, borderWidth: 2,
                  borderColor: rarity.color, backgroundColor: rarity.bgSubtle,
                  flexDirection: "row", alignItems: "center", justifyContent: "center", gap: BoxSpacing.sm,
                  transform: [{ scale: pressed ? 0.96 : 1 }],
                })}
              >
                <Share2 size={bs(18)} color={rarity.color} />
                <Text style={[BoxTypography.button, { color: rarity.color }]}>{t("opening.shareBtn")}</Text>
              </Pressable>

              <BoxActionButton
                title={t("opening.viewBackpack")}
                icon={<ShoppingBag size={bs(20)} color={BoxText.onGold} />}
                onPress={() => router.push("/box/backpack")}
              />
              <BoxActionButton
                title={t("opening.openAgain")}
                variant="secondary"
                icon={<Package size={bs(20)} color={BoxText.primary} />}
                onPress={() => router.replace(`/box/${id}`)}
              />
            </View>
          </Animated.View>
        )}
      </View>
    </View>
  );
}
