import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useRevealLists } from "@/hooks/usePoints";
import { normalizeImageUrl } from "@/lib/utils";

const TEAL = Colors.primary.DEFAULT;

export default function RevealHistoryScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState<any[]>([]);
  const { data, isLoading, isFetching } = useRevealLists({ page, limit: 20 });

  const mapped = useMemo(() => {
    const list = (data as any)?.data?.lists ?? (data as any)?.lists ?? [];
    return (Array.isArray(list) ? list : [])
      .map((item: any) => ({
        id: Number(item.id ?? 0),
        name: String(item.store_name ?? ""),
        image: normalizeImageUrl(String(item.image ?? "")),
        period: String(item.bianhao ?? ""),
        winner: String(item.nickname ?? ""),
        code: String(item.zj_unique ?? ""),
        time: String(item.zhongjiang_time ?? ""),
      }))
      .filter((row: { id: number }) => row.id > 0);
  }, [data]);

  useEffect(() => {
    setRows((prev) => {
      if (page === 1) return mapped;
      const seen = new Set(prev.map((row) => row.id));
      return [...prev, ...mapped.filter((row) => !seen.has(row.id))];
    });
  }, [mapped, page]);

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.latestReveal")} />
      <ScrollView contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) }}>
        {isLoading && rows.length === 0 ? (
          <ActivityIndicator color={TEAL} style={{ marginTop: 40 }} />
        ) : rows.length === 0 ? (
          <Text className="text-center text-gray-400 py-16">{t("pointsMall.noHistoryYet")}</Text>
        ) : (
          rows.map((row) => (
            <Pressable
              key={row.id}
              className="flex-row bg-white px-3 py-3 border-b border-gray-100"
              onPress={() => router.push(`/reveal/${row.id}` as never)}
            >
              <View className="w-16 h-16 bg-gray-50 rounded overflow-hidden mr-3">
                {row.image ? <Image source={row.image} style={{ width: 64, height: 64 }} contentFit="contain" /> : null}
              </View>
              <View className="flex-1">
                <Text className="text-[11px]" style={{ color: TEAL }}>
                  {t("pointsMall.periodN", { n: row.period || "-" })}
                </Text>
                <Text className="text-sm text-gray-900 mt-0.5" numberOfLines={2}>
                  {row.name}
                </Text>
                <Text className="text-xs text-gray-500 mt-1">
                  {t("pointsMall.winnerLabel")}：{row.winner || t("pointsMall.anonymous")}
                </Text>
                {row.code ? (
                  <Text className="text-xs font-mono mt-0.5" style={{ color: TEAL }}>
                    {t("pointsMall.luckyCode")} {row.code}
                  </Text>
                ) : null}
              </View>
            </Pressable>
          ))
        )}
        {rows.length > 0 ? (
          <Pressable
            className="mx-3 my-4 h-10 rounded items-center justify-center border"
            style={{ borderColor: TEAL }}
            onPress={() => setPage((p) => p + 1)}
            disabled={isFetching}
          >
            <Text className="text-sm font-bold" style={{ color: TEAL }}>
              {isFetching ? t("common.loading") : t("pointsMall.viewMoreHistory")}
            </Text>
          </Pressable>
        ) : null}
      </ScrollView>
      <PointsMallTabBar />
    </View>
  );
}
