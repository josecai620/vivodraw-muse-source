/**
 * Box Mall Design System — Direction C「轻立体 soft-UI」
 *
 * 冷灰页面底 + 纯白浮卡柔影 + 单一 teal 强调色 + 墨黑线性图标。
 * All box pages MUST import tokens from here.
 * Zero hardcoded colors in page files.
 *
 * 历史命名说明：gold / purple 等字段名保留（避免大面积改名），
 * 其值已全部映射为 teal 同色系或中性墨灰，不代表真实金/紫色。
 */
import { Dimensions, type TextStyle, type ViewStyle } from "react-native";
import { Fonts } from "@/constants/theme";

const BASE_WIDTH = 390;
const scale = () => {
  const { width } = Dimensions.get("window");
  return Math.min(Math.max(width / BASE_WIDTH, 1), 1.16);
};
export const bs = (size: number) => Math.round(size * scale());

// ─── Surface Palette (light, layered depth) ──────────────

export const BoxSurfaces = {
  void: "#F5F7F7",      // 页面底（极浅冷灰）
  deep: "#F6F8F8",      // 页面底/卡内浅灰分层
  card: "#FFFFFF",      // 纯白浮卡
  elevated: "#F7F9F9",  // 卡内小块
  glass: "rgba(255,255,255,0.72)",
  shimmer: "rgba(12,31,31,0.02)",
} as const;

// ─── Accent Palette（单一 teal，语义红除外）──────────────

export const BoxAccent = {
  gold: "#04A8AE",
  goldLight: "#33C6CC",
  goldDark: "#07858C",
  goldMuted: "rgba(4,168,174,0.12)",
  goldDim: "rgba(4,168,174,0.07)",
  goldBorder: "rgba(4,168,174,0.25)",
  purple: "#04A8AE",
  purpleLight: "#33C6CC",
  purpleDark: "#07858C",
  purpleMuted: "rgba(4,168,174,0.12)",
  purpleBorder: "rgba(4,168,174,0.30)",
  red: "#EF4444",
  redMuted: "rgba(239,68,68,0.12)",
  green: "#04A8AE",
  greenMuted: "rgba(4,168,174,0.12)",
  blue: "#787976",
  blueMuted: "rgba(120,121,118,0.12)",
} as const;

// ─── Text Colors（墨黑系，teal 强调）─────────────────────

export const BoxText = {
  primary: "#171A1A",
  secondary: "#5E5F5E",
  tertiary: "#787976",
  disabled: "#AAAAA8",
  gold: "#04A8AE",
  onGold: "#FFFFFF",
  onPurple: "#FFFFFF",
} as const;

// ─── Border Colors（极细冷边）────────────────────────────

export const BoxBorders = {
  default: "rgba(12,31,31,0.08)",
  subtle: "rgba(12,31,31,0.05)",
  accent: "rgba(4,168,174,0.25)",
  strong: "rgba(12,31,31,0.12)",
} as const;

// ─── Gradient Presets ────────────────────────────────────

export const BoxGradients = {
  headerDark: ["#FFFFFF", "#F6F8F8"] as [string, string],
  cardSubtle: ["#FFFFFF", "#F6F8F8"] as [string, string],
  goldCta: ["#33C6CC", "#08AEB4", "#07858C"] as [string, string, string],
  goldWarm: ["rgba(4,168,174,0.14)", "rgba(4,168,174,0.04)"] as [string, string],
  purpleEvent: ["#08AEB4", "#07858C"] as [string, string],
  purpleDeep: ["#07858C", "#33C6CC"] as [string, string],
  hotPick: ["rgba(4,168,174,0.14)", "rgba(4,168,174,0.04)"] as [string, string],
  newbieGold: ["#08AEB4", "#07858C"] as [string, string],
  surface: ["#FFFFFF", "#F6F8F8"] as [string, string],
  void: ["#F5F7F7", "#F6F8F8"] as [string, string],
} as const;

// ─── Rarity Tier System（白底：中性明度阶梯，secret=teal）─

export type RarityTier = "common" | "uncommon" | "rare" | "epic" | "legendary" | "secret";

export interface RarityConfig {
  label: string;
  color: string;
  gradient: [string, string];
  glow: string;
  bgSubtle: string;
  borderColor: string;
}

export const RarityTiers: Record<RarityTier, RarityConfig> = {
  common: {
    label: "Common",
    color: "#AAAAA8",
    gradient: ["#C0C0BE", "#AAAAA8"],
    glow: "rgba(170,170,168,0.30)",
    bgSubtle: "rgba(120,121,118,0.08)",
    borderColor: "rgba(120,121,118,0.20)",
  },
  uncommon: {
    label: "Uncommon",
    color: "#787976",
    gradient: ["#919290", "#787976"],
    glow: "rgba(120,121,118,0.30)",
    bgSubtle: "rgba(120,121,118,0.08)",
    borderColor: "rgba(120,121,118,0.22)",
  },
  rare: {
    label: "Rare",
    color: "#4A4A48",
    gradient: ["#5E5F5E", "#4A4A48"],
    glow: "rgba(74,74,72,0.28)",
    bgSubtle: "rgba(74,74,72,0.07)",
    borderColor: "rgba(74,74,72,0.22)",
  },
  epic: {
    label: "Epic",
    color: "#2C2E2D",
    gradient: ["#4A4A48", "#2C2E2D"],
    glow: "rgba(44,46,45,0.28)",
    bgSubtle: "rgba(44,46,45,0.07)",
    borderColor: "rgba(44,46,45,0.24)",
  },
  legendary: {
    label: "Legendary",
    color: "#171A1A",
    gradient: ["#2C2E2D", "#171A1A"],
    glow: "rgba(23,26,26,0.26)",
    bgSubtle: "rgba(23,26,26,0.06)",
    borderColor: "rgba(23,26,26,0.24)",
  },
  secret: {
    label: "Secret",
    color: "#04A8AE",
    gradient: ["#33C6CC", "#07858C"],
    glow: "rgba(4,168,174,0.35)",
    bgSubtle: "rgba(4,168,174,0.10)",
    borderColor: "rgba(4,168,174,0.25)",
  },
};

export function getRarityTier(key?: string): RarityConfig {
  if (!key) return RarityTiers.common;
  const normalized = key.toLowerCase().trim();
  return RarityTiers[normalized as RarityTier] ?? RarityTiers.common;
}

export const RARITY_ORDER: RarityTier[] = ["common", "uncommon", "rare", "epic", "legendary", "secret"];

// ─── Typography ──────────────────────────────────────────

export const BoxTypography: Record<string, TextStyle> = {
  hero: { fontFamily: Fonts.display, fontSize: bs(36), lineHeight: bs(42), fontWeight: "400" },
  h1: { fontFamily: Fonts.display, fontSize: bs(28), lineHeight: bs(34), fontWeight: "400" },
  h2: { fontFamily: Fonts.display, fontSize: bs(24), lineHeight: bs(30), fontWeight: "400" },
  h3: { fontFamily: Fonts.display, fontSize: bs(21), lineHeight: bs(27), fontWeight: "400" },
  body: { fontFamily: Fonts.sans, fontSize: bs(14), lineHeight: bs(20), fontWeight: "400" },
  bodyBold: { fontFamily: Fonts.sans, fontSize: bs(14), lineHeight: bs(20), fontWeight: "700" },
  caption: { fontFamily: Fonts.sans, fontSize: bs(12), lineHeight: bs(16), fontWeight: "600" },
  micro: { fontFamily: Fonts.sans, fontSize: bs(10), lineHeight: bs(14), fontWeight: "700" },
  price: { fontFamily: Fonts.sans, fontSize: bs(18), lineHeight: bs(24), fontWeight: "700" },
  priceHero: { fontFamily: Fonts.sans, fontSize: bs(28), lineHeight: bs(36), fontWeight: "800" },
  button: { fontFamily: Fonts.sans, fontSize: bs(16), lineHeight: bs(24), fontWeight: "700" },
  buttonSmall: { fontFamily: Fonts.sans, fontSize: bs(14), lineHeight: bs(20), fontWeight: "600" },
};

// ─── Spacing ─────────────────────────────────────────────

export const BoxSpacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  "2xl": 24,
  "3xl": 32,
  "4xl": 48,
} as const;

// ─── Border Radius ───────────────────────────────────────

export const BoxRadius = {
  sm: 6,
  md: 10,
  lg: 14,
  xl: 18,
  "2xl": 22,
  "3xl": 28,
  full: 9999,
} as const;

// ─── Shadows（冷青墨极柔投影）─────────────────────────────

export const BoxShadows = {
  card: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 3,
  } as ViewStyle,
  raisedSm: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  } as ViewStyle,
  elevated: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.075,
    shadowRadius: 20,
    elevation: 5,
  } as ViewStyle,
  glow: (color: string): ViewStyle => ({
    shadowColor: color,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 18,
    elevation: 6,
  }),
  neon: (color: string): ViewStyle => ({
    shadowColor: color,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.38,
    shadowRadius: 26,
    elevation: 10,
  }),
  subtle: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  } as ViewStyle,
};

// ─── Animation Constants ─────────────────────────────────

export const BoxAnimation = {
  press: { scale: 0.96, duration: 100 },
  spring: { damping: 15, stiffness: 150 },
  springBouncy: { damping: 10, stiffness: 180 },
  fast: 150,
  normal: 250,
  slow: 400,
  stagger: 50,
} as const;

// ─── Layout Constants ────────────────────────────────────

export const BoxLayout = {
  maxWidth: 430,
  headerHeight: bs(56),
  tabBarHeight: bs(44),
  bottomBarHeight: bs(72),
  safeAreaBottom: bs(32),
  quickActionSize: bs(44),
  cardImageHeight: bs(128),
  avatarSmall: bs(32),
  avatarMedium: bs(40),
  avatarLarge: bs(48),
} as const;
