# API 契约快照（API Contract Snapshot）

> 按功能分组，便于联调查阅。M-B2 批次扩展。
> 标注「与代码一致」表示前端使用的返回字段与常见结构一致。

---

## auth
| 接口 | Method | Path | 请求参数 | 关键返回 | 与代码一致 |
|------|--------|------|----------|----------|------------|
| 登录 | POST | /api/login | account, password | token, expires_time | ✓ |
| 用户信息 | GET | /api/user | (Token) | uid, integral, nickname, now_money... | ✓ |
| 退出 | GET | /api/logout | (Token) | status=200 | ✓ |
| 注册 | POST | /api/register | account, captcha, password | token | ✓ |
| 验证码 key | GET | /api/verify_code | - | key, expire_time | ✓ |
| 发送验证码 | POST | /api/register/verify | phone, type, key, code | status=200 | ✓ |
| 找回密码 | POST | /api/register/reset | account, captcha, password | status=200 | ✓ |

## home
| 接口 | Method | Path | 请求参数 | 关键返回 | 与代码一致 |
|------|--------|------|----------|----------|------------|
| 首页聚合 | GET | /api/index | - | banner, menus, roll... | ✓ |
| DIY | GET | /api/diy/get_diy/:id | id=0 首页 | value(组件列表) | ✓ |
| 推荐 | GET | /api/groom/list/:type | type | list | ✓ |

## product
| 接口 | Method | Path | 请求参数 | 关键返回 | 与代码一致 |
|------|--------|------|----------|----------|------------|
| 商品列表 | GET | /api/products | page, limit, cid, keyword | list, total | ✓ |
| 商品详情 | GET | /api/product/detail/:id | - | 商品对象 | ✓ |
| 分类 | GET | /api/category | - | list | ✓ |
| 搭配套餐 | GET | /api/store_discounts/list/:productId | - | list | ✓ |

## order
| 接口 | Method | Path | 请求参数 | 关键返回 | 与代码一致 |
|------|--------|------|----------|----------|------------|
| 确认 | POST | /api/order/confirm | cartId, new, addressId? | orderKey | ✓ |
| 计算 | POST | /api/order/computed/:key | addressId, couponId... | priceGroup | ✓ |
| 创建 | POST | /api/order/create/:key | 同 computed | orderId | ✓ |
| 列表 | GET | /api/order/list | type, page, limit | list | ✓ |
| 详情 | GET | /api/order/detail/:id | - | 订单对象 | ✓ |
| 取消 | POST | /api/order/cancel | id | status=200 | ✓ |
| 售后列表 | GET | /api/order/refund/list | - | list | ✓ |
| 售后详情 | GET | /api/order/refund/detail/:uni | - | - | ✓ |

## user (address / collect / coupon)
| 接口 | Method | Path | 请求参数 | 关键返回 | 与代码一致 |
|------|--------|------|----------|----------|------------|
| 地址列表 | GET | /api/address/list | - | list | ✓ |
| 地址编辑 | POST | /api/address/edit | - | - | ✓ |
| 优惠券可领 | GET | /api/coupons | type?, product_id? | list | ✓ |
| 我的优惠券 | GET | /api/coupons/user/:types | types 0~3 | list | ✓ |
| 订单可用券 | GET | /api/coupons/order/:price | price | list | ✓ |
| 领取优惠券 | POST | /api/coupon/receive | couponId | status=200 | ✓ |

## wallet
| 接口 | Method | Path | 请求参数 | 关键返回 | 与代码一致 |
|------|--------|------|----------|----------|------------|
| 充值档位 | GET | /api/recharge/index | - | list | ✓ |
| 充值提交 | POST | /api/recharge/recharge | price, payType 等 | - | ✓ |
| 提现银行卡 | GET | /api/extract/bank | - | list | ✓ |
| 提现申请 | POST | /api/extract/cash | money, bankInfo | - | ✓ |

## article
| 接口 | Method | Path | 请求参数 | 关键返回 | 与代码一致 |
|------|--------|------|----------|----------|------------|
| 分类列表 | GET | /api/article/category/list | - | list | ✓ |
| 文章列表 | GET | /api/article/list/:cid | cid | list | ✓ |
| 文章详情 | GET | /api/article/details/:id | - | - | ✓ |
| 热门/最新 | GET | /api/article/hot/list, new/list | - | list | ✓ |

## box（盲盒）
| 接口 | Method | Path | 请求参数 | 关键返回 | 与代码一致 |
|------|--------|------|----------|----------|------------|
| 大厅 | GET | /api/manghe/hall | - | - | 待核对 |
| 橱窗 | GET | /api/manghe/shopwindow | - | - | 待核对 |
| 商城列表 | POST | /api/manghe/getBoxShop | page?, limit?, cid? | - | 待核对 |
| 开盒 | POST | /api/manghe/addBox | id, num? | - | 待核对 |
| 回收 | POST | /api/manghe/recovery | ids[] | - | 待核对 |

## points（积分）
| 接口 | Method | Path | 请求参数 | 关键返回 | 与代码一致 |
|------|--------|------|----------|----------|------------|
| 余额 | GET | /api/user | (Token) | integral | ✓ |
| 积分商城首页 | GET | /api/store_integral/index | - | - | ✓ |
| 商品列表 | GET | /api/store_integral/list | - | list | ✓ |
| 兑换 | POST | /api/integral/order/exchange | productId, num, uniqueId | - | ✓ |
| 订单收货 | POST | /api/integral/order/take | body: order_id | status=200 | ✓ |
| 订单取消 | POST | /api/integral/order/cancel | body: order_id | status=200 | ✓ |
| 签到 | POST | /api/sign/integral | - | - | ✓ |
| 抽奖信息 | GET | /api/v2/lottery/info | - | - | ✓ |
| 抽奖 | POST | /api/v2/lottery | - | - | ✓ |
| 抽奖记录 | GET | /api/v2/lottery/record | - | - | ✓ |

## marketing（秒杀/拼团/砍价/直播）
| 接口 | Method | Path | 请求参数 | 关键返回 |
|------|--------|------|----------|----------|
| 秒杀 | GET | /api/seckill/index, list/:time, detail/:id/:time | - | - |
| 拼团 | GET | /api/combination/list, detail/:id, pink/:id | - | - |
| 砍价 | GET/POST | /api/bargain/config, list, start, help | - | - |
| 直播 | GET | /api/wechat/live, livePlaybacks/:id | - | - |
