import type { Router } from "expo-router";
/**
 * WebView 原生桥接 — H5 → Native 消息路由
 *
 * H5 侧发送协议：
 *   window.ReactNativeWebView.postMessage(JSON.stringify({
 *     type: 'share',
 *     callbackId: 'uniq-id',     // 可选；需要回调时传
 *     payload: { text: '...', url: '...' }
 *   }))
 *
 * Native 回调协议（可选）：
 *   webViewRef.injectJavaScript(`
 *     window.__APP_BRIDGE__ && window.__APP_BRIDGE__.resolve('uniq-id', {...});
 *   `)
 *
 * 支持的 type：
 *   close                   关闭当前 WebView 页（返回上一页）
 *   login-required          跳原生登录
 *   pay-success             跳原生订单列表
 *   open-native { route }   push 原生路由
 *   title { text }          修改顶部标题
 *   share { text,url,title} 调起系统分享
 *   copy { text }           复制到剪贴板
 *   get-push-token          申请推送权限并回传 Expo push token
 *   local-notify {title,body} 触发本地通知（测试用）
 */
import type { MutableRefObject } from "react";
import type WebView from "react-native-webview";

import { getCachedPushToken, registerForPush, sendLocalNotification } from "./push";
import { copyToClipboard, shareText } from "./share";

export type BridgeMessage = {
  type: string;
  callbackId?: string;
  payload?: Record<string, unknown>;
  [k: string]: unknown;
};

export type BridgeContext = {
  router: Router;
  webViewRef: MutableRefObject<WebView | null>;
  setTitle?: (t: string) => void;
};

/** 把结果注回 H5（供 H5 的 callbackId resolve） */
function resolveCallback(
  ctx: BridgeContext,
  callbackId: string | undefined,
  result: unknown,
): void {
  if (!callbackId || !ctx.webViewRef.current) return;
  const payload = JSON.stringify(result);
  const js = `
    try {
      if (window.__APP_BRIDGE__ && typeof window.__APP_BRIDGE__.resolve === 'function') {
        window.__APP_BRIDGE__.resolve(${JSON.stringify(callbackId)}, ${payload});
      }
    } catch(e) {}
    true;
  `;
  ctx.webViewRef.current.injectJavaScript(js);
}

export async function handleBridgeMessage(msg: BridgeMessage, ctx: BridgeContext): Promise<void> {
  const { router } = ctx;
  const payload = (msg.payload ?? {}) as Record<string, unknown>;

  switch (msg.type) {
    case "close":
      router.back();
      return;

    case "login-required":
      router.push("/auth/login");
      return;

    case "pay-success":
      router.replace("/orders");
      return;

    case "open-native": {
      const route =
        typeof payload.route === "string"
          ? payload.route
          : typeof msg.route === "string"
            ? (msg.route as string)
            : "";
      if (route) router.push(route as never);
      return;
    }

    case "title": {
      const text =
        typeof payload.text === "string"
          ? payload.text
          : typeof msg.text === "string"
            ? (msg.text as string)
            : "";
      if (text) ctx.setTitle?.(text);
      return;
    }

    case "share": {
      const text = typeof payload.text === "string" ? payload.text : "";
      const url = typeof payload.url === "string" ? payload.url : undefined;
      const title = typeof payload.title === "string" ? payload.title : undefined;
      const r = await shareText(text, url, title);
      resolveCallback(ctx, msg.callbackId, r);
      return;
    }

    case "copy": {
      const text = typeof payload.text === "string" ? payload.text : "";
      const ok = await copyToClipboard(text);
      resolveCallback(ctx, msg.callbackId, { ok });
      return;
    }

    case "scan": {
      resolveCallback(ctx, msg.callbackId, { ok: false, error: "scanner_removed" });
      return;
    }

    case "get-push-token": {
      const cached = await getCachedPushToken();
      if (cached) {
        resolveCallback(ctx, msg.callbackId, { ok: true, token: cached });
        return;
      }
      const r = await registerForPush();
      resolveCallback(ctx, msg.callbackId, r);
      return;
    }

    case "local-notify": {
      const title = typeof payload.title === "string" ? payload.title : "通知";
      const body = typeof payload.body === "string" ? payload.body : "";
      const id = await sendLocalNotification(title, body);
      resolveCallback(ctx, msg.callbackId, { ok: true, id });
      return;
    }

    default:
      // 不认识的消息忽略
      return;
  }
}

/**
 * H5 侧脚手架 — 注入到 WebView 里，让 H5 可以方便地发消息 + 等回调。
 *
 * 用法（H5 内）：
 *   const r = await window.__APP_BRIDGE__.call('share', { text: 'hi', url: 'x' });
 *   window.__APP_BRIDGE__.emit('close');
 */
export const BRIDGE_INJECT_SCRIPT = `
(function () {
  if (window.__APP_BRIDGE__) return;
  var pending = {};
  var seq = 0;
  function uid() { seq += 1; return 'cb_' + Date.now() + '_' + seq; }

  function emit(type, payload) {
    try {
      window.ReactNativeWebView.postMessage(JSON.stringify({ type: type, payload: payload || {} }));
    } catch (e) {}
  }

  function call(type, payload) {
    return new Promise(function (resolve) {
      var cid = uid();
      pending[cid] = resolve;
      try {
        window.ReactNativeWebView.postMessage(JSON.stringify({
          type: type, callbackId: cid, payload: payload || {}
        }));
      } catch (e) { resolve({ ok: false, error: String(e) }); }
      // 30s 超时保护
      setTimeout(function () {
        if (pending[cid]) { try { pending[cid]({ ok:false, error:'timeout' }); } catch(e){} delete pending[cid]; }
      }, 30000);
    });
  }

  function resolve(cid, data) {
    var fn = pending[cid];
    if (fn) { try { fn(data); } catch (e) {} delete pending[cid]; }
  }

  window.__APP_BRIDGE__ = { emit: emit, call: call, resolve: resolve };
})();
true;
`;
