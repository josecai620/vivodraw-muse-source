import { memo, useMemo } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

import { theme } from "./petTheme";
import { getPetPreviewActions, getPetStagePreviewActions, type PetActionName } from "@/lib/pet-animations";
import type { PixelDeskPetId } from "@/lib/pets";

type PetActionPreviewPanelProps = {
  activeAction: PetActionName;
  petId: PixelDeskPetId;
  mode?: "stage" | "widget";
  onSelect: (action: PetActionName) => void;
};

const actionLabels: Partial<Record<PetActionName, string>> = {
  idle: "Idle",
  showcase: "Showcase",
  sleep: "Sleep",
  talk: "Talk",
  lookOwner: "Look",
  standIdleFront: "Stand",
  pawGreetFront: "Wave",
  headTiltFront: "Tilt",
  frontBobIdle: "Bob",
  frontHappyWave: "Wave",
  frontJoyBounce: "Bounce",
  frontReadIdle: "Read",
  frontPageFlip: "Flip",
  frontHappyLookup: "Look",
  happy: "Happy",
  stage: "Stage",
  drag: "Drag",
  hatTrick: "Hat",
  runRight: "Run R",
  runLeft: "Run L",
  wave: "Wave",
  jump: "Jump",
  fail: "Fail",
  wait: "Wait",
  run: "Run",
  inspect: "Inspect",
};

function PetActionPreviewPanelComponent({ activeAction, mode = "widget", petId, onSelect }: PetActionPreviewPanelProps) {
  const actions = useMemo(() => (mode === "stage" ? getPetStagePreviewActions(petId) : getPetPreviewActions(petId)), [mode, petId]);

  if (actions.length === 0) {
    return null;
  }

  return (
    <View style={styles.wrap}>
      <Text style={styles.label}>{mode === "stage" ? "Showcase action" : "Action preview"}</Text>
      <View style={styles.actionRow}>
        {actions.map((action) => {
          const active = action === activeAction;

          return (
            <Pressable
              key={action}
              accessibilityRole="button"
              accessibilityLabel={`Preview ${action}`}
              style={({ pressed }) => [styles.chip, active && styles.chipActive, pressed && styles.pressed]}
              onPress={() => onSelect(action)}
            >
              <Text style={[styles.chipLabel, active && styles.chipLabelActive]}>{actionLabels[action] ?? action}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

export const PetActionPreviewPanel = memo(PetActionPreviewPanelComponent);

const styles = StyleSheet.create({
  wrap: {
    gap: theme.spacing.xs,
  },
  label: {
    color: theme.colors.muted,
    fontFamily: theme.typography.family.ui,
    fontSize: theme.typography.size.xs,
    fontWeight: "900",
    letterSpacing: 0.5,
    textTransform: "uppercase",
  },
  actionRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: theme.spacing.xs,
  },
  chip: {
    minHeight: 34,
    justifyContent: "center",
    borderWidth: 1,
    borderColor: theme.colors.hairline,
    borderRadius: theme.radius.pill,
    backgroundColor: theme.colors.surface,
    paddingHorizontal: theme.spacing.md,
  },
  chipActive: {
    borderColor: theme.colors.accent,
    backgroundColor: theme.colors.accentSoft,
  },
  chipLabel: {
    color: theme.colors.muted,
    fontFamily: theme.typography.family.ui,
    fontSize: theme.typography.size.xs,
    fontWeight: "900",
  },
  chipLabelActive: {
    color: theme.colors.accentDeep,
  },
  pressed: {
    opacity: 0.72,
  },
});
