import React from "react";
import { ActivityIndicator, Image, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { getPresaleList } from "@/lib/api/presale";
import { normalizeImageUrl } from "@/lib/utils";
import { Calendar, Package } from "lucide-react-native";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

export default function PresaleScreen() {
  const router = useRouter();
  const { data, isLoading } = useQuery({
    queryKey: ["presaleList"],
    queryFn: () => getPresaleList({ page: 1, limit: 50 }),
  });

  const raw = (data as any)?.data ?? data ?? {};
  const list = raw?.list ?? raw?.data ?? (Array.isArray(raw) ? raw : []);

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Presale" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }} showsVerticalScrollIndicator={false}>
          {Array.isArray(list) && list.length > 0 ? (
            list.map((item: any) => {
              const id = item.id ?? item.product_id ?? 0;
              const image = item.image ?? item.pic ?? item.slider_image?.[0] ?? "";
              const name = item.store_name ?? item.title ?? item.name ?? "";
              const price = item.price ?? item.presale_price ?? "0";

              return (
                <Pressable
                  key={id}
                  onPress={() => router.push(`/product/${id}`)}
                  className="bg-white rounded-2xl mb-3 flex-row overflow-hidden border border-gray-100"
                >
                  {image ? (
                    <Image source={{ uri: normalizeImageUrl(image) }} className="w-24 h-24" resizeMode="cover" />
                  ) : (
                    <View className="w-24 h-24 bg-gray-100 items-center justify-center">
                      <Package size={s(26)} color={Colors.neutral[400]} strokeWidth={1.8} />
                    </View>
                  )}
                  <View className="flex-1 p-3 justify-center">
                    <Text className="font-semibold" style={{ color: Colors.neutral[800] }} numberOfLines={2}>
                      {name}
                    </Text>
                    <Text className="text-lg font-bold mt-1" style={{ color: Colors.brand.red }}>
                      ${price}
                    </Text>
                    <View className="mt-1 px-2 py-0.5 self-start rounded" style={{ backgroundColor: "#04A8AE15" }}>
                      <Text className="text-xs font-medium" style={{ color: "#04A8AE" }}>
                        Presale
                      </Text>
                    </View>
                  </View>
                </Pressable>
              );
            })
          ) : (
            <View className="py-12 items-center">
              <Calendar size={s(40)} color={Colors.neutral[300]} strokeWidth={1.8} style={{ marginBottom: s(12) }} />
              <Text style={{ color: Colors.neutral[500] }}>No presale products</Text>
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}
