import type { ImageSourcePropType } from "react-native";
import { normalizeImageUrl } from "@/lib/utils";

export type SystemAvatarPick = {
  sex: "male" | "female";
  index: number;
  path: string;
  source: ImageSourcePropType;
  labelZh: string;
  labelEn: string;
};

export const SYSTEM_AVATAR_PICKS: SystemAvatarPick[] = [
  {
    sex: "male",
    index: 1,
    path: "/static/avatars/avatar_male_1.png",
    source: require("../assets/系统默认头像/默认头像-男-欧洲人.png"),
    labelZh: "欧洲男",
    labelEn: "European man",
  },
  {
    sex: "male",
    index: 2,
    path: "/static/avatars/avatar_male_2.png",
    source: require("../assets/系统默认头像/默认头像-男-亚洲人.png"),
    labelZh: "亚洲男",
    labelEn: "Asian man",
  },
  {
    sex: "female",
    index: 1,
    path: "/static/avatars/avatar_female_1.png",
    source: require("../assets/系统默认头像/默认头像-女-欧洲人.png"),
    labelZh: "欧洲女",
    labelEn: "European woman",
  },
  {
    sex: "female",
    index: 2,
    path: "/static/avatars/avatar_female_2.png",
    source: require("../assets/系统默认头像/默认头像-女-亚洲人.png"),
    labelZh: "亚洲女",
    labelEn: "Asian woman",
  },
];

export function pickSystemAvatar(uid?: number | null): SystemAvatarPick {
  const list = SYSTEM_AVATAR_PICKS;
  if (!uid || uid <= 0) return list[0];
  return list[(uid - 1) % list.length];
}

export function isPlaceholderAvatar(uri?: string | null): boolean {
  const raw = String(uri || "").trim().toLowerCase();
  if (!raw || raw === "null" || raw === "undefined") return true;
  if (raw.includes("723adbdd4e49a0f9394dfc700ab5dba3")) return true;
  return false;
}

export function avatarSeed(uid?: number | null, extra?: string | number | null): number {
  if (uid && uid > 0) return uid;
  const s = String(extra ?? "");
  let hash = 0;
  for (let i = 0; i < s.length; i += 1) {
    hash = (hash * 31 + s.charCodeAt(i)) >>> 0;
  }
  return hash || 1;
}

export function hasRemoteAvatar(uri?: string | null): boolean {
  const next = String(uri || "").trim();
  if (isPlaceholderAvatar(next)) return false;
  if (next.startsWith("data:")) return true;
  if (next.startsWith("http://") || next.startsWith("https://")) return true;
  if (next.includes("/uploads/") || next.includes("/static/avatars/")) return true;
  return false;
}

export function matchSystemAvatar(uri?: string | null): SystemAvatarPick | null {
  const raw = String(uri || "").trim();
  if (!raw) return null;
  const direct = SYSTEM_AVATAR_PICKS.find((pick) => raw.endsWith(pick.path) || raw.includes(pick.path));
  if (direct) return direct;
  const legacy = raw.match(/avatar_(male|female)_([3-5])\.png/i);
  if (!legacy) return null;
  const sex = legacy[1].toLowerCase() === "female" ? "female" : "male";
  return SYSTEM_AVATAR_PICKS.find((pick) => pick.sex === sex && pick.index === 2) ?? null;
}

export function resolveUserAvatarSource(uri?: string | null, uid?: number | null, extra?: string | number | null): ImageSourcePropType {
  const raw = String(uri || "").trim();
  if (!isPlaceholderAvatar(raw)) {
    const bundled = matchSystemAvatar(raw);
    if (bundled) return bundled.source;
    if (hasRemoteAvatar(raw) && !raw.includes("/static/avatars/")) {
      return { uri: normalizeImageUrl(raw) };
    }
  }
  return pickSystemAvatar(avatarSeed(uid, extra)).source;
}
