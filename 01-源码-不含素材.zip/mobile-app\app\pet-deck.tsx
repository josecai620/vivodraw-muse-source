import PageHeader from "@/components/shared/PageHeader";
import { PixelDeskPetStage } from "@/components/pets/PixelDeskPetStage";
import { PixelDeskPetSprite } from "@/components/pets/PixelDeskPetSprite";
import { Colors, TealGradient } from "@/constants/theme";
import {
  claimPetDailyGift,
  exchangeRewardCoins,
  fetchPetDailyGiftStatus,
  fetchPetUnlockStatus,
  claimPetUnlock,
  fetchPetDeskBond,
  playPetDeskBond,
  fetchPetDeskDialogue,
  dialogueMatchesLocale,
  type PetDailyGiftStatus,
  type PetUnlockStatus,
  type PetDeskBondStatus,
  type PetDeskDialogue,
} from "@/lib/api/petWorld";
import {
  getPetBehaviorConfig,
  pickRandomPetAction,
  type PetActionName,
} from "@/lib/pet-animations";
import { formatPetGiftRange, getPetGiftTier } from "@/lib/pet-gift-tiers";
import {
  formatUsdPrice,
  isPetIdUnlocked,
  PET_POINT_GIFT_HINT,
  petUnlockCost,
  petUsdQuote,
} from "@/lib/pet-unlock";
import { getPixelDeskPet, pixelDeskPetIds, type PixelDeskPetId } from "@/lib/pets";
import { usePetTheme } from "@/store/pet-theme";
import { useAuthStore } from "@/store/auth";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { Heart, MessageCircle, Sparkles } from "lucide-react-native";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";

function PrimaryButton({
  label,
  disabled,
  loading,
  onPress,
}: {
  label: string;
  disabled?: boolean;
  loading?: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable disabled={disabled || loading} onPress={onPress}>
      <LinearGradient
        colors={
          disabled || loading
            ? [Colors.neutral[300], Colors.neutral[300]]
            : [TealGradient.light, TealGradient.base, TealGradient.dark]
        }
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        className="h-12 rounded-xl items-center justify-center"
      >
        {loading ? (
          <ActivityIndicator color="#fff" size="small" />
        ) : (
          <Text className="text-white font-bold text-sm">{label}</Text>
        )}
      </LinearGradient>
    </Pressable>
  );
}

function GhostButton({
  label,
  disabled,
  onPress,
}: {
  label: string;
  disabled?: boolean;
  onPress: () => void;
}) {
  return (
    <Pressable
      disabled={disabled}
      onPress={onPress}
      className="h-12 rounded-xl bg-white border border-neutral-200 items-center justify-center"
    >
      <Text className="font-bold text-sm text-neutral-700">{label}</Text>
    </Pressable>
  );
}

function PetGridAvatar({ petId, dimmed }: { petId: PixelDeskPetId; dimmed?: boolean }) {
  const behavior = useMemo(() => getPetBehaviorConfig(petId), [petId]);
  return (
    <View
      style={{
        width: 44,
        height: 44,
        marginTop: 4,
        alignSelf: "center",
        overflow: "hidden",
        opacity: dimmed ? 0.55 : 1,
      }}
    >
      <View style={{ marginLeft: -26, marginTop: -26 }}>
        <PixelDeskPetSprite petId={petId} animation={behavior.defaultAction} size={96} />
      </View>
    </View>
  );
}

function PetDeckInner() {
  const router = useRouter();
  const { i18n, t } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const text = (z: string, e: string) => (zh ? z : e);
  const tt = (key: string) => key; // 宠物名/台词等英文数据原样透传

  const token = useAuthStore((s) => s.token);
  const hasApiToken = !!token;
  const { activePetId, isMagicThemeEnabled, isFloatingPetEnabled, setActivePetId, toggleMagicTheme, toggleFloatingPet } = usePetTheme();
  const [stagePetId, setStagePetId] = useState<PixelDeskPetId>(activePetId);
  const isLockedPreviewRef = useRef(false);
  const stagePet = useMemo(() => getPixelDeskPet(stagePetId), [stagePetId]);
  const behavior = useMemo(() => getPetBehaviorConfig(stagePetId), [stagePetId]);

  const [stageAction, setStageAction] = useState<PetActionName | null>(null);
  const [previewNonce, setPreviewNonce] = useState(0);
  const [giftStatus, setGiftStatus] = useState<PetDailyGiftStatus | undefined>();
  const [giftLoading, setGiftLoading] = useState(false);
  const [giftClaiming, setGiftClaiming] = useState(false);
  const [coinExchanging, setCoinExchanging] = useState(false);
  const [giftMessage, setGiftMessage] = useState("");
  const [unlockStatus, setUnlockStatus] = useState<PetUnlockStatus | undefined>();
  const [bondStatus, setBondStatus] = useState<PetDeskBondStatus | undefined>();
  const [bondPlaying, setBondPlaying] = useState(false);
  const [snackPlaying, setSnackPlaying] = useState(false);
  const [unlockClaiming, setUnlockClaiming] = useState(false);
  const [usdPaying, setUsdPaying] = useState(false);
  const [petTip, setPetTip] = useState<PetDeskDialogue | undefined>();
  const [tipLoading, setTipLoading] = useState(false);

  const giftMinAmount = giftStatus?.minAmount || 10;
  const giftMaxAmount = giftStatus?.maxAmount || 60;
  const giftUnit = giftStatus?.rewardUnit === "point" ? text("積分", "points") : text("金幣", "coins");
  const giftAmountLabel = giftStatus?.claimedToday
    ? `+${giftStatus.rewardCoins || giftStatus.rewardPoints || giftStatus.amount || giftMinAmount}`
    : `${giftMinAmount}-${giftMaxAmount}`;
  const giftButtonTitle = !hasApiToken
    ? text("登入後領取", "Sign in to claim")
    : giftStatus?.claimedToday
      ? text("已領取", "Gift claimed")
      : giftClaiming
        ? text("領取中…", "Claiming...")
        : text("領取每日禮物", "Claim gift");
  const coinBalance = giftStatus?.coinBalance ?? 0;
  const exchangeRate = giftStatus?.exchangeRate ?? 10;
  const convertiblePoints =
    giftStatus?.convertiblePoints ?? Math.floor(coinBalance / Math.max(1, exchangeRate));
  const exchangeButtonTitle = !hasApiToken
    ? text("登入後兌換", "Sign in to convert")
    : coinExchanging
      ? text("兌換中…", "Converting...")
      : convertiblePoints > 0
        ? `${text("兌換金幣", "Convert coins")} +${convertiblePoints} ${text("積分", "points")}`
        : `${text("需要", "Need")} ${exchangeRate} ${text("金幣", "coins")}`;

  useEffect(() => {
    let active = true;
    if (!hasApiToken) {
      setGiftStatus(undefined);
      setGiftMessage("");
      setGiftLoading(false);
      return () => {
        active = false;
      };
    }
    setGiftLoading((loading) => loading || !giftStatus);
    fetchPetDailyGiftStatus(activePetId)
      .then((gift) => {
        if (!active) return;
        setGiftStatus(gift);
        if (gift?.unlock) setUnlockStatus(gift.unlock);
      })
      .finally(() => {
        if (active) setGiftLoading(false);
      });
    return () => {
      active = false;
    };
  }, [activePetId, hasApiToken]);

  useEffect(() => {
    let active = true;
    if (!hasApiToken) {
      setUnlockStatus(undefined);
      return () => {
        active = false;
      };
    }
    fetchPetUnlockStatus()
      .then((unlock) => {
        if (active && unlock) setUnlockStatus(unlock);
      })
      .catch(() => {
        if (active) setUnlockStatus(undefined);
      });
    return () => {
      active = false;
    };
  }, [hasApiToken]);

  useEffect(() => {
    if (!hasApiToken || !unlockStatus) return;
    if (!isPetIdUnlocked(activePetId, unlockStatus.progress, true, unlockStatus.unlockedIds)) {
      setActivePetId("cat_programmer");
    }
  }, [activePetId, hasApiToken, setActivePetId, unlockStatus]);

  useEffect(() => {
    if (isLockedPreviewRef.current) return;
    setStagePetId(activePetId);
  }, [activePetId]);

  useEffect(() => {
    let active = true;
    if (!hasApiToken) {
      setBondStatus(undefined);
      setPetTip(undefined);
      return () => {
        active = false;
      };
    }
    fetchPetDeskBond(activePetId).then((bond) => {
      if (active) setBondStatus(bond);
    });
    return () => {
      active = false;
    };
  }, [activePetId, hasApiToken]);

  const playStageAction = (actionName?: string) => {
    const cfg = getPetBehaviorConfig(stagePetId);
    const candidate = (actionName || "") as PetActionName;
    const pool =
      cfg.stagePreviewActions.length > 0 ? cfg.stagePreviewActions : cfg.previewActions;
    const next =
      candidate &&
      (pool.includes(candidate) ||
        cfg.clickPool.includes(candidate) ||
        cfg.previewActions.includes(candidate))
        ? candidate
        : pickRandomPetAction(pool, cfg.showcaseAction);
    setStageAction(next);
    setPreviewNonce((n) => n + 1);
  };

  const selectPet = (petId: PixelDeskPetId) => {
    const progress = unlockStatus?.progress;
    const unlocked = isPetIdUnlocked(petId, progress, hasApiToken, unlockStatus?.unlockedIds);
    const nextBehavior = getPetBehaviorConfig(petId);
    const actionPool =
      nextBehavior.stagePreviewActions.length > 0
        ? nextBehavior.stagePreviewActions
        : nextBehavior.previewActions;
    setStagePetId(petId);
    setStageAction(pickRandomPetAction(actionPool, nextBehavior.showcaseAction));
    setPreviewNonce((c) => c + 1);
    if (!unlocked) {
      isLockedPreviewRef.current = true;
      const cost = petUnlockCost(petId);
      const have = unlockStatus?.progress.intimacyValue || 0;
      const quote = petUsdQuote(petId, have);
      setGiftMessage(
        hasApiToken
          ? have >= cost
            ? text(`默契夠了。領取這隻會扣 ${cost} 點默契。`, `Bond is enough. Claiming this pet spends ${cost} bond.`)
            : quote.mode === "fixed"
              ? text(
                  `這隻一口價 ${formatUsdPrice(quote.price)}，已存默契不能抵。也可以繼續攢到 ${cost} 默契免費領。僅可預覽，不能帶走。`,
                  `This pet is a flat ${formatUsdPrice(quote.price)}. Saved bond does not discount it. Or keep grinding to ${cost} bond and claim free. Preview only — not equipped.`,
                )
              : quote.canPay
                ? text(
                    `這隻還鎖着。領走要 ${cost} 默契，你現在有 ${have}。也可以補差價 ${formatUsdPrice(quote.price)}。僅可預覽，不能帶走。`,
                    `This pet is still locked. Claiming it costs ${cost} bond; you have ${have}. Or pay the remainder ${formatUsdPrice(quote.price)}. Preview only — not equipped.`,
                  )
                : text(
                    `這隻還鎖着。領走要 ${cost} 默契，你現在有 ${have}。僅可預覽，不能帶走。`,
                    `This pet is still locked. Claiming it costs ${cost} bond; you have ${have}. Preview only — not equipped.`,
                  )
          : text("登入後解鎖。現在只能預覽。", "Sign in to unlock. Preview only for now."),
      );
      return;
    }
    isLockedPreviewRef.current = false;
    setActivePetId(petId);
    setGiftMessage("");
  };

  const applyUnlockResult = (petId: PixelDeskPetId, accepted: boolean, unlock?: PetUnlockStatus, message?: string) => {
    if (unlock) setUnlockStatus(unlock);
    if (message) setGiftMessage(tt(message));
    if (accepted) {
      isLockedPreviewRef.current = false;
      setActivePetId(petId);
      setStagePetId(petId);
    }
  };

  const claimUnlockPet = async (petId: PixelDeskPetId, payMode: "bond" | "usd") => {
    if (!hasApiToken) {
      router.push("/auth");
      return;
    }
    if (unlockClaiming || usdPaying) return;
    if (payMode === "usd") setUsdPaying(true);
    else setUnlockClaiming(true);
    setGiftMessage("");
    try {
      const result = await claimPetUnlock(petId, "", payMode);
      applyUnlockResult(petId, result.accepted, result.unlock, result.message);
    } finally {
      setUnlockClaiming(false);
      setUsdPaying(false);
    }
  };

  const claimGift = async () => {
    if (!hasApiToken) {
      router.push("/auth");
      return;
    }
    if (giftLoading || giftClaiming || giftStatus?.canClaim === false) return;
    setGiftClaiming(true);
    setGiftMessage("");
    try {
      const result = await claimPetDailyGift(activePetId);
      if (result.ok && result.gift) {
        setGiftStatus(result.gift);
        setGiftMessage(
          result.gift.accepted
            ? `${text("桌寵禮物", "Pet figure gift")} +${result.coins || result.points} ${giftUnit} ${text("已入帳", "added")}.`
            : tt(result.gift.message),
        );
      } else {
        setGiftMessage(tt(result.message));
      }
    } finally {
      setGiftClaiming(false);
    }
  };

  const convertCoins = async () => {
    if (!hasApiToken) {
      router.push("/auth");
      return;
    }
    if (coinExchanging || convertiblePoints <= 0) return;
    setCoinExchanging(true);
    setGiftMessage("");
    try {
      const result = await exchangeRewardCoins();
      if (result.ok && result.gift) {
        setGiftStatus((current) =>
          current
            ? {
                ...current,
                balance: result.gift?.balance ?? current.balance,
                coinBalance: result.gift?.coinBalance ?? current.coinBalance,
                exchangeRate: result.gift?.exchangeRate ?? current.exchangeRate,
                convertiblePoints: result.gift?.convertiblePoints ?? current.convertiblePoints,
                remainingCoins: result.gift?.remainingCoins ?? current.remainingCoins,
              }
            : result.gift,
        );
        setGiftMessage(`${text("已兌換金幣", "Converted coins")} +${result.points} ${text("積分", "points")} ${text("已入帳", "added")}.`);
      } else {
        setGiftMessage(tt(result.message));
      }
    } finally {
      setCoinExchanging(false);
    }
  };

  const playBond = async () => {
    if (!hasApiToken) {
      router.push("/auth");
      return;
    }
    if (bondPlaying || snackPlaying || bondStatus?.canPlay === false) return;
    setBondPlaying(true);
    setGiftMessage("");
    try {
      const result = await playPetDeskBond(activePetId, "play");
      if (result.ok && result.bond) {
        setBondStatus(result.bond);
        if (result.bond.dialogue && dialogueMatchesLocale(result.bond.dialogue, i18n.language)) {
          setPetTip(result.bond.dialogue);
        }
        setGiftMessage(result.bond.message || text("桌寵和你更親近了。", "Your pet feels closer."));
        playStageAction(result.bond.previewAction);
        fetchPetUnlockStatus().then((unlock) => {
          if (unlock) setUnlockStatus(unlock);
        }).catch(() => {});
      } else {
        setGiftMessage(tt(result.message));
      }
    } finally {
      setBondPlaying(false);
    }
  };

  const feedSnack = async () => {
    if (!hasApiToken) {
      router.push("/auth");
      return;
    }
    if (bondPlaying || snackPlaying) return;
    if (bondStatus && bondStatus.snacksLeft <= 0) {
      setGiftMessage(text("明天再來", "Play again tomorrow"));
      return;
    }
    if (bondStatus && bondStatus.coinBalance < bondStatus.snackCost) {
      setGiftMessage(text("金幣不足", "Not enough coins"));
      return;
    }
    setSnackPlaying(true);
    setGiftMessage("");
    try {
      const result = await playPetDeskBond(activePetId, "snack");
      if (result.ok && result.bond) {
        setBondStatus(result.bond);
        if (result.bond.dialogue && dialogueMatchesLocale(result.bond.dialogue, i18n.language)) {
          setPetTip(result.bond.dialogue);
        }
        setGiftMessage(result.bond.message || text("桌寵和你更親近了。", "Your pet feels closer."));
        playStageAction(result.bond.previewAction);
        fetchPetUnlockStatus().then((unlock) => {
          if (unlock) setUnlockStatus(unlock);
        }).catch(() => {});
      } else {
        setGiftMessage(tt(result.message));
      }
    } finally {
      setSnackPlaying(false);
    }
  };

  const askPetTip = async () => {
    if (!hasApiToken) {
      router.push("/auth");
      return;
    }
    if (tipLoading) return;
    setTipLoading(true);
    try {
      const tip = await fetchPetDeskDialogue({
        deskPetId: activePetId,
        trigger: "game_guide",
        route: "/pet-deck",
        locale: i18n.language,
      });
      if (tip && dialogueMatchesLocale(tip, i18n.language)) setPetTip(tip);
      else setGiftMessage(text("桌寵悄悄話", "Pet tip"));
    } finally {
      setTipLoading(false);
    }
  };

  const petName = (petId: PixelDeskPetId, fallback: string) =>
    t(`petDeck.pets.${petId}.name`, { defaultValue: fallback });
  const petRole = (petId: PixelDeskPetId, fallback: string) =>
    t(`petDeck.pets.${petId}.role`, { defaultValue: fallback });
  const petStatus = (petId: PixelDeskPetId, fallback: string) =>
    t(`petDeck.pets.${petId}.status`, { defaultValue: fallback });
  const petQuote = (petId: PixelDeskPetId, fallback: string) =>
    t(`petDeck.pets.${petId}.quote`, { defaultValue: fallback });

  const magic = isMagicThemeEnabled;
  const cardBg = magic ? "#121a3e" : "#FFFFFF";
  const titleColor = magic ? "#eef1ff" : "#171A1A";
  const muteColor = magic ? "#98a0d8" : Colors.neutral[500];
  const spendableBond = unlockStatus?.progress.intimacyValue || 0;
  const stageUnlocked = isPetIdUnlocked(stagePetId, unlockStatus?.progress, hasApiToken, unlockStatus?.unlockedIds);
  const stageCost = petUnlockCost(stagePetId);
  const stageMeta = unlockStatus?.pets?.[stagePetId];
  const stageQuote = petUsdQuote(stagePetId, spendableBond);
  const stageUsdPrice = stageMeta?.usdPrice || stageQuote.price;
  const stageUsdMode = (stageMeta?.usdMode || stageQuote.mode) as string;
  const stageCanPayUsd = stageMeta?.canPayUsd ?? stageQuote.canPay;
  const stageGiftHint = PET_POINT_GIFT_HINT[stagePetId];
  const unlockRatio = stageCost > 0 ? Math.min(1, spendableBond / stageCost) : 1;

  return (
    <View className="flex-1" style={{ backgroundColor: magic ? "#050816" : Colors.neutral[50] }}>
      <PageHeader
        title={text("桌寵世界", "Pet deck")}
        inverted={magic}
        onBackPress={() => router.replace("/")}
      />
      <ScrollView
        contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 120, maxWidth: 480, width: "100%", alignSelf: "center" }}
        showsVerticalScrollIndicator={false}
      >
        {/* 像素舞台（深色舞台是像素游戏内容，保留） */}
        <View
          className="rounded-3xl overflow-hidden"
          style={{ backgroundColor: "#0F2A2C", borderWidth: 4, borderColor: magic ? "rgba(138, 114, 255, 0.45)" : "#fff" }}
        >
          <Pressable
            onPress={toggleMagicTheme}
            className="absolute top-3 left-3 z-10 h-9 px-3 rounded-full items-center justify-center"
            style={{
              backgroundColor: magic ? "rgba(176, 244, 111, 0.9)" : "rgba(255,255,255,0.16)",
            }}
          >
            <Text className="text-xs font-bold" style={{ color: magic ? "#050816" : "#fff" }}>
              {isMagicThemeEnabled ? text("原版主題", "Original") : text("魔法主題", "Magic theme")}
            </Text>
          </Pressable>
          <Pressable
            onPress={toggleFloatingPet}
            className="absolute top-3 right-3 z-10 h-9 px-3 rounded-full items-center justify-center"
            style={{
              backgroundColor: isFloatingPetEnabled ? "rgba(176, 244, 111, 0.9)" : "rgba(255,255,255,0.16)",
            }}
          >
            <Text className="text-xs font-bold" style={{ color: isFloatingPetEnabled ? "#050816" : "#fff" }}>
              {isFloatingPetEnabled ? text("關閉掛件", "Hide pet") : text("顯示掛件", "Show pet")}
            </Text>
          </Pressable>
          <PixelDeskPetStage
            animation={stageAction ?? behavior.defaultAction}
            petId={stagePetId}
            resetKey={previewNonce}
          />
          {!stageUnlocked ? (
            <View
              className="absolute bottom-3 left-3 right-3 z-10 rounded-full px-3 py-2 items-center"
              style={{ backgroundColor: "rgba(5,8,22,0.72)" }}
            >
              <Text className="text-[11px] font-bold text-center" style={{ color: "#B0F46F" }}>
                {text("僅可預覽 · 不能帶走", "Preview only · not equipped")}
              </Text>
            </View>
          ) : null}
        </View>

        {/* 每日礼物 */}
        <View className="rounded-2xl p-5 gap-4" style={{ backgroundColor: cardBg }}>
          <View className="flex-row items-center gap-3">
            <View className="flex-1 gap-1">
              <Text className="text-xs font-bold" style={{ color: Colors.brand.redDark }}>
                {text("每日桌寵禮物", "DAILY PET GIFT")}
              </Text>
              <Text className="text-lg font-bold" style={{ color: titleColor }}>
                {t("petDeck.giftTitle", { defaultValue: text("寵物手辦禮", "Pet figure gift") })}
              </Text>
              <Text className="text-xs text-neutral-500 leading-4">
                {hasApiToken && giftStatus?.message
                  ? tt(giftStatus.message)
                  : text(
                      "當前桌寵決定今日禮物區間，越高階桌寵金幣越多，10 金幣 = 1 積分。",
                      "Your active pet sets today's gift range. Higher-tier pets bring more coins. 10 coins = 1 point.",
                    )}
              </Text>
            </View>
            <View
              className="rounded-2xl px-3 py-2 items-center"
              style={{ backgroundColor: "#ECFBFB" }}
            >
              <Text className="text-2xl font-bold" style={{ color: Colors.brand.redDark }}>
                {giftAmountLabel}
              </Text>
              <Text className="text-[10px] font-bold text-neutral-500">{giftUnit}</Text>
            </View>
          </View>

          <PrimaryButton
            label={giftLoading && !giftStatus ? text("讀取中…", "Loading gift") : giftButtonTitle}
            disabled={hasApiToken && (giftClaiming || giftStatus?.canClaim === false || (giftLoading && !giftStatus))}
            loading={giftClaiming}
            onPress={claimGift}
          />

          {hasApiToken && giftStatus ? (
            <View className="rounded-xl p-3 gap-2" style={{ backgroundColor: "#F7F9F9" }}>
              <Text className="text-xs text-neutral-500 text-center">
                {coinBalance.toLocaleString()} {text("金幣", "coins")} ·{" "}
                {convertiblePoints.toLocaleString()} {text("積分", "points")}{" "}
                {text("可兌換", "ready to convert")}
              </Text>
              <GhostButton
                label={exchangeButtonTitle}
                disabled={coinExchanging || convertiblePoints <= 0}
                onPress={convertCoins}
              />
              <GhostButton
                label={text("打開金幣兌換", "Open coin exchange")}
                onPress={() => router.push("/coin-exchange")}
              />
            </View>
          ) : null}
          {giftMessage ? (
            <Text className="text-xs font-semibold text-center leading-4" style={{ color: Colors.brand.redDark }}>
              {giftMessage}
            </Text>
          ) : null}
        </View>

        {/* 亲密度 */}
        <View className="rounded-2xl p-5 gap-4" style={{ backgroundColor: cardBg }}>
          <View className="flex-row items-center">
            <Heart size={18} color={Colors.brand.red} />
            <Text className="text-base font-bold ml-2" style={{ color: titleColor }}>
              {text("親密度", "Bond level")}
            </Text>
          </View>
          <View>
            <Text className="text-lg font-bold" style={{ color: titleColor }}>
              {hasApiToken && bondStatus
                ? `Lv.${bondStatus.intimacyLevel} · ${bondStatus.intimacyValue}`
                : hasApiToken
                  ? text("載入默契…", "Loading bond")
                  : text("登入後互動", "Sign in to play")}
            </Text>
            <Text className="text-xs mt-1" style={{ color: muteColor }}>
              {hasApiToken && bondStatus
                ? `${text("今日剩餘互動", "Daily plays left")} ${bondStatus.playsLeft}/${bondStatus.playLimit} · +${bondStatus.playGain} ${text("默契", "bond")}`
                : text("逗寵 +3 默契，零食 +10 默契。一天最多 60。默契用來領取指定桌寵，不是積分。", "Play +3 bond, snack +10 bond. Cap 60/day. Bond claims a pet you choose — it is not points.")}
            </Text>
            {hasApiToken && bondStatus ? (
              <Text className="text-xs text-neutral-500 mt-1">
                {text("剩餘零食", "Snacks left")} {bondStatus.snacksLeft}/{bondStatus.snackLimit} ·{" "}
                {bondStatus.snackCost} {text("金幣", "coins")} → +{bondStatus.snackGain} {text("默契", "bond")}
              </Text>
            ) : null}
          </View>
          <PrimaryButton
            label={
              !hasApiToken
                ? text("登入後互動", "Sign in to play")
                : bondPlaying
                  ? text("互動中…", "Playing…")
                  : bondStatus?.canPlay === false
                    ? text("明天再來", "Play again tomorrow")
                    : text("和桌寵玩", "Play with pet")
            }
            disabled={hasApiToken && (bondPlaying || snackPlaying || bondStatus?.canPlay === false)}
            loading={bondPlaying}
            onPress={playBond}
          />
          <GhostButton
            label={
              !hasApiToken
                ? text("登入後互動", "Sign in to play")
                : snackPlaying
                  ? text("餵食中…", "Feeding…")
                  : bondStatus && bondStatus.snacksLeft <= 0
                    ? text("明天再來", "Play again tomorrow")
                    : bondStatus && bondStatus.coinBalance < bondStatus.snackCost
                      ? text("金幣不足", "Not enough coins")
                      : `${text("餵零食", "Feed snack")} · ${bondStatus?.snackCost ?? 10}`
            }
            disabled={
              hasApiToken &&
              (bondPlaying ||
                snackPlaying ||
                (bondStatus
                  ? bondStatus.snacksLeft <= 0 || bondStatus.coinBalance < bondStatus.snackCost
                  : false))
            }
            onPress={feedSnack}
          />
          <GhostButton
            label={tipLoading ? "..." : text("問問桌寵", "Ask pet")}
            onPress={askPetTip}
          />

          {petTip ? (
            <Pressable
              className="rounded-xl p-4 gap-1"
              style={{ backgroundColor: "#ECFBFB" }}
              onPress={() => petTip.route && router.push(petTip.route)}
            >
              <View className="flex-row items-center">
                <MessageCircle size={14} color={Colors.brand.redDark} />
                <Text className="text-xs font-bold ml-1.5" style={{ color: Colors.brand.redDark }}>
                  {text("桌寵悄悄話", "Pet tip")}
                </Text>
              </View>
              <Text className="text-sm font-bold text-neutral-900">{tt(petTip.title)}</Text>
              <Text className="text-xs text-neutral-600 leading-4">{tt(petTip.message)}</Text>
              {petTip.foundPoints ? (
                <Text className="text-xs font-semibold" style={{ color: Colors.brand.redDark }}>
                  {text(`撿到積分 +${petTip.foundPoints}`, `Found points +${petTip.foundPoints}`)}
                </Text>
              ) : null}
              <Text className="text-xs font-bold" style={{ color: Colors.brand.redDark }}>
                {tt(petTip.ctaLabel)}
              </Text>
            </Pressable>
          ) : null}
        </View>

        {/* 可花默契 + 桌宠网格 */}
        <View className="rounded-2xl p-4 gap-3" style={{ backgroundColor: cardBg }}>
          <View className="gap-2 p-1">
            <Text className="text-sm font-bold" style={{ color: titleColor }}>
              {text("可花默契", "Spendable bond")}
            </Text>
            {hasApiToken && unlockStatus ? (
              <>
                <Text className="text-xs font-semibold" style={{ color: Colors.brand.redDark }}>
                  {stageUnlocked
                    ? text(
                        `已解鎖 ${petName(stagePetId, stagePet.name)} · 剩餘默契 ${spendableBond}`,
                        `Unlocked ${petName(stagePetId, stagePet.name)} · leftover bond ${spendableBond}`,
                      )
                    : `${petName(stagePetId, stagePet.name)} · ${spendableBond}/${stageCost}`}
                </Text>
                <View className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: magic ? "rgba(255,255,255,0.12)" : "#E8EEEE" }}>
                  <View
                    style={{
                      width: `${Math.round(unlockRatio * 100)}%`,
                      height: "100%",
                      borderRadius: 999,
                      backgroundColor: Colors.brand.red,
                    }}
                  />
                </View>
                <Text className="text-xs leading-4" style={{ color: muteColor }}>
                  {text(
                    "自己選要領的那隻。後面越貴，一天最多 60 默契。金幣不能買解鎖。高等級桌寵有消費時會撿積分。",
                    "Pick which pet to claim. Later pets cost more. Cap 60 bond/day. Coins cannot buy unlock. Higher pets find points when you spent yesterday.",
                  )}
                </Text>
                {stageGiftHint ? (
                  <Text className="text-xs font-semibold" style={{ color: Colors.brand.redDark }}>
                    {text(
                      `這隻撿積分約 ${stageGiftHint.min}-${stageGiftHint.max}（${stageGiftHint.percent}%）`,
                      `This pet finds about ${stageGiftHint.min}-${stageGiftHint.max} points (${stageGiftHint.percent}%)`,
                    )}
                  </Text>
                ) : null}
                {!stageUnlocked && stageCost > 0 ? (
                  <View className="gap-2 mt-1">
                    <PrimaryButton
                      label={
                        unlockClaiming
                          ? text("領取中…", "Claiming…")
                          : spendableBond >= stageCost
                            ? text(`領取這隻 · 扣 ${stageCost} 默契`, `Claim this pet · spend ${stageCost} bond`)
                            : text(`默契不夠 · 還差 ${Math.max(0, stageCost - spendableBond)}`, `Need ${Math.max(0, stageCost - spendableBond)} more bond`)
                      }
                      disabled={unlockClaiming || usdPaying || spendableBond < stageCost}
                      loading={unlockClaiming}
                      onPress={() => claimUnlockPet(stagePetId, "bond")}
                    />
                    {stageCanPayUsd && stageUsdPrice > 0 ? (
                      <GhostButton
                        label={
                          usdPaying
                            ? text("扣款中…", "Paying…")
                            : stageUsdMode === "fixed"
                              ? text(`一口價 ${formatUsdPrice(stageUsdPrice)}`, `Flat price ${formatUsdPrice(stageUsdPrice)}`)
                              : text(`補差價 ${formatUsdPrice(stageUsdPrice)}`, `Pay remainder ${formatUsdPrice(stageUsdPrice)}`)
                        }
                        disabled={unlockClaiming || usdPaying}
                        onPress={() => claimUnlockPet(stagePetId, "usd")}
                      />
                    ) : null}
                    {typeof unlockStatus.nowMoney === "number" ? (
                      <Text className="text-[10px] text-center" style={{ color: muteColor }}>
                        {text("美元錢包", "USD wallet")} ${unlockStatus.nowMoney.toFixed(2)}
                      </Text>
                    ) : null}
                  </View>
                ) : null}
              </>
            ) : (
              <Text className="text-xs" style={{ color: muteColor }}>
                {text("登入後解鎖。點鎖定卡片可先預覽。", "Sign in to unlock. Tap a locked card to preview.")}
              </Text>
            )}
          </View>
          <View className="flex-row flex-wrap justify-between gap-2">
            {pixelDeskPetIds.map((petId, index) => {
              const pet = getPixelDeskPet(petId);
              const active = petId === stagePetId;
              const equipped = petId === activePetId;
              const tier = getPetGiftTier(petId).tier;
              const unlocked = isPetIdUnlocked(petId, unlockStatus?.progress, hasApiToken, unlockStatus?.unlockedIds);
              const cost = petUnlockCost(petId);
              const hint = PET_POINT_GIFT_HINT[petId];
              const quote = petUsdQuote(petId, spendableBond);
              return (
                <Pressable
                  key={petId}
                  onPress={() => selectPet(petId)}
                  className="rounded-xl p-2.5 border"
                  style={{
                    width: "48.5%",
                    borderColor: active ? Colors.brand.red : "rgba(12,31,31,0.08)",
                    backgroundColor: active ? "#ECFBFB" : magic ? "rgba(255,255,255,0.06)" : "#F7F9F9",
                    opacity: unlocked ? 1 : 0.92,
                  }}
                >
                  <View className="flex-row items-center justify-between">
                    <View className="w-2 h-2 rounded-full" style={{ backgroundColor: pet.accent }} />
                    <Text className="text-[10px] text-neutral-400 font-bold">
                      {unlocked
                        ? equipped
                          ? text("使用中", "On")
                          : String(index + 1).padStart(2, "0")
                        : text("預覽", "Preview")}
                    </Text>
                  </View>
                  <PetGridAvatar petId={petId} dimmed={!unlocked} />
                  <Text numberOfLines={1} className="text-xs font-bold mt-1" style={{ color: titleColor }}>
                    {petName(petId, pet.name)}
                  </Text>
                  <Text numberOfLines={1} className="text-[10px]" style={{ color: muteColor }}>
                    T{tier} · {formatPetGiftRange(petId)} {text("金幣", "coins")}
                  </Text>
                  <Text numberOfLines={1} className="text-[10px] text-neutral-400">
                    {unlocked
                      ? petRole(petId, pet.role)
                      : cost <= 0
                        ? text("免費開場", "Free starter")
                        : quote.mode === "fixed"
                          ? `${cost} ${text("默契", "bond")} / ${formatUsdPrice(quote.price)}`
                          : `${cost} ${text("默契", "bond")}`}
                  </Text>
                  {hint ? (
                    <Text numberOfLines={1} className="text-[10px] font-semibold" style={{ color: Colors.brand.redDark }}>
                      {text(`撿積分 ${hint.min}-${hint.max}`, `Finds ${hint.min}-${hint.max} pts`)}
                    </Text>
                  ) : null}
                </Pressable>
              );
            })}
          </View>
        </View>

        {/* 当前桌宠台词 */}
        <View className="rounded-2xl p-5 gap-1" style={{ backgroundColor: cardBg }}>
          <View className="flex-row items-center">
            <Sparkles size={14} color={Colors.brand.red} />
            <Text className="text-xs font-bold ml-1.5" style={{ color: Colors.brand.redDark }}>
              {petStatus(stagePetId, stagePet.status)}
            </Text>
          </View>
          <Text className="text-sm font-bold mt-1" style={{ color: titleColor }}>{petQuote(stagePetId, stagePet.quote)}</Text>
        </View>
      </ScrollView>
    </View>
  );
}

export default function PetDeckScreen() {
  return <PetDeckInner />;
}
