import { unwrapApiData } from "@/lib/api/response";

/** 0 普通（静态）→ 1 新星 → 2 黄金 → 3 白金 → 4 翡翠 → 5 钻石 → 6 黑金 */
export type MemberFrameLevel = 0 | 1 | 2 | 3 | 4 | 5 | 6;

export const FREE_TRIAL_HINT = {
  code: "FUDTE8D",
  pwd: "DN8n9p",
};

export type MemberFrameTier = {
  level: MemberFrameLevel;
  key: string;
  nameZh: string;
  nameEn: string;
  ring: string;
  glow: string;
  cardFrom: string;
  cardTo: string;
  bonus: string;
  motion: boolean;
};

export const MEMBER_FRAME_TIERS: Record<MemberFrameLevel, MemberFrameTier> = {
  0: {
    level: 0,
    key: "regular",
    nameZh: "普通會員",
    nameEn: "Regular",
    ring: "#9CA3AF",
    glow: "rgba(156,163,175,0.2)",
    cardFrom: "#F3F4F6",
    cardTo: "#FFFFFF",
    bonus: "—",
    motion: false,
  },
  1: {
    level: 1,
    key: "nova",
    nameZh: "新星會員",
    nameEn: "Nova",
    ring: "#04A8AE",
    glow: "rgba(4,168,174,0.4)",
    cardFrom: "#E6F7F8",
    cardTo: "#FFFFFF",
    bonus: "1.1x",
    motion: true,
  },
  2: {
    level: 2,
    key: "gold",
    nameZh: "黃金會員",
    nameEn: "Gold",
    ring: "#E0B429",
    glow: "rgba(224,180,41,0.55)",
    cardFrom: "#FFF3C4",
    cardTo: "#FFFDF5",
    bonus: "1.2x",
    motion: true,
  },
  3: {
    level: 3,
    key: "platinum",
    nameZh: "白金會員",
    nameEn: "Platinum",
    ring: "#C5C0B5",
    glow: "rgba(197,192,181,0.6)",
    cardFrom: "#F4F1EA",
    cardTo: "#FFFFFF",
    bonus: "1.5x",
    motion: true,
  },
  4: {
    level: 4,
    key: "jade",
    nameZh: "翡翠會員",
    nameEn: "Jade",
    ring: "#1F8A70",
    glow: "rgba(31,138,112,0.55)",
    cardFrom: "#D1FAE5",
    cardTo: "#F0FDFA",
    bonus: "1.8x",
    motion: true,
  },
  5: {
    level: 5,
    key: "diamond",
    nameZh: "鑽石會員",
    nameEn: "Diamond",
    ring: "#04A8AE",
    glow: "rgba(126,240,255,0.65)",
    cardFrom: "#CFF7FA",
    cardTo: "#FFF6D6",
    bonus: "2.0x",
    motion: true,
  },
  6: {
    level: 6,
    key: "blackgold",
    nameZh: "黑金會員",
    nameEn: "Black Gold",
    ring: "#C9A227",
    glow: "rgba(201,162,39,0.7)",
    cardFrom: "#F7E7C4",
    cardTo: "#1F1A12",
    bonus: "2.5x",
    motion: true,
  },
};

/** 试用 7 天专用皮（不是等级；到期回普通） */
export const MEMBER_TRIAL_SKIN: MemberFrameTier = {
  level: 0,
  key: "trial",
  nameZh: "試用會員",
  nameEn: "Trial",
  ring: "#5ED0C8",
  glow: "rgba(94,208,200,0.55)",
  cardFrom: "#D8F7F3",
  cardTo: "#FFF6E8",
  bonus: "7d",
  motion: true,
};

/** 累计实付美元（不含退款）达到即解锁该档；与付费卡取较高档 */
export const MEMBER_SPEND_USD: Record<Exclude<MemberFrameLevel, 0>, number> = {
  1: 30,
  2: 99,
  3: 299,
  4: 799,
  5: 1999,
  6: 4999,
};

export const PLAN_TO_LEVEL: Record<string, MemberFrameLevel> = {
  free: 0,
  month: 2,
  quarter: 3,
  year: 5,
  ever: 6,
};

export const SHOP_GIFT_RATIO = 0.03;
export const SHOP_GIFT_ORDER_CAP = 500;
export const CARD_DAILY_HARD_CAP = 8;

export const PLAN_POINT_GRANT: Record<
  string,
  { daily: number; pool: number; days: number }
> = {
  month: { daily: 7, pool: 200, days: 30 },
  quarter: { daily: 7, pool: 630, days: 90 },
  year: { daily: 7, pool: 2555, days: 365 },
  ever: { daily: 8, pool: 10000, days: 0 },
  free: { daily: 0, pool: 0, days: 7 },
};

export const MEMBER_SHOP_MULTIPLIER: Record<MemberFrameLevel, number> = {
  0: 1.0,
  1: 1.1,
  2: 1.2,
  3: 1.5,
  4: 1.8,
  5: 2.0,
  6: 2.5,
};

/** 购物确认收货赠分：实付 × 3% × 档位倍数，单笔最多 500。不是每天送的那笔。 */
export function shopGiftPoints(payUsd: number, level: MemberFrameLevel): number {
  const pay = Math.max(0, Number(payUsd) || 0);
  const base = Math.min(SHOP_GIFT_ORDER_CAP, Math.floor(pay * SHOP_GIFT_RATIO));
  const boosted = Math.floor(base * MEMBER_SHOP_MULTIPLIER[level]);
  return Math.min(SHOP_GIFT_ORDER_CAP, Math.max(0, boosted));
}

/** 会员卡每日滴灌：0 点自动入账，不用点领取。一天最多 daily，发完池子就停。 */
export function cardDailyGrant(remainingPool: number, planType: string): number {
  const grant = PLAN_POINT_GRANT[planType] ?? PLAN_POINT_GRANT.month;
  return Math.max(
    0,
    Math.min(CARD_DAILY_HARD_CAP, grant.daily, Math.floor(remainingPool)),
  );
}

export const MEMBER_PRIVILEGES: Record<
  MemberFrameLevel,
  { howZh: string; perksZh: string[] }
> = {
  0: {
    howZh: "注册即有",
    perksZh: ["静态头像框", "购物赠送积分按原比例（1.0 倍，不加成）", "无会员价"],
  },
  1: {
    howZh: "累计实付满 $30",
    perksZh: ["动态头像框", "购物赠送积分 1.1 倍", "新星身份卡"],
  },
  2: {
    howZh: "累计实付满 $99，或购买月卡",
    perksZh: ["动态头像框", "会员价", "购物赠分 1.2 倍", "每天自动 7 分（共 200）", "每月 2 张满 $15 减 $2"],
  },
  3: {
    howZh: "累计实付满 $299，或购买季卡",
    perksZh: ["动态头像框", "会员价", "购物赠分 1.5 倍", "每天自动 7 分（共 630）", "每月 2 张满 $20 减 $3"],
  },
  4: {
    howZh: "累计实付满 $799（买卡无法直接跳到翡翠）",
    perksZh: ["动态头像框", "会员价", "购物赠分 1.8 倍", "无买卡日赠", "升档当月 2 张满 $25 减 $3"],
  },
  5: {
    howZh: "累计实付满 $1,999，或购买年卡",
    perksZh: ["动态头像框", "会员价", "购物赠分 2.0 倍", "每天自动 7 分（共 2555）", "每月 2 张满 $25 减 $4"],
  },
  6: {
    howZh: "累计实付满 $4,999，或购买永久卡",
    perksZh: ["动态头像框", "会员价", "购物赠分 2.5 倍", "每天自动 8 分直到 10000 分发完", "每月 2 张满 $30 减 $5"],
  },
};

export const PLAN_REWARDS: Record<
  string,
  {
    level: MemberFrameLevel;
    days: number;
    listPrice: number;
    price: number;
    growth: number;
    points: number;
    daily: number;
    coupon: string;
    couponMin: number;
    couponTimes: number;
  }
> = {
  month: { level: 2, days: 30, listPrice: 29.99, price: 19.99, growth: 0, points: 200, daily: 7, coupon: "$2", couponMin: 15, couponTimes: 2 },
  quarter: { level: 3, days: 90, listPrice: 69.99, price: 49.99, growth: 0, points: 630, daily: 7, coupon: "$3", couponMin: 20, couponTimes: 2 },
  year: { level: 5, days: 365, listPrice: 199.99, price: 149.99, growth: 0, points: 2555, daily: 7, coupon: "$4", couponMin: 25, couponTimes: 2 },
  ever: { level: 6, days: 0, listPrice: 499, price: 399, growth: 0, points: 10000, daily: 8, coupon: "$5", couponMin: 30, couponTimes: 2 },
  free: { level: 0, days: 7, listPrice: 0, price: 0, growth: 0, points: 0, daily: 0, coupon: "", couponMin: 0, couponTimes: 0 },
};

export type MemberFrameState = {
  level: MemberFrameLevel;
  trialActive: boolean;
  motion: boolean;
};

export function spendToLevel(spendUsd: number): MemberFrameLevel {
  const n = Number(spendUsd);
  if (!Number.isFinite(n) || n < MEMBER_SPEND_USD[1]) return 0;
  if (n >= MEMBER_SPEND_USD[6]) return 6;
  if (n >= MEMBER_SPEND_USD[5]) return 5;
  if (n >= MEMBER_SPEND_USD[4]) return 4;
  if (n >= MEMBER_SPEND_USD[3]) return 3;
  if (n >= MEMBER_SPEND_USD[2]) return 2;
  return 1;
}

export function paidPlanToLevel(input: {
  isEverLevel?: number | string | null;
  isMoneyLevel?: number | string | null;
  overdueTime?: number | string | null;
  memberType?: string | null;
}): MemberFrameLevel {
  if (Number(input.isEverLevel ?? 0) === 1) return 6;
  const overdue = Number(input.overdueTime ?? 0);
  const money = Number(input.isMoneyLevel ?? 0) > 0;
  const stillActive = money && (overdue <= 0 || overdue * 1000 > Date.now());
  if (!stillActive) return 0;
  const type = String(input.memberType ?? "");
  if (type === "ever") return 6;
  if (type === "year") return 5;
  if (type === "quarter") return 3;
  if (type === "month") return 2;
  if (type === "free") return 0;
  const leftDays = overdue > 0 ? (overdue * 1000 - Date.now()) / 86400000 : 30;
  if (leftDays >= 300) return 5;
  if (leftDays >= 80) return 3;
  return 2;
}

export function isTrialMembership(input: {
  isMoneyLevel?: number | string | null;
  isEverLevel?: number | string | null;
  overdueTime?: number | string | null;
  memberType?: string | null;
}): boolean {
  if (Number(input.isEverLevel ?? 0) === 1) return false;
  const type = String(input.memberType ?? "");
  if (type && type !== "free") return false;
  const overdue = Number(input.overdueTime ?? 0);
  const money = Number(input.isMoneyLevel ?? 0);
  const stillActive = money > 0 && (overdue <= 0 || overdue * 1000 > Date.now());
  if (!stillActive) return false;
  if (type === "free") return true;
  const leftDays = overdue > 0 ? (overdue * 1000 - Date.now()) / 86400000 : 0;
  return money === 2 && leftDays > 0 && leftDays <= 8;
}

export function clampMemberLevel(n: number): MemberFrameLevel {
  if (n >= 6) return 6;
  if (n >= 5) return 5;
  if (n >= 4) return 4;
  if (n >= 3) return 3;
  if (n >= 2) return 2;
  if (n >= 1) return 1;
  return 0;
}

export function resolveMemberFrame(input: {
  isLoggedIn?: boolean;
  isMoneyLevel?: number | string | null;
  isEverLevel?: number | string | null;
  overdueTime?: number | string | null;
  memberType?: string | null;
  spendUsd?: number | string | null;
}): MemberFrameState {
  if (!input.isLoggedIn) {
    return { level: 0, trialActive: false, motion: false };
  }
  const spendLevel = spendToLevel(Number(input.spendUsd ?? 0));
  const paidLevel = paidPlanToLevel(input);
  const trialActive = isTrialMembership(input) && spendLevel === 0 && paidLevel === 0;
  const level = clampMemberLevel(Math.max(spendLevel, paidLevel));
  const motion = trialActive || MEMBER_FRAME_TIERS[level].motion;
  return { level, trialActive, motion };
}

export function resolveMemberFrameLevel(
  input: Parameters<typeof resolveMemberFrame>[0] & { userLevel?: number | string | null },
): MemberFrameLevel {
  return resolveMemberFrame(input).level;
}

export function displayMemberTier(state: MemberFrameState): MemberFrameTier {
  if (state.trialActive && state.level === 0) return MEMBER_TRIAL_SKIN;
  return MEMBER_FRAME_TIERS[state.level];
}

export function memberBadgeText(level: MemberFrameLevel, zh: boolean, trial = false) {
  if (trial && level === 0) return zh ? "試用" : "TRIAL";
  const tier = MEMBER_FRAME_TIERS[level] ?? MEMBER_FRAME_TIERS[0];
  if (level === 0) return zh ? "普通" : "REGULAR";
  return `LV${level} ${zh ? tier.nameZh.replace("會員", "") : tier.nameEn}`;
}

export function parseUserLevelPayload(raw: unknown) {
  const data = unwrapApiData<Record<string, any>>(raw, {});
  const nested = data.user && typeof data.user === "object" ? data.user : null;
  const user = nested ?? data;
  const levelInfo =
    data.level_info && typeof data.level_info === "object" ? data.level_info : {};
  const levelList = Array.isArray(data.level_list) ? data.level_list : [];
  const grade = Number(levelInfo.grade ?? user.level ?? 0);
  const exp = Number(levelInfo.exp ?? user.exp ?? 0);
  const todayExp = Number(levelInfo.today_exp ?? 0);
  const nextFromList = levelList.find((row: any) => Number(row?.grade ?? 0) > grade);
  const currentFromList = levelList.find((row: any) => Number(row?.grade ?? 0) === grade);
  const nextExp = Number(
    nextFromList?.exp_num ?? currentFromList?.next_exp_num ?? levelInfo.next_exp_num ?? 0,
  );
  return { user, levelInfo, levelList, grade, exp, todayExp, nextExp };
}

export function memberTierLabel(level: MemberFrameLevel, zh: boolean, trial = false) {
  if (trial && level === 0) return zh ? MEMBER_TRIAL_SKIN.nameZh : "Trial Member";
  const tier = MEMBER_FRAME_TIERS[level];
  return zh ? tier.nameZh : `${tier.nameEn} Member`;
}
