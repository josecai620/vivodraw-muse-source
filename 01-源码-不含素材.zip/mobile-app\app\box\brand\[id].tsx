/**
 * 品牌详情 - Boxes under a specific brand
 */
import React from "react";
import { Pressable, ScrollView, Text, View, ActivityIndicator } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { ChevronRight, Package } from "lucide-react-native";
import { BoxHeader, BoxEmptyState, BoxChestVFX } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, bs,
} from "@/lib/boxTheme";
import { useBoxBrand } from "@/hooks";

const FALLBACK_BRAND_CHEST = require("../../../assets/box-category-chests/apple-products.png");

export default function BrandDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const brandId = Number(id) || 0;

  const { data: brandData, isLoading } = useBoxBrand(brandId);

  const brand = brandData?.data || brandData || {};
  const boxes = Array.isArray(brand?.list) ? brand.list : Array.isArray(brand?.boxes) ? brand.boxes : [];
  const brandName = brand?.brand_name || brand?.name || "Brand Details";
  const brandImageUri = brand?.pic || brand?.image || null;

  const cardWidth = (bs(390) - BoxSpacing.lg * 2 - BoxSpacing.md) / 2;

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={brandName} showThemeToggle={false} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(96) }}>
          {/* Brand Hero */}
          {brandImageUri && (
            <View style={{
              borderRadius: BoxRadius.xl,
              overflow: "hidden",
              marginBottom: BoxSpacing.xl,
              borderWidth: 1,
              borderColor: BoxBorders.default,
              ...BoxShadows.elevated,
            }}>
              <Image
                source={{ uri: brandImageUri }}
                style={{ width: "100%", height: bs(180) }}
                contentFit="cover"
                transition={300}
              />
              <LinearGradient
                colors={["transparent", BoxSurfaces.card]}
                style={{
                  position: "absolute",
                  bottom: 0,
                  left: 0,
                  right: 0,
                  height: bs(80),
                }}
              />
              <View style={{
                padding: BoxSpacing.lg,
                backgroundColor: BoxSurfaces.card,
              }}>
                <Text style={[BoxTypography.h2, { color: BoxText.primary }]}>
                  {brandName}
                </Text>
                {brand.description && (
                  <Text style={[BoxTypography.body, { color: BoxText.secondary, marginTop: BoxSpacing.xs }]}>
                    {brand.description}
                  </Text>
                )}
                <View style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: BoxSpacing.xl,
                  marginTop: BoxSpacing.md,
                }}>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.xs }}>
                    <Package size={bs(14)} color={BoxAccent.gold} />
                    <Text style={[BoxTypography.caption, { color: BoxAccent.gold }]}>
                      {boxes.length} boxes
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          )}

          {/* Box Grid */}
          {isLoading ? (
            <View style={{ alignItems: "center", justifyContent: "center", paddingVertical: bs(80) }}>
              <ActivityIndicator size="large" color={BoxAccent.gold} />
            </View>
          ) : boxes.length === 0 ? (
            <BoxEmptyState
              icon={<Package size={bs(48)} color={BoxText.tertiary} />}
              title="No mystery boxes for this brand"
            />
          ) : (
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: BoxSpacing.md }}>
              {boxes.map((box: any) => {
                const imageUri = (box.pic && /^https?:\/\//.test(box.pic))
                  ? box.pic
                  : (box.image && /^https?:\/\//.test(box.image))
                    ? box.image
                    : null;

                return (
                  <Pressable
                    key={box.id}
                    onPress={() => router.push(`/box/${box.id}`)}
                    style={({ pressed }) => ({
                      width: cardWidth,
                      borderRadius: BoxRadius.xl,
                      overflow: "hidden",
                      backgroundColor: BoxSurfaces.card,
                      borderWidth: 1,
                      borderColor: BoxBorders.default,
                      transform: [{ scale: pressed ? 0.97 : 1 }],
                      ...BoxShadows.card,
                    })}
                  >
                    <View style={{
                      height: bs(112),
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: BoxSurfaces.deep,
                    }}>
                      {imageUri ? (
                        <Image
                          source={{ uri: imageUri }}
                          style={{ width: "100%", height: "100%" }}
                          contentFit="cover"
                          transition={200}
                        />
                      ) : (
                        <BoxChestVFX image={FALLBACK_BRAND_CHEST} tier="legendary" size={96} density="compact" />
                      )}
                    </View>
                    <View style={{ padding: BoxSpacing.md }}>
                      <Text
                        style={[BoxTypography.bodyBold, { color: BoxText.primary, marginBottom: BoxSpacing.xs }]}
                        numberOfLines={1}
                      >
                        {box.cate_name || box.name || "Mystery Box"}
                      </Text>
                      <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
                        <Text style={[BoxTypography.price, { color: BoxAccent.gold }]}>
                          ¥{box.price || box.min_price || 0}
                        </Text>
                        <View style={{
                          width: bs(28),
                          height: bs(28),
                          borderRadius: BoxRadius.full,
                          alignItems: "center",
                          justifyContent: "center",
                          backgroundColor: BoxAccent.goldDim,
                        }}>
                          <ChevronRight size={bs(14)} color={BoxAccent.gold} />
                        </View>
                      </View>
                    </View>
                  </Pressable>
                );
              })}
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}
