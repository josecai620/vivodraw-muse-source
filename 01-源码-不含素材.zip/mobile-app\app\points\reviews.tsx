import React, { useMemo, useState } from "react";
import { Image, Pressable, RefreshControl, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { useQueryClient } from "@tanstack/react-query";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useAddShaidanComment, useShaidanLike, useShaidanList, useUserShaidanList } from "@/hooks";
import { unwrapApiPagedList } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";

const TEAL = Colors.primary.DEFAULT;
const REACTIONS = ["❤️", "👍", "😂", "🎉", "🔥"];

function mapReview(item: any) {
  return {
    id: Number(item?.id ?? 0),
    name: String(item?.nickname ?? item?.user?.name ?? ""),
    product: String(item?.store_name ?? item?.product ?? ""),
    content: String(item?.content ?? item?.title ?? ""),
    image: normalizeImageUrl(String((item?.shaidan_images ?? item?.images ?? [])[0] ?? "")),
    likes: Number(item?.dianzhan_num ?? item?.likes ?? 0),
    time: String(item?.add_time ?? item?.time ?? ""),
  };
}

export default function PointsReviewsScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const params = useLocalSearchParams<{ tab?: string }>();
  const [activeTab, setActiveTab] = useState<"all" | "my">(params.tab === "my" ? "my" : "all");
  const [refreshing, setRefreshing] = useState(false);
  const qc = useQueryClient();
  const likeMutation = useShaidanLike();
  const addComment = useAddShaidanComment();
  const { data } = useShaidanList();
  const { data: myData } = useUserShaidanList();

  const allReviews = useMemo(() => {
    return unwrapApiPagedList<any>(data).map(mapReview).filter((row: { id: number }) => row.id > 0);
  }, [data]);
  const myReviews = useMemo(() => {
    return unwrapApiPagedList<any>(myData).map(mapReview).filter((row: { id: number }) => row.id > 0);
  }, [myData]);
  const reviews = activeTab === "my" ? myReviews : allReviews;

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.showcasePlaza")} />
      <View className="flex-row bg-white px-3" style={{ gap: 8 }}>
        {(["all", "my"] as const).map((tab) => {
          const on = activeTab === tab;
          return (
            <Pressable key={tab} className="px-2 py-2.5" onPress={() => setActiveTab(tab)}>
              <Text
                className="text-sm font-bold"
                style={{
                  color: on ? TEAL : "#6B7280",
                  borderBottomWidth: on ? 2 : 0,
                  borderBottomColor: TEAL,
                  paddingBottom: 3,
                }}
              >
                {tab === "all" ? t("pointsMall.showcasePlaza") : t("pointsMall.myShowcases")}
              </Text>
            </Pressable>
          );
        })}
      </View>
      <ScrollView
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={async () => {
              setRefreshing(true);
              await qc.invalidateQueries();
              setRefreshing(false);
            }}
            tintColor={TEAL}
          />
        }
        contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 56 }}
      >
        {reviews.length === 0 ? (
          <View className="px-8 py-16">
            <Text className="text-center text-gray-400">{t("pointsMall.noComments")}</Text>
            <Text className="text-center text-gray-400 text-xs mt-3 leading-5">{t("pointsMall.showcaseEmptyHint")}</Text>
          </View>
        ) : (
          reviews.map((review) => (
            <Pressable
              key={review.id}
              className="flex-row bg-white px-3 py-3 border-b border-gray-100"
              onPress={() =>
                router.push({ pathname: "/points/review-detail", params: { id: String(review.id) } })
              }
            >
              <View className="w-16 h-16 bg-gray-50 rounded overflow-hidden mr-3">
                {review.image ? (
                  <Image source={{ uri: review.image }} className="w-full h-full" resizeMode="cover" />
                ) : null}
              </View>
              <View className="flex-1">
                <Text className="text-sm text-gray-900" numberOfLines={2}>
                  {review.content || review.product}
                </Text>
                <Text className="text-xs text-gray-500 mt-1">
                  {review.name} · {review.time}
                </Text>
                <Pressable className="mt-1 self-start" onPress={() => likeMutation.mutate(review.id)}>
                  <Text className="text-xs" style={{ color: TEAL }}>
                    {t("pointsMall.likeCount", { n: review.likes })}
                  </Text>
                </Pressable>
                <View className="flex-row mt-2" style={{ gap: 8 }}>
                  {REACTIONS.map((emoji) => (
                    <Pressable
                      key={emoji}
                      className="px-2 py-1 rounded-full bg-gray-50"
                      onPress={() => addComment.mutate({ shaidanId: review.id, content: emoji })}
                    >
                      <Text className="text-sm">{emoji}</Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            </Pressable>
          ))
        )}
      </ScrollView>
      <Pressable
        className="absolute right-4 h-10 px-3 rounded items-center justify-center"
        style={{ backgroundColor: TEAL, bottom: pointsMallTabPaddingBottom(insets.bottom) + 8 }}
        onPress={() => router.push("/points/shaidan-post")}
      >
        <Text className="text-white text-sm font-bold">{t("pointsMall.postShowcase")}</Text>
      </Pressable>
      <PointsMallTabBar />
    </View>
  );
}
