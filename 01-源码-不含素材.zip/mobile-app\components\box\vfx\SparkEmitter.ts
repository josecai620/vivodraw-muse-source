import { Container, Sprite, Texture } from 'pixi.js';

export interface SparkEmitterConfig {
  sparkCount: number; // sparkCount：火星粒子数量
  particleColor: number; // particleColor：粒子颜色
  particleSize: number; // particleSize：粒子大小
}

interface SparkRhythm {
  charge: number; // charge：聚能强度
  burst: number; // burst：爆闪强度
  afterglow: number; // afterglow：余辉强度
  scatter: number; // scatter：粒子散落强度
  brightness: number; // brightness：整体亮度节奏
}

type ParticleKind = 'feather' | 'comet' | 'star' | 'ember';

interface SparkParticle {
  sprite: Sprite; // sprite：粒子纹理精灵
  seed: number; // seed：随机种子
  life: number; // life：生命周期相位
  speed: number; // speed：上升速度
  arc: number; // arc：能量场弧度
  size: number; // size：基础尺寸
  color: number; // color：粒子颜色
  rotation: number; // rotation：粒子旋转
  kind: ParticleKind; // kind：粒子类型
  alpha: number; // alpha：基础透明度
}

export class SparkEmitter { // SparkEmitter：火星与能量光屑发射器
  private readonly sparks: SparkParticle[] = []; // sparks：粒子池列表
  private readonly textures: Record<ParticleKind, Texture>; // textures：粒子软纹理集合
  private readonly centerX: number; // centerX：矿石中心 X
  private readonly baseY: number; // baseY：粒子底部 Y

  constructor(layer: Container, centerX: number, baseY: number) {
    this.centerX = centerX; // centerX：保存中心 X
    this.baseY = baseY; // baseY：保存底部 Y
    this.textures = {
      feather: this.createFeatherTexture(), // feather：能量羽片纹理
      comet: this.createCometTexture(), // comet：流星碎光纹理
      star: this.createStarTexture(), // star：小星芒纹理
      ember: this.createEmberTexture(), // ember：拖尾火星纹理
    };

    for (let index = 0; index < 64; index += 1) { // index：粒子池序号
      const kind = this.pickKind(index); // kind：粒子类型
      const sprite = new Sprite(this.textures[kind]); // sprite：单个粒子精灵
      sprite.anchor.set(0.5);
      sprite.blendMode = 'add';
      this.sparks.push({
        sprite,
        seed: Math.random(), // seed：随机种子
        life: Math.random(), // life：生命周期相位
        speed: 0.36 + Math.random() * 1.18, // speed：上升速度
        arc: -58 + Math.random() * 116, // arc：能量场弧度
        size: 0.34 + Math.random() * 0.92, // size：基础缩放
        color: Math.random() > 0.58 ? 0xb2ecee : 0x9fe4e6, // color：粒子颜色（teal 系）
        rotation: Math.random() * Math.PI * 2, // rotation：粒子旋转
        kind,
        alpha: 0.38 + Math.random() * 0.42, // alpha：基础透明度
      });
      layer.addChild(sprite);
    }
  }

  update(time: number, delta: number, config: SparkEmitterConfig, rhythm: SparkRhythm) {
    const activeCount = Math.floor(config.sparkCount * (0.62 + rhythm.charge * 0.14) + rhythm.scatter * 18); // activeCount：当前启用粒子数量
    this.sparks.forEach((sparkItem, index) => {
      const visible = index < activeCount; // visible：是否显示该粒子
      sparkItem.sprite.visible = visible;
      if (!visible) return;
      sparkItem.life = (sparkItem.life + delta * sparkItem.speed * (0.24 + rhythm.scatter * 0.24)) % 1;

      const orbit = sparkItem.life * Math.PI * 2 + sparkItem.seed * 6.28; // orbit：能量轨道相位
      const ringPull = Math.sin(time * 1.35 + orbit) * 22; // ringPull：能量环牵引
      const drift = Math.sin(time * 2.6 + sparkItem.seed * 20) * 20 + sparkItem.arc * sparkItem.life + ringPull; // drift：横向漂移
      const x = this.centerX - 132 + sparkItem.seed * 264 + drift; // x：粒子 X 坐标
      const y = this.baseY - sparkItem.life * 318 + Math.sin(time * 2 + sparkItem.seed) * 9; // y：粒子 Y 坐标
      const edgeDistance = Math.abs(Math.hypot(x - this.centerX, (y - (this.baseY - 160)) * 1.12) - 142); // edgeDistance：距矿石边缘估计
      const edgeBoost = edgeDistance < 28 ? 1.24 + rhythm.afterglow * 0.2 : 1; // edgeBoost：经过矿石边缘增亮
      const centerDistance = Math.hypot(x - this.centerX, y - (this.baseY - 160)); // centerDistance：距矿石中心估计
      const centerMask = centerDistance < 92 ? 0.24 + centerDistance / 130 : 1; // centerMask：主体区域遮挡衰减
      const fade = Math.sin(sparkItem.life * Math.PI); // fade：生命周期淡入淡出
      const airFlicker = 0.82 + Math.sin(time * 5.4 + sparkItem.seed * 11) * 0.18; // airFlicker：空气闪烁
      const scale = sparkItem.size * (0.68 + airFlicker * 0.18 + rhythm.scatter * 0.16) * edgeBoost; // scale：当前缩放

      sparkItem.sprite.x = x;
      sparkItem.sprite.y = y;
      sparkItem.sprite.tint = sparkItem.kind === 'ember' ? sparkItem.color : config.particleColor;
      sparkItem.sprite.alpha = fade * sparkItem.alpha * airFlicker * edgeBoost * centerMask * (0.55 + rhythm.scatter * 0.6) * rhythm.brightness;
      sparkItem.sprite.rotation = sparkItem.rotation + time * (0.48 + sparkItem.speed * 0.62);
      sparkItem.sprite.scale.set(scale * config.particleSize * this.kindScaleX(sparkItem.kind), scale * config.particleSize * this.kindScaleY(sparkItem.kind));
    });
  }

  private pickKind(index: number): ParticleKind {
    if (index % 8 === 0) return 'star';
    if (index % 4 === 0) return 'comet';
    if (index % 3 === 0) return 'ember';
    return 'feather';
  }

  private kindScaleX(kind: ParticleKind) {
    if (kind === 'comet') return 1.24;
    if (kind === 'feather') return 0.88;
    return 1;
  }

  private kindScaleY(kind: ParticleKind) {
    if (kind === 'comet') return 0.72;
    if (kind === 'feather') return 1.18;
    return 1;
  }

  private createFeatherTexture() {
    const canvas = this.createCanvas(); // canvas：羽片离屏画布
    const context = canvas.getContext('2d'); // context：画布上下文
    if (!context) return Texture.EMPTY;
    context.translate(64, 64);
    context.rotate(-0.22);
    context.shadowColor = 'rgba(127, 216, 220, 0.7)';
    context.shadowBlur = 14;
    const gradient = context.createLinearGradient(-38, 12, 42, -22); // gradient：羽片渐变
    gradient.addColorStop(0, 'rgba(207,243,244,0)');
    gradient.addColorStop(0.36, 'rgba(127,216,220,0.72)');
    gradient.addColorStop(1, 'rgba(159,228,230,0)');
    context.fillStyle = gradient;
    context.beginPath();
    context.moveTo(42, -24);
    context.bezierCurveTo(12, -20, -22, -4, -42, 22);
    context.bezierCurveTo(-10, 18, 24, 8, 42, -24);
    context.closePath();
    context.fill();
    return Texture.from(canvas);
  }

  private createCometTexture() {
    const canvas = this.createCanvas(); // canvas：流星离屏画布
    const context = canvas.getContext('2d'); // context：画布上下文
    if (!context) return Texture.EMPTY;
    const trail = context.createLinearGradient(18, 64, 104, 64); // trail：拖尾渐变
    trail.addColorStop(0, 'rgba(127,216,220,0)');
    trail.addColorStop(0.55, 'rgba(127,216,220,0.34)');
    trail.addColorStop(1, 'rgba(234,251,251,0.95)');
    context.fillStyle = trail;
    context.shadowColor = 'rgba(127,216,220,0.7)';
    context.shadowBlur = 12;
    context.beginPath();
    context.moveTo(108, 64);
    context.bezierCurveTo(70, 52, 36, 54, 14, 63);
    context.bezierCurveTo(36, 74, 72, 78, 108, 64);
    context.closePath();
    context.fill();
    return Texture.from(canvas);
  }

  private createStarTexture() {
    const canvas = this.createCanvas(); // canvas：星芒离屏画布
    const context = canvas.getContext('2d'); // context：画布上下文
    if (!context) return Texture.EMPTY;
    const glow = context.createRadialGradient(64, 64, 0, 64, 64, 42); // glow：星芒径向光
    glow.addColorStop(0, 'rgba(234,251,251,0.95)');
    glow.addColorStop(0.24, 'rgba(127,216,220,0.36)');
    glow.addColorStop(1, 'rgba(127,216,220,0)');
    context.fillStyle = glow;
    context.fillRect(0, 0, 128, 128);
    context.strokeStyle = 'rgba(234,251,251,0.82)';
    context.lineWidth = 3;
    context.shadowColor = 'rgba(159,228,230,0.8)';
    context.shadowBlur = 10;
    context.beginPath();
    context.moveTo(22, 64);
    context.lineTo(106, 64);
    context.moveTo(64, 30);
    context.lineTo(64, 98);
    context.stroke();
    return Texture.from(canvas);
  }

  private createEmberTexture() {
    const canvas = this.createCanvas(); // canvas：火星离屏画布
    const context = canvas.getContext('2d'); // context：画布上下文
    if (!context) return Texture.EMPTY;
    context.translate(64, 64);
    const gradient = context.createRadialGradient(0, 0, 0, 0, 0, 42); // gradient：火星径向光
    gradient.addColorStop(0, 'rgba(234,251,251,0.95)');
    gradient.addColorStop(0.32, 'rgba(8,174,180,0.5)');
    gradient.addColorStop(1, 'rgba(7,133,140,0)');
    context.fillStyle = gradient;
    context.shadowColor = 'rgba(4,168,174,0.7)';
    context.shadowBlur = 10;
    context.beginPath();
    context.moveTo(24, -8);
    context.bezierCurveTo(8, -26, -18, -12, -22, 10);
    context.bezierCurveTo(-6, 22, 18, 18, 24, -8);
    context.closePath();
    context.fill();
    return Texture.from(canvas);
  }

  private createCanvas() {
    const canvas = document.createElement('canvas'); // canvas：通用离屏画布
    canvas.width = 128;
    canvas.height = 128;
    return canvas;
  }
}
