import React, { useState } from "react";
import { Pressable, ScrollView, Text, View, ActivityIndicator } from "react-native";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Heart, Star, Trash2 } from "lucide-react-native";
import { Image } from "expo-image";
import { SafeAreaView } from "react-native-safe-area-context";
import { BoxHeader, RarityBadge, BoxActionButton, BoxEmptyState, BoxTabBar, BoxChestVFX } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  getRarityTier, bs,
} from "@/lib/boxTheme";
import { useBoxTuijian, useWishlistList, useAddWishlistItem, useRemoveWishlistItem, useWishlistNotifications, useWishlistUnreadCount } from "@/hooks";
import { Bell } from "lucide-react-native";

const FALLBACK_WISHLIST_CHEST = require("../../assets/box-category-chests/apple-products.png");

export default function WishlistPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const { data: boxes } = useBoxTuijian();
  const { data: wishlist, isLoading } = useWishlistList();
  const addMutation = useAddWishlistItem();
  const removeMutation = useRemoveWishlistItem();
  const [showAdd, setShowAdd] = useState(false);

  const list: any[] = Array.isArray(wishlist) ? wishlist : [];

  const rarityStats = list.reduce<Record<string, number>>((acc, w) => {
    acc[w.rarity] = (acc[w.rarity] || 0) + 1;
    return acc;
  }, {});

  const handleAdd = (boxId: number, boxName: string) => {
    addMutation.mutate({ box_id: boxId, item_name: t("wishlist.defaultItem"), rarity: "legendary" });
    setShowAdd(false);
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: BoxSurfaces.void }}>
        <ActivityIndicator size="large" color={BoxAccent.gold} />
      </View>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("wishlist.title")} showThemeToggle={false} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(96) }}>
          {/* Stats Banner */}
          <View style={{
            borderRadius: BoxRadius["2xl"],
            overflow: "hidden",
            marginBottom: BoxSpacing["2xl"],
            borderWidth: 1,
            borderColor: BoxAccent.goldBorder,
            ...BoxShadows.glow(BoxAccent.gold),
          }}>
            <LinearGradient
              colors={BoxGradients.goldWarm}
              style={{ padding: BoxSpacing.xl }}
            >
              <View style={{
                flexDirection: "row",
                alignItems: "center",
                gap: BoxSpacing.sm,
                marginBottom: BoxSpacing.md,
              }}>
                <Star size={bs(20)} color={BoxAccent.gold} />
                <Text style={[BoxTypography.h2, { color: BoxText.primary }]}>
                  {t("wishlist.myWish")}
                </Text>
              </View>
              <View style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}>
                <View style={{ alignItems: "center" }}>
                  <Text style={[BoxTypography.hero, { color: BoxAccent.gold }]}>
                    {list.length}
                  </Text>
                  <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
                    {t("wishlist.wishItems")}
                  </Text>
                </View>
                <View style={{ flexDirection: "row", gap: BoxSpacing.sm }}>
                  {Object.entries(rarityStats).map(([rarity, count]) => {
                    const rc = getRarityTier(rarity);
                    return (
                      <View key={rarity} style={{
                        alignItems: "center",
                        paddingHorizontal: BoxSpacing.md,
                        paddingVertical: BoxSpacing.sm,
                        borderRadius: BoxRadius.full,
                        backgroundColor: rc.bgSubtle,
                      }}>
                        <Text style={[BoxTypography.bodyBold, { color: rc.color }]}>
                          {count as number}
                        </Text>
                        <Text style={[BoxTypography.micro, { color: rc.color }]}>
                          {t("rarity." + rarity)}
                        </Text>
                      </View>
                    );
                  })}
                </View>
              </View>
            </LinearGradient>
          </View>

          {/* Add Wish Toggle */}
          <Pressable
            onPress={() => setShowAdd(!showAdd)}
            style={{
              borderRadius: BoxRadius.xl,
              padding: BoxSpacing.lg,
              marginBottom: BoxSpacing.lg,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: BoxSpacing.sm,
              backgroundColor: showAdd ? BoxAccent.goldMuted : BoxSurfaces.card,
              borderWidth: 1,
              borderColor: showAdd ? BoxAccent.gold : BoxBorders.default,
              borderStyle: showAdd ? "solid" : "dashed",
            }}
          >
            <Heart size={bs(18)} color={BoxAccent.gold} />
            <Text style={[BoxTypography.buttonSmall, { color: BoxAccent.gold }]}>
              {showAdd ? t("wishlist.collapse") : t("wishlist.addWish")}
            </Text>
          </Pressable>

          {/* Add Panel */}
          {showAdd && (
            <View style={{
              borderRadius: BoxRadius.xl,
              padding: BoxSpacing.lg,
              marginBottom: BoxSpacing["2xl"],
              backgroundColor: BoxSurfaces.card,
              borderWidth: 1,
              borderColor: BoxAccent.goldBorder,
            }}>
              <Text style={[BoxTypography.bodyBold, { color: BoxText.primary, marginBottom: BoxSpacing.md }]}>
                {t("wishlist.selectFromSeries")}
              </Text>
              {(boxes || []).map((box: any) => (
                <View
                  key={box.id}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: BoxSpacing.md,
                    borderRadius: BoxRadius.lg,
                    marginBottom: BoxSpacing.sm,
                    backgroundColor: BoxSurfaces.deep,
                    borderWidth: 1,
                    borderColor: BoxBorders.default,
                  }}
                >
                  <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.md }}>
                    <View style={{ width: bs(44), height: bs(44), alignItems: "center", justifyContent: "center" }}>
                      <BoxChestVFX image={FALLBACK_WISHLIST_CHEST} tier="legendary" size={54} density="compact" />
                    </View>
                    <View>
                      <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>
                        {box.name || t("wishlist.defaultSeries")}
                      </Text>
                      <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
                        {t("wishlist.pointsPerOpen", { pts: box.price })}
                      </Text>
                    </View>
                  </View>
                  <Pressable
                    onPress={() => handleAdd(box.id, box.name || t("wishlist.defaultSeries"))}
                    disabled={addMutation.isPending}
                    style={{
                      paddingHorizontal: BoxSpacing.md,
                      paddingVertical: BoxSpacing.sm,
                      borderRadius: BoxRadius.full,
                      backgroundColor: BoxAccent.goldMuted,
                    }}
                  >
                    <Text style={[BoxTypography.caption, { color: BoxAccent.gold }]}>
                      {addMutation.isPending ? "..." : t("wishlist.wish")}
                    </Text>
                  </Pressable>
                </View>
              ))}
            </View>
          )}

          {/* Notification Badge */}
          <Pressable onPress={() => router.push("/box/wishlist-notifications" as any)} style={{
            borderRadius: BoxRadius.xl, padding: BoxSpacing.lg, marginBottom: BoxSpacing.lg,
            flexDirection: "row", alignItems: "center", gap: BoxSpacing.md,
            backgroundColor: BoxSurfaces.card, borderWidth: 1, borderColor: BoxBorders.default,
          }}>
            <Bell size={bs(20)} color={BoxAccent.gold} />
            <Text style={[BoxTypography.body, { color: BoxText.primary, flex: 1 }]}>
              {t("wishlist.notifications")}
            </Text>
            <View style={{
              width: bs(8), height: bs(8), borderRadius: bs(4),
              backgroundColor: BoxAccent.red,
            }} />
          </Pressable>

          {/* Wishlist */}
          <Text style={[BoxTypography.h2, { color: BoxText.primary, marginBottom: BoxSpacing.lg }]}>
            {t("wishlist.listTitle")}
          </Text>
          {list.length === 0 ? (
            <BoxEmptyState
              icon={<Star size={bs(48)} color={BoxText.tertiary} />}
              title={t("wishlist.empty")}
              description={t("wishlist.emptyHint")}
            />
          ) : (
            list.map((wish: any) => {
              const rc = getRarityTier(wish.rarity);
              return (
                <View
                  key={wish.id}
                  style={{
                    borderRadius: BoxRadius.xl,
                    padding: BoxSpacing.lg,
                    marginBottom: BoxSpacing.md,
                    flexDirection: "row",
                    alignItems: "center",
                    gap: BoxSpacing.md,
                    backgroundColor: BoxSurfaces.card,
                    borderWidth: 1,
                    borderColor: rc.borderColor,
                    ...BoxShadows.subtle,
                  }}
                >
                  <View style={{
                    width: bs(48), height: bs(48), borderRadius: BoxRadius.lg, overflow: "hidden",
                    alignItems: "center", justifyContent: "center",
                    backgroundColor: rc.bgSubtle,
                  }}>
                    {wish.item_image && /^https?:\/\//i.test(String(wish.item_image)) ? (
                      <Image source={{ uri: String(wish.item_image) }} style={{ width: "100%", height: "100%" }} contentFit="cover" />
                    ) : (
                      <Star size={bs(22)} color={BoxAccent.gold} strokeWidth={1.6} />
                    )}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>
                      {wish.item_name}
                    </Text>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm, marginTop: 2 }}>
                      <RarityBadge tier={wish.rarity} size="sm" />
                      <Text style={[BoxTypography.micro, { color: BoxText.tertiary }]}>
                        {t("wishlist.from", { name: wish.box_name })}
                      </Text>
                    </View>
                  </View>
                  <Pressable
                    onPress={() => removeMutation.mutate({ id: wish.id })}
                    disabled={removeMutation.isPending}
                    style={{ padding: BoxSpacing.sm }}
                  >
                    <Trash2 size={bs(18)} color={BoxAccent.red} />
                  </Pressable>
                </View>
              );
            })
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
