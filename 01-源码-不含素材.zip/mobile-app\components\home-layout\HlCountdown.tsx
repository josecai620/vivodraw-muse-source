import React, { useEffect, useState } from "react";
import { Pressable, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { Colors } from "@/constants/theme";
import { pickLang } from "./utils";

interface HlCountdownProps {
  props: {
    title?: { en?: string; zh?: string } | string;
    endAt?: number | string; // 秒级时间戳或 ISO
    link?: string;
    bg?: string;
    text_color?: string;
  };
  lang: string;
}

function resolveEndTs(raw: unknown): number {
  if (raw == null) return 0;
  if (typeof raw === "number") {
    // 秒 or 毫秒
    return raw > 10_000_000_000 ? raw : raw * 1000;
  }
  const n = Number(raw);
  if (!isNaN(n) && n > 0) return n > 10_000_000_000 ? n : n * 1000;
  const d = Date.parse(String(raw));
  return isNaN(d) ? 0 : d;
}

function formatRemain(ms: number, lang: string) {
  if (ms <= 0) return lang === "en" ? "Ended" : "已結束";
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return d > 0 ? `${d}d ${pad(h)}:${pad(m)}:${pad(ss)}` : `${pad(h)}:${pad(m)}:${pad(ss)}`;
}

/** 倒计时：秒杀/活动用 */
export default function HlCountdown({ props, lang }: HlCountdownProps) {
  const router = useRouter();
  const endTs = resolveEndTs(props.endAt);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    if (!endTs) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [endTs]);

  if (!endTs) return null;
  const remain = endTs - now;
  const title = pickLang(props.title, lang) || (lang === "en" ? "Limited Time" : "限時活動");
  const bg = props.bg || Colors.brand.red;
  const color = props.text_color || "#FFFFFF";

  return (
    <Pressable onPress={() => props.link && router.push(props.link as any)} className="mx-4 mt-3 rounded-xl px-4 py-3 flex-row items-center justify-between" style={{ backgroundColor: bg }}>
      <View>
        <Text style={{ color, fontSize: 13, fontWeight: "600" }}>⏰ {title}</Text>
      </View>
      <View className="rounded-lg px-3 py-1" style={{ backgroundColor: "rgba(255,255,255,0.15)" }}>
        <Text style={{ color, fontSize: 16, fontWeight: "700", fontVariant: ["tabular-nums"] }}>{formatRemain(remain, lang)}</Text>
      </View>
    </Pressable>
  );
}
