import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import { changePassword } from "@/lib/api/user";
import { useAppStore } from "@/store/app";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { Eye, EyeOff, Lock } from "lucide-react-native";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";

function getErrorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

export default function ChangePasswordScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const showToast = useAppStore((s) => s.showToast);

  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showOld, setShowOld] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const canSubmit =
    oldPassword.length > 0 && newPassword.length >= 6 && newPassword === confirmPassword;

  const handleSubmit = async () => {
    if (submitting) return;

    if (newPassword.length < 6 || newPassword.length > 16) {
      showToast(t("settings.passwordTooShort"), "error");
      return;
    }
    if (newPassword !== confirmPassword) {
      showToast(t("settings.passwordsDontMatch"), "error");
      return;
    }

    setSubmitting(true);
    try {
      await changePassword({ old_password: oldPassword, new_password: newPassword });
      showToast(t("settings.passwordChanged"), "success");
      router.back();
    } catch (err: unknown) {
      showToast(getErrorMessage(err, t("settings.passwordChangeFailed")), "error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-neutral-50"
    >
      <PageHeader title={t("settings.changePassword")} />

      <ScrollView
        className="flex-1 px-4 pt-6"
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <View className="bg-white rounded-2xl p-5 mb-4 gap-5">
          {/* Current Password */}
          <View>
            <Text className="text-sm font-medium text-neutral-700 mb-2">
              {t("settings.currentPassword")}
            </Text>
            <View className="relative">
              <View className="absolute left-3.5 top-3 z-10">
                <Lock size={20} color={Colors.neutral[400]} />
              </View>
              <TextInput
                value={oldPassword}
                onChangeText={setOldPassword}
                placeholder={t("settings.enterCurrentPassword")}
                placeholderTextColor={Colors.neutral[400]}
                secureTextEntry={!showOld}
                className="w-full pl-12 pr-12 h-12 bg-neutral-50 border border-neutral-200 rounded-xl text-sm"
              />
              <Pressable
                className="absolute right-3 top-3 z-10 p-0.5"
                onPress={() => setShowOld(!showOld)}
              >
                {showOld ? (
                  <EyeOff size={18} color={Colors.neutral[400]} />
                ) : (
                  <Eye size={18} color={Colors.neutral[400]} />
                )}
              </Pressable>
            </View>
          </View>

          {/* New Password */}
          <View>
            <Text className="text-sm font-medium text-neutral-700 mb-2">
              {t("settings.newPassword")}
            </Text>
            <View className="relative">
              <View className="absolute left-3.5 top-3 z-10">
                <Lock size={20} color={Colors.neutral[400]} />
              </View>
              <TextInput
                value={newPassword}
                onChangeText={setNewPassword}
                placeholder={t("settings.enterNewPassword")}
                placeholderTextColor={Colors.neutral[400]}
                secureTextEntry={!showNew}
                className="w-full pl-12 pr-12 h-12 bg-neutral-50 border border-neutral-200 rounded-xl text-sm"
              />
              <Pressable
                className="absolute right-3 top-3 z-10 p-0.5"
                onPress={() => setShowNew(!showNew)}
              >
                {showNew ? (
                  <EyeOff size={18} color={Colors.neutral[400]} />
                ) : (
                  <Eye size={18} color={Colors.neutral[400]} />
                )}
              </Pressable>
            </View>
          </View>

          {/* Confirm New Password */}
          <View>
            <Text className="text-sm font-medium text-neutral-700 mb-2">
              {t("settings.confirmNewPassword")}
            </Text>
            <View className="relative">
              <View className="absolute left-3.5 top-3 z-10">
                <Lock size={20} color={Colors.neutral[400]} />
              </View>
              <TextInput
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                placeholder={t("settings.reenterNewPassword")}
                placeholderTextColor={Colors.neutral[400]}
                secureTextEntry={!showConfirm}
                className="w-full pl-12 pr-12 h-12 bg-neutral-50 border border-neutral-200 rounded-xl text-sm"
              />
              <Pressable
                className="absolute right-3 top-3 z-10 p-0.5"
                onPress={() => setShowConfirm(!showConfirm)}
              >
                {showConfirm ? (
                  <EyeOff size={18} color={Colors.neutral[400]} />
                ) : (
                  <Eye size={18} color={Colors.neutral[400]} />
                )}
              </Pressable>
            </View>
            {confirmPassword.length > 0 && newPassword !== confirmPassword && (
              <Text className="text-xs text-brand-red mt-1">{t("settings.passwordsDontMatch")}</Text>
            )}
          </View>
        </View>

        {/* Submit */}
        <Pressable
          className="rounded-xl overflow-hidden mb-4"
          style={{ opacity: canSubmit && !submitting ? 1 : 0.5 }}
          onPress={handleSubmit}
          disabled={!canSubmit || submitting}
        >
          <LinearGradient
            colors={
              canSubmit
                ? [TealGradient.light, TealGradient.base, TealGradient.dark]
                : [Colors.neutral[300], Colors.neutral[300]]
            }
            start={{ x: 0, y: 0.5 }}
            end={{ x: 1, y: 0.5 }}
            className="h-12 items-center justify-center rounded-xl"
          >
            {canSubmit && (
              <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 12 }} />
            )}
            {submitting ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Text className="text-white font-bold text-base">
                {t("settings.changePasswordBtn")}
              </Text>
            )}
          </LinearGradient>
        </Pressable>

        {/* Forgot password fallback */}
        <Pressable
          className="items-center py-3"
          onPress={() => router.push("/auth/forgot-password")}
        >
          <Text className="text-sm" style={{ color: Colors.brand.red }}>
            {t("settings.forgotCurrentPassword")}
          </Text>
        </Pressable>

        <View className="h-8" />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
