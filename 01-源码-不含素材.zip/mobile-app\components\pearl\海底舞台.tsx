import React, { memo, useEffect, useRef, useState } from "react";
import {
  Animated,
  AppState,
  Easing,
  Image,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
  type LayoutChangeEvent,
} from "react-native";



import { usePearlT } from "@/components/pearl/文案";
import { SwimmingCompanions } from "@/components/pearl/会游泳的伙伴";
import type { PearlKey, PearlTell } from "@/lib/api/pearl";

export type { PearlKey };
export type PearlPhase = "idle" | "submitting" | "selected" | "all";

export type PearlStageProps = {
  selectedShell: number | null;
  selectedShells?: number[];
  shells: Array<{ index: number; pearlKey: PearlKey | null; tells?: PearlTell[] }> | null;
  phase: PearlPhase;
  disabled: boolean;
  reducedMotion: boolean;
  curtain?: boolean;
  lifeIds?: string[];
  onSelect: (index: number) => void;
  onCurtain?: () => void;
  onDragging?: (v: boolean) => void;
};

const CLOSED_SHELL = Platform.OS === "web"
  ? require("../../assets/海底寻珠/闭合珍珠蚌-轻量.webp")
  : require("../../assets/海底寻珠/闭合珍珠蚌.png");
const OPEN_SHELL = Platform.OS === "web"
  ? require("../../assets/海底寻珠/打开珍珠蚌-轻量.webp")
  : require("../../assets/海底寻珠/打开珍珠蚌.png");
// 六只蚌共用线上这套手绘壳，靠各自错峰的呼吸、微张合与水流轻摆区分律动。
// breath = [单程毫秒, 停顿毫秒, 缩放幅度]；gape = [单程毫秒, 最大张合度]；sway = [横摆px, 摆角deg, 相位]。
const CLAM_MOTION = [
  { breath: [1250, 620, 0.020], gape: [2400, 0.12], sway: [2.6, 0.7, 0.0] },
  { breath: [1080, 480, 0.016], gape: [2050, 0.10], sway: [2.0, 0.55, 0.17] },
  { breath: [1430, 700, 0.026], gape: [2680, 0.15], sway: [3.4, 0.9, 0.34] },
  { breath: [1160, 560, 0.018], gape: [2270, 0.11], sway: [2.3, 0.6, 0.51] },
  { breath: [1340, 640, 0.022], gape: [2520, 0.13], sway: [2.9, 0.78, 0.68] },
  { breath: [1220, 600, 0.020], gape: [2360, 0.11], sway: [2.7, 0.72, 0.85] },
] as const;
const USE_NATIVE_DRIVER = Platform.OS !== "web";
const REVEAL_EASING = Easing.bezier(0.22, 1, 0.36, 1);
const SHELL_INDICES = [0, 1, 2, 3, 4, 5] as const;
const NO_DECORATIONS: string[] = [];
const STAR_COLORS = ["#FFF0B9", "#D0FCED", "#FACCDD", "#D4EDFA"];
const BURST_DIRECTIONS = Array.from({ length: 10 }, (_, index) => {
  const angle = (index / 10) * Math.PI * 2 - Math.PI / 2;
  return { x: Math.cos(angle), y: Math.sin(angle), color: STAR_COLORS[index % STAR_COLORS.length] };
});

/** 页面失焦、进入后台时停止循环；同一套组件在原生和浏览器端共用。 */
function useMotionActive() {
  const [active, setActive] = useState(true);
  useEffect(() => {
    let focused = true;
    const sync = () => setActive(
      focused
      && AppState.currentState !== "background"
      && AppState.currentState !== "inactive"
      && (typeof document === "undefined" || !document.hidden),
    );
    const onFocus = () => { focused = true; sync(); };
    const onBlur = () => { focused = false; sync(); };
    const subscription = AppState.addEventListener("change", sync);
    if (Platform.OS === "web" && typeof document !== "undefined") {
      document.addEventListener("visibilitychange", sync);
      window.addEventListener("focus", onFocus);
      window.addEventListener("blur", onBlur);
    }
    sync();
    return () => {
      subscription.remove();
      if (Platform.OS === "web" && typeof document !== "undefined") {
        document.removeEventListener("visibilitychange", sync);
        window.removeEventListener("focus", onFocus);
        window.removeEventListener("blur", onBlur);
      }
    };
  }, []);
  return active;
}

function animateTo(value: Animated.Value, toValue: number, duration: number, easing = REVEAL_EASING) {
  return Animated.timing(value, { toValue, duration, easing, useNativeDriver: USE_NATIVE_DRIVER, isInteraction: false });
}

const PEARLS: Record<
  PearlKey,
  { label: string; rim: string; body: string; light: string; reflection: string; glow: string }
> = {
  white: {
    label: "White pearl",
    rim: "#81A4AA",
    body: "#D2E7DD",
    light: "#F4F6E9",
    reflection: "#C3D5F0",
    glow: "rgba(244, 246, 233, 0.42)",
  },
  pink: {
    label: "Pink pearl",
    rim: "#AE6B89",
    body: "#E5A2B4",
    light: "#FCE2D8",
    reflection: "#CF9ACA",
    glow: "rgba(252, 200, 210, 0.42)",
  },
  gold: {
    label: "Gold pearl",
    rim: "#A97830",
    body: "#E9B95E",
    light: "#FFF0BC",
    reflection: "#E5A25A",
    glow: "rgba(255, 229, 154, 0.5)",
  },
  black: {
    label: "Black pearl",
    rim: "#263D4B",
    body: "#40546A",
    light: "#8EA5B8",
    reflection: "#777793",
    glow: "rgba(179, 207, 225, 0.35)",
  },
  sand: {
    label: "Sand pearl",
    rim: "#8A6A45",
    body: "#C4A06A",
    light: "#E8D2A8",
    reflection: "#B08958",
    glow: "rgba(232, 210, 168, 0.35)",
  },
  aurora: {
    label: "Aurora pearl",
    rim: "#3E6E88",
    body: "#7FD0C8",
    light: "#E7FFF4",
    reflection: "#C9A6E8",
    glow: "rgba(127, 208, 200, 0.5)",
  },
  living: {
    label: "Tideheart pearl",
    rim: "#7A3A58",
    body: "#E07A9A",
    light: "#FFE0EC",
    reflection: "#F2B3C9",
    glow: "rgba(224, 122, 154, 0.5)",
  },
};

function curtainShift(index: number, span: number) {
  const column = index % 3;
  const dir = column === 0 ? -1 : column === 2 ? 1 : index < 3 ? -1 : 1;
  return dir * (column === 1 ? span * 0.78 : span);
}

/** 小尺寸原生珍珠，依靠层次和高光表现珠光，供舞台与图鉴共用。 */
export const PearlGem = memo(function PearlGem({
  pearlKey,
  size = 32,
  muted = false,
}: {
  pearlKey: PearlKey;
  size?: number;
  muted?: boolean;
}) {
  const palette = PEARLS[pearlKey] ?? PEARLS.white;
  return (
    <View
      pointerEvents="none"
      accessible={false}
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
      style={{ width: size, height: size, opacity: muted ? 0.34 : 1 }}
    >
      <View
        style={[
          styles.pearlSphere,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            backgroundColor: palette.rim,
          },
        ]}
      >
        <View
          style={[
            styles.pearlLayer,
            { left: "4%", top: "2%", width: "90%", height: "91%", backgroundColor: palette.body },
          ]}
        />
        <View
          style={[
            styles.pearlLayer,
            { left: "8%", top: "3%", width: "77%", height: "74%", backgroundColor: palette.light, opacity: 0.55 },
          ]}
        />
        <View
          style={[
            styles.pearlLayer,
            { left: "15%", top: "9%", width: "55%", height: "49%", backgroundColor: palette.light, opacity: 0.75 },
          ]}
        />
        <View
          style={[
            styles.pearlLayer,
            { right: "12%", bottom: "9%", width: "56%", height: "23%", backgroundColor: palette.reflection, opacity: 0.44, transform: [{ rotate: "-28deg" }] },
          ]}
        />
        <View style={[styles.pearlLayer, styles.pearlHighlight]} />
        <View style={[styles.pearlLayer, styles.pearlGlint]} />
      </View>
    </View>
  );
});

const TellMarks = memo(function TellMarks({ tells, size, motionEnabled }: { tells: PearlTell[]; size: number; motionEnabled: boolean }) {
  if (!tells.length) return null;
  return (
    <View pointerEvents="none" style={[styles.tellLayer, { width: size, height: size }]}>
      {tells.includes("bubbles") ? (
        <>
          <View style={[styles.tellBubble, { left: size * 0.18, bottom: size * 0.42, width: 7, height: 7 }]} />
          <View style={[styles.tellBubble, { left: size * 0.32, bottom: size * 0.58, width: 5, height: 5, opacity: 0.7 }]} />
          <View style={[styles.tellBubble, { left: size * 0.46, bottom: size * 0.5, width: 6, height: 6, opacity: 0.85 }]} />
        </>
      ) : null}
      {tells.includes("shimmer") ? <View style={[styles.tellShimmer, { width: size * 0.42, height: size * 0.18, top: size * 0.22 }]} /> : null}
      {tells.includes("ajar") ? <View style={[styles.tellAjar, { width: size * 0.28, height: 4, top: size * 0.38 }]} /> : null}
      {tells.includes("visitor") ? <View style={[styles.tellVisitor, { right: size * 0.12, top: size * 0.28 }]} /> : null}
      {tells.includes("heartbeat") ? <View style={[styles.tellHeart, motionEnabled && styles.tellHeartPulse]} /> : null}
    </View>
  );
});

type ShellProps = {
  twin?: boolean;
  index: number;
  size: number;
  selected: boolean;
  opened: boolean;
  submitting: boolean;
  pearlKey: PearlKey | null;
  tells: PearlTell[];
  disabled: boolean;
  reducedMotion: boolean;
  motionActive: boolean;
  idle: boolean;
  tide: Animated.Value;
  onSelect: (index: number) => void;
};

const Shell = memo(function Shell({
  index,
  size,
  selected,
  opened,
  submitting,
  pearlKey,
  twin = false,
  tells,
  disabled,
  reducedMotion,
  motionActive,
  idle,
  tide,
  onSelect,
}: ShellProps) {
  const t = usePearlT();
  const reveal = useRef(new Animated.Value(opened ? 1 : 0)).current;
  const shake = useRef(new Animated.Value(0)).current;
  const touch = useRef(new Animated.Value(1)).current;
  const charge = useRef(new Animated.Value(0)).current;
  const launch = useRef(new Animated.Value(opened ? 1 : 0)).current;
  const flourish = useRef(new Animated.Value(opened ? 1 : 0)).current;
  const motion = CLAM_MOTION[index % CLAM_MOTION.length];
  const breath = useRef(new Animated.Value(0)).current; // 慢呼吸：每只蚌自己的周期与幅度
  const gape = useRef(new Animated.Value(0)).current; // 微张合：壳体轻轻张开一条缝
  const openedOnce = useRef(opened);
  const [focused, setFocused] = useState(false);
  const motionEnabled = motionActive && !reducedMotion;

  useEffect(() => {
    // 只响应本局“未开到已开”的转换，selected → all 不会重播选中的蚌。
    if (!opened) {
      openedOnce.current = false;
      reveal.setValue(0);
      launch.setValue(0);
      flourish.setValue(0);
      return;
    }
    if (!motionEnabled || openedOnce.current) {
      reveal.setValue(1);
      launch.setValue(1);
      flourish.setValue(1);
      openedOnce.current = true;
      return;
    }
    openedOnce.current = true;
    // 其他蚌只错开表现时间，开奖结果始终完整来自父级服务器响应。
    const animation = Animated.sequence([
      Animated.delay(selected ? 0 : index * 90),
      Animated.parallel([
        animateTo(reveal, 1, selected ? 680 : 470, Easing.bezier(0.3, 0.72, 0.25, 1)),
        Animated.sequence([
          Animated.delay(selected ? 170 : 110),
          animateTo(launch, 1, selected ? 1000 : 530),
        ]),
        Animated.sequence([
          Animated.delay(selected ? 260 : 100),
          animateTo(flourish, 1, selected ? 1320 : 550, Easing.linear),
        ]),
      ]),
    ]);
    animation.start();
    return () => animation.stop();
  }, [opened, motionEnabled, selected, index, reveal, launch, flourish]);

  useEffect(() => {
    if (!motionEnabled || !idle || opened || submitting) {
      breath.setValue(0);
      gape.setValue(0);
      return;
    }
    const [inhale, hold] = motion.breath;
    const [gapeUp] = motion.gape;
    // 被选中的蚌呼吸更急：不用光圈也能看出"就等这一下"。
    const pace = selected ? 0.6 : 1;
    const slow = Animated.loop(Animated.sequence([
      animateTo(breath, 1, Math.round(inhale * pace), Easing.inOut(Easing.sin)),
      animateTo(breath, 0, Math.round(inhale * 1.34 * pace), Easing.inOut(Easing.sin)),
      Animated.delay(Math.round(hold * pace)),
    ]));
    const micro = Animated.loop(Animated.sequence([
      animateTo(gape, 1, Math.round(gapeUp * pace), Easing.inOut(Easing.quad)),
      animateTo(gape, 0, Math.round(gapeUp * 1.25 * pace), Easing.inOut(Easing.quad)),
    ]));
    const animation = Animated.parallel([
      Animated.sequence([Animated.delay(Math.round(motion.sway[2] * 2600)), slow]),
      Animated.sequence([Animated.delay(Math.round(motion.sway[2] * 1700)), micro]),
    ]);
    animation.start();
    return () => animation.stop();
  }, [breath, gape, motion, motionEnabled, idle, opened, submitting, selected]);

  useEffect(() => {
    if (!submitting || !motionEnabled) {
      shake.setValue(0);
      charge.setValue(0);
      return;
    }
    const step = (value: number, duration: number) => animateTo(shake, value, duration, Easing.inOut(Easing.quad));
    const animation = Animated.parallel([
      animateTo(charge, 1, 750),
      Animated.sequence([
        step(-0.45, 120), step(0.6, 100), step(-0.85, 85), step(1, 75),
        Animated.loop(Animated.sequence([step(-1, 68), step(1, 68), step(-0.55, 68), step(0.55, 68)])),
      ]),
    ]);
    animation.start();
    return () => animation.stop();
  }, [submitting, motionEnabled, shake, charge]);

  useEffect(() => {
    if (!motionEnabled) {
      touch.stopAnimation();
      touch.setValue(1);
    }
    return () => touch.stopAnimation();
  }, [touch, motionEnabled]);

  const pressDepth = (pressed: boolean) => {
    if (!motionEnabled) return;
    animateTo(touch, pressed ? 0.88 : 1, pressed ? 90 : 240).start();
  };

  // 纯展示：揭晓时在没被点开的蚌里挑一只，把两颗珍珠叠在一起给用户看（不参与结算）。
  const showTwin = Boolean(twin);
  const canSelect = !disabled && !opened;
  const status = submitting
    ? t("Opening shell")
    : opened
      ? pearlKey ? t((PEARLS[pearlKey] ?? PEARLS.white).label) : t("Empty shell")
      : t("Closed shell");
  const pearlSize = selected ? Math.round(size * 0.37) : Math.round(size * 0.26);
  const closedOpacity = reveal.interpolate({ inputRange: [0, 0.18, 0.54, 1], outputRange: [1, 1, 0, 0] });
  const openOpacity = reveal.interpolate({ inputRange: [0, 0.12, 0.36, 1], outputRange: [0, 0, 1, 1] });
  const pearlOpacity = launch.interpolate({ inputRange: [0, 0.13, 0.32, 1], outputRange: [0, 0.45, 1, 1] });
  const openWidth = size * 1.19;
  const openHeight = size * 1.055;
  const tidePoints = Array.from({ length: 9 }, (_, point) => point / 8);
  const [swayX, swayDeg, swayPhase] = motion.sway;
  const wave = (point: number, offset: number) => Math.sin((point + swayPhase + offset) * Math.PI * 2);
  // 水流轻摆：横漂 + 浮沉 + 微转共用一条潮汐驱动，各蚌相位不同。
  const floatY = idle && motionEnabled ? tide.interpolate({ inputRange: tidePoints, outputRange: tidePoints.map((point) => wave(point, 0) * swayX * 0.9) }) : 0;
  const driftX = idle && motionEnabled ? tide.interpolate({ inputRange: tidePoints, outputRange: tidePoints.map((point) => wave(point, 0.27) * swayX) }) : 0;
  const waterRoll = idle && motionEnabled ? tide.interpolate({ inputRange: tidePoints, outputRange: tidePoints.map((point) => wave(point, 0.55) * swayDeg + "deg") }) : "0deg";
  const breathScale = breath.interpolate({ inputRange: [0, 1], outputRange: [1, 1 + motion.breath[2] * (selected ? 1.45 : 1)] });
  const gapeLift = gape.interpolate({ inputRange: [0, 1], outputRange: [0, -size * 0.012] });
  // 按下时收拢张合：像真蚌被碰到会夹紧。
  const gapeFactor = touch.interpolate({ inputRange: [0.88, 1], outputRange: [0, 1] });
  const gapeOpacity = Animated.multiply(gape.interpolate({ inputRange: [0, 1], outputRange: [0, motion.gape[1]] }), gapeFactor);

  return (
    <View style={[styles.shellInner, { zIndex: selected ? 2 : 1 }]}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`${t("Shell")} ${index + 1}, ${status}`}
        accessibilityHint={canSelect ? t("Tap to open this shell") : undefined}
        accessibilityState={{ disabled: !canSelect, selected, busy: submitting, expanded: opened }}
        disabled={!canSelect}
        onPress={() => { if (canSelect) onSelect(index); }}
        onPressIn={() => pressDepth(true)}
        onPressOut={() => pressDepth(false)}
        onFocus={(event) => setFocused(Platform.OS !== "web" || Boolean((event.currentTarget as unknown as HTMLElement).matches?.(":focus-visible")))}
        onBlur={() => setFocused(false)}
        style={[styles.shellPressable, focused && canSelect && styles.focusRing]}
      >
        <View style={[styles.shellArt, { width: size, height: size * 1.05 }]}>
          <View pointerEvents="none" style={[styles.sandShadow, { width: size * 0.77, height: size * 0.15 }]} />
          <View pointerEvents="none" style={[styles.sandShadowCore, { width: size * 0.56, height: size * 0.075 }]} />

          <Animated.View
            pointerEvents="none"
            style={[
              styles.shellLayers,
              {
                transform: [
                  { scale: touch },
                  { scale: breathScale },
                  { translateX: driftX },
                  { translateY: floatY },
                  { rotate: waterRoll },
                  { translateY: touch.interpolate({ inputRange: [0.88, 1], outputRange: [6, 0] }) },
                  { translateX: shake.interpolate({ inputRange: [-1, 1], outputRange: [-4, 4] }) },
                  { scaleX: charge.interpolate({ inputRange: [0, 1], outputRange: [1, 1.055] }) },
                  { scaleY: charge.interpolate({ inputRange: [0, 1], outputRange: [1, 0.93] }) },
                ],
              },
            ]}
          >
            <Animated.View
              style={[
                styles.shellImageLayer,
                {
                  opacity: closedOpacity,
                  transform: [
                    { translateY: gapeLift },
                    { translateY: reveal.interpolate({ inputRange: [0, 0.25, 1], outputRange: [0, reducedMotion ? 0 : size * 0.1, reducedMotion ? 0 : -size * 0.07] }) },
                    { scaleY: reveal.interpolate({ inputRange: [0, 0.25, 1], outputRange: [1, reducedMotion ? 1 : 0.78, reducedMotion ? 1 : 0.5] }) },
                  ],
                },
              ]}
            >
              <Image
                source={CLOSED_SHELL}
                defaultSource={CLOSED_SHELL}
                accessible={false}
                resizeMode="contain"
                fadeDuration={0}
                style={{ width: size, height: size, position: "absolute", bottom: -size * 0.13 }}
              />
              {!opened ? <TellMarks tells={tells} size={size} motionEnabled={motionEnabled} /> : null}
            </Animated.View>
            {/* 同一张开壳素材分成下碗和上盖，上盖绕底部近似铰链展开。 */}
            <Animated.View
              style={[
                styles.openBowl,
                {
                  width: openWidth,
                  height: openHeight * 0.47,
                  opacity: Animated.add(openOpacity, gapeOpacity),
                  transform: [
                    { scale: reveal.interpolate({ inputRange: [0, 1], outputRange: [reducedMotion ? 1 : 0.88, 1] }) },
                  ],
                },
              ]}
            >
              <Image
                source={OPEN_SHELL}
                defaultSource={OPEN_SHELL}
                accessible={false}
                resizeMode="contain"
                fadeDuration={0}
                style={{ width: openWidth, height: openHeight, position: "absolute", bottom: 0 }}
              />
            </Animated.View>
            <Animated.View style={[styles.openLid, {
              width: openWidth,
              height: openHeight * 0.58,
              bottom: openHeight * 0.42,
              opacity: openOpacity,
              transform: [
                { perspective: 420 },
                { translateY: reveal.interpolate({ inputRange: [0, 1], outputRange: [reducedMotion ? 0 : size * 0.23, 0] }) },
                { rotateX: reveal.interpolate({ inputRange: [0, 1], outputRange: [reducedMotion ? "0deg" : "64deg", "0deg"] }) },
                { scaleY: reveal.interpolate({ inputRange: [0, 1], outputRange: [reducedMotion ? 1 : 0.26, 1] }) },
              ],
            }]}>
              <Image source={OPEN_SHELL} defaultSource={OPEN_SHELL} accessible={false} resizeMode="contain" fadeDuration={0}
                style={{ width: openWidth, height: openHeight, position: "absolute", top: 0 }} />
            </Animated.View>

            {opened && pearlKey && showTwin ? (
          <View pointerEvents="none" style={[styles.twinGem, { width: pearlSize, height: pearlSize, transform: [{ translateX: -pearlSize * 0.5 }, { translateY: -pearlSize * 0.55 }] }]}>
            <PearlGem pearlKey={pearlKey} size={pearlSize * 0.86} />
          </View>
        ) : null}
        {opened && pearlKey ? (
              <Animated.View
                style={[
                  styles.pearlReveal,
                  {
                    bottom: size * 0.3,
                    opacity: pearlOpacity,
                    transform: [
                      { translateY: launch.interpolate({ inputRange: [0, 0.73, 1], outputRange: [reducedMotion ? -size * (selected ? 0.55 : 0.1) : size * 0.13, -size * (selected ? (reducedMotion ? 0.55 : 0.63) : (reducedMotion ? 0.1 : 0.13)), -size * (selected ? 0.55 : 0.1)] }) },
                      { scale: launch.interpolate({ inputRange: [0, 0.72, 1], outputRange: [reducedMotion ? 1 : 0.2, selected && !reducedMotion ? 1.08 : 1, 1] }) },
                      { rotate: launch.interpolate({ inputRange: [0, 1], outputRange: [reducedMotion ? "0deg" : "-28deg", "0deg"] }) },
                    ],
                  },
                ]}
              >
                <View
                  style={[
                    styles.pearlHalo,
                    { width: pearlSize * 1.7, height: pearlSize * 1.7, borderRadius: pearlSize, backgroundColor: PEARLS[pearlKey].glow },
                  ]}
                />
                {selected && !reducedMotion ? (
                  <Animated.View pointerEvents="none" style={[styles.prismaticBloom, {
                    width: pearlSize * 3,
                    height: pearlSize * 3,
                    opacity: flourish.interpolate({ inputRange: [0, 0.12, 0.55, 1], outputRange: [0, 1, 0.7, 0] }),
                    transform: [{ scale: flourish.interpolate({ inputRange: [0, 1], outputRange: [0.45, 1.3] }) }],
                  }]}>
                    <View style={[styles.bloomCircle, { width: "100%", height: "100%", backgroundColor: "rgba(229, 247, 203, 0.17)" }]} />
                    <View style={[styles.bloomCircle, { width: "75%", height: "75%", backgroundColor: "rgba(237, 189, 219, 0.18)" }]} />
                    <View style={[styles.bloomCircle, { width: "49%", height: "49%", backgroundColor: "rgba(187, 249, 232, 0.24)" }]} />
                  </Animated.View>
                ) : null}
                <PearlGem pearlKey={pearlKey} size={pearlSize} />
                {selected && !reducedMotion ? (
                  <>
                    <View pointerEvents="none" style={[styles.gemSweepClip, { width: pearlSize, height: pearlSize, borderRadius: pearlSize / 2 }]}>
                      <Animated.View style={[styles.gemSweep, {
                        height: pearlSize * 1.5,
                        opacity: flourish.interpolate({ inputRange: [0, 0.12, 0.5, 1], outputRange: [0, 0.85, 0.6, 0] }),
                        transform: [{ translateX: flourish.interpolate({ inputRange: [0, 1], outputRange: [-pearlSize, pearlSize * 2] }) }, { rotate: "24deg" }],
                      }]} />
                    </View>
                    <Animated.View pointerEvents="none" style={[styles.orbitPlane, {
                      width: pearlSize * 2.4,
                      height: pearlSize * 2.4,
                      opacity: flourish.interpolate({ inputRange: [0, 0.15, 0.67, 1], outputRange: [0, 0.95, 0.7, 0] }),
                      transform: [{ rotate: "-24deg" }, { scaleY: 0.55 }],
                    }]}>
                      <Animated.View style={[styles.orbitRing, {
                        transform: [{ rotate: flourish.interpolate({ inputRange: [0, 1], outputRange: ["-80deg", "350deg"] }) }],
                      }]}>
                        <View style={[styles.orbitLight, { top: -3, left: "46%" }]} />
                        <View style={[styles.orbitLight, { bottom: -2, left: "42%", width: 4, height: 4, backgroundColor: "#DAFCEA" }]} />
                      </Animated.View>
                    </Animated.View>
                    {BURST_DIRECTIONS.map((direction, particleIndex) => (
                      <Animated.View key={particleIndex} pointerEvents="none" style={[styles.burstParticle, {
                        opacity: flourish.interpolate({ inputRange: [0, 0.1, 0.5, 0.88, 1], outputRange: [0, 1, 0.9, 0, 0] }),
                        transform: [
                          { translateX: flourish.interpolate({ inputRange: [0, 1], outputRange: [direction.x * pearlSize * 0.25, direction.x * pearlSize * (particleIndex % 2 ? 1.95 : 1.55)] }) },
                          { translateY: flourish.interpolate({ inputRange: [0, 1], outputRange: [direction.y * pearlSize * 0.25, direction.y * pearlSize * (particleIndex % 2 ? 1.65 : 1.45)] }) },
                          { scale: flourish.interpolate({ inputRange: [0, 0.12, 1], outputRange: [0.1, particleIndex % 2 ? 0.72 : 1, 0.2] }) },
                          { rotate: `${particleIndex * 19}deg` },
                        ],
                      }]}>
                        <View style={[styles.burstVertical, { backgroundColor: direction.color }]} />
                        <View style={[styles.burstHorizontal, { backgroundColor: direction.color }]} />
                      </Animated.View>
                    ))}
                  </>
                ) : null}
                {selected ? (
                  <View style={styles.sparkle}>
                    <View style={styles.sparkleVertical} />
                    <View style={styles.sparkleHorizontal} />
                  </View>
                ) : null}
              </Animated.View>
            ) : null}
          </Animated.View>
        </View>

        <View style={styles.shellCaption} pointerEvents="none" accessible={false}>
          <Text style={[styles.shellNumber, selected && styles.selectedNumber, opened && styles.revealedNumber]}>{String(index + 1).padStart(2, "0")}</Text>
          {opened ? <Animated.Text style={[styles.resultLabel, {
            opacity: reveal.interpolate({ inputRange: [0, 0.55, 1], outputRange: [0, 0, 1] }),
          }]} numberOfLines={2}>{status}</Animated.Text> : null}
        </View>
      </Pressable>
    </View>
  );
});

/** 六蚌舞台使用透明底，方便页面复用已批准的完整海底场景。 */
export function PearlStage({ selectedShell, selectedShells = [], shells, phase, disabled, reducedMotion, curtain = false, lifeIds, onSelect, onCurtain, onDragging }: PearlStageProps) {
  const [width, setWidth] = useState(360);
  const [dragging, setDragging] = useState(false);
  const swipe = useRef<{ x: number; y: number; armed: boolean } | null>(null);
  const motionActive = useMotionActive();
  const tide = useRef(new Animated.Value(0)).current;
  const cover = useRef(new Animated.Value(curtain ? 1 : 0)).current;
  useEffect(() => {
    if (!motionActive || reducedMotion) {
      tide.setValue(0);
      return;
    }
    const animation = Animated.loop(animateTo(tide, 1, 6200, Easing.linear));
    animation.start();
    return () => animation.stop();
  }, [motionActive, reducedMotion, tide]);
  useEffect(() => {
    if (reducedMotion || !motionActive) {
      cover.setValue(curtain ? 1 : 0);
      return;
    }
    const animation = animateTo(cover, curtain ? 1 : 0, 560, Easing.bezier(0.22, 1, 0.36, 1));
    animation.start();
    return () => animation.stop();
  }, [curtain, reducedMotion, motionActive, cover]);
  // 纯展示：揭晓时在没被点开的蚌里挑珠档最高的一只，显示「两颗珍珠叠在一起」。
  const twinIndex = (() => {
    if (!shells) return -1;
    const order = ["sand", "white", "pink", "gold", "black", "aurora", "living"];
    const rest = shells.filter((shell) => shell.pearlKey && !selectedShells.includes(shell.index));
    if (!rest.length) return -1;
    return rest.reduce((best, shell) => (order.indexOf(String(shell.pearlKey)) > order.indexOf(String(best.pearlKey)) ? shell : best)).index;
  })();
  const shellSize = Math.min(118, Math.max(64, width / 3 - 13));
  const onLayout = ({ nativeEvent }: LayoutChangeEvent) => {
    const nextWidth = Math.round(nativeEvent.layout.width);
    if (nextWidth > 0 && nextWidth !== width) setWidth(nextWidth);
  };
  const hunting = phase === "idle" || phase === "submitting";
  const markDrag = (value: boolean) => {
    setDragging(value);
    onDragging?.(value);
  };
  const onSwipeGrant = (x: number, y: number) => {
    if (phase === "selected" || phase === "submitting") return;
    swipe.current = { x, y, armed: false };
  };
  const onSwipeMove = (x: number, y: number) => {
    const start = swipe.current;
    if (!start) return;
    const dx = x - start.x;
    const dy = y - start.y;
    if (!start.armed && Math.abs(dx) > 24 && Math.abs(dx) > Math.abs(dy) * 1.2) {
      start.armed = true;
    }
  };
  const onSwipeRelease = (x: number) => {
    const start = swipe.current;
    swipe.current = null;
    if (!start?.armed || Math.abs(x - start.x) < 56) return;
    onCurtain?.();
  };

  return (
    <View
      collapsable={false}
      style={styles.stage}
      onLayout={onLayout}
      onStartShouldSetResponderCapture={(event) => {
        onSwipeGrant(event.nativeEvent.pageX, event.nativeEvent.pageY);
        return false;
      }}
      onStartShouldSetResponder={() => !dragging || curtain}
      onMoveShouldSetResponder={() => !dragging || curtain}
      onResponderGrant={(event) => onSwipeGrant(event.nativeEvent.pageX, event.nativeEvent.pageY)}
      onResponderMove={(event) => onSwipeMove(event.nativeEvent.pageX, event.nativeEvent.pageY)}
      onResponderRelease={(event) => onSwipeRelease(event.nativeEvent.pageX)}
      onResponderTerminate={() => { swipe.current = null; }}
    >
      <View
        collapsable={false}
        pointerEvents="auto"
        style={styles.swipeCatch}
        onStartShouldSetResponder={() => curtain || !dragging}
        onMoveShouldSetResponder={() => curtain || !dragging}
        onResponderGrant={(event) => onSwipeGrant(event.nativeEvent.pageX, event.nativeEvent.pageY)}
        onResponderMove={(event) => onSwipeMove(event.nativeEvent.pageX, event.nativeEvent.pageY)}
        onResponderRelease={(event) => onSwipeRelease(event.nativeEvent.pageX)}
        onResponderTerminate={() => { swipe.current = null; }}
      />
      <SwimmingCompanions reducedMotion={reducedMotion} visibleIds={lifeIds} interactive={curtain} onDragging={markDrag} />
      {[SHELL_INDICES.slice(0, 3), SHELL_INDICES.slice(3, 6)].map((row, rowIndex) => (
        <View key={rowIndex} pointerEvents={curtain ? "none" : "box-none"} style={[
          styles.shellRow,
          { zIndex: selectedShell !== null && Math.floor(selectedShell / 3) === rowIndex ? 2 : 1 },
        ]}>
          {row.map((index) => {
            const selected = selectedShells.includes(index) || selectedShell === index;
            const result = shells?.find((shell) => shell.index === index);
            const opened = Boolean(result) && (phase === "all" || selectedShells.includes(index));
            const span = Math.max(width, 280);
            return (
              <Animated.View
                key={index}
                pointerEvents={curtain ? "none" : "auto"}
                style={[
                  styles.shellSlot,
                  {
                    transform: [
                      { translateX: cover.interpolate({ inputRange: [0, 1], outputRange: [0, curtainShift(index, span)] }) },
                      { translateY: cover.interpolate({ inputRange: [0, 1], outputRange: [0, index < 3 ? -28 : 36] }) },
                    ],
                    opacity: cover.interpolate({ inputRange: [0, 0.62, 1], outputRange: [1, 0.45, 0] }),
                  },
                ]}
              >
              <Shell
                index={index}
                size={shellSize}
                selected={selected}
                opened={opened}
                submitting={phase === "submitting" && selectedShell === index && !opened}
                pearlKey={result?.pearlKey ?? null}
                twin={index === twinIndex}
                tells={opened ? [] : result?.tells ?? []}
                disabled={disabled || curtain || phase === "all" || opened}
                reducedMotion={reducedMotion}
                motionActive={motionActive}
                idle={hunting && !opened}
                tide={tide}
                onSelect={onSelect}
              />
              </Animated.View>
            );
          })}
        </View>
      ))}
    </View>
  );
}

// 原生端不支持 OKLCH 字面量，使用与已批准素材匹配的 sRGB 色值。
const styles = StyleSheet.create({
  stage: { width: "100%", maxWidth: 468, height: 312, alignSelf: "center", paddingTop: 4, overflow: "visible" },
  swipeCatch: { ...StyleSheet.absoluteFillObject, zIndex: 0, backgroundColor: "rgba(0,0,0,0.01)" },
  shellRow: { width: "100%", height: 148, flexDirection: "row", alignItems: "flex-end", zIndex: 1 },
  shellSlot: { width: "33.333333%", height: "100%", alignItems: "center" },
  shellInner: { width: "100%", height: "100%", alignItems: "center" },
  shellPressable: { width: "100%", height: "100%", alignItems: "center", justifyContent: "flex-end" },
  shellArt: { alignItems: "center", justifyContent: "flex-end" },
  shellLayers: { ...StyleSheet.absoluteFillObject, alignItems: "center" },
  shellImageLayer: { ...StyleSheet.absoluteFillObject, alignItems: "center" },
  openBowl: { position: "absolute", bottom: 0, alignItems: "center", overflow: "hidden" },
  openLid: { position: "absolute", alignItems: "center", overflow: "hidden" },
  sandShadow: { position: "absolute", bottom: -2, borderRadius: 999, backgroundColor: "rgba(24, 94, 82, 0.1)", transform: [{ rotate: "-5deg" }] },
  sandShadowCore: { position: "absolute", bottom: 0, borderRadius: 999, backgroundColor: "rgba(24, 79, 66, 0.11)" },
  focusRing: { borderColor: "#1D5D55", borderWidth: 1, borderStyle: "dotted", borderRadius: 12 },
  shellCaption: { width: "100%", minHeight: 32, alignItems: "center", marginTop: 4, paddingHorizontal: 2 },
  shellNumber: { color: "#315F55", fontSize: 10, lineHeight: 19, fontWeight: "600", letterSpacing: 2 },
  selectedNumber: { color: "#62492D", fontWeight: "800", textDecorationLine: "underline" },
  revealedNumber: { opacity: 0.65, fontSize: 10, lineHeight: 16 },
  resultLabel: { color: "#234F46", fontSize: 10, lineHeight: 14, fontWeight: "700", textAlign: "center", marginTop: 2 },
  pearlReveal: { position: "absolute", alignItems: "center", justifyContent: "center" },
  pearlHalo: { position: "absolute" },
  prismaticBloom: { position: "absolute", alignItems: "center", justifyContent: "center" },
  bloomCircle: { position: "absolute", borderRadius: 999 },
  twinGem: { position: "absolute", alignItems: "center", justifyContent: "center", opacity: 0.9 },
  gemSweepClip: { position: "absolute", overflow: "hidden" },
  gemSweep: { position: "absolute", top: -5, left: 0, width: 8, backgroundColor: "rgba(255, 249, 222, 0.7)" },
  orbitPlane: { position: "absolute" },
  orbitRing: { width: "100%", height: "100%", borderRadius: 999, borderWidth: 1.5, borderTopColor: "rgba(255, 240, 180, 0.88)", borderRightColor: "rgba(250, 198, 217, 0.72)", borderBottomColor: "rgba(188, 248, 228, 0.82)", borderLeftColor: "rgba(209, 235, 249, 0.42)" },
  orbitLight: { position: "absolute", width: 7, height: 7, borderRadius: 7, backgroundColor: "#FFF6D0" },
  burstParticle: { position: "absolute", width: 14, height: 14, alignItems: "center", justifyContent: "center" },
  burstVertical: { position: "absolute", width: 2, height: 14, borderRadius: 2 },
  burstHorizontal: { position: "absolute", width: 10, height: 2, borderRadius: 2 },
  pearlSphere: { overflow: "hidden", shadowColor: "#214F54", shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.23, shadowRadius: 4 },
  pearlLayer: { position: "absolute", borderRadius: 999 },
  pearlHighlight: { left: "22%", top: "14%", width: "26%", height: "16%", backgroundColor: "#FFFBEF", opacity: 0.86, transform: [{ rotate: "-34deg" }] },
  pearlGlint: { right: "17%", bottom: "21%", width: "8%", height: "8%", backgroundColor: "#FFF5E3", opacity: 0.65 },
  sparkle: { position: "absolute", right: -11, top: -8, width: 14, height: 14, alignItems: "center", justifyContent: "center", transform: [{ rotate: "14deg" }] },
  sparkleVertical: { position: "absolute", width: 2, height: 14, borderRadius: 2, backgroundColor: "#FFF6CD" },
  sparkleHorizontal: { position: "absolute", width: 10, height: 2, borderRadius: 2, backgroundColor: "#FFF6CD" },
  tellLayer: { position: "absolute", bottom: 0, alignItems: "center" },
  tellBubble: { position: "absolute", borderRadius: 99, backgroundColor: "rgba(214, 255, 246, 0.82)", borderWidth: 1, borderColor: "rgba(255,255,255,0.7)" },
  tellShimmer: { position: "absolute", borderRadius: 99, backgroundColor: "rgba(255, 248, 210, 0.55)" },
  tellAjar: { position: "absolute", borderRadius: 99, backgroundColor: "rgba(255, 236, 176, 0.85)" },
  tellVisitor: { position: "absolute", width: 10, height: 6, borderRadius: 8, backgroundColor: "#F4B267" },
  tellHeart: { position: "absolute", top: 18, width: 10, height: 10, borderRadius: 10, backgroundColor: "rgba(255, 170, 196, 0.8)" },
  tellHeartPulse: { transform: [{ scale: 1.15 }] },
});
