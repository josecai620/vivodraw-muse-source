import { OreVFX } from '../OreVFX';
import type { LightStyleId } from '../LightStyleSystem';
import { oreVFXPresets } from '../presets';
import { EnergyRing } from './EnergyRing';
import { FireSystem } from './FireSystem';
import { GlowSystem } from './GlowSystem';
import { ParticleSystem } from './ParticleSystem';
import {
  mergeVFXConfig,
  toRuntimeVFXConfig,
  type VFXPresetConfig,
  type VFXPresetPatch,
  type VFXRarity,
  type VFXState,
} from './VFXConfig';

export interface VFXManagerOptions {
  mount: HTMLElement; // mount：画布挂载节点
  assetUrl: string; // assetUrl：主体贴图路径
  width?: number; // width：画布宽度
  height?: number; // height：画布高度
  assetSize?: number; // assetSize：主体显示尺寸
  assetOffsetY?: number; // assetOffsetY：主体垂直偏移
  rarity?: VFXRarity; // rarity：初始稀有度
}

export class VFXManager { // VFXManager：可复用特效管理器
  private readonly oreVFX: OreVFX; // oreVFX：当前 Pixi 主体特效实例
  private preset: VFXPresetConfig; // preset：当前预设配置
  private state: VFXState = 'idle'; // state：当前状态
  private glowSystem: GlowSystem; // glowSystem：发光系统
  private particleSystem: ParticleSystem; // particleSystem：粒子系统
  private energyRing: EnergyRing; // energyRing：能量波系统
  private fireSystem: FireSystem; // fireSystem：火焰系统

  constructor(options: VFXManagerOptions) {
    this.preset = oreVFXPresets[options.rarity ?? 'legendary'];
    this.glowSystem = new GlowSystem(this.preset.glow, this.preset.flow);
    this.particleSystem = new ParticleSystem(this.preset.spark);
    this.energyRing = new EnergyRing(this.preset.energy, this.preset.explosion);
    this.fireSystem = new FireSystem(this.preset.fire);
    this.oreVFX = new OreVFX({
      mount: options.mount,
      oreUrl: options.assetUrl,
      width: options.width,
      height: options.height,
      assetSize: options.assetSize,
      assetOffsetY: options.assetOffsetY,
      config: toRuntimeVFXConfig(this.preset),
    });
  }

  async init() {
    await this.oreVFX.init();
    this.applyPreset(this.preset);
  }

  play() {
    this.state = 'idle';
    this.oreVFX.play();
    this.oreVFX.setState('idle');
  }

  stop() {
    this.state = 'idle';
    this.oreVFX.stop();
  }

  destroy() {
    this.oreVFX.destroy();
  }

  pause() {
    this.oreVFX.pause();
  }

  trigger() {
    this.state = 'trigger';
    this.oreVFX.setState('trigger');
  }

  explode() {
    this.state = 'explode';
    this.oreVFX.burst();
  }

  cooldown() {
    this.state = 'cooldown';
    this.oreVFX.setState('cooldown');
  }

  setRarity(rarity: VFXRarity) {
    this.preset = oreVFXPresets[rarity];
    this.applyPreset(this.preset);
    this.trigger();
  }

  setLightStyle(style: LightStyleId) {
    this.oreVFX.setLightStyle(style); // oreVFX：切换具体光效形态
  }

  setConfig(config: VFXPresetPatch) {
    this.preset = mergeVFXConfig(this.preset, config);
    this.applyPreset(this.preset);
  }

  getState() {
    return this.state;
  }

  getPreset() {
    return this.preset;
  }

  private applyPreset(preset: VFXPresetConfig) {
    this.glowSystem.glowEffect.setConfig(preset.glow);
    this.glowSystem.flowLightEffect.setConfig(preset.flow);
    this.particleSystem.sparkEffect.setConfig(preset.spark);
    this.energyRing.energyWaveEffect.setConfig(preset.energy);
    this.energyRing.explosionEffect.setConfig(preset.explosion);
    this.fireSystem.fireEffect.setConfig(preset.fire);
    this.oreVFX.setConfig(toRuntimeVFXConfig(preset));
  }
}
