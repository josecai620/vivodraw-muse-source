/**
 * 品牌列表 - Browse mystery box brands
 */
import React from "react";
import { useTranslation } from "react-i18next";
import { Pressable, ScrollView, Text, View, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { Layers, Flame, Tag } from "lucide-react-native";
import { BoxHeader, BoxEmptyState } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, bs,
} from "@/lib/boxTheme";
import { useBoxBrandList } from "@/hooks";

export default function BoxBrandsScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const { data: brandData, isLoading } = useBoxBrandList();

  const brands = Array.isArray(brandData?.data?.list)
    ? brandData.data.list
    : Array.isArray(brandData?.data)
      ? brandData.data
      : [];

  const cardWidth = (bs(390) - BoxSpacing.lg * 2 - BoxSpacing.md) / 2;

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("brands.title")} showThemeToggle={false} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(96) }}>
          {isLoading ? (
            <View style={{ alignItems: "center", justifyContent: "center", paddingVertical: bs(80) }}>
              <ActivityIndicator size="large" color={BoxAccent.gold} />
              <Text style={[BoxTypography.body, { color: BoxText.tertiary, marginTop: BoxSpacing.lg }]}>
                {t("common.loading")}
              </Text>
            </View>
          ) : brands.length === 0 ? (
            <BoxEmptyState
              icon={<Layers size={bs(48)} color={BoxText.tertiary} />}
              title={t("brands.empty")}
            />
          ) : (
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: BoxSpacing.md }}>
              {brands.map((brand: any) => {
                const imageUri = (brand.pic && /^https?:\/\//.test(brand.pic))
                  ? brand.pic
                  : (brand.image && /^https?:\/\//.test(brand.image))
                    ? brand.image
                    : null;

                return (
                  <Pressable
                    key={brand.id}
                    onPress={() => router.push(`/box/brand/${brand.id}`)}
                    style={({ pressed }) => ({
                      width: cardWidth,
                      borderRadius: BoxRadius.xl,
                      overflow: "hidden",
                      backgroundColor: BoxSurfaces.card,
                      borderWidth: 1,
                      borderColor: brand.is_hot === 1 ? BoxAccent.goldBorder : BoxBorders.default,
                      transform: [{ scale: pressed ? 0.97 : 1 }],
                      ...BoxShadows.card,
                    })}
                  >
                    <View style={{
                      height: bs(112),
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: BoxSurfaces.deep,
                    }}>
                      {imageUri ? (
                        <Image
                          source={{ uri: imageUri }}
                          style={{ width: "100%", height: "100%" }}
                          contentFit="cover"
                          transition={200}
                        />
                      ) : (
                        <Tag size={bs(36)} color={BoxAccent.gold} strokeWidth={1.5} />
                      )}
                      {brand.is_hot === 1 && (
                        <View style={{
                          position: "absolute",
                          top: BoxSpacing.sm,
                          right: BoxSpacing.sm,
                          flexDirection: "row",
                          alignItems: "center",
                          gap: 3,
                          backgroundColor: BoxAccent.goldMuted,
                          paddingHorizontal: BoxSpacing.sm,
                          paddingVertical: 3,
                          borderRadius: BoxRadius.sm,
                          borderWidth: 1,
                          borderColor: BoxAccent.goldBorder,
                        }}>
                          <Flame size={bs(10)} color={BoxAccent.gold} />
                          <Text style={[BoxTypography.micro, { color: BoxAccent.gold }]}>
                            {t("brands.hot")}
                          </Text>
                        </View>
                      )}
                    </View>
                    <View style={{ padding: BoxSpacing.md }}>
                      <Text
                        style={[BoxTypography.bodyBold, { color: BoxText.primary, marginBottom: BoxSpacing.xs }]}
                        numberOfLines={1}
                      >
                        {brand.brand_name || brand.name || t("brands.unknown")}
                      </Text>
                      <Text style={[BoxTypography.micro, { color: BoxText.tertiary }]}>
                        {t("brands.boxCount", { count: brand.count || brand.box_count || 0 })}
                      </Text>
                    </View>
                  </Pressable>
                );
              })}
            </View>
          )}
        </View>
      </ScrollView>
    </View>
  );
}
