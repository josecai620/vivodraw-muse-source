# mobile-app 接口对接盘点（API Connectivity Audit）

> 对照 `backend_src/route/api.php` 与 `mobile-app/lib/api/*`、`constants/api.ts`、`lib/http.ts` 核对
> 更新：2026-03-11（M-B1 批次）

---

## 一、已真实后端对接 ✅

| 模块 | 接口 | 前端调用 | 后端路由 | 状态 |
|------|------|----------|----------|------|
| 鉴权 | 登录 | POST /api/login | ✓ | lib/api/user.ts |
| 鉴权 | 用户信息 | GET /api/user | ✓ | |
| 鉴权 | 退出 | GET /api/logout | ✓ | |
| 鉴权 | 注册 | POST /api/register | ✓ | |
| 鉴权 | 验证码 | GET verify_code + POST register/verify | ✓ | 已补齐 key/type 参数 |
| 鉴权 | 找回密码 | POST /api/register/reset | ✓ | 后端有此路由，前端直接调用 |
| 首页 | 聚合/DIY/推荐 | GET /api/index, diy, groom | ✓ | lib/api/home.ts |
| 商品 | 列表/详情/分类 | GET /api/products, product/detail, category | ✓ | lib/api/product.ts |
| 购物车 | 增删改查 | POST/GET /api/cart/* | ✓ | lib/api/cart.ts |
| 订单 | 确认/计算/创建/列表/详情/取消 | POST/GET /api/order/* | ✓ | lib/api/order.ts |
| 地址 | 列表/编辑/删除/默认 | GET/POST /api/address/* | ✓ | lib/api/address.ts |
| 收藏 | 列表/添加/删除 | GET/POST /api/collect/* | ✓ | lib/api/collect.ts |
| 优惠券 | 可领/我的/订单可用/领取 | GET/POST /api/coupons, coupon/receive | ✓ | 已修复 |
| 积分 | 余额/记录/商城/兑换/签到/抽奖 | api/user, integral/*, store_integral/* | ✓ | lib/api/points.ts |
| 盲盒 | 大厅/橱窗/商城/开盒/订单/回收 | GET/POST /api/manghe/* | ✓ | lib/api/box.ts |
| 钱包 | 充值/提现 | /api/recharge/*, /api/extract/* | ✓ | lib/api/wallet.ts |
| 文章 | 分类/列表/详情 | /api/article/* | ✓ | lib/api/article.ts |
| 营销 | 秒杀/拼团/砍价/直播/预售/套餐 | seckill, combination, bargain, live... | ✓ | constants 已定义 |

---

## 二、API 优先 + 本地兜底（已实现）

以下页面对接真实 API，接口失败时使用 MOCK 避免白屏：

| 页面 | 真实 API | 兜底数据 | 说明 |
|------|----------|----------|------|
| 首页热门/新品 | groom/list | MOCK_HOT, MOCK_NEW | 推荐商品 |
| 购物车 | cart/list | MOCK_CART（仅游客） | 游客无真实购物车 |
| 订单列表 | order/list | MOCK_ORDERS | 空时展示占位 |
| 积分订单/分类/心愿单/兑换/通知/评价 | points API | MOCK_* | 各页独立兜底 |
| 积分订单详情/物流追踪 | integral/order/* | MOCK_ORDER, MOCK_TRACKING | 详情页 |
| 盲盒图鉴 | - | MOCK_SERIES | TODO: 等待后端图鉴接口 |

---

## 三、疑似未对接 / 返回契约不明

| 接口 | 前端使用 | 说明 |
|------|----------|------|
| POST /api/register/reset | ✅ 已入 API_ENDPOINTS.user.reset | - |
| GET /api/integral/jiexiao_* | lib/api/reveal.ts 使用 points.reveal | ✅ 已核对：integral/index、jiexiao_lists、jiexiao_detail、huande_lists、huande_info 与 backend_src/route/api.php 一致 |
| POST /api/integral/order/take | lib/api/points.ts takeIntegralOrder | ✅ 已入 api 层，body: order_id |
| POST /api/integral/order/cancel | lib/api/points.ts cancelIntegralOrder | ✅ 已入 api 层，body: order_id |
| box/collection 图鉴 | MOCK 固定数据 | 后端未提供图鉴接口 |

---

## 四、断联点清单

| 优先级 | 断联点 | 修复建议 |
|--------|--------|----------|
| P0 | 登录/鉴权/验证码 | ✅ 已完成 |
| P1 | 订单/支付/商品核心 | ✅ 已对接 |
| P2 | register/reset 未入 constants | ✅ 已完成 |
| P2 | 积分订单 take/cancel 入 api 层 | ✅ 已完成（lib/api/points.ts takeIntegralOrder/cancelIntegralOrder） |
| P2 | 积分/盲盒全流程 | 路径已对齐，建议实机联调验证 |
| P3 | 揭晓接口路径 | ✅ 已核对，与 backend_src/route/api.php 一致 |
| P3 | 图鉴接口 | 待后端提供，当前保留 MOCK |

---

## 五、修复优先级建议

1. **P0**：登录/鉴权/验证码（已完成）
2. **P1**：订单/支付/商品核心流程（已对接）
3. **P2**：低风险接线（register/reset 入常量、积分订单 take/cancel 入 api 层）
4. **P2**：积分/盲盒业务实机联调
5. **P3**：揭晓路径核对、图鉴待后端

---

## 六、lib/http.ts 与鉴权

- **baseURL**：来自 `constants/api.ts`，.env `EXPO_PUBLIC_API_BASE_URL` 可覆盖
- **Token 注入**：request 拦截器从 `useAuthStore.getState().token` 读取，写入 `Authori-zation: Bearer ${token}`
- **登录失效**：status 410000/410001/410002 或 HTTP 401 时调用 `logout()`
- **响应解包**：status=200 返回 data，否则 reject
