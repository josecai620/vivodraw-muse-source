export type ApiEnvelope<T> = {
  status?: number;
  msg?: string;
  data?: T;
};

export type ApiRecord = Record<string, unknown>;

export function isApiRecord(value: unknown): value is ApiRecord {
  return typeof value === "object" && value !== null;
}

export function unwrapApiData<T>(value: unknown, fallback: T): T {
  if (value == null) return fallback;

  if (isApiRecord(value) && "data" in value) {
    const data = value.data;
    return data == null ? fallback : (data as T);
  }

  return value as T;
}

export function unwrapApiList<T>(value: unknown): T[] {
  const data = unwrapApiData<unknown>(value, []);
  return Array.isArray(data) ? (data as T[]) : [];
}

export function unwrapApiRecord<T extends ApiRecord>(value: unknown, fallback: T): T {
  const data = unwrapApiData<unknown>(value, fallback);
  return isApiRecord(data) ? (data as T) : fallback;
}

export function unwrapApiListField<T>(value: unknown, fields = ["list", "lists"]): T[] {
  const data = unwrapApiData<unknown>(value, []);
  if (Array.isArray(data)) return data as T[];

  if (isApiRecord(data)) {
    for (const field of fields) {
      const list = data[field];
      if (Array.isArray(list)) return list as T[];
    }
  }

  return [];
}

export function unwrapApiPagedList<T>(value: unknown): T[] {
  return unwrapApiListField<T>(value, ["list", "lists"]);
}
