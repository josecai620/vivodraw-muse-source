import { useCallback, useEffect, useRef, useState } from "react";
import { useAuthStore } from "@/store/auth";
import { useFocusEffect } from "expo-router";
import { buyPlatformPoints, getPointPurchaseState, type PointPurchaseReceipt, type PointPurchaseState } from "@/lib/api/pointPurchase";
import type { GameWalletGame } from "@/lib/api/gameWallet";
import { withAccountRequestLock } from "@/lib/game/accountRequestLock";
import { clearPendingPointPurchase, isConfirmedPurchaseRejection, newPointPurchaseId, quotePointPurchase, readPendingPointPurchase, receiptConfirmsPointPurchase, savePendingPointPurchase, type PendingPointPurchase } from "@/lib/game/pointPurchaseRecovery";

function currentToken() {
  try {
    return useAuthStore.getState().token ?? "";
  } catch { return ""; }
}
const loginStatus = (status?: number) => [401, 410000, 410001, 410002].includes(status ?? 0);
type OwnedBalance = { token: string; game: GameWalletGame; state: PointPurchaseState };

export function usePointPurchase(game: GameWalletGame | null) {
  const gameRef = useRef(game); gameRef.current = game;
  const tokenRef = useRef<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [authRevision, setAuthRevision] = useState(0);
  const [balance, setBalance] = useState<OwnedBalance>();
  const balanceRef = useRef<OwnedBalance | undefined>(undefined);
  const [pointsText, setPointsText] = useState("1");
  const [review, setReview] = useState<PendingPointPurchase | null>(null);
  const [pending, setPending] = useState<PendingPointPurchase | null>(null);
  const [receipt, setReceipt] = useState<PointPurchaseReceipt | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [authExpired, setAuthExpired] = useState(false);
  const [storageBlocked, setStorageBlocked] = useState(false);
  const epoch = useRef(0), busy = useRef<symbol | null>(null), active = useRef(true);
  const refreshRef = useRef<() => void>(() => {});
  const syncRef = useRef<() => void>(() => {});
  const applyBalance = (value?: OwnedBalance) => { balanceRef.current = value; setBalance(value); };

  const refresh = useCallback(async () => {
    if (!game || !token || currentToken() !== token || busy.current || !active.current) return;
    const version = ++epoch.current;
    setLoading(true); setReview(null); setError("");
    const response = await getPointPurchaseState(game);
    if (version !== epoch.current || currentToken() !== token || gameRef.current !== game || !active.current) return;
    setLoading(false);
    if (!response.ok || !response.data) {
      applyBalance(undefined);
      if (loginStatus(response.status)) setAuthExpired(true);
      setError(loginStatus(response.status) ? "login" : "load_failed"); return;
    }
    applyBalance({ token, game, state: response.data }); setAuthExpired(false);
    try {
      const saved = readPendingPointPurchase(response.data.account_id, game);
      setPending(saved); setStorageBlocked(false);
      if (saved) { setPointsText(String(saved.points)); setError("pending"); }
    } catch { setPending(null); setStorageBlocked(true); setError("storage"); }
  }, [game, token]);
  refreshRef.current = () => { void refresh(); };

  useEffect(() => {
    const sync = () => {
      const next = currentToken();
      if (tokenRef.current === next) return;
      // 在事件内立即撤销旧账号回调，A→B→A 同一批渲染也不会接受旧响应。
      tokenRef.current = next; ++epoch.current; busy.current = null; balanceRef.current = undefined;
      setBalance(undefined); setReview(null); setPending(null); setReceipt(null);
      setToken(next); setAuthRevision((value) => value + 1);
    };
    syncRef.current = sync; sync();
    const focus = () => { sync(); refreshRef.current(); };
    if (typeof window === "undefined") return;
    window.addEventListener("storage", sync); const unsubAuth = useAuthStore.subscribe(sync); window.addEventListener("focus", focus);
    return () => { window.removeEventListener("storage", sync); unsubAuth(); window.removeEventListener("focus", focus); ++epoch.current; };
  }, []);

  useFocusEffect(useCallback(() => {
    active.current = true; syncRef.current(); refreshRef.current();
    return () => { active.current = false; ++epoch.current; busy.current = null; setSubmitting(false); };
  }, []));

  useEffect(() => {
    ++epoch.current; busy.current = null; applyBalance(undefined);
    setPending(null); setReview(null); setReceipt(null); setPointsText("1"); setError("");
    setLoading(false); setSubmitting(false); setAuthExpired(false); setStorageBlocked(false);
    if (token && game && active.current) void refresh();
    return () => { ++epoch.current; };
  }, [token, game, authRevision, refresh]);

  const liveBalance = () => {
    const value = balanceRef.current;
    return value && value.game === game && value.token === token && currentToken() === token && active.current ? value.state : undefined;
  };
  const prepare = () => {
    const state = liveBalance();
    if (!state || !token || authExpired || busy.current || loading || storageBlocked || pending) return;
    const quote = quotePointPurchase(state, pointsText);
    if (quote.error || !quote.points || !quote.money) { setError(quote.error ?? "invalid_points"); return; }
    try {
      setReview({ request_id: newPointPurchaseId(), account_id: state.account_id, game: state.game, points: quote.points, quote_version: state.quote_version,
        currency: "USD", price_per_point_minor: state.price_per_point_minor, expected_money_minor: quote.money });
      setReceipt(null); setError("");
    } catch { setStorageBlocked(true); setError("storage"); }
  };
  const submit = async () => {
    const candidate = pending ?? review, state = liveBalance();
    if (!candidate || !state || candidate.account_id !== state.account_id || candidate.game !== game || !token || authExpired
      || busy.current || loading || storageBlocked) return;
    if (!pending && (candidate.quote_version !== state.quote_version || candidate.price_per_point_minor !== state.price_per_point_minor)) {
      setReview(null); setError("quote_changed"); return;
    }
    const owner = Symbol("point-purchase"), version = ++epoch.current;
    busy.current = owner; setSubmitting(true); setError("");
    try {
      const started = await withAccountRequestLock(candidate.account_id, `point-purchase:${candidate.game}`, () => {
        if (version !== epoch.current || currentToken() !== token || gameRef.current !== candidate.game || !active.current) return null;
        const request = savePendingPointPurchase(candidate); setPending(request); setReview(null);
        // 同账号同游戏已经确认同一内容的两个标签共用原UUID；不同内容先显示原单供核对。
        if ((pending && request.request_id !== pending.request_id) || JSON.stringify({ ...request, request_id: candidate.request_id }) !== JSON.stringify(candidate)) {
          setPointsText(String(request.points)); setError("pending"); return null;
        }
        // 在锁内保存并开始原请求；响应在锁外等待，让同时确认的其他标签仍能发现原单。
        return { request, response: buyPlatformPoints(request) };
      });
      if (!started) return;
      const { request } = started, response = await started.response;
      if (version !== epoch.current || currentToken() !== token || gameRef.current !== request.game || !active.current) return;
      if (!response.ok || !response.data) {
        if (loginStatus(response.status)) { setAuthExpired(true); applyBalance(undefined); }
        setError(loginStatus(response.status) ? "login" : "pending"); return;
      }
      const result = response.data;
      if (result.state.account_id !== request.account_id || result.state.game !== request.game) {
        applyBalance(undefined); setError("account_changed"); return;
      }
      if (result.accepted && !receiptConfirmsPointPurchase(request, result.receipt)) { setError("receipt_mismatch"); return; }
      applyBalance({ token, game: request.game, state: result.state });
      const resolved = result.accepted || (!result.receipt && isConfirmedPurchaseRejection(result.reason_code));
      if (!resolved) { setError(result.reason_code === "request_conflict" ? "request_conflict" : "pending"); return; }
      const cleared = await withAccountRequestLock(request.account_id, `point-purchase:${request.game}`, () => {
        if (version !== epoch.current || currentToken() !== token || gameRef.current !== request.game || !active.current) return null;
        if (clearPendingPointPurchase(request)) return true;
        setPending(readPendingPointPurchase(request.account_id, request.game)); setError("pending"); return false;
      });
      if (!cleared || version !== epoch.current || currentToken() !== token || gameRef.current !== request.game || !active.current) return;
      setPending(null);
      if (result.accepted) { setReceipt(result.receipt); setError(""); }
      else setError(result.reason_code ?? "pending");
    } catch (error) { if (version === epoch.current && currentToken() === token && gameRef.current === candidate.game) { setStorageBlocked(true); setError(error instanceof Error && error.message === "request_lock_unavailable" ? "lock_unavailable" : "storage"); } }
    finally { if (busy.current === owner) { busy.current = null; setSubmitting(false); } }
  };

  const owned = balance?.token === token && balance?.game === game && currentToken() === token;
  return { ready: token !== null, signedIn: !!token && !authExpired, state: owned ? balance?.state : undefined,
    pointsText, review, pending, receipt, error, loading, submitting, storageBlocked, prepare, submit, refresh,
    changePoints: (value: string) => { if (!busy.current && !pending) { setPointsText(value); setReview(null); setReceipt(null); setError(""); } },
    cancelReview: () => { if (!busy.current) setReview(null); } };
}
