import { Container, Graphics, Sprite } from 'pixi.js';

export interface FlowFilterConfig {
  edgeSpeed: number; // edgeSpeed：边缘流光速度
  edgeCount: number; // edgeCount：边缘流光节点数量
  sweepSpeed: number; // sweepSpeed：扫光速度
  flowColor: number; // flowColor：流光颜色
}

interface FlowRhythm {
  charge: number; // charge：聚能强度
  burst: number; // burst：爆闪强度
  afterglow: number; // afterglow：余辉强度
  brightness: number; // brightness：整体亮度节奏
}

interface EdgeLight {
  node: Graphics; // node：流光图形节点
  offset: number; // offset：边缘相位偏移
  size: number; // size：基础尺寸
  color: number; // color：流光颜色
  speedJitter: number; // speedJitter：速度差异
}

export class FlowFilter { // FlowFilter：边缘流光与扫光滤镜
  private readonly layer: Container; // layer：流光所在层
  private readonly sweep: Graphics; // sweep：扫光图形
  private readonly edgeLights: EdgeLight[] = []; // edgeLights：边缘流光节点列表
  private readonly centerX: number; // centerX：矿石中心 X
  private readonly centerY: number; // centerY：矿石中心 Y
  private sweepX = -260; // sweepX：扫光当前位置

  constructor(layer: Container, oreSprite: Sprite, centerX: number, centerY: number, edgeCount: number) {
    this.layer = layer; // layer：保存图层引用
    this.centerX = centerX; // centerX：保存中心 X
    this.centerY = centerY; // centerY：保存中心 Y
    this.sweep = new Graphics(); // sweep：创建扫光图形
    this.sweep.blendMode = 'add';
    this.sweep.mask = oreSprite;

    for (let index = 0; index < edgeCount; index += 1) { // index：边缘流光序号
      const light = new Graphics(); // light：单个流光节点
      light.blendMode = 'add';
      this.edgeLights.push({
        node: light,
        offset: index / edgeCount,
        size: 4 + Math.random() * 5, // size：随机基础尺寸
        color: index % 3 === 0 ? 0xb2ecee : 0x7fd8dc, // color：随机流光颜色（teal 系）
        speedJitter: 0.86 + Math.random() * 0.32, // speedJitter：速度差异
      });
      this.layer.addChild(light);
    }

    this.layer.addChild(this.sweep);
  }

  update(time: number, delta: number, config: FlowFilterConfig, rhythm: FlowRhythm) {
    this.updateEdgeLights(time, config, rhythm);
    this.updateSweep(delta, config, rhythm);
  }

  private updateEdgeLights(time: number, config: FlowFilterConfig, rhythm: FlowRhythm) {
    const radiusX = 148; // radiusX：边缘椭圆半径 X
    const radiusY = 132; // radiusY：边缘椭圆半径 Y

    this.edgeLights.forEach((lightItem) => {
      const angle = (lightItem.offset + time * 0.18 * config.edgeSpeed * lightItem.speedJitter) * Math.PI * 2; // angle：流光角度
      const shimmer = 0.5 + Math.sin(angle * 4 + time * 8 * lightItem.speedJitter) * 0.5; // shimmer：亮度闪烁
      const tailAngle = angle - 0.11; // tailAngle：流光尾巴角度
      const x = this.centerX + Math.cos(angle) * radiusX; // x：节点 X 坐标
      const y = this.centerY + Math.sin(angle) * radiusY; // y：节点 Y 坐标
      const tailX = this.centerX + Math.cos(tailAngle) * radiusX; // tailX：尾巴 X 坐标
      const tailY = this.centerY + Math.sin(tailAngle) * radiusY; // tailY：尾巴 Y 坐标
      const size = lightItem.size + shimmer * 7; // size：节点尺寸
      lightItem.node.clear();
      lightItem.node.moveTo(tailX, tailY);
      lightItem.node.lineTo(x, y);
      const alphaBoost = rhythm.brightness * (0.62 + rhythm.charge * 0.22 + rhythm.afterglow * 0.14); // alphaBoost：边缘流光节奏亮度
      const color = lightItem.color === 0x7fd8dc ? config.flowColor : lightItem.color; // color：按预设替换流光主色
      lightItem.node.stroke({ width: Math.max(1, size * 0.42), color, alpha: (0.08 + shimmer * 0.28) * alphaBoost });
      this.drawEnergyWisp(lightItem.node, x, y, size, angle, color, (0.12 + shimmer * 0.4) * alphaBoost);
      this.drawEnergyWisp(lightItem.node, x, y, size * 0.52, angle + 0.4, 0xeafbfb, (0.14 + shimmer * 0.3) * alphaBoost);
    });
  }

  private updateSweep(delta: number, config: FlowFilterConfig, rhythm: FlowRhythm) {
    this.sweepX += delta * 180 * config.sweepSpeed; // sweepX：扫光横向推进
    if (this.sweepX > 310) this.sweepX = -310;
    const x = this.centerX + this.sweepX; // x：扫光中心 X
    const noise = Math.sin(this.sweepX * 0.021) * 13; // noise：扫光边缘扰动
    const sweepAlpha = 0.72 + rhythm.charge * 0.34 + rhythm.burst * 0.58; // sweepAlpha：扫光节奏透明度
    this.sweep.clear();
    this.drawSweepBand(x + noise, 68, 0xcff3f4, 0.2 * sweepAlpha);
    this.drawSweepBand(x + noise + 16, 26, 0xffffff, 0.28 * sweepAlpha);
    this.drawSweepBand(x + noise - 24, 36, config.flowColor, 0.14 * sweepAlpha);
  }

  private drawSweepBand(x: number, width: number, color: number, alpha: number) {
    this.sweep.moveTo(x - width, this.centerY - 178);
    this.sweep.bezierCurveTo(
      x - width * 0.36,
      this.centerY - 96,
      x + width * 0.18,
      this.centerY + 84,
      x + width,
      this.centerY + 178,
    );
    this.sweep.bezierCurveTo(
      x + width * 0.34,
      this.centerY + 122,
      x - width * 0.2,
      this.centerY - 76,
      x - width,
      this.centerY - 178,
    );
    this.sweep.closePath();
    this.sweep.fill({ color, alpha });
  }

  private drawEnergyWisp(node: Graphics, x: number, y: number, size: number, angle: number, color: number, alpha: number) {
    const length = size * 2.1; // length：柔性流光长度
    const tailX = x - Math.cos(angle) * length; // tailX：尾端 X
    const tailY = y - Math.sin(angle) * length; // tailY：尾端 Y
    const controlX = x - Math.cos(angle) * length * 0.36 + Math.cos(angle + Math.PI / 2) * size * 0.42; // controlX：贝塞尔控制点 X
    const controlY = y - Math.sin(angle) * length * 0.36 + Math.sin(angle + Math.PI / 2) * size * 0.42; // controlY：贝塞尔控制点 Y
    node.moveTo(tailX, tailY);
    node.bezierCurveTo(controlX, controlY, x - size * 0.3, y - size * 0.2, x, y);
    node.stroke({ width: Math.max(1, size * 0.44), color, alpha });
  }
}
