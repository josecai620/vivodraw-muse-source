import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

export function getVisitList() {
  return http.get(API_ENDPOINTS.user.visitList);
}

export function deleteVisit(ids: number[]) {
  return http.request({
    method: "DELETE",
    url: API_ENDPOINTS.user.visitDelete,
    data: { ids },
  });
}
