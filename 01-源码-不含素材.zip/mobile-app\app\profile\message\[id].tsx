import React from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { getMessageDetail } from "@/lib/api/message";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

function formatDate(str: string): string {
  if (!str) return "";
  const d = new Date(str);
  return isNaN(d.getTime()) ? str : d.toLocaleString();
}

export default function MessageDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const msgId = id ? parseInt(id, 10) : 0;

  const { data, isLoading } = useQuery({
    queryKey: ["messageDetail", msgId],
    queryFn: () => getMessageDetail(msgId),
    enabled: msgId > 0,
  });

  const raw = (data as any)?.data ?? data ?? {};
  const title = raw.title ?? raw.content?.slice(0, 50) ?? "Message";
  const content = raw.content ?? raw.detail ?? "";
  const time = formatDate(raw.create_time ?? raw.time ?? "");

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Message" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }} showsVerticalScrollIndicator={false}>
          <Text className="text-lg font-bold mb-2" style={{ color: Colors.neutral[900] }}>
            {title}
          </Text>
          {time ? (
            <Text className="text-xs mb-4" style={{ color: Colors.neutral[500] }}>
              {time}
            </Text>
          ) : null}
          <Text className="text-base leading-6" style={{ color: Colors.neutral[700] }}>
            {content || "No content"}
          </Text>
        </ScrollView>
      )}
    </View>
  );
}
