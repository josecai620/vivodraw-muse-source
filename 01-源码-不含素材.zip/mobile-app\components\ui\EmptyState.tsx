import React from "react";
import { View, Text } from "react-native";
import { PackageOpen } from "lucide-react-native";
import { Colors, s } from "@/constants/theme";
import LuxeIcon from "@/components/shared/LuxeIcon";
import Button from "./Button";

interface EmptyStateProps {
  title?: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
  icon?: React.ReactNode;
}

export default function EmptyState({
  title = "Nothing here yet",
  description,
  actionLabel,
  onAction,
  icon,
}: EmptyStateProps) {
  return (
    <View className="flex-1 items-center justify-center py-20 px-8">
      <LuxeIcon
        Icon={icon ? undefined : PackageOpen}
        tone="brand"
        size={78}
        iconSize={34}
        contentStyle={icon ? { width: s(42), height: s(42), alignItems: "center", justifyContent: "center" } : undefined}
      >
        {icon}
      </LuxeIcon>
      <Text className="text-lg font-semibold mt-6 text-center" style={{ color: Colors.luxe.ink }}>
        {title}
      </Text>
      {description && (
        <Text className="text-sm mt-2 text-center" style={{ color: Colors.luxe.inkMuted }}>
          {description}
        </Text>
      )}
      {actionLabel && onAction && (
        <View className="mt-6">
          <Button onPress={onAction}>{actionLabel}</Button>
        </View>
      )}
    </View>
  );
}
