import PearlClamIcon from "@/components/home-layout/珍珠蚌图标";
import { Colors, s } from "@/constants/theme";
import { Gamepad2, Pickaxe, Sparkles, Sprout } from "lucide-react-native";
import React from "react";
import { useTranslation } from "react-i18next";
import { Platform, Pressable, Text, View } from "react-native";

interface HlCategoryNavProps {
  props?: unknown;
  lang: string;
  onLink: (link: string) => void;
}

type IconType = React.ComponentType<{ size?: number; color?: string; strokeWidth?: number }>;

const HOME_GAME_ENTRIES: Array<{
  key: "pearl" | "mine" | "pet" | "farm" | "play";
  Icon: IconType;
  route?: string;
  external?: string;
}> = [
  { key: "pearl", Icon: PearlClamIcon, route: "/pearl" },
  { key: "mine", Icon: Pickaxe, external: "/mine/mobile" },
  { key: "pet", Icon: Sparkles, route: "/pet-deck" },
  { key: "farm", Icon: Sprout, external: "/farm" },
  { key: "play", Icon: Gamepad2, route: "/play" },
];

function openHomeGame(
  entry: (typeof HOME_GAME_ENTRIES)[number],
  onLink: (link: string) => void,
) {
  const href = entry.external || entry.route;
  if (!href) return;
  if (entry.external && Platform.OS === "web" && typeof window !== "undefined") {
    window.location.assign(entry.external);
    return;
  }
  onLink(href);
}

export default function HlCategoryNav({ lang, onLink }: HlCategoryNavProps) {
  const { t } = useTranslation();

  return (
    <View
      style={{
        marginTop: s(12),
        paddingHorizontal: s(12),
        flexDirection: "row",
        alignItems: "flex-start",
        justifyContent: "space-between",
      }}
    >
      {HOME_GAME_ENTRIES.map((entry) => {
        const Icon = entry.Icon;
        return (
          <Pressable
            key={entry.key}
            accessibilityRole="button"
            accessibilityLabel={t(`home.gameNav.${entry.key}`)}
            style={({ pressed }) => ({
              flex: 1,
              alignItems: "center",
              transform: [{ scale: pressed ? 0.95 : 1 }],
            })}
            onPress={() => openHomeGame(entry, onLink)}
          >
            <View
              style={{
                width: s(48),
                height: s(48),
                borderRadius: s(15),
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: Colors.primary.softer,
                marginBottom: s(6),
              }}
            >
              <Icon size={s(22)} color={Colors.primary.DEFAULT} strokeWidth={1.9} />
            </View>
            <Text
              numberOfLines={2}
              style={{
                color: "#171A1A",
                fontSize: s(11),
                lineHeight: s(14),
                fontWeight: "700",
                textAlign: "center",
                width: "100%",
                paddingHorizontal: 2,
              }}
            >
              {t(`home.gameNav.${entry.key}`)}
            </Text>
          </Pressable>
        );
      })}
    </View>
  );
}
