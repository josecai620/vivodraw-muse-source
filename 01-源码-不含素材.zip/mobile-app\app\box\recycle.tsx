/**
 * 回收页 - Multi-select items, recycle ratio, confirm button
 */
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Pressable,
  ScrollView,
  Text,
  View,
  ActivityIndicator,
} from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { Recycle, Check, Sparkles, Package } from "lucide-react-native";
import {
  BoxHeader,
  RarityBadge,
  BoxActionButton,
  BoxEmptyState,
  BoxProgressBar,
  BoxTabBar,
  CountdownTimer,
} from "@/components/box";
import {
  BoxSurfaces,
  BoxAccent,
  BoxText,
  BoxBorders,
  BoxGradients,
  BoxTypography,
  BoxSpacing,
  BoxRadius,
  BoxShadows,
  getRarityTier,
  bs,
} from "@/lib/boxTheme";
import { useBoxList, useDoRecovery } from "@/hooks";

interface RecycleItem {
  id: number;
  name: string;
  image: string;
  rarity: string;
  recycleValue: number;
}

const RECYCLE_RATIO = 0.8;

export default function RecycleScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [recycleSuccess, setRecycleSuccess] = useState(false);
  const [recycleError, setRecycleError] = useState<string | null>(null);

  const { data: backpackItems, isLoading, error } = useBoxList();
  const { mutate: doRecovery, isPending: isRecovering } = useDoRecovery();

  const recyclableItems: RecycleItem[] = (backpackItems || [])
    .filter((item: { status: number }) => item.status === 2)
    .map((item: Record<string, unknown>) => ({
      id: item.id as number,
      name: (item.name as string) || t("recycle.fallbackItem"),
      image: (item.image as string) || "",
      rarity: (item.rarity as string) || "common",
      recycleValue: (item.recycleValue as number) || 0,
    }));

  const toggleSelect = (id: number) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const selectedItems = recyclableItems.filter((i) =>
    selectedIds.includes(i.id)
  );
  const totalRecycleValue = selectedItems.reduce(
    (s, i) => s + i.recycleValue,
    0
  );
  const pointsToReceive = Math.floor(totalRecycleValue * RECYCLE_RATIO);

  const handleRecycle = () => {
    if (selectedIds.length === 0) return;

    doRecovery(
      { ids: selectedIds },
      {
        onSuccess: () => {
          setRecycleSuccess(true);
          setSelectedIds([]);
          setTimeout(() => {
            router.back();
          }, 1500);
        },
        onError: (error) => {
          setRecycleError(t("recycle.fail"));
          console.error("Recycle failed:", error);
        },
      }
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("recycle.title")} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View
          style={{
            paddingHorizontal: BoxSpacing.lg,
            paddingTop: BoxSpacing["2xl"],
            paddingBottom: bs(96),
          }}
        >
          {/* Recycle Ratio Info Card */}
          <LinearGradient
            colors={BoxGradients.cardSubtle}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{
              borderRadius: BoxRadius.xl,
              padding: BoxSpacing.xl,
              marginBottom: BoxSpacing["2xl"],
              borderWidth: 1,
              borderColor: BoxBorders.default,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: BoxSpacing.sm,
                marginBottom: BoxSpacing.md,
              }}
            >
              <View
                style={{
                  width: bs(36),
                  height: bs(36),
                  borderRadius: BoxRadius.md,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: BoxAccent.greenMuted,
                }}
              >
                <Recycle size={bs(18)} color={BoxAccent.green} />
              </View>
              <Text
                style={[BoxTypography.h3, { color: BoxText.primary }]}
              >
                {t("recycle.ratioTitle")}
              </Text>
            </View>
            <Text
              style={[
                BoxTypography.body,
                { color: BoxText.secondary, marginBottom: BoxSpacing.md },
              ]}
            >
              {t("recycle.ratioDesc", {
                ratio: Math.floor(RECYCLE_RATIO * 100),
              })}
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: BoxSpacing.sm,
              }}
            >
              <View style={{ flex: 1 }}>
                <BoxProgressBar
                  progress={RECYCLE_RATIO * 100}
                  color={BoxAccent.green}
                  size="compact"
                  glow
                />
              </View>
              <Text
                style={[BoxTypography.bodyBold, { color: BoxAccent.green }]}
              >
                {Math.floor(RECYCLE_RATIO * 100)}%
              </Text>
            </View>
          </LinearGradient>

          {/* Item List Header */}
          <Text
            style={[
              BoxTypography.h3,
              { color: BoxText.primary, marginBottom: BoxSpacing.md },
            ]}
          >
            {t("recycle.selectItems")}
          </Text>

          {isLoading ? (
            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: BoxSpacing["4xl"],
              }}
            >
              <ActivityIndicator size="large" color={BoxAccent.gold} />
              <Text
                style={[
                  BoxTypography.body,
                  { color: BoxText.secondary, marginTop: BoxSpacing.lg },
                ]}
              >
                {t("common.loading")}
              </Text>
            </View>
          ) : recyclableItems.length === 0 ? (
            <BoxEmptyState
              icon={<Recycle size={bs(48)} color={BoxText.tertiary} />}
              title={t("recycle.noItems")}
            />
          ) : (
            recyclableItems.map((item) => {
              const isSelected = selectedIds.includes(item.id);
              const rarityConfig = getRarityTier(item.rarity);
              return (
                <Pressable
                  key={item.id}
                  onPress={() => toggleSelect(item.id)}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    padding: BoxSpacing.lg,
                    borderRadius: BoxRadius.xl,
                    marginBottom: BoxSpacing.md,
                    backgroundColor: BoxSurfaces.card,
                    borderWidth: 2,
                    borderColor: isSelected
                      ? BoxAccent.gold
                      : BoxBorders.default,
                    ...(isSelected
                      ? BoxShadows.glow(BoxAccent.goldDark)
                      : {}),
                  }}
                >
                  <View
                    style={{
                      width: bs(48),
                      height: bs(48),
                      borderRadius: BoxRadius.lg,
                      overflow: "hidden",
                      alignItems: "center",
                      justifyContent: "center",
                      marginRight: BoxSpacing.lg,
                      backgroundColor: isSelected
                        ? BoxAccent.goldMuted
                        : BoxSurfaces.deep,
                    }}
                  >
                    {isSelected ? (
                      <Check size={bs(24)} color={BoxAccent.gold} />
                    ) : /^https?:\/\//i.test(item.image) ? (
                      <Image source={{ uri: item.image }} style={{ width: "100%", height: "100%" }} contentFit="cover" />
                    ) : (
                      <Package size={bs(22)} color={BoxAccent.gold} strokeWidth={1.6} />
                    )}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={[
                        BoxTypography.bodyBold,
                        { color: BoxText.primary },
                      ]}
                    >
                      {item.name}
                    </Text>
                    <RarityBadge
                      tier={item.rarity}
                      size="sm"
                      style={{ marginTop: BoxSpacing.xs }}
                    />
                  </View>
                  <Text
                    style={[BoxTypography.price, { color: BoxAccent.gold }]}
                  >
                    {t("recycle.value", { pts: item.recycleValue })}
                  </Text>
                </Pressable>
              );
            })
          )}

          {/* Summary & Confirm */}
          {selectedIds.length > 0 && (
            <LinearGradient
              colors={BoxGradients.purpleEvent}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                borderRadius: BoxRadius.xl,
                padding: BoxSpacing.xl,
                marginTop: BoxSpacing["2xl"],
                overflow: "hidden",
                ...BoxShadows.glow(BoxAccent.purple),
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginBottom: BoxSpacing.lg,
                }}
              >
                <Text
                  style={[
                    BoxTypography.body,
                    { color: "rgba(255,255,255,0.8)" },
                  ]}
                >
                  {t("recycle.selected", { count: selectedIds.length })}
                </Text>
                <Text
                  style={[
                    BoxTypography.body,
                    { color: "rgba(255,255,255,0.8)" },
                  ]}
                >
                  {t("recycle.value", { pts: totalRecycleValue })}
                </Text>
              </View>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginBottom: BoxSpacing.lg,
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    gap: BoxSpacing.xs,
                  }}
                >
                  <Sparkles size={bs(16)} color={BoxAccent.goldLight} />
                  <Text
                    style={[
                      BoxTypography.h3,
                      { color: BoxText.primary },
                    ]}
                  >
                    {t("recycle.willGet")}
                  </Text>
                </View>
                <Text
                  style={[BoxTypography.priceHero, { color: BoxText.primary }]}
                >
                  {pointsToReceive} pts
                </Text>
              </View>
              <Pressable
                onPress={handleRecycle}
                disabled={isRecovering}
                style={{
                  width: "100%",
                  height: bs(48),
                  borderRadius: BoxRadius.lg,
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: "rgba(255,255,255,0.15)",
                  borderWidth: 1,
                  borderColor: "rgba(255,255,255,0.25)",
                }}
              >
                {isRecovering ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <Text
                    style={[BoxTypography.button, { color: BoxText.primary }]}
                  >
                    {t("recycle.confirm")}
                  </Text>
                )}
              </Pressable>
            </LinearGradient>
          )}
        </View>
      </ScrollView>
    </View>
  );
}
