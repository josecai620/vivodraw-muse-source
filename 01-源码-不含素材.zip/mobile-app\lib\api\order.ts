import { API_ENDPOINTS } from "@/constants/api";
import { http } from "@/lib/http";

export interface OrderItem {
  order_id: string;
  total_num: number;
  total_price: string;
  pay_price: string;
  paid: number;
  status: number;
  refund_status: number;
  create_time: string;
  cartInfo: Array<{
    productInfo: {
      image: string;
      store_name: string;
      price: string;
    };
    cart_num: number;
  }>;
  _status: {
    _type: number;
    _title: string;
    _msg: string;
  };
}

/** 订单确认返回，含 orderKey，用于后续 computed 和 create */
export interface OrderConfirmData {
  orderKey: string;
  addressInfo: unknown;
  cartInfo: unknown[];
  priceGroup: { totalPrice?: string; payPrice?: string; [k: string]: unknown };
  [k: string]: unknown;
}

export function getOrderList(params: {
  type: number;
  page?: number;
  limit?: number;
}) {
  return http.get<OrderItem[]>(API_ENDPOINTS.order.list, { params });
}

export function getOrderDetail(id: string) {
  return http.get<OrderItem>(API_ENDPOINTS.order.detail(id));
}

export function getOrderExpress(id: string) {
  return http.get(API_ENDPOINTS.order.express(id));
}

/**
 * 1. 订单确认：获取 orderKey，必先调用
 */
export function confirmOrder(data: {
  cartId: string;
  new?: boolean;
  addressId?: number;
  shipping_type?: number;
  store_id?: number;
  couponId?: number;
}) {
  return http.post<OrderConfirmData>(API_ENDPOINTS.order.confirm, data);
}

/**
 * 2. 计算订单金额（需先 confirm 获取 key）
 */
export function computedOrder(
  key: string,
  data: {
    addressId?: number;
    couponId?: number;
    payType?: string;
    useIntegral?: boolean;
    mark?: string;
    shipping_type?: number;
  },
) {
  return http.post(API_ENDPOINTS.order.computed(key), data);
}

/**
 * 3. 创建订单（需先 confirm 获取 key，可先 computed 预览金额）
 */
export function createOrder(
  key: string,
  data: {
    addressId: number;
    couponId?: number;
    payType: string;
    useIntegral?: boolean;
    mark?: string;
    shipping_type?: number;
  },
) {
  return http.post(API_ENDPOINTS.order.create(key), data);
}

/** 取消订单：后端期望 POST body { id } */
export function cancelOrder(id: number) {
  return http.post(API_ENDPOINTS.order.cancel, { id });
}

/** 确认收货（uni 为 order_id） */
export function takeOrder(uni: string) {
  return http.post(API_ENDPOINTS.order.take, { uni });
}

/** 再次下单（uni 为 order_id） */
export function againOrder(uni: string) {
  return http.post(API_ENDPOINTS.order.again, { uni });
}

/** 获取退款理由列表 */
export function getRefundReasons() {
  return http.get<string[]>(API_ENDPOINTS.order.refund.reason);
}

/** 获取可退款商品列表 */
export function getRefundCartInfo(orderId: number) {
  return http.get(API_ENDPOINTS.order.refund.cartInfo(orderId));
}

/** 申请退款/退货 */
export function applyRefund(
  orderId: number,
  data: {
    text: string;
    refund_reason_wap_img?: string;
    refund_reason_wap_explain?: string;
    refund_type: 1 | 2;
    refund_price?: number;
    cart_ids?: Array<{ cart_id: number; cart_num: number }>;
  },
) {
  return http.post(API_ENDPOINTS.order.refund.apply(orderId), data);
}

/** 订单评价（按商品，每个 unique 提交一次） */
export function commentOrder(data: {
  unique: string;
  comment: string;
  pics?: string | string[];
  product_score: number;
  service_score: number;
}) {
  return http.post(API_ENDPOINTS.order.comment, data);
}
