import { StyleSheet, View } from "react-native";
import { useEffect, useMemo, useState } from "react";

import { FXLayer } from "@/components/pets/FXLayer";
import { PixelDeskPetSprite } from "@/components/pets/PixelDeskPetSprite";
import { theme } from "./petTheme";
import {
  getPetActionDefinition,
  getPetActionDurationMs,
  getPetBehaviorConfig,
  pickRandomPetAction,
  type PetActionName,
} from "@/lib/pet-animations";
import { type PixelDeskPetId } from "@/lib/pets";

type PixelDeskPetStageProps = {
  animation?: PetActionName;
  petId: PixelDeskPetId;
  resetKey?: number;
};

const STAGE_PET_SIZE = 192;

function randomBetween(min: number, max: number) {
  return min + Math.random() * (max - min);
}

function isLoopingAction(petId: PixelDeskPetId, action: PetActionName) {
  const definition = getPetActionDefinition(petId, action);
  return !!definition?.loop && (definition.frames || 0) > 1;
}

export function PixelDeskPetStage({ animation, petId, resetKey = 0 }: PixelDeskPetStageProps) {
  const behavior = useMemo(() => getPetBehaviorConfig(petId), [petId]);
  const [currentAction, setCurrentAction] = useState<PetActionName>(behavior.defaultAction);
  const sparkDots = useMemo(
    () => [
      { left: "16%", top: "18%", size: 6, color: theme.colors.violet },
      { left: "28%", top: "30%", size: 5, color: theme.colors.neon },
      { left: "78%", top: "20%", size: 6, color: theme.colors.amber },
      { left: "88%", top: "38%", size: 5, color: theme.colors.violet },
    ],
    [],
  );
  const idlePool = useMemo(() => {
    const actions = [...behavior.randomIdlePool, ...behavior.stagePreviewActions, behavior.defaultAction].filter(
      (action) => action !== behavior.inactiveAction && isLoopingAction(petId, action),
    );
    const unique = [...new Set(actions)];
    return unique.length ? unique : [behavior.defaultAction];
  }, [behavior.defaultAction, behavior.inactiveAction, behavior.randomIdlePool, behavior.stagePreviewActions, petId]);

  useEffect(() => {
    setCurrentAction(behavior.defaultAction);
  }, [petId, behavior.defaultAction]);

  useEffect(() => {
    if (!animation) return;
    setCurrentAction(animation);
  }, [animation, resetKey]);

  useEffect(() => {
    if (!isLoopingAction(petId, currentAction)) {
      const timer = setTimeout(() => {
        setCurrentAction(behavior.defaultAction);
      }, getPetActionDurationMs(petId, currentAction));
      return () => clearTimeout(timer);
    }
    if (currentAction !== behavior.defaultAction) {
      const holdMs = Math.max(getPetActionDurationMs(petId, currentAction) * 2, 1600);
      const timer = setTimeout(() => setCurrentAction(behavior.defaultAction), holdMs);
      return () => clearTimeout(timer);
    }
    const timer = setTimeout(() => {
      const others = idlePool.filter((action) => action !== currentAction);
      setCurrentAction(pickRandomPetAction(others.length ? others : idlePool, behavior.defaultAction));
    }, randomBetween(behavior.randomIdleAfterMs[0], behavior.randomIdleAfterMs[1]));
    return () => clearTimeout(timer);
  }, [behavior.defaultAction, behavior.randomIdleAfterMs, currentAction, idlePool, petId]);

  return (
    <View style={styles.stage}>
      {sparkDots.map((spark, index) => (
        <View
          key={`${spark.left}-${spark.top}-${index}`}
          style={[
            styles.spark,
            { left: spark.left as never, top: spark.top as never, width: spark.size, height: spark.size, backgroundColor: spark.color },
          ]}
        />
      ))}

      <View style={styles.backPlate} />
      <View style={styles.floorGlow} />
      <View style={styles.floorLine} />

      <View style={styles.petLayer}>
        <FXLayer action={currentAction} petId={petId} />
        <PixelDeskPetSprite key={`${petId}-${currentAction}-${resetKey}`} animation={currentAction} petId={petId} size={STAGE_PET_SIZE} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  stage: {
    position: "relative",
    width: "100%",
    minHeight: 292,
    alignItems: "center",
    justifyContent: "flex-end",
    overflow: "hidden",
    borderRadius: 28,
    backgroundColor: theme.colors.nightPanel,
  },
  spark: {
    position: "absolute",
    borderRadius: 2,
  },
  backPlate: {
    position: "absolute",
    right: 30,
    bottom: 70,
    width: 154,
    height: 134,
    borderRadius: 38,
    backgroundColor: "rgba(40, 55, 76, 0.52)",
    borderWidth: 1,
    borderColor: "rgba(139, 232, 94, 0.08)",
  },
  floorGlow: {
    position: "absolute",
    bottom: 36,
    width: 236,
    height: 46,
    borderRadius: theme.radius.pill,
    backgroundColor: "rgba(138, 114, 255, 0.22)",
  },
  floorLine: {
    position: "absolute",
    bottom: 50,
    width: 330,
    height: 12,
    borderRadius: theme.radius.pill,
    backgroundColor: "#1b2554",
  },
  petLayer: {
    position: "relative",
    marginBottom: 42,
    width: STAGE_PET_SIZE,
    height: STAGE_PET_SIZE,
    alignItems: "center",
    justifyContent: "center",
  },
});
