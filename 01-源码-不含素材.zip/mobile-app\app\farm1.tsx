import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import { FarmVisualChrome } from "@/components/farm-demo/农场视觉层";
import { IsoFarmStage } from "@/components/farm-demo/等轴舞台";
import { rollPracticeHarvest, type PracticeHarvestResult } from "@/lib/game/practiceHarvest";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Info, Sprout } from "lucide-react-native";
import React, { useCallback, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Animated,
  Easing,
  Platform,
  Pressable,
  Text,
  View,
} from "react-native";

/** 纯本地试玩沙盒：不扣次数、不要求登录、积分绝不写入真实账本。 */
const PRACTICE_MODE = true;
const nativeDriver = Platform.OS !== "web";
const easeOut = Easing.bezier(0.22, 1, 0.36, 1);

export default function Farm1Screen() {
  const router = useRouter();
  const { i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const { from } = useLocalSearchParams<{ from?: string }>();
  const [busy, setBusy] = useState(false);
  const [combo, setCombo] = useState(0);
  const [result, setResult] = useState<PracticeHarvestResult | null>(null);
  const [floatLabel, setFloatLabel] = useState<string>();
  const [notice, setNotice] = useState<string | undefined>(
    zh ? "試玩開放中：無需登入，積分僅本地演示。" : "Practice open: no login, points are local only.",
  );
  const [harvestTotal, setHarvestTotal] = useState(18);
  const [practiceCount, setPracticeCount] = useState(0);

  const shake = useRef(new Animated.Value(0)).current;
  const resultAnim = useRef(new Animated.Value(0)).current;
  const floatAnim = useRef(new Animated.Value(0)).current;

  const goBack = useCallback(() => {
    if (from === "home") return void router.replace("/");
    if (router.canGoBack()) router.back();
    else router.replace("/play");
  }, [from, router]);

  const impact = useCallback(() => {
    shake.setValue(0);
    Animated.sequence([
      Animated.timing(shake, { toValue: 1, duration: 35, useNativeDriver: nativeDriver }),
      Animated.timing(shake, { toValue: -1, duration: 45, useNativeDriver: nativeDriver }),
      Animated.timing(shake, { toValue: 0, duration: 40, useNativeDriver: nativeDriver }),
    ]).start();
  }, [shake]);

  const showFloat = useCallback(
    (label: string) => {
      setFloatLabel(label);
      floatAnim.setValue(0);
      Animated.timing(floatAnim, {
        toValue: 1,
        duration: 700,
        easing: easeOut,
        useNativeDriver: nativeDriver,
      }).start(({ finished }) => {
        if (finished) setFloatLabel(undefined);
      });
    },
    [floatAnim],
  );

  const onHarvest = useCallback(() => {
    if (busy) return;
    setBusy(true);
    impact();
    const rolled = rollPracticeHarvest(zh);
    const nextCombo = combo + 1;
    setCombo(nextCombo);
    const bonus = Math.min(2, nextCombo - 1);
    const points = rolled.points + bonus;
    showFloat(nextCombo > 1 ? `+${points}  x${nextCombo}` : `+${points}`);

    setTimeout(() => {
      setPracticeCount((n) => n + 1);
      setHarvestTotal((n) => n + 1);
      setResult({
        ...rolled,
        points,
        message:
          nextCombo > 1
            ? zh
              ? `${rolled.crop}連點 x${nextCombo}`
              : `Combo x${nextCombo} · ${rolled.crop}`
            : rolled.message,
      });
      resultAnim.setValue(0);
      Animated.spring(resultAnim, {
        toValue: 1,
        friction: 6,
        tension: 150,
        useNativeDriver: nativeDriver,
      }).start();
      setBusy(false);
      setNotice(
        PRACTICE_MODE
          ? zh
            ? "試玩中：不扣次數、不要求登入、積分不入帳。"
            : "Practice: no attempts spent, no login, no ledger write."
          : undefined,
      );
    }, 220);
  }, [busy, combo, impact, resultAnim, showFloat, zh]);

  const onChromeTap = useCallback(
    (id: string) => {
      if (id === "harvest") {
        onHarvest();
        return;
      }
      setNotice(
        zh
          ? "欄目先做視覺還原；當前只有「點熟作物/收成」可操作。"
          : "Visual mock only; only tapping ripe crops / Harvest works.",
      );
    },
    [onHarvest, zh],
  );

  const shakeX = shake.interpolate({ inputRange: [-1, 1], outputRange: [-5, 5] });

  return (
    <View className="flex-1 bg-neutral-50">
      <PageHeader
        title={zh ? "試玩農場" : "Farm demo"}
        onBackPress={goBack}
        rightElement={
          <View className="flex-row items-center rounded-full px-2.5 py-1" style={{ backgroundColor: "#ECFBFB" }}>
            <Sprout size={12} color={Colors.brand.redDark} />
            <Text className="text-[11px] font-bold ml-1" style={{ color: Colors.brand.redDark }}>
              {zh ? "試玩" : "DEMO"}
            </Text>
          </View>
        }
      />

      {/* 试玩说明条 */}
      <View
        className="mx-4 mt-1 rounded-xl p-3 flex-row items-start"
        style={{ backgroundColor: "#ECFBFB" }}
      >
        <Info size={15} color={Colors.brand.redDark} />
        <Text className="flex-1 ml-2 text-xs leading-4" style={{ color: Colors.brand.redDark }}>
          {zh
            ? "概念原型：收成積分只存在本機，不寫入真實帳本；正式版以 /farm 在線農場為準。"
            : "Concept prototype: harvest points stay local and never hit a real ledger. The live game is /farm."}
        </Text>
      </View>

      {/* 等轴舞台（绿色农场为游戏内容） */}
      <View className="flex-1 m-4 rounded-3xl overflow-hidden" style={{ backgroundColor: "#cfe8c4" }}>
        <View
          style={{
            position: "absolute",
            left: -40,
            right: -40,
            bottom: -80,
            height: "42%",
            borderRadius: 200,
            backgroundColor: "rgba(150,190,110,0.35)",
          }}
        />
        <Animated.View style={{ flex: 1, transform: [{ translateX: shakeX }] }}>
          <FarmVisualChrome
            remaining={999}
            harvestCount={harvestTotal}
            onHarvest={onHarvest}
            onChromeTap={onChromeTap}
            harvestDisabled={busy}
          />
          <IsoFarmStage busy={busy} disabled={false} onPlotPress={onHarvest} />
          {combo > 1 ? (
            <Text
              style={{
                position: "absolute",
                top: 118,
                alignSelf: "center",
                color: "#07858C",
                fontSize: 16,
                fontWeight: "900",
                zIndex: 30,
              }}
            >
              COMBO x{combo}
            </Text>
          ) : null}
          {floatLabel ? (
            <Animated.Text
              style={{
                position: "absolute",
                alignSelf: "center",
                top: "42%",
                color: "#07858C",
                fontSize: 36,
                fontWeight: "900",
                zIndex: 30,
                opacity: floatAnim.interpolate({ inputRange: [0, 0.12, 1], outputRange: [0, 1, 0] }),
                transform: [
                  { translateY: floatAnim.interpolate({ inputRange: [0, 1], outputRange: [8, -52] }) },
                ],
              }}
            >
              {floatLabel}
            </Animated.Text>
          ) : null}
        </Animated.View>
      </View>

      {/* 收成结果（白浮卡） */}
      {result ? (
        <Animated.View
          className="bg-white rounded-2xl mx-4 p-4 mb-2"
          style={{
            opacity: resultAnim,
            transform: [
              { translateY: resultAnim.interpolate({ inputRange: [0, 1], outputRange: [12, 0] }) },
            ],
          }}
        >
          <Text className="text-xs font-bold" style={{ color: Colors.brand.redDark }}>
            {result.crop}
          </Text>
          <Text className="text-2xl font-bold text-neutral-900">
            +{result.points} {zh ? "試玩積分" : "demo pts"}
          </Text>
          <Text className="text-xs text-neutral-500 mt-0.5">{result.message}</Text>
        </Animated.View>
      ) : null}

      <View className="px-4 pb-4 gap-2">
        {notice ? (
          <Text className="text-xs text-neutral-500 text-center">{notice}</Text>
        ) : null}
        <View className="flex-row items-center justify-between">
          <Text className="text-xs text-neutral-400">
            {zh ? `已試玩 ${practiceCount} 次 · 累計收成 ${harvestTotal}` : `Practice ${practiceCount} · harvests ${harvestTotal}`}
          </Text>
          <Pressable
            onPress={() => router.push("/play")}
            className="h-10 px-4 rounded-xl items-center justify-center"
            style={{ backgroundColor: "#fff", borderWidth: 1, borderColor: "rgba(12,31,31,0.08)" }}
          >
            <Text className="text-sm font-semibold text-neutral-700">
              {zh ? "返回互動樂園" : "Back to Play"}
            </Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}
