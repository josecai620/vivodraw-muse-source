import type { VFXPresetConfig } from '../core/VFXConfig';

export const oreRarePreset: VFXPresetConfig = { // oreRarePreset：稀有蓝色流光矿石
  id: 'rare',
  label: 'rare',
  glow: {
    enabled: true,
    glowColor: 0x4ec3c8,
    glowStrength: 0.82,
    glowSpeed: 1.05,
  },
  flow: {
    enabled: true,
    flowColor: 0x4ec3c8,
    flowSpeed: 0.9,
    sweepSpeed: 0.85,
  },
  energy: {
    enabled: true,
    energyColor: 0x4ec3c8,
    energyWaveSize: 0.75,
    energyWaveStrength: 0.65,
  },
  explosion: {
    enabled: true,
    explosionStrength: 0.45,
    explosionDuration: 0.68,
  },
  fire: {
    enabled: false,
    fireIntensity: 0,
    fireSpeed: 0.55,
  },
  spark: {
    enabled: true,
    particleColor: 0x9fe4e6,
    particleCount: 24,
    particleSize: 0.82,
  },
};
