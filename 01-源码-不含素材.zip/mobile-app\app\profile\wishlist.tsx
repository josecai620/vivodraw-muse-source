import React, { useState } from "react";
import { View, Text, ScrollView, Pressable, Image } from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import {
  Heart,
  HeartCrack,
  ShoppingCart,
  Trash2,
  TrendingUp,
} from "lucide-react-native";
import { useTranslation } from "react-i18next";
import { TealGradient, Colors, s, Shadows } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import TealSurface from "@/components/ui/TealSurface";
import { USE_DEV_MOCK_DATA } from "@/constants/env";
import { normalizeImageUrl } from "@/lib/utils";
import { useCollectList, useDelCollect } from "@/hooks";

interface WishlistItem {
  id: number;
  name: string;
  image: string;
  price: number;
  originalPrice: number;
  sales: number;
  rating: number;
}

const INITIAL_ITEMS: WishlistItem[] = [
  {
    id: 1,
    name: "Premium Wireless Headphones with Active Noise Cancellation",
    image:
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80",
    price: 299.99,
    originalPrice: 399.99,
    sales: 1234,
    rating: 4.8,
  },
  {
    id: 2,
    name: "Smart Watch Series 8 - GPS + Cellular",
    image:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&q=80",
    price: 449.99,
    originalPrice: 549.99,
    sales: 2567,
    rating: 4.9,
  },
  {
    id: 3,
    name: "Bluetooth Portable Speaker - Waterproof",
    image:
      "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&q=80",
    price: 129.99,
    originalPrice: 179.99,
    sales: 987,
    rating: 4.7,
  },
  {
    id: 4,
    name: "Fitness Tracker Band with Heart Rate Monitor",
    image:
      "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6?w=400&q=80",
    price: 199.99,
    originalPrice: 249.99,
    sales: 1876,
    rating: 4.6,
  },
  {
    id: 5,
    name: "USB-C Power Bank 20000mAh Fast Charging",
    image:
      "https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=400&q=80",
    price: 79.99,
    originalPrice: 99.99,
    sales: 3456,
    rating: 4.5,
  },
  {
    id: 6,
    name: "RGB Gaming Mouse with Programmable Buttons",
    image:
      "https://images.unsplash.com/photo-1527814050087-3793815479db?w=400&q=80",
    price: 89.99,
    originalPrice: 119.99,
    sales: 654,
    rating: 4.7,
  },
];

export default function WishlistScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const delCollect = useDelCollect();

  const { data: collectRaw } = useCollectList();
  const realItems: any[] = (collectRaw as any)?.data?.list ?? (collectRaw as any)?.data ?? (collectRaw as any)?.list ?? [];

  const apiItems: WishlistItem[] = realItems.map((c: any) => ({
    id: c.product_id ?? c.id,
    name: c.productInfo?.store_name ?? c.store_name ?? t("profileWishlist.productFallback"),
    image: c.productInfo?.image ?? c.image ?? "",
    price: Number(c.productInfo?.price ?? c.price ?? 0),
    originalPrice: Number(c.productInfo?.ot_price ?? c.ot_price ?? 0),
    sales: c.productInfo?.sales ?? c.sales ?? 0,
    rating: 4.5,
  }));

  const [localItems, setLocalItems] = useState<WishlistItem[]>(USE_DEV_MOCK_DATA ? INITIAL_ITEMS : []);
  const items = apiItems.length > 0 ? apiItems : USE_DEV_MOCK_DATA ? localItems : [];

  const removeItem = (id: number) => {
    if (apiItems.length > 0) {
      delCollect.mutate({ id });
    } else {
      setLocalItems((prev) => prev.filter((item) => item.id !== id));
    }
  };

  const addToCart = (id: number) => {
    router.push(`/product/${id}`);
  };

  const totalSavings = items.reduce(
    (sum, item) => sum + (item.originalPrice - item.price),
    0
  );

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("profileWishlist.title")} onBackPress={() => router.replace("/profile")} />

      {items.length === 0 ? (
        <View className="flex-1 items-center justify-center px-8">
          <View
            className="w-32 h-32 rounded-full items-center justify-center mb-6"
            style={{ backgroundColor: "#F7F8F8" }}
          >
            <Heart size={s(64)} color={Colors.neutral[300]} />
            <View
              className="absolute -top-2 -right-2 w-16 h-16 bg-white rounded-full items-center justify-center"
              style={Shadows.lg}
            >
              <HeartCrack size={s(28)} color={Colors.neutral[400]} strokeWidth={1.9} />
            </View>
          </View>
          <Text className="text-xl font-bold text-gray-900 mb-2">
            {t("profileWishlist.emptyTitle")}
          </Text>
          <Text
            className="text-gray-500 text-center text-sm mb-8 leading-relaxed"
            style={{ maxWidth: 280 }}
          >
            {t("profileWishlist.emptyHint")}
          </Text>
          <Pressable onPress={() => router.push("/")}>
            <LinearGradient
              colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={{
                height: s(48),
                paddingHorizontal: s(24),
                borderRadius: s(12),
                justifyContent: "center",
                alignItems: "center",
                shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6,
              }}
            >
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
              <Text className="text-white font-bold text-base">
                {t("profileWishlist.startBrowsing")}
              </Text>
            </LinearGradient>
          </Pressable>
        </View>
      ) : (
        <ScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: s(32) }}
        >
          {/* Stats Card */}
          <View className="px-4 pt-4">
            <TealSurface
              direction="lr"
              style={{ height: s(100), marginBottom: s(16) }}
              contentStyle={{ padding: s(20), justifyContent: "center" }}
            >
                <View className="flex-row items-center justify-between">
                  <View>
                    <Text
                      className="text-sm mb-1"
                      style={{ color: "rgba(255,255,255,0.9)" }}
                    >
                      {t("profileWishlist.totalSaved")}
                    </Text>
                    <Text className="text-3xl font-bold text-white">
                      {items.length}
                    </Text>
                  </View>
                  <View className="items-end">
                    <Text
                      className="text-sm mb-1"
                      style={{ color: "rgba(255,255,255,0.9)" }}
                    >
                      {t("profileWishlist.savings")}
                    </Text>
                    <Text className="text-2xl font-bold text-white">
                      ${totalSavings.toFixed(2)}
                    </Text>
                  </View>
                </View>
              </TealSurface>
          </View>

          {/* Product List */}
          <View className="px-4" style={{ gap: s(12) }}>
            {items.map((item) => (
              <View
                key={item.id}
                className="bg-white rounded-2xl overflow-hidden border border-gray-100"
                style={Shadows.sm}
              >
                <Pressable
                  className="p-4 flex-row gap-4"
                  onPress={() => router.push(`/product/${item.id}`)}
                >
                  <View className="w-28 h-28 rounded-xl overflow-hidden bg-gray-100">
                    <Image
                      source={{ uri: normalizeImageUrl(item.image) }}
                      className="w-full h-full"
                      resizeMode="cover"
                    />
                    {item.originalPrice > item.price && (
                      <View
                        className="absolute top-2 left-2 px-2 py-1 rounded-md"
                        style={{ backgroundColor: Colors.brand.red }}
                      >
                        <Text className="text-white text-xs font-bold">
                          -
                          {Math.round(
                            ((item.originalPrice - item.price) /
                              item.originalPrice) *
                              100
                          )}
                          %
                        </Text>
                      </View>
                    )}
                  </View>

                  <View className="flex-1 justify-between">
                    <View>
                      <Text
                        className="text-sm font-bold text-gray-900 mb-2"
                        numberOfLines={2}
                      >
                        {item.name}
                      </Text>
                      <View className="flex-row items-center gap-1.5 mb-2">
                        <TrendingUp
                          size={s(12)}
                          color={Colors.neutral[400]}
                        />
                        <Text
                          className="text-xs"
                          style={{ color: Colors.neutral[500] }}
                        >
                          {t("profileWishlist.sold", { count: item.sales.toLocaleString() })}
                        </Text>
                      </View>
                    </View>
                    <View className="flex-row items-baseline gap-2">
                      <Text
                        className="text-xl font-bold"
                        style={{ color: Colors.brand.red }}
                      >
                        ${item.price.toFixed(2)}
                      </Text>
                      <Text className="text-sm text-gray-400 line-through">
                        ${item.originalPrice.toFixed(2)}
                      </Text>
                    </View>
                  </View>
                </Pressable>

                {/* Action Buttons */}
                <View className="px-4 pb-4 flex-row gap-2">
                  <Pressable
                    onPress={() => removeItem(item.id)}
                    className="flex-1 h-10 border-2 border-gray-300 rounded-xl flex-row items-center justify-center gap-2"
                  >
                    <Trash2 size={s(16)} color={Colors.neutral[700]} />
                    <Text className="font-bold text-sm text-gray-700">
                      {t("profileWishlist.remove")}
                    </Text>
                  </Pressable>
                  <Pressable
                    onPress={() => addToCart(item.id)}
                    className="flex-1"
                    style={({ pressed }) => ({ transform: [{ scale: pressed ? 0.97 : 1 }] })}
                  >
                    <TealSurface
                      direction="lr"
                      radius={s(12)}
                      style={{ height: s(40) }}
                      contentStyle={{
                        flexDirection: "row",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: s(8),
                      }}
                    >
                      <ShoppingCart size={s(16)} color="#fff"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
                      <Text className="font-bold text-sm text-white">
                        {t("profileWishlist.addToCart")}
                      </Text>
                    </TealSurface>
                  </Pressable>
                </View>
              </View>
            ))}
          </View>

          {/* Recommended Section */}
          <View className="px-4 mt-6">
            <View
              className="rounded-2xl p-4 border"
              style={{ backgroundColor: "#F7F8F8", borderColor: "#E5E5E2" }}
            >
              <View className="flex-row items-center gap-2 mb-3">
                <View
                  className="w-8 h-8 rounded-lg items-center justify-center"
                  style={{ backgroundColor: Colors.ios.purple }}
                >
                  <Heart size={s(16)} color="#fff" fill="#fff"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
                </View>
                <Text className="text-sm font-bold text-gray-900">
                  {t("profileWishlist.alsoLike")}
                </Text>
              </View>
              <Text className="text-xs text-gray-600 mb-3">
                {t("profileWishlist.alsoLikeHint")}
              </Text>
              <Pressable
                className="w-full h-9 bg-white rounded-lg items-center justify-center"
                onPress={() => router.push("/")}
              >
                <Text className="text-sm font-medium text-gray-700">
                  {t("profileWishlist.browseSimilar")}
                </Text>
              </Pressable>
            </View>
          </View>
        </ScrollView>
      )}
    </View>
  );
}
