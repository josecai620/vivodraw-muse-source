const REFERRAL_SESSION_KEY = "vivodraw:acquisition:spread";

let memoryReferralUid = 0;

function normalizeReferralUid(value: unknown): number {
  const candidate = Array.isArray(value) ? value[0] : value;
  const text = typeof candidate === "number" ? String(candidate) : String(candidate ?? "").trim();
  if (!/^\d{1,12}$/.test(text)) return 0;

  const uid = Number(text);
  return Number.isSafeInteger(uid) && uid > 0 ? uid : 0;
}

function readReferralFromUrl(): number {
  if (typeof window === "undefined") return 0;
  try {
    return normalizeReferralUid(new URLSearchParams(window.location.search).get("spread"));
  } catch {
    return 0;
  }
}

export function captureReferralAttribution(value?: unknown): void {
  const uid = normalizeReferralUid(value) || readReferralFromUrl();
  if (!uid) return;

  memoryReferralUid = uid;
  if (typeof window !== "undefined") {
    try {
      window.sessionStorage.setItem(REFERRAL_SESSION_KEY, String(uid));
    } catch {
      // Private browsing may disable session storage; the in-memory value still covers this app session.
    }
  }
}

export function getReferralAttribution(): number {
  const urlUid = readReferralFromUrl();
  if (urlUid) {
    captureReferralAttribution(urlUid);
    return urlUid;
  }

  if (typeof window !== "undefined") {
    try {
      const storedUid = normalizeReferralUid(window.sessionStorage.getItem(REFERRAL_SESSION_KEY));
      if (storedUid) return storedUid;
    } catch {
      // Continue with the in-memory value when session storage is unavailable.
    }
  }

  return memoryReferralUid;
}

export function clearReferralAttribution(): void {
  memoryReferralUid = 0;
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.removeItem(REFERRAL_SESSION_KEY);
  } catch {
    // Clearing is best effort; the current tab may have storage disabled.
  }
}
