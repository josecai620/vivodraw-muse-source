import React from "react";
import { View, Text, Pressable, type ViewStyle } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Clock, Zap, ChevronRight } from "lucide-react-native";
import {
  BoxAccent, BoxText, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, BoxAnimation, bs,
} from "@/lib/boxTheme";

interface ActivityBannerProps {
  title: string;
  description?: string;
  boost?: string;
  onPress?: () => void;
  style?: ViewStyle;
}

export function ActivityBanner({ title, description, boost, onPress, style }: ActivityBannerProps) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        { borderRadius: BoxRadius.xl, overflow: "hidden", transform: [{ scale: pressed ? BoxAnimation.press.scale : 1 }] },
        BoxShadows.glow(BoxAccent.purple),
        style,
      ]}
    >
      <LinearGradient
        colors={BoxGradients.purpleEvent}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          flexDirection: "row",
          alignItems: "center",
          padding: BoxSpacing.lg,
          gap: BoxSpacing.md,
        }}
      >
        <View style={{
          width: bs(40), height: bs(40), borderRadius: bs(20),
          backgroundColor: "rgba(255,255,255,0.18)",
          alignItems: "center", justifyContent: "center",
        }}>
          <Clock size={bs(20)} color="#fff" />
        </View>

        <View style={{ flex: 1 }}>
          <Text style={[BoxTypography.bodyBold, { color: "#fff" }]}>{title}</Text>
          {description && (
            <Text style={[BoxTypography.caption, { color: "rgba(255,255,255,0.7)", marginTop: 2 }]}>
              {description}
            </Text>
          )}
          {boost && (
            <View style={{
              flexDirection: "row", alignItems: "center", gap: 4,
              marginTop: BoxSpacing.xs,
              backgroundColor: "rgba(255,255,255,0.18)",
              borderRadius: BoxRadius.sm,
              paddingHorizontal: BoxSpacing.sm,
              paddingVertical: 2,
              alignSelf: "flex-start",
            }}>
              <Zap size={bs(12)} color="#fff" />
              <Text style={[BoxTypography.micro, { color: "#fff" }]}>{boost}</Text>
            </View>
          )}
        </View>

        <View style={{
          paddingHorizontal: BoxSpacing.md,
          paddingVertical: BoxSpacing.xs,
          borderRadius: BoxRadius.full,
          backgroundColor: "rgba(255,255,255,0.22)",
        }}>
          <Text style={[BoxTypography.micro, { color: "#fff", fontWeight: "700" }]}>GO</Text>
        </View>
      </LinearGradient>
    </Pressable>
  );
}
