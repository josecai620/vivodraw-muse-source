import React, { useEffect, useRef } from "react";
import { Animated, Easing, Pressable, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { ChevronRight, Crown } from "lucide-react-native";

type 会员入口卡Props = {
  label: string;
  onPress: () => void;
};

/** 个人中心的会员入口：窄比例黑金卡，扫光只作为材质高光，不抢主内容。 */
export function 会员入口卡({ label, onPress }: 会员入口卡Props) {
  const shine = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.delay(1500),
        Animated.timing(shine, {
          toValue: 1,
          duration: 900,
          easing: Easing.inOut(Easing.quad),
          useNativeDriver: true,
        }),
        Animated.timing(shine, {
          toValue: 0,
          duration: 0,
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [shine]);

  const shineX = shine.interpolate({ inputRange: [0, 1], outputRange: [-170, 190] });

  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={({ pressed }) => ({
        flex: 1,
        minHeight: 54,
        borderRadius: 17,
        padding: 1,
        overflow: "hidden",
        borderWidth: 1,
        borderColor: "rgba(220, 182, 104, 0.62)",
        opacity: pressed ? 0.9 : 1,
        transform: [{ scale: pressed ? 0.985 : 1 }],
        shadowColor: "#9D742E",
        shadowOffset: { width: 0, height: 6 },
        shadowOpacity: 0.16,
        shadowRadius: 12,
        elevation: 4,
      })}
    >
      <LinearGradient
        colors={["#3A3428", "#211D17", "#0B0C0D"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={{ flex: 1, borderRadius: 15, overflow: "hidden", justifyContent: "center" }}
      >
        <Animated.View
          pointerEvents="none"
          style={{
            position: "absolute",
            top: -28,
            bottom: -28,
            left: 0,
            width: 28,
            backgroundColor: "rgba(255, 232, 168, 0.38)",
            transform: [{ translateX: shineX }, { rotate: "18deg" }],
          }}
        />

        <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 12, gap: 9 }}>
          <View
            style={{
              width: 28,
              height: 28,
              borderRadius: 10,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 1,
              borderColor: "rgba(233, 199, 125, 0.58)",
              backgroundColor: "rgba(227, 187, 99, 0.12)",
            }}
          >
            <Crown size={15} color="#F1D48F" strokeWidth={1.7} />
          </View>
          <View style={{ flex: 1, minWidth: 0 }}>
            <Text
              numberOfLines={1}
              style={{ color: "#D4B06A", fontSize: 8, fontWeight: "800", letterSpacing: 1.35 }}
            >
              PREMIUM
            </Text>
            <Text
              numberOfLines={1}
              adjustsFontSizeToFit
              style={{ color: "#FFF4D7", fontSize: 14, fontWeight: "800", marginTop: 2 }}
            >
              {label}
            </Text>
          </View>
          <ChevronRight size={17} color="#D9B86F" strokeWidth={1.8} />
        </View>
      </LinearGradient>
    </Pressable>
  );
}
