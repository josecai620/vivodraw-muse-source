import TealSurface from "@/components/ui/TealSurface";
import { HomeLayoutRenderer } from "@/components/home-layout";
import HomeClaimBar from "@/components/home-layout/HomeClaimBar";
import 首页品牌标 from "@/components/home-layout/首页品牌标";
import { Colors, Shadows, s } from "@/constants/theme";
import { useHomeIndex, useHomeLayout } from "@/hooks";
import type { BannerItem, HomeLayoutBlock, HomeLayoutData } from "@/lib/api/home";
import { unwrapApiData } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getMessageList } from "@/lib/api/message";
import { useAuthStore } from "@/store/auth";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import {
  Bell,
  Coins,
  Gift,
  Headset,
  Search,
  Users,
} from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  AccessibilityInfo,
  Animated,
  Easing,
  Image,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

// 原图 3552×1184；按字标完整轮廓（含圆点和 ®）外扩 30px，仅调整显示窗口，不改原图。
/** 顶栏：左侧品牌 Logo，右侧通知浮钮；可拖动语言钮由根布局承载 */
function HomeTopBar({
  top,
  onSearch,
  onService,
  onNotifications,
  unreadCount = 0,
  pageReady = false,
}: {
  top: number;
  onSearch: () => void;
  onService: () => void;
  onNotifications: () => void;
  unreadCount?: number;
  pageReady?: boolean;
}) {
  const { t } = useTranslation();

  return (
    <View style={[styles.topWrap, { paddingTop: top + s(10) }]}>
      <View style={styles.topBar}>
        <View style={styles.topLeft}>
          <View style={styles.logoFrame}>
            <首页品牌标 ready={pageReady} />
          </View>
        </View>
        <View style={styles.topActions}>
          <Pressable
            hitSlop={10}
            style={styles.iconButton}
            onPress={onService}
            accessibilityRole="button"
            accessibilityLabel="客服"
          >
            <Headset size={s(19)} color="#171A1A" strokeWidth={1.8} />
          </Pressable>
          <Pressable
            hitSlop={10}
            style={styles.iconButton}
            onPress={onNotifications}
            accessibilityRole="button"
            accessibilityLabel="消息"
          >
            <Bell size={s(19)} color="#171A1A" strokeWidth={1.8} />
            {unreadCount > 0 ? <View style={styles.notificationDot} /> : null}
          </Pressable>
        </View>
      </View>

      <Pressable style={styles.searchBox} onPress={onSearch}>
        <Search size={s(17)} color={Colors.home.muted} strokeWidth={2} />
        <Text style={styles.searchText}>{t("home.searchPlaceholder")}</Text>
      </Pressable>
    </View>
  );
}

function useReduceMotionPreference() {
  const [reduceMotion, setReduceMotion] = React.useState(false);

  React.useEffect(() => {
    let alive = true;
    AccessibilityInfo.isReduceMotionEnabled().then((value) => {
      if (alive) setReduceMotion(Boolean(value));
    });
    const sub = AccessibilityInfo.addEventListener("reduceMotionChanged", (value) => {
      setReduceMotion(Boolean(value));
    });
    return () => {
      alive = false;
      sub.remove();
    };
  }, []);

  return reduceMotion;
}

function useEntryBreath(
  delayMs: number,
  reduceMotion: boolean,
  strength = 1,
  tiltDirection: -1 | 1 = 1,
) {
  const phase = React.useRef(new Animated.Value(0)).current;
  const motionScale = reduceMotion ? 0.55 : 1;

  React.useEffect(() => {
    phase.stopAnimation();
    phase.setValue(0);
    let loop: Animated.CompositeAnimation | null = null;
    const timer = setTimeout(() => {
      loop = Animated.loop(
        Animated.timing(phase, {
          toValue: 1,
          duration: 4300,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
          isInteraction: false,
        }),
      );
      loop.start();
    }, delayMs);

    return () => {
      clearTimeout(timer);
      loop?.stop();
      phase.stopAnimation();
    };
  }, [delayMs, phase, reduceMotion]);

  return {
    card: {
      transform: [
        {
          translateX: phase.interpolate({
            inputRange: [0, 0.22, 0.48, 0.74, 1],
            outputRange: [
              0,
              -1.8 * strength * motionScale,
              1.5 * strength * motionScale,
              -0.7 * strength * motionScale,
              0,
            ],
          }),
        },
        {
          translateY: phase.interpolate({
            inputRange: [0, 0.22, 0.48, 0.74, 1],
            outputRange: [0, -1.6 * strength * motionScale, -0.5, -2.5 * strength * motionScale, 0],
          }),
        },
        {
          scale: phase.interpolate({
            inputRange: [0, 0.22, 0.48, 0.74, 1],
            outputRange: [
              1,
              1 + 0.014 * strength * motionScale,
              1 + 0.006 * strength * motionScale,
              1 + 0.02 * strength * motionScale,
              1,
            ],
          }),
        },
      ],
    },
    icon: {
      transform: [
        {
          translateX: phase.interpolate({
            inputRange: [0, 0.22, 0.48, 0.74, 1],
            outputRange: [0, 1.2 * tiltDirection * motionScale, -1.5 * tiltDirection * motionScale, 0.8 * tiltDirection * motionScale, 0],
          }),
        },
        {
          translateY: phase.interpolate({
            inputRange: [0, 0.22, 0.48, 0.74, 1],
            outputRange: [0, -2.2 * motionScale, -0.6, -2.9 * motionScale, 0],
          }),
        },
        {
          rotate: phase.interpolate({
            inputRange: [0, 0.22, 0.48, 0.74, 1],
            outputRange: [
              "0deg",
              `${-2.8 * tiltDirection * motionScale}deg`,
              `${2.2 * tiltDirection * motionScale}deg`,
              `${-1.2 * tiltDirection * motionScale}deg`,
              "0deg",
            ],
          }),
        },
        {
          scale: phase.interpolate({
            inputRange: [0, 0.22, 0.48, 0.74, 1],
            outputRange: [1, 1.07, 1.025, 1.085, 1],
          }),
        },
      ],
    },
  };
}

/** 错落三入口：两侧白色小卡，中间更大的 teal 突出块（云购入口） */
function HomeEntryTrio({
  onPoints,
  onBox,
  onGroup,
}: {
  onPoints: () => void;
  onBox: () => void;
  onGroup: () => void;
}) {
  const reduceMotion = useReduceMotionPreference();
  const boxMotion = useEntryBreath(0, reduceMotion, 0.95, -1);
  const pointsMotion = useEntryBreath(360, reduceMotion, 1.1, 1);
  const groupMotion = useEntryBreath(720, reduceMotion, 0.95, -1);

  return (
    <View>
      <View style={styles.entryRow}>
        <Animated.View style={[styles.entrySideSlot, boxMotion.card]}>
          <Pressable
            style={({ pressed }) => [styles.entrySide, { transform: [{ scale: pressed ? 0.96 : 1 }] }]}
            onPress={onBox}
          >
            <Animated.View style={boxMotion.icon}>
              <Coins size={s(25)} color="#5E5F5E" strokeWidth={1.8} />
            </Animated.View>
          </Pressable>
        </Animated.View>

        <Animated.View style={[styles.entryCenterSlot, pointsMotion.card]}>
          <Pressable
            style={({ pressed }) => [styles.entryCenter, { transform: [{ scale: pressed ? 0.96 : 1 }] }]}
            onPress={onPoints}
          >
            <TealSurface
              radius={s(22)}
              direction="tb"
              style={StyleSheet.absoluteFill}
              contentStyle={{ alignItems: "center", justifyContent: "center" }}
            >
              <Animated.View style={pointsMotion.icon}>
                <Gift size={s(28)} color="#FFFFFF" strokeWidth={2.1} />
              </Animated.View>
            </TealSurface>
          </Pressable>
        </Animated.View>

        <Animated.View style={[styles.entrySideSlot, groupMotion.card]}>
          <Pressable
            style={({ pressed }) => [styles.entrySide, { transform: [{ scale: pressed ? 0.96 : 1 }] }]}
            onPress={onGroup}
          >
            <Animated.View style={groupMotion.icon}>
              <Users size={s(25)} color="#5E5F5E" strokeWidth={1.8} />
            </Animated.View>
          </Pressable>
        </Animated.View>
      </View>
      <Text style={styles.entryCaption}>Blind Box · Points Mall · Group Buy</Text>
    </View>
  );
}

function withScrollCategories(layout: HomeLayoutData): HomeLayoutData {
  return {
    ...layout,
    blocks: layout.blocks.map((block: HomeLayoutBlock) =>
      block.type === "category_nav"
        ? { ...block, props: { ...block.props, layout: "scroll", limit: 12 } }
        : block,
    ),
  };
}

function FallbackBanner({ banners }: { banners: BannerItem[] }) {
  const { t } = useTranslation();
  const first = banners[0];
  const image = normalizeImageUrl(first?.pic ?? first?.img ?? first?.image ?? "");
  if (!image) return null;
  return (
    <View style={styles.fallbackBanner}>
      <Image source={{ uri: image }} resizeMode="cover" style={StyleSheet.absoluteFill} />
      <LinearGradient
        colors={["rgba(0,0,0,0.52)", "rgba(0,0,0,0.06)"]}
        start={{ x: 0, y: 0.5 }}
        end={{ x: 1, y: 0.5 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={styles.fallbackBannerCopy}>
        <Text style={styles.fallbackBannerTitle}>{t("home.fallbackBanner.title")}</Text>
        <Text style={styles.fallbackBannerSub}>{t("home.fallbackBanner.subtitle")}</Text>
      </View>
    </View>
  );
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const queryClient = useQueryClient();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const [refreshing, setRefreshing] = useState(false);
  const [deferredHomeExtrasVisible, setDeferredHomeExtrasVisible] = useState(false);
  const { data: messageData } = useQuery({
    queryKey: ["messageList"],
    queryFn: () => getMessageList({ page: 1, limit: 80 }),
    enabled: isLoggedIn,
  });
  const messagePayload = unwrapApiData<{ service_num?: number; list?: { is_read?: unknown; look?: unknown }[] }>(
    messageData,
    {},
  );
  const unreadCount = Number(messagePayload.service_num ?? 0);

  const { data: layoutResp, isFetched: layoutFetched } = useHomeLayout();
  const homeLayout = unwrapApiData<HomeLayoutData | null>(layoutResp, null);
  const hasLayout = Array.isArray(homeLayout?.blocks) && homeLayout.blocks.length > 0;
  const { data: homeData, isFetched: indexFetched } = useHomeIndex(layoutFetched && !hasLayout);
  const pageReady =
    layoutFetched && deferredHomeExtrasVisible && (hasLayout || indexFetched);
  const homeIndex = unwrapApiData<{ banner?: BannerItem[] }>(homeData, {});
  const banners = homeIndex.banner ?? [];

  const { bannerLayout, noticeLayout, categoryLayout, restLayout } = useMemo(() => {
    if (!homeLayout || !hasLayout) {
      return { bannerLayout: null, noticeLayout: null, categoryLayout: null, restLayout: null };
    }
    const contentBlocks = homeLayout.blocks.filter(
      (block) =>
        !["banner", "notice", "quick_grid", "group_lottery", "points_balance"].includes(
          block.type,
        ),
    );
    return {
      bannerLayout: {
        ...homeLayout,
        blocks: homeLayout.blocks.filter((block) => block.type === "banner"),
      },
      noticeLayout: {
        ...homeLayout,
        blocks: homeLayout.blocks.filter((block) => block.type === "notice"),
      },
      categoryLayout: withScrollCategories({
        ...homeLayout,
        blocks: contentBlocks.filter((block) => block.type === "category_nav"),
      }),
      restLayout: {
        ...homeLayout,
        blocks: contentBlocks.filter((block) => block.type !== "category_nav"),
      },
    };
  }, [hasLayout, homeLayout]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["homeLayout"] }),
      queryClient.invalidateQueries({ queryKey: ["homeIndex"] }),
      queryClient.invalidateQueries({ queryKey: ["groom"] }),
      queryClient.invalidateQueries({ queryKey: ["messageList"] }),
      queryClient.invalidateQueries({ queryKey: ["signConfig"] }),
      queryClient.invalidateQueries({ queryKey: ["signUser"] }),
    ]);
    setRefreshing(false);
  };

  React.useEffect(() => {
    const timer = setTimeout(() => setDeferredHomeExtrasVisible(true), 900);
    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={styles.outer}>
      <StatusBar style="dark" />
      <View style={styles.shell}>
        <ScrollView
          style={styles.scroll}
          showsVerticalScrollIndicator={false}
          bounces={false}
          overScrollMode="never"
          contentContainerStyle={{ paddingBottom: s(96) + insets.bottom }}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor={Colors.brand.red}
            />
          }
        >
          <HomeTopBar
            top={insets.top}
            unreadCount={unreadCount}
            pageReady={pageReady}
            onSearch={() => router.push("/search")}
            onService={() => router.push("/profile/service")}
            onNotifications={() => router.push("/profile/messages")}
          />

          {bannerLayout?.blocks.length ? (
            <HomeLayoutRenderer layout={bannerLayout} />
          ) : (
            <FallbackBanner banners={banners} />
          )}

          {noticeLayout?.blocks.length ? <HomeLayoutRenderer layout={noticeLayout} /> : null}

          <HomeEntryTrio
            onPoints={() => router.push("/(tabs)/points")}
            onBox={() => router.push("/box")}
            onGroup={() => router.push("/group-lottery")}
          />

          <HomeClaimBar />

          {categoryLayout?.blocks.length ? (
            <HomeLayoutRenderer layout={categoryLayout} />
          ) : layoutFetched ? (
            <HomeLayoutRenderer
              layout={{
                id: 0,
                name: "fallback-category",
                status: 1,
                theme: { bg_color: Colors.screen.bg },
                blocks: [
                  {
                    id: "fallback_category",
                    type: "category_nav",
                    visible: true,
                    props: { source: "auto", limit: 12, columns: 4, layout: "scroll" },
                  },
                ],
              }}
            />
          ) : null}

          {deferredHomeExtrasVisible && restLayout?.blocks.length ? (
            <HomeLayoutRenderer layout={restLayout} />
          ) : null}

          {deferredHomeExtrasVisible && !hasLayout ? (
            <HomeLayoutRenderer
              layout={{
                id: 0,
                name: "fallback",
                status: 1,
                theme: { bg_color: Colors.screen.bg },
                blocks: [
                  {
                    id: "fallback_hot",
                    type: "product_list",
                    visible: true,
                    props: {
                      title: { zh: "热销榜单", en: "Hot Products" },
                      source: "hot",
                      layout: "horizontal",
                      limit: 10,
                    },
                  },
                  {
                    id: "fallback_new",
                    type: "product_list",
                    visible: true,
                    props: {
                      title: { zh: "推荐新品", en: "New Picks" },
                      source: "new",
                      layout: "grid",
                      limit: 8,
                    },
                  },
                ],
              }}
            />
          ) : null}
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  outer: {
    flex: 1,
    backgroundColor: Colors.screen.bg,
  },
  shell: {
    flex: 1,
    width: "100%",
    maxWidth: 430,
    alignSelf: "center",
    backgroundColor: Colors.screen.bg,
  },
  scroll: {
    flex: 1,
    backgroundColor: Colors.screen.bg,
  },
  topWrap: {
    position: "relative",
    zIndex: 20,
    backgroundColor: "transparent",
    paddingHorizontal: s(16),
    paddingBottom: s(8),
  },
  topBar: {
    minHeight: s(42),
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  topLeft: {
    flex: 1,
    minWidth: 0,
    flexDirection: "row",
    alignItems: "center",
    gap: s(10),
    marginRight: s(10),
  },
  logoFrame: {
    flex: 1,
    maxWidth: s(168),
    height: s(28),
    justifyContent: "center",
    alignItems: "flex-start",
  },
  topActions: {
    flexShrink: 0,
    flexDirection: "row",
    alignItems: "center",
    gap: s(10),
  },
  iconButton: {
    width: s(40),
    height: s(40),
    borderRadius: s(20),
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    ...Shadows.raisedSm,
  },
  notificationDot: {
    position: "absolute",
    top: s(8),
    right: s(8),
    width: s(7),
    height: s(7),
    borderRadius: s(4),
    backgroundColor: Colors.brand.red,
  },
  searchBox: {
    height: s(46),
    borderRadius: s(23),
    backgroundColor: "#FFFFFF",
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: s(16),
    gap: s(9),
    marginTop: s(12),
    ...Shadows.raisedSm,
  },
  searchText: {
    flex: 1,
    color: Colors.home.muted,
    fontSize: s(13.5),
    fontWeight: "500",
  },
  entryRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: s(10),
    marginHorizontal: s(16),
    marginTop: s(16),
  },
  entrySideSlot: {
    flex: 1,
    height: s(92),
  },
  entrySide: {
    width: "100%",
    height: "100%",
    borderRadius: s(22),
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: Colors.screen.hairline,
    alignItems: "center",
    justifyContent: "center",
    ...Shadows.raised,
  },
  entryCenterSlot: {
    flex: 1.12,
    height: s(108),
  },
  entryCenter: {
    width: "100%",
    height: "100%",
    borderRadius: s(22),
  },
  entryCaption: {
    textAlign: "center",
    color: "#8A8F8E",
    fontSize: s(11.5),
    fontWeight: "600",
    marginTop: s(10),
    letterSpacing: 0.2,
  },
  fallbackBanner: {
    marginHorizontal: s(16),
    marginTop: s(12),
    height: s(150),
    borderRadius: s(24),
    overflow: "hidden",
    backgroundColor: "#08AEB4",
    ...Shadows.raisedLg,
  },
  fallbackBannerCopy: {
    position: "absolute",
    left: s(22),
    top: s(44),
  },
  fallbackBannerTitle: {
    color: Colors.white,
    fontSize: s(28),
    lineHeight: s(32),
    fontWeight: "800",
  },
  fallbackBannerSub: {
    color: "rgba(255,255,255,0.88)",
    fontSize: s(13),
    marginTop: s(6),
    fontWeight: "600",
  },
});
