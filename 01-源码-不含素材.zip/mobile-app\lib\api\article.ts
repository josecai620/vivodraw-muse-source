import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";

export function getArticleCategoryList() {
  return http.get(API_ENDPOINTS.article.categoryList);
}

export function getArticleList(cid: number, params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.article.list(cid), { params });
}

export function getArticleDetail(id: number) {
  return http.get(API_ENDPOINTS.article.details(id));
}

export function getArticleHotList(params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.article.hot, { params });
}

export function getArticleNewList(params?: { page?: number; limit?: number }) {
  return http.get(API_ENDPOINTS.article.new, { params });
}
