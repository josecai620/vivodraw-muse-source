import { fetchAuthGet, fetchAuthPost } from "@/lib/api/legacyHttp";

export type RewardCoinSummary = {
  coinBalance: number;
  exchangeRate: number;
  convertiblePoints: number;
  remainingCoins: number;
};

type RemoteSummary = {
  coin_balance?: number | string;
  reward_coin_balance?: number | string;
  exchange_rate?: number | string;
  convertible_points?: number | string;
  remaining_coins?: number | string;
  points?: number | string;
  point_balance?: number | string;
  coins_spent?: number | string;
};

function toNumber(value: unknown) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function normalizeSummary(payload?: RemoteSummary): RewardCoinSummary {
  const coinBalance = toNumber(payload?.coin_balance ?? payload?.reward_coin_balance);
  const exchangeRate = Math.max(10, toNumber(payload?.exchange_rate) || 10);
  return {
    coinBalance,
    exchangeRate,
    convertiblePoints: toNumber(payload?.convertible_points) || Math.floor(coinBalance / exchangeRate),
    remainingCoins: toNumber(payload?.remaining_coins) || coinBalance % exchangeRate,
  };
}

export async function fetchRewardCoinSummary(): Promise<{ ok: boolean; summary?: RewardCoinSummary; message?: string; status?: number }> {
  const result = await fetchAuthGet<RemoteSummary>("/api/reward_coin/summary");
  return {
    ok: result.ok,
    summary: result.data ? normalizeSummary(result.data) : undefined,
    message: result.message,
    status: result.status,
  };
}

export async function exchangeRewardCoinsToPoints(coins = 0): Promise<{
  ok: boolean;
  summary?: RewardCoinSummary;
  points: number;
  coinsSpent: number;
  message?: string;
  status?: number;
}> {
  const result = await fetchAuthPost<RemoteSummary>("/api/reward_coin/exchange", { coins });
  return {
    ok: result.ok,
    summary: result.data ? normalizeSummary(result.data) : undefined,
    points: toNumber(result.data?.points),
    coinsSpent: toNumber(result.data?.coins_spent),
    message: result.message,
    status: result.status,
  };
}
