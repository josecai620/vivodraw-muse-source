/**
 * 我的背包 — Premium Dark Gaming UI
 */
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { Pressable, ScrollView, Text, View, ActivityIndicator } from "react-native";
import { useRouter } from "expo-router";
import { Image } from "expo-image";
import { Package, Truck, Recycle } from "lucide-react-native";
import { useRevealColorScheme } from "@/contexts/RevealColorSchemeContext";
import { useBoxList } from "@/hooks";

import { BoxHeader, BoxTabBar, RarityBadge, BoxEmptyState, BoxActionButton } from "@/components/box";
import { NextStepGuide } from "@/components/onboarding/PlayGuides";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  getRarityTier, bs,
} from "@/lib/boxTheme";

type TabKey = "all" | "pending" | "shipped" | "recyclable";

const STATUS_COLORS: Record<string, { bg: string; text: string }> = {
  shipped: { bg: "rgba(4,168,174,0.15)", text: "#04A8AE" },
  pending: { bg: "rgba(4,168,174,0.15)", text: "#04A8AE" },
  recyclable: { bg: "rgba(145,146,144,0.15)", text: "#919290" },
};

function isRemoteImage(value?: string) {
  return !!value && /^https?:\/\//i.test(value);
}

export default function BackpackScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const { colors } = useRevealColorScheme();
  const [activeTab, setActiveTab] = useState<TabKey>("all");

  const { data: backpackItems, isLoading } = useBoxList();

  const mapStatus = (status: number): string => {
    switch (status) {
      case 0: return "pending";
      case 1: return "shipped";
      case 2: return "recyclable";
      default: return "pending";
    }
  };

  const items = (backpackItems || []).map((item: Record<string, unknown>) => ({
    id: item.id,
    name: item.name || t("backpack.fallbackItem"),
    image: item.image ?? undefined,
    rarity: String(item.rarity || "common"),
    status: mapStatus(Number(item.status)),
    recycleValue: item.recycleValue || 0,
    boxName: item.boxName || t("backpack.fallbackBox"),
    qty: Number(item.qty || item.quantity || 1),
  }));

  const filteredItems = activeTab === "all"
    ? items
    : items.filter((i: { status: string }) => i.status === activeTab);

  const tabs = [
    { key: "all", label: t("backpack.tabAll"), count: items.length, icon: <Package size={bs(14)} color={activeTab === "all" ? "#fff" : BoxText.secondary} /> },
    { key: "pending", label: t("backpack.tabPending"), count: items.filter((i: { status: string }) => i.status === "pending").length },
    { key: "shipped", label: t("backpack.tabShipped"), count: items.filter((i: { status: string }) => i.status === "shipped").length, icon: <Truck size={bs(14)} color={activeTab === "shipped" ? "#fff" : BoxText.secondary} /> },
    { key: "recyclable", label: t("backpack.tabRecyclable"), count: items.filter((i: { status: string }) => i.status === "recyclable").length, icon: <Recycle size={bs(14)} color={activeTab === "recyclable" ? "#fff" : BoxText.secondary} /> },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("backpack.title")} />

      <BoxTabBar
        tabs={tabs}
        activeKey={activeTab}
        onSelect={(key) => setActiveTab(key as TabKey)}
        style={{ backgroundColor: BoxSurfaces.deep, borderBottomWidth: 1, borderBottomColor: BoxBorders.subtle }}
      />

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(100), gap: BoxSpacing.md }}>
          <NextStepGuide kind="boxBackpack" />

          {isLoading ? (
            <View style={{ alignItems: "center", paddingVertical: bs(48) }}>
              <ActivityIndicator size="large" color={BoxAccent.gold} />
              <Text style={[BoxTypography.caption, { color: BoxText.secondary, marginTop: BoxSpacing.md }]}>
                {t("common.loading")}
              </Text>
            </View>
          ) : filteredItems.length === 0 ? (
            <BoxEmptyState
              icon={<Package size={bs(48)} color={BoxText.tertiary} />}
              title={t("backpack.empty")}
              description={t("backpack.emptyHint") || undefined}
              actionLabel={t("backpack.goExplore") || undefined}
              onAction={() => router.push("/box")}
            />
          ) : (
            filteredItems.map((item: any) => {
              const rarity = getRarityTier(item.rarity);
              const statusStyle = STATUS_COLORS[item.status] || STATUS_COLORS.pending;
              const statusLabel = item.status === "shipped" ? t("backpack.tabShipped") : item.status === "pending" ? t("backpack.tabPending") : t("backpack.tabRecyclable");
              return (
                <View key={item.id} style={{
                  backgroundColor: BoxSurfaces.card,
                  borderRadius: BoxRadius["2xl"],
                  borderWidth: 1, borderColor: BoxBorders.default,
                  padding: BoxSpacing.lg,
                  flexDirection: "row", alignItems: "center", gap: BoxSpacing.md,
                  ...BoxShadows.subtle,
                }}>
                  {/* Item image */}
                  <View style={{
                    width: bs(64), height: bs(64), borderRadius: BoxRadius.xl,
                    backgroundColor: rarity.bgSubtle,
                    alignItems: "center", justifyContent: "center",
                    borderWidth: 1, borderColor: rarity.borderColor,
                  }}>
                    {isRemoteImage(String(item.image)) ? (
                      <Image source={{ uri: String(item.image) }} style={{ width: bs(52), height: bs(52), borderRadius: BoxRadius.lg }} contentFit="cover" />
                    ) : (
                      <Package size={bs(28)} color={rarity.color} />
                    )}
                    {item.qty > 1 && (
                      <View style={{
                        position: "absolute", top: -6, right: -6,
                        backgroundColor: BoxAccent.gold, borderRadius: BoxRadius.full,
                        paddingHorizontal: 6, paddingVertical: 2,
                        borderWidth: 2, borderColor: BoxSurfaces.card,
                      }}>
                        <Text style={[BoxTypography.micro, { color: BoxText.onGold }]}>x{item.qty}</Text>
                      </View>
                    )}
                  </View>

                  {/* Item info + status in top-right */}
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" }}>
                      <Text style={[BoxTypography.bodyBold, { color: BoxText.primary, flex: 1, marginRight: BoxSpacing.sm }]} numberOfLines={1}>
                        {item.name}
                      </Text>
                      <View style={{
                        paddingHorizontal: BoxSpacing.sm, paddingVertical: 3,
                        borderRadius: BoxRadius.sm, backgroundColor: statusStyle.bg,
                      }}>
                        <Text style={{ fontSize: bs(10), fontWeight: "700", color: statusStyle.text }}>
                          {statusLabel}
                        </Text>
                      </View>
                    </View>
                    <RarityBadge tier={item.rarity} size="sm" style={{ marginTop: 6 }} />
                    <Text style={[BoxTypography.micro, { color: BoxText.tertiary, marginTop: 4 }]}>
                      {item.boxName} · <Text style={{ color: BoxAccent.gold }}>{item.recycleValue} pts</Text> recycle
                    </Text>
                  </View>
                </View>
              );
            })
          )}
        </View>
      </ScrollView>
    </View>
  );
}
