import { fetchAuthGet, fetchAuthPost, fetchReadApi, type ApiWriteResult } from "@/lib/api/legacyHttp";

export type PearlKey = "sand" | "white" | "pink" | "gold" | "black" | "aurora" | "living";
export type PearlPlayMode = "free" | "paid";
export type PearlTell = "bubbles" | "shimmer" | "ajar" | "heartbeat" | "visitor";
export type PearlPose = "round" | "tall" | "fan" | "knobby" | "flat" | "spiral";
export type PearlCharmId = "star" | "kelp" | "hermit" | "coral" | "fan" | "seahorse" | "jelly";
export type PearlKind = { id: PearlKey; name: string; points: number; weight: number; coins?: number };
export type PearlCharm = { id: PearlCharmId; name: string; buy: number };

// 集齐某档珍珠即送对应挂件（服务端记账，客户端只展示进度）
export type PearlCharmMilestone = {
  tier: string;
  charm: PearlCharmId;
  need: number;
  count: number;
  granted: boolean;
  owned: boolean;
};
export type PearlDecoration = {
  id: string; name: string; requirementType: string; required: number; current: number; unlocked: boolean;
};
export type PearlRules = {
  ruleVersion: string; serverNowMs: number; resetAtMs: number; shellCount: number;
  pearlShellCount: number; dailyFreePlays: number; emptyShellFragments: number; doubleOpenChance: number;
  dailyGoal: { plays: number; fragments: number; reefStone?: number }; pearls: PearlKind[];
  decorations: Omit<PearlDecoration, "current" | "unlocked">[]; freePointsDailyCap: number;
  paidCost?: number; pricingVersion?: string; paidPearls?: { id: PearlKey; name: string; coins: number; weight: number }[];
  game?: "pearl"; currencyCode?: "pearl_coin"; currencyName?: string;
  charms?: PearlCharm[]; pity?: { pink: number; gold: number; aurora: number };
  freePointsFloor?: number; freePointsCap?: number; fragmentConvert?: number;
};
export type PearlRound = {
  pearlsInRound?: number;
  id: number; requestId: string; selectedShell: number;
  status: "choosing" | "complete"; maxSelections: 1 | 2; selectedShells: number[];
  shells: { index: number; pearlKey: PearlKey | null; tells?: PearlTell[]; pose?: PearlPose }[]; pearlKey: PearlKey | null;
  pointsDelta: number; requestedPoints: number; rewardCapped: boolean; fragmentsDelta: number;
  dailyGoalFragments: number; newCollectionKeys: string[]; unlockedDecorationKeys: string[];
  ruleVersion: string; createdAtMs: number;
  playMode?: PearlPlayMode; pricingVersion?: string | null; coinsSpent?: number; coinsDelta?: number;
  coinBalance?: number; coinCostBillId?: number; coinRewardBillId?: number;
  game?: "pearl"; currencyCode?: "pearl_coin" | "reward_coin"; currencyName?: string;
  convertedCoins?: number; streak?: number; dailyStone?: boolean;
};
export type PearlState = {
  mode: "formal" | "unavailable"; available: boolean; reasonCode?: string;
  serverNowMs: number; ruleVersion: string; rules: PearlRules;
  profile: {
    accountId?: number;
    pointsBalance: number; playsTotal: number; playsToday: number; dailyLimit: number;
    remainingPlays: number; freePointsRemainingToday: number; fragmentsTotal: number;
    pearlsTotal: number; dailyGoalClaimed: boolean; resetAtMs: number;
    coinBalance?: number; freeRemaining?: number; paidCost?: number;
    game?: "pearl"; currencyCode?: "pearl_coin"; currencyName?: string;
    fragmentBank?: number; reefStones?: number; divesToday?: number; streak?: number; bestStreak?: number;
    freePointsToday?: number;
  } | null;
  collection: (PearlKind & { count: number; collected: boolean })[];
  decorations: PearlDecoration[]; lastRound: PearlRound | null;
  companions?: string[]; charms?: PearlCharmId[];
  charmMilestones?: PearlCharmMilestone[];
};
export type PearlOpenResult = {
  accepted: boolean; duplicate: boolean; requestId: string; reasonCode?: string;
  round: PearlRound | null; snapshot: PearlState;
};
export type PearlCharmResult = {
  accepted: boolean; reasonCode?: string; snapshot?: PearlState;
};

export async function getPearlRules(): Promise<PearlRules | undefined> {
  try {
    return await fetchReadApi<PearlRules>("/api/pearl/rules");
  } catch {
    return undefined;
  }
}

// legacyHttp 已用 AbortController 限时 15 秒（包含响应体读取）。
// 不再用较短的 Promise.race 丢弃迟到成功，也不叠加重试；失败由页面持原请求恢复。
async function pearlRequest<T>(request: () => Promise<ApiWriteResult<T>>): Promise<ApiWriteResult<T>> {
  try {
    return await request();
  } catch {
    return { ok: false, message: "Pearl request could not be completed." };
  }
}

// 只读核对待确认动作时用独有URL避开旧缓存；仍只发一次GET，不增加重试。
export const getPearlState = (fresh = false) => pearlRequest(() => fetchAuthGet<PearlState>(
  fresh ? `/api/pearl/state?_fresh=${encodeURIComponent(newPearlRequestId())}` : "/api/pearl/state",
));
export const startPearlRound = (requestId: string, expectedPreviousRoundId: number, mode: PearlPlayMode = "free", pricingVersion?: string) =>
  pearlRequest(() => fetchAuthPost<PearlOpenResult>("/api/pearl/start", {
    requestId, expectedPreviousRoundId, ...(mode === "paid" ? { mode, pricingVersion } : {}),
  }));
export const pickPearlShell = (requestId: string, selectedShell: number, selectionStep: 1 | 2) =>
  pearlRequest(() => fetchAuthPost<PearlOpenResult>("/api/pearl/pick", { requestId, selectedShell, selectionStep }));
// 仅供已经保存的旧版待确认记录恢复，新的探索必须走 start / pick。
export const openPearlShell = (requestId: string, selectedShell: number) =>
  pearlRequest(() => fetchAuthPost<PearlOpenResult>("/api/pearl/open", { requestId, selectedShell }));
export const buyPearlCharm = (requestId: string, charmId: PearlCharmId) =>
  pearlRequest(() => fetchAuthPost<PearlCharmResult>("/api/pearl/charm/buy", { requestId, charmId }));

// 这里只生成请求标识；次数、随机结果、积分和收藏全部由服务器确定。
export function newPearlRequestId() {
  if (typeof globalThis.crypto?.randomUUID === "function") return globalThis.crypto.randomUUID();
  const words = new Uint32Array(4);
  globalThis.crypto.getRandomValues(words);
  return `pearl-${Array.from(words, (word) => word.toString(16).padStart(8, "0")).join("")}`;
}
