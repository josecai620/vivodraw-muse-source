import {
  addToCart,
  flattenCartList,
  getCartCount,
  getCartList,
  removeFromCart,
  updateCartNum,
} from "@/lib/api/cart";
import type { CartItem } from "@/lib/api/cart";
import { unwrapApiData } from "@/lib/api/response";
import { useAppStore } from "@/store/app";
import { useCartStore } from "@/store/cart";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";

type CartListData = { valid: CartItem[]; invalid: CartItem[] };
type RawCartListData = { valid?: unknown; invalid?: unknown };
type AddToCartData = { cartId?: unknown };

export function useCartList() {
  const setItems = useCartStore((s) => s.setItems);

  return useQuery({
    queryKey: ["cart"],
    queryFn: async () => {
      const res = await getCartList();
      const raw = unwrapApiData<RawCartListData>(res, {});
      // 后端是「按活动分组」结构，这里拍平成购物车项，页面才能正常渲染
      const data: CartListData = {
        valid: flattenCartList(raw.valid),
        invalid: flattenCartList(raw.invalid),
      };
      setItems(data.valid);
      return data;
    },
  });
}

export function useCartCount() {
  const setCount = useCartStore((s) => s.setCount);

  return useQuery({
    queryKey: ["cartCount"],
    queryFn: async () => {
      const res = await getCartCount();
      const data = unwrapApiData<{ count: number }>(res, { count: 0 });
      setCount(Number(data.count) || 0);
      return Number(data.count) || 0;
    },
  });
}

export function useAddToCart() {
  const queryClient = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);

  return useMutation({
    mutationFn: addToCart,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cart"] });
      queryClient.invalidateQueries({ queryKey: ["cartCount"] });
      showToast("Added to cart", "success");
    },
    onError: (err: Error) => {
      showToast(err.message, "error");
    },
  });
}

/** 立即购买：加购（is_new=1，不落购物车）→ 直达结算页 */
export function useAddToCartAndCheckout() {
  const queryClient = useQueryClient();
  const showToast = useAppStore((s) => s.showToast);
  const router = useRouter();

  return useMutation({
    mutationFn: addToCart,
    onSuccess: (res) => {
      queryClient.invalidateQueries({ queryKey: ["cart"] });
      queryClient.invalidateQueries({ queryKey: ["cartCount"] });
      const data = unwrapApiData<AddToCartData>(res, {});
      const id = Array.isArray(data.cartId) ? data.cartId[0] : data.cartId;
      if (!id) {
        showToast("Failed to start checkout", "error");
        return;
      }
      router.push({ pathname: "/checkout", params: { cartId: String(id), new: "1" } });
    },
    onError: (err: Error) => {
      showToast(err?.message ?? "Failed", "error");
    },
  });
}

export function useRemoveFromCart() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: removeFromCart,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cart"] });
      queryClient.invalidateQueries({ queryKey: ["cartCount"] });
    },
  });
}

export function useUpdateCartNum() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, num }: { id: number; num: number }) => updateCartNum(id, num),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["cart"] });
    },
  });
}
