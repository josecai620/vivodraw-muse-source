import type { CloudBuyCartItem } from "@/lib/points/cloudBuyCart";

const PENDING_KEY = "yunmall:pendingCartItem";

function canUseSession() {
  return typeof sessionStorage !== "undefined";
}

/** 立即参与时先记下刚加的商品，清单页接口空着也能先画出来。 */
export function rememberPendingCartItem(item: CloudBuyCartItem) {
  if (!canUseSession()) return;
  try {
    sessionStorage.setItem(PENDING_KEY, JSON.stringify(item));
  } catch {
    /* ignore */
  }
}

export function peekPendingCartItem(): CloudBuyCartItem | null {
  if (!canUseSession()) return null;
  try {
    const raw = sessionStorage.getItem(PENDING_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const productId = Number(parsed?.productId ?? 0);
    if (!productId) return null;
    return {
      id: Number(parsed?.id ?? 0),
      productId,
      name: String(parsed?.name ?? ""),
      image: String(parsed?.image ?? ""),
      num: Math.max(1, Number(parsed?.num ?? 1) || 1),
      bianhao: String(parsed?.bianhao ?? ""),
      remain: Math.max(0, Number(parsed?.remain ?? 0) || 0),
      totalNeed: Math.max(1, Number(parsed?.totalNeed ?? 1) || 1),
    };
  } catch {
    return null;
  }
}

export function clearPendingCartItem() {
  if (!canUseSession()) return;
  try {
    sessionStorage.removeItem(PENDING_KEY);
  } catch {
    /* ignore */
  }
}

export function openCloudBuyCartList(router: { push: (href: never) => void }) {
  router.push("/points/cart" as never);
}
