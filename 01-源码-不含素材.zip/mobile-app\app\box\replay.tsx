import React, { useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  Pressable,
  ActivityIndicator,
} from "react-native";
import { Image } from "expo-image";
import { useTranslation } from "react-i18next";
import { useRouter } from "expo-router";
import { Play, Box } from "lucide-react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { BoxHeader, RarityBadge, BoxActionButton, BoxEmptyState, BoxTabBar } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows,
  getRarityTier, bs,
} from "@/lib/boxTheme";
import { useReplayList } from "@/hooks";

export default function ReplayPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const [page, setPage] = useState(1);
  const { data, isLoading } = useReplayList(page);

  const items = data?.list || [];
  const hasMore = data?.hasMore || false;

  const handleReplay = useCallback(
    (item: any) => {
      const result = JSON.stringify({
        id: item.productId,
        name: item.productName,
        image: item.productImage,
        rarity: item.rarity,
      });
      router.push({
        pathname: `/box/[id]/opening`,
        params: { id: item.cateId, result: encodeURIComponent(result) },
      });
    },
    [router]
  );

  const renderItem = useCallback(
    ({ item }: { item: any }) => {
      const rc = getRarityTier(item.rarity);
      return (
        <Pressable
          onPress={() => handleReplay(item)}
          style={{
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: BoxSurfaces.card,
            borderRadius: BoxRadius.xl,
            borderWidth: 1,
            borderColor: rc.borderColor,
            padding: BoxSpacing.md,
            marginBottom: BoxSpacing.md,
            gap: BoxSpacing.md,
            ...BoxShadows.subtle,
          }}
        >
          <View style={{
            width: bs(60), height: bs(60), borderRadius: BoxRadius.lg,
            alignItems: "center", justifyContent: "center",
            backgroundColor: rc.bgSubtle,
          }}>
            {item.productImage ? (
              <Image
                source={{ uri: item.productImage }}
                style={{ width: bs(48), height: bs(48), borderRadius: BoxRadius.sm }}
                contentFit="contain"
                transition={200}
              />
            ) : (
              <Box size={bs(32)} color={rc.color} />
            )}
          </View>
          <View style={{ flex: 1, gap: BoxSpacing.xs }}>
            <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]} numberOfLines={1}>
              {item.productName}
            </Text>
            <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm }}>
              <RarityBadge tier={item.rarity} size="sm" />
              <Text style={[BoxTypography.micro, { color: BoxText.tertiary }]}>
                {item.createDate}
              </Text>
            </View>
            <Text style={[BoxTypography.micro, { color: BoxText.tertiary }]}>
              {item.cateName}
            </Text>
          </View>
          <View style={{
            width: bs(40), height: bs(40), borderRadius: bs(20),
            backgroundColor: BoxAccent.purpleMuted,
            alignItems: "center", justifyContent: "center",
            ...BoxShadows.glow(BoxAccent.purple),
          }}>
            <Play size={bs(18)} color={BoxAccent.purpleLight} fill={BoxAccent.purpleLight} />
          </View>
        </Pressable>
      );
    },
    [handleReplay, t]
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("replay.title")} showThemeToggle={false} />

      <FlatList
        data={items}
        keyExtractor={(item) => String(item.id)}
        renderItem={renderItem}
        contentContainerStyle={{
          padding: BoxSpacing.lg,
          paddingBottom: BoxSpacing["4xl"],
        }}
        ListEmptyComponent={
          isLoading ? (
            <ActivityIndicator size="large" color={BoxAccent.gold} style={{ marginTop: bs(60) }} />
          ) : (
            <BoxEmptyState
              icon={<Play size={bs(48)} color={BoxText.tertiary} />}
              title={t("replay.empty")}
              description={t("replay.emptySub")}
            />
          )
        }
        onEndReached={() => {
          if (hasMore && !isLoading) setPage((p) => p + 1);
        }}
        onEndReachedThreshold={0.3}
      />
    </SafeAreaView>
  );
}
