/** 只保存恢复请求所需的标识和选择；积分、结果、令牌及账号资料不进入记录。 */
export type PendingExploration =
  | { requestId: string; selectedShell: number; action?: undefined }
  | { requestId: string; action: "start"; expectedPreviousRoundId: number; mode?: "free"; pricingVersion?: undefined }
  | { requestId: string; action: "start"; expectedPreviousRoundId: number; mode: "paid"; pricingVersion: string }
  | { requestId: string; action: "pick"; selectedShell: number; selectionStep: 1 | 2 };
export type PendingExplorationErrorCode = "invalid_account" | "invalid_request" | "invalid_record" | "storage_unavailable";

export class PendingExplorationStorageError extends Error {
  readonly code: PendingExplorationErrorCode;

  constructor(code: PendingExplorationErrorCode) {
    super(`Pending exploration recovery failed: ${code}`);
    this.name = "PendingExplorationStorageError";
    this.code = code;
  }
}

function storageKey(uid: number): string {
  if (!Number.isSafeInteger(uid) || uid <= 0) throw new PendingExplorationStorageError("invalid_account");
  return `vivodraw:海底寻珠:待结算:v1:${uid}`;
}

function requestIdValid(value: unknown): value is string {
  return typeof value === "string" && value === value.trim() && /^[A-Za-z0-9._:-]{8,128}$/.test(value);
}

function validateRequest(value: unknown, code: "invalid_request" | "invalid_record"): PendingExploration {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new PendingExplorationStorageError(code);
  const record = value as Record<string, unknown>;
  const keys = Object.keys(record);
  if (!requestIdValid(record.requestId)) throw new PendingExplorationStorageError(code);
  if (record.action === "start" && Number.isSafeInteger(record.expectedPreviousRoundId)
    && typeof record.expectedPreviousRoundId === "number" && record.expectedPreviousRoundId >= 0) {
    const base = { requestId: record.requestId, action: "start" as const, expectedPreviousRoundId: record.expectedPreviousRoundId };
    if (keys.length === 3 && !keys.includes("mode") && !keys.includes("pricingVersion")) return base;
    if (keys.length === 4 && record.mode === "free" && !keys.includes("pricingVersion")) return { ...base, mode: "free" as const };
    if (keys.length === 5 && record.mode === "paid" && typeof record.pricingVersion === "string"
      && /^[A-Za-z0-9._:-]{1,96}$/.test(record.pricingVersion)) return { ...base, mode: "paid" as const, pricingVersion: record.pricingVersion };
    throw new PendingExplorationStorageError(code);
  }
  const legacy = record.action === undefined && keys.length === 2 && !keys.includes("action");
  const pick = record.action === "pick" && keys.length === 4 && (record.selectionStep === 1 || record.selectionStep === 2);
  if ((!legacy && !pick) || !Number.isInteger(record.selectedShell)
    || typeof record.selectedShell !== "number" || record.selectedShell < 0 || record.selectedShell > 5) {
    throw new PendingExplorationStorageError(code);
  }
  // 返回独立副本，调用者修改对象不会改变待结算标识。
  return pick ? { requestId: record.requestId, action: "pick", selectedShell: record.selectedShell, selectionStep: record.selectionStep as 1 | 2 }
    : { requestId: record.requestId, selectedShell: record.selectedShell };
}

/** 同一个局号不代表同一个动作；第二次选择必须逐项确认，才可清理恢复记录。 */
export function pendingConfirmedByRound(request: PendingExploration, round: {
  requestId: string; selectedShell: number; selectedShells?: number[]; status?: string; playMode?: string; pricingVersion?: string | null; currencyCode?: string;
} | null | undefined): boolean {
  if (!round || round.requestId !== request.requestId) return false;
  // v1 已扣旧金币的局继续按原币结算；新局必须明确返回寻珠专属币。
  if (round.playMode === "paid" && (round.currencyCode ?? (round.pricingVersion === "pearl-paid-20260913-v1" ? "reward_coin" : ""))
    !== (round.pricingVersion === "pearl-paid-20260913-v1" ? "reward_coin" : "pearl_coin")) return false;
  // 旧记录只代表免费开局，不能用同 ID 的金币局清除；付费重试必须确认原报价。
  if (request.action === "start") return (round.playMode ?? "free") === (request.mode ?? "free")
    && (request.mode !== "paid" || round.pricingVersion === request.pricingVersion);
  if (request.action === "pick") return round.selectedShells?.[request.selectionStep - 1] === request.selectedShell;
  return round.status !== "choosing" && round.selectedShell === request.selectedShell;
}

function browserStorage(): Storage {
  try {
    if (typeof window === "undefined") throw new Error("Browser storage is unavailable");
    const storage = window.localStorage;
    if (!storage || typeof storage.getItem !== "function" || typeof storage.setItem !== "function" || typeof storage.removeItem !== "function") {
      throw new Error("Browser storage is unavailable");
    }
    return storage;
  } catch {
    // 浏览器拒绝存储时禁止降级为内存记录，否则刷新后会换一个请求标识。
    throw new PendingExplorationStorageError("storage_unavailable");
  }
}

function readRaw(storage: Storage, key: string): string | null {
  try { return storage.getItem(key); }
  catch { throw new PendingExplorationStorageError("storage_unavailable"); }
}

function readFromStorage(storage: Storage, key: string): PendingExploration | undefined {
  const raw = readRaw(storage, key);
  if (raw === null) return undefined;
  if (raw.length > 512) throw new PendingExplorationStorageError("invalid_record");
  let decoded: unknown;
  try { decoded = JSON.parse(raw); }
  catch { throw new PendingExplorationStorageError("invalid_record"); }
  // 无效记录保留原样并阻止新请求；不能静默删除后再次发奖。
  return validateRequest(decoded, "invalid_record");
}

/** 只有确实没有记录时返回 undefined；存储不可读或记录损坏都抛错。 */
export function readPendingExploration(uid: number): PendingExploration | undefined {
  const key = storageKey(uid);
  return readFromStorage(browserStorage(), key);
}

/** 调用方必须使用返回的请求发送 POST，不能继续使用可能被替换的新请求。 */
export function savePendingExploration(uid: number, request: PendingExploration): PendingExploration {
  const key = storageKey(uid);
  const next = validateRequest(request, "invalid_request");
  const storage = browserStorage();
  const existing = readFromStorage(storage, key);
  if (existing) return existing;
  const serialized = JSON.stringify(next);
  try { storage.setItem(key, serialized); }
  catch { throw new PendingExplorationStorageError("storage_unavailable"); }
  // 写入失败、被拦截或被其他页面更改时，均不允许启动新的正式请求。
  if (readRaw(storage, key) !== serialized) throw new PendingExplorationStorageError("storage_unavailable");
  return next;
}

/** 只清理指定账号且标识吻合的记录，迟到响应不能清除下一次探索。 */
export function clearPendingExploration(uid: number, request: string | PendingExploration): boolean {
  const key = storageKey(uid);
  const requestId = typeof request === "string" ? request : request.requestId;
  if (!requestIdValid(requestId)) throw new PendingExplorationStorageError("invalid_request");
  const storage = browserStorage();
  const existing = readFromStorage(storage, key);
  if (!existing || existing.requestId !== requestId) return false;
  // 字符串重载仅为旧版恢复兼容；新协议必须匹配动作、步数与位置。
  if (typeof request === "string" ? existing.action !== undefined
    : JSON.stringify(existing) !== JSON.stringify(validateRequest(request, "invalid_request"))) return false;
  try { storage.removeItem(key); }
  catch { throw new PendingExplorationStorageError("storage_unavailable"); }
  if (readRaw(storage, key) !== null) throw new PendingExplorationStorageError("storage_unavailable");
  return true;
}
