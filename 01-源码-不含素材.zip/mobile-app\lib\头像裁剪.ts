export const AVATAR_CROP_VIEW = 400;
export const AVATAR_CROP_HOLE = 368;
export const AVATAR_CROP_OUT = 512;
export const AVATAR_CROP_MIN_SCALE = 0.25;
export const AVATAR_CROP_MAX_SCALE = 6;
const AVATAR_CROP_DECODE_MAX = 1600;

export type CropSource = {
  source: CanvasImageSource;
  width: number;
  height: number;
  displayUrl: string;
  objectUrl?: string;
};

export function cropLayout(maxView = AVATAR_CROP_VIEW) {
  const vw = typeof window !== "undefined" ? window.innerWidth : maxView;
  const vh = typeof window !== "undefined" ? window.innerHeight : 720;
  const view = Math.max(280, Math.min(maxView, Math.floor(Math.min(vw - 20, vh - 210))));
  const hole = Math.max(240, Math.round(view * 0.92));
  return { view, hole };
}

export function coverScale(naturalW: number, naturalH: number, hole = AVATAR_CROP_HOLE) {
  if (naturalW <= 0 || naturalH <= 0) return 1;
  return Math.max(hole / naturalW, hole / naturalH);
}

function clampAxis(
  size: number,
  imgStart: number,
  imgEnd: number,
  holeStart: number,
  holeEnd: number,
  hole: number,
  current: number,
) {
  if (size >= hole) {
    let next = current;
    if (imgStart > holeStart) next -= imgStart - holeStart;
    if (imgEnd < holeEnd) next += holeEnd - imgEnd;
    return next;
  }
  let next = current;
  if (imgStart < holeStart) next += holeStart - imgStart;
  if (imgEnd > holeEnd) next -= imgEnd - holeEnd;
  return next;
}

export function clampPan(
  tx: number,
  ty: number,
  scale: number,
  naturalW: number,
  naturalH: number,
  view = AVATAR_CROP_VIEW,
  hole = AVATAR_CROP_HOLE,
) {
  const cover = coverScale(naturalW, naturalH, hole);
  const dw = naturalW * cover * scale;
  const dh = naturalH * cover * scale;
  const holeLeft = (view - hole) / 2;
  const holeTop = (view - hole) / 2;
  const holeRight = holeLeft + hole;
  const holeBottom = holeTop + hole;
  const imgLeft = view / 2 + tx - dw / 2;
  const imgTop = view / 2 + ty - dh / 2;
  return {
    tx: clampAxis(dw, imgLeft, imgLeft + dw, holeLeft, holeRight, hole, tx),
    ty: clampAxis(dh, imgTop, imgTop + dh, holeTop, holeBottom, hole, ty),
  };
}

export function clampScale(scale: number) {
  return Math.min(AVATAR_CROP_MAX_SCALE, Math.max(AVATAR_CROP_MIN_SCALE, scale));
}

function canvasToUrl(canvas: HTMLCanvasElement) {
  return canvas.toDataURL("image/jpeg", 0.85);
}

function rasterizeSource(source: CanvasImageSource, width: number, height: number): CropSource {
  const fit = Math.min(1, AVATAR_CROP_DECODE_MAX / Math.max(width, height, 1));
  const w = Math.max(1, Math.round(width * fit));
  const h = Math.max(1, Math.round(height * fit));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    throw new Error("canvas");
  }
  ctx.drawImage(source, 0, 0, w, h);
  return { source: canvas, width: w, height: h, displayUrl: canvasToUrl(canvas) };
}

export async function loadCropSource(fileOrUri: File | Blob | string): Promise<CropSource> {
  if (typeof File !== "undefined" && fileOrUri instanceof Blob && typeof createImageBitmap === "function") {
    try {
      const bmp = await createImageBitmap(fileOrUri, { imageOrientation: "from-image" } as ImageBitmapOptions);
      const loaded = rasterizeSource(bmp, bmp.width, bmp.height);
      if (typeof bmp.close === "function") bmp.close();
      return loaded;
    } catch {
      // 回落到 Image（iPhone HEIC / 旧 WebKit）
    }
  }
  const objectUrl = typeof fileOrUri === "string" ? fileOrUri : URL.createObjectURL(fileOrUri);
  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const el = new Image();
    el.crossOrigin = "anonymous";
    el.onload = () => resolve(el);
    el.onerror = () => reject(new Error("image load failed"));
    el.src = objectUrl;
  });
  const loaded = rasterizeSource(img, img.naturalWidth || img.width, img.naturalHeight || img.height);
  if (typeof fileOrUri !== "string") {
    URL.revokeObjectURL(objectUrl);
  }
  return loaded;
}

export function cropToJpegBlob(
  source: CanvasImageSource,
  naturalW: number,
  naturalH: number,
  scale: number,
  tx: number,
  ty: number,
  view = AVATAR_CROP_VIEW,
  hole = AVATAR_CROP_HOLE,
  outSize = AVATAR_CROP_OUT,
  quality = 0.92,
): Promise<Blob> {
  const cover = coverScale(naturalW, naturalH, hole);
  const dw = naturalW * cover * scale;
  const dh = naturalH * cover * scale;
  const imgLeft = view / 2 + tx - dw / 2;
  const imgTop = view / 2 + ty - dh / 2;
  const holeLeft = (view - hole) / 2;
  const holeTop = (view - hole) / 2;
  const canvas = document.createElement("canvas");
  canvas.width = outSize;
  canvas.height = outSize;
  const ctx = canvas.getContext("2d");
  if (!ctx) return Promise.reject(new Error("canvas"));
  ctx.fillStyle = "#111111";
  ctx.fillRect(0, 0, outSize, outSize);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  const dx = ((imgLeft - holeLeft) / hole) * outSize;
  const dy = ((imgTop - holeTop) / hole) * outSize;
  const ddw = (dw / hole) * outSize;
  const ddh = (dh / hole) * outSize;
  ctx.drawImage(source, 0, 0, naturalW, naturalH, dx, dy, ddw, ddh);
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("toBlob"))),
      "image/jpeg",
      quality,
    );
  });
}
