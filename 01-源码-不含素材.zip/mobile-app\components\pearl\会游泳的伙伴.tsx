import React, { useEffect, useMemo, useRef, useState } from "react";
import { Image as RNImage, Platform, StyleSheet, View } from "react-native";

const PETS = [
  { id: "clownfish", src: require("../../assets/海底寻珠/动态伙伴/clownfish.webp"), x: 16, y: 22, s: 1.9, size: 92, kind: "swim" as const },
  { id: "octopus", src: require("../../assets/海底寻珠/动态伙伴/octopus.webp"), x: 62, y: 16, s: 1.05, size: 96, kind: "swim" as const },
  { id: "axolotl", src: require("../../assets/海底寻珠/动态伙伴/axolotl.webp"), x: 20, y: 58, s: 1.3, size: 94, kind: "swim" as const },
  { id: "pip", src: require("../../assets/海底寻珠/动态伙伴/pip.webp"), x: 66, y: 52, s: 1.45, size: 88, kind: "swim" as const },
  { id: "star", src: require("../../assets/海底寻珠/动态伙伴/star.webp"), x: 42, y: 72, s: 0.4, size: 44, kind: "sand" as const },
  { id: "hermit", src: require("../../assets/海底寻珠/动态伙伴/hermit.webp"), x: 18, y: 70, s: 0.35, size: 46, kind: "sand" as const },
  { id: "seahorse", src: require("../../assets/海底寻珠/动态伙伴/seahorse.webp"), x: 58, y: 28, s: 1.1, size: 56, kind: "swim" as const },
  { id: "jelly", src: require("../../assets/海底寻珠/动态伙伴/jelly.webp"), x: 22, y: 12, s: 0.9, size: 58, kind: "swim" as const },
  { id: "kelp", src: require("../../assets/海底寻珠/动态礁石/kelp.png"), x: 4, y: 58, s: 0, size: 54, kind: "plant" as const },
  { id: "coral", src: require("../../assets/海底寻珠/动态礁石/coral.png"), x: 40, y: 68, s: 0, size: 52, kind: "plant" as const },
  { id: "fan", src: require("../../assets/海底寻珠/动态礁石/fan.png"), x: 70, y: 54, s: 0, size: 50, kind: "plant" as const },
] as const;

// 伙伴是 30 帧动画：浏览器原生就播；iOS/Android 的 RN Image 不播动图，
// 所以只有原生端才动态加载 expo-image（web 端根本不 require 它，避免影响 RN Web 的图片渲染）。
function CompanionArt({ source }: { source: number }) {
  if (Platform.OS === "web") return <RNImage source={source} style={styles.art} resizeMode="contain" />;
  const ExpoImage = require("expo-image").Image as React.ComponentType<{
    source: number; style: unknown; contentFit?: string; transition?: number;
  }>;
  return <ExpoImage source={source} style={styles.art} contentFit="contain" transition={0} />;
}

type Body = { id: string; x: number; y: number; vx: number; vy: number; facing: 1 | -1; next: number };

function positionCompanion(node: View | null, body: Body, dragging = false) {
  if (!node) return;
  if (Platform.OS === "web") {
    const element = node as unknown as HTMLElement;
    element.style.left = `${body.x}%`;
    element.style.top = `${body.y}%`;
    element.style.transform = `scaleX(${body.facing})`;
    element.style.zIndex = dragging ? "8" : "3";
    return;
  }
  node.setNativeProps({
    style: {
      left: `${body.x}%`,
      top: `${body.y}%`,
      transform: [{ scaleX: body.facing }],
      zIndex: dragging ? 8 : 3,
    },
  });
}

export function SwimmingCompanions({
  reducedMotion,
  visibleIds,
  interactive = false,
  onDragging,
}: {
  reducedMotion: boolean;
  visibleIds?: string[];
  interactive?: boolean;
  onDragging?: (v: boolean) => void;
}) {
  const visibleIdsKey = visibleIds?.join(",");
  const shown = useMemo(() => {
    const ids = visibleIdsKey?.split(",");
    return PETS.filter((pet) => !ids || ids.includes(pet.id));
  }, [visibleIdsKey]);
  const layer = useRef<View>(null);
  const nodes = useRef<Array<View | null>>([]);
  const bodies = useRef<Body[]>([]);
  const held = useRef<number | null>(null);
  const [heldIndex, setHeldIndex] = useState<number | null>(null);

  useEffect(() => {
    bodies.current = shown.map((pet) => {
      const existing = bodies.current.find((body) => body.id === pet.id);
      if (existing) return existing;
      const ang = Math.random() * Math.PI * 2;
      return {
        id: pet.id,
        x: pet.x,
        y: pet.y,
        vx: Math.cos(ang) * pet.s,
        vy: Math.sin(ang) * pet.s * 0.62,
        facing: 1 as const,
        next: 2800 + Math.random() * 4200,
      };
    });
    // Refs are already attached before effects run; do not clear live DOM nodes.
  }, [shown]);

  useEffect(() => {
    if (reducedMotion || Platform.OS !== "web") return;
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      bodies.current.forEach((body, index) => {
        if (held.current === index) return;
        const pet = shown[index];
        if (!pet || pet.kind === "plant") return;
        body.next -= dt * 1000;
        if (body.next <= 0) {
          const ang = Math.random() * Math.PI * 2;
          body.vx = Math.cos(ang) * pet.s;
          body.vy = Math.sin(ang) * pet.s * 0.62;
          body.next = 2800 + Math.random() * 4200;
        }
        body.x += body.vx * dt * 4.2;
        body.y += body.vy * dt * 3.1;
        if (body.x < 4 || body.x > 78) body.vx *= -1;
        if (body.y < 8 || body.y > 78) body.vy *= -1;
        body.x = Math.min(78, Math.max(4, body.x));
        body.y = Math.min(78, Math.max(8, body.y));
        body.facing = body.vx >= 0 ? 1 : -1;
        positionCompanion(nodes.current[index], body);
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [reducedMotion, shown]);

  const move = (index: number, x: number, y: number) => {
    const body = bodies.current[index];
    if (!body) return;
    body.x = Math.min(82, Math.max(0, x));
    body.y = Math.min(80, Math.max(0, y));
    positionCompanion(nodes.current[index], body, true);
  };

  return (
    <View ref={layer} pointerEvents={interactive ? "box-none" : "none"} style={styles.layer}>
      {shown.map((pet, index) => {
        const body = bodies.current.find((item) => item.id === pet.id);
        return (
        <View
          key={pet.id}
          ref={(node) => { nodes.current[index] = node; }}
          style={[styles.pet, { left: `${body?.x ?? pet.x}%`, top: `${body?.y ?? pet.y}%`, transform: [{ scaleX: body?.facing ?? 1 }], width: pet.size, height: pet.size, zIndex: heldIndex === index ? 8 : 3 }]}
          onStartShouldSetResponder={() => interactive}
          onMoveShouldSetResponder={() => interactive}
          onResponderGrant={() => {
            held.current = index;
            setHeldIndex(index);
            onDragging?.(true);
          }}
          onResponderMove={(event) => {
            if (held.current !== index || !layer.current) return;
            const native = event.nativeEvent;
            if (Platform.OS === "web") {
              const bounds = (layer.current as unknown as HTMLElement).getBoundingClientRect();
              if (bounds.width <= 0 || bounds.height <= 0) return;
              move(index, ((native.pageX - bounds.left - window.scrollX) / bounds.width) * 100 - 6, ((native.pageY - bounds.top - window.scrollY) / bounds.height) * 100 - 6);
              return;
            }
            (layer.current as unknown as { measure?: Function }).measure?.((_x: number, _y: number, w: number, h: number, pageX: number, pageY: number) => {
              if (w <= 0 || h <= 0) return;
              move(index, ((native.pageX - pageX) / w) * 100 - 6, ((native.pageY - pageY) / h) * 100 - 6);
            });
          }}
          onResponderRelease={() => {
            held.current = null;
            setHeldIndex(null);
            onDragging?.(false);
          }}
          onResponderTerminate={() => {
            held.current = null;
            setHeldIndex(null);
            onDragging?.(false);
          }}
        >
          <CompanionArt source={pet.src} />
        </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  // 必须低于蚌行（蚌行 zIndex 1/2）：小动物游在六只蚌后面，不挡蚌。
  layer: { ...StyleSheet.absoluteFillObject, zIndex: 0 },
  pet: { position: "absolute" },
  art: { width: "100%", height: "100%" },
});
