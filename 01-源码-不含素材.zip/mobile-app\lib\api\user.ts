import { API_ENDPOINTS } from "@/constants/api";
import { unwrapApiData } from "@/lib/api/response";
import { http } from "@/lib/http";

export interface UserProfile {
  id?: number;
  uid: number;
  nickname: string;
  avatar: string;
  phone: string;
  sex?: number;
  birthday?: number;
  now_money: string;
  integral: number;
  level: number;
  vip?: boolean;
  pet?: {
    code?: string;
    name?: string;
    species?: string;
    pet_code?: string;
    pet_name?: string;
    intimacy_level?: number;
  } | null;
  couponCount?: number;
  orderStatusNum?: {
    unPaid: number;
    unShipped: number;
    received: number;
    evaluated: number;
    refund: number;
  };
}

export interface LoginParams {
  account: string;
  password?: string;
  captcha?: string;
  type?: string;
  captcha_key?: string;
  captcha_code?: string;
}

export interface LoginErrorData {
  fail_count?: number;
  need_captcha?: boolean;
  locked?: boolean;
}

export function login(data: LoginParams) {
  return http.post<{ token: string; expires_time: number }>(API_ENDPOINTS.user.login, data);
}

export function getLoginCaptcha() {
  return http.get<{ key: string; img: string }>(API_ENDPOINTS.user.loginCaptcha);
}

export function register(data: {
  account: string;
  captcha: string;
  password: string;
  spread?: number;
}) {
  return http.post<{ token: string }>(API_ENDPOINTS.user.register, data);
}

/** 发送邮箱验证码；注册成功后验证码由 /api/register 校验并清除。 */
export async function sendEmailVerifyCode(email: string, type = "register") {
  const keyResponse = await http.get<{ key?: string; expire_time?: number }>(
    API_ENDPOINTS.user.emailVerifyCode,
  );
  const keyData = unwrapApiData<{ key?: string; expire_time?: number }>(keyResponse, {});
  const key = typeof keyData.key === "string" ? keyData.key.trim() : "";
  if (!key) throw new Error("Email verification service is unavailable.");

  await http.post(API_ENDPOINTS.user.emailVerify, {
    email: email.trim().toLowerCase(),
    type,
    key,
    code: "",
  });

  const expireMinutes = Number(keyData.expire_time) || 10;
  return Math.max(60, expireMinutes * 60);
}

export function getUserProfile() {
  return http.get<UserProfile>(API_ENDPOINTS.user.profile);
}

export type PetDialogueTrigger = "idle" | "story" | "daily_task" | "game_guide" | "reminder" | "user_chat";

export interface PetDialogueResult {
  title: string;
  message: string;
  cta_label: string;
  route: string;
  reward_hint: string;
  mood: "idle" | "guide" | "happy" | "reminder";
  source: "deepseek" | "fallback";
}

export function getPetDialogue(data: {
  trigger: PetDialogueTrigger;
  user_message?: string;
  client_context?: {
    route?: string;
    route_title?: string;
    task_hint?: string;
    local_time?: string;
  };
}) {
  return http.post<PetDialogueResult>(API_ENDPOINTS.user.petDialogue, data);
}

/** 获取短信验证码所需的 key（后端防刷，必须先调此接口） */
export function getVerifyCodeKey() {
  return http.get<{ key: string; expire_time: number }>(API_ENDPOINTS.user.verifyCodeKey);
}

/**
 * 发送短信验证码
 * @param phone 手机号
 * @param type 用途：register | reset | login | binding 等，默认 reset（找回密码）
 */
export function sendVerifyCode(phone: string, type = "reset") {
  return getVerifyCodeKey().then((res) => {
    const { key } = unwrapApiData<{ key?: string }>(res, {});
    if (!key) throw new Error("Failed to get verify key");
    return http.post(API_ENDPOINTS.user.sendCode, {
      phone,
      type,
      key,
      code: "", // 前 2 次无需图形验证码；超过则需先调 sms_captcha 并传用户输入的 code
    });
  });
}

export function logout() {
  return http.get(API_ENDPOINTS.user.logout);
}

/** 找回密码（重置密码） */
export function resetPassword(data: {
  account: string;
  captcha: string;
  password: string;
}) {
  return http.post(API_ENDPOINTS.user.reset, data);
}

export function changePassword(data: { old_password: string; new_password: string }) {
  return http.post(API_ENDPOINTS.user.changePassword, data);
}


/** 注销账号（confirm 必须为 "DELETE"，后端校验） */
export function cancelAccount(confirm: string) {
  return http.post<unknown>(API_ENDPOINTS.user.cancelAccount, { confirm });
}
export function updateProfile(data: { avatar?: string; nickname?: string }) {
  return http.post(API_ENDPOINTS.user.edit, data);
}

export interface UpdateProfileFullData {
  avatar?: string;
  nickname?: string;
  sex?: number | string;
  birthday?: string;
}

export function updateProfileFull(data: UpdateProfileFullData) {
  return http.post(API_ENDPOINTS.user.edits, data);
}

export function uploadImage(file: FormData) {
  return http.post<{ name: string; url: string }>(API_ENDPOINTS.user.uploadImage, file);
}

export function wearAvatarFrame(frameId: string) {
  return http.post<{ avatar_frame?: string }>(API_ENDPOINTS.user.avatarFrame, { frame_id: frameId });
}
