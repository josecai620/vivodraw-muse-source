import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Image,
  Pressable,
  ScrollView,
  Share,
  Text,
  View,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import * as Clipboard from "expo-clipboard";
import { Copy, Image as ImageIcon, QrCode, Share2 } from "lucide-react-native";
import { useTranslation } from "react-i18next";
import { useAuthStore } from "@/store/auth";
import { useAppStore } from "@/store/app";
import { TealGradient,  Colors, s  } from "@/constants/theme";
import { API_BASE_URL } from "@/constants/env";
import { API_ENDPOINTS } from "@/constants/api";
import PageHeader from "@/components/shared/PageHeader";

export default function CommissionPromoteScreen() {
  const { t } = useTranslation();
  const user = useAuthStore((x) => x.user);
  const showToast = useAppStore((x) => x.showToast);

  const uid = user?.uid;
  const shortLink = useMemo(
    () => (uid ? `${API_BASE_URL}/api/r/${uid}` : ""),
    [uid],
  );
  const longLink = useMemo(
    () =>
      uid
        ? `${API_BASE_URL}/pages/users/register/index?spread=${uid}`
        : "",
    [uid],
  );
  const inviteCode = uid ? String(uid) : "";

  const qrUrl = uid ? `${API_BASE_URL}${API_ENDPOINTS.commission.qrcode(uid)}` : "";
  const posterUrl = uid
    ? `${API_BASE_URL}${API_ENDPOINTS.commission.poster(uid)}`
    : "";

  const [saving, setSaving] = useState(false);

  const copy = async (text: string) => {
    if (!text) return;
    await Clipboard.setStringAsync(text);
    showToast(t("commission.promote.copied"), "success");
  };

  const share = async (url: string) => {
    if (!url) return;
    try {
      await Share.share({ message: url, url });
    } catch {}
  };

  const savePoster = async () => {
    if (!posterUrl) return;
    setSaving(true);
    try {
      // iOS: share sheet can receive remote URL. Android: share the link.
      // 用户长按图片也可以"保存到相册"（系统原生菜单），所以这条是分享辅助。
      await Share.share({ url: posterUrl, message: posterUrl });
    } catch {
      showToast(t("commission.promote.downloadFailed"), "error");
    } finally {
      setSaving(false);
    }
  };

  if (!uid) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("commission.promote.title")} />
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      </View>
    );
  }

  const steps = [
    t("commission.promote.step1"),
    t("commission.promote.step2"),
    t("commission.promote.step3"),
  ];

  const inputStyle = {
    padding: s(14),
    borderRadius: s(12),
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.neutral[200],
    color: Colors.neutral[800],
    fontSize: s(14),
  } as const;

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("commission.promote.title")} />
      <ScrollView
        className="flex-1"
        contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }}
        showsVerticalScrollIndicator={false}
      >
        {/* Short link — primary CTA */}
        <View
          className="rounded-2xl p-5 mb-4"
          style={{ }}
        >
          <LinearGradient pointerEvents="none" colors={[TealGradient.light, TealGradient.base, TealGradient.dark]} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 16, shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6 }} />
          <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.28)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: 16 }} />
          <Text className="text-white/90 text-xs mb-1">
            {t("commission.promote.shortLink")}
          </Text>
          <Text
            className="text-white font-bold mb-3"
            style={{ fontSize: s(18) }}
            numberOfLines={1}
          >
            {shortLink}
          </Text>
          <Text className="text-white/80 text-xs mb-3">
            {t("commission.promote.shortLinkTip")}
          </Text>
          <View className="flex-row gap-2">
            <Pressable
              onPress={() => copy(shortLink)}
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: s(11),
                borderRadius: s(10),
                backgroundColor: "rgba(255,255,255,0.25)",
              }}
            >
              <Copy size={s(15)} color="#fff" />
              <Text className="ml-1 text-sm font-medium text-white">
                {t("commission.promote.copyLink")}
              </Text>
            </Pressable>
            <Pressable
              onPress={() => share(shortLink)}
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
                paddingVertical: s(11),
                borderRadius: s(10),
                backgroundColor: "#fff",
              }}
            >
              <Share2 size={s(15)} color={Colors.brand.red} />
              <Text
                className="ml-1 text-sm font-semibold"
                style={{ color: Colors.brand.red }}
              >
                {t("commission.promote.share")}
              </Text>
            </Pressable>
          </View>
        </View>

        {/* QR code */}
        <View className="bg-white rounded-2xl p-6 mb-4 items-center border border-gray-100">
          <View className="flex-row items-center mb-4">
            <QrCode size={s(18)} color={Colors.brand.red} />
            <Text
              className="ml-2 font-semibold"
              style={{ color: Colors.neutral[800], fontSize: s(15) }}
            >
              {t("commission.promote.qrCode")}
            </Text>
          </View>
          <View
            style={{
              padding: s(12),
              borderRadius: s(16),
              backgroundColor: "#fff",
              borderWidth: 1,
              borderColor: Colors.neutral[200],
            }}
          >
            <Image
              source={{ uri: qrUrl }}
              style={{ width: s(200), height: s(200) }}
              resizeMode="contain"
            />
          </View>
          <Text
            className="text-xs mt-3 text-center"
            style={{ color: Colors.neutral[500] }}
          >
            {t("commission.promote.qrCaption")}
          </Text>
        </View>

        {/* Poster preview + save */}
        <View className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
          <View className="flex-row items-center mb-3">
            <ImageIcon size={s(18)} color={Colors.accent.orange} />
            <Text
              className="ml-2 font-semibold flex-1"
              style={{ color: Colors.neutral[800], fontSize: s(15) }}
            >
              {t("commission.promote.poster")}
            </Text>
          </View>
          <View
            style={{
              borderRadius: s(12),
              overflow: "hidden",
              backgroundColor: Colors.neutral[100],
              alignItems: "center",
              paddingVertical: s(8),
            }}
          >
            <Image
              source={{ uri: posterUrl }}
              style={{ width: s(160), height: s(285) }}
              resizeMode="contain"
            />
          </View>
          <Text
            className="text-xs my-3 text-center"
            style={{ color: Colors.neutral[500] }}
          >
            {t("commission.promote.posterTip")}
          </Text>
          <Pressable
            onPress={savePoster}
            disabled={saving}
            style={{
              paddingVertical: s(11),
              borderRadius: s(10),
              backgroundColor: Colors.accent.orange,
              alignItems: "center",
            }}
          >
            {saving ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text className="text-sm font-semibold text-white">
                {t("commission.promote.savePoster")}
              </Text>
            )}
          </Pressable>
        </View>

        {/* Invite code */}
        <View className="bg-white rounded-2xl p-4 mb-3 border border-gray-100">
          <Text className="text-xs mb-1" style={{ color: Colors.neutral[500] }}>
            {t("commission.promote.myCode")}
          </Text>
          <View className="flex-row items-center justify-between">
            <Text
              className="font-bold"
              style={{ color: Colors.neutral[800], fontSize: s(20) }}
            >
              {inviteCode}
            </Text>
            <Pressable
              onPress={() => copy(inviteCode)}
              style={{
                flexDirection: "row",
                alignItems: "center",
                paddingVertical: s(8),
                paddingHorizontal: s(12),
                borderRadius: s(10),
                backgroundColor: `${Colors.brand.red}15`,
              }}
            >
              <Copy size={s(14)} color={Colors.brand.red} />
              <Text
                className="ml-1 text-sm font-medium"
                style={{ color: Colors.brand.red }}
              >
                {t("commission.promote.copyCode")}
              </Text>
            </Pressable>
          </View>
        </View>

        {/* Long link (collapsed, for completeness) */}
        <View className="bg-white rounded-2xl p-4 mb-4 border border-gray-100">
          <Text className="text-xs mb-1" style={{ color: Colors.neutral[500] }}>
            {t("commission.promote.inviteLink")}
          </Text>
          <Text
            className="text-xs mb-3"
            style={{ color: Colors.neutral[600] }}
            numberOfLines={2}
          >
            {longLink}
          </Text>
          <Pressable
            onPress={() => copy(longLink)}
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              paddingVertical: s(10),
              borderRadius: s(10),
              backgroundColor: Colors.neutral[100],
            }}
          >
            <Copy size={s(14)} color={Colors.neutral[700]} />
            <Text
              className="ml-1 text-sm font-medium"
              style={{ color: Colors.neutral[700] }}
            >
              {t("commission.promote.copyLink")}
            </Text>
          </Pressable>
        </View>

        {/* How it works */}
        <View className="bg-white rounded-2xl p-5 border border-gray-100">
          <Text
            className="font-semibold mb-3"
            style={{ color: Colors.neutral[800], fontSize: s(15) }}
          >
            {t("commission.promote.howItWorks")}
          </Text>
          {steps.map((text, i) => (
            <View key={i} className="flex-row items-start mb-2">
              <View
                className="w-6 h-6 rounded-full items-center justify-center mr-3 mt-0.5"
                style={{ backgroundColor: `${Colors.brand.red}15` }}
              >
                <Text
                  className="font-bold"
                  style={{ color: Colors.brand.red, fontSize: s(12) }}
                >
                  {i + 1}
                </Text>
              </View>
              <Text
                className="flex-1 text-sm"
                style={{ color: Colors.neutral[700], lineHeight: s(20) }}
              >
                {text}
              </Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}
