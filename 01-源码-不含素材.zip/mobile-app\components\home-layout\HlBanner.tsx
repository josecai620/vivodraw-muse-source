import React, { useEffect, useRef, useState } from "react";
import { Pressable, ScrollView, useWindowDimensions, View } from "react-native";
import { Colors, Shadows, s } from "@/constants/theme";
import { normalizeImageUrl } from "@/lib/utils";
import { CachedImage } from "@/components/shared";

interface BannerItem {
  img: string;
  link?: string;
}

interface HlBannerProps {
  props: {
    height?: number;
    autoplay?: boolean;
    interval?: number;
    items?: BannerItem[];
  };
  onLink: (link: string) => void;
}

export default function HlBanner({ props, onLink }: HlBannerProps) {
  const { width: screenWidth } = useWindowDimensions();
  const items = (props.items ?? []).filter((it) => !!it.img);
  const outerGap = s(16);
  const bannerWidth = Math.max(0, screenWidth - outerGap * 2);
  const height = Math.min(props.height || s(172), s(176));
  const autoplay = props.autoplay ?? true;
  const interval = Math.max(1500, props.interval ?? 3500);

  const [idx, setIdx] = useState(0);
  const [readyIndexes, setReadyIndexes] = useState<number[]>([0]);
  const scrollRef = useRef<ScrollView>(null);

  const ensureBannerReady = (index: number) => {
    setReadyIndexes((cur) => (cur.includes(index) ? cur : [...cur, index]));
  };

  useEffect(() => {
    setReadyIndexes([0]);
    setIdx(0);
  }, [items.length]);

  useEffect(() => {
    if (items.length <= 1) return;
    const next = (idx + 1) % items.length;
    const t = setTimeout(() => ensureBannerReady(next), 1200);
    return () => clearTimeout(t);
  }, [idx, items.length]);

  useEffect(() => {
    if (!autoplay || items.length <= 1) return;
    const t = setInterval(() => {
      setIdx((cur) => {
        const next = (cur + 1) % items.length;
        ensureBannerReady(next);
        scrollRef.current?.scrollTo({ x: next * bannerWidth, animated: true });
        return next;
      });
    }, interval);
    return () => clearInterval(t);
  }, [autoplay, bannerWidth, interval, items.length]);

  if (items.length === 0) return null;

  return (
    <View
      style={{
        position: "relative",
        marginHorizontal: outerGap,
        marginTop: s(10),
        borderRadius: s(22),
        overflow: "hidden",
        backgroundColor: Colors.screen.card,
        borderWidth: 1,
        borderColor: Colors.screen.hairline,
        ...Shadows.raised,
      }}
    >
      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScrollBeginDrag={() => {
          setReadyIndexes(items.map((_, i) => i));
        }}
        onMomentumScrollEnd={(e) => {
          const i = Math.round(e.nativeEvent.contentOffset.x / bannerWidth);
          ensureBannerReady(i);
          setIdx(i);
        }}
      >
        {items.map((it, i) => (
          <Pressable
            key={i}
            style={{ width: bannerWidth, height }}
            onPress={() => it.link && onLink(it.link)}
          >
            {readyIndexes.includes(i) ? (
              <CachedImage
                uri={normalizeImageUrl(it.img) || it.img}
                style={{ width: bannerWidth, height }}
                priority={i === 0 ? "high" : "low"}
              />
            ) : (
              <View style={{ width: bannerWidth, height, backgroundColor: "#F1F3F3" }} />
            )}
          </Pressable>
        ))}
      </ScrollView>
      {items.length > 1 && (
        <View className="absolute bottom-3 left-0 right-0 flex-row justify-center" style={{ gap: 6 }}>
          {items.map((_, i) => (
            <View
              key={i}
              className="rounded-full"
              style={{
                width: i === idx ? 20 : 6,
                height: 6,
                backgroundColor: i === idx ? Colors.primary.DEFAULT : "rgba(255,255,255,0.65)",
              }}
            />
          ))}
        </View>
      )}
    </View>
  );
}
