/**
 * 兼容层：为从 v3 移植的游戏化模块（reward_coin / game_wallet / point_purchase /
 * pearl / pet-world / community）提供与 v3 lib/api/http.ts 相同的
 * { ok, data, message, status } 不抛错契约。
 * 底层复用 v4 的同源 API_BASE_URL 与 zustand auth token。
 */
import { API_BASE_URL } from "@/constants/api";
import { useAuthStore } from "@/store/auth";

type ApiResponse<T> = {
  status?: number;
  msg?: string;
  data?: T;
};

export type ApiWriteResult<T> = {
  ok: boolean;
  data?: T;
  message?: string;
  status?: number;
};

const TIMEOUT = 15_000;

function readToken(): string {
  try {
    return useAuthStore.getState().token?.trim() || "";
  } catch {
    return "";
  }
}

function applyAuth(headers: Record<string, string>) {
  const token = readToken();
  if (token) {
    // CRMEB 部分旧接口同时识别两种拼写，保持与 v3 一致。
    headers["Authori-zation"] = `Bearer ${token}`;
    headers.Authorization = `Bearer ${token}`;
  }
}

function buildHeaders(hasBody: boolean, extra?: HeadersInit): HeadersInit {
  const headers: Record<string, string> = {
    Accept: "application/json",
    "X-Client": "mobile-app",
  };
  applyAuth(headers);
  if (hasBody) headers["Content-Type"] = "application/json";
  if (extra) {
    const src = new Headers(extra);
    src.forEach((value, key) => {
      headers[key] = value;
    });
  }
  return headers;
}

async function authRequest<T>(path: string, init: RequestInit): Promise<ApiWriteResult<T>> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT);
  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      ...init,
      headers: buildHeaders(!!init.body, init.headers),
      signal: controller.signal,
    });
    const payload = (await response.json()) as ApiResponse<T>;
    const status = typeof payload.status === "number" ? payload.status : response.status;
    if (!response.ok || (typeof payload.status === "number" && payload.status !== 200)) {
      return { ok: false, data: payload.data, message: payload.msg || `HTTP ${response.status}`, status };
    }
    return { ok: true, data: payload.data, message: payload.msg, status };
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : "Network error" };
  } finally {
    clearTimeout(timer);
  }
}

export function fetchAuthGet<T>(path: string): Promise<ApiWriteResult<T>> {
  return authRequest<T>(path, { method: "GET" });
}

export function fetchAuthPost<T>(
  path: string,
  body: Record<string, unknown> = {},
): Promise<ApiWriteResult<T>> {
  return authRequest<T>(path, { method: "POST", body: JSON.stringify(body) });
}

/** FormData 上传（不设置 Content-Type，交由浏览器生成 boundary） */
export async function fetchAuthFormData<T>(
  path: string,
  body: FormData,
): Promise<ApiWriteResult<T>> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT);
  const headers: Record<string, string> = { Accept: "application/json", "X-Client": "mobile-app" };
  applyAuth(headers);
  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      method: "POST",
      headers,
      body,
      signal: controller.signal,
    });
    const payload = (await response.json()) as ApiResponse<T>;
    const status = typeof payload.status === "number" ? payload.status : response.status;
    if (!response.ok || (typeof payload.status === "number" && payload.status !== 200)) {
      return { ok: false, data: payload.data, message: payload.msg || `HTTP ${response.status}`, status };
    }
    return { ok: true, data: payload.data, message: payload.msg, status };
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : "Network error" };
  } finally {
    clearTimeout(timer);
  }
}

/** 只读接口：失败一律返回 undefined（与 v3 契约一致） */
export async function fetchReadApi<T>(path: string): Promise<T | undefined> {
  const result = await authRequest<T>(path, { method: "GET" });
  return result.ok ? result.data : undefined;
}

export async function fetchReadApiPost<T>(
  path: string,
  body: Record<string, unknown> = {},
): Promise<T | undefined> {
  const result = await authRequest<T>(path, { method: "POST", body: JSON.stringify(body) });
  return result.ok ? result.data : undefined;
}

function getKnownAssetPath(image: string) {
  if (image.startsWith("/uploads/") || image.startsWith("/statics/")) {
    return image;
  }
  const match = image.match(
    /^https?:\/\/(?:8\.166\.115\.27|vivodraw\.com|www\.vivodraw\.com)(\/(?:uploads|statics)\/.+)$/i,
  );
  return match?.[1] || "";
}

export function normalizeRemoteImage(value?: unknown) {
  const image = String(value || "").trim();
  if (!image) return "";
  const known = getKnownAssetPath(image);
  if (known) return `${API_BASE_URL}${known}`;
  if (/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?\//i.test(image)) {
    return `${API_BASE_URL}/${image.replace(/^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?\/+/i, "")}`;
  }
  if (/^https?:\/\//i.test(image)) return image;
  if (image.startsWith("//")) return `https:${image}`;
  return `${API_BASE_URL}/${image.replace(/^\/+/, "")}`;
}
