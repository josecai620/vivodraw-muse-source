import React, { type PropsWithChildren } from "react";
import { View, type ViewStyle } from "react-native";
import { Colors, Shadows, s } from "@/constants/theme";

interface CardProps {
  shadow?: "sm" | "md" | "lg";
  className?: string;
  style?: ViewStyle;
}

// 方向C：纯白「硬块」浮卡 + 冷青墨柔投影，浮在浅冷灰页面底上
const CARD_SHADOW = {
  sm: Shadows.raisedSm,
  md: Shadows.raised,
  lg: Shadows.raisedLg,
} as const;

export default function Card({
  children,
  shadow = "sm",
  className = "",
  style,
}: PropsWithChildren<CardProps>) {
  return (
    <View
      className={`overflow-hidden ${className}`}
      style={[
        {
          backgroundColor: Colors.screen.card,
          borderRadius: s(18),
          borderWidth: 1,
          borderColor: Colors.screen.hairline,
        },
        CARD_SHADOW[shadow],
        style,
      ]}
    >
      {children}
    </View>
  );
}
