import { Colors, Shadows } from "@/constants/theme";
import { usePointsCartCount } from "@/hooks";
import { unwrapApiData } from "@/lib/api/response";
import type { PointsCartCount } from "@/lib/api/points";
import { openCloudBuyCartList } from "@/lib/points/openCloudBuyCart";
import { usePathname, useRouter } from "expo-router";
import { ChevronLeft, ClipboardList, Gift, Home, LayoutGrid, User } from "lucide-react-native";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { PanResponder, Platform, Pressable, Text, View, useWindowDimensions } from "react-native";
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { create } from "zustand";

type TabKey = "home" | "glist" | "reveal" | "cart" | "me";

const ACTIVE = Colors.primary.DEFAULT;
const INACTIVE = "#9AA09F";
const BADGE_RED = "#FF3B30";
const SPRING = { damping: 20, stiffness: 240, mass: 0.85 };

/** 积分夺宝底栏收起状态：同一次浏览里各云购页共用 */
const usePointsTabDock = create<{ collapsed: boolean; setCollapsed: (v: boolean) => void }>((set) => ({
  collapsed: false,
  setCollapsed: (collapsed) => set({ collapsed }),
}));

export function PointsMallTabBar() {
  const { t } = useTranslation();
  const router = useRouter();
  const pathname = usePathname() || "";
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const uiScale = Math.min(Math.max(width / 390, 1), 1.16);
  const { data: cartCountData } = usePointsCartCount();
  const cartCount = Number(unwrapApiData<PointsCartCount>(cartCountData, {}).count ?? 0) || 0;
  const collapsed = usePointsTabDock((s) => s.collapsed);
  const setCollapsed = usePointsTabDock((s) => s.setCollapsed);
  const collapsedRef = useRef(collapsed);
  collapsedRef.current = collapsed;
  /** 只挡刚结束的那一次滑动，用时间戳，避免标志位卡住后栏目永远点不了 */
  const ignorePressUntil = useRef(0);
  const pointer = useRef({ down: false, x: 0, y: 0, dragging: false });
  const [pressGen, setPressGen] = useState(0);

  const active: TabKey = useMemo(() => {
    if (pathname.includes("/points/glist") || pathname.includes("/points/categories")) return "glist";
    if (pathname.includes("/reveal") || pathname.includes("/points/lottery")) return "reveal";
    if (pathname.includes("/points/cart")) return "cart";
    if (pathname.includes("/points/me") || pathname.includes("/points/redemptions")) return "me";
    return "home";
  }, [pathname]);

  const tabs: Array<{
    key: TabKey;
    label: string;
    Icon: typeof Home;
    href: string;
  }> = [
    { key: "home", label: t("pointsMall.tabHome"), Icon: Home, href: "/(tabs)/points" },
    { key: "glist", label: t("pointsMall.tabAllPeriods"), Icon: LayoutGrid, href: "/points/glist" },
    { key: "reveal", label: t("pointsMall.tabReveal"), Icon: Gift, href: "/reveal" },
    { key: "cart", label: t("pointsMall.tabCart"), Icon: ClipboardList, href: "/points/cart" },
    { key: "me", label: t("pointsMall.tabMe"), Icon: User, href: "/points/me" },
  ];

  const bottom = Platform.OS === "web" ? 12 : Math.max(insets.bottom, Math.round(10 * uiScale));
  const sideGap = Math.round(14 * uiScale);
  const handleW = Math.round(34 * uiScale);
  const handleH = Math.round(52 * uiScale);
  const hiddenX = width + 8;
  const hiddenRef = useRef(hiddenX);
  hiddenRef.current = hiddenX;
  const hiddenXSv = useSharedValue(hiddenX);
  const tx = useSharedValue(collapsed ? hiddenX : 0);

  useEffect(() => {
    hiddenXSv.value = hiddenX;
    if (collapsedRef.current) tx.value = hiddenX;
  }, [hiddenX, hiddenXSv, tx]);

  const resetPointer = () => {
    pointer.current = { down: false, x: 0, y: 0, dragging: false };
  };

  const snap = (next: boolean) => {
    resetPointer();
    if (next) ignorePressUntil.current = Date.now() + 120;
    else {
      ignorePressUntil.current = 0;
      setPressGen((n) => n + 1);
    }
    tx.value = withSpring(next ? hiddenRef.current : 0, SPRING);
    setCollapsed(next);
  };

  const goTab = (tab: { key: TabKey; href: string }) => {
    if (collapsedRef.current) return;
    if (Date.now() < ignorePressUntil.current) return;
    ignorePressUntil.current = Date.now() + 240;
    if (tab.key === "cart") openCloudBuyCartList(router);
    else router.push(tab.href as never);
  };

  const endBarSwipe = (dx: number, vx = 0) => {
    ignorePressUntil.current = Date.now() + 240;
    const hide = Math.abs(dx) > 48 || Math.abs(vx) > 0.55;
    if (!hide) {
      snap(false);
    } else if (dx < 0) {
      resetPointer();
      ignorePressUntil.current = Date.now() + 120;
      tx.value = withSpring(-hiddenRef.current, SPRING, (finished) => {
        if (finished) tx.value = hiddenRef.current;
      });
      setCollapsed(true);
    } else {
      snap(true);
    }
  };

  const barPan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => false,
      onStartShouldSetPanResponderCapture: () => false,
      onMoveShouldSetPanResponder: (_, g) =>
        !collapsedRef.current && Math.abs(g.dx) > 24 && Math.abs(g.dx) > Math.abs(g.dy) * 1.4,
      onMoveShouldSetPanResponderCapture: () => false,
      onPanResponderTerminationRequest: () => true,
      onShouldBlockNativeResponder: () => false,
      onPanResponderMove: (_, g) => {
        pointer.current.dragging = true;
        tx.value = g.dx;
      },
      onPanResponderRelease: (_, g) => {
        endBarSwipe(g.dx, g.vx);
      },
      onPanResponderTerminate: (_, g) => {
        endBarSwipe(g.dx, g.vx);
      },
    }),
  ).current;

  const pageX = (e: any) => Number(e?.nativeEvent?.pageX ?? e?.nativeEvent?.clientX ?? 0);
  const pageY = (e: any) => Number(e?.nativeEvent?.pageY ?? e?.nativeEvent?.clientY ?? 0);

  const webBarProps =
    Platform.OS === "web"
      ? {
          onPointerDown: (e: any) => {
            pointer.current = { down: true, x: pageX(e), y: pageY(e), dragging: false };
          },
          onPointerMove: (e: any) => {
            if (!pointer.current.down || collapsedRef.current) return;
            const dx = pageX(e) - pointer.current.x;
            const dy = pageY(e) - pointer.current.y;
            if (!pointer.current.dragging) {
              if (Math.abs(dx) < 24 || Math.abs(dx) <= Math.abs(dy) * 1.4) return;
              pointer.current.dragging = true;
            }
            tx.value = dx;
          },
          onPointerUp: (e: any) => {
            if (!pointer.current.down) return;
            const dx = pageX(e) - pointer.current.x;
            const wasDragging = pointer.current.dragging;
            resetPointer();
            if (wasDragging) endBarSwipe(dx);
          },
          onPointerCancel: () => {
            const wasDragging = pointer.current.dragging;
            resetPointer();
            if (wasDragging) snap(collapsedRef.current);
          },
        }
      : {};

  const webHandleProps =
    Platform.OS === "web"
      ? {
          onPointerDown: (e: any) => {
            pointer.current = { down: true, x: pageX(e), y: pageY(e), dragging: false };
          },
          onPointerMove: (e: any) => {
            if (!pointer.current.down || !collapsedRef.current) return;
            const dx = pageX(e) - pointer.current.x;
            const dy = pageY(e) - pointer.current.y;
            if (!pointer.current.dragging) {
              if (Math.abs(dx) < 8 || Math.abs(dx) <= Math.abs(dy)) return;
              pointer.current.dragging = true;
            }
            tx.value = Math.min(hiddenRef.current, Math.max(0, hiddenRef.current + dx));
          },
          onPointerUp: (e: any) => {
            if (!pointer.current.down) return;
            const dx = pageX(e) - pointer.current.x;
            const wasDragging = pointer.current.dragging;
            resetPointer();
            if (wasDragging) snap(!(dx < -40));
          },
          onPointerCancel: () => {
            const wasDragging = pointer.current.dragging;
            resetPointer();
            if (wasDragging) snap(collapsedRef.current);
          },
        }
      : {};

  const handlePan = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => false,
      onMoveShouldSetPanResponder: (_, g) =>
        collapsedRef.current && Math.abs(g.dx) > 8 && Math.abs(g.dx) > Math.abs(g.dy),
      onPanResponderMove: (_, g) => {
        tx.value = Math.min(hiddenRef.current, Math.max(0, hiddenRef.current + g.dx));
      },
      onPanResponderRelease: (_, g) => {
        snap(!(g.dx < -40 || g.vx < -0.45));
      },
      onPanResponderTerminate: (_, g) => {
        snap(!(g.dx < -40));
      },
    }),
  ).current;

  const barAnim = useAnimatedStyle(() => ({
    transform: [{ translateX: tx.value }],
  }));

  const handleAnim = useAnimatedStyle(() => {
    const p = Math.min(1, Math.abs(tx.value) / Math.max(1, hiddenXSv.value));
    return {
      opacity: p,
      transform: [{ translateX: (1 - p) * handleW }],
    };
  });

  return (
    <View
      pointerEvents="box-none"
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        bottom,
        zIndex: 50,
        height: Math.round(62 * uiScale),
      }}
    >
      <Animated.View
        {...(Platform.OS === "web" ? webBarProps : barPan.panHandlers)}
        pointerEvents={collapsed ? "none" : "auto"}
        style={[
          {
            position: "absolute",
            left: sideGap,
            right: sideGap,
            top: 0,
            height: Math.round(62 * uiScale),
            borderRadius: Math.round(24 * uiScale),
            backgroundColor: "#FFFFFF",
            borderWidth: 1,
            borderColor: Colors.screen.hairline,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-around",
            paddingHorizontal: 4,
            overflow: "visible",
            ...Shadows.floatingTab,
          },
          barAnim,
        ]}
      >
        {tabs.map((tab) => {
          const focused = active === tab.key;
          const Icon = tab.Icon;
          const showBadge = tab.key === "cart" && cartCount > 0;
          return (
            <Pressable
              key={`${tab.key}-${pressGen}`}
              accessibilityRole="button"
              accessibilityLabel={tab.label}
              onPress={() => goTab(tab)}
              {...(Platform.OS === "web"
                ? {
                    onClick: (e: any) => {
                      e?.preventDefault?.();
                      goTab(tab);
                    },
                  }
                : {})}
              style={{ flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 6, zIndex: 2 }}
            >
              <View style={{ width: 28, height: 22, alignItems: "center", justifyContent: "center", overflow: "visible" }}>
                <Icon size={20} color={focused ? ACTIVE : "#5E5F5E"} strokeWidth={focused ? 2.2 : 1.8} />
                {showBadge ? (
                  <View
                    style={{
                      position: "absolute",
                      top: -7,
                      right: -9,
                      minWidth: 18,
                      height: 18,
                      borderRadius: 9,
                      backgroundColor: BADGE_RED,
                      borderWidth: 1.5,
                      borderColor: "#fff",
                      alignItems: "center",
                      justifyContent: "center",
                      paddingHorizontal: 4,
                      zIndex: 6,
                    }}
                  >
                    <Text style={{ color: "#fff", fontSize: 10, fontWeight: "800" }}>
                      {cartCount > 99 ? "99+" : cartCount}
                    </Text>
                  </View>
                ) : null}
              </View>
              <View
                style={{
                  width: 16,
                  height: 3,
                  borderRadius: 2,
                  marginTop: 3,
                  backgroundColor: focused ? ACTIVE : "transparent",
                }}
              />
              <Text
                numberOfLines={1}
                style={{
                  marginTop: 2,
                  fontSize: 9,
                  fontWeight: focused ? "800" : "600",
                  color: focused ? ACTIVE : INACTIVE,
                }}
              >
                {tab.label.replace(/ /g, "\u00A0")}
              </Text>
            </Pressable>
          );
        })}
      </Animated.View>

      <Animated.View
        {...(Platform.OS === "web" ? webHandleProps : handlePan.panHandlers)}
        pointerEvents={collapsed ? "auto" : "none"}
        style={[
          {
            position: "absolute",
            right: 0,
            top: Math.round((62 * uiScale - handleH) / 2),
            width: handleW,
            height: handleH,
            borderTopLeftRadius: Math.round(18 * uiScale),
            borderBottomLeftRadius: Math.round(18 * uiScale),
            borderTopRightRadius: 0,
            borderBottomRightRadius: 0,
            backgroundColor: "#FFFFFF",
            borderWidth: 1,
            borderRightWidth: 0,
            borderColor: Colors.screen.hairline,
            alignItems: "center",
            justifyContent: "center",
            zIndex: collapsed ? 6 : 0,
            ...Shadows.floatingTab,
          },
          handleAnim,
        ]}
      >
        <Pressable
          onPress={() => {
            if (!collapsedRef.current) return;
            snap(false);
          }}
          hitSlop={8}
          style={{ flex: 1, width: "100%", alignItems: "center", justifyContent: "center" }}
          accessibilityRole="button"
          accessibilityLabel="Expand tab bar"
        >
          <ChevronLeft size={20} color="#5E5F5E" strokeWidth={2.4} />
        </Pressable>
      </Animated.View>
    </View>
  );
}

export function pointsMallTabPaddingBottom(insetsBottom = 0) {
  return Math.max(insetsBottom, 12) + 78;
}
