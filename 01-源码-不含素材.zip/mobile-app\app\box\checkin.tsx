/**
 * 每日签到 + 每日任务（Premium Dark Gaming UI）
 */
import React from "react";
import { View, Text, ScrollView, Pressable, ActivityIndicator } from "react-native";
import { useTranslation } from "react-i18next";
import { LinearGradient } from "expo-linear-gradient";
import {
  Calendar, Gift, CheckCircle,
  Package, Eye, Repeat, Star, Trophy, Target,
} from "lucide-react-native";
import { BoxHeader, BoxActionButton, BoxProgressBar } from "@/components/box";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders, BoxGradients,
  BoxTypography, BoxSpacing, BoxRadius, BoxShadows, bs,
} from "@/lib/boxTheme";
import { usePointsBalance } from "@/hooks/usePoints";
import { useCheckinInfo, useCheckin, useCheckinTasks, useClaimCheckinTask } from "@/hooks";

const TASK_ICONS: Record<string, typeof Package> = {
  open1: Package,
  browse3: Eye,
  open3: Repeat,
  share1: Star,
  open10: Trophy,
};

export default function CheckinPage() {
  const { t } = useTranslation();
  const { data: balanceData } = usePointsBalance();
  const userPoints = (balanceData as any)?.data?.integral ?? (balanceData as any)?.integral ?? 0;

  const { data: checkinInfo, isLoading: loadingInfo } = useCheckinInfo();
  const checkinMutation = useCheckin();
  const { data: tasks, isLoading: loadingTasks } = useCheckinTasks();
  const claimMutation = useClaimCheckinTask();

  const streak = (checkinInfo as any)?.streak ?? 0;
  const totalDays = (checkinInfo as any)?.totalDays ?? 0;
  const todayChecked = (checkinInfo as any)?.todayChecked ?? false;
  const rewards: any[] = (checkinInfo as any)?.rewards ?? [
    { day: 1, points: 10 },
    { day: 2, points: 15 },
    { day: 3, points: 20 },
    { day: 4, points: 30 },
    { day: 5, points: 40 },
    { day: 6, points: 50 },
    { day: 7, points: 100, special: true },
  ];

  const currentDayInWeek = todayChecked ? ((streak - 1) % 7) + 1 : (streak % 7) + 1;
  const todayReward = rewards.find((r: any) => r.day === currentDayInWeek);

  const taskList: any[] = Array.isArray(tasks) ? tasks : [];
  const completedTasks = taskList.filter((t: any) => t.completed).length;
  const totalTaskReward = taskList.reduce((s: number, t: any) => s + (t.reward || 0), 0);
  const earnedTaskReward = taskList.filter((t: any) => t.completed).reduce((s: number, t: any) => s + (t.reward || 0), 0);

  if (loadingInfo) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: BoxSurfaces.void }}>
        <ActivityIndicator size="large" color={BoxAccent.gold} />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("checkin.title")} points={userPoints} />

      <ScrollView style={{ flex: 1 }} showsVerticalScrollIndicator={false}>
        <View style={{ padding: BoxSpacing.lg, paddingBottom: bs(100) }}>
          {/* Gold gradient stats card */}
          <LinearGradient
            colors={BoxGradients.goldWarm}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={{
              borderRadius: BoxRadius["2xl"],
              padding: BoxSpacing.xl,
              marginBottom: BoxSpacing["2xl"],
              borderWidth: 1,
              borderColor: BoxAccent.goldBorder,
              ...BoxShadows.glow(BoxAccent.gold),
            }}
          >
            <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: BoxSpacing.lg }}>
              <View>
                <Text style={[BoxTypography.caption, { color: BoxText.secondary }]}>
                  {t("checkin.streak")}
                </Text>
                <View style={{ flexDirection: "row", alignItems: "baseline" }}>
                  <Text style={[BoxTypography.hero, { color: BoxAccent.gold }]}>{streak}</Text>
                  <Text style={[BoxTypography.caption, { color: BoxAccent.gold, marginLeft: BoxSpacing.xs }]}>
                    {t("checkin.days")}
                  </Text>
                </View>
              </View>
              <View style={{ alignItems: "flex-end" }}>
                <Text style={[BoxTypography.caption, { color: BoxText.secondary }]}>
                  {t("checkin.total")}
                </Text>
                <Text style={[BoxTypography.h2, { color: BoxText.primary }]}>
                  {totalDays} {t("checkin.days")}
                </Text>
              </View>
            </View>

            {/* 7-day calendar row */}
            <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: BoxSpacing.lg }}>
              {rewards.map((reward: any) => {
                const isPast = reward.day < currentDayInWeek;
                const isToday = reward.day === currentDayInWeek;
                const checked = isPast || (isToday && todayChecked);
                return (
                  <View key={reward.day} style={{ alignItems: "center", width: bs(42) }}>
                    <View
                      style={{
                        width: bs(40),
                        height: bs(40),
                        borderRadius: BoxRadius.full,
                        alignItems: "center",
                        justifyContent: "center",
                        marginBottom: BoxSpacing.xs,
                        backgroundColor: checked
                          ? BoxAccent.gold
                          : isToday
                            ? BoxAccent.goldMuted
                            : BoxSurfaces.elevated,
                        borderWidth: isToday && !checked ? 2 : 0,
                        borderColor: BoxAccent.gold,
                      }}
                    >
                      {checked ? (
                        <CheckCircle size={bs(18)} color={BoxText.onGold} />
                      ) : reward.special ? (
                        <Gift size={bs(18)} color={isToday ? BoxAccent.gold : BoxText.tertiary} />
                      ) : (
                        <Text style={[BoxTypography.micro, { color: isToday ? BoxAccent.gold : BoxText.tertiary }]}>
                          +{reward.points}
                        </Text>
                      )}
                    </View>
                    <Text style={[BoxTypography.micro, { color: isToday ? BoxAccent.gold : BoxText.tertiary }]}>
                      {reward.label ?? t("checkin.day", { n: reward.day })}
                    </Text>
                  </View>
                );
              })}
            </View>

            {/* Check-in button */}
            <BoxActionButton
              title={
                todayChecked
                  ? t("checkin.todayChecked")
                  : t("checkin.claimPoints", { pts: todayReward?.points || 10 })
              }
              variant={todayChecked ? "secondary" : "primary"}
              icon={<Calendar size={bs(18)} color={todayChecked ? BoxText.tertiary : BoxText.onGold} />}
              loading={checkinMutation.isPending}
              disabled={todayChecked}
              onPress={() => checkinMutation.mutate(undefined as any)}
            />
          </LinearGradient>

          {/* Daily tasks header */}
          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: BoxSpacing.md }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.sm }}>
              <Target size={bs(20)} color={BoxAccent.gold} />
              <Text style={[BoxTypography.h3, { color: BoxText.primary }]}>
                {t("checkin.dailyTasks")}
              </Text>
            </View>
            <Text style={[BoxTypography.micro, { color: BoxText.secondary }]}>
              {t("checkin.taskProgress", { done: completedTasks, total: taskList.length, earned: earnedTaskReward, max: totalTaskReward })}
            </Text>
          </View>

          <BoxProgressBar
            progress={taskList.length > 0 ? (completedTasks / taskList.length) * 100 : 0}
            color={BoxAccent.gold}
            size="compact"
            glow
            style={{ marginBottom: BoxSpacing.lg }}
          />

          {loadingTasks ? (
            <ActivityIndicator color={BoxAccent.gold} />
          ) : (
            taskList.map((task: any) => {
              const Icon = TASK_ICONS[task.id] || Package;
              const canClaim = task.progress >= task.target && !task.completed;
              return (
                <View
                  key={task.id}
                  style={{
                    borderRadius: BoxRadius.xl,
                    padding: BoxSpacing.lg,
                    marginBottom: BoxSpacing.md,
                    flexDirection: "row",
                    alignItems: "center",
                    gap: BoxSpacing.md,
                    backgroundColor: BoxSurfaces.card,
                    borderWidth: 1,
                    borderColor: task.completed ? BoxAccent.goldBorder : BoxBorders.default,
                    opacity: task.completed ? 0.7 : 1,
                  }}
                >
                  <View
                    style={{
                      width: bs(40),
                      height: bs(40),
                      borderRadius: BoxRadius.md,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: task.completed ? BoxAccent.goldMuted : BoxSurfaces.elevated,
                    }}
                  >
                    <Icon size={bs(18)} color={task.completed ? BoxAccent.gold : BoxText.tertiary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[BoxTypography.bodyBold, { color: BoxText.primary }]}>
                      {t(`checkin.tasks.${task.id}.title`, { defaultValue: task.title })}
                    </Text>
                    <Text style={[BoxTypography.caption, { color: BoxText.secondary, marginTop: 2 }]}>
                      {t(`checkin.tasks.${task.id}.desc`, { defaultValue: task.desc })}
                    </Text>
                    <BoxProgressBar
                      progress={Math.min(100, (task.progress / task.target) * 100)}
                      color={task.completed ? BoxAccent.gold : BoxAccent.purple}
                      size="compact"
                      style={{ marginTop: BoxSpacing.sm }}
                    />
                  </View>
                  <View style={{ alignItems: "flex-end" }}>
                    <Text style={[BoxTypography.caption, { color: BoxAccent.gold, marginBottom: BoxSpacing.xs }]}>
                      +{task.reward}
                    </Text>
                    {task.completed ? (
                      <View style={{
                        paddingHorizontal: BoxSpacing.md,
                        paddingVertical: BoxSpacing.xs,
                        borderRadius: BoxRadius.full,
                        backgroundColor: BoxAccent.goldMuted,
                      }}>
                        <Text style={[BoxTypography.micro, { color: BoxAccent.gold }]}>
                          {t("checkin.completed")}
                        </Text>
                      </View>
                    ) : canClaim ? (
                      <Pressable
                        onPress={() => claimMutation.mutate({ task_id: task.id })}
                        disabled={claimMutation.isPending}
                        style={{
                          paddingHorizontal: BoxSpacing.md,
                          paddingVertical: BoxSpacing.xs,
                          borderRadius: BoxRadius.full,
                          backgroundColor: BoxAccent.gold,
                        }}
                      >
                        <Text style={[BoxTypography.micro, { color: BoxText.onGold }]}>
                          {claimMutation.isPending ? t("common.loading") : t("checkin.claim")}
                        </Text>
                      </Pressable>
                    ) : (
                      <Text style={[BoxTypography.micro, { color: BoxText.tertiary }]}>
                        {task.progress}/{task.target}
                      </Text>
                    )}
                  </View>
                </View>
              );
            })
          )}
        </View>
      </ScrollView>
    </View>
  );
}
