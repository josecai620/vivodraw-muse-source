import React, { useState } from "react";
import { View, Text, Image, ScrollView, Pressable, ActivityIndicator, Alert } from "react-native";
import { useLocalSearchParams, useRouter, Stack } from "expo-router";
import { useTranslation } from "react-i18next";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";
import { useGroupLotteryDetail, useCreatePink } from "@/hooks/useGroupLottery";
import type { PinkInfo } from "@/lib/api/groupLottery";
import { useAuthStore } from "@/store/auth";

function PriceTag({ price, priceType }: { price: number; priceType: number }) {
  const { t } = useTranslation();
  return (
    <Text style={{ color: "#04A8AE", fontSize: s(22), fontWeight: "bold" }}>
      {priceType === 1 ? `${price} ${t("common.pts")}` : `$${price}`}
    </Text>
  );
}

function PinkCard({ pink, onPress }: { pink: any; onPress: () => void }) {
  const { t } = useTranslation();
  const remain = pink.people_count - pink.current_count;
  const mins = Math.floor(pink.remain_seconds / 60);
  const hrs = Math.floor(mins / 60);
  const timeStr = hrs > 0 ? `${hrs}h${mins % 60}m` : `${mins}m`;
  return (
    <Pressable
      onPress={onPress}
      style={{
        backgroundColor: "#fff",
        borderRadius: s(10),
        padding: s(10),
        marginBottom: s(8),
        flexDirection: "row",
        alignItems: "center",
        borderWidth: 1,
        borderColor: "#f5f5f5",
      }}
    >
      <View style={{ flexDirection: "row", flex: 1 }}>
        {pink.members?.slice(0, 5).map((m: any, i: number) => (
          <Image
            key={i}
            source={{ uri: m.avatar || "https://api.dicebear.com/7.x/avataaars/png?seed=default" }}
            style={{ width: s(28), height: s(28), borderRadius: s(14), marginLeft: i > 0 ? -s(6) : 0, borderWidth: 1, borderColor: "#fff" }}
          />
        ))}
      </View>
      <View style={{ alignItems: "flex-end" }}>
        <Text style={{ fontSize: s(11), color: Colors.neutral[500] }}>
          {t("groupLottery.needMore", { count: remain, time: timeStr })}
        </Text>
        <View style={{ backgroundColor: "#04A8AE", paddingHorizontal: s(12), paddingVertical: s(4), borderRadius: s(12), marginTop: s(4) }}>
          <Text style={{ color: "#fff", fontSize: s(12), fontWeight: "600" }}>{t("groupLottery.joinBtn")}</Text>
        </View>
      </View>
    </Pressable>
  );
}

export default function GroupLotteryDetailScreen() {
  const { t } = useTranslation();
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const { data, isLoading } = useGroupLotteryDetail(Number(id));
  const createPinkMut = useCreatePink();
  const [selectedPeople, setSelectedPeople] = useState(0);

  const info = data?.data?.info;
  const activePinks = data?.data?.active_pinks ?? [];

  if (isLoading || !info) {
    return (
      <View className="flex-1 bg-gray-50 items-center justify-center">
        <Stack.Screen options={{ headerShown: false }} />
        <ActivityIndicator size="large" color="#04A8AE" />
      </View>
    );
  }

  const peopleOpts = (info.people_options || "3,5,10").split(",").map(Number);
  const selected = selectedPeople || peopleOpts[0];

  const handleCreate = () => {
    if (!isLoggedIn) {
      Alert.alert(t("groupLottery.loginRequired"), t("groupLottery.loginToBuy"), [
        { text: t("common.cancel") },
        { text: t("groupLottery.goLogin"), onPress: () => router.push("/auth") },
      ]);
      return;
    }
    const priceStr = info.price_type === 1
      ? `${info.price} ${t("common.pts")}`
      : `$${info.price}`;
    Alert.alert(
      t("groupLottery.confirmCreate"),
      t("groupLottery.confirmCreateMsg", { price: priceStr, count: selected }),
      [
        { text: t("common.cancel") },
        {
          text: t("groupLottery.confirmCreate"),
          onPress: () => {
            createPinkMut.mutate(
              { lottery_id: info.id, people_count: selected },
              {
                onSuccess: (res: any) => {
                  const pinkId = res?.data?.pink_id ?? res?.pink_id;
                  if (pinkId) router.push(`/group-lottery/pink/${pinkId}`);
                },
              }
            );
          },
        },
      ]
    );
  };

  return (
    <View className="flex-1 bg-gray-50">
      <Stack.Screen options={{ headerShown: false }} />
      <PageHeader title={t("groupLottery.productDetail")} />
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        <Image source={{ uri: info.image }} style={{ width: "100%", height: s(300) }} resizeMode="cover" />

        <View style={{ padding: s(14), backgroundColor: "#fff" }}>
          <PriceTag price={info.price} priceType={info.price_type} />
          <Text style={{ fontSize: s(16), fontWeight: "600", color: Colors.neutral[800], marginTop: s(6) }}>
            {info.title}
          </Text>
          <Text style={{ fontSize: s(12), color: Colors.neutral[500], marginTop: s(4) }}>{info.info}</Text>

          <View style={{ flexDirection: "row", marginTop: s(10), gap: s(6) }}>
            <View style={{ backgroundColor: "#ECFBFB", paddingHorizontal: s(8), paddingVertical: s(3), borderRadius: s(4) }}>
              <Text style={{ fontSize: s(11), color: "#04A8AE" }}>
                {t("groupLottery.bonusRefund", { rate: info.bonus_rate })}
              </Text>
            </View>
            <View style={{ backgroundColor: "#F7F8F8", paddingHorizontal: s(8), paddingVertical: s(3), borderRadius: s(4) }}>
              <Text style={{ fontSize: s(11), color: "#04A8AE" }}>
                {info.price_type === 1 ? t("groupLottery.ptsPayment") : t("groupLottery.usdPayment")}
              </Text>
            </View>
          </View>
        </View>

        {/* Select group size */}
        <View style={{ margin: s(12), backgroundColor: "#fff", borderRadius: s(10), padding: s(14) }}>
          <Text style={{ fontSize: s(13), fontWeight: "600", color: Colors.neutral[700], marginBottom: s(8) }}>
            {t("groupLottery.selectPeople")}
          </Text>
          <View style={{ flexDirection: "row", gap: s(8) }}>
            {peopleOpts.map((n) => (
              <Pressable
                key={n}
                onPress={() => setSelectedPeople(n)}
                style={{
                  flex: 1,
                  paddingVertical: s(10),
                  borderRadius: s(8),
                  alignItems: "center",
                  backgroundColor: selected === n ? "#04A8AE" : "#f5f5f5",
                }}
              >
                <Text style={{ fontSize: s(16), fontWeight: "bold", color: selected === n ? "#fff" : Colors.neutral[700] }}>
                  {n}
                </Text>
                <Text style={{ fontSize: s(10), color: selected === n ? "#F3F5F3" : Colors.neutral[500], marginTop: s(2) }}>
                  {t("groupLottery.pplGroup")}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        {/* Active groups */}
        {activePinks.length > 0 && (
          <View style={{ marginHorizontal: s(12), marginBottom: s(12) }}>
            <Text style={{ fontSize: s(13), fontWeight: "600", color: Colors.neutral[700], marginBottom: s(8) }}>
              {t("groupLottery.activeGroups", { count: activePinks.length })}
            </Text>
            {activePinks.map((p: any) => (
              <PinkCard
                key={p.id}
                pink={p}
                onPress={() => router.push(`/group-lottery/pink/${p.id}`)}
              />
            ))}
          </View>
        )}

        {/* Rules */}
        <View style={{ marginHorizontal: s(12), marginBottom: s(100), backgroundColor: "#fff", borderRadius: s(10), padding: s(14) }}>
          <Text style={{ fontSize: s(13), fontWeight: "600", color: Colors.neutral[700], marginBottom: s(8) }}>
            {t("groupLottery.rules")}
          </Text>
          {[
            t("groupLottery.rule1"),
            t("groupLottery.rule2"),
            t("groupLottery.rule3"),
            t("groupLottery.rule4", { rate: info.bonus_rate }),
            t("groupLottery.rule5", { hours: info.effective_hours }),
            t("groupLottery.rule6"),
          ].map((rule, i) => (
            <Text key={i} style={{ fontSize: s(12), color: Colors.neutral[500], lineHeight: s(20) }}>
              {rule}
            </Text>
          ))}
        </View>
      </ScrollView>

      {/* Bottom actions */}
      <View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: "#fff",
          borderTopWidth: 1,
          borderTopColor: "#f0f0f0",
          padding: s(12),
          paddingBottom: s(28),
          flexDirection: "row",
          gap: s(10),
        }}
      >
        <Pressable
          onPress={() => router.push("/group-lottery/my")}
          style={{ paddingVertical: s(12), paddingHorizontal: s(16), borderRadius: s(10), backgroundColor: "#f5f5f5" }}
        >
          <Text style={{ fontSize: s(13), color: Colors.neutral[600] }}>{t("groupLottery.myGroups")}</Text>
        </Pressable>
        <Pressable
          onPress={handleCreate}
          disabled={createPinkMut.isPending}
          style={{
            flex: 1,
            paddingVertical: s(12),
            borderRadius: s(10),
            backgroundColor: createPinkMut.isPending ? "#078E93" : "#04A8AE",
            alignItems: "center",
          }}
        >
          <Text style={{ color: "#fff", fontSize: s(15), fontWeight: "bold" }}>
            {createPinkMut.isPending
              ? t("groupLottery.creating")
              : t("groupLottery.createBtn", { count: selected })}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}
