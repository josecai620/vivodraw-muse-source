import { PageHeader } from "@/components/shared";
import { USE_DEV_MOCK_DATA } from "@/constants/env";
import { TealGradient, Colors, s } from "@/constants/theme";
import { usePointsOrderDetail } from "@/hooks";
import { cancelIntegralOrder, takeIntegralOrder } from "@/lib/api/points";
import { unwrapApiData } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Copy, MapPin, Package, Phone, Truck, Clock, CircleCheck, CircleX, type LucideIcon } from "lucide-react-native";
import React, { useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import { ActivityIndicator, Alert, Image, Pressable, ScrollView, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

type OrderStatus = "pending" | "shipping" | "delivered" | "cancelled";

type OrderTimelineItem = {
  status: string;
  time: string;
  completed: boolean;
};

type OrderDetail = {
  id: string;
  status: OrderStatus;
  product: {
    name: string;
    image: string;
    points: number;
    quantity: number;
  };
  address: {
    name: string;
    phone: string;
    lines: string[];
  };
  timeline: OrderTimelineItem[];
  orderDate: string;
  trackingNumber: string;
};

type ApiOrderProduct = {
  store_name?: unknown;
  image?: unknown;
};

type ApiOrderCartItem = {
  productInfo?: ApiOrderProduct;
};

type ApiTimelineItem = {
  status?: unknown;
  title?: unknown;
  time?: unknown;
  add_time?: unknown;
  completed?: unknown;
};

type ApiOrderDetail = {
  id?: unknown;
  order_id?: unknown;
  status?: unknown;
  store_name?: unknown;
  image?: unknown;
  total_price?: unknown;
  pay_price?: unknown;
  total_num?: unknown;
  real_name?: unknown;
  user_phone?: unknown;
  user_address?: unknown;
  city?: unknown;
  country?: unknown;
  add_time?: unknown;
  _add_time?: unknown;
  delivery_id?: unknown;
  tracking_number?: unknown;
  cartInfo?: ApiOrderCartItem[];
  timeline?: ApiTimelineItem[];
};

type StatusConfig = {
  color: string;
  bg: string;
  borderColor: string;
  Icon: LucideIcon;
  label: string;
  description: string;
};

const MOCK_ORDER: OrderDetail = {
  id: "RD202603060001",
  status: "shipping",
  product: {
    name: "Wireless Headphones Pro",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80",
    points: 3500,
    quantity: 1,
  },
  address: {
    name: "John Doe",
    phone: "+1 (555) 123-4567",
    lines: ["123 Main Street, Apt 4B", "New York, NY 10001", "United States"],
  },
  timeline: [
    { status: "Order Placed", time: "2026-03-05 14:30", completed: true },
    { status: "Processing", time: "2026-03-05 15:00", completed: true },
    { status: "Shipped", time: "2026-03-06 09:00", completed: true },
    { status: "Out for Delivery", time: "", completed: false },
    { status: "Delivered", time: "", completed: false },
  ],
  orderDate: "2026-03-05 14:30",
  trackingNumber: "TRK123456789",
};

function toText(value: unknown, fallback = "") {
  if (value == null) return fallback;
  return String(value);
}

function errorMessage(error: unknown, fallback: string) {
  return error instanceof Error ? error.message : fallback;
}

function firstProduct(order: ApiOrderDetail): ApiOrderProduct {
  if (!Array.isArray(order.cartInfo)) return {};
  return order.cartInfo[0]?.productInfo ?? {};
}

function mapOrderStatus(order: ApiOrderDetail): OrderStatus {
  const status = Number(order.status ?? -1);
  if (status === 0) return "pending";
  if (status === 1) return "shipping";
  if (status === 2 || status === 3) return "delivered";
  if (status === -1 || status === -2) return "cancelled";
  return "pending";
}

function buildTimeline(rawTimeline: ApiTimelineItem[] | undefined): OrderTimelineItem[] {
  if (!Array.isArray(rawTimeline)) return [];
  return rawTimeline.map((item) => ({
    status: toText(item.status ?? item.title),
    time: toText(item.time ?? item.add_time),
    completed: Boolean(item.completed),
  }));
}

function buildAddressLines(order: ApiOrderDetail) {
  return [order.user_address, order.city, order.country]
    .map((line) => toText(line))
    .filter(Boolean);
}

function buildOrder(order: ApiOrderDetail | null, fallbackProductName: string): OrderDetail | null {
  if (!order || (!order.id && !order.order_id)) return null;
  const product = firstProduct(order);
  return {
    id: toText(order.order_id ?? order.id),
    status: mapOrderStatus(order),
    product: {
      name: toText(order.store_name ?? product.store_name, fallbackProductName),
      image: normalizeImageUrl(toText(order.image ?? product.image)),
      points: Number(order.total_price ?? order.pay_price ?? 0),
      quantity: Number(order.total_num ?? 1),
    },
    address: {
      name: toText(order.real_name),
      phone: toText(order.user_phone),
      lines: buildAddressLines(order),
    },
    timeline: buildTimeline(order.timeline),
    orderDate: toText(order.add_time ?? order._add_time),
    trackingNumber: toText(order.delivery_id ?? order.tracking_number),
  };
}

export default function PointsOrderDetailScreen() {
  const { t } = useTranslation();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { data, isLoading } = usePointsOrderDetail(id ?? "");
  const queryClient = useQueryClient();
  const [actionLoading, setActionLoading] = useState(false);

  const statusMap = useMemo<Record<OrderStatus, StatusConfig>>(
    () => ({
      shipping: {
        color: "#04A8AE",
        bg: "#F1F3F3",
        borderColor: "#F1F3F3",
        Icon: Truck,
        label: t("pointsOrderDetail.status.shipping.label"),
        description: t("pointsOrderDetail.status.shipping.description"),
      },
      delivered: {
        color: "#04A8AE",
        bg: "#ECFBFB",
        borderColor: "#ECFBFB",
        Icon: CircleCheck,
        label: t("pointsOrderDetail.status.delivered.label"),
        description: t("pointsOrderDetail.status.delivered.description"),
      },
      pending: {
        color: "#04A8AE",
        bg: "#FFFFFF",
        borderColor: "#EBEEEE",
        Icon: Clock,
        label: t("pointsOrderDetail.status.pending.label"),
        description: t("pointsOrderDetail.status.pending.description"),
      },
      cancelled: {
        color: Colors.home.muted,
        bg: Colors.home.background,
        borderColor: Colors.home.border,
        Icon: CircleX,
        label: t("pointsOrderDetail.status.cancelled.label"),
        description: t("pointsOrderDetail.status.cancelled.description"),
      },
    }),
    [t],
  );

  const rawOrder = unwrapApiData<ApiOrderDetail | null>(data, null);
  const builtOrder = buildOrder(rawOrder, t("pointsMall.pointsProduct"));
  const order = builtOrder ?? (USE_DEV_MOCK_DATA ? MOCK_ORDER : null);

  const copyToClipboard = (text: string) => {
    Alert.alert(t("pointsOrderDetail.copied"), text);
  };

  const handleTake = () => {
    if (!order) return;
    Alert.alert(
      t("pointsOrderDetail.confirmReceipt"),
      t("pointsOrderDetail.confirmReceiptMessage"),
      [
        { text: t("pointsOrderDetail.no") },
        {
          text: t("pointsOrderDetail.yes"),
          onPress: async () => {
            setActionLoading(true);
            try {
              await takeIntegralOrder(id ?? order.id);
              queryClient.invalidateQueries({ queryKey: ["pointsOrderDetail"] });
              queryClient.invalidateQueries({ queryKey: ["pointsOrders"] });
              Alert.alert(t("common.success"), t("pointsOrderDetail.receiptConfirmed"));
            } catch (error: unknown) {
              Alert.alert(t("common.failed"), errorMessage(error, t("common.failed")));
            } finally {
              setActionLoading(false);
            }
          },
        },
      ],
    );
  };

  const handleCancel = () => {
    if (!order) return;
    Alert.alert(t("pointsOrderDetail.cancelOrder"), t("pointsOrderDetail.cancelOrderMessage"), [
      { text: t("pointsOrderDetail.no") },
      {
        text: t("pointsOrderDetail.yes"),
        style: "destructive",
        onPress: async () => {
          setActionLoading(true);
          try {
            await cancelIntegralOrder(id ?? order.id);
            queryClient.invalidateQueries({ queryKey: ["pointsOrderDetail"] });
            queryClient.invalidateQueries({ queryKey: ["pointsOrders"] });
            Alert.alert(t("common.success"), t("pointsOrderDetail.orderCancelled"));
          } catch (error: unknown) {
            Alert.alert(t("common.failed"), errorMessage(error, t("common.failed")));
          } finally {
            setActionLoading(false);
          }
        },
      },
    ]);
  };

  if (isLoading) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("pointsOrderDetail.title")} />
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator color={Colors.brand.red} />
        </View>
      </View>
    );
  }

  if (!order) {
    return (
      <View className="flex-1 bg-gray-50">
        <PageHeader title={t("pointsOrderDetail.title")} />
        <View className="flex-1 items-center justify-center px-8">
          <Package size={s(56)} color={Colors.neutral[300]} />
          <Text className="text-xl font-bold text-gray-900 mt-4 mb-2">
            {t("pointsOrderDetail.orderNotFound")}
          </Text>
          <Text className="text-sm text-gray-500 text-center">
            {t("pointsOrderDetail.orderUnavailable")}
          </Text>
        </View>
      </View>
    );
  }

  const statusConfig = statusMap[order.status] ?? statusMap.cancelled;

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title={t("pointsOrderDetail.title")} />

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
      >
        <View className="px-4 pt-4">
          <View
            className="rounded-3xl p-6"
            style={{
              backgroundColor: statusConfig.bg,
              borderWidth: 2,
              borderColor: statusConfig.borderColor,
            }}
          >
            <View className="flex-row items-center gap-4 mb-4">
              <statusConfig.Icon size={44} color={statusConfig.color} strokeWidth={1.9} />
              <View className="flex-1">
                <Text className="text-xl font-bold mb-1" style={{ color: statusConfig.color }}>
                  {statusConfig.label}
                </Text>
                <Text className="text-sm text-gray-600">{statusConfig.description}</Text>
              </View>
            </View>
            {order.status === "shipping" && order.trackingNumber ? (
              <View className="pt-4 border-t border-gray-200">
                <Text className="text-xs text-gray-600 mb-1">
                  {t("pointsOrderDetail.trackingNumber")}
                </Text>
                <View className="flex-row items-center gap-2">
                  <Text
                    className="text-sm font-bold text-gray-900"
                    style={{ fontFamily: "monospace" }}
                  >
                    {order.trackingNumber}
                  </Text>
                  <Pressable
                    className="p-1.5 rounded-lg"
                    onPress={() => copyToClipboard(order.trackingNumber)}
                  >
                    <Copy size={s(14)} color={Colors.neutral[600]} />
                  </Pressable>
                </View>
              </View>
            ) : null}
          </View>
        </View>

        {order.status !== "cancelled" && order.timeline.length > 0 && (
          <View className="px-4 pt-5">
            <View className="flex-row items-center gap-2 mb-3">
              <Truck size={s(16)} color={Colors.brand.red} />
              <Text className="text-sm font-bold text-gray-900">
                {t("pointsOrderDetail.shippingTimeline")}
              </Text>
            </View>
            <View className="bg-white rounded-2xl p-4">
              <View className="gap-4">
                {order.timeline.map((item, index) => (
                  <View key={`${item.status}-${item.time}`} className="flex-row gap-3">
                    <View className="items-center">
                      <View
                        className="w-3 h-3 rounded-full"
                        style={{
                          backgroundColor: item.completed ? Colors.brand.red : "#FFFFFF",
                          borderWidth: 2,
                          borderColor: item.completed ? Colors.brand.red : Colors.neutral[300],
                        }}
                      />
                      {index < order.timeline.length - 1 && (
                        <View
                          className="w-0.5"
                          style={{
                            height: 40,
                            backgroundColor: item.completed
                              ? Colors.brand.red
                              : Colors.neutral[200],
                          }}
                        />
                      )}
                    </View>
                    <View className="flex-1 pb-2">
                      <Text
                        className={`text-sm font-semibold ${
                          item.completed ? "text-gray-900" : "text-gray-400"
                        }`}
                      >
                        {item.status}
                      </Text>
                      {item.time ? (
                        <Text className="text-xs text-gray-500 mt-0.5">{item.time}</Text>
                      ) : null}
                    </View>
                  </View>
                ))}
              </View>
            </View>
          </View>
        )}

        <View className="px-4 pt-5">
          <View className="flex-row items-center gap-2 mb-3">
            <Package size={s(16)} color={Colors.brand.red} />
            <Text className="text-sm font-bold text-gray-900">
              {t("pointsOrderDetail.productInformation")}
            </Text>
          </View>
          <View className="bg-white rounded-2xl p-4">
            <View className="flex-row gap-3">
              <View className="w-20 h-20 rounded-xl overflow-hidden bg-gray-100">
                <Image
                  source={{ uri: order.product.image }}
                  className="w-full h-full"
                  resizeMode="cover"
                />
              </View>
              <View className="flex-1">
                <Text className="text-sm font-bold text-gray-900 mb-1">{order.product.name}</Text>
                <Text className="text-xs text-gray-500 mb-2">
                  {t("pointsOrderDetail.quantity", { count: order.product.quantity })}
                </Text>
                <View className="flex-row items-baseline">
                  <Text className="text-lg font-bold" style={{ color: Colors.brand.red }}>
                    {order.product.points.toLocaleString()}{" "}
                  </Text>
                  <Text className="text-xs text-gray-500">{t("pointsOrders.points")}</Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        <View className="px-4 pt-5">
          <View className="flex-row items-center gap-2 mb-3">
            <MapPin size={s(16)} color={Colors.brand.red} />
            <Text className="text-sm font-bold text-gray-900">
              {t("pointsOrderDetail.deliveryAddress")}
            </Text>
          </View>
          <View className="bg-white rounded-2xl p-4">
            <View className="flex-row items-start justify-between mb-3">
              <View>
                <Text className="text-sm font-bold text-gray-900 mb-0.5">
                  {order.address.name || "-"}
                </Text>
                <View className="flex-row items-center gap-2">
                  <Phone size={s(12)} color={Colors.neutral[600]} />
                  <Text className="text-xs text-gray-600">{order.address.phone || "-"}</Text>
                </View>
              </View>
            </View>
            <Text className="text-sm text-gray-700 leading-5">
              {order.address.lines.length > 0 ? order.address.lines.join("\n") : "-"}
            </Text>
          </View>
        </View>

        <View className="px-4 pt-5">
          <Text className="text-sm font-bold text-gray-900 mb-3">
            {t("pointsOrderDetail.orderInformation")}
          </Text>
          <View className="bg-white rounded-2xl overflow-hidden">
            <View className="flex-row items-center justify-between px-4 py-3 border-b border-gray-100">
              <Text className="text-sm text-gray-600">{t("pointsOrderDetail.orderId")}</Text>
              <View className="flex-row items-center gap-2">
                <Text
                  className="text-sm font-medium text-gray-900"
                  style={{ fontFamily: "monospace" }}
                >
                  {order.id}
                </Text>
                <Pressable className="p-1 rounded" onPress={() => copyToClipboard(order.id)}>
                  <Copy size={s(14)} color={Colors.neutral[400]} />
                </Pressable>
              </View>
            </View>
            <View className="flex-row items-center justify-between px-4 py-3 border-b border-gray-100">
              <Text className="text-sm text-gray-600">{t("pointsOrderDetail.orderDate")}</Text>
              <Text className="text-sm font-medium text-gray-900">{order.orderDate || "-"}</Text>
            </View>
            <View className="flex-row items-center justify-between px-4 py-3">
              <Text className="text-sm text-gray-600">{t("pointsOrderDetail.paymentPoints")}</Text>
              <Text className="text-base font-bold" style={{ color: Colors.brand.red }}>
                {t("pointsOrderDetail.pointsValue", {
                  points: order.product.points.toLocaleString(),
                })}
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>

      <View
        className="bg-white border-t border-gray-200 px-4 py-3"
        style={{ paddingBottom: Math.max(12, insets.bottom) }}
      >
        {actionLoading && (
          <View className="h-12 items-center justify-center">
            <ActivityIndicator color={Colors.brand.red} />
          </View>
        )}
        {!actionLoading && order.status === "shipping" && (
          <View className="flex-row gap-2">
            <Pressable
              className="flex-1 h-12 border-2 border-gray-300 rounded-xl items-center justify-center"
              onPress={() =>
                router.push({ pathname: "/points/tracking", params: { id: order.id } })
              }
            >
              <Text className="font-bold text-gray-700">
                {t("pointsOrderDetail.trackShipping")}
              </Text>
            </Pressable>
            <View className="flex-1 rounded-xl overflow-hidden" style={{ height: 48 }}>
              <LinearGradient
                colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                start={{ x: 0, y: 0.5 }}
                end={{ x: 1, y: 0.5 }}
                style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6,  height: 48, alignItems: "center", justifyContent: "center" }}
              >
                  <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                <Pressable
                  className="w-full h-full items-center justify-center"
                  onPress={handleTake}
                >
                  <Text className="text-white font-bold">
                    {t("pointsOrderDetail.confirmReceipt")}
                  </Text>
                </Pressable>
              </LinearGradient>
            </View>
          </View>
        )}
        {!actionLoading && order.status === "pending" && (
          <View className="flex-row gap-2">
            <Pressable
              className="flex-1 h-12 border-2 border-gray-300 rounded-xl items-center justify-center"
              onPress={handleCancel}
            >
              <Text className="font-bold text-gray-700">{t("pointsOrderDetail.cancelOrder")}</Text>
            </Pressable>
            <View className="flex-1 rounded-xl overflow-hidden" style={{ height: 48 }}>
              <LinearGradient
                colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                start={{ x: 1, y: 0.5 }}
                end={{ x: 0, y: 0.5 }}
                style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6,  height: 48, alignItems: "center", justifyContent: "center" }}
              >
                  <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
                <Pressable
                  className="w-full h-full items-center justify-center"
                  onPress={handleTake}
                >
                  <Text className="text-white font-bold">
                    {t("pointsOrderDetail.confirmReceipt")}
                  </Text>
                </Pressable>
              </LinearGradient>
            </View>
          </View>
        )}
        {!actionLoading && order.status === "delivered" && (
          <View className="rounded-xl overflow-hidden" style={{ height: 48 }}>
            <LinearGradient
              colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={{ shadowColor: "#04A8AE", shadowOffset: { width: 0, height: 6 }, shadowOpacity: 0.3, shadowRadius: 12, elevation: 6,  height: 48, alignItems: "center", justifyContent: "center" }}
            >
                <LinearGradient pointerEvents="none" colors={["rgba(255,255,255,0.30)", "rgba(255,255,255,0)"]} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }} />
              <Pressable
                className="w-full h-full items-center justify-center"
                onPress={() => router.push("/(tabs)/points")}
              >
                <Text className="text-white font-bold">{t("pointsOrderDetail.redeemAgain")}</Text>
              </Pressable>
            </LinearGradient>
          </View>
        )}
      </View>
    </View>
  );
}
