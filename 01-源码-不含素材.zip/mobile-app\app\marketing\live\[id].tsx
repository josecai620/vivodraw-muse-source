import React from "react";
import { ActivityIndicator, Image, Linking, Pressable, ScrollView, Text, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { getLivePlaybacks } from "@/lib/api/live";
import { normalizeImageUrl } from "@/lib/utils";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";
import { Video } from "lucide-react-native";

export default function LiveDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const roomId = id ? parseInt(id, 10) : 0;

  const { data, isLoading } = useQuery({
    queryKey: ["livePlaybacks", roomId],
    queryFn: () => getLivePlaybacks(roomId),
    enabled: roomId > 0,
  });

  const raw = (data as any)?.data ?? data ?? {};
  const playbacks = raw?.list ?? (Array.isArray(raw) ? raw : []);

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Live Replays" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }} showsVerticalScrollIndicator={false}>
          {Array.isArray(playbacks) && playbacks.length > 0 ? (
            playbacks.map((item: any, i: number) => {
              const mediaUrl = item.media_url ?? item.playback_url ?? item.url ?? "";
              const title = item.title ?? item.name ?? "Replay";

              return (
                <Pressable
                  key={i}
                  onPress={() => mediaUrl && Linking.openURL(mediaUrl)}
                  className="bg-white rounded-2xl mb-3 overflow-hidden border border-gray-100"
                >
                  <View className="relative">
                    {item.cover ?? item.cover_url ? (
                      <Image source={{ uri: normalizeImageUrl(item.cover ?? item.cover_url) }} className="w-full h-32" resizeMode="cover" />
                    ) : (
                      <View className="w-full h-32 bg-gray-200 items-center justify-center">
                        <Video size={s(40)} color={Colors.neutral[400]} />
                      </View>
                    )}
                  </View>
                  <View className="p-3">
                    <Text className="font-semibold" style={{ color: Colors.neutral[800] }} numberOfLines={2}>
                      {title}
                    </Text>
                    {mediaUrl ? (
                      <Text className="text-xs mt-1" style={{ color: Colors.brand.red }}>
                        Tap to watch
                      </Text>
                    ) : null}
                  </View>
                </Pressable>
              );
            })
          ) : (
            <View className="py-12 items-center">
              <Video size={s(48)} color={Colors.neutral[300]} />
              <Text className="mt-3" style={{ color: Colors.neutral[500] }}>
                No replays
              </Text>
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}
