import { isApiRecord, unwrapApiPagedList } from "@/lib/api/response";
import { normalizeImageUrl } from "@/lib/utils";
import { cloudBuyShares, toNum } from "@/lib/points/cloudBuyParse";

export type CloudBuyCartItem = {
  id: number;
  productId: number;
  name: string;
  image: string;
  num: number;
  bianhao: string;
  remain: number;
  totalNeed: number;
};

function asRows(value: unknown): Record<string, unknown>[] {
  const direct = unwrapApiPagedList<Record<string, unknown>>(value);
  if (direct.length) return direct;
  if (!isApiRecord(value)) return [];
  const nested = [value.data, value.valid, value.cart, value.cartList];
  for (const item of nested) {
    const rows = unwrapApiPagedList<Record<string, unknown>>(item);
    if (rows.length) return rows;
    if (Array.isArray(item)) return item as Record<string, unknown>[];
  }
  return [];
}

function mapRow(raw: Record<string, unknown>, _idx: number): CloudBuyCartItem {
  const shares = cloudBuyShares(raw);
  return {
    id: toNum(raw.id ?? raw.cart_id),
    productId: toNum(raw.product_id ?? raw.pid),
    name: String(raw.store_name ?? raw.product_name ?? raw.title ?? raw.name ?? ""),
    image: normalizeImageUrl(String(raw.image ?? raw.img ?? raw.pic ?? "")),
    num: Math.max(1, Math.min(shares.remain || 1, toNum(raw.cart_num ?? raw.num ?? raw.buy_num, 1))),
    bianhao: String(raw.cbianhao ?? raw.bianhao ?? raw.qishu ?? ""),
    remain: shares.remain,
    totalNeed: shares.total,
  };
}

export function parseCloudBuyCart(data: unknown): CloudBuyCartItem[] {
  return asRows(data).map(mapRow);
}

export function mergePendingCartItem(
  items: CloudBuyCartItem[],
  pending: CloudBuyCartItem | null,
): CloudBuyCartItem[] {
  if (!pending) return items;
  if (items.some((it) => it.productId === pending.productId)) return items;
  return [pending, ...items];
}

export const QTY_PRESETS = [20, 50, 100] as const;
