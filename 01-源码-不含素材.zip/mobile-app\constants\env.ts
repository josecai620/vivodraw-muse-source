/**
 * 环境配置 — 集中管理 API / Web 基础地址
 *
 * 覆盖优先级（高 → 低）：
 *   1. 运行时环境变量 EXPO_PUBLIC_API_BASE_URL / EXPO_PUBLIC_WEB_BASE_URL
 *   2. app.json 的 expo.extra (ApiBaseUrl / WebBaseUrl)
 *   3. 硬编码兜底（当前测试期大陆 IP）
 *
 * 上线切美国服务器时：
 *   - 只需改 app.json 的 extra 或构建脚本注入环境变量
 *   - 代码零改动、重打包即可
 */
import Constants from "expo-constants";

type Extra = {
  ApiBaseUrl?: string;
  WebBaseUrl?: string;
  UseMockData?: boolean | string;
};

const extra: Extra = (Constants.expoConfig?.extra as Extra | undefined) ?? {};

const envApi = typeof process !== "undefined" && process.env?.EXPO_PUBLIC_API_BASE_URL;
const envWeb = typeof process !== "undefined" && process.env?.EXPO_PUBLIC_WEB_BASE_URL;
const envMockData = typeof process !== "undefined" && process.env?.EXPO_PUBLIC_USE_MOCK_DATA;
const runtimeOrigin =
  typeof globalThis !== "undefined" &&
  typeof (globalThis as { location?: { origin?: string } }).location?.origin === "string"
    ? (globalThis as { location: { origin: string } }).location.origin
    : "";
const isWebRuntime =
  typeof globalThis !== "undefined" &&
  typeof (globalThis as { document?: unknown }).document !== "undefined" &&
  !!runtimeOrigin;

function parseBooleanFlag(value: unknown): boolean | undefined {
  if (typeof value === "boolean") return value;
  if (typeof value !== "string") return undefined;
  const normalized = value.trim().toLowerCase();
  if (["1", "true", "yes", "on"].includes(normalized)) return true;
  if (["0", "false", "no", "off"].includes(normalized)) return false;
  return undefined;
}

/** 后端 API 基础地址（带协议，无结尾斜杠） */
export const API_BASE_URL: string = (
  isWebRuntime ? runtimeOrigin : envApi || extra.ApiBaseUrl || "https://vivodraw.com"
).replace(
  /\/+$/,
  "",
);

/**
 * H5 前台基础地址。当前和 API 在同一台机器，默认等于 API_BASE_URL。
 * 将来前后端分离/独立 CDN 时可分开配置。
 */
export const WEB_BASE_URL: string = (envWeb || extra.WebBaseUrl || API_BASE_URL).replace(
  /\/+$/,
  "",
);

/** 开发测试假数据开关：默认关闭；需要验收假数据时显式设置 EXPO_PUBLIC_USE_MOCK_DATA=1 */
export const USE_DEV_MOCK_DATA: boolean =
  parseBooleanFlag(envMockData) ?? parseBooleanFlag(extra.UseMockData) ?? false;

/** 标识当前页面跑在 app 内，H5 可据此隐藏自己的底部 tabbar 等 */
export const APP_UA_MARKER = "EccomallApp/1.0";
