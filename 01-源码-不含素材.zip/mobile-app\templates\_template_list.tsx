/**
 * 模板：列表页（Header + 筛选 + 商品网格）
 * 使用方法：复制到 app/xxx/index.tsx，接入真实 API hook
 */
import React from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { Colors, s } from "@/constants/theme";
import { PageHeader, ProductCard, SectionHeader } from "@/components/shared";

const MOCK_PRODUCTS = Array.from({ length: 6 }).map((_, i) => ({
  id: i + 1,
  image: "",
  store_name: `Product ${i + 1}`,
  price: String(99 + i * 10),
  ot_price: String(149 + i * 10),
  sales: 100 + i * 50,
  give_integral: 0,
  is_hot: i < 2 ? 1 : 0,
  is_new: i >= 2 && i < 4 ? 1 : 0,
}));

export default function TemplateListScreen() {
  // TODO: 替换为真实 hook
  const products = MOCK_PRODUCTS;
  const isLoading = false;

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Product List" />

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
      >
        <SectionHeader title="All Products" />

        {isLoading ? (
          <View className="items-center justify-center py-12">
            <ActivityIndicator size="large" color={Colors.brand.red} />
          </View>
        ) : products.length === 0 ? (
          <View className="items-center justify-center py-12">
            <Text className="text-lg mb-2" style={{ color: Colors.neutral[300] }}>
              No products found
            </Text>
          </View>
        ) : (
          <View className="flex-row flex-wrap justify-between">
            {products.map((item) => (
              <ProductCard
                key={item.id}
                id={item.id}
                image={item.image}
                name={item.store_name}
                price={item.price}
                originalPrice={item.ot_price}
                sales={item.sales}
                giveIntegral={Number(item.give_integral) || 0}
                isHot={item.is_hot === 1}
                isNew={item.is_new === 1}
                layout="grid"
              />
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}
