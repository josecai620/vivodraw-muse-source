import React from "react";
import { Image as ExpoImage } from "expo-image";
import type { ImageStyle } from "react-native";

interface CachedImageProps {
  uri: string;
  style?: ImageStyle;
  className?: string;
  contentFit?: "cover" | "contain" | "fill" | "none";
  placeholder?: string;
  transition?: number;
  priority?: "low" | "normal" | "high";
}

const BLURHASH_PLACEHOLDER = "L6PZfSi_.AyE_3t7t7R**0o#DgR4";

export default function CachedImage({
  uri,
  style,
  className,
  contentFit = "cover",
  placeholder = BLURHASH_PLACEHOLDER,
  transition = 200,
  priority = "normal",
}: CachedImageProps) {
  if (!uri) {
    return null;
  }

  return (
    <ExpoImage
      source={{ uri }}
      style={style}
      className={className}
      contentFit={contentFit}
      placeholder={{ blurhash: placeholder }}
      transition={transition}
      cachePolicy="memory-disk"
      priority={priority}
    />
  );
}
