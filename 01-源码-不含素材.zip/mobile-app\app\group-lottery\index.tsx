import React, { useState } from "react";
import { View, Text, FlatList, Image, Pressable, ActivityIndicator } from "react-native";
import { useRouter, Stack } from "expo-router";
import { useTranslation } from "react-i18next";
import { Gift } from "lucide-react-native";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";
import { useGroupLotteryList } from "@/hooks/useGroupLottery";

function PriceLabel({ price, priceType }: { price: number; priceType: number }) {
  const { t } = useTranslation();
  return (
    <Text style={{ color: "#04A8AE", fontSize: s(16), fontWeight: "bold" }}>
      {priceType === 1 ? `${price} ${t("common.pts")}` : `$${price}`}
    </Text>
  );
}

export default function GroupLotteryListScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const [page] = useState(1);
  const { data, isLoading } = useGroupLotteryList(page);
  const list = data?.data?.list ?? [];

  return (
    <View className="flex-1 bg-gray-50">
      <Stack.Screen options={{ headerShown: false }} />
      <PageHeader title={t("home.groupLottery.title")} />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color="#04A8AE" />
        </View>
      ) : list.length === 0 ? (
        <View className="flex-1 items-center justify-center">
          <Gift size={s(44)} color={Colors.neutral[300]} strokeWidth={1.8} />
          <Text className="mt-3 text-gray-400" style={{ fontSize: s(14) }}>{t("groupLottery.noItems")}</Text>
        </View>
      ) : (
        <FlatList
          data={list}
          keyExtractor={(item: any) => String(item.id)}
          contentContainerStyle={{ padding: s(12) }}
          renderItem={({ item, index }: { item: any; index: number }) => {
            const peopleOpts = (item.people_options || "3,5,10").split(",");
            return (
              <Pressable
                onPress={() => router.push(`/group-lottery/${item.id}`)}
                style={{
                  backgroundColor: "#fff",
                  borderRadius: s(12),
                  marginBottom: s(10),
                  flexDirection: "row",
                  padding: s(10),
                  borderWidth: 1,
                  borderColor: "#f0f0f0",
                }}
              >
                <Image
                  source={{ uri: item.image }}
                  style={{ width: s(90), height: s(90), borderRadius: s(8) }}
                  resizeMode="cover"
                />
                <View style={{ flex: 1, marginLeft: s(10), justifyContent: "space-between" }}>
                  <Text numberOfLines={2} style={{ fontSize: s(14), fontWeight: "600", color: Colors.neutral[800] }}>
                    {item.title}
                  </Text>
                  <Text numberOfLines={1} style={{ fontSize: s(11), color: Colors.neutral[500], marginTop: s(2) }}>
                    {item.info}
                  </Text>
                  <View
                    style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginTop: s(4) }}
                  >
                    <PriceLabel price={item.price} priceType={item.price_type} />
                    <View style={{ flexDirection: "row", gap: s(4) }}>
                      {peopleOpts.map((n: string) => (
                        <View key={n} style={{ backgroundColor: "#F7F8F8", paddingHorizontal: s(6), paddingVertical: s(2), borderRadius: s(4) }}>
                          <Text style={{ fontSize: s(10), color: "#04A8AE" }}>{t("groupLottery.nPeopleGroup", { count: Number(n), defaultValue: `${n} ppl` })}</Text>
                        </View>
                      ))}
                    </View>
                  </View>
                  <View
                    style={{ flexDirection: "row", alignItems: "center", marginTop: s(4) }}
                  >
                    <Text style={{ fontSize: s(10), color: "#04A8AE" }}>{t("groupLottery.bonusRefund", { rate: item.bonus_rate, defaultValue: `Losers +${item.bonus_rate}% bonus refund` })}</Text>
                    <Text style={{ fontSize: s(10), color: Colors.neutral[400], marginLeft: s(8) }}>{t("groupLottery.drawnTimes", { count: item.sales, defaultValue: `${item.sales} draws done` })}</Text>
                  </View>
                </View>
              </Pressable>
            );
          }}
        />
      )}
    </View>
  );
}
