import * as Clipboard from "expo-clipboard";
import * as Sharing from "expo-sharing";
/**
 * 原生分享 — 调起系统分享面板
 *
 * 在 iOS / Android 都用 RN 内置的 Share API（最稳定、无需额外权限）。
 * 分享图片文件用 expo-sharing。
 */
import { Platform, Share, type ShareContent } from "react-native";

export type ShareResult =
  | { ok: true; action: "shared" | "dismissed"; activityType?: string }
  | { ok: false; error: string };

/**
 * 分享纯文本 + 可选 URL。
 * iOS 会把 url 和 message 合并显示；Android 不支持 url 字段，我们会拼进 message。
 */
export async function shareText(
  message: string,
  url?: string,
  title?: string,
): Promise<ShareResult> {
  try {
    const content: ShareContent =
      Platform.OS === "ios"
        ? { message, ...(url ? { url } : {}), ...(title ? { title } : {}) }
        : {
            message: url ? `${message}\n${url}` : message,
            ...(title ? { title } : {}),
          };
    const res = await Share.share(content);
    if (res.action === Share.sharedAction) {
      return { ok: true, action: "shared", activityType: res.activityType ?? undefined };
    }
    return { ok: true, action: "dismissed" };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : String(e),
    };
  }
}

/**
 * 分享本地文件（通常是图片/海报）。传 file:// URI。
 * 用于商品分享海报等场景。
 */
export async function shareFile(
  fileUri: string,
  mimeType?: string,
  dialogTitle?: string,
): Promise<ShareResult> {
  try {
    const available = await Sharing.isAvailableAsync();
    if (!available) {
      return { ok: false, error: "当前设备不支持分享" };
    }
    await Sharing.shareAsync(fileUri, {
      mimeType: mimeType || "image/jpeg",
      dialogTitle: dialogTitle || "分享",
    });
    return { ok: true, action: "shared" };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : String(e),
    };
  }
}

/** 复制到剪贴板（分享退回方案） */
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await Clipboard.setStringAsync(text);
    return true;
  } catch {
    return false;
  }
}
