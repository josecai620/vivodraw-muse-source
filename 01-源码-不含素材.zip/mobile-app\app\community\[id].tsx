import CachedImage from "@/components/shared/CachedImage";
import PageHeader from "@/components/shared/PageHeader";
import { Colors, TealGradient } from "@/constants/theme";
import { useCommunityDetail } from "@/hooks/useCommunityDetail";
import { addCommunityComment, toggleCommunityLike } from "@/lib/api/community";
import { shareCommunityPost, type CommunityShareTarget } from "@/lib/community-share";
import { LinearGradient } from "expo-linear-gradient";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Eye, Heart, Link2, MessageCircle, Send, Share2 } from "lucide-react-native";
import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from "react-native";

export default function CommunityDetailScreen() {
  const router = useRouter();
  const params = useLocalSearchParams<{ id?: string }>();
  const { i18n } = useTranslation();
  const zh = !!i18n.language?.startsWith("zh");
  const text = (z: string, e: string) => (zh ? z : e);
  const id = Array.isArray(params.id) ? params.id[0] : params.id || "";
  const detail = useCommunityDetail(id);
  const [comment, setComment] = useState("");
  const [message, setMessage] = useState("");
  const [shareLog, setShareLog] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const post = detail.post;
  const canSubmit = comment.trim().length > 0 && !isSubmitting;

  const submitComment = async () => {
    const content = comment.trim();
    if (!post || !content) return;
    setIsSubmitting(true);
    setMessage("");
    const result = await addCommunityComment(post.id, content);
    setIsSubmitting(false);
    if (!result.ok) {
      setMessage(result.message || text("評論未發送", "Comment was not sent."));
      return;
    }
    setComment("");
    setMessage(text("評論已發送", "Comment sent."));
    detail.refresh();
  };

  const likePost = async () => {
    if (!post) return;
    await toggleCommunityLike(post.id, post.productId);
    detail.refresh();
  };

  const sharePost = async (target: CommunityShareTarget) => {
    if (!post) return;
    try {
      const result = await shareCommunityPost(post, target);
      setShareLog(result.message);
      if (result.rewardPoints > 0) {
        Alert.alert(text("積分入帳", "Point added"), text(result.message, result.message));
      }
    } catch {
      setShareLog(text("分享失敗，請用系統分享按鈕", "Share failed. Try the system share button."));
    }
  };

  return (
    <View className="flex-1 bg-neutral-50">
      <PageHeader title={post?.title || text("社區詳情", "Community detail")} />
      <ScrollView
        contentContainerStyle={{ padding: 16, gap: 16, paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
      >
        {post ? (
          <>
            <View className="bg-white rounded-2xl p-5 gap-3">
              <Text className="text-xs font-bold" style={{ color: Colors.brand.redDark }}>
                {post.productName}
              </Text>
              <Text className="text-xl font-bold text-neutral-900">{post.title}</Text>
              <Text className="text-xs text-neutral-400">
                {post.author} · {post.createdAt}
                {post.statusLabel ? ` · ${post.statusLabel}` : ""}
              </Text>
              {post.image ? (
                <CachedImage uri={post.image} style={{ width: "100%", aspectRatio: 1.2, borderRadius: 12 }} />
              ) : null}
              {post.images.length > 1 ? (
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  <View className="flex-row gap-2">
                    {post.images.slice(1).map((image) => (
                      <CachedImage
                        key={image}
                        uri={image}
                        style={{ width: 96, height: 96, borderRadius: 10 }}
                      />
                    ))}
                  </View>
                </ScrollView>
              ) : null}
              <Text className="text-sm text-neutral-700 leading-6">
                {post.content || text("會員晒單", "Buyer photo post.")}
              </Text>
              <View className="flex-row gap-4">
                <View className="flex-row items-center">
                  <Heart size={14} color={Colors.neutral[500]} />
                  <Text className="text-xs text-neutral-500 ml-1">
                    {post.likes} {text("讚", "likes")}
                  </Text>
                </View>
                <View className="flex-row items-center">
                  <MessageCircle size={14} color={Colors.neutral[500]} />
                  <Text className="text-xs text-neutral-500 ml-1">
                    {post.comments} {text("評論", "comments")}
                  </Text>
                </View>
                <View className="flex-row items-center">
                  <Eye size={14} color={Colors.neutral[500]} />
                  <Text className="text-xs text-neutral-500 ml-1">
                    {post.views} {text("瀏覽", "views")}
                  </Text>
                </View>
              </View>
              <View className="flex-row gap-2">
                <Pressable
                  className="flex-1 h-11 rounded-xl border items-center justify-center flex-row"
                  style={{ borderColor: Colors.brand.red }}
                  onPress={() => void likePost()}
                >
                  <Heart
                    size={15}
                    color={Colors.brand.red}
                    fill={post.isLiked ? Colors.brand.red : "transparent"}
                  />
                  <Text className="text-sm font-bold ml-1.5" style={{ color: Colors.brand.redDark }}>
                    {post.isLiked ? text("已讚", "Liked") : text("點讚", "Like")}
                  </Text>
                </Pressable>
                <Pressable
                  className="flex-1 h-11 rounded-xl bg-neutral-100 items-center justify-center flex-row"
                  onPress={() => router.push("/community/new")}
                >
                  <Share2 size={15} color={Colors.neutral[600]} />
                  <Text className="text-sm font-bold ml-1.5 text-neutral-700">
                    {text("我也晒單", "Share a win")}
                  </Text>
                </Pressable>
              </View>
            </View>

            {/* 分享 */}
            <View className="bg-white rounded-2xl p-5 gap-3">
              <Text className="text-base font-bold text-neutral-900">
                {text("分享這個發現", "Share this find")}
              </Text>
              <Text className="text-xs text-neutral-500 leading-4">
                {text(
                  "可發送到訊息、群組，或複製連結自行貼上；符合條件的分享會在平台開放後計入積分。",
                  "Use your phone's share sheet for messages and groups, or copy the link. Qualifying shares earn points once the platform opens.",
                )}
              </Text>
              <Pressable onPress={() => void sharePost("system")}>
                <LinearGradient
                  colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
                  start={{ x: 0, y: 0.5 }}
                  end={{ x: 1, y: 0.5 }}
                  className="h-12 rounded-xl items-center justify-center"
                >
                  <Text className="text-white font-bold">{text("發送給好友", "Send to a friend")}</Text>
                </LinearGradient>
              </Pressable>
              <View className="flex-row gap-2">
                {([
                  ["copy", text("複製連結", "Copy link")],
                  ["whatsapp", "WhatsApp"],
                  ["facebook", "Facebook"],
                  ["instagram", "Instagram"],
                ] as const).map(([target, label]) => (
                  <Pressable
                    key={target}
                    className="flex-1 h-10 rounded-lg bg-neutral-100 items-center justify-center"
                    onPress={() => void sharePost(target)}
                  >
                    <Text className="text-xs font-semibold text-neutral-700">{label}</Text>
                  </Pressable>
                ))}
              </View>
              {shareLog ? (
                <View className="flex-row items-center">
                  <Link2 size={13} color={Colors.brand.redDark} />
                  <Text className="text-xs ml-1.5" style={{ color: Colors.brand.redDark }}>
                    {shareLog}
                  </Text>
                </View>
              ) : null}
            </View>

            {/* 评论 */}
            <View className="bg-white rounded-2xl p-5 gap-3">
              <View className="flex-row items-center justify-between">
                <Text className="text-base font-bold text-neutral-900">{text("評論", "Comments")}</Text>
                <Text className="text-sm text-neutral-400">{detail.comments.length}</Text>
              </View>
              {detail.comments.length > 0 ? (
                detail.comments.map((row) => (
                  <View key={row.id} className="flex-row gap-3">
                    <View
                      className="w-9 h-9 rounded-full items-center justify-center"
                      style={{ backgroundColor: "#ECFBFB" }}
                    >
                      <Text className="text-sm font-bold" style={{ color: Colors.brand.redDark }}>
                        {row.author.slice(0, 1).toUpperCase()}
                      </Text>
                    </View>
                    <View className="flex-1">
                      <View className="flex-row items-center justify-between">
                        <Text numberOfLines={1} className="text-sm font-bold text-neutral-900">
                          {row.author}
                        </Text>
                        <Text className="text-xs text-neutral-400">{row.createdAt}</Text>
                      </View>
                      <Text className="text-sm text-neutral-600 leading-5 mt-0.5">{row.content}</Text>
                    </View>
                  </View>
                ))
              ) : (
                <Text className="text-sm text-neutral-400">{text("還沒有評論", "No comments yet.")}</Text>
              )}
              <View className="flex-row gap-2 items-end">
                <TextInput
                  multiline
                  placeholder={text("寫下評論…", "Write a comment")}
                  placeholderTextColor={Colors.neutral[400]}
                  value={comment}
                  onChangeText={setComment}
                  className="flex-1 bg-neutral-50 border border-neutral-200 rounded-xl px-3 py-2.5 text-sm text-neutral-900"
                  style={{ minHeight: 44 }}
                />
                <Pressable
                  disabled={!canSubmit}
                  onPress={() => void submitComment()}
                  className="w-12 h-11 rounded-xl items-center justify-center"
                  style={{ backgroundColor: canSubmit ? Colors.brand.red : Colors.neutral[300] }}
                >
                  {isSubmitting ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <Send size={18} color="#fff" />
                  )}
                </Pressable>
              </View>
              {message ? (
                <Text className="text-xs" style={{ color: Colors.brand.redDark }}>
                  {message}
                </Text>
              ) : null}
            </View>
          </>
        ) : (
          <View className="bg-white rounded-2xl p-8 items-center gap-3">
            <Text className="text-base font-bold text-neutral-900">
              {detail.isLoading ? text("載入中…", "Loading...") : text("沒有找到該貼文", "Post not found")}
            </Text>
            <Text className="text-sm text-neutral-500 text-center">
              {text("返回社區廣場選擇其他貼文", "Refresh the community feed or choose another post.")}
            </Text>
            <Pressable
              className="h-11 px-6 rounded-xl border border-neutral-200 items-center justify-center"
              onPress={() => router.push("/community")}
            >
              <Text className="font-semibold text-neutral-700">{text("返回社區", "Back to community")}</Text>
            </Pressable>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
