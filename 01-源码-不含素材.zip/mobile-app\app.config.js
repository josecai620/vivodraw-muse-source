// Dynamic Expo config.
//
// By default this returns app.json unchanged, so the main-site build (root "/")
// behaves exactly as before.
//
// When EXPO_WEB_BASE_URL is set (e.g. EXPO_WEB_BASE_URL=/v4 for the isolated v4
// preview deployment), every bundled web resource link (_expo/assets) is prefixed
// with that subpath so the build can be served from https://vivodraw.com/v4
// without colliding with the live root frontend.
const appJson = require('./app.json');

module.exports = function createConfig() {
  const expo = { ...appJson.expo };
  const baseUrl = process.env.EXPO_WEB_BASE_URL || '';

  if (baseUrl) {
    expo.experiments = {
      ...(expo.experiments || {}),
      baseUrl,
    };
  }

  return expo;
};
