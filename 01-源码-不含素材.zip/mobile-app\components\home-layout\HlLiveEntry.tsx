import React, { useEffect, useRef } from "react";
import { Animated, Easing, Image, Pressable, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { Colors } from "@/constants/theme";
import { normalizeImageUrl } from "@/lib/utils";
import { pickLang } from "./utils";

interface HlLiveEntryProps {
  props: {
    title?: { en?: string; zh?: string } | string;
    subtitle?: { en?: string; zh?: string } | string;
    cover?: string;
    link?: string;
    status?: "live" | "upcoming" | "ended";
  };
  lang: string;
}

/** 直播入口：封面 + 直播状态点 + 跳转链接 */
export default function HlLiveEntry({ props, lang }: HlLiveEntryProps) {
  const router = useRouter();
  const pulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (props.status !== "live") return;
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 0.3, duration: 700, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1, duration: 700, easing: Easing.inOut(Easing.ease), useNativeDriver: true }),
      ]),
    ).start();
  }, [props.status]);

  const title = pickLang(props.title, lang) || (lang === "en" ? "Live Now" : "正在直播");
  const subtitle = pickLang(props.subtitle, lang);
  const cover = props.cover ? normalizeImageUrl(props.cover) : "";
  const statusLabel =
    props.status === "live"
      ? lang === "en" ? "LIVE" : "直播中"
      : props.status === "upcoming"
        ? lang === "en" ? "SOON" : "即將開播"
        : lang === "en" ? "ENDED" : "已結束";
  const statusColor = props.status === "live" ? Colors.brand.red : props.status === "upcoming" ? Colors.accent.gold : Colors.home.muted;
  const link = props.link || "/live";

  return (
    <Pressable
      onPress={() => router.push(link as any)}
      className="mx-4 mt-3 rounded-2xl overflow-hidden"
      style={{
        backgroundColor: Colors.home.surface,
        borderColor: Colors.home.border,
        borderWidth: 1,
        height: 96,
      }}
    >
      <View className="flex-row h-full">
        <View style={{ width: 128, height: "100%", backgroundColor: Colors.home.warmSurface }}>
          {cover ? <Image source={{ uri: cover }} style={{ width: "100%", height: "100%" }} resizeMode="cover" /> : null}
        </View>
        <View className="flex-1 p-3 justify-between">
          <View>
            <View className="flex-row items-center gap-2">
              <Animated.View style={{ opacity: pulse, width: 8, height: 8, borderRadius: 4, backgroundColor: statusColor }} />
              <Text style={{ color: statusColor, fontSize: 11, fontWeight: "700" }}>{statusLabel}</Text>
            </View>
            <Text numberOfLines={1} style={{ color: Colors.home.text, fontSize: 14, fontWeight: "700", marginTop: 4 }}>{title}</Text>
            {!!subtitle && (
              <Text numberOfLines={1} style={{ color: Colors.home.muted, fontSize: 12, marginTop: 2 }}>{subtitle}</Text>
            )}
          </View>
          <View className="self-start rounded-full px-2.5 py-0.5" style={{ backgroundColor: Colors.brand.red }}>
            <Text style={{ color: "#fff", fontSize: 11, fontWeight: "600" }}>{lang === "en" ? "Watch" : "進入直播"}</Text>
          </View>
        </View>
      </View>
    </Pressable>
  );
}
