import { Linking, Platform, Share } from "react-native";

import {
  fetchCommunitySharePayload,
  trackCommunityShare,
  type CommunityPost,
  type CommunitySharePayload,
} from "@/lib/api/community";

export type CommunityShareTarget = "system" | "copy" | "whatsapp" | "facebook" | "instagram";

export type CommunityShareResult = {
  message: string;
  rewardPoints: number;
};

type ResolvedSharePayload = {
  title: string;
  text: string;
  url: string;
  imageUrl?: string;
  platforms?: CommunitySharePayload["platforms"];
};

type WebShareData = {
  title?: string;
  text?: string;
  url?: string;
  files?: File[];
};

type NavigatorWithShare = Navigator & {
  share?: (data: WebShareData) => Promise<void>;
  canShare?: (data: WebShareData) => boolean;
};

export function createCommunitySharePayload(post: CommunityPost, target: CommunityShareTarget = "system"): ResolvedSharePayload {
  const origin = readWebOrigin();
  const url = buildTrackedShareUrl(`${origin}/community/share/${encodeURIComponent(post.id)}`, target, post.id);
  const caption = [
    post.title,
    post.content || "A Vivodraw member shared a real find.",
    post.productName ? `Find: ${post.productName}` : "",
    "Shared from Vivodraw. I may earn points.",
  ]
    .map((line) => line.trim())
    .filter(Boolean)
    .join("\n");

  return {
    title: post.title,
    text: caption,
    url,
    imageUrl: post.image,
    platforms: post.share?.platforms,
  };
}

export async function shareCommunityPost(post: CommunityPost, target: CommunityShareTarget): Promise<CommunityShareResult> {
  const payload = applyShareTarget(await resolveSharePayload(post), target, post.id);
  let result = "";

  if (target === "copy") {
    const copied = await copyText(payload.url);
    return {
      message: copied ? "Link copied. Send it wherever the conversation is already happening." : "Copy is not available in this browser.",
      rewardPoints: 0,
    };
  }

  if (target === "system") {
    result = await openSystemShare(payload);
  } else if (target === "whatsapp") {
    await Linking.openURL(payload.platforms?.whatsapp || `https://wa.me/?text=${encodeURIComponent(formatShareText(payload))}`);
    result = "WhatsApp share opened.";
  } else if (target === "facebook") {
    await Linking.openURL(
      payload.platforms?.facebook ||
        `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(payload.url)}&quote=${encodeURIComponent(payload.text)}`,
    );
    result = "Facebook share opened.";
  } else {
    const shared = await tryWebShare(payload, true);
    if (shared) {
      result = "Instagram share opened.";
    } else {
      await Linking.openURL("https://www.instagram.com/");
      result = "Instagram needs the system share sheet. Paste the caption and image there.";
    }
  }

  const tracked = await trackCommunityShare(post.id, target);
  const rewardPoints = tracked.ok ? normalizeRewardPoints(tracked.data) : 0;

  return {
    message: rewardPoints > 0 ? "You earned 1 point." : result,
    rewardPoints,
  };
}

async function resolveSharePayload(post: CommunityPost): Promise<ResolvedSharePayload> {
  const remotePayload = post.share || await fetchCommunitySharePayload(post.id);
  if (!remotePayload) {
    return createCommunitySharePayload(post);
  }

  return {
    title: remotePayload.title || post.title,
    text: remotePayload.text || post.content,
    url: remotePayload.url || createCommunitySharePayload(post).url,
    imageUrl: remotePayload.image || remotePayload.images?.[0] || post.image,
    platforms: remotePayload.platforms,
  };
}

async function openSystemShare(payload: ResolvedSharePayload) {
  const webShared = await tryWebShare(payload, true);
  if (webShared) {
    return "Share sheet opened.";
  }

  const message = formatShareText(payload);
  if (Platform.OS !== "web") {
    await Share.share({
      title: payload.title,
      message,
      url: payload.url,
    });
    return "Share sheet opened.";
  }

  const copied = await copyText(message);
  return copied ? "Caption copied. Paste it into any app." : "Share is not available in this browser.";
}

async function tryWebShare(payload: ResolvedSharePayload, includeImage: boolean) {
  if (Platform.OS !== "web" || typeof navigator === "undefined") {
    return false;
  }

  const nav = navigator as NavigatorWithShare;
  if (!nav.share) {
    return false;
  }

  const shareData: WebShareData = {
    title: payload.title,
    text: payload.text,
    url: payload.url,
  };

  const imageFile = includeImage && payload.imageUrl ? await buildShareFile(payload.imageUrl, payload.title) : undefined;
  if (imageFile && (!nav.canShare || nav.canShare({ files: [imageFile] }))) {
    shareData.files = [imageFile];
  }

  await nav.share(shareData);
  return true;
}

async function buildShareFile(imageUrl: string, title: string) {
  try {
    const response = await fetch(imageUrl);
    if (!response.ok) return undefined;

    const blob = await response.blob();
    const extension = blob.type.includes("png") ? "png" : blob.type.includes("webp") ? "webp" : "jpg";
    const safeTitle = title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "community-post";
    return new File([blob], `${safeTitle}.${extension}`, { type: blob.type || "image/jpeg" });
  } catch {
    return undefined;
  }
}

async function copyText(text: string) {
  try {
    if (typeof navigator === "undefined" || !navigator.clipboard?.writeText) {
      return false;
    }
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

function formatShareText(payload: ResolvedSharePayload) {
  return [
    payload.text,
    payload.url,
  ]
    .filter(Boolean)
    .join("\n");
}

function applyShareTarget(payload: ResolvedSharePayload, target: CommunityShareTarget, postId: string): ResolvedSharePayload {
  const copyUrl = target === "copy" ? readCopyPlatformUrl(payload.platforms) : "";

  return {
    ...payload,
    url: copyUrl || buildTrackedShareUrl(payload.url, target, postId),
  };
}

function readCopyPlatformUrl(platforms: CommunitySharePayload["platforms"] | undefined) {
  const copy = platforms?.copy;
  if (typeof copy === "string") {
    return copy;
  }
  if (copy && typeof copy === "object" && typeof copy.url === "string") {
    return copy.url;
  }
  return "";
}

function buildTrackedShareUrl(url: string, target: CommunityShareTarget, postId: string) {
  try {
    const parsed = new URL(url, readWebOrigin());
    const source = target === "system" ? "system_share" : target === "copy" ? "copy_link" : target;
    parsed.searchParams.set("utm_source", source);
    parsed.searchParams.set("utm_medium", source === "copy_link" ? "copy_link" : "social_share");
    parsed.searchParams.set("utm_campaign", "community_post");
    parsed.searchParams.set("utm_content", `post_${postId}`);
    parsed.searchParams.set("ref", `community_post_${postId}`);
    return parsed.toString();
  } catch {
    return url;
  }
}

function normalizeRewardPoints(data: unknown) {
  if (!data || typeof data !== "object") {
    return 0;
  }

  const record = data as { rewardPoints?: unknown; reward_points?: unknown };
  const value = Number(record.rewardPoints ?? record.reward_points ?? 0);
  return Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0;
}

function readWebOrigin() {
  if (typeof globalThis !== "undefined" && typeof globalThis.location?.origin === "string") {
    return globalThis.location.origin;
  }

  return "https://vivodraw.com";
}
