import React, { useState } from "react";
import {
  Dimensions,
  Modal,
  Pressable,
  ScrollView,
  Text,
  View,
} from "react-native";
import { useTranslation } from "react-i18next";
import { Menu, X } from "lucide-react-native";
import { useRouter, usePathname } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import Animated, {
  runOnJS,
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from "react-native-reanimated";
import { TealGradient } from "@/constants/theme";
import TealSurface from "@/components/ui/TealSurface";

const BUTTON_SIZE = 56;
const { width: SCREEN_W, height: SCREEN_H } = Dimensions.get("window");

export default function FloatingNav() {
  const { t } = useTranslation();
  const [menuOpen, setMenuOpen] = useState(false);
  const openMenu = () => {
    setMenuOpen(true);
  };

  const categoryOrder = [
    t("nav.categoryShop"),
    t("nav.categoryPointsStore"),
    t("nav.categoryPointsReveal"),
    t("nav.categoryBox"),
    t("nav.categoryProfile"),
    t("nav.categoryBasic"),
  ];

  const pages = [
    { route: "/(tabs)", label: t("nav.shopHome"), category: t("nav.categoryShop") },
    { route: "/product/1", label: t("nav.productDetail"), category: t("nav.categoryShop") },
    { route: "/(tabs)/cart", label: t("nav.cart"), category: t("nav.categoryShop") },
    { route: "/checkout", label: t("nav.checkout"), category: t("nav.categoryShop") },
    { route: "/orders", label: t("nav.orders"), category: t("nav.categoryShop") },
    { route: "/orders/detail", label: t("nav.orderDetail"), category: t("nav.categoryShop") },
    { route: "/(tabs)/categories", label: t("nav.categoriesPage"), category: t("nav.categoryShop") },
    { route: "/search", label: t("nav.searchPage"), category: t("nav.categoryShop") },

    { route: "/(tabs)/points", label: t("nav.pointsStoreHome"), category: t("nav.categoryPointsStore") },
    { route: "/points/product", label: t("nav.pointsProductDetail"), category: t("nav.categoryPointsStore") },
    { route: "/points/categories", label: t("nav.pointsCategories"), category: t("nav.categoryPointsStore") },
    { route: "/points/orders", label: t("nav.pointsOrders"), category: t("nav.categoryPointsStore") },
    { route: "/points/order-detail", label: t("nav.pointsOrderDetail"), category: t("nav.categoryPointsStore") },
    { route: "/points/me", label: t("nav.pointsCenter"), category: t("nav.categoryPointsStore") },
    { route: "/points/history", label: t("nav.pointsHistory"), category: t("nav.categoryPointsStore") },
    { route: "/points/tasks", label: t("nav.earnPointsTasks"), category: t("nav.categoryPointsStore") },
    { route: "/points/checkin", label: t("nav.dailyCheckin"), category: t("nav.categoryPointsStore") },
    { route: "/points/lottery", label: t("nav.luckyDraw"), category: t("nav.categoryPointsStore") },
    { route: "/points/wishlist", label: t("nav.pointsWishlist"), category: t("nav.categoryPointsStore") },
    { route: "/points/collection", label: t("nav.pointsFavorites"), category: t("nav.categoryPointsStore") },
    { route: "/points/reviews", label: t("nav.reviewSquare"), category: t("nav.categoryPointsStore") },
    { route: "/points/redemptions", label: t("nav.redemptionRecords"), category: t("nav.categoryPointsStore") },
    { route: "/points/notifications", label: t("nav.pointsNotifications"), category: t("nav.categoryPointsStore") },
    { route: "/points/tracking", label: t("nav.shipmentTracking"), category: t("nav.categoryPointsStore") },
    { route: "/points/rules", label: t("nav.pointsRules"), category: t("nav.categoryPointsStore") },

    { route: "/reveal", label: t("nav.revealHome"), category: t("nav.categoryPointsReveal") },
    { route: "/reveal/1", label: t("nav.revealProductDetail"), category: t("nav.categoryPointsReveal") },
    { route: "/reveal/1/countdown", label: t("nav.revealCountdown"), category: t("nav.categoryPointsReveal") },
    { route: "/reveal/1/result", label: t("nav.revealResult"), category: t("nav.categoryPointsReveal") },
    { route: "/reveal/records", label: t("nav.myRevealRecords"), category: t("nav.categoryPointsReveal") },
    { route: "/reveal/rules", label: t("nav.revealRules"), category: t("nav.categoryPointsReveal") },
    { route: "/reveal/history", label: t("nav.revealHistory"), category: t("nav.categoryPointsReveal") },

    { route: "/box", label: t("nav.boxHall"), category: t("nav.categoryBox") },
    { route: "/box/1", label: t("nav.boxDetail"), category: t("nav.categoryBox") },
    { route: "/box/1/opening", label: t("nav.boxOpening"), category: t("nav.categoryBox") },
    { route: "/box/backpack", label: t("nav.myBackpack"), category: t("nav.categoryBox") },
    { route: "/box/history", label: t("nav.boxHistory"), category: t("nav.categoryBox") },
    { route: "/box/recycle", label: t("nav.boxRecycle"), category: t("nav.categoryBox") },
    { route: "/box/collection", label: t("nav.boxCollection"), category: t("nav.categoryBox") },

    { route: "/(tabs)/profile", label: t("nav.personalCenter"), category: t("nav.categoryProfile") },
    { route: "/profile/wishlist", label: t("nav.favoriteWishlist"), category: t("nav.categoryProfile") },
    { route: "/profile/address", label: t("nav.addressManagement"), category: t("nav.categoryProfile") },
    { route: "/profile/coupons", label: t("nav.couponsLabel"), category: t("nav.categoryProfile") },
    { route: "/profile/payment", label: t("nav.paymentMethodsLabel"), category: t("nav.categoryProfile") },
    { route: "/profile/help", label: t("nav.helpCenterLabel"), category: t("nav.categoryProfile") },

    { route: "/auth", label: t("nav.login"), category: t("nav.categoryBasic") },
    { route: "/auth/register", label: t("nav.register"), category: t("nav.categoryBasic") },
    { route: "/auth/forgot-password", label: t("nav.forgotPasswordLabel"), category: t("nav.categoryBasic") },
    { route: "/profile/notifications", label: t("nav.notificationCenter"), category: t("nav.categoryBasic") },
  ];

  function getCurrentPageLabel(pathname: string): string {
    const match = pages.find((p) => p.route === pathname);
    if (match) return match.label;
    if (
      pathname === "/" ||
      pathname === "/(tabs)" ||
      pathname === "/(tabs)/index"
    )
      return t("nav.shopHome");
    if (pathname.startsWith("/product/")) return t("nav.productDetail");
    if (pathname === "/box") return t("nav.boxHall");
    if (pathname.startsWith("/box/") && pathname.includes("/opening"))
      return t("nav.boxOpening");
    if (pathname.startsWith("/box/")) return t("nav.boxDetail");
    return t("nav.shopHome");
  }

  const router = useRouter();
  const pathname = usePathname();
  const insets = useSafeAreaInsets();
  const currentLabel = getCurrentPageLabel(pathname);

  const translateX = useSharedValue(SCREEN_W - BUTTON_SIZE - 16);
  const translateY = useSharedValue(SCREEN_H - BUTTON_SIZE - insets.bottom - 100);
  const contextX = useSharedValue(0);
  const contextY = useSharedValue(0);
  const scale = useSharedValue(1);
  const dragged = useSharedValue(false);

  const panGesture = Gesture.Pan()
    .onStart(() => {
      contextX.value = translateX.value;
      contextY.value = translateY.value;
      scale.value = withSpring(1.15);
      dragged.value = false;
    })
    .onUpdate((e) => {
      if (Math.abs(e.translationX) > 4 || Math.abs(e.translationY) > 4) {
        dragged.value = true;
      }
      const newX = contextX.value + e.translationX;
      const newY = contextY.value + e.translationY;
      translateX.value = Math.max(0, Math.min(newX, SCREEN_W - BUTTON_SIZE));
      translateY.value = Math.max(
        insets.top,
        Math.min(newY, SCREEN_H - BUTTON_SIZE - insets.bottom),
      );
    })
    .onEnd(() => {
      scale.value = withSpring(1);
      dragged.value = false; // 拖拽结束后重置，确保下次点击能展开菜单
      const midX = SCREEN_W / 2;
      translateX.value = withSpring(
        translateX.value < midX ? 8 : SCREEN_W - BUTTON_SIZE - 8,
        { damping: 15, stiffness: 150 },
      );
    });

  const tapGesture = Gesture.Tap().onEnd(() => {
    if (!dragged.value) {
      // 手势回调运行在 UI worklet 线程，必须通过 runOnJS 回到 JS 线程更新 React state。
      runOnJS(openMenu)();
    }
  });

  const composedGesture = Gesture.Race(panGesture, tapGesture);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { scale: scale.value },
    ],
  }));

  const navigateTo = (route: string) => {
    setMenuOpen(false);
    setTimeout(() => {
      router.push(route as never);
    }, 150);
  };

  return (
    <>
      <GestureDetector gesture={composedGesture}>
        <Animated.View
          className="absolute z-50 w-14 h-14 rounded-full items-center justify-center"
          style={[
            {
              shadowColor: "#04A8AE",
              shadowOffset: { width: 0, height: 10 },
              shadowOpacity: 0.45,
              shadowRadius: 20,
              elevation: 10,
              position: "absolute",
              top: 0,
              left: 0,
            },
            animatedStyle,
          ]}
        >
          <LinearGradient
            colors={[TealGradient.light, TealGradient.base, TealGradient.dark]}
            start={{ x: 0.2, y: 0 }}
            end={{ x: 0.8, y: 1 }}
            style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, borderRadius: BUTTON_SIZE / 2, overflow: "hidden" }}
          >
            <LinearGradient
              pointerEvents="none"
              colors={["rgba(255,255,255,0.35)", "rgba(255,255,255,0)"]}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
              style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}
            />
          </LinearGradient>
          <Menu size={24} color="#FFFFFF"  style={{ shadowColor: "rgba(0,0,0,0.22)", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 1, shadowRadius: 2, elevation: 2 }} />
        </Animated.View>
      </GestureDetector>

      <Modal
        visible={menuOpen}
        transparent
        animationType="slide"
        onRequestClose={() => setMenuOpen(false)}
      >
        <View className="flex-1 flex-row">
          <Pressable
            className="flex-1 bg-black/50"
            onPress={() => setMenuOpen(false)}
          />

          <View
            className="w-80 bg-white"
            style={{
              paddingTop: insets.top + 16,
              paddingBottom: insets.bottom + 16,
            }}
          >
            <View className="px-6">
              <View className="flex-row items-center justify-between mb-6">
                <Text className="text-2xl font-bold text-gray-900">
                  {t("nav.title")}
                </Text>
                <Pressable
                  className="p-2 rounded-lg"
                  onPress={() => setMenuOpen(false)}
                >
                  <X size={24} color="#5E5F5E" />
                </Pressable>
              </View>

              <TealSurface
                direction="lr"
                radius={12}
                style={{ marginBottom: 24 }}
                contentStyle={{ padding: 12, alignItems: "center" }}
              >
                <Text className="text-white/90 text-sm mb-1">{t("nav.currentPage")}</Text>
                <Text className="text-white font-bold">{currentLabel}</Text>
              </TealSurface>
            </View>

            <ScrollView
              className="flex-1 px-6"
              showsVerticalScrollIndicator={false}
            >
              {categoryOrder.map((category) => {
                const categoryPages = pages.filter(
                  (p) => p.category === category,
                );
                if (categoryPages.length === 0) return null;
                return (
                  <View key={category} className="mb-6">
                    <Text className="text-sm font-bold text-gray-500 uppercase tracking-wide mb-3">
                      {category}
                    </Text>
                    <View className="gap-1">
                      {categoryPages.map((page) => {
                        const isActive = currentLabel === page.label;
                        return (
                          <Pressable
                            key={page.route}
                            onPress={() => navigateTo(page.route)}
                            className={`px-4 py-3 rounded-xl ${isActive ? "bg-[#04A8AE]" : "bg-gray-50"}`}
                          >
                            <Text
                              className={`text-sm ${isActive ? "text-white font-semibold" : "text-gray-700"}`}
                            >
                              {page.label}
                            </Text>
                          </Pressable>
                        );
                      })}
                    </View>
                  </View>
                );
              })}

              <View className="mt-2 mb-4 p-4 bg-gray-50 rounded-xl items-center">
                <Text className="text-sm text-gray-600 mb-1">
                  {t("nav.totalPages", { count: pages.length })}
                </Text>
                <Text className="text-xs text-gray-500">
                  {t("nav.tapToSwitch")}
                </Text>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </>
  );
}
