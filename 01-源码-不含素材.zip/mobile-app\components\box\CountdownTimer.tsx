import React, { useState, useEffect, useRef } from "react";
import { View, Text, type ViewStyle } from "react-native";
import {
  BoxSurfaces, BoxAccent, BoxText, BoxBorders,
  BoxTypography, BoxSpacing, BoxRadius, bs,
} from "@/lib/boxTheme";

interface CountdownTimerProps {
  endTime: number | string | Date;
  label?: string;
  onEnd?: () => void;
  style?: ViewStyle;
}

function pad(n: number) {
  return n.toString().padStart(2, "0");
}

export function CountdownTimer({ endTime, label, onEnd, style }: CountdownTimerProps) {
  const [remaining, setRemaining] = useState(0);
  const onEndRef = useRef(onEnd);
  onEndRef.current = onEnd;

  useEffect(() => {
    const target = typeof endTime === "number"
      ? endTime * (endTime < 1e12 ? 1000 : 1)
      : new Date(endTime).getTime();

    const tick = () => {
      const diff = Math.max(0, target - Date.now());
      setRemaining(diff);
      if (diff <= 0) onEndRef.current?.();
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [endTime]);

  const totalSec = Math.floor(remaining / 1000);
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  const isUrgent = remaining > 0 && remaining < 3600_000;

  const segments = days > 0
    ? [pad(days), pad(hours), pad(mins), pad(secs)]
    : [pad(hours), pad(mins), pad(secs)];

  const accentColor = isUrgent ? BoxAccent.red : BoxText.primary;

  return (
    <View style={[{ alignItems: "center" }, style]}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: BoxSpacing.xs }}>
        {segments.map((seg, i) => (
          <React.Fragment key={i}>
            {i > 0 && (
              <Text style={[BoxTypography.h3, { color: BoxText.tertiary }]}>:</Text>
            )}
            <View style={{
              backgroundColor: BoxSurfaces.elevated,
              borderRadius: BoxRadius.md,
              paddingHorizontal: BoxSpacing.sm,
              paddingVertical: BoxSpacing.xs,
              minWidth: bs(36),
              alignItems: "center",
            }}>
              <Text style={[BoxTypography.h3, {
                color: accentColor,
                fontVariant: ["tabular-nums"],
              }]}>
                {seg}
              </Text>
            </View>
          </React.Fragment>
        ))}
      </View>
      {label && (
        <Text style={[BoxTypography.caption, { color: BoxText.tertiary, marginTop: BoxSpacing.xs }]}>
          {label}
        </Text>
      )}
    </View>
  );
}
