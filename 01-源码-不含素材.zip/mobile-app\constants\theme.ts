/**
 * Design Tokens — 全局设计系统
 * 所有页面必须引用此文件中的常量，禁止硬编码颜色/字号/间距
 *
 * 视觉基调（严格对齐 VivoDraw 设计稿取色）：
 * 纯白底 + 青蓝 Teal 主色 #04A8AE + 纯中性灰阶 + 现代无衬线
 * 说明：brand.red 为历史命名，当前承载 Teal 主色（避免大规模重命名引入风险）
 */

import { Dimensions } from "react-native";

const BASE_WIDTH = 390;

function getScale() {
  const { width } = Dimensions.get("window");
  return Math.min(Math.max(width / BASE_WIDTH, 1), 1.16);
}

/** 响应式缩放：传入设计稿值，返回适配当前屏宽的值 */
export function s(size: number): number {
  return Math.round(size * getScale());
}

// ─── Colors ───────────────────────────────────────────────

export const Colors = {
  // 历史命名 brand.red，实际为 Teal 主色 #04A8AE
  brand: {
    red: "#04A8AE",
    redDark: "#078E93",
    redLight: "#D6F4F5",
  },
  // 主色语义别名（新代码优先使用 primary）
  primary: {
    DEFAULT: "#04A8AE",
    dark: "#078E93",
    light: "#D6F4F5",
    softer: "#ECFBFB",
  },
  accent: {
    gold: "#171A1A",
    orange: "#04A8AE",
    orangeLight: "#D6F4F5",
  },
  home: {
    background: "#FFFFFF",
    surface: "#FFFFFF",
    warmSurface: "#F7F8F8",
    softYellow: "#ECFBFB",
    softPink: "#F3F5F3",
    softRose: "#ECFBFB",
    softPeach: "#F7F8F8",
    text: "#171A1A",
    muted: "#5E5F5E",
    border: "rgba(12,31,31,0.06)",
  },
  luxe: {
    backgroundTop: "#FFFFFF",
    background: "#FFFFFF",
    backgroundBottom: "#FFFFFF",
    surface: "#FFFFFF",
    surfaceRaised: "#FFFFFF",
    surfaceTint: "#F7F8F8",
    hairline: "rgba(12,31,31,0.06)",
    hairlineStrong: "rgba(12,31,31,0.09)",
    ink: "#171A1A",
    inkMuted: "#5E5F5E",
    inkSoft: "#919290",
    glow: "rgba(4, 168, 174, 0.16)",
    gold: "#171A1A",
  },
  neutral: {
    0: "#FFFFFF",
    50: "#F6F8F8",
    100: "#F1F3F3",
    200: "#EBEEEE",
    300: "#C0C0BE",
    400: "#AAAAA8",
    500: "#787976",
    600: "#5E5F5E",
    700: "#4A4A48",
    800: "#2C2E2D",
    900: "#171A1A",
    950: "#0A0B0B",
  },
  success: "#04A8AE",
  warning: "#F59E0B",
  error: "#EF4444",
  info: "#04A8AE",
  ios: {
    blue: "#04A8AE",
    green: "#04A8AE",
    red: "#FF3B30",
    purple: "#04A8AE",
    gray: "#919290",
  },
  overlay: "rgba(0, 0, 0, 0.5)",
  white: "#FFFFFF",
  // ── 轻立体体系（图C：纯白「硬块」卡片浮在极浅冷灰页面底上）──
  screen: {
    // 页面底色：极浅冷灰，几乎是白，仅用于把纯白卡片托出浮起感
    bg: "#F5F7F7",
    // 浮卡本体永远纯白
    card: "#FFFFFF",
    // 浮卡顶部受光高光边
    highlight: "rgba(255,255,255,0.9)",
    // 浮卡极细描边（比阴影更弱，仅用于卡片边缘收口）
    hairline: "rgba(12,31,31,0.055)",
  },
} as const;

// ─── Spacing ──────────────────────────────────────────────

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  "2xl": 24,
  "3xl": 32,
  "4xl": 40,
  "5xl": 48,
  "6xl": 64,
} as const;

// ─── Border Radius ────────────────────────────────────────

export const BorderRadius = {
  sm: 4,
  md: 8,
  lg: 12,
  xl: 16,
  "2xl": 20,
  "3xl": 24,
  "4xl": 32,
  full: 9999,
} as const;

// ─── Shadows ──────────────────────────────────────────────

export const Shadows = {
  // 方向C：旧阴影 token 统一冷青墨柔影（原纯黑 #000 全部收敛），引用处自动变柔
  sm: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 1,
  },
  md: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 3,
  },
  lg: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.075,
    shadowRadius: 18,
    elevation: 5,
  },
  xl: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.09,
    shadowRadius: 24,
    elevation: 8,
  },
  glow: (color: string) => ({
    shadowColor: color,
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.26,
    shadowRadius: 22,
    elevation: 10,
  }),
  warmCard: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.07,
    shadowRadius: 18,
    elevation: 4,
  },
  premiumCard: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.07,
    shadowRadius: 20,
    elevation: 5,
  },
  premiumFloat: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 14 },
    shadowOpacity: 0.1,
    shadowRadius: 28,
    elevation: 8,
  },
  // 主 CTA：teal 同色柔光，像轻轻浮起
  teal: {
    shadowColor: "#04A8AE",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.32,
    shadowRadius: 18,
    elevation: 6,
  },
  // teal 小色块/徽标：更紧凑的同色光晕
  tealBlock: {
    shadowColor: "#04A8AE",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 14,
    elevation: 8,
  },
  // 小图标容器：中性极淡浮影，让图标浮在卡面
  icon: {
    shadowColor: "#171A1A",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 2,
  },
  // ── 轻立体「浮卡」阴影：偏冷的深青墨色 + 柔和下沉扩散，像实体硬块浮起 ──
  raisedSm: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 3,
  },
  raised: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.075,
    shadowRadius: 20,
    elevation: 5,
  },
  raisedLg: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 14 },
    shadowOpacity: 0.1,
    shadowRadius: 30,
    elevation: 10,
  },
  // 悬浮底部导航浮条
  floatingTab: {
    shadowColor: "#0C1F1F",
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.14,
    shadowRadius: 28,
    elevation: 14,
  },
} as const;

// teal 立体渐变三段：受光面(亮) -> 主色 -> 背光面(暗)，全站统一
export const TealGradient = {
  light: "#33C6CC",
  base: "#08AEB4",
  dark: "#07858C",
} as const;

// 立体表面顶部受光高光边
export const SURFACE_HIGHLIGHT = "rgba(255,255,255,0.32)";

// ─── Typography ───────────────────────────────────────────

export const Fonts = {
  sans: "Manrope",
  display: "Manrope",
  mono: "monospace",
  webSans:
    'Manrope, "SF Pro Text", "Segoe UI Variable", "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
  webDisplay:
    'Manrope, "SF Pro Display", "SF Pro Text", "Segoe UI Variable", "Segoe UI", sans-serif',
  webMono:
    '"SF Mono", "Cascadia Code", "JetBrains Mono", Menlo, Consolas, monospace',
} as const;

export const Typography = {
  hero: { fontFamily: Fonts.sans, fontSize: 34, lineHeight: 42, fontWeight: "800" as const },
  h1: { fontFamily: Fonts.sans, fontSize: 32, lineHeight: 40, fontWeight: "800" as const },
  h2: { fontFamily: Fonts.sans, fontSize: 24, lineHeight: 32, fontWeight: "700" as const },
  h3: { fontFamily: Fonts.sans, fontSize: 20, lineHeight: 28, fontWeight: "700" as const },
  h4: { fontFamily: Fonts.sans, fontSize: 18, lineHeight: 24, fontWeight: "700" as const },
  body: { fontFamily: Fonts.sans, fontSize: 16, lineHeight: 24, fontWeight: "400" as const },
  bodySmall: { fontFamily: Fonts.sans, fontSize: 14, lineHeight: 20, fontWeight: "400" as const },
  caption: { fontFamily: Fonts.sans, fontSize: 12, lineHeight: 16, fontWeight: "500" as const },
  tiny: { fontFamily: Fonts.sans, fontSize: 10, lineHeight: 14, fontWeight: "500" as const },
  button: { fontFamily: Fonts.sans, fontSize: 16, lineHeight: 24, fontWeight: "800" as const },
  buttonSmall: { fontFamily: Fonts.sans, fontSize: 14, lineHeight: 20, fontWeight: "700" as const },
  price: { fontFamily: Fonts.sans, fontSize: 24, lineHeight: 32, fontWeight: "800" as const },
  priceSmall: { fontFamily: Fonts.sans, fontSize: 18, lineHeight: 24, fontWeight: "700" as const },
} as const;

// ─── Animation ────────────────────────────────────────────

export const Duration = {
  fast: 120,
  normal: 200,
  slow: 300,
  slower: 500,
} as const;

export const Easing = {
  easeOut: [0.0, 0.0, 0.2, 1.0] as const,
  easeIn: [0.4, 0.0, 1.0, 1.0] as const,
  easeInOut: [0.4, 0.0, 0.2, 1.0] as const,
};

// ─── Hit Slop ─────────────────────────────────────────────

export const HitSlop = { top: 12, right: 12, bottom: 12, left: 12 };

// ─── Icon sizes ───────────────────────────────────────────

export const IconSize = {
  sm: 16,
  md: 20,
  lg: 24,
  xl: 28,
} as const;

// ─── Raised Card（全站统一轻立体白卡，图C语言） ─────────────
// 用法：style={[RAISED.card, RAISED.radius.md, 自定义]}
export const RAISED = {
  // 标准浮卡：纯白底 + 极细收口边 + 柔和下沉阴影
  card: {
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "rgba(12,31,31,0.055)",
  },
  radius: { sm: 16, md: 20, lg: 26, pill: 999 },
} as const;
