import React from "react";
import { ActivityIndicator, Pressable, ScrollView, Text, View } from "react-native";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { Colors } from "@/constants/theme";
import { PageHeader } from "@/components/shared";
import { PointsMallTabBar, pointsMallTabPaddingBottom } from "@/components/points/PointsMallTabBar";
import { useAddPointsCart, useDetailHqjlUnique, useHqjlInfo } from "@/hooks";
import { openCloudBuyCartList } from "@/lib/points/openCloudBuyCart";
import { normalizeImageUrl } from "@/lib/utils";
import { useAuthStore } from "@/store/auth";

const TEAL = Colors.primary.DEFAULT;

export default function ExchangeRecordDetailScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const hid = Number(id) || 0;
  const isLoggedIn = useAuthStore((s) => s.isLoggedIn);
  const addCart = useAddPointsCart();
  const { data, isLoading } = useHqjlInfo(hid);
  const { data: uniqueData } = useDetailHqjlUnique(hid);

  const detail = (data as any)?.data?.detail ?? (data as any)?.detail ?? {};
  const uniqueList: any[] = (uniqueData as any)?.data?.lists ?? (uniqueData as any)?.lists ?? [];
  const codes = uniqueList
    .map((item) => String(item?.unique ?? item?.user_code ?? item ?? ""))
    .filter(Boolean);
  const winCode = String(detail?.zj_unique ?? detail?.unique ?? "");
  const productId = Number(detail?.product_id ?? detail?.pid ?? 0);
  const status = Number(detail?.status ?? 0);
  const name = String(detail?.store_name ?? "");
  const image = normalizeImageUrl(String(detail?.image ?? ""));
  const period = String(detail?.bianhao ?? detail?.hbianhao ?? "");
  const shares = Number(detail?.exchange_num ?? detail?.total_num ?? codes.length ?? 0);

  return (
    <View className="flex-1" style={{ backgroundColor: Colors.screen.bg }}>
      <PageHeader title={t("pointsMall.buyRecords")} />
      {isLoading ? (
        <ActivityIndicator color={TEAL} style={{ marginTop: 40 }} />
      ) : (
        <ScrollView
          contentContainerStyle={{ paddingBottom: pointsMallTabPaddingBottom(insets.bottom) + 16 }}
        >
          <Pressable
            className="flex-row bg-white px-3 py-3"
            onPress={() =>
              productId
                ? router.push({ pathname: "/points/product", params: { id: String(productId) } })
                : undefined
            }
          >
            <View className="w-20 h-20 bg-gray-50 rounded overflow-hidden items-center justify-center mr-3">
              {image ? <Image source={image} style={{ width: 80, height: 80 }} contentFit="contain" /> : null}
            </View>
            <View className="flex-1">
              <Text className="text-xs" style={{ color: TEAL }}>
                {t("pointsMall.periodN", { n: period || "-" })}
              </Text>
              <Text className="text-sm font-bold text-gray-900 mt-0.5" numberOfLines={2}>
                {name || t("pointsMall.pointsProduct")}
              </Text>
              <Text className="text-xs text-gray-500 mt-1">
                {status === 1 ? t("pointsMall.revealedTab") : t("pointsMall.inProgressTab")}
              </Text>
            </View>
          </Pressable>

          <View className="bg-white mt-2 px-3 py-3">
            <Text className="text-sm text-gray-700">
              {t("pointsMall.periodShares")}：
              <Text className="font-bold" style={{ color: TEAL }}>
                {shares || codes.length}
              </Text>
            </Text>
            {detail?.zhongjiang_time ? (
              <Text className="text-xs text-gray-500 mt-1">
                {t("pointsMall.revealTime")}：{detail.zhongjiang_time}
              </Text>
            ) : null}
            {detail?.nickname ? (
              <Text className="text-xs text-gray-500 mt-1">
                {t("pointsMall.winnerLabel")}：{detail.nickname}
              </Text>
            ) : null}
          </View>

          <View className="bg-white mt-2 px-3 py-3">
            <Text className="text-sm font-bold text-gray-900 mb-2">
              {t("pointsMall.luckyCode")} ({codes.length || 0})
            </Text>
            {codes.length === 0 ? (
              <Text className="text-xs text-gray-400">{t("pointsMall.noJoinRecords")}</Text>
            ) : (
              <View className="flex-row flex-wrap" style={{ gap: 6 }}>
                {codes.map((code) => {
                  const win = winCode && code === winCode;
                  return (
                    <View
                      key={code}
                      className="px-2 py-1 rounded"
                      style={{
                        backgroundColor: win ? Colors.primary.light : "#F3F4F6",
                        borderWidth: 1,
                        borderColor: win ? TEAL : "#E5E7EB",
                      }}
                    >
                      <Text
                        className="text-xs font-mono"
                        style={{ color: win ? TEAL : "#374151", fontWeight: win ? "800" : "500" }}
                      >
                        {code}
                      </Text>
                    </View>
                  );
                })}
              </View>
            )}
          </View>

          {productId > 0 ? (
            <Pressable
              className="mx-3 mt-4 h-11 rounded items-center justify-center"
              style={{ backgroundColor: TEAL }}
              onPress={() => {
                if (!isLoggedIn) {
                  router.push("/auth");
                  return;
                }
                addCart.mutate(
                  { productId, cartNum: 1 } as any,
                  { onSettled: () => openCloudBuyCartList(router) },
                );
              }}
            >
              <Text className="text-white font-bold">{t("pointsMall.appendBuy")}</Text>
            </Pressable>
          ) : null}
        </ScrollView>
      )}
      <PointsMallTabBar />
    </View>
  );
}
