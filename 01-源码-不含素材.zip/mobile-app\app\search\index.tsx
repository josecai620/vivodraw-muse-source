import { LuxeIcon, ProductCard } from "@/components/shared";
import { ProductCardSkeleton } from "@/components/ui/Skeleton";
import { Colors, s } from "@/constants/theme";
import type { Product } from "@/lib/api/product";
import { unwrapApiList, unwrapApiPagedList } from "@/lib/api/response";
import { getSearchKeywords, searchProducts } from "@/lib/api/search";
import { getRecentSearches as loadRecentSearches, saveRecentSearches } from "@/lib/searchHistory";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "expo-router";
import { Clock, Search, TrendingUp, X } from "lucide-react-native";
import React, { useCallback, useEffect, useState } from "react";
import { Pressable, RefreshControl, ScrollView, Text, TextInput, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const PRODUCT_SKELETON_KEYS = [
  "search-product-1",
  "search-product-2",
  "search-product-3",
  "search-product-4",
];

export default function SearchScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState("");
  const [submittedQuery, setSubmittedQuery] = useState("");
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  useEffect(() => {
    loadRecentSearches().then(setRecentSearches);
  }, []);

  const queryClient = useQueryClient();
  const [refreshing, setRefreshing] = useState(false);
  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["searchKeywords"] }),
      submittedQuery
        ? queryClient.invalidateQueries({ queryKey: ["searchResults", submittedQuery] })
        : Promise.resolve(),
    ]);
    setRefreshing(false);
  };

  const { data: keywordsRaw } = useQuery({
    queryKey: ["searchKeywords"],
    queryFn: getSearchKeywords,
  });
  const keywords = unwrapApiList<string>(keywordsRaw);

  const { data: resultsRaw, isLoading: searching } = useQuery({
    queryKey: ["searchResults", submittedQuery],
    queryFn: () => searchProducts(submittedQuery, { page: 1, limit: 20 }),
    enabled: submittedQuery.length > 0,
  });
  const results = unwrapApiPagedList<Product>(resultsRaw);

  const handleSearch = useCallback((query: string) => {
    const q = query.trim();
    if (!q) return;
    setSearchQuery(q);
    setSubmittedQuery(q);
    setRecentSearches((prev) => {
      const updated = [q, ...prev.filter((x) => x !== q)].slice(0, 10);
      saveRecentSearches(updated);
      return updated;
    });
  }, []);

  const clearRecentSearchesHandler = useCallback(() => {
    setRecentSearches([]);
    saveRecentSearches([]);
  }, []);

  const removeRecentItem = useCallback((term: string) => {
    setRecentSearches((prev) => {
      const updated = prev.filter((x) => x !== term);
      saveRecentSearches(updated);
      return updated;
    });
  }, []);

  const clearSearch = () => {
    setSearchQuery("");
    setSubmittedQuery("");
  };

  const showResults = submittedQuery.length > 0;

  return (
    <View className="flex-1" style={{ paddingTop: insets.top, backgroundColor: Colors.screen.bg }}>
      <View
        style={{
          backgroundColor: "#FFFFFF",
          borderBottomWidth: 1,
          borderBottomColor: Colors.screen.hairline,
          shadowColor: "#0C1F1F",
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.05,
          shadowRadius: 10,
          elevation: 3,
        }}
      >
        <View className="h-14 px-4 flex-row items-center gap-3">
          <Pressable onPress={() => router.back()}>
            <LuxeIcon glyph="back" tone="neutral" variant="soft" size={36} iconSize={24} />
          </Pressable>
          <View
            className="flex-1 flex-row items-center h-10 rounded-2xl px-2"
            style={{ backgroundColor: Colors.luxe.surfaceRaised, borderWidth: 1, borderColor: Colors.luxe.hairline }}
          >
            <LuxeIcon glyph="search" tone="neutral" variant="plain" size={28} iconSize={22} />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Search products..."
              placeholderTextColor={Colors.neutral[400]}
              className="flex-1 ml-2 text-sm"
              style={{ color: Colors.luxe.ink, fontWeight: "500" }}
              autoFocus
              returnKeyType="search"
              onSubmitEditing={() => handleSearch(searchQuery)}
            />
            {searchQuery.length > 0 && (
              <Pressable onPress={clearSearch}>
                <LuxeIcon Icon={X} tone="neutral" variant="soft" size={26} iconSize={13} />
              </Pressable>
            )}
          </View>
        </View>
      </View>

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#04A8AE" />
        }
      >
        {!showResults ? (
          <>
            {recentSearches.length > 0 && (
              <View className="px-4 pt-5">
                <View className="flex-row items-center justify-between mb-3">
                  <Text className="text-sm font-semibold text-gray-900">Recent Searches</Text>
                  <Pressable onPress={clearRecentSearchesHandler}>
                    <Text className="text-xs" style={{ color: Colors.brand.red }}>
                      Clear All
                    </Text>
                  </Pressable>
                </View>
                {recentSearches.map((term) => (
                  <Pressable
                    key={term}
                    className="flex-row items-center gap-3 py-2.5"
                    onPress={() => handleSearch(term)}
                  >
                    <Clock size={16} color={Colors.neutral[400]} />
                    <Text className="flex-1 text-sm" style={{ color: Colors.neutral[700] }}>
                      {term}
                    </Text>
                    <Pressable hitSlop={8} onPress={() => removeRecentItem(term)}>
                      <X size={14} color={Colors.neutral[400]} />
                    </Pressable>
                  </Pressable>
                ))}
              </View>
            )}

            {keywords.length > 0 && (
              <View className="px-4 pt-5">
                <Text className="text-sm font-semibold text-gray-900 mb-3">Hot Searches</Text>
                <View className="flex-row flex-wrap gap-2">
                  {keywords.slice(0, 12).map((kw: string) => (
                    <Pressable
                      key={kw}
                      className="px-3 py-1.5 rounded-full"
                      style={{ backgroundColor: "#F1F3F3" }}
                      onPress={() => handleSearch(kw)}
                    >
                      <Text className="text-sm" style={{ color: Colors.neutral[700] }}>
                        {kw}
                      </Text>
                    </Pressable>
                  ))}
                </View>
              </View>
            )}

            <View className="px-4 pt-5">
              <Text className="text-sm font-semibold text-gray-900 mb-3">Popular</Text>
              {["Electronics", "Fashion", "Home & Garden", "Sports"].map((item) => (
                <Pressable
                  key={item}
                  className="flex-row items-center gap-3 py-2.5"
                  onPress={() => handleSearch(item)}
                >
                  <TrendingUp size={16} color={Colors.brand.red} />
                  <Text className="flex-1 text-sm" style={{ color: Colors.neutral[700] }}>
                    {item}
                  </Text>
                </Pressable>
              ))}
            </View>
          </>
        ) : (
          <View className="px-4 pt-4">
            {searching ? (
              <View className="flex-row flex-wrap justify-between">
                {PRODUCT_SKELETON_KEYS.map((key) => (
                  <View key={key} style={{ width: "48.5%", marginBottom: 8 }}>
                    <ProductCardSkeleton />
                  </View>
                ))}
              </View>
            ) : results.length === 0 ? (
              <View className="items-center justify-center py-12">
                <Search size={s(40)} color={Colors.neutral[300]} strokeWidth={1.8} style={{ marginBottom: s(12) }} />
                <Text className="text-lg font-semibold" style={{ color: Colors.neutral[700] }}>
                  No results
                </Text>
                <Text className="text-sm mt-1" style={{ color: Colors.neutral[400] }}>
                  Try a different search term
                </Text>
              </View>
            ) : (
              <>
                <Text className="text-sm mb-3" style={{ color: Colors.neutral[500] }}>
                  {results.length} results for "{submittedQuery}"
                </Text>
                <View className="flex-row flex-wrap justify-between">
                  {results.map((item) => (
                    <ProductCard
                      key={item.id}
                      id={item.id}
                      image={item.image}
                      name={item.store_name}
                      price={item.price}
                      originalPrice={item.ot_price}
                      sales={item.sales}
                      giveIntegral={Number(item.give_integral) || 0}
                      isHot={item.is_hot === 1}
                      isNew={item.is_new === 1}
                      layout="grid"
                    />
                  ))}
                </View>
              </>
            )}
          </View>
        )}
        <View className="h-8" />
      </ScrollView>
    </View>
  );
}
