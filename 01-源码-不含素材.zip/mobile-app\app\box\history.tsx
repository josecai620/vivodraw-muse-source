/**
 * 开盒历史 - FlatList with infinite scroll, timeline style, stats card
 */
import React, { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Pressable,
  FlatList,
  Text,
  View,
  ActivityIndicator,
} from "react-native";
import { useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import { Image } from "expo-image";
import { Clock, Trophy, Flame, Star, Package } from "lucide-react-native";
import {
  BoxHeader,
  RarityBadge,
  BoxActionButton,
  BoxEmptyState,
  BoxProgressBar,
  BoxTabBar,
  CountdownTimer,
} from "@/components/box";
import {
  BoxSurfaces,
  BoxAccent,
  BoxText,
  BoxBorders,
  BoxGradients,
  BoxTypography,
  BoxSpacing,
  BoxRadius,
  BoxShadows,
  getRarityTier,
  bs,
} from "@/lib/boxTheme";
import { useBoxLog } from "@/hooks";

type FormattedHistoryItem = {
  id: number;
  itemName: string;
  itemImage: string;
  rarity: string;
  boxName: string;
  time: string;
};

export default function BoxHistoryScreen() {
  const { t } = useTranslation();
  const router = useRouter();
  const [page, setPage] = useState(1);
  const [allRecords, setAllRecords] = useState<any[]>([]);

  const {
    data: historyRecords,
    isLoading,
    isFetching,
  } = useBoxLog({
    page,
    limit: 20,
  });

  const rawList = historyRecords || [];

  useEffect(() => {
    if (rawList.length === 0 && page > 1) return;
    setAllRecords((prev) => (page === 1 ? rawList : [...prev, ...rawList]));
  }, [rawList, page]);

  const hasMore = rawList.length >= 20;

  const loadMore = useCallback(() => {
    if (!isFetching && hasMore) setPage((p) => p + 1);
  }, [isFetching, hasMore]);

  const formattedHistory: FormattedHistoryItem[] = allRecords.map(
    (record: Record<string, unknown>) => ({
      id: Number(record.id ?? 0),
      itemName: String(record.itemName ?? t("history.fallbackItem")),
      itemImage: record.itemImage ? String(record.itemImage) : "",
      rarity: String(record.rarity ?? "common"),
      boxName: String(record.boxName ?? t("history.fallbackBox")),
      time: String(record.openTime ?? record.time ?? t("history.fallbackTime")),
    })
  );

  const totalOpened = formattedHistory.length;
  const epicCount = formattedHistory.filter(
    (r: { rarity: string }) => r.rarity === "epic"
  ).length;
  const legendaryCount = formattedHistory.filter(
    (r: { rarity: string }) => r.rarity === "legendary"
  ).length;

  const renderItem = useCallback(
    ({
      item: record,
      index,
    }: {
      item: {
        id: number;
        itemName: string;
        itemImage: string;
        rarity: string;
        boxName: string;
        time: string;
      };
      index: number;
    }) => {
      const rarityConfig = getRarityTier(record.rarity);
      return (
        <View
          style={{ flexDirection: "row", marginBottom: BoxSpacing.lg }}
        >
          {/* Timeline dot */}
          <View
            style={{
              alignItems: "center",
              marginRight: BoxSpacing.lg,
            }}
          >
            <LinearGradient
              colors={rarityConfig.gradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={{
                width: bs(40),
                height: bs(40),
                borderRadius: bs(20),
                alignItems: "center",
                justifyContent: "center",
                ...BoxShadows.glow(rarityConfig.color),
              }}
            >
              {/^https?:\/\//i.test(record.itemImage) ? (
                <Image source={{ uri: record.itemImage }} style={{ width: bs(40), height: bs(40), borderRadius: bs(20) }} contentFit="cover" />
              ) : (
                <Package size={bs(18)} color="#fff" strokeWidth={1.6} />
              )}
            </LinearGradient>
            {index < formattedHistory.length - 1 && (
              <View
                style={{
                  width: 2,
                  flex: 1,
                  marginTop: BoxSpacing.sm,
                  backgroundColor: BoxBorders.default,
                  minHeight: bs(48),
                }}
              />
            )}
          </View>

          {/* Card */}
          <View
            style={{
              flex: 1,
              borderRadius: BoxRadius.xl,
              overflow: "hidden",
              marginBottom: BoxSpacing.sm,
              backgroundColor: BoxSurfaces.card,
              borderWidth: 1,
              borderColor: BoxBorders.default,
              ...BoxShadows.card,
            }}
          >
            <View
              style={{
                padding: BoxSpacing.lg,
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: BoxSpacing.md,
                  flex: 1,
                }}
              >
                <View
                  style={{
                    width: bs(48),
                    height: bs(48),
                    borderRadius: BoxRadius.lg,
                    alignItems: "center",
                    justifyContent: "center",
                    backgroundColor: BoxSurfaces.deep,
                    borderWidth: 1,
                    borderColor: rarityConfig.borderColor,
                  }}
                >
                  {/^https?:\/\//i.test(record.itemImage) ? (
                    <Image source={{ uri: record.itemImage }} style={{ width: bs(48), height: bs(48), borderRadius: BoxRadius.lg }} contentFit="cover" />
                  ) : (
                    <Package size={bs(22)} color={BoxAccent.gold} strokeWidth={1.6} />
                  )}
                </View>
                <View style={{ flex: 1 }}>
                  <Text
                    style={[
                      BoxTypography.bodyBold,
                      { color: BoxText.primary },
                    ]}
                    numberOfLines={1}
                  >
                    {record.itemName}
                  </Text>
                  <RarityBadge
                    tier={record.rarity}
                    size="sm"
                    style={{ marginTop: BoxSpacing.xs }}
                  />
                </View>
              </View>
              <Text
                style={[BoxTypography.caption, { color: BoxText.tertiary }]}
              >
                {record.time}
              </Text>
            </View>
            <View
              style={{
                paddingHorizontal: BoxSpacing.lg,
                paddingVertical: BoxSpacing.sm,
                borderTopWidth: 1,
                borderTopColor: BoxBorders.subtle,
              }}
            >
              <Text
                style={[BoxTypography.caption, { color: BoxText.tertiary }]}
              >
                {t("history.from", { name: record.boxName })}
              </Text>
            </View>
          </View>
        </View>
      );
    },
    [formattedHistory.length, t]
  );

  const StatsHeader = () => (
    <View style={{ marginBottom: BoxSpacing.lg }}>
      <LinearGradient
        colors={BoxGradients.purpleDeep}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{
          borderRadius: BoxRadius.xl,
          padding: BoxSpacing.xl,
          overflow: "hidden",
          ...BoxShadows.glow(BoxAccent.purple),
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <View style={{ alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: BoxSpacing.xs,
                marginBottom: BoxSpacing.xs,
              }}
            >
              <Star size={bs(12)} color="rgba(255,255,255,0.6)" />
              <Text
                style={[
                  BoxTypography.caption,
                  { color: "rgba(255,255,255,0.7)" },
                ]}
              >
                {t("history.totalOpens")}
              </Text>
            </View>
            <Text
              style={[BoxTypography.hero, { color: BoxText.primary }]}
            >
              {totalOpened}
            </Text>
          </View>
          <View style={{ alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: BoxSpacing.xs,
                marginBottom: BoxSpacing.xs,
              }}
            >
              <Flame size={bs(12)} color="rgba(255,255,255,0.6)" />
              <Text
                style={[
                  BoxTypography.caption,
                  { color: "rgba(255,255,255,0.7)" },
                ]}
              >
                {t("history.epicPlus")}
              </Text>
            </View>
            <Text
              style={[BoxTypography.hero, { color: BoxText.primary }]}
            >
              {epicCount + legendaryCount}
            </Text>
          </View>
          <View style={{ alignItems: "center" }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: BoxSpacing.xs,
                marginBottom: BoxSpacing.xs,
              }}
            >
              <Trophy size={bs(12)} color={BoxAccent.goldLight} />
              <Text
                style={[
                  BoxTypography.caption,
                  { color: "rgba(255,255,255,0.7)" },
                ]}
              >
                {t("rarity.legendary")}
              </Text>
            </View>
            <Text
              style={[BoxTypography.hero, { color: BoxAccent.goldLight }]}
            >
              {legendaryCount}
            </Text>
          </View>
          <Package size={bs(34)} color="#fff" strokeWidth={1.5} />
        </View>
      </LinearGradient>

      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          gap: BoxSpacing.sm,
          marginTop: BoxSpacing.lg,
        }}
      >
        <View
          style={{
            width: bs(32),
            height: bs(32),
            borderRadius: BoxRadius.sm,
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: BoxAccent.goldDim,
          }}
        >
          <Clock size={bs(16)} color={BoxAccent.gold} />
        </View>
        <Text style={[BoxTypography.h2, { color: BoxText.primary }]}>
          {t("history.timeline")}
        </Text>
      </View>
    </View>
  );

  const ListFooter = () => {
    if (isFetching && page > 1) {
      return (
        <View
          style={{ alignItems: "center", paddingVertical: BoxSpacing.lg }}
        >
          <ActivityIndicator size="small" color={BoxAccent.gold} />
        </View>
      );
    }
    if (!hasMore && allRecords.length > 0) {
      return (
        <Text
          style={[
            BoxTypography.caption,
            {
              color: BoxText.tertiary,
              textAlign: "center",
              paddingVertical: BoxSpacing.lg,
            },
          ]}
        >
          {t("history.noMore")}
        </Text>
      );
    }
    return null;
  };

  return (
    <View style={{ flex: 1, backgroundColor: BoxSurfaces.void }}>
      <BoxHeader title={t("history.title")} />

      {isLoading && page === 1 ? (
        <View
          style={{ flex: 1, alignItems: "center", justifyContent: "center" }}
        >
          <ActivityIndicator size="large" color={BoxAccent.gold} />
          <Text
            style={[
              BoxTypography.body,
              { color: BoxText.secondary, marginTop: BoxSpacing.lg },
            ]}
          >
            {t("common.loading")}
          </Text>
        </View>
      ) : formattedHistory.length === 0 ? (
        <BoxEmptyState
          icon={<Clock size={bs(48)} color={BoxText.tertiary} />}
          title={t("history.empty")}
          style={{ flex: 1 }}
        />
      ) : (
        <FlatList
          data={formattedHistory}
          keyExtractor={(item) => String(item.id)}
          renderItem={renderItem}
          ListHeaderComponent={StatsHeader}
          ListFooterComponent={ListFooter}
          contentContainerStyle={{
            padding: BoxSpacing.lg,
            paddingBottom: bs(32),
          }}
          onEndReached={loadMore}
          onEndReachedThreshold={0.3}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}
