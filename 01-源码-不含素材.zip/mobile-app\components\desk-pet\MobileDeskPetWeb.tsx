import React, { useEffect, useMemo, useRef, useState } from "react";
import { Platform } from "react-native";
import { usePathname, useRouter } from "expo-router";
import { unwrapApiData } from "@/lib/api/response";
import { getPetDialogue, type PetDialogueResult, type PetDialogueTrigger } from "@/lib/api/user";
import { useAuthStore } from "@/store/auth";

type DeskPetActionId = "idle" | "greet" | "guide" | "angry" | "happy";

type DeskPetClip = {
  src: string;
  chromaKeyHex: string;
};

type DeskPet = {
  id: string;
  name: string;
  actions: Record<DeskPetActionId, DeskPetClip>;
};

type DeskPetPosition = {
  x: number;
  y: number;
};

type RgbColor = {
  red: number;
  green: number;
  blue: number;
};

type PixelBounds = {
  left: number;
  top: number;
  right: number;
  bottom: number;
};

const PET_SIZE = 108;
const PET_COLLAPSED_SIZE = 70;
const AUTO_COLLAPSE_MS = 9000;
const DESK_PET_Z_INDEX = 5000;
const STORAGE_KEYS = {
  hidden: "eccomall-desk-pet-hidden",
  position: "eccomall-desk-pet-position",
} as const;

const MUTED_ROUTE_PATTERNS = [
  /^\/auth/,
  /^\/login/,
  /^\/register/,
  /^\/checkout/,
  /^\/pay/,
  /^\/address/,
  /^\/profile\/address/,
  /^\/profile\/payment/,
  /^\/profile\/wallet/,
  /^\/orders\/refund/,
  /^\/box\/.*\/opening/,
  /^\/reveal/,
  /^\/farm/,
];
const ACTIONS: DeskPetActionId[] = ["greet", "guide", "angry", "happy"];
const IDLE_GREETING_MS = { min: 70_000, max: 115_000 } as const;
const DISMISS_COOLDOWN_MS = 90_000;

type MobileRecommendation = {
  title: string;
  copy: string;
  reward: string;
  cta: string;
  route: string;
  taskKey: string;
};

function parseHexColor(hex: string): RgbColor {
  const normalized = hex.replace("#", "");
  return {
    red: Number.parseInt(normalized.slice(0, 2), 16),
    green: Number.parseInt(normalized.slice(2, 4), 16),
    blue: Number.parseInt(normalized.slice(4, 6), 16),
  };
}

function chromaDistance(red: number, green: number, blue: number, key: RgbColor) {
  return Math.sqrt((red - key.red) ** 2 + (green - key.green) ** 2 + (blue - key.blue) ** 2);
}

function cyanDominant(red: number, green: number, blue: number) {
  return blue > red + 14 && green > red + 14 && blue + green > 164;
}

function clearChromaKey(imageData: ImageData, key: RgbColor) {
  const data = imageData.data;
  const hardCutoff = 92;
  const softCutoff = 132;
  for (let index = 0; index < data.length; index += 4) {
    const red = data[index]!;
    const green = data[index + 1]!;
    const blue = data[index + 2]!;
    const distance = chromaDistance(red, green, blue, key);
    const isCyan = cyanDominant(red, green, blue);
    const cutoff = isCyan ? softCutoff + 18 : softCutoff;
    if (distance <= hardCutoff) {
      data[index + 3] = 0;
      continue;
    }
    if (distance < cutoff) {
      const ratio = (distance - hardCutoff) / (softCutoff - hardCutoff);
      data[index + 3] = Math.round(data[index + 3]! * Math.max(0, Math.min(1, ratio)));
      const edgeRatio = Math.max(0, Math.min(1, (Math.min(distance, softCutoff) - hardCutoff) / (softCutoff - hardCutoff)));
      data[index + 1] = Math.round(green * (0.62 + edgeRatio * 0.38));
      data[index + 2] = Math.round(blue * (0.56 + edgeRatio * 0.44));
      if (isCyan && distance >= softCutoff) data[index + 3] = Math.round(data[index + 3]! * 0.35);
    }
  }
}

function clearConnectedBackground(imageData: ImageData, key: RgbColor) {
  const { data, width, height } = imageData;
  const visited = new Uint8Array(width * height);
  const queue: number[] = [];
  const canClear = (pixel: number) => {
    const index = pixel * 4;
    const red = data[index]!;
    const green = data[index + 1]!;
    const blue = data[index + 2]!;
    const alpha = data[index + 3]!;
    return alpha < 12 || chromaDistance(red, green, blue, key) < 152 || cyanDominant(red, green, blue) || red + green + blue < 38;
  };
  const enqueue = (pixel: number) => {
    if (visited[pixel] || !canClear(pixel)) return;
    visited[pixel] = 1;
    queue.push(pixel);
  };
  for (let x = 0; x < width; x += 1) {
    enqueue(x);
    enqueue((height - 1) * width + x);
  }
  for (let y = 1; y < height - 1; y += 1) {
    enqueue(y * width);
    enqueue(y * width + width - 1);
  }
  for (let cursor = 0; cursor < queue.length; cursor += 1) {
    const pixel = queue[cursor]!;
    data[pixel * 4 + 3] = 0;
    const x = pixel % width;
    const y = Math.floor(pixel / width);
    if (x > 0) enqueue(pixel - 1);
    if (x < width - 1) enqueue(pixel + 1);
    if (y > 0) enqueue(pixel - width);
    if (y < height - 1) enqueue(pixel + width);
  }
}

function alphaBounds(imageData: ImageData): PixelBounds | null {
  const { data, width, height } = imageData;
  let left = width;
  let top = height;
  let right = -1;
  let bottom = -1;
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (data[(y * width + x) * 4 + 3]! < 18) continue;
      left = Math.min(left, x);
      top = Math.min(top, y);
      right = Math.max(right, x + 1);
      bottom = Math.max(bottom, y + 1);
    }
  }
  if (right <= left || bottom <= top) return null;
  return { left, top, right, bottom };
}

function expandBounds(bounds: PixelBounds, width: number, height: number, padding: number): PixelBounds {
  return {
    left: Math.max(0, bounds.left - padding),
    top: Math.max(0, bounds.top - padding),
    right: Math.min(width, bounds.right + padding),
    bottom: Math.min(height, bounds.bottom + padding),
  };
}

function trimTransparentOutsideBounds(imageData: ImageData, bounds: PixelBounds) {
  const { data, width, height } = imageData;
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      if (x >= bounds.left && x < bounds.right && y >= bounds.top && y < bounds.bottom) continue;
      data[(y * width + x) * 4 + 3] = 0;
    }
  }
}

function unionBounds(current: PixelBounds | null, next: PixelBounds): PixelBounds {
  if (!current) return next;
  return {
    left: Math.min(current.left, next.left),
    top: Math.min(current.top, next.top),
    right: Math.max(current.right, next.right),
    bottom: Math.max(current.bottom, next.bottom),
  };
}

function drawFittedPetFrame(context: CanvasRenderingContext2D, sourceCanvas: HTMLCanvasElement, bounds: PixelBounds) {
  const target = context.canvas;
  const sourceWidth = bounds.right - bounds.left;
  const sourceHeight = bounds.bottom - bounds.top;
  const scale = Math.min((target.width * 0.72) / sourceWidth, (target.height * 0.72) / sourceHeight);
  const drawWidth = sourceWidth * scale;
  const drawHeight = sourceHeight * scale;
  const drawX = (target.width - drawWidth) / 2;
  const drawY = target.height - drawHeight - target.height * 0.02;
  context.clearRect(0, 0, target.width, target.height);
  context.drawImage(sourceCanvas, bounds.left, bounds.top, sourceWidth, sourceHeight, drawX, drawY, drawWidth, drawHeight);
}

const DESK_PETS: DeskPet[] = [
  pet("panda", "Panda", "#0FF2F9", "#08FDFD", "#07FDFD", "#09FDED", "#07F9C4"),
  pet("cat", "Cat", "#0EF6F9", "#06FEFD", "#03FEFD", "#0DFBB9", "#06E985"),
  pet("white-snake", "White Snake", "#2CCAD1", "#2BC9D1", "#2CC9CF", "#2DC9CF", "#2EC9CF"),
  pet("squirrel", "Squirrel", "#05FDFE", "#03FEFC", "#05FDFE", "#0CE955", "#0DE850"),
  pet("white-fox", "White Fox", "#25D4DA", "#25D6DC", "#2ACFD2", "#24D5DB", "#23D5DB"),
  pet("dog", "Dog", "#05FDFE", "#02FDFD", "#02FDFE", "#07FBB0", "#08F8A9"),
  pet("fox", "Fox", "#11F5FB", "#07FDFE", "#03FEFE", "#06FDF3", "#0AE45B"),
  pet("rabbit", "Rabbit", "#12F6FA", "#06FCFE", "#03FEFE", "#09E980", "#06E57D"),
  pet("niffler", "Niffler", "#07E9F8", "#07E9F8", "#08E8F7", "#08E8F6", "#02EED9"),
];

function pet(
  id: string,
  name: string,
  idle: string,
  greet: string,
  guide: string,
  angry: string,
  happy: string,
): DeskPet {
  return {
    id,
    name,
    actions: {
      idle: { src: `/desk-pets/v1/${id}/idle.webm`, chromaKeyHex: idle },
      greet: { src: `/desk-pets/v1/${id}/greet.webm`, chromaKeyHex: greet },
      guide: { src: `/desk-pets/v1/${id}/guide.webm`, chromaKeyHex: guide },
      angry: { src: `/desk-pets/v1/${id}/angry.webm`, chromaKeyHex: angry },
      happy: { src: `/desk-pets/v1/${id}/happy.webm`, chromaKeyHex: happy },
    },
  };
}

function defaultPosition() {
  return {
    x: Math.max(12, window.innerWidth - PET_COLLAPSED_SIZE - 18),
    y: Math.max(96, window.innerHeight - PET_COLLAPSED_SIZE - 92),
  };
}

function clampPosition(position: DeskPetPosition, size: number) {
  const bottomInset = window.innerWidth <= 900 ? 96 : 16;
  return {
    x: Math.min(Math.max(10, position.x), Math.max(10, window.innerWidth - size - 10)),
    y: Math.min(Math.max(84, position.y), Math.max(84, window.innerHeight - size - bottomInset)),
  };
}

function routeMuted(pathname: string) {
  return MUTED_ROUTE_PATTERNS.some((pattern) => pattern.test(pathname));
}

function routeRecommendation(pathname: string): MobileRecommendation | null {
  if (pathname.startsWith("/points")) {
    return { title: "去盲盒看看", copy: "积分看完了，可以顺手抽一次。", reward: "抽盒", cta: "去盲盒", route: "/box", taskKey: "route-box" };
  }
  if (pathname.startsWith("/box") || pathname.startsWith("/reveal")) {
    return { title: "先攒点积分", copy: "从这里开始，今天流程最顺。", reward: "积分", cta: "去积分", route: "/points", taskKey: "route-points" };
  }
  if (pathname.startsWith("/pet")) {
    return { title: "看看农场", copy: "有空可以回农场收一轮。", reward: "回访", cta: "去农场", route: "/farm", taskKey: "route-farm" };
  }
  if (pathname.startsWith("/farm")) {
    return { title: "回宠物舱", copy: "收完这一轮，看看亲密反馈。", reward: "陪伴", cta: "回宠物", route: "/pet", taskKey: "route-pet" };
  }
  if (pathname.startsWith("/mine")) {
    return { title: "补点积分", copy: "矿洞看完了，顺手看看签到。", reward: "签到", cta: "去积分", route: "/points", taskKey: "route-points" };
  }
  if (pathname === "/" || pathname.startsWith("/product")) {
    return { title: "看今日奖励", copy: "有可用积分和兑换入口。", reward: "每日", cta: "查看", route: "/points", taskKey: "route-points" };
  }
  return null;
}

function randomRecommendation(pathname: string, seed: number): MobileRecommendation {
  const currentRoute = pathname === "/" ? "/" : pathname.replace(/\/$/, "");
  const tasks: MobileRecommendation[] = [
    { title: "去领今日积分", copy: "有空顺手看一眼签到入口。", reward: "轻任务", cta: "去积分", route: "/points", taskKey: "random-points" },
    { title: "看看农场", copy: "可能有地块可以收，别断节奏。", reward: "回访", cta: "去农场", route: "/farm", taskKey: "random-farm" },
    { title: "瞄一眼盲盒", copy: "今天可以轻看一下，不着急抽。", reward: "探索", cta: "去看看", route: "/box", taskKey: "random-box" },
    { title: "回宠物舱", copy: "看看今天的互动和成长反馈。", reward: "陪伴", cta: "回宠物", route: "/pet", taskKey: "random-pet" },
    { title: "矿洞巡一下", copy: "节点和倒计时看一眼就好。", reward: "短回访", cta: "去矿洞", route: "/mine", taskKey: "random-mine" },
  ];
  const candidates = tasks.filter((task) => task.route !== currentRoute);
  return candidates[Math.abs(seed) % candidates.length] ?? tasks[0]!;
}

function inferDialogueTrigger(pathname: string, recommendation: MobileRecommendation): PetDialogueTrigger {
  if (recommendation.taskKey.includes("pet") || pathname.startsWith("/pet")) return "story";
  if (recommendation.taskKey.includes("farm") || recommendation.taskKey.includes("mine") || recommendation.taskKey.includes("box")) return "game_guide";
  if (recommendation.taskKey.includes("points") || recommendation.taskKey.includes("checkin")) return "daily_task";
  return "reminder";
}

function pickDefaultPet() {
  return DESK_PETS.find((candidate) => candidate.id === "dog") ?? DESK_PETS[0]!;
}

function pickPetFromServerFields(user: unknown) {
  const maybeUser = user as { pet?: { code?: string; name?: string; species?: string; pet_code?: string; pet_name?: string } } | null;
  const haystack =
    `${maybeUser?.pet?.code ?? ""} ${maybeUser?.pet?.pet_code ?? ""} ${maybeUser?.pet?.name ?? ""} ${maybeUser?.pet?.pet_name ?? ""} ${maybeUser?.pet?.species ?? ""}`.toLowerCase();
  if (!haystack.trim()) return pickDefaultPet();
  const candidates: Array<[string, string[]]> = [
    ["panda", ["熊猫", "panda"]],
    ["cat", ["猫", "cat"]],
    ["white-snake", ["白蛇", "snake", "white-snake"]],
    ["squirrel", ["松鼠", "squirrel"]],
    ["white-fox", ["白狐", "white fox", "white-fox"]],
    ["dog", ["狗", "柯基", "dog", "corgi"]],
    ["fox", ["狐狸", "fox"]],
    ["rabbit", ["兔", "rabbit"]],
    ["niffler", ["嗅嗅", "niffler"]],
  ];
  const matched = candidates.find(([, keywords]) => keywords.some((keyword) => haystack.includes(keyword)));
  if (!matched) return pickDefaultPet();
  return DESK_PETS.find((candidate) => candidate.id === matched[0]) ?? pickDefaultPet();
}

export default function MobileDeskPetWeb() {
  const pathname = usePathname();
  const router = useRouter();
  const user = useAuthStore((state) => state.user);
  const authToken = useAuthStore((state) => state.token);
  const isHydrated = useAuthStore((state) => state.isHydrated);
  const pet = useMemo(() => pickPetFromServerFields(user), [user]);
  const [action, setAction] = useState<DeskPetActionId>("idle");
  const [token, setToken] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [position, setPosition] = useState<DeskPetPosition | null>(null);
  const dragRef = useRef<{ pointerId: number; startX: number; startY: number; originX: number; originY: number; moved: boolean } | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [canvasAspectRatio, setCanvasAspectRatio] = useState(1);
  const [randomTaskSeed, setRandomTaskSeed] = useState<number | null>(null);
  const [aiDialogue, setAiDialogue] = useState<PetDialogueResult | null>(null);
  const dismissedUntilRef = useRef(0);
  const activeClip = pet.actions[action];
  const recommendation = useMemo(
    () => (randomTaskSeed === null ? routeRecommendation(pathname) : randomRecommendation(pathname, randomTaskSeed)),
    [pathname, randomTaskSeed],
  );
  const muted = routeMuted(pathname);

  const navigateToRecommendation = (route: string) => {
    const gameRoute = route === "/mine" ? "/mine/mobile" : route;
    if (Platform.OS === "web" && (gameRoute === "/farm" || gameRoute === "/pet" || gameRoute.startsWith("/mine"))) {
      window.location.assign(gameRoute);
      return;
    }
    router.push(gameRoute as never);
  };

  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    const savedHidden = window.localStorage.getItem(STORAGE_KEYS.hidden) === "1";
    setHidden(savedHidden);
    const savedPosition = window.localStorage.getItem(STORAGE_KEYS.position);
    if (savedPosition) {
      try {
        setPosition(clampPosition(JSON.parse(savedPosition) as DeskPetPosition, PET_COLLAPSED_SIZE));
        return;
      } catch {
        window.localStorage.removeItem(STORAGE_KEYS.position);
      }
    }
    setPosition(defaultPosition());
  }, []);

  useEffect(() => {
    setRandomTaskSeed(null);
  }, [pathname]);

  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    const syncPosition = () => {
      setPosition((current) => (current ? clampPosition(current, expanded ? PET_SIZE : PET_COLLAPSED_SIZE) : defaultPosition()));
    };
    window.addEventListener("resize", syncPosition);
    window.visualViewport?.addEventListener("resize", syncPosition);
    return () => {
      window.removeEventListener("resize", syncPosition);
      window.visualViewport?.removeEventListener("resize", syncPosition);
    };
  }, [expanded]);

  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    setPosition((current) => (current ? clampPosition(current, expanded ? PET_SIZE : PET_COLLAPSED_SIZE) : current));
  }, [expanded]);

  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    const onMove = (event: PointerEvent) => {
      const current = dragRef.current;
      if (!current || current.pointerId !== event.pointerId) return;
      const deltaX = event.clientX - current.startX;
      const deltaY = event.clientY - current.startY;
      if (!current.moved && Math.abs(deltaX) + Math.abs(deltaY) > 6) {
        current.moved = true;
        setDragging(true);
      }
      if (!current.moved) return;
      event.preventDefault();
      const nextPosition = clampPosition({ x: current.originX + deltaX, y: current.originY + deltaY }, expanded ? PET_SIZE : PET_COLLAPSED_SIZE);
      setPosition(nextPosition);
      window.localStorage.setItem(STORAGE_KEYS.position, JSON.stringify(nextPosition));
    };
    const onUp = (event: PointerEvent) => {
      const current = dragRef.current;
      if (!current || current.pointerId !== event.pointerId) return;
      dragRef.current = null;
      if (current.moved) {
        setDragging(false);
        return;
      }
      if (!expanded) {
        setExpanded(true);
        return;
      }
      setAction(ACTIONS[Math.floor(Math.random() * ACTIONS.length)]!);
      setToken((value) => value + 1);
    };
    window.addEventListener("pointermove", onMove, { passive: false });
    window.addEventListener("pointerup", onUp);
    window.addEventListener("pointercancel", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
      window.removeEventListener("pointercancel", onUp);
    };
  }, [expanded]);

  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    const onHappy = () => {
      setExpanded(true);
      setAction("happy");
      setToken((value) => value + 1);
    };
    window.addEventListener("deskpet:happy", onHappy);
    return () => window.removeEventListener("deskpet:happy", onHappy);
  }, []);

  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    if (hidden || dragging || muted || expanded || action !== "idle") return;
    const delay = IDLE_GREETING_MS.min + Math.round(Math.random() * (IDLE_GREETING_MS.max - IDLE_GREETING_MS.min));
    const timer = window.setTimeout(() => {
      if (Date.now() < dismissedUntilRef.current) return;
      setRandomTaskSeed(Date.now());
      setExpanded(true);
      setAction("guide");
      setToken((value) => value + 1);
    }, delay);
    return () => window.clearTimeout(timer);
  }, [action, dragging, expanded, hidden, muted, pathname]);

  useEffect(() => {
    if (Platform.OS !== "web" || !authToken || !expanded || !recommendation || hidden || dragging || muted) {
      setAiDialogue(null);
      return;
    }

    let cancelled = false;
    void getPetDialogue({
      trigger: inferDialogueTrigger(pathname, recommendation),
      client_context: {
        route: pathname,
        route_title: recommendation.title,
        task_hint: recommendation.copy,
        local_time: new Date().toISOString(),
      },
    })
      .then((response) => {
        if (cancelled) return;
        setAiDialogue(unwrapApiData<PetDialogueResult | null>(response, null));
      })
      .catch(() => {
        if (!cancelled) setAiDialogue(null);
      });

    return () => {
      cancelled = true;
    };
  }, [authToken, dragging, expanded, hidden, muted, pathname, recommendation]);

  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    if (action === "idle") return;
    const timer = window.setTimeout(() => {
      setAction("idle");
      setToken((value) => value + 1);
    }, 6300);
    return () => window.clearTimeout(timer);
  }, [action, token]);

  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    if (!expanded || hidden || dragging || muted) return;
    const timer = window.setTimeout(() => setExpanded(false), AUTO_COLLAPSE_MS);
    return () => window.clearTimeout(timer);
  }, [expanded, hidden, dragging, muted, action, token]);

  useEffect(() => {
    if (muted) {
      setExpanded(false);
      setRandomTaskSeed(null);
    }
  }, [muted]);

  useEffect(() => {
    if (Platform.OS !== "web" || typeof window === "undefined") return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;
    const context = canvas.getContext("2d", { willReadFrequently: true });
    if (!context) return;

    const keyColor = parseHexColor(activeClip.chromaKeyHex);
    const workCanvas = document.createElement("canvas");
    const workContext = workCanvas.getContext("2d", { willReadFrequently: true });
    if (!workContext) return;
    let frame = 0;
    let lastPaintAt = 0;
    let renderBounds: PixelBounds | null = null;

    const paint = () => {
      const now = performance.now();
      if (now - lastPaintAt < 70) {
        frame = window.requestAnimationFrame(paint);
        return;
      }
      lastPaintAt = now;

      if (!video.videoWidth || !video.videoHeight) {
        frame = window.requestAnimationFrame(paint);
        return;
      }
      if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
      }
      if (workCanvas.width !== video.videoWidth || workCanvas.height !== video.videoHeight) {
        workCanvas.width = video.videoWidth;
        workCanvas.height = video.videoHeight;
      }
      workContext.clearRect(0, 0, workCanvas.width, workCanvas.height);
      workContext.drawImage(video, 0, 0, workCanvas.width, workCanvas.height);

      let imageData: ImageData;
      try {
        imageData = workContext.getImageData(0, 0, workCanvas.width, workCanvas.height);
      } catch {
        context.clearRect(0, 0, canvas.width, canvas.height);
        frame = window.requestAnimationFrame(paint);
        return;
      }
      clearChromaKey(imageData, keyColor);
      clearConnectedBackground(imageData, keyColor);
      const bounds = alphaBounds(imageData);
      if (!bounds) {
        context.clearRect(0, 0, canvas.width, canvas.height);
        frame = window.requestAnimationFrame(paint);
        return;
      }
      const paddedBounds = expandBounds(bounds, imageData.width, imageData.height, 3);
      trimTransparentOutsideBounds(imageData, paddedBounds);
      renderBounds = unionBounds(renderBounds, paddedBounds);
      const boundsWidth = renderBounds.right - renderBounds.left;
      const boundsHeight = renderBounds.bottom - renderBounds.top;
      if (boundsWidth > 0 && boundsHeight > 0) {
        setCanvasAspectRatio((current) => {
          const next = boundsWidth / boundsHeight;
          return Math.abs(current - next) > 0.025 ? next : current;
        });
      }
      workContext.putImageData(imageData, 0, 0);
      drawFittedPetFrame(context, workCanvas, renderBounds);
      frame = window.requestAnimationFrame(paint);
    };
    const start = () => {
      window.cancelAnimationFrame(frame);
      frame = window.requestAnimationFrame(paint);
    };
    video.addEventListener("play", start);
    video.addEventListener("loadeddata", start);
    start();
    return () => {
      video.removeEventListener("play", start);
      video.removeEventListener("loadeddata", start);
      window.cancelAnimationFrame(frame);
    };
  }, [activeClip.chromaKeyHex, activeClip.src]);

  if (Platform.OS !== "web" || !isHydrated || muted || !position) return null;

  if (hidden) {
    return React.createElement(
      "button",
      {
        type: "button",
        style: styles.restore,
        onClick: () => {
          setHidden(false);
          window.localStorage.setItem(STORAGE_KEYS.hidden, "0");
        },
      },
      "Show pet",
    );
  }

  const size = expanded ? PET_SIZE : PET_COLLAPSED_SIZE;
  const bubbleTitle = aiDialogue?.title || recommendation?.title;
  const bubbleCopy = aiDialogue?.message || recommendation?.copy;
  const bubbleReward = aiDialogue?.reward_hint || recommendation?.reward;
  const bubbleCta = aiDialogue?.cta_label || recommendation?.cta;
  const bubbleRoute = aiDialogue?.route || recommendation?.route;
  const getBubbleStyle = (): React.CSSProperties => {
    if (typeof window === "undefined") return styles.bubble;
    const bubbleWidth = Math.min(252, window.innerWidth - 24);
    const bubbleHeight = bubbleWidth / 1.62;
    const naturalLeft = size - 54 - bubbleWidth;
    const naturalTop = -92;
    const minLeft = 12 - position.x;
    const maxLeft = window.innerWidth - 12 - bubbleWidth - position.x;
    const minTop = 12 - position.y;
    const maxTop = window.innerHeight - 12 - bubbleHeight - position.y;
    return {
      ...styles.bubble,
      width: bubbleWidth,
      left: Math.min(maxLeft, Math.max(minLeft, naturalLeft)),
      right: "auto",
      top: Math.min(maxTop, Math.max(minTop, naturalTop)),
    };
  };

  return React.createElement(
    "div",
    { style: styles.root },
    React.createElement("style", {
      dangerouslySetInnerHTML: {
        __html: `
@keyframes mobileDeskPetBubbleBreathe {
  0%, 100% { transform: translateY(0) scale(1) rotate(-0.2deg); box-shadow: 0 18px 34px rgba(23,26,26,0.16), 0 0 18px rgba(229,229,226,0.1); }
  50% { transform: translateY(-3px) scale(1.015) rotate(0.25deg); box-shadow: 0 23px 42px rgba(23,26,26,0.2), 0 0 30px rgba(229,229,226,0.28); }
}
@keyframes mobileDeskPetBubbleGlow {
  0%, 100% { opacity: 0.58; }
  50% { opacity: 0.92; }
}
@keyframes mobileDeskPetTailBreathe {
  0%, 100% { transform: translateY(0) scale(1); }
  50% { transform: translateY(-1px) scale(1.08); }
}
        `,
      },
    }),
    React.createElement(
      "div",
      { style: { ...styles.pet, left: position.x, top: position.y, width: size, height: size } },
      expanded && recommendation
        ? React.createElement(
            "div",
            { style: getBubbleStyle(), onPointerDown: (event: PointerEvent) => event.stopPropagation() },
            React.createElement("span", { style: styles.bubbleRim, "aria-hidden": true }),
            React.createElement("span", { style: styles.bubbleGlow, "aria-hidden": true }),
            React.createElement(
              "button",
              {
                type: "button",
                "aria-label": "Close pet bubble",
                style: styles.bubbleClose,
                onClick: () => {
                  dismissedUntilRef.current = Date.now() + DISMISS_COOLDOWN_MS;
                  setRandomTaskSeed(null);
                  setExpanded(false);
                },
              },
              "×",
            ),
            React.createElement(
              "div",
              { style: styles.bubbleContent },
              React.createElement("span", { style: styles.eyebrow }, "桌宠想说"),
              React.createElement("strong", { style: styles.title }, bubbleTitle),
              React.createElement("span", { style: styles.copy }, bubbleCopy),
            ),
            React.createElement(
              "div",
              { style: styles.bubbleFoot },
              React.createElement("span", { style: styles.reward }, bubbleReward),
              React.createElement(
                "button",
                {
                  type: "button",
                  style: styles.cta,
                  onClick: () => {
                    setAction("guide");
                    setToken((value) => value + 1);
                    navigateToRecommendation(bubbleRoute || recommendation.route);
                  },
                },
                bubbleCta,
              ),
            ),
            React.createElement("span", { "aria-hidden": true, style: styles.bubbleTailLarge }),
            React.createElement("span", { "aria-hidden": true, style: styles.bubbleTailSmall }),
          )
        : null,
      React.createElement(
        "button",
        {
          type: "button",
          "aria-label": `${pet.name} desk pet`,
          style: styles.petButton,
          onPointerDown: (event: PointerEvent) => {
            event.preventDefault();
            dragRef.current = {
              pointerId: event.pointerId,
              startX: event.clientX,
              startY: event.clientY,
              originX: position.x,
              originY: position.y,
              moved: false,
            };
            setDragging(false);
          },
        },
        React.createElement("video", {
          ref: videoRef,
          key: `${pet.id}-${action}-${token}`,
          src: activeClip.src,
          autoPlay: true,
          muted: true,
          playsInline: true,
          loop: action === "idle",
          preload: action === "idle" ? "auto" : "metadata",
          style: styles.video,
          onEnded: () => {
            if (action !== "idle") {
              setAction("idle");
              setToken((value) => value + 1);
            }
          },
        }),
        React.createElement("canvas", { ref: canvasRef, width: 256, height: 256, style: { ...styles.canvas, aspectRatio: canvasAspectRatio } }),
        expanded ? React.createElement("span", { style: styles.badge }, pet.name) : null,
      ),
      React.createElement(
        "button",
        {
          type: "button",
          style: styles.hide,
          "aria-label": "Hide desk pet",
          onClick: () => {
            setHidden(true);
            setExpanded(false);
            setRandomTaskSeed(null);
            window.localStorage.setItem(STORAGE_KEYS.hidden, "1");
          },
        },
        "×",
      ),
    ),
  );
}

const styles = {
  root: {
    position: "fixed",
    inset: 0,
    pointerEvents: "none",
    zIndex: DESK_PET_Z_INDEX,
  },
  pet: {
    position: "fixed",
    pointerEvents: "auto",
    touchAction: "none",
    zIndex: DESK_PET_Z_INDEX,
  },
  petButton: {
    position: "relative",
    width: "100%",
    height: "100%",
    padding: 0,
    border: 0,
    background: "transparent",
    cursor: "grab",
    touchAction: "none",
    WebkitTapHighlightColor: "transparent",
  },
  video: {
    display: "none",
  },
  canvas: {
    height: "100%",
    width: "auto",
    objectFit: "contain",
    pointerEvents: "none",
    filter: "drop-shadow(0 12px 16px rgba(94,95,94, 0.22))",
  },
  badge: {
    position: "absolute",
    left: "50%",
    bottom: -7,
    transform: "translateX(-50%)",
    padding: "3px 9px",
    borderRadius: 999,
    color: "#171A1A",
    background: "rgba(255,255,255, 0.94)",
    border: "1px solid rgba(23,26,26, 0.14)",
    fontSize: 11,
    fontWeight: 800,
    boxShadow: "0 8px 14px rgba(94,95,94, 0.12)",
    whiteSpace: "nowrap",
  },
  hide: {
    position: "absolute",
    right: -6,
    top: -8,
    width: 24,
    height: 24,
    borderRadius: 999,
    border: "1px solid rgba(23,26,26, 0.14)",
    color: "#5E5F5E",
    background: "rgba(255, 253, 249, 0.92)",
    fontSize: 17,
    lineHeight: "20px",
    cursor: "pointer",
  },
  restore: {
    position: "fixed",
    right: 13,
    bottom: 82,
    zIndex: DESK_PET_Z_INDEX,
    padding: "7px 11px",
    borderRadius: 999,
    border: "1px solid rgba(23,26,26, 0.14)",
    color: "#2C2E2D",
    background: "rgba(255,255,255, 0.94)",
    fontSize: 12,
    fontWeight: 800,
    boxShadow: "0 10px 18px rgba(94,95,94, 0.14)",
  },
  bubble: {
    position: "absolute",
    right: 54,
    top: -92,
    display: "flex",
    width: 252,
    aspectRatio: 1.62,
    flexDirection: "column",
    justifyContent: "center",
    gap: 8,
    padding: "28px 38px 30px 36px",
    border: 0,
    borderRadius: 0,
    color: "#171A1A",
    background: "transparent",
    filter: "drop-shadow(0 18px 28px rgba(23,26,26,0.16)) drop-shadow(0 0 14px rgba(255,255,255,0.34))",
    animation: "mobileDeskPetBubbleBreathe 3.8s ease-in-out infinite",
    isolation: "isolate",
  },
  bubbleRim: {
    position: "absolute",
    inset: 0,
    zIndex: -2,
    borderRadius: "50% / 45%",
    border: "1px solid rgba(255, 255, 255, 0.64)",
    background: "radial-gradient(ellipse at 25% 16%, rgba(255,255,255,0.66), transparent 30%), radial-gradient(ellipse at 72% 78%, rgba(229,229,226,0.28), transparent 38%), linear-gradient(135deg, rgba(255,255,255,0.48), rgba(229,229,226,0.24) 58%, rgba(255,255,255,0.34))",
    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.9), inset 0 -12px 24px rgba(229,229,226,0.12), 0 0 0 1px rgba(255,255,255,0.22)",
    backdropFilter: "blur(9px) saturate(1.18)",
    WebkitBackdropFilter: "blur(9px) saturate(1.18)",
    pointerEvents: "none",
  },
  bubbleGlow: {
    position: "absolute",
    inset: 5,
    borderRadius: "50% / 45%",
    border: "1px solid rgba(255,255,255, 0.58)",
    boxShadow: "inset 0 0 18px rgba(255,255,255,0.28), 0 0 16px rgba(229,229,226,0.18)",
    opacity: 0.86,
    pointerEvents: "none",
    animation: "mobileDeskPetBubbleGlow 2.6s ease-in-out infinite",
    zIndex: -1,
  },
  bubbleClose: {
    position: "absolute",
    top: 18,
    right: 28,
    zIndex: 3,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    width: 18,
    height: 18,
    padding: 0,
    borderRadius: 999,
    border: "1px solid rgba(94,95,94, 0.14)",
    color: "rgba(23,26,26, 0.74)",
    background: "rgba(255,255,255, 0.64)",
    fontSize: 12,
    lineHeight: "14px",
    fontWeight: 800,
    cursor: "pointer",
    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.64), 0 6px 12px rgba(23,26,26,0.1)",
    backdropFilter: "blur(8px) saturate(1.12)",
    WebkitBackdropFilter: "blur(8px) saturate(1.12)",
  },
  bubbleContent: {
    display: "flex",
    flexDirection: "column",
    gap: 7,
    maxWidth: 158,
    overflow: "hidden",
    position: "relative",
    zIndex: 2,
  },
  bubbleFoot: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    gap: 6,
    marginTop: -2,
    paddingRight: 14,
    position: "relative",
    zIndex: 2,
  },
  bubbleTailLarge: {
    display: "block",
    position: "absolute",
    right: -8,
    bottom: 8,
    zIndex: -3,
    width: 48,
    height: 30,
    borderRadius: 999,
    border: "1px solid rgba(255, 255, 255, 0.34)",
    background: "linear-gradient(145deg, rgba(248, 246, 239, 0.78), rgba(229,229,226, 0.62))",
    boxShadow: "0 10px 22px rgba(23,26,26, 0.14), inset 0 1px 0 rgba(255, 255, 255, 0.66)",
    backdropFilter: "blur(12px) saturate(1.12)",
    WebkitBackdropFilter: "blur(12px) saturate(1.12)",
    pointerEvents: "none",
    animation: "mobileDeskPetTailBreathe 3.8s ease-in-out infinite",
  },
  bubbleTailSmall: {
    display: "block",
    position: "absolute",
    right: -25,
    bottom: -12,
    zIndex: -4,
    width: 28,
    height: 20,
    borderRadius: 999,
    border: "1px solid rgba(255, 255, 255, 0.34)",
    background: "linear-gradient(145deg, rgba(248, 246, 239, 0.78), rgba(229,229,226, 0.62))",
    boxShadow: "0 8px 18px rgba(23,26,26, 0.13), inset 0 1px 0 rgba(255, 255, 255, 0.66)",
    backdropFilter: "blur(12px) saturate(1.12)",
    WebkitBackdropFilter: "blur(12px) saturate(1.12)",
    pointerEvents: "none",
    animation: "mobileDeskPetTailBreathe 3.8s ease-in-out infinite",
  },
  eyebrow: {
    color: "rgba(94,95,94, 0.82)",
    fontSize: 11,
    fontWeight: 750,
    letterSpacing: 0.4,
    textTransform: "uppercase",
  },
  title: {
    color: "#171A1A",
    fontSize: 16,
    lineHeight: "18px",
    fontWeight: 900,
  },
  copy: {
    color: "#5E5F5E",
    fontSize: 11,
    lineHeight: "15px",
    fontWeight: 600,
    maxHeight: 30,
    overflow: "hidden",
  },
  reward: {
    maxWidth: 52,
    padding: "3px 7px",
    borderRadius: 999,
    border: "1px solid rgba(94,95,94, 0.12)",
    color: "rgba(94,95,94, 0.78)",
    background: "rgba(255,255,255, 0.38)",
    fontSize: 9,
    lineHeight: "11px",
    fontWeight: 800,
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  },
  cta: {
    alignSelf: "flex-start",
    minHeight: 32,
    maxWidth: 76,
    padding: "0 12px",
    border: 0,
    borderRadius: 999,
    color: "#FFFFFF",
    background: "radial-gradient(circle at 28% 18%, rgba(255,255,255,0.24), transparent 34%), linear-gradient(180deg, rgba(4,168,174,0.98), rgba(94,95,94,0.98))",
    fontSize: 10,
    fontWeight: 900,
    cursor: "pointer",
    boxShadow: "0 10px 18px rgba(94,95,94, 0.24), inset 0 1px 0 rgba(255,255,255,0.3)",
    whiteSpace: "nowrap",
  },
} satisfies Record<string, React.CSSProperties>;
