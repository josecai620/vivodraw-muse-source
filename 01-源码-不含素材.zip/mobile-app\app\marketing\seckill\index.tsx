import React, { useState, useMemo } from "react";
import { ActivityIndicator, Image, Pressable, ScrollView, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { http } from "@/lib/http";
import { API_ENDPOINTS } from "@/constants/api";
import { normalizeImageUrl, formatPrice } from "@/lib/utils";
import { Colors, s } from "@/constants/theme";
import PageHeader from "@/components/shared/PageHeader";

function formatSlotLabel(slot: any, i: number): string {
  const t = slot?.time ?? slot?.start_time ?? slot;
  if (typeof t === "string" && t.includes(":")) return t;
  if (typeof t === "number") return `${String(t).padStart(2, "0")}:00`;
  return typeof t === "string" ? t : `Slot ${i + 1}`;
}

export default function SeckillScreen() {
  const router = useRouter();
  const { data, isLoading } = useQuery({
    queryKey: ["seckillIndex"],
    queryFn: () => http.get(API_ENDPOINTS.seckill.index),
  });

  const raw = (data as any)?.data ?? data;
  const timeList: any[] = raw?.seckillTime ?? raw?.seckill_time ?? raw?.time ?? [];
  const defaultIndex = raw?.seckillTimeIndex ?? 0;
  const slots = useMemo(() => {
    return timeList.map((s: any, i: number) => ({
      id: s?.id ?? i + 1,
      label: formatSlotLabel(s, i),
      status: s?.status ?? 1,
      state: s?.state ?? "",
    }));
  }, [timeList]);

  const [selectedId, setSelectedId] = useState<number | string | null>(null);
  const defaultSlot = slots[defaultIndex >= 0 && defaultIndex < slots.length ? defaultIndex : 0];
  const timeId = selectedId ?? defaultSlot?.id ?? slots[0]?.id ?? 1;

  const { data: listData, isLoading: listLoading } = useQuery({
    queryKey: ["seckillList", timeId],
    queryFn: () => http.get(API_ENDPOINTS.seckill.list(String(timeId))),
    enabled: !!timeId && slots.length > 0,
  });

  const listRaw = (listData as any)?.data ?? listData;
  const products = listRaw?.list ?? listRaw?.product ?? Array.isArray(listRaw) ? listRaw : [];

  return (
    <View className="flex-1 bg-gray-50">
      <PageHeader title="Flash Sale" />
      {isLoading ? (
        <View className="flex-1 items-center justify-center">
          <ActivityIndicator size="large" color={Colors.brand.red} />
        </View>
      ) : (
        <>
          {slots.length > 0 && (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              className="bg-white border-b border-gray-100"
              contentContainerStyle={{ paddingHorizontal: s(12), paddingVertical: s(10), gap: s(8) }}
            >
              {slots.map((slot) => {
                const isSelected = timeId === slot.id;
                return (
                  <Pressable
                    key={slot.id}
                    onPress={() => setSelectedId(slot.id)}
                    className="px-4 py-2 rounded-xl"
                    style={{ backgroundColor: isSelected ? Colors.brand.red : Colors.neutral[100] }}
                  >
                    <Text className="font-semibold" style={{ color: isSelected ? "#fff" : Colors.neutral[600] }}>
                      {slot.label}
                    </Text>
                    {slot.state ? (
                      <Text className="text-xs mt-0.5" style={{ color: isSelected ? "rgba(255,255,255,0.9)" : Colors.neutral[500] }}>
                        {slot.status === 1 ? "Live" : slot.status === 2 ? "Upcoming" : "Ended"}
                      </Text>
                    ) : null}
                  </Pressable>
                );
              })}
            </ScrollView>
          )}
          {listLoading ? (
            <View className="flex-1 items-center justify-center">
              <ActivityIndicator size="large" color={Colors.brand.red} />
            </View>
          ) : products.length === 0 ? (
            <View className="flex-1 items-center justify-center px-6">
              <Text style={{ color: Colors.neutral[500] }}>No flash sale at the moment</Text>
            </View>
          ) : (
            <ScrollView className="flex-1" contentContainerStyle={{ padding: s(16), paddingBottom: s(80) }} showsVerticalScrollIndicator={false}>
              <View className="flex-row flex-wrap justify-between">
                {products.map((item: any, i: number) => (
                  <Pressable
                    key={item.id ?? i}
                    onPress={() => router.push(`/marketing/seckill/${item.id}?time=${timeId}`)}
                    className="bg-white rounded-2xl overflow-hidden border border-gray-100 mb-3"
                    style={{ width: "48%" }}
                  >
                    <Image source={{ uri: normalizeImageUrl(item.image ?? item.pic) }} style={{ width: "100%", aspectRatio: 1, backgroundColor: Colors.neutral[100] }} resizeMode="cover" />
                    <View className="p-3">
                      <Text className="font-medium" style={{ color: Colors.neutral[800] }} numberOfLines={2}>{item.store_name ?? item.title}</Text>
                      <View className="flex-row items-center mt-2">
                        <Text className="font-bold" style={{ color: Colors.brand.red }}>{formatPrice(item.seckill_price ?? item.price)}</Text>
                        <Text className="text-xs ml-1 line-through" style={{ color: Colors.neutral[400] }}>{formatPrice(item.price ?? item.ot_price)}</Text>
                      </View>
                    </View>
                  </Pressable>
                ))}
              </View>
            </ScrollView>
          )}
        </>
      )}
    </View>
  );
}
