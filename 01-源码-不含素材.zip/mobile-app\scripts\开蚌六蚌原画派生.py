# -*- coding: utf-8 -*-
"""从已认可的手绘原画 01-潮扇 派生六只各有轮廓与壳纹的蚌（v3：矩形工作区，无裁切）。
仅派生轮廓（极坐标径向重映射）与壳纹（生长轮/辐纹/人字纹/斑纹/配色），保留手绘笔触与珠母材质。"""
import json, math, os
import numpy as np
from PIL import Image, ImageFilter

SRC_DIR = r"D:\eccomall\mobile-app\assets\海底寻珠\灵蚌原画"
TMP_DIR = r"D:\eccomall\tmp\灵蚌派生"
os.makedirs(TMP_DIR, exist_ok=True)
GW, GH = 1700, 1500          # 矩形工作区：宽扇与深扇都完整容纳
SCALE = 0.62                 # 归一化单位（主体高度）相对工作区的比例
HY = 0.06                    # 铰链在工作区高度的位置
OUT = 1024
MARGIN = 0.075
ANG = math.pi / 2            # 输出角度域固定 ±90°，轮廓由径向函数闭合

def load(p):
    return np.asarray(Image.open(p).convert("RGBA")).astype(np.float32) / 255.0

def geometry(exterior):
    a = exterior[..., 3]
    ys, xs = np.nonzero(a > 0.35)
    hy = int(ys.min())
    hx = float(xs[ys == hy].mean())
    height = float(ys.max() - ys.min())
    th = np.arctan2(xs - hx, ys - hy)
    rr = np.hypot(xs - hx, ys - hy) / height
    span = float(np.abs(th).max())
    bins = 1600
    idx = np.clip(((th + span) / (2 * span) * (bins - 1)).astype(np.int32), 0, bins - 1)
    prof = np.zeros(bins)
    np.maximum.at(prof, idx, rr)
    known = prof > 0
    prof = np.interp(np.arange(bins), np.nonzero(known)[0], prof[known])
    prof = np.convolve(np.pad(prof, 8, mode="edge"), np.ones(17) / 17.0, mode="valid")
    return dict(hx=hx, hy=float(hy), height=height, span=span, prof=prof, bins=bins)

def profile_at(geo, theta):
    span = geo["span"]
    t = np.clip(theta, -span, span)
    pos = (t + span) / (2 * span) * (geo["bins"] - 1)
    lo = np.floor(pos).astype(np.int32); hi = np.minimum(lo + 1, geo["bins"] - 1)
    w = pos - lo
    return geo["prof"][lo] * (1 - w) + geo["prof"][hi] * w

def sample(src, x, y):
    h, w = src.shape[:2]
    x = np.clip(x, 0, w - 1.001); y = np.clip(y, 0, h - 1.001)
    x0 = np.floor(x).astype(np.int32); y0 = np.floor(y).astype(np.int32)
    fx = (x - x0)[..., None]; fy = (y - y0)[..., None]
    p00 = src[y0, x0]; p10 = src[y0, x0 + 1]; p01 = src[y0 + 1, x0]; p11 = src[y0 + 1, x0 + 1]
    return (p00 * (1 - fx) + p10 * fx) * (1 - fy) + (p01 * (1 - fx) + p11 * fx) * fy

def warp(src, geo, spec):
    cx = GW / 2.0 + spec.get("apex", 0.0) * GH
    hy = GH * HY
    ys, xs = np.mgrid[0:GH, 0:GW]
    nx = (xs - cx) / (GH * SCALE)   # 单位：主体高度
    ny = (ys - hy) / (GH * SCALE)
    theta = np.arctan2(nx, np.maximum(ny, 1e-6))
    rho = np.hypot(nx, ny)
    fan = spec["out_fan"] * ANG
    t_norm = np.clip(theta / fan, -1.0, 1.0)
    theta_src = t_norm * geo["span"] * spec["src_use"] + spec["asym"] * geo["span"] * (t_norm ** 2)
    at = np.abs(t_norm)
    shape = (1.0 + spec["wide"] * at ** 2) * (1.0 + spec["tall"] * (1.0 - at) ** 2)
    if spec.get("notch"):
        shape = shape * (1.0 - spec["notch"] * np.exp(-(theta / 0.14) ** 2))
    for k, amp, ph in spec["lobes"]:
        shape = shape * (1.0 + amp * np.cos(k * theta + ph))
    # 扇缘平滑收拢成自然翼尖，避免直边裁切
    win = (1.0 - np.clip(np.abs(theta) / fan, 0, 1) ** 8) ** 0.5
    prof = profile_at(geo, theta_src)
    edge = prof * shape * win
    u = np.where(edge > 1e-6, rho / np.maximum(edge, 1e-6), 9.0)
    r_src = u * prof
    sx = geo["hx"] + r_src * geo["height"] * np.sin(theta_src)
    sy = geo["hy"] + r_src * geo["height"] * np.cos(theta_src)
    out = sample(src, sx, sy)
    out[..., 3] *= np.clip((1.0 - u) / 0.02, 0.0, 1.0)
    return out, u, theta

def rgb_hsv(rgb):
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mx = np.max(rgb, axis=-1); mn = np.min(rgb, axis=-1); d = mx - mn
    m = d > 1e-6
    h = np.zeros_like(mx)
    i = m & (mx == r); h[i] = ((g - b)[i] / d[i]) % 6
    i = m & (mx == g); h[i] = ((b - r)[i] / d[i]) + 2
    i = m & (mx == b); h[i] = ((r - g)[i] / d[i]) + 4
    return h / 6.0, np.where(mx > 1e-6, d / np.maximum(mx, 1e-6), 0.0), mx

def hsv_rgb(h, s, v):
    i = np.floor(h * 6.0); f = h * 6.0 - i
    p = v * (1 - s); q = v * (1 - f * s); t = v * (1 - (1 - f) * s)
    i = (i % 6).astype(np.int32)
    sel = [i == 0, i == 1, i == 2, i == 3, i == 4, i == 5]
    r = np.select(sel, [v, q, p, p, t, v]); g = np.select(sel, [t, v, v, q, p, p]); b = np.select(sel, [p, p, t, v, v, q])
    return np.stack([r, g, b], axis=-1)

def blur(arr, radius):
    im = Image.fromarray(np.clip(arr * 255.0, 0, 255).astype(np.uint8))
    return np.asarray(im.filter(ImageFilter.GaussianBlur(radius))).astype(np.float32) / 255.0

def grade(rgba, u, theta, g, seed):
    rgb = rgba[..., :3]; a = rgba[..., 3]
    h, s, v = rgb_hsv(rgb)
    if g.get("bands"):
        f, amp, ph = g["bands"]
        w = np.clip((u - 0.1) / 0.9, 0, 1) ** 0.75
        v = v * (1.0 + amp * np.sin(2 * math.pi * f * u + ph) * w)
    if g.get("striation"):
        k, amp, ph = g["striation"]
        w = np.clip((u - 0.12) / 0.88, 0, 1) ** 0.55
        v = v * (1.0 + amp * np.cos(k * theta + ph) * w)
    if g.get("chevron"):
        k, m, amp, ph = g["chevron"]
        w = np.clip((u - 0.15) / 0.85, 0, 1) ** 0.7
        v = v * (1.0 + amp * np.cos(k * theta + 2 * math.pi * m * u + ph) * w)
    if g.get("speckle"):
        amp, lo, hi, rad = g["speckle"]
        noise = blur(np.random.default_rng(seed).normal(0.5, 0.17, v.shape).astype(np.float32), rad)
        w = np.clip((u - lo) / max(hi - lo, 1e-3), 0, 1) * np.clip((1.02 - u) / 0.3, 0, 1)
        v = v * (1.0 + amp * (noise - 0.5) * 2.0 * w)
    h = (h + g.get("dh", 0.0)) % 1.0
    s = np.clip(s * g.get("sat", 1.0) + g.get("d_sat", 0.0), 0.0, 1.0)
    v = np.clip(v * g.get("bright", 1.0), 0.0, 1.0)
    out = hsv_rgb(h, s, v)
    if g.get("tint"):
        color, amount, curve = g["tint"]
        w = (np.clip((v - 0.16) / 0.74, 0, 1) ** curve * amount)[..., None]
        out = out * (1 - w) + np.array(color, dtype=np.float32) * w
    if g.get("sheen"):
        k, amp, color = g["sheen"]
        mask = np.clip((np.clip(np.cos(k * theta), 0, 1) ** 2) * np.clip((u - 0.2) / 0.8, 0, 1) * amp, 0, 1)
        out = out + (np.array(color, dtype=np.float32) - out) * mask[..., None]
    out = np.clip(out, 0.0, 1.0)
    return np.concatenate([out * a[..., None], a[..., None]], axis=-1)

def fit(rgba):
    a = rgba[..., 3]
    ys, xs = np.nonzero(a > 0.32)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    crop = rgba[y0:y1, x0:x1]
    ch, cw = crop.shape[:2]
    inner = OUT * (1 - 2 * MARGIN)
    scale = min(inner / cw, inner / ch)
    tw, th = max(1, int(round(cw * scale))), max(1, int(round(ch * scale)))
    img = Image.fromarray(np.clip(crop * 255.0, 0, 255).astype(np.uint8), "RGBA").resize((tw, th), Image.LANCZOS)
    canvas = Image.new("RGBA", (OUT, OUT), (0, 0, 0, 0))
    ox, oy = (OUT - tw) // 2, (OUT - th) // 2
    canvas.paste(img, (ox, oy), img)
    hinge_px = (GH * HY - y0) * scale + oy
    return canvas, dict(hinge=round(float(hinge_px) / OUT, 4), aspect=round(tw / float(th), 4),
                        clipped=bool(x0 == 0 or x1 == GW or y1 == GH))

SPECS = [
    dict(id="02", name="月环", file="02-月环", out_fan=1.00, src_use=1.00, asym=0.0, wide=0.02, tall=0.18, apex=0.0,
         lobes=[(14, 0.018, 0.5)],
         ext=dict(dh=0.006, sat=0.56, bright=1.16, bands=(10, 0.062, 0.6), striation=(30, 0.016, 0.0),
                  speckle=(0.016, 0.32, 0.95, 3.0), tint=([1.0, 0.96, 0.88], 0.40, 1.0),
                  sheen=(3, 0.14, [1.0, 0.99, 0.95])),
         inner=dict(dh=0.006, sat=0.82, bright=1.02, bands=(7, 0.05, 1.1), tint=([1.0, 0.95, 0.86], 0.44, 0.95),
                    sheen=(2, 0.20, [0.92, 1.0, 0.96]))),
    dict(id="03", name="长潮", file="03-长潮", out_fan=0.46, src_use=0.60, asym=0.08, wide=-0.06, tall=0.10, apex=0.015,
         lobes=[(9, 0.026, 1.1), (18, 0.012, 0.3)],
         ext=dict(dh=-0.045, sat=1.62, bright=0.76, bands=(9, 0.075, 0.2), striation=(7, 0.095, 0.4),
                  speckle=(0.028, 0.35, 0.9, 3.0), tint=([0.24, 0.66, 0.56], 0.54, 0.74),
                  sheen=(2, 0.16, [0.46, 0.90, 0.72])),
         inner=dict(dh=-0.020, sat=1.05, bright=0.94, bands=(9, 0.06, 0.9), tint=([0.46, 0.84, 0.74], 0.52, 0.85),
                    sheen=(3, 0.26, [0.60, 0.96, 0.84]))),
    dict(id="04", name="珠梯", file="04-珠梯", out_fan=0.96, src_use=1.00, asym=0.02, wide=0.0, tall=0.16, apex=-0.008,
         lobes=[(4, 0.045, 0.0), (16, 0.014, 0.7)],
         ext=dict(dh=0.058, sat=1.40, bright=0.90, bands=(12, 0.07, 1.4), striation=(4, 0.105, 0.0),
                  speckle=(0.018, 0.25, 0.85, 3.0), tint=([0.56, 0.92, 0.50], 0.48, 0.88),
                  sheen=(4, 0.24, [0.92, 0.99, 0.72])),
         inner=dict(dh=0.030, sat=0.95, bright=0.98, bands=(12, 0.055, 0.3), tint=([0.66, 0.95, 0.62], 0.50, 0.92),
                    sheen=(4, 0.28, [0.78, 1.0, 0.72]))),
    dict(id="05", name="霞褶", file="05-霞褶", out_fan=1.00, src_use=1.00, asym=0.20, wide=0.04, tall=-0.02, apex=-0.012,
         lobes=[(7, 0.05, 0.9), (13, 0.026, 2.1)],
         ext=dict(dh=-0.082, sat=1.30, bright=1.02, bands=(5, 0.055, 2.0), chevron=(6, 4.0, 0.088, 0.4),
                  speckle=(0.038, 0.3, 0.95, 4.0), tint=([0.99, 0.54, 0.72], 0.44, 0.86),
                  sheen=(3, 0.26, [0.99, 0.68, 0.88])),
         inner=dict(dh=-0.040, sat=1.10, bright=0.98, bands=(5, 0.045, 0.4), chevron=(5, 3.0, 0.05, 1.0),
                    tint=([1.0, 0.60, 0.80], 0.52, 0.86), sheen=(3, 0.32, [0.86, 0.74, 1.0]))),
    dict(id="06", name="星斑", file="06-星斑", out_fan=1.00, src_use=1.00, asym=-0.07, wide=0.10, tall=-0.06, apex=0.028,
         notch=0.05, lobes=[(6, 0.028, 0.3)],
         ext=dict(dh=0.160, sat=1.26, bright=0.96, bands=(4, 0.05, 1.0), chevron=(9, 5.0, 0.062, 1.6),
                  speckle=(0.088, 0.24, 0.98, 9.0), tint=([0.60, 0.66, 1.0], 0.34, 0.82),
                  sheen=(2, 0.26, [0.66, 0.76, 1.0])),
         inner=dict(dh=0.115, sat=1.18, bright=0.96, bands=(4, 0.04, 0.8), chevron=(7, 4.0, 0.055, 0.8),
                    tint=([0.56, 0.64, 1.0], 0.54, 0.82), sheen=(2, 0.36, [0.70, 0.78, 1.0]))),
]

def sheet(items, path, bg=(228, 231, 227, 255)):
    cols, rows, cell = 3, 2, 512
    canvas = Image.new("RGBA", (cols * cell, rows * cell), bg)
    for i, im in enumerate(items):
        small = im.resize((cell, cell), Image.LANCZOS)
        canvas.paste(small, ((i % cols) * cell, (i // cols) * cell), small)
    canvas.save(path)

def main():
    ext = load(os.path.join(SRC_DIR, "01-潮扇-外壳.png"))
    inner = load(os.path.join(SRC_DIR, "01-潮扇-内壁.png"))
    geo = geometry(ext)
    print("geo span=%.4f (%.1f deg) height=%.1f" % (geo["span"], math.degrees(geo["span"]), geo["height"]))
    meta = {}
    ext_sheet = [Image.open(os.path.join(SRC_DIR, "01-潮扇-外壳.png")).convert("RGBA")]
    inner_sheet = [Image.open(os.path.join(SRC_DIR, "01-潮扇-内壁.png")).convert("RGBA")]
    for spec in SPECS:
        e, u, th = warp(ext, geo, spec)
        i2, _, _ = warp(inner, geo, spec)
        eg = grade(e, u, th, spec["ext"], seed=1100 + int(spec["id"]))
        ig = grade(i2, u, th, spec["inner"], seed=2200 + int(spec["id"]))
        ce, me = fit(eg); ci, mi = fit(ig)
        ce.save(os.path.join(SRC_DIR, spec["file"] + "-外壳.png"))
        ci.save(os.path.join(SRC_DIR, spec["file"] + "-内壁.png"))
        meta[spec["id"]] = dict(name=spec["name"], hinge=me["hinge"], aspect=me["aspect"], clipped=me["clipped"])
        print(spec["file"], "hinge=%.3f aspect=%.3f clipped=%s" % (me["hinge"], me["aspect"], me["clipped"]))
        ext_sheet.append(ce); inner_sheet.append(ci)
    sheet(ext_sheet, os.path.join(TMP_DIR, "六蚌-外壳-拼版.png"))
    sheet(inner_sheet, os.path.join(TMP_DIR, "六蚌-内壁-拼版.png"))
    # 实际游戏尺寸（约 112px）对照，深海底色
    cell = 112
    small = Image.new("RGBA", (cell * 6 + 40, cell + 40), (26, 96, 108, 255))
    for i, im in enumerate(ext_sheet):
        s = im.resize((cell, cell), Image.LANCZOS)
        small.alpha_composite(s, (20 + i * cell, 20))
    small.convert("RGB").save(os.path.join(TMP_DIR, "六蚌-游戏尺寸对照.png"))
    with open(os.path.join(TMP_DIR, "六蚌几何.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    print("done")

main()
