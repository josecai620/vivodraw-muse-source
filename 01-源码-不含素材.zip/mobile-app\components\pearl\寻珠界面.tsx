import { useEffect, useRef, useState } from "react";
import { Image, Platform, StyleSheet, Text, View, useWindowDimensions, type DimensionValue, type StyleProp, type ViewStyle } from "react-native";
import type { ReactNode } from "react";
import { ArrowLeft, ChevronRight, CircleHelp, Plus, X } from "lucide-react-native";
import { MotionPressable as Pressable } from "./动效组件";
import { usePearlT } from "./文案";
import { LinearGradient } from "expo-linear-gradient";

const lagoonArt = {
  play: require("../../assets/海底寻珠/界面原画/寻珠-母贝.webp"),
  collection: require("../../assets/海底寻珠/界面原画/图鉴-珍珠手札.webp"),
  reef: require("../../assets/海底寻珠/界面原画/礁石-珊瑚藏珠.webp"),
  tide: require("../../assets/海底寻珠/界面原画/潮汐计数匣-第二版.webp"),
  coins: require("../../assets/海底寻珠/界面原画/贝币计数匣-第二版.webp"),
  quest: require("../../assets/海底寻珠/界面原画/珊瑚任务签-第二版.webp"),
  shelves: require("../../assets/海底寻珠/界面原画/三礁导航座-第二版.webp"),
};

const ink = "#123F43";

// 三礁导航座实测值（透明通道扫描）：保证图标永远落在礁石正中。
// 礁石中心在图片宽度中的位置、图片宽高比、礁石顶/底在图片高度中的位置。
const SHELF_CENTERS = [0.1597, 0.4953, 0.8362] as const;
const SHELF_ART_ASPECT = 2116 / 743;
const SHELF_ROCK_TOP = 0.2961;
const SHELF_ROCK_BOTTOM = 0.7806;
const SHELF_ROCK_Y = 46;

// 手绘件的透明裁剪框（透明通道扫描实测，见 开蚌界面美术说明.md 第五版）。
// 手绘原画自带透明边距，直接用 stretch 铺满会被拉变形：这里按可见框裁剪后等比铺满。
type ArtBox = readonly [number, number, number, number];
const visibleAspect = (box: ArtBox, size: readonly [number, number]) =>
  ((box[2] - box[0]) * size[0]) / ((box[3] - box[1]) * size[1]);
export const SHELF_BOX: ArtBox = [0.0113, 0.2961, 0.9882, 0.7820];
export const SHELF_ASPECT = visibleAspect(SHELF_BOX, [2116, 743]);
export const QUEST_BOX: ArtBox = [0.0414, 0.1551, 0.9637, 0.8020];
export const QUEST_ASPECT = visibleAspect(QUEST_BOX, [1983, 793]);
export const ACTION_BOX: ArtBox = [0.0332, 0.1230, 0.9687, 0.8968];
export const ACTION_ASPECT = visibleAspect(ACTION_BOX, [2079, 756]);
// 任务签「签身」在可见框内的相对位置：文字必须落在这条带上，而不是按内容高度居中。
const QUEST_BAND_BOX: ArtBox = [0.0414, 0.3000, 0.9637, 0.7800];
export const QUEST_BAND_ASPECT = visibleAspect(QUEST_BAND_BOX, [1983, 793]);
const QUEST_TEXT_TOP = (0.3468 - 0.1551) / (0.8020 - 0.1551);
const QUEST_TEXT_HEIGHT = (0.7415 - 0.3468) / (0.8020 - 0.1551);
// 三礁中心在裁剪框内的相对位置（原图内 15.97%/49.53%/83.62% 换算）。
const SHELF_TRIM_CENTERS = [0.1519, 0.4955, 0.8443] as const;

/** 按原画可见范围裁剪并等比铺满容器：手绘件不再被拉伸，且随容器宽度一起缩放。 */
export function TrimmedArt({ source, box, style, children }: { source: number; box: ArtBox; style?: StyleProp<ViewStyle>; children?: ReactNode }) {
  const [x0, y0, x1, y1] = box;
  const w = x1 - x0;
  const h = y1 - y0;
  return <View style={[{ overflow: "hidden" }, style]}>
    <Image
      source={source}
      resizeMode="stretch"
      accessible={false}
      fadeDuration={0}
      style={{
        position: "absolute",
        left: (((-x0 / w) * 100).toFixed(3) + "%") as DimensionValue,
        top: (((-y0 / h) * 100).toFixed(3) + "%") as DimensionValue,
        width: ((100 / w).toFixed(3) + "%") as DimensionValue,
        height: ((100 / h).toFixed(3) + "%") as DimensionValue,
      }}
    />
    {children}
  </View>;
}

/** 游戏 HUD 只接收展示数据和操作，不持有余额、次数或结算规则。 */
export function LagoonHeader({ language, balance, attempts, practice, onBack, onLanguage, onHelp, onSupply, onBuyPoints }: {
  language: string; balance: string; attempts: string; practice: boolean;
  onBack: () => void; onLanguage: () => void; onHelp: () => void; onSupply: () => void; onBuyPoints: () => void;
}) {
  const t = usePearlT();
  const compact = useWindowDimensions().width < 360;
  const [walletOpen, setWalletOpen] = useState(false);
  const walletButton = useRef<View>(null);
  useEffect(() => {
    if (Platform.OS !== "web" || !walletOpen) return;
    const dismiss = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      setWalletOpen(false);
      walletButton.current?.focus();
    };
    window.addEventListener("keydown", dismiss);
    return () => window.removeEventListener("keydown", dismiss);
  }, [walletOpen]);
  return <View style={s.header}>
    <View style={s.topline}>
      <Pressable accessibilityRole="button" accessibilityLabel={t("Back to home")} style={s.iconButton} onPress={onBack}><ArrowLeft size={20} strokeWidth={1.6} color={ink} /></Pressable>
      <View style={s.wordmark}>
        <Text style={s.kicker}>PEARL LAGOON</Text>
        <Text accessibilityRole="header" style={s.title}>{t("Pearl Lagoon")}</Text>
      </View>
      <Pressable accessibilityRole="button" accessibilityLabel={t("Language")} style={s.iconButton} onPress={onLanguage}><Text style={s.language}>{language === "en" ? "中" : "EN"}</Text></Pressable>
      <Pressable accessibilityRole="button" accessibilityLabel={t("How to play")} style={s.iconButton} onPress={onHelp}><CircleHelp size={20} strokeWidth={1.6} color={ink} /></Pressable>
    </View>
    <View style={s.resources}>
      <View style={s.attempts}>
        <Image source={lagoonArt.tide} style={s.counterArt} resizeMode="contain" accessible={false} />
        <View style={s.resourceCopy}><Text numberOfLines={1} adjustsFontSizeToFit style={[s.resourceLabel, compact && s.resourceLabelCompact]}>{t(practice ? "Exploration mode" : "Free explorations")}</Text><Text testID="pearl-free-remaining" numberOfLines={1} adjustsFontSizeToFit style={[s.resourceValue, compact && s.resourceValueCompact]}>{attempts}</Text></View>
      </View>
      <Pressable ref={walletButton} accessibilityRole="button" accessibilityLabel={t("Shell wallet")} accessibilityState={{ expanded: walletOpen }} style={s.wallet} onPress={() => setWalletOpen((open) => !open)}>
        <Image source={lagoonArt.coins} style={s.counterArt} resizeMode="contain" accessible={false} />
        <View style={s.resourceCopy}><Text numberOfLines={1} adjustsFontSizeToFit style={[s.resourceLabel, compact && s.resourceLabelCompact]}>{t("Shell coins")}</Text><Text testID="pearl-coin-balance" numberOfLines={1} adjustsFontSizeToFit style={[s.resourceValue, compact && s.resourceValueCompact]}>{balance}</Text></View>
        <View style={s.walletToggle}>{walletOpen ? <X size={16} color="#FFF0C8" /> : <Plus size={16} color="#FFF0C8" />}</View>
      </Pressable>
    </View>
    {walletOpen ? <View testID="pearl-wallet-menu" style={s.walletMenu}>
      <Text style={s.menuTitle}>{t("Shell wallet")}</Text>
      <Pressable accessibilityRole="button" onPress={() => { setWalletOpen(false); onSupply(); }} style={s.menuAction}><Image source={lagoonArt.play} style={s.menuArt} resizeMode="contain" accessible={false} /><Text style={s.menuText}>{t("Points to shell coins")}</Text><ChevronRight size={16} color="#796841" /></Pressable>
      <Pressable accessibilityRole="button" onPress={() => { setWalletOpen(false); onBuyPoints(); }} style={s.menuAction}><Plus size={18} color="#796841" /><Text style={s.menuText}>{t("Buy points")}</Text><ChevronRight size={16} color="#796841" /></Pressable>
      <Text style={s.menuNote}>{t("Shell coins stay in the lagoon.")}</Text>
    </View> : null}
  </View>;
}

export function LagoonQuest({ title, caption, done, goal, practice, actionLabel, onAction, hint, infoOpen, onToggleInfo, onPress }: {
  title: string; caption: string; done: number; goal: number; practice: boolean;
  actionLabel: string | null; onAction: () => void; hint: string;
  infoOpen: boolean; onToggleInfo: () => void; onPress: () => void;
}) {
  const t = usePearlT();
  // 手绘签就是收纳说明文字的容器：标题/说明在左，主动作按钮与「?」在右。
  const label = t("Today's little adventure") + ", " + done + "/" + goal;
  // 只留一条透明细行：标题 + 进度 + 主动作 + 玩法提示，不再有大底板挡海景（用户要求去掉框）。
  return <View style={s.questWrap}>
    <View style={s.questRow}>
      <Text style={s.questTitle} numberOfLines={1}>{title}</Text>
      {!practice ? <Text style={s.progressCount}>{done} / {goal}</Text> : null}
      {actionLabel ? <Pressable accessibilityRole="button" style={s.questAction} onPress={onAction}><Text style={s.questActionText} numberOfLines={1}>{actionLabel}</Text></Pressable> : null}
      <Pressable accessibilityRole="button" accessibilityLabel={t("How to play")} accessibilityState={{ expanded: infoOpen }} style={s.questInfo} onPress={onToggleInfo}><Text style={s.questInfoText}>?</Text></Pressable>
      {caption ? <Text style={s.questCaption} numberOfLines={1}>{caption}</Text> : null}
    </View>
    {infoOpen ? <Text style={s.questHint}>{hint}</Text> : null}
  </View>;
}

export function LagoonNavigation({ panel, count, footer, onChange }: { panel: string; count: number; footer: string; onChange: (panel: "play" | "collection" | "reef") => void }) {
  const t = usePearlT();
  const entries = [
    { id: "play" as const, label: "Explore" },
    { id: "collection" as const, label: "Collection" },
    { id: "reef" as const, label: "My reef" },
  ];
  // 礁石图随容器宽度等比缩放，图标按实测比例定位：任何屏宽都落在礁石正中。
  const windowWidth = useWindowDimensions().width;
  const navWidth = Math.max(272, windowWidth - 24);
  const shelfArtHeight = Math.round(navWidth / SHELF_ASPECT);
  const itemWidth = Math.round(navWidth / 3);
  const navHeight = Math.max(130, SHELF_ROCK_Y + shelfArtHeight + 26);
  return <View style={s.dock}>
    <LinearGradient pointerEvents="none" colors={["rgba(246,242,219,0)", "rgba(246,242,219,0.66)", "#EEE8CD"]} locations={[0,0.7,1]} style={StyleSheet.absoluteFillObject} />
    <View style={[s.navigation, { height: navHeight }]}>
      <View pointerEvents="none" style={[s.shelves, { top: SHELF_ROCK_Y, height: shelfArtHeight }]}><TrimmedArt source={lagoonArt.shelves} box={SHELF_BOX} style={{ width: "100%", height: "100%" }} /></View>
      {entries.map(({ id, label }, index) => {
        const active = panel === id;
        return <Pressable key={id} accessibilityRole="tab" accessibilityState={{ selected: active }} aria-selected={active} style={[s.navItem, { left: Math.round(navWidth * SHELF_TRIM_CENTERS[index]) - Math.round(itemWidth / 2), width: itemWidth }]} onPress={() => onChange(id)}>
          <Image source={lagoonArt[id]} resizeMode="contain" accessible={false} style={[s.navArt, active && s.navArtActive]} />
          <View style={s.navLabelRow}><Text style={[s.navLabel, active && s.navLabelActive]}>{t(label)}</Text>{id === "collection" ? <Text style={s.collectionCount}>{count}/7</Text> : null}</View>
        </Pressable>;
      })}
    </View>
    <Text style={s.footer}>{footer}</Text>
  </View>;
}

const s = StyleSheet.create({
  header: { paddingHorizontal: 12, paddingTop: 2, zIndex: 20 },
  topline: { flexDirection: "row", alignItems: "center", gap: 2, marginBottom: 0 },
  iconButton: { width: 44, height: 44, alignItems: "center", justifyContent: "center", borderRadius: 4 },
  wordmark: { flex: 1, paddingLeft: 8, minWidth: 0 },
  kicker: { color: "#2D6362", fontSize: 8, fontWeight: "700", letterSpacing: 2.4, marginBottom: 3 },
  title: { color: ink, fontSize: 22, fontWeight: "700", letterSpacing: 1.3, fontFamily: Platform.OS === "web" ? 'Georgia, "Songti SC", "Noto Serif TC", serif' : undefined },
  language: { color: ink, fontSize: 12, fontWeight: "700", letterSpacing: 0.6 },
  resources: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: -4 },
  attempts: { flex: 1, aspectRatio: 2.18, justifyContent: "center" },
  counterArt: { ...StyleSheet.absoluteFillObject, width: "100%", height: "100%" },
  // 文案在贝壳装饰与右侧补给按钮之间居中，两块牌共用同一对齐线。
  resourceCopy: { marginLeft: "38%", marginRight: "17%", marginTop: 7, gap: 0 },
  resourceLabel: { fontSize: 10, lineHeight: 13, color: "#FCF0D6", textAlign: "center" },
  resourceLabelCompact: { fontSize: 8, lineHeight: 10 },
  resourceValueCompact: { fontSize: 17, lineHeight: 19 },
  resourceValue: { color: "#FFF7DD", fontSize: 20, lineHeight: 23, fontWeight: "700", textAlign: "center", fontVariant: ["tabular-nums"], textShadowColor: "#174C48", textShadowRadius: 2, textShadowOffset: { width: 0, height: 1 } },
  wallet: { flex: 1, aspectRatio: 2.18, justifyContent: "center" },
  walletToggle: { position: "absolute", right: "8%", top: "44%" },
  walletMenu: { position: "absolute", right: 0, top: "100%", width: 260, padding: 18, borderRadius: 9, borderWidth: 1, borderColor: "#ADAD83", backgroundColor: "#F7F0D9", shadowColor: "#082B31", shadowOpacity: 0.15, shadowRadius: 15, shadowOffset: { width: 0, height: 8 }, elevation: 8 },
  menuTitle: { color: ink, fontSize: 16, fontWeight: "700", marginBottom: 8 },
  menuAction: { minHeight: 48, flexDirection: "row", alignItems: "center", gap: 10, borderBottomWidth: 1, borderBottomColor: "#D8D9B9" },
  menuArt: { width: 28, height: 28 },
  menuText: { flex: 1, color: ink, fontSize: 12 },
  menuNote: { color: "#4E695C", fontSize: 11, lineHeight: 17, marginTop: 12 },
  questWrap: { marginHorizontal: 12, marginTop: 2, marginBottom: 2 },
  questRow: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, minHeight: 30, paddingHorizontal: 8 },
  questAction: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 999, backgroundColor: "rgba(255,251,240,0.88)", borderWidth: 1, borderColor: "rgba(150,124,72,0.5)" },
  questActionText: { color: "#5B431E", fontSize: 11, fontWeight: "700" },
  questInfo: { width: 22, height: 22, borderRadius: 11, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "rgba(90,120,105,0.5)", backgroundColor: "rgba(255,255,255,0.5)" },
  questInfoText: { color: "#3C5A50", fontSize: 12, fontWeight: "700", lineHeight: 14 },
  questHint: { color: "#355E51", fontSize: 11, lineHeight: 16, textAlign: "center", marginTop: 4, paddingHorizontal: 18 },
  questTitle: { color: "#244C43", fontSize: 13, lineHeight: 18, fontWeight: "700" },
  questCaption: { color: "#365A50", fontSize: 10, lineHeight: 14 },
  progressCount: { color: "#244C43", fontSize: 13, fontWeight: "700", textAlign: "center", fontVariant: ["tabular-nums"] },
  dock: { paddingHorizontal: 12, paddingBottom: 7, paddingTop: 0 },
  navigation: { height: 142 },
  shelves: { position: "absolute", left: 0, top: 38, width: "100%", height: 126 },
  navItem: { position: "absolute", top: 0, alignItems: "center", justifyContent: "flex-start" },
  navArt: { width: "100%", maxWidth: 132, height: 112 },
  navArtActive: { transform: [{ translateY: -4 }] },
  navLabelRow: { flexDirection: "row", alignItems: "baseline", justifyContent: "center", gap: 4 },
  collectionCount: { color: "#59705E", fontSize: 9, fontVariant: ["tabular-nums"] },
  navLabel: { fontSize: 12, fontWeight: "700", color: "#244C43", letterSpacing: 0.5, textShadowColor: "#FFF5DA", textShadowRadius: 3, textShadowOffset: { width: 0, height: 1 } },
  navLabelActive: { color: "#7B5627", fontWeight: "800" },
  footer: { color: "#596F5E", textAlign: "center", fontSize: 9, lineHeight: 14, paddingTop: 3 },
});
